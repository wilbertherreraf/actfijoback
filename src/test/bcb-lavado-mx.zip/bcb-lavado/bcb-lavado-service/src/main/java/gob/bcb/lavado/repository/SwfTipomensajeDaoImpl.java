package gob.bcb.lavado.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfTipomensaje;

@Repository("swfTipomensajeDao")
@Transactional
public class SwfTipomensajeDaoImpl implements SwfTipomensajeDao {
	private static final Logger log = LoggerFactory.getLogger(SwfTipomensajeDaoImpl.class);
	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;
	
	@Autowired
	@Qualifier("entityManagerFactory")	
	private EntityManagerFactory entityManagerFactory;

	public SwfTipomensaje getByCodigo(String timCodmt) {
		String jpql = "SELECT t FROM SwfTipomensaje t ";
		jpql = jpql.concat("WHERE t.timCodmt = :timCodmt ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("timCodmt", timCodmt);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfTipomensaje) lista.get(0);
		}

		return null;

	}
}
