package gob.bcb.lavado.services;

import java.util.Locale;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.CharEncoding;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring4.SpringTemplateEngine;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.lavado.client.pojos.GenLauDto;
import gob.bcb.lavado.client.utils.UtilsDate;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfParamsDao;

@Service("mailService")
public class MailServiceImpl implements MailService {
	private static final Logger log = LoggerFactory.getLogger(MailServiceImpl.class);

	@Autowired
	private JavaMailSenderImpl javaMailSender;
	@Autowired
	private SpringTemplateEngine templateEngine;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private AppProperties appProperties;

	//@Async
	private void sendEmail(String from, String[] to, String subject, String content, boolean isMultipart, ArchivoSinple archivoSinple, boolean isHtml) {
		log.info("Send e-mail[multipart '{}' and html '{}'] to '{}' with subject '{}' and content={}", isMultipart, isHtml, to, subject, content);
		// Prepare message using a Spring helper
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		
		if (StringUtils.isBlank(from)){
			SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CORREOREMITENTE);
			if (swfParams == null){
				throw new RuntimeException("Parametro {" + Constants.PARAM_CORREOREMITENTE + "} de correo remitente en Parámetros nulo");
			}
			from = swfParams.getParValor();
		}
		final String[] tokens = StringUtils.split(from, ",;");
		if (tokens.length > 1){
			throw new RuntimeException("Existe más de un correo remitente registrado: " + from);
		}
		try {
			MimeMessageHelper message = new MimeMessageHelper(mimeMessage, isMultipart, CharEncoding.UTF_8);

			message.setFrom(from);
			message.setSubject(subject);
			message.setText(content, isHtml);
			message.setTo(to);
			if (archivoSinple != null) {
				Resource resource = new ByteArrayResource(archivoSinple.getData());
				message.addAttachment(archivoSinple.getNameOriginal(), resource);
			}
		
//			for (int i = 0; i < to.length; i++) {
//				if (!StringUtils.isBlank(to[i])){
//					message.setTo(to[i]);
//					log.info("[{}]==>Sent e-mail to User '{}'", i, to[i]);
//					javaMailSender.send(mimeMessage);
//				}
//			}

			javaMailSender.send(mimeMessage);
			log.info("==>Sent e-mail to User '{}'", ArrayUtils.toString(to));
		} catch (NullPointerException e) {			
			log.error("Error al enviar valor nulo" + e.getMessage(),e);
			throw new RuntimeException("Error al enviar valor nulo", e);
		} catch (MessagingException e) {
			log.error("Error al enviar valor " + e.getMessage(),e);
			throw new RuntimeException("Error al enviar "  + e.getMessage(), e);			
		} catch (Exception e) {
			// no se envia error
			log.error("Error al enviar " + e.getMessage(),e);
			throw new RuntimeException("Error al enviar "  + e.getMessage(), e);			
		}
	}

	@Async
	public void sendAlertSwiftForRevisionEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle, ArchivoSinple archivoSinple) {
		log.info("Sending sendAlertSwiftForRevisionEmail e-mail to '{}'", ArrayUtils.toString(emailDetalle.getTo()));
		Locale locale = Locale.getDefault();
		Context context = new Context(locale);
		context.setVariable("swfMensaje", mensajesDatos.getSwfMensaje());
		log.debug("Thymeleaf Initialized " + templateEngine.isInitialized());
		if (!templateEngine.isInitialized()) {
			templateEngine.initialize();
			log.info("Thymeleaf initialized!!! " + templateEngine.isInitialized());
		}

		String content = templateEngine.process("alertaVerificacionEmail", context);

		if (StringUtils.isBlank(emailDetalle.getSubject())){
			String subject = messageSource.getMessage("email.alertalavado.title", null, locale);			
			emailDetalle.setSubject(subject);
		}
		sendEmail(null, emailDetalle.getTo(), emailDetalle.getSubject(), content, false, null, true);
	}

	@Async
	public void sendAlertSwiftAutorizadoEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle, ArchivoSinple archivoSinple) {
		log.info("Sending sendAlertSwiftAutorizadoEmail e-mail to '{}'", ArrayUtils.toString(emailDetalle.getTo()));
		Locale locale = Locale.getDefault();
		Context context = new Context(locale);
		context.setVariable("swfMensaje", mensajesDatos.getSwfMensaje());
		log.debug("Thymeleaf Initialized " + templateEngine.isInitialized());
		if (!templateEngine.isInitialized()) {
			templateEngine.initialize();
			log.info("Thymeleaf initialized!!! " + templateEngine.isInitialized());
		}

		String content = templateEngine.process("alertaAutorizacionEmail", context);
		String subject = messageSource.getMessage("email.alertaautorizacion.title", null, locale);

		sendEmail(null, emailDetalle.getTo(), subject, content, false, null, true);
	}
	
	public void sendAlertCodeLauEmail(GenLauDto genLauDto, EmailDetalle emailDetalle) {
		log.info("Sending sendAlertCodeLauEmail e-mail to '{}'", ArrayUtils.toString(emailDetalle.getTo()));
		Locale locale = Locale.getDefault();
		Context context = new Context(locale);
		context.setVariable("emailDetalle", emailDetalle);
		context.setVariable("genLauDto", genLauDto);
		context.setVariable("fechacreacion", UtilsDate.stringFromDate(genLauDto.getFechaCreacion(), "dd/MM/yyyy") );
		context.setVariable("fechacaduca", UtilsDate.stringFromDate(genLauDto.getFechaCaducidad(), "dd/MM/yyyy") );		
		
		log.debug("Thymeleaf Initialized " + templateEngine.isInitialized());
		if (!templateEngine.isInitialized()) {
			templateEngine.initialize();
			log.info("Thymeleaf initialized!!! " + templateEngine.isInitialized());
		}

		String content = templateEngine.process("alertaCodeLauEmail", context);
		String subject = emailDetalle.getSubject();

		sendEmail(null, emailDetalle.getTo(), subject, content, false, null, true);
	}	
	
	//@Async
	public void sendSwiftAsignForProcessWithAttachEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle, ArchivoSinple archivoSinple) {
		log.info("Sending creation sendSwiftAsignForProcessWithAttachEmail e-mail to '{}'", ArrayUtils.toString(emailDetalle.getTo()));
		Locale locale = Locale.getDefault();
		Context context = new Context(locale);
		context.setVariable("swfMensaje", mensajesDatos.getSwfMensaje());
		log.debug("Thymeleaf Initialized " + templateEngine.isInitialized());
		if (!templateEngine.isInitialized()) {
			templateEngine.initialize();
			log.info("Thymeleaf initialized!!! " + templateEngine.isInitialized());
		}

		String content = templateEngine.process("envioConAdjunto", context);
		String subject = messageSource.getMessage("email.sendattach.title", null, locale);

		sendEmail(null, emailDetalle.getTo(), subject, content, true, archivoSinple, true);
	}
	
	@Async
	public void sendConfirmaSolicNroSwiftEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle) {
		log.info("Sending confirmation e-mail to '{}'", ArrayUtils.toString(emailDetalle.getTo()));

		Locale locale = Locale.getDefault();
		Context context = new Context(locale);
		context.setVariable("swfPersona", mensajesDatos.getAsignacion().getSwfPersona());
		context.setVariable("baseUrl", emailDetalle.getParams().get("urlreq"));
		
		//UriComponentsBuilder.fromUriString(baseUrl).queryParam("token", page).toUriString();
		log.info("Thymeleaf Initialized " + templateEngine.isInitialized());
		if (!templateEngine.isInitialized()) {
			templateEngine.initialize();
			log.info("Thymeleaf initialized!!! " + templateEngine.isInitialized());
		}

		String content = templateEngine.process("confirmaNroSwiftEmail", context);

		if (StringUtils.isBlank(emailDetalle.getSubject())){
			String subject = messageSource.getMessage("email.activation.title", null, locale);			
			emailDetalle.setSubject(subject);
		}
		log.info("URL Confirma {}", emailDetalle.getParams().get("urlreq"));
		sendEmail(emailDetalle.getFrom(), emailDetalle.getTo(), emailDetalle.getSubject(), content, false, null, true);
	}

	private static String generateUri(String baseUrl, int page, int size) {
        return UriComponentsBuilder.fromUriString(baseUrl).queryParam("page", page).queryParam("size", size).toUriString();
    }

}
