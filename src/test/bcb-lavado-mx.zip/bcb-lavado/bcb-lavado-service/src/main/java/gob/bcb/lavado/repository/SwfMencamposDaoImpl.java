package gob.bcb.lavado.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.pojos.MensajesDatos;

@Repository("swfMencamposDao")
public class SwfMencamposDaoImpl implements SwfMencamposDao {
	private static final Logger log = LoggerFactory.getLogger(SwfMencamposDaoImpl.class);

	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;

	@Autowired
	@Qualifier("entityManagerFactory")
	private EntityManagerFactory entityManagerFactory;

	public List<MensajesDatos> camposPorMensaje(Integer menEstmensaje) {
		String jsql = "select distinct dem_codcampo, ";
		jsql = jsql.concat("nvl((select a.mtf_descrip ");
		jsql = jsql.concat("from swf_mencampos a ");
		jsql = jsql.concat("where  a.mtf_codcampo = dem_codcampo ");
		jsql = jsql.concat("and a.mtf_codmt = men_codmt ");
		jsql = jsql.concat("and a.mtf_nro = (select min(b.mtf_nro) from swf_mencampos b where  b.mtf_codcampo = dem_codcampo ");
		jsql = jsql.concat("and b.mtf_codmt = men_codmt)), 'SIN DESCRIP.') ");
		jsql = jsql.concat("from Swf_Mensaje, swf_detmensaje ");
		jsql = jsql.concat("where men_codmen = dem_codmen ");
		jsql = jsql.concat("and men_estmensaje = :menEstmensaje ");

		Query query = entityManager.createNativeQuery(jsql);
		query.setParameter("menEstmensaje", menEstmensaje);

		List<MensajesDatos> unidadOrgCoinLista = new ArrayList<MensajesDatos>();
		try {
			List<Object[]> result = query.getResultList();
			for (Object[] resultObj : result) {
				MensajesDatos unidadOrgCoin = new MensajesDatos();
				unidadOrgCoin.setMenCampoaux1((String) resultObj[0]);
				unidadOrgCoin.setMenCampoaux1descrip((String) resultObj[1]);

				unidadOrgCoinLista.add(unidadOrgCoin);
			}

		} catch (Exception e) {
			log.error("Error al consultar  camposPorMensaje: " + e.getMessage(), e);
			throw new SwiftAdminException("Error al consultar  camposPorMensaje : " + e.getMessage(), e);
		}

		return unidadOrgCoinLista;

	}

	public List<MensajesDatos> camposPorCodMens(Integer menCodmen, Integer resCodemp) {
		String jsql = "select distinct dem_codcampo, ";
		jsql = jsql.concat("nvl((select a.mtf_descrip ");
		jsql = jsql.concat("from swf_mencampos a ");
		jsql = jsql.concat("where  a.mtf_codcampo = dem_codcampo ");
		jsql = jsql.concat("and a.mtf_codmt = men_codmt ");
		jsql = jsql.concat("and a.mtf_nro = (select min(b.mtf_nro) from swf_mencampos b where  b.mtf_codcampo = dem_codcampo ");
		jsql = jsql.concat("and b.mtf_codmt = men_codmt)), 'SIN DESCRIPCION: ' || dem_codcampo ) ");
		jsql = jsql.concat("from swf_Mensaje, swf_detmensaje ");
		jsql = jsql.concat("where men_codmen = dem_codmen ");
		jsql = jsql.concat("and men_estmensaje in (1,2) ");
		jsql = jsql.concat(
				"and exists(select 1 from swf_asignamensaje where res_codmen = men_codmen and res_codemp = :resCodemp) ");

		log.info("get campos mensajes pend. " + resCodemp + " -> " + jsql);
		Query query = entityManager.createNativeQuery(jsql);
		query.setParameter("resCodemp", resCodemp);

		List<MensajesDatos> mensajesDatosLista = new ArrayList<MensajesDatos>();
		try {
			List<Object[]> result = query.getResultList();
			for (Object[] resultObj : result) {
				MensajesDatos mensajesDatos = new MensajesDatos();
				mensajesDatos.setMenCampoaux1((String) resultObj[0]);
				mensajesDatos.setMenCampoaux1descrip((String) resultObj[1]);

				mensajesDatosLista.add(mensajesDatos);
			}

		} catch (Exception e) {
			log.error("Error al ejecutar consulta campos : " + e.getMessage(), e);
			throw new SwiftAdminException("Error al consultar campos : " + e.getMessage(), e);
		}

		return mensajesDatosLista;
	}
}
