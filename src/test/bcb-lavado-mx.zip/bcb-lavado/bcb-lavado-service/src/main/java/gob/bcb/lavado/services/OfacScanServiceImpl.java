package gob.bcb.lavado.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.concurrent.Future;

import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.search.DocumentBatch;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.indexer.JPASearchFactoryController;
import gob.bcb.lavado.search.presearcher.HighlightingMatcher;
import gob.bcb.lavado.search.presearcher.MatchAllPresearcher;
import gob.bcb.lavado.search.presearcher.PhrasePresearcher;
import gob.bcb.lavado.search.presearcher.PresearcherMatcher;
import gob.bcb.lavado.search.presearcher.SimpleMatcher;
import gob.bcb.lavado.search.presearcher.SpanPhrasePreseacher;
import gob.bcb.lavado.search.presearcher.TermsPreseacher;
import gob.bcb.lavado.search.queryparsers.QueryParsersBuilder;
import gob.bcb.lavado.strategy.StrategyBase;
import gob.bcb.lavado.strategy.ValidatorStrategy;

//@Service
public class OfacScanServiceImpl {
	private static final Logger log = LoggerFactory.getLogger(OfacScanServiceImpl.class);
	public static final int MAX_CHARS_LOG = 88;
	
	private final JPASearchFactoryController jPASearchFactoryController;

//	public OfacScanServiceImpl() {
//		this.jPASearchFactoryController = null;
//		this.fieldQueryLista = null;
//	}

	public OfacScanServiceImpl(JPASearchFactoryController jPASearchFactoryController) {
		this.jPASearchFactoryController = jPASearchFactoryController;
	}

	public DocumentBatch<SearchResultOfac> search(String query, List<FieldQuery> fieldQueryLista) throws IOException {
		DocumentBatch<SearchResultOfac> documentBatchResultS = new DocumentBatch<SearchResultOfac>();
		if (fieldQueryLista == null || fieldQueryLista.size() == 0)
			return documentBatchResultS;

		if (log.isDebugEnabled())
			for (FieldQuery fieldQuery : fieldQueryLista) {
				log.info(
						"Questions to execute for [" + query + "] : " + fieldQuery.getId() + " " + fieldQuery.getField() + " " + fieldQuery.getQueryTemplate()
								+ " " + fieldQuery.getAnalyzer().getClass().getSimpleName() + " " + fieldQuery.getValidatorStrategy().getType().toString());
			}
		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();

		log.info("@@@@@@@@@@@@@@@ init[" + fieldQueryLista.get(0).getIdStrategy() + ":" + fieldQueryLista.get(0).getId() + "] @@@@@@@@@@@@@@@@@@@@ ");
//		log.info("Questions[" + fieldQueryLista.size() + "] to execute for " + fieldQueryLista.get(0).getQueryTemplate() + " "
//				+ fieldQueryLista.get(0).getAnalyzer().getClass().getSimpleName() + " " + fieldQueryLista.get(0).getValidatorStrategy().getType().toString());

		if (fieldQueryLista.size() > 1) {
			if (fieldQueryLista.get(0).getValidatorStrategy().getType().compareTo(ValidatorStrategy.ValidatorType.SIMPLE) >= 0) {
//				log.info("Before of SpanPhrasePreseacher SIMPLE");
				for (FieldQuery fieldQuerysub : fieldQueryLista) {
//					log.info("Before of SpanPhrasePreseacher SIMPLE Field " + fieldQuerysub.getField());					
					MatchAllPresearcher matchAllPresearcher = new MatchAllPresearcher(jPASearchFactoryController,
							new SpanPhrasePreseacher(jPASearchFactoryController), fieldQuerysub);
					matchAllPresearcher.addFieldQuery(query);
					DocumentBatch<SearchResultOfac> documentBatchResultR = matchAllPresearcher.match(documentBatchResultS, SimpleMatcher.FACTORY);
					documentBatchResultR.forEach(doc -> {
						documentBatchResultS.add(doc);
					});
				}

				for (SearchResultOfac searchResultOfac : documentBatchResultS) {
					documentBatchResult.add(searchResultOfac);
				}
			}
			/*******************/
			if (documentBatchResult.getBatchSize() > 0
					&& (fieldQueryLista.get(0).getValidatorStrategy().getType().compareTo(ValidatorStrategy.ValidatorType.MEDIUM) >= 0)) {
				log.info("Before of TermsPreseacher MEDIUM with docs: " + documentBatchResult.getBatchSize());
				for (FieldQuery fieldQuerysub : fieldQueryLista) {
					MatchAllPresearcher matchAllPresearcher = new MatchAllPresearcher(jPASearchFactoryController,
							new TermsPreseacher(jPASearchFactoryController), fieldQuerysub);
					matchAllPresearcher.addFieldQuery(query);

					documentBatchResult = matchAllPresearcher.match(documentBatchResult, PresearcherMatcher.FACTORY);
					matchAllPresearcher.continueSearch(documentBatchResult, matchAllPresearcher.validate(documentBatchResult));
				}
			}
			/*******************/
			if (documentBatchResult.getBatchSize() > 0
					&& (fieldQueryLista.get(0).getValidatorStrategy().getType().compareTo(ValidatorStrategy.ValidatorType.EXACT) >= 0)) {
				log.info("Before of PhrasePresearcher EXACT with docs: " + documentBatchResult.getBatchSize());
				for (FieldQuery fieldQuerysub : fieldQueryLista) {
					MatchAllPresearcher matchAllPresearcher = new MatchAllPresearcher(jPASearchFactoryController,
							new PhrasePresearcher(jPASearchFactoryController), fieldQuerysub);

					documentBatchResult = matchAllPresearcher.match(query, documentBatchResult, HighlightingMatcher.FACTORY);
				}
			}
		} else {
			if (fieldQueryLista.get(0).getValidatorStrategy().getType().compareTo(ValidatorStrategy.ValidatorType.SIMPLE) >= 0) {
//				log.info("Simple: Before of SpanPhrasePreseacher SimpleMatcher");
				MatchAllPresearcher matchAllPresearcher = new MatchAllPresearcher(jPASearchFactoryController,
						new SpanPhrasePreseacher(jPASearchFactoryController), fieldQueryLista.get(0));
				matchAllPresearcher.addFieldQuery(query);
				documentBatchResult = matchAllPresearcher.match(documentBatchResultS, SimpleMatcher.FACTORY);
			}

			if (documentBatchResult.getBatchSize() > 0)
				if (fieldQueryLista.get(0).getValidatorStrategy().getType().compareTo(ValidatorStrategy.ValidatorType.EXACT) >= 0) {
					log.info("Simple: Before of PhrasePresearcher HighlightingMatcher EXACT with docs: " + documentBatchResult.getBatchSize());
					MatchAllPresearcher matchAllPresearcher = new MatchAllPresearcher(jPASearchFactoryController,
							new PhrasePresearcher(jPASearchFactoryController), fieldQueryLista.get(0));

					documentBatchResult = matchAllPresearcher.match(query, documentBatchResult, HighlightingMatcher.FACTORY);
				}
		}

		log.info("@@@@@ Total matches " + (documentBatchResult.getBatchSize() > 0) + " [" + fieldQueryLista.get(0).getIdStrategy() + ":"
				+ fieldQueryLista.get(0).getId() + "][" + documentBatchResult.getBatchSize() + "] @@@@@");

		if (log.isDebugEnabled()) {
			printMatches(documentBatchResult);
		}

		return documentBatchResult;
	}


	public DocumentBatch<SearchResultOfac> searchForFieldSwift(String query, String fieldSwift, StrategyBase strategyBase, boolean exitOnFirstFound)
			throws Exception {

		Map<String, Map<String, List<FieldQuery>>> docs = strategyBase.matchesForFieldswift(fieldSwift);
		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();
		if (docs == null || docs.size() == 0) {
			log.info("==>> field: " + fieldSwift + " Sin estrategias!!!");
			return documentBatchResult;
		}
		long buildTime = System.currentTimeMillis();

		log.info("===oooO0[Inicio scan field swift[" + fieldSwift + "] query:\n" + query + "\n]0Oooo===");
//		log.info("query:: " + query);

		for (Entry<String, Map<String, List<FieldQuery>>> fieldQueryMapE : docs.entrySet()) {
			// ciclo por idstrategia
			/* ####### process search ###### */
			DocumentBatch<SearchResultOfac> documentBatchResultR = search(query, fieldQueryMapE.getValue());
			for (SearchResultOfac searchResultOfacR : documentBatchResultR) {
				documentBatchResult.add(searchResultOfacR);
			}
			if (exitOnFirstFound && documentBatchResult.getBatchSize() > 0) { 
				break;
			}
		}

		log.info("==>> FIN scan field: [" + fieldSwift + "] Con registros: " + documentBatchResult.getBatchSize() + "["
				+ (System.currentTimeMillis() - buildTime) + " ms.]");

		return documentBatchResult;
	}

	public DocumentBatch<SearchResultOfac> search(String query, Map<String, List<FieldQuery>> fieldQueryMap) throws IOException {
		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();
		DocumentBatch<SearchResultOfac> documentBatchResultMust = new DocumentBatch<SearchResultOfac>();

		int cont = 1;
		boolean haveMust = false;
		boolean querySimple = true;
		
		for (List<FieldQuery> fieldQueryEntry : fieldQueryMap.values()) {
			if (fieldQueryEntry.size() == 0)
				continue;

			for (FieldQuery fieldQuery : fieldQueryEntry) {
				if (log.isDebugEnabled())
					log.info("[fieldsswf[" + fieldQuery.getIdStrategy() + "]: fieldQueryLista " + fieldQuery.getId() + " Field:" + fieldQuery.getField()
							+ " QueryTemplate: " + fieldQuery.getQueryTemplate() + " DistanceUpTo: " + fieldQuery.getDistanceUpTo() + " Junction: "
							+ fieldQuery.getJunction());

				if (fieldQuery.getJunction().equals(BooleanClause.Occur.MUST)) {
					haveMust = true;
					break;
				}
			}
		}

		for (Entry<String, List<FieldQuery>> fieldQueryEntry : fieldQueryMap.entrySet()) {
			List<FieldQuery> fieldQueryLista = fieldQueryEntry.getValue();
			if (fieldQueryLista.size() == 0)
				continue;
//			log.info("Inicio Idquery " + fieldQueryEntry.getKey() + " " + fieldQueryLista.get(0).getJunction().name());
			/* ####### process search ###### */
			DocumentBatch<SearchResultOfac> documentBatchResultR = search(query, fieldQueryLista);
			BooleanClause.Occur junction = fieldQueryLista.get(0).getJunction();
			if (junction.equals(BooleanClause.Occur.MUST))
				if (documentBatchResultR.getBatchSize() == 0)
					// es obligatorio que tenga, por lo tanto si no hay
					// resultados se abandona el ciclo
					// return new
					// AsyncResult<DocumentBatch<SearchResultOfac>>(documentBatchResultR);
					return documentBatchResultR;

			if (junction.equals(BooleanClause.Occur.MUST_NOT))
				if (documentBatchResultR.getBatchSize() != 0) {
					// si se encontro al menos un registro se infiere que no se
					// incluya en el resultado
					log.warn("-->En lista blanca!!!!! " + documentBatchResultR.getBatchSize() + " regs encontrados, Idquery " + fieldQueryEntry.getKey() + " "
							+ fieldQueryLista.get(0).getJunction().name());
					return new DocumentBatch<SearchResultOfac>();
				}

			if (!haveMust || cont == 1) {
				// si no hay obligarios o es el primer ciclo se agrega todo
				for (SearchResultOfac searchResultOfacR : documentBatchResultR) {
					documentBatchResult.add(searchResultOfacR);
					if (junction.equals(BooleanClause.Occur.MUST)) 
						documentBatchResultMust.add(searchResultOfacR);
				}
			} else {
				/*
				 * whf recomendacion: al parametrizar estrategias_query es 'mas
				 * mejor' que los queries must deben ir primero
				 */
				DocumentBatch<SearchResultOfac> documentBatchResultTmp = new DocumentBatch<SearchResultOfac>();

				if (junction.equals(BooleanClause.Occur.MUST)) {
					for (SearchResultOfac searchResultOfacR : documentBatchResultR) {
						// se verifica que exista en los resultados anteriores y
						// se realiza el join
						if (documentBatchResultMust.getBatchSize() == 0) {
							documentBatchResultTmp.add(searchResultOfacR);
						} else {
							String idDocR = searchResultOfacR.getDocId();
							boolean existInListNewResult = false;
							// registros de un anterior must se registran
							for (SearchResultOfac searchResultOfac : documentBatchResultMust) {
								if (searchResultOfac.getDocId().equals(idDocR) && searchResultOfac.getOfacQuery().getFieldQuery().getClazz().getSimpleName()
										.equals(searchResultOfacR.getOfacQuery().getFieldQuery().getClazz().getSimpleName())) {
									documentBatchResultTmp.add(searchResultOfac);
									existInListNewResult = true;
								}
							}
							if (existInListNewResult)
								documentBatchResultTmp.add(searchResultOfacR);
						}
					}
					documentBatchResultMust = new DocumentBatch<SearchResultOfac>();
					// nueva lista must
					for (SearchResultOfac searchResultOfacR : documentBatchResultTmp)
						documentBatchResultMust.add(searchResultOfacR);
				} else if (junction.equals(BooleanClause.Occur.MUST_NOT)) {
					// el resultado sera lo que actualmente se encontro
					for (SearchResultOfac searchResultOfac : documentBatchResult)
						documentBatchResultTmp.add(searchResultOfac);
				} else if (junction.equals(BooleanClause.Occur.SHOULD)) {
					if (documentBatchResultMust.getBatchSize() == 0) {
						// no existe lista musts se agrega todo lo que hasta el
						// moemnto se encontro que sera todos los musts
						for (SearchResultOfac searchResultOfac : documentBatchResult)
							documentBatchResultTmp.add(searchResultOfac);
					} else {
						for (SearchResultOfac searchResultOfac : documentBatchResultMust) {
							documentBatchResultTmp.add(searchResultOfac);
							String idDocR = searchResultOfac.getDocId();
							for (SearchResultOfac searchResultOfacR : documentBatchResultR) {
								if (searchResultOfacR.getDocId().equals(idDocR) && searchResultOfacR.getOfacQuery().getFieldQuery().getClazz().getSimpleName()
										.equals(searchResultOfacR.getOfacQuery().getFieldQuery().getClazz().getSimpleName())) {
									documentBatchResultTmp.add(searchResultOfacR);
								}
							}
						}
					}
				}

				documentBatchResult = new DocumentBatch<SearchResultOfac>();
				for (SearchResultOfac searchResultOfacR : documentBatchResultTmp) {
					documentBatchResult.add(searchResultOfacR);
				}
			}
			
			if (querySimple && fieldQueryLista.get(0).getValidatorStrategy().getType().compareTo(ValidatorStrategy.ValidatorType.SIMPLE) != 0) {
				querySimple = false;
			}
			
			cont++;
		}

		// refinamos el resultado, verificamos que todos los terminos
		// encontrados esten la consulta
		Map<String, DocumentBatch<SearchResultOfac>> itemsSearchResultOfac = new LinkedHashMap<>();
		DocumentBatch<SearchResultOfac> documentBatchResponse = new DocumentBatch<SearchResultOfac>();

		if (documentBatchResult.getBatchSize() != 0) {
			Map<String, List<String>> itemsSearchResultOfac0 = new LinkedHashMap<>();
			Map<String, OfacQuery> itemsSearchResultOfac1 = new LinkedHashMap<>();
			for (SearchResultOfac searchResultOfac : documentBatchResult) {
				for (OfacQuery ofacQuery : searchResultOfac.getMatches()) {
					String idInfo = String.valueOf(Objects.hash(ofacQuery.getFieldQuery().getClazz().getSimpleName(), searchResultOfac.getDocId()));
					log.debug("ofacQuery.getTerm() " + ofacQuery.getTerm() + " : " + ofacQuery.getFieldQuery().getClazz().getSimpleName() + " iddoc: "
							+ searchResultOfac.getDocId());
					if (!itemsSearchResultOfac0.containsKey(idInfo)) {
						itemsSearchResultOfac0.put(idInfo, new ArrayList<>());
						itemsSearchResultOfac1.put(idInfo, ofacQuery);
						itemsSearchResultOfac.put(idInfo, new DocumentBatch<SearchResultOfac>());
					}

					List<String> listTerms = itemsSearchResultOfac0.get(idInfo);
					listTerms.add(ofacQuery.getTerm());
					itemsSearchResultOfac0.put(idInfo, listTerms);
					DocumentBatch<SearchResultOfac> documentBatchResponse0 = itemsSearchResultOfac.get(idInfo);
					documentBatchResponse0.add(searchResultOfac);
					itemsSearchResultOfac.put(idInfo, documentBatchResponse0);
				}
			}
			
			QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, OfaSdnentry.class);
			for (Entry<String, List<String>> s : itemsSearchResultOfac0.entrySet()) {
				OfacQuery ofacQuery = itemsSearchResultOfac1.get(s.getKey());
//				log.debug("Text found: " + s.getKey() + " : " + itemsSearchResultOfac0.get(s.getKey()) + " " + ofacQuery.getDocId() + " "
//						+ ofacQuery.getFieldQuery().getClazz().getSimpleName());
				// no se considera el orden por no conocer el orden de los
				// resultados
				boolean inOrder = false;
				String hiqh = "";
				try {
					hiqh = queryParsersBuilder.highlightFieldSpanNearFuzzy(ofacQuery.getFieldQuery().getField(), itemsSearchResultOfac0.get(s.getKey()),
							query, ofacQuery.getFieldQuery().getDistanceUpTo(), ofacQuery.getFieldQuery().getPrefixLength(),
							ofacQuery.getFieldQuery().getBoost(), ofacQuery.getFieldQuery().getSlop(), inOrder, ofacQuery.getFieldQuery().getMinWordLen(),
							ofacQuery.getFieldQuery().isExceptNumbers(), ofacQuery.getFieldQuery().getAnalyzer());

					if (hiqh != null) {
//						log.debug("hiqh " + hiqh);
						for (SearchResultOfac searchResultOfac : itemsSearchResultOfac.get(s.getKey())) {
							documentBatchResponse.add(searchResultOfac);
						}
					} else {
						if (querySimple && !haveMust){
							for (SearchResultOfac searchResultOfac : itemsSearchResultOfac.get(s.getKey())) {
								documentBatchResponse.add(searchResultOfac);
							} 
						}
					}
				} catch (InvalidTokenOffsetsException e) {
					log.error(e.getMessage(), e);
				}
			}

			if (documentBatchResponse.getBatchSize() != 0) {
				log.info("@@@@@ CONSULTA POSITIVA!!![" + documentBatchResponse.getBatchSize() + " regs.] @@@@@\n" + query + "\n");
				if (log.isDebugEnabled()) 
					printMatches(documentBatchResponse);
			}
		}

		return documentBatchResponse;
	}

	public static void printMatches(DocumentBatch<SearchResultOfac> matches) {
		Integer i = 0;
		for (SearchResultOfac searchResultOfac : matches) {
			i++;
			Object clazz = searchResultOfac.getDocumentMatch();
			log.info(i + "::=>[" + searchResultOfac.getDocId() + ":" + searchResultOfac.getQueryId() + "] Query:[" + searchResultOfac.getScore()
					+ "] (SubQueries: " + ":" + searchResultOfac.getMatches().size() + " )" + " Term: "
					+ (searchResultOfac.getOfacQuery() != null ? searchResultOfac.getOfacQuery().getTerm() : "") + " High: "
					+ (searchResultOfac.getOfacQuery() != null ? searchResultOfac.getOfacQuery().getTermHigh() : "")
					+ (clazz != null ? clazz.getClass().getSimpleName() : "null clazz"));

			searchResultOfac.getMatches().forEach(oq -> {
				log.info("	::=> " + oq.getQueryId() + "][" + oq.getScore() + "] " + oq.getLuceneQuery());
			});
		}
	}

	public JPASearchFactoryController getjPASearchFactoryController() {
		return jPASearchFactoryController;
	}

}
