package gob.bcb.lavado.repository;

import java.util.HashMap;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.services.SwiftBcbSearcherServiceImpl;
import gob.bcb.swift.pojos.SwiftDatos;


public class SwfLoaderDaoImpl {
	private static final Logger log = LoggerFactory.getLogger(SwfLoaderDaoImpl.class);
	
	private SwfMensaje generarCorrelativoSwiftPortia(SwiftDatos swiftDatos) {
		log.info("Inicio actualizar nro swift " + swiftDatos.getSwfMensaje().getMenCodmen());

//		SwfMensaje swfMensaje = swfMensajeLocal.findByCodigo(swiftDatos.getSwfMensaje().getMenCodmen());
//
//		if (swfMensaje == null) {
//			log.error("Error al actualizar nro swift mensaje " + swiftDatos.getSwfMensaje().getMenCodmen() + " inexistente");
//			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swiftDatos.getSwfMensaje().getMenCodmen() + " inexistente");
//		}
//
//		if (StringUtils.isBlank(swfMensaje.getMenCveestswift()) || swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)
//				|| swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_RECH)) {
//			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift()
//					+ " invalido");
//			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado "
//					+ swfMensaje.getMenCveestswift() + " invalido");
//		}
//
//		if (StringUtils.isBlank(swfMensaje.getMenCodusrswf())) {
//			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
//			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
//		}
//
//		if (swfMensaje.getMenNrocorr() != null && swfMensaje.getMenNrocorr().compareTo(0) > 0) {
//			LoaderDao loaderDao = new LoaderDao();
//			loaderDao.setSessionFactory(PortiaService.getSessionFactory());
//
//			Loader loaderOld = loaderDao.findByNroSwift(swfMensaje.getMenNrocorr());
//
//			log.info("loader.getIdLoaderOld() " + loaderOld.getIdLoader() + " " + swfMensaje.getMenNrocorr());
//			if (loaderOld != null) {
//
//				if (loaderOld.getDescrip() != null && loaderOld.getDescrip().trim().equals("SIOCWEB")) {
//					log.info("Correltativo a reutilizar mensaje==> " + swfMensaje.getMenCodmen());
//					return swfMensaje;
//				}
//			}
//		}
//
//		// // POOOOOOORTIA
//		Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
//		mapaParametros2.put("consulta", "crear");
//		mapaParametros2.put("usuarioaudit", swfMensaje.getMenAuditusr());
//		mapaParametros2.put("estacionaudit", swfMensaje.getMenAuditwst());
//
//		log.info("Llamando al servicio de portiaswift: obtener numero swift");
//
//		PortiaService portiaService = new PortiaService();
//		Map<String, Object> mapaResultado2 = portiaService.executeTask(mapaParametros2);
//
//		Integer codSwift = (Integer) mapaResultado2.get("swift");
//		Loader loader = (Loader) mapaResultado2.get("loader");
//
//		log.info("Inicio portia solicitud de nuevo nro swift");
//		log.info("Nro swift Portia asignado " + codSwift + " a mensaje==> " + swfMensaje.getMenCodmen());
//
//		swfMensaje.setMenNrocorr(codSwift);
//		SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swfMensaje);
//
//		swiftDatos.setSwfMensaje(swfMensajeNew);
//
//		LoaderDao loaderDao = new LoaderDao();
//		loaderDao.setSessionFactory(PortiaService.getSessionFactory());
//
//		Loader loaderNew = loaderDao.findByCodigo(loader.getIdLoader());
//
//		log.info("loader.getIdLoader() " + loader.getIdLoader() + " " + swfMensajeNew.getMenNrocorr());
//
//		if (loaderNew == null || loaderNew.getNumeroSwift().compareTo(swfMensajeNew.getMenNrocorr()) != 0) {
//			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " nro asignado no coincide "
//					+ swfMensaje.getMenNrocorr());
//		}
//		log.info("Fin generara correltativo a mensaje==> " + swfMensajeNew.getMenCodmen());
		//return swfMensajeNew;
		return null;
	}
	
//	public Loader find(Long id) {
//		Loader lista0 = null;
//
//		StringBuffer query = new StringBuffer();
//		query = query.append(" select re ");
//		query = query.append(" from ");
//		query = query.append(" Loader re ");
//		query = query.append(" where re.idLoader = :codigo ");
//
//		Query consulta = getSession().createQuery(query.toString());
//
//		consulta.setParameter("codigo", id);
//
//		List lista = consulta.list();
//		if (lista.size() > 0) {
//			Loader loader = (Loader) lista.get(0);
//			return loader;
//		}
//		return null;
//	}
//
//	public Loader findMax() {
//		StringBuffer query = new StringBuffer();
//		query = query.append(" select re ");
//		query = query.append(" from Loader re ");
//		query = query.append(" where re.idLoader = (select max(r1.idLoader) from Loader r1) ");
//
//		Query consulta = getSession().createQuery(query.toString());
//
//		List lista = consulta.list();
//		if (lista.size() > 0) {
//			Loader loader = (Loader) lista.get(0);
//			return loader;
//		}
//		return null;
//	}
//
//	public Loader findByCodigo(Long idLoader) {
//
//		StringBuilder query = new StringBuilder();
//		
//	    query = query.append(" select re ");
//	    query = query.append(" from Loader re ");
//	    query = query.append(" where re.idLoader = :idLoader ");
//
//		Query consulta = getSession().createQuery(query.toString());
//		
//		consulta.setParameter("idLoader", idLoader);
//		
//		List lista =  consulta.list();
//		if (lista.size() > 0){
//			return (Loader) lista.get(0); 
//		}
//
//		return null;		
//	}	
//	
//	public Loader findByNroSwift(Integer nroSwift) {
//
//		StringBuffer query = new StringBuffer();
//		query = query.append("select re ");
//		query = query.append("from Loader re ");
//		query = query.append("where re.numeroSwift = :codigo ");
//
//		Query consulta = getSession().createQuery(query.toString());
//
//		consulta.setParameter("codigo", nroSwift);
//
//		List lista = consulta.list();
//		if (lista.size() > 0) {
//			Loader loader = (Loader) lista.get(0);
//			return loader;
//		}
//		return null;
//	}
//
//	public Loader nuevoCodSwift(String idSistema, String auditWst, String auditUsr) {
//		Integer codSwift = maxNroSwift();
//		Long idLoader = getCodigo();
//
//		logger.info("numero SWIFT obtenito: " + codSwift + " idLoader " + idLoader);
//
//		Loader loader = new Loader();
//		loader.setIdLoader(idLoader);
//		loader.setIdBase(0);
//		loader.setIdPortia(0);
//		loader.setNumeroSwift(codSwift);
//		loader.setEstado('0');
//		loader.setDescrip(idSistema);
//		loader.setEstacion(auditWst);
//		loader.setFechaHora(new Date());
//		loader.setUsuario(auditUsr);
//		saveOrUpdate(loader);
//		
//		this.getHibernateTemplate().save(loader);
//		
//		Loader loaderNew = findByCodigo(idLoader);
//		logger.info("registro Swift en PORTIA a crear: " + loaderNew.toString());
//		return loader;
//	}
//
//	public Integer maxNroSwift() {
//
//		StringBuilder jsql = new StringBuilder();
//		jsql.append("select max(l.numeroSwift) from Loader l");
//
//		Query query = getSession().createQuery(jsql.toString());
//
//		List result = query.list();
//		if (result.size() > 0) {
//			Integer maximo = (Integer) result.get(0);
//			return (maximo == null ? Integer.valueOf(1) : ++maximo);
//		}
//
//		return Integer.valueOf(0);
//	}
//	public Long getCodigo() {
//		Loader loader = findMax();
//		if (loader == null){
//			logger.error("No se pudo recuperar nro swift");
//			return 1L;
//			//throw new RuntimeException("No se pudo recuperar nro swift");
//		}
// 
//		Long codigo = loader.getIdLoader() + 1;
//		logger.info("IdLoader : " + codigo);		
//		return codigo;
//
//	}	
}
