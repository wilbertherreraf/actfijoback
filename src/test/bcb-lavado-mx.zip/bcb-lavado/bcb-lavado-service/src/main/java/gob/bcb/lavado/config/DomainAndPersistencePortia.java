package gob.bcb.lavado.config;

import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import gob.bcb.lavado.QL.portiaswift.LoaderQLBean;
import gob.bcb.lavado.QL.portiaswift.entities.Loader;
import gob.bcb.lavado.commons.Constants;

@Configuration
@ComponentScan(basePackageClasses={LoaderQLBean.class,Loader.class})
@ConfigurationProperties(prefix = Constants.PROP_PREFIX_PORTIA)
@EnableTransactionManagement
public class DomainAndPersistencePortia extends HikariConfig {
	private static final Logger log = LoggerFactory.getLogger(DomainAndPersistencePortia.class);
	
	private JpaVendorAdapter jpaVendorAdapter() {
		log.info("Portiaswift config jpaVendorAdapter");
		HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
		hibernateJpaVendorAdapter.setShowSql(false);
		hibernateJpaVendorAdapter.setDatabase(Database.INFORMIX);
		hibernateJpaVendorAdapter.setDatabasePlatform("org.hibernate.dialect.InformixDialect");
		return hibernateJpaVendorAdapter;
	}

//	@Bean(name = "dataSourcePortia",destroyMethod = "close")
//	public DataSource dataSourcePortia() throws IllegalArgumentException, NamingException {
//		log.info("dataSourcePortia " + getDataSourceJNDI());
//        JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
//        bean.setJndiName(getDataSourceJNDI());
//        bean.setProxyInterface(DataSource.class);
//        bean.setLookupOnStartup(false);
//        bean.afterPropertiesSet();
//		
//		HikariDataSource ds = new HikariDataSource();
//		ds.setDataSource((DataSource) bean.getObject());
//		ds.addDataSourceProperty("cachePrepStmts", "true");
//		ds.addDataSourceProperty("useServerPrepStmts", "true");
//		ds.setAutoCommit(false);
//		ds.setPoolName(Constants.PUNIT_PORTIA);
//
//		return ds;
//	}	
	
	@Bean(name = "dataSourcePortia")
	public DataSource dataSourcePortia()  throws NamingException {
		log.info("dataSourcePortia ");
        JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
        bean.setJndiName(getDataSourceJNDI());
        bean.setProxyInterface(DataSource.class);
        bean.setLookupOnStartup(false);
        bean.afterPropertiesSet();
        return (DataSource) bean.getObject();
	}	
	
	private Map<String, ?> jpaProperties() {
		Map<String, Object> jpaPropertiesMap = new HashMap<String, Object>();
		jpaPropertiesMap.put("hibernate.hikari.registerMbeans", "true");
		jpaPropertiesMap.put("hibernate.current_session_context_class", "jta");
		jpaPropertiesMap.put("hibernate.transaction.manager_lookup_class", "org.springframework.orm.hibernate4.HibernateTransactionManager");
		return jpaPropertiesMap;
	}
	
	@Bean(name = "entityManagerFactoryPortia")
	public LocalContainerEntityManagerFactoryBean entityManagerFactoryPortia(@Qualifier("dataSourcePortia") DataSource dataSourcePortia) {
		log.info("Portia:::: entityManagerFactoryPortiaDS " + (dataSourcePortia == null));
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource( dataSourcePortia);
        em.setPackagesToScan(Loader.class.getPackage().getName(), LoaderQLBean.class.getPackage().getName());
        em.setJpaVendorAdapter(jpaVendorAdapter());
		em.setJpaPropertyMap(jpaProperties());        
        em.setPersistenceUnitName(Constants.PUNIT_PORTIA);
        
		em.afterPropertiesSet();
		
        return em;		
	}	
	
	@Bean(name = "transactionManagerPortia")
	public JpaTransactionManager transactionManagerPortia(@Qualifier("entityManagerFactoryPortia") LocalContainerEntityManagerFactoryBean entityManagerFactoryPortia) {
		log.info("%%%%%%%%%%% transactionManager transactionManagerPortia %%%%%%%%%%%%");
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactoryPortia.getObject());
		return transactionManager;
	}	
}
