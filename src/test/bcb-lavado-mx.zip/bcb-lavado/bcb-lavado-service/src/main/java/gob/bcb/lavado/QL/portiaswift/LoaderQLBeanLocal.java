package gob.bcb.lavado.QL.portiaswift;

import gob.bcb.lavado.QL.portiaswift.entities.Loader;

public interface LoaderQLBeanLocal {
	Integer getCodigo();
	Integer maxNroSwift();
	Loader nuevoCodSwift(String idSistema, String auditWst, String auditUsr);
	Loader maxLoader();
	Loader findByCodigo(Integer idLoader);
	Loader saveorupdate(Loader loader);
	Loader generarNroSwift(Loader loader);
}
