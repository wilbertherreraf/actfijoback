package gob.bcb.lavado.repository;

import java.util.List;

import gob.bcb.lavado.model.SwfMencampos;
import gob.bcb.lavado.pojos.MensajesDatos;
public interface SwfMencamposDao {

	List<MensajesDatos> camposPorMensaje(Integer menEstmensaje);

	List<MensajesDatos> camposPorCodMens(Integer menCodmen, Integer resCodemp);

}
