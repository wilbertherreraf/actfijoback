package gob.bcb.lavado.commons;

import java.io.Serializable;

public abstract class Constants implements Serializable {
	public static final String BASE_DIR_APP = "/opt/aplicaciones/lavado/";
	public static final String FILE_APPLICATION_WEB = "applicationw.properties";
	public static final String FILE_APPLICATION = "application.properties";
	public static final String COD_APP_NEMO = "LVD";

	public static final String PUNIT_LAVADO = "portiaDS";
	public static final String PUNIT_PORTIA = "portiaswiftDS";
	public static final String PUNIT_CONTBCB = "coinDS";
	public static final String PUNIT_AXESSO = "axessoDSJndi";
	public static final String PUNIT_RRHH = "sap2000DS";
	
	public static final String JNDI_LAVADO = "java:jboss/datasources/lavadoDS";
	public static final String JNDI_PORTIA = "java:jboss/datasources/portiaswiftDS";
	public static final String JNDI_CONTBCB = "java:jboss/datasources/coinDS";
	public static final String JNDI_AXESSO = "java:jboss/datasources/axessoDS";
	public static final String JNDI_RRHH = "java:jboss/datasources/sap2000DS";	

	public static final String PROP_PREFIX_LAVADO = "portia";
	public static final String PROP_PREFIX_PORTIA = "portiaswift";
	public static final String PROP_PREFIX_CONTBCB = "coin";
	public static final String PROP_PREFIX_AXESSO = "axesso";
	public static final String PROP_PREFIX_RRHH = "sap";

	public static final Integer SEARCH_LIMIT_REGS = 158;
	
	// estado que determina el estado del registro
	public static final Integer TAB_ESTMENSAJE = 100;
	public static final Integer TAB_ESTMENSAJE_REGISTRADO = 1;
	// util para asignaciones de mensajes entrantes
	public static final Integer TAB_ESTMENSAJE_ASIGNADO = 2;
	public static final Integer TAB_ESTMENSAJE_EN_PROCESO = 3;
	public static final Integer TAB_ESTMENSAJE_PROCESADO = 5;	
	public static final Integer TAB_ESTMENSAJE_ELIMINADO = 9;

	public static final Integer TAB_ESTVERIFICA = 3;
	public static final Integer TAB_ESTVERIFICA_REGISTRADO = 1;
	public static final Integer TAB_ESTVERIFICA_VERIFICADO = 2;
	public static final Integer TAB_ESTVERIFICA_EN_VERIFICACION_BLQ = 3;
	public static final Integer TAB_ESTVERIFICA_FALSO_POSITIVO = 5;
	public static final Integer TAB_ESTVERIFICA_POSITIVO_BLQ = 6;

	public static final Integer TAB_ESTAUTORIZA = 6;
	public static final Integer TAB_ESTAUTORIZA_PENDIENTEAUTORIZA = 1;
	public static final Integer TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR = 2;
	public static final Integer TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT = 3;
	public static final Integer TAB_ESTAUTORIZA_RECHAZADOPORADMINSWFT = 5;
	public static final Integer TAB_ESTAUTORIZA_PROVISIONALCONNROCORR = 6;

	public static final Integer TAB_ESTREVISION = 2;
	public static final Integer TAB_ESTREVISION_PEND = 1;
	public static final Integer TAB_ESTREVISION_ENPROC_ASIGNACION = 2;
	public static final Integer TAB_ESTREVISION_PROCESADO = 3;
	public static final Integer TAB_ESTREVISION_RECHAZADO = 5;
	public static final Integer TAB_ESTREVISION_ELIMINADO = 9;
	
	public static final Integer TAB_STATUSAUTOLBLANCA = 5;
	public static final Integer TAB_STATUSAUTOLBLANCA_PENDIENTE = 1;
	public static final Integer TAB_STATUSAUTOLBLANCA_AUTORIZADO = 2;
	public static final String TAB_STATUSAUTOLBLANCA_AUTORIZADOSTR = "auto";
	public static final Integer TAB_STATUSAUTOLBLANCA_ELIMINADO = 9;

	public static final String COD_RESP_EXITO = "000";
	public static final String COD_RESP_ERR_01 = "E01";
	public static final String COD_RESP_ERR_02 = "E02";	
	

	public static final String TIPO_MENSAJE_IN = "I";
	public static final String TIPO_MENSAJE_OUT = "O";

	public static final String TIPO_LOTE_OFAC = "OFAC";
	public static final String TIPO_LOTE_SWIFT = "SWIFT";

	public static final String AREA_ADM = "0";

	public static final String CAMPO_SWIFT_20 = "20";

	public static final String CONTEXTO_BLOCK4 = "block4";

	public static final String PREFIJO_EMPLEADO = "EMPLEADO";
	public static final String PREFIJO_EMPLEADOASIG = "EMPLEADOASIG";

	public static final String BCB_NOMBRE = "BANCO CENTRAL DE BOLIVIA";
	public static final String BCB_RESIDENCIA = "LA PAZ BO";

	public static final String PARAM_CORREOREMITENTE = "CORRREMITE";
	public static final String PARAM_CORREOREMITENTENSWF = "CORRREMITENSWF";	
	public static final String PARAM_TIPPROCOFAC = "TIPPROCOFAC";
	public static final String PARAM_TRUNCATEOFAC = "TRUNCATEOFAC";
	public static final String PARAM_ACCIONSCAN = "ACCIONSCAN";
	public static final String PARAM_ACCIONSCAN_BLQ = "B";
	public static final String PARAM_PATHDIRSWIFT = "PATHDIRSWIFT";
	public static final String PARAM_PATHDIRSWIFTLAU = "PATHDIRSWIFTLAU";	

	public static final String BICS_CODESTRATEGIA_DEFAULT = "BICS";

	/**
	 * Correos para alerta
	 */
	public static final String PARAM_CORRALERTAVERIF = "CORRALERTAVERIF";
	public static final String PARAM_CORREOSPORAPP = "CORREOSPORAPP";	
	public static final String PARAM_CODESTRADEFAULT = "CODESTRADEFAULT";
	public static final String PARAM_HORARIOSIMPORT = "HORARIOSIMPORT";
	public static final String PARAM_HORARIOSINDEXAR = "HORARIOSINDEXAR";	
	public static final String PARAM_CODIGOLAU = "CODIGOLAU";	
	public static final String PARAM_CODIGOLAUOLD = "CODIGOLAUOLD";
	public static final String PARAM_CORREOSCODLAU = "CORREOSCODLAU";	
	public static final String PARAM_CORRMONITORSWF = "CORRMONITORSWF";
	
	public static final String EMAIL_SUBJECT_ASIGNA = "Asignación de Mensaje SWIFT: ";
	public static final String EMAIL_SUBJECT_RECHAZO = "Rechazo de Mensaje SWIFT: ";

	public static final String SPRING_PROFILE_DEVELOPMENT = "dev";
	public static final String SPRING_PROFILE_PRODUCTION = "prod";

	public static final String DIR_LOTES = "lotes";
	public static final String DIR_QUERIES = "queries";
	public static final String DIR_OFAC_FILES_TMP = "ofacfilestmp";
	public static final String DIR_OFAC_FILES_DESCARGA = "ofacfiles_descarga";	
	public static final String DIR_OFAC_FILES = "ofacfiles";
	public static final String DIR_FILES_STORE = "filestore";

	public static final String FILE_ESTRATEGIES = "estrategias.json";
	public static final String FILE_ESTRATEGIES_QUERY = "estrategias_query.json";
	public static final String FILE_STORE_OP = "store_file.properties";

	/******** tipos ******/
	public static final String TIPO_LOT_TIPOLOTE_OFAC = "OFAC";
	public static final String TIPO_LOT_TIPOLOTE_SWIFT = "SWIFT";
	
	/******** resources ******/
	public static final String PATH_RESOURCE_API_SEARCH = "/api/_search";
	public static final String PATH_RESOURCE_API_V3_SEARCH = "/api/V3/_search";
	
	public static final String PATH_RESOURCE_API_BIC = "/api/bic";	
	public static final String PATH_RESOURCE_API_PARAM = "/api/param";	
	public static final String PATH_RESOURCE_API_OFACLIST = "/api/ofaclist";	
	public static final String PATH_RESOURCE_API_LVD = "/api/swift";
	
	public static final Integer SEC_MAX_ATTEMPT = 3;	
	public static final Integer SEC_TIME_LOCKED_FOR_ATTEMPS = 5 * 60;//minutos	
	public static final Integer SEC_TIME_LIFE_FOR_SESSIONS_REST = 5;//minutos	
	/**
	 * dias vigencia de password
	 */
	public static final Integer SEC_DAYS_LIFE_PASSWORD = 60;
	public static final long DAY_IN_MILLI = 24 * 60 * 60 * 1000;
	public static final long METRIC_TIME_REPORTER = 5; // IN MINUTES
	
	public static final String SES_REQUIRE_CHGPASSWORD = "SES_REQUIRE_CHGPASSWORD";	
	public static final String SCHEDULER_CRON_EXPRESION = "ss mm hh ? * *";
	public static final String ENCODING = "UTF-8";	
	public static final String ENCODING_ISO = "ISO-8859-1";
	
	/******** numeracion swift ******/
	
	public static final Integer TAB_TIPONRO = 8;
	public static final Integer TAB_TIPONRO_MANUAL = 2;
	public static final Integer TAB_TIPONRO_AUTOMATICO = 1;
	public static final Integer TAB_TIPONRO_SOLICXADM = 3;
	
	public static final Integer TAB_ESTNRO = 9;
	public static final Integer TAB_ESTNRO_SOLIC = 1;
	public static final Integer TAB_ESTNRO_ASIGNADO = 2;
	public static final Integer TAB_ESTNRO_VENC = 3;
	public static final Integer TAB_ESTNRO_RECHAZADO = 5;
	
	public static final Integer TAB_STATREG = 1008;
	public static final Integer TAB_STATREG_VIG = 1;
	public static final Integer TAB_STATREG_SUSP = 2;
}
