package gob.bcb.lavado.services;

import java.io.File;
import java.net.URI;

import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import gob.bcb.core.utils.WebUtils;
import gob.bcb.lavado.client.HandlerGeneratorLauSrv;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.repository.SwfParamsDao;

@Component
public class BuildSearchIndex {
	private static final Logger log = LoggerFactory.getLogger(BuildSearchIndex.class);

	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private SchedulerService schedulerService;
	
	@Autowired
	private AppProperties appProperties;
//	
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
    @EventListener
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) throws Exception {
    	log.info("oooooOOOOOO00000 en onApplicationEvent 00000OOOOOooooo");
    	
    	HandlerGeneratorLauSrv.initCurrentInstance(appProperties.getLavado().getAppdir(), "LAVADO");
    	SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_HORARIOSIMPORT);

    	//schedulerService.startScheduling(swfParams.getParValor(), Constants.PARAM_HORARIOSIMPORT, Constants.SCHEDULER_CRON_EXPRESION);
    	swfParams = swfParamsDao.findByCod(Constants.PARAM_HORARIOSINDEXAR);
    	schedulerService.startScheduling(swfParams.getParValor(), Constants.PARAM_HORARIOSINDEXAR, Constants.SCHEDULER_CRON_EXPRESION);
    	
    	String pathDirectory = new File(appProperties.getLavado().getAppdir(), Constants.DIR_QUERIES).getAbsolutePath();
    	log.info("schedulerService con: {} path {}", swfParams.getParValor(), pathDirectory);    	
    	try {
    		if (pathDirectory.startsWith("/")) {
    			swiftAdminDaoService.indexOfaSdnentry();
    			
    		}
//			log.info("Indexando entidades lvd");
//			swiftAdminDaoService.indexLvdEntities();
		} catch (Exception e) {
			throw new RuntimeException("Error al iniciar indices OFAC");
		}
    	log.info("oooooOOOOOO LAVADO IINCIALIZADO A LA ESPERA DE MENSAJES OOOOOooooo");
    	
    }

	@EventListener
	public void onApplicationEvent(ContextClosedEvent event) {
		schedulerService.cancelAll();
		ILoggerFactory context =LoggerFactory.getILoggerFactory();
		
		log.info("oooOOOOOO00000 CERRANDO APLICACION 00000OOOOOooo");
		
	}
    
}
