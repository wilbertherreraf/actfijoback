package gob.bcb.lavado.repository;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.services.SchedulerService;


@Repository("swfParamsDao")
@Transactional
public class SwfParamsDaoImpl implements SwfParamsDao {
	private static final Logger log = LoggerFactory.getLogger(SwfParamsDaoImpl.class);

	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;
	
	@Autowired
	@Qualifier("entityManagerFactory")	
	private EntityManagerFactory entityManagerFactory;

	public List<SwfParams> getAll() {
		String jpql = "SELECT t FROM SwfParams t ";
		Query query = entityManager.createQuery(jpql);
		List lista = query.getResultList();
		return lista;
	}
		
	public SwfParams findByCod(String parCodparam) {
		String jpql = "SELECT t FROM SwfParams t WHERE t.parCodpar = :parCodparam";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("parCodparam", parCodparam);
		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfParams) lista.get(0);
		}
		return null;

	}

	public SwfParams saveOrUpdate(SwfParams swfParams) {
		log.info("Actualizando parametro " + swfParams.toString());
		
		if (StringUtils.isBlank(swfParams.getParValor()))
			throw new DataException("Valor parametro inválido");
		if (StringUtils.isBlank(swfParams.getParDescrip()))
			throw new DataException("Valor descripción inválido");
		try {
			swfParams.setParDescrip(UtilsGeneric.convertStringToEncode(swfParams.getParDescrip(), Constants.ENCODING_ISO));
			swfParams.setParValor(UtilsGeneric.convertStringToEncode(swfParams.getParValor(), Constants.ENCODING_ISO));			
		} catch (UnsupportedEncodingException e) {
		}		
		swfParams = entityManager.merge(swfParams);
		return swfParams;
	}
}
