package gob.bcb.lavado.repository;



import java.util.List;

import gob.bcb.lavado.model.SwfParams;

public interface SwfParamsDao {

	SwfParams findByCod(String parCodparam);

	SwfParams saveOrUpdate(SwfParams SwfParams);

	List<SwfParams> getAll();
}
