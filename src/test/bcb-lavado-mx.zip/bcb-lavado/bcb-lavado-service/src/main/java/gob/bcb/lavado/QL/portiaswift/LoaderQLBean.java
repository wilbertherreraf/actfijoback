package gob.bcb.lavado.QL.portiaswift;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.lavado.QL.portiaswift.entities.Loader;
import gob.bcb.lavado.commons.Constants;

@Repository("loaderQLBeanLocal")
@Transactional(value="transactionManagerPortia")
public class LoaderQLBean implements LoaderQLBeanLocal {
	private static final Logger logger = LoggerFactory.getLogger(LoaderQLBean.class);

	@PersistenceContext(unitName = Constants.PUNIT_PORTIA)
	private EntityManager em;

	@Autowired
	@Qualifier("entityManagerFactoryPortia")
	private EntityManagerFactory entityManagerFactoryPortia;

	/**
	 * Default constructor.
	 */
	public Integer getCodigo() {
		Loader loader = maxLoader();
		if (loader == null) {
			logger.error("No se pudo recuperar nro swift");
			return 1;
			// throw new RuntimeException("No se pudo recuperar nro swift");
		}

		Integer codigo = loader.getIdLoader() + 1;
		logger.info("IdLoader : " + codigo);
		return codigo;
	}

	public Loader maxLoader() {

		StringBuilder query = new StringBuilder();

		query = query.append(" select re ");
		query = query.append(" from Loader re ");
		query = query.append(" where re.idLoader = (select max(r1.idLoader) from Loader r1) ");

		Query consulta = em.createQuery(query.toString());
		List lista = consulta.getResultList();
		if (lista.size() > 0) {
			return (Loader) lista.get(0);
		}

		return null;
	}

	public Loader findByCodigo(Integer idLoader) {
		StringBuilder query = new StringBuilder();

		query = query.append("select re ");
		query = query.append("from Loader re ");
		query = query.append("where re.idLoader = :idLoader ");

		Query consulta = em.createQuery(query.toString());

		consulta.setParameter("idLoader", idLoader);

		List<Loader> lista = consulta.getResultList();
		if (lista.size() > 0) {
			return lista.get(0);
		}

		return null;
	}

	@Transactional(value="transactionManagerPortia", propagation = Propagation.REQUIRES_NEW)	
	// @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Loader nuevoCodSwift(String idSistema, String auditWst, String auditUsr) {

		Integer codSwift = maxNroSwift();
		Integer idLoader = getCodigo();

		logger.info("numero SWIFT obtenito: " + codSwift + " idLoader " + idLoader);

		// Loader loader = new Loader(idLoader, 0, 0, codSwift, '1', idSistema,
		// auditWst, new Date(), auditUsr);
		Loader loader = new Loader();
		loader.setIdLoader(idLoader);
		loader.setIdBase(0);
		loader.setIdPortia(0);
		loader.setNumeroSwift(codSwift);
		loader.setEstado('0');
		loader.setDescrip(idSistema);
		loader.setEstacion(auditWst);
		loader.setFechaHora(new Date());
		loader.setUsuario(auditUsr);
		em.merge(loader);

		Loader loaderNew = findByCodigo(idLoader);
		if (loaderNew == null){
			logger.error("No se pudo crear objeto loader en portia idSistema {}, auditWst {}, auditUsr {}", idSistema, auditWst, auditUsr);
			throw new RuntimeException("No se pudo crear objeto loader en portia ");
		}
		
		logger.info("registro Swift en PORTIA a crear: " + loaderNew.toString());
		return loaderNew;
	}

	public Loader generarNroSwift(Loader loader) {
		Integer codSwift = maxNroSwift();
		Integer idLoader = getCodigo();

		logger.info("numero SWIFT obtenito: " + codSwift + " idLoader " + idLoader);

		loader.setIdLoader(idLoader);
		loader.setIdBase(0);
		loader.setIdPortia(0);
		loader.setNumeroSwift(codSwift);
		loader.setEstado('0');
		loader.setFechaHora(new Date());
		em.persist(loader);

		Loader loaderNew = findByCodigo(idLoader);
		logger.info("registro Swift en PORTIA a crear: " + loaderNew.toString());
		return loader;
	}

	public Loader saveorupdate(Loader loader) {
		logger.info("saveorupdate PORTIA a mod: " + loader.toString());
		Loader loaderOld = findByCodigo(loader.getIdLoader());
		if (loaderOld == null) {
			throw new RuntimeException("Swift: No puede insertar nuevo registro");
		} else {
			loaderOld.setEstado(loader.getEstado());
			loaderOld.setIdBase(loader.getIdBase());
			loaderOld.setIdPortia(loader.getIdPortia());
			loaderOld.setDescrip("loader.getDescrip()");
			// entityManager.getTransaction().begin();
			loader = em.merge(loaderOld);
			Loader loaderN = findByCodigo(loader.getIdLoader());
			loaderOld.setDescrip("loader222");
			// Loader loaderN2 = entityManager.merge(loaderN);
			// logger.info("XXX:22222 " + loaderN.getDescrip() + " ::: " +
			// loaderN2.getDescrip());
		}
		return loader;
	}

	public Integer maxNroSwift() {

		StringBuilder jsql = new StringBuilder();
		jsql.append("select max(l.numeroSwift) from Loader l");

		Query query = em.createQuery(jsql.toString());

		List result = query.getResultList();
		if (result.size() > 0) {
			Integer maximo = (Integer) result.get(0);
			return (maximo == null ? Integer.valueOf(1) : ++maximo);
		}

		return Integer.valueOf(0);
	}
}
