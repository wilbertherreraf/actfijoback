package gob.bcb.lavado.strategy;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.utils.UtilsFile;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.swift.pojos.Block4;

public class StrategyBaseTest {
	private static final Logger log = LoggerFactory.getLogger(StrategyBaseTest.class);

	private String pathDir = "/opt/aplicaciones/lavado";
	//@Test
	public void loadQueriesTest() throws Exception {

		String path = pathDir +  "/"+ Constants.DIR_QUERIES;
		StrategyBase strategyBase = StrategyBase.getInstance().initialize(path);
		String id = "59";
		log.info("Consultanto estrategia ..." + id);
		Map<String, Map<String, List<FieldQuery>>> docs = strategyBase.matchesForFieldswift(id);
		docs.forEach((k, v) -> {
			log.info(k + " " + v);
		});
		log.info("***********************************************");
		id = "70";
		StrategyBase strategyBase0 = StrategyBase.getInstance().initialize(path);
		Map<String, Map<String, List<FieldQuery>>> docs0 = strategyBase0.matchesForFieldswift(id);
		docs0.forEach((k, v) -> {
			log.info("		" + k + " " + v);
		});
		log.info("***********************************************");
		id = "1111";
		StrategyBase strategyBase1 = StrategyBase.getInstance().initialize(path);
		Map<String, Map<String, List<FieldQuery>>> docs1 = strategyBase1.matchesForFieldswift(id);
		docs1.forEach((k, v) -> {
			log.info("		" + k + " " + v);
		});
		
		Assert.assertTrue("Numero de registros esperados menor campo swift " + id, docs.size() > 2);
	}

//	@Test
	public void loadBlock4MT() throws Exception {
		log.info("en mtttttttttttttttttttttttttttttttttttttttttttttttttttt");
		String path = pathDir +  "/"+ Constants.DIR_QUERIES;
		StrategyBase strategyBase = StrategyBase.getInstance().initialize(path);
		
		String nfile = "src/test/resources/swifts/swf_4633_ent_alias.dos"; // siodex_103.txt
		String str = UtilsFile.readFileAsString2(nfile);
		
		SwiftMessageAbstract sm = FactoryParser.createParser(str).parser();
		log.info("tipo " + sm.messageType());
		sm.getBlock4().forEach(b -> {
			log.info("valor " + b.getName() + " -> " + b.getValue());
		});
		
		//List<gob.bcb.iso20022.pojo.Block4> block4Exists0 = sm.getBlock4().stream().filter(b -> strategyBase.matchesForFieldswift(b.getName()).size() > 0).collect(Collectors.toList());
		
		List<gob.bcb.iso20022.pojo.Block4> block4Exists = sm.getBlock4().stream().filter( b -> {
			Map<String, Map<String, List<FieldQuery>>> matches;
			try {
				matches = strategyBase.matchesForFieldswift(b.getName());
				return matches.size() > 0;
			} catch (ExecutionException e) {
				log.error(e.getMessage(), e);
				return false;
			}
			
		}).collect(Collectors.toList());

		block4Exists.forEach(b -> {
			log.info("	tipo " + b.getName() + " -> " + b.getValue());
		});
	}	
	
	@Test
	public void loadBlock4MX() throws Exception {
		String path = pathDir +  "/"+ Constants.DIR_QUERIES;
		StrategyBase strategyBase = StrategyBase.getInstance().initialize(path);

		strategyBase.groupsForIdEstrategia().forEach((k, v) -> {
			log.info(k + " :: " + v);
		});
		
		String nfile = "src/test/resources/mx/pacs.008hdr.xml"; // siodex_103.txt
		String str = UtilsFile.readFileAsString2(nfile);
		//log.info(str);
		
		SwiftMessageAbstract sm = FactoryParser.createParser(str).parser();
		
		log.info("tipo " + sm.messageType());
		sm.getBlock4().forEach(b -> {
			log.info("valor " + b.getName() + " -> " + b.getValue());
		});

		log.info("***************************");
		
//		List<gob.bcb.iso20022.pojo.Block4> block4Exists = sm.getBlock4().stream().filter(b -> strategyBase.matchesForFieldswift(b.getName()).size() > 0).collect(Collectors.toList());
//		
//		block4Exists.forEach(b -> {
//			log.info("	tipo " + b.getName() + " -> " + b.getValue());
//		});
		log.info("##############################");		
		List<gob.bcb.iso20022.pojo.Block4> block4Exists = sm.getBlock4().stream().filter( b -> {
			Map<String, Map<String, List<FieldQuery>>> matches;
			try {
				matches = strategyBase.matchesForFieldswift(b.getName());
				return matches.size() > 0;
			} catch (ExecutionException e) {
				log.error(e.getMessage(), e);
				return false;
			}
			
		}).collect(Collectors.toList());

		block4Exists.forEach(b -> {
			log.info("	tipo " + b.getName() + " -> " + b.getValue());
		});
		log.info(".................1111111111111.................");		
		block4Exists = sm.getBlock4().stream().filter( b -> {
			Map<String, Map<String, List<FieldQuery>>> matches;
			try {
				matches = strategyBase.matchesForFieldswift(b.getName());
				return matches.size() > 0;
			} catch (ExecutionException e) {
				log.error(e.getMessage(), e);
				return false;
			}
			
		}).collect(Collectors.toList());

		block4Exists.forEach(b -> {
			log.info("	tipo " + b.getName() + " -> " + b.getValue());
		});

		log.info(".................2222222222222.................");		
		block4Exists = sm.getBlock4().stream().filter( b -> {
			Map<String, Map<String, List<FieldQuery>>> matches;
			try {
				matches = strategyBase.matchesForFieldswift(b.getName());
				return matches.size() > 0;
			} catch (ExecutionException e) {
				log.error(e.getMessage(), e);
				return false;
			}
			
		}).collect(Collectors.toList());

		block4Exists.forEach(b -> {
			log.info("	tipo " + b.getName() + " -> " + b.getValue());
		});
		
	}	
}
