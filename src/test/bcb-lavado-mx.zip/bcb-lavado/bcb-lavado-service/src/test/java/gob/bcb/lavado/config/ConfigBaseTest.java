package gob.bcb.lavado.config;

import java.net.URL;
import java.util.Iterator;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.dumbster.smtp.SimpleSmtpServer;
import com.dumbster.smtp.SmtpMessage;
import com.zaxxer.hikari.HikariConfig;

import gob.bcb.axesso.services.JndiDatasourceCreator;
import gob.bcb.lavado.ConfigApp;
import gob.bcb.lavado.commons.ArchivoSinpleServiceImpl;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.repository.OfaSdnentryRepository;
import gob.bcb.lavado.services.SwiftAdminDaoService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ConfigApp.class)
@WebAppConfiguration
//@IntegrationTest(value={"spring.config.location=" + Constants.BASE_DIR_APP,"spring.profiles.active=dev"})//,"server.port=8881"})
@IntegrationTest(value={"spring.config.location=" + Constants.BASE_DIR_APP,"spring.profiles.active=dev","server.port=8881"})
//@DirtiesContext
public abstract class ConfigBaseTest { 
	protected final static Logger log = LoggerFactory.getLogger(ConfigBaseTest.class);
	static int cont = 0;

	protected int TEST_SMTP_PORT = 1025;
	protected String TEST_SMTP_HOSTNAME = "localhost";
	protected SimpleSmtpServer smtpServer;
	
	@Autowired
	protected JavaMailSenderImpl javaMailSenderImpl;
	@Autowired
	@Qualifier("dataSourceSwift")
	protected DataSource dataSourceSwift;
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
	@Autowired
	protected OfaSdnentryRepository ofaSdnentryRepository;
	
	@Value("${local.server.port}")
	protected int port;
	
	protected URL base;
	protected RestTemplate template;
	
	boolean dropExecuted = false;
	protected static boolean listLoaded = false;
	protected static SwfLote swfLoteLoaded;
	protected static long testTimeGlobal = System.currentTimeMillis();
	private final AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();	

	@Before
	public void before() throws Throwable {
		cont++;
		log.info("=== Before setup==== " + cont);

		Assert.assertNotNull("Conexxion dataSourceSwift NULO", dataSourceSwift);
		this.base = new URL("http://localhost:" + port + "/");
		//this.base = new URL("http://swfapp.bcb.com:8881/lavado/");		
//		this.base = new URL("http://10.3.11.170:8080/lavado/");		
		template = new TestRestTemplate();
		log.info(this.base.toString());
		
		initMailDummy();
	} 

	@After
	public void stopSmtp() {
		log.info("=== After setup==== " + cont);		
		if (smtpServer!= null && !smtpServer.isStopped()){
			smtpServer.stop();
			log.info("SMTP dummy stoping.");			
		}
	}
	
	@AfterClass
	public static void afterTest() {
		log.info("Fin test tiempo: " + (System.currentTimeMillis() - testTimeGlobal) + " ms");
	}
	public void initMailDummy() throws Exception {
		if (smtpServer != null)
			return;
		log.info("SMTP dummy inicializando...");
		
		smtpServer = SimpleSmtpServer.start(TEST_SMTP_PORT);
		log.info("SMTP dummy started...");
		javaMailSenderImpl.setHost(TEST_SMTP_HOSTNAME);
		javaMailSenderImpl.setPort(TEST_SMTP_PORT);
		javaMailSenderImpl.setUsername("wherrera");
		javaMailSenderImpl.setPassword("12345678");
		
		log.info("SMTP dummy inicializando... portMail: " + javaMailSenderImpl.getPort() + " " + javaMailSenderImpl.getHost());		
	}
	
	public void receiveMail(boolean expectMail) {
		log.info("receiveMail ...: ");
		if (smtpServer == null || smtpServer.isStopped()){
			return;
		}
		Iterator emailIter = null;
		if (expectMail) {
			int cont = 0;
			do {
				try {
					Thread.sleep(1000);
					log.info("Esperando mail ciclo " + cont);
				} catch (InterruptedException e) {
					log.error("message " + e.getMessage(), e);
				}
			} while (cont++ <= 8 && smtpServer.getReceivedEmailSize() == 0);

		} 
		
		emailIter = smtpServer.getReceivedEmail();
		while (emailIter.hasNext()) {
			log.info("========= new mail dummy incoming ==========" +  smtpServer.getReceivedEmailSize());
			SmtpMessage email = (SmtpMessage) emailIter.next();
			log.info(email.getHeaderValue("Subject"));
			log.info(email.getHeaderValue("From"));
			log.info(email.getHeaderValue("To"));
			log.info(email.toString());
		}
	}
	
	public void initDataInicialBaseSearch() throws Throwable {
		if (listLoaded ){
			// el proceso inicial fue cargado
			return ;
		}
		log.info("Proceso test initDataBaseSearch");
		
		String fileSdn = "src/test/resources/ofac/lista_inicial.xml";
		String nameFileOriginal = "lista_inicial.xml";
		
		ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
		archivoSinpleService.fromPathfile(fileSdn, nameFileOriginal);
		
		swfLoteLoaded = swiftAdminDaoService.guardarLoteOfac("usertest", archivoSinpleService.getArchivoSinple(),"estacion");
		log.info("guardarLoteOfacTest done!! " + swfLoteLoaded.getLotNrolote());
		
		Assert.assertTrue("Se esperaba tabla con registros", ofaSdnentryRepository.count() > 0);
		
		swiftAdminDaoService.indexOfaSdnentry();
		log.info("Proceso initDataBaseSearch ejecutado");
		listLoaded = true;
	}

	@Configuration
	@ConfigurationProperties(prefix = Constants.PROP_PREFIX_CONTBCB)	
	static class TestDataSourceConfCoin extends HikariConfig{
		@PostConstruct
		public void init() throws Exception{
			log.info("PostConstruct TestDataSourceConfiguration coin....." + getJdbcUrl() + " " + getUsername());
			JndiDatasourceCreator.createJndiMock(getUsername().trim(),getPassword().trim(),getJdbcUrl().trim(), getDataSourceJNDI());
		}
	}
	
	@Configuration
	@ConfigurationProperties(prefix = Constants.PROP_PREFIX_LAVADO)	
	static class TestDataSourceConfLavado extends HikariConfig{
		@PostConstruct
		public void init() throws Exception{
			log.info("PostConstruct TestDataSourceConfiguration lavado....." + getJdbcUrl() + " " + getUsername());
			JndiDatasourceCreator.createJndiMock(getUsername().trim(),getPassword().trim(),getJdbcUrl().trim(), getDataSourceJNDI());
		}
	}	
	
	@Configuration
	@ConfigurationProperties(prefix = Constants.PROP_PREFIX_PORTIA)	
	static class TestDataSourceConfPortia extends HikariConfig{
		@PostConstruct
		public void init() throws Exception{
			log.info("PostConstruct TestDataSourceConfiguration portia....." + getJdbcUrl() + " " + getUsername());
			JndiDatasourceCreator.createJndiMock(getUsername().trim(),getPassword().trim(),getJdbcUrl().trim(), getDataSourceJNDI());
		}
	}	
	
	@Configuration
	@ConfigurationProperties(prefix = Constants.PROP_PREFIX_RRHH)	
	static class TestDataSourceConfSap extends HikariConfig{
		@PostConstruct
		public void init() throws Exception{
			log.info("PostConstruct TestDataSourceConfiguration RRHH....." + getJdbcUrl() + " " + getUsername());
			JndiDatasourceCreator.createJndiMock(getUsername().trim(),getPassword().trim(),getJdbcUrl().trim(), getDataSourceJNDI());
		}
	}	
	@Configuration
	@ConfigurationProperties(prefix = Constants.PROP_PREFIX_AXESSO)	
	static class TestDataSourceConfAxesso extends HikariConfig{
		@PostConstruct
		public void init() throws Exception{
			log.info("PostConstruct TestDataSourceConfiguration AXESSO....." + getJdbcUrl() + " " + getUsername());
			JndiDatasourceCreator.createJndiMock(getUsername().trim(),getPassword().trim(),getJdbcUrl().trim(), getDataSourceJNDI());
		}
	}	
	
}
