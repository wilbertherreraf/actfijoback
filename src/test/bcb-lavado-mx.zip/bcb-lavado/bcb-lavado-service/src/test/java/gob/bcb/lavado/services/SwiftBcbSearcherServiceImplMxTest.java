package gob.bcb.lavado.services;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.client.ClienteLvd;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.model.SwfMensaje;

public class SwiftBcbSearcherServiceImplMxTest extends ConfigBaseTest {
	protected final static Logger log = LoggerFactory.getLogger(SwiftBcbSearcherServiceImplMxTest.class);
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;

	private String url;
	ClienteLvd scanSwiftMessage;

	@Before
	@Override
	public void before() throws Throwable {
		super.before();
		// initDataInicialBaseSearch();
		url = base.toString();
		scanSwiftMessage = ClienteLvd.init(url, "/opt/aplicaciones/lavado", "SIOCWEB");
	}

	// @Test
	public void verificarMensajeSinObsTest() throws Throwable {
		final String archSwift = "src/test/resources/mx/pacs008.xml";
		searchAndVerifyResponse(archSwift, 0);
	}

//	@Test
	public void verificarMensajeObsTest() throws Throwable {
		final String archSwift = "src/test/resources/mx/pacs008obs.xml";
		searchAndVerifyResponse(archSwift, 1);
	}

	// @Test
	public void solicitarCorrelativoTest() {
		String archSwift = "src/test/resources/mx/pacs008.xml";
		SwfMensaje swfMensaje = generarMensaje(archSwift);
		SearchResponse searchResponse = swiftBcbSearcherService.solicitarCorrelativo(swfMensaje.getMenCodapp(), swfMensaje.getMenRefer(),
				swfMensaje.getMenAuditusr(), swfMensaje.getMenFirmaorigen(), "test");
		printSearchResponse(searchResponse);
	}

	//@Test
	public void scanMensajePlanoConCorrSolicitadoTest() {
		String archSwift = "src/test/resources/mx/pacs008.xml";
		SwfMensaje swfMensaje = generarMensaje(archSwift);
		String clau = "";
		Integer idmen = 845;
		swfMensaje.setMenCodmen(idmen);
		swfMensaje.setMenNrocorr(1720);
		
		SearchResponse searchResponse = swiftBcbSearcherService.scanMensajePlanoConCorrSolicitado(swfMensaje.getMenPlano(), swfMensaje.getMenCodapp(),
				swfMensaje.getMenCodmen(), swfMensaje.getMenNrocorr(), swfMensaje.getMenRefer(), swfMensaje.getMenAuditusr(), "estacion", swfMensaje.getMenFirmaorigen(), clau);
		printSearchResponse(searchResponse);
	}

	@Test
	public void scanMensajeConCorrSolicitadoObsTest() {
		String archSwift = "src/test/resources/mx/pacs008.xml";
		SwfMensaje swfMensaje = generarMensaje(archSwift);
		
		SearchResponse searchResponse = swiftBcbSearcherService.solicitarCorrelativo(swfMensaje.getMenCodapp(), swfMensaje.getMenRefer(),
				swfMensaje.getMenAuditusr(), swfMensaje.getMenFirmaorigen(), "test");
		printSearchResponse(searchResponse);
		
		String clau = searchResponse.getCodResplau();
		Integer idmen = Integer.valueOf(searchResponse.getCodoperacion());
		swfMensaje.setMenCodmen(idmen);
		swfMensaje.setMenNrocorr(searchResponse.getNrocorr());
		log.info("antes de scan ............");
		SearchResponse searchResponse0 = swiftBcbSearcherService.scanMensajePlanoConCorrSolicitado(swfMensaje.getMenPlano(), swfMensaje.getMenCodapp(),
				swfMensaje.getMenCodmen(), swfMensaje.getMenNrocorr(), swfMensaje.getMenRefer(), swfMensaje.getMenAuditusr(), "estacion", swfMensaje.getMenFirmaorigen(), clau);
		printSearchResponse(searchResponse0);
		
		log.info("antes de pre auto............");

		SearchResponse searchResponse1 = swiftBcbSearcherService.preAutorizaSwift(swfMensaje.getMenCodmen(), swfMensaje.getMenCodapp(),
				swfMensaje.getMenAuditusr(), swfMensaje.getMenRefer(), swfMensaje.getMenFirmaorigen(), swfMensaje.getMenPlano(), "estacion", clau);
		printSearchResponse(searchResponse1);		
	}
	private void searchAndVerifyResponse(String archSwift, Integer expectedregs) {
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		SearchResponse searchResponse = swiftBcbSearcherService.searchScanSingle(menPlano, true);
		printSearchResponse(searchResponse);
		verifyResponse(searchResponse, expectedregs);
	}

	private void verifyResponse(SearchResponse searchResponse, Integer expectedregs) {
		log.info("expectedregs " + expectedregs + " " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
		if (expectedregs.compareTo(0) > 0) {
			Assert.assertTrue("nro de registros invalido", searchResponse.getCountRegs().compareTo(expectedregs) >= 0);
		} else {
			Assert.assertTrue("nro de registros invalido", searchResponse.getCountRegs().compareTo(0) == 0);
		}
	}

	public static void printSearchResponse(SearchResponse searchResponse) {
		log.info("==> Respuesta " + searchResponse.getCodResp() + " : " + searchResponse.getDescripResp() + " " + searchResponse.getDescripResplau());
		if (searchResponse.getCountRegs() != null && searchResponse.getCountRegs() > 0) {
			for (gob.bcb.lavado.client.pojos.SearchResponse.ItemsInfo ii : searchResponse.getItemsInfo()) {
				log.info("ii => {} : {} {} -> {} [{}]", ii.getIdDoc(), ii.getField(), ii.getContent(), ii.getContentHighlight(), ii.getScore());
			}
		}
	}

	public SwfMensaje generarMensaje(String file) {
		log.info("generarMensaje");
		String codapp = "TEST";
		String coduser = "1622";
		String idoperacion = String.valueOf(System.currentTimeMillis());
		String menPlano = UtilsFile.readFileAsString2(file);
		menPlano = menPlano.replace("1392930010", idoperacion);

		// solicitud del correlativo
		SwfMensaje swfMensaje = new SwfMensaje();
		swfMensaje.setMenCodapp(codapp);
		swfMensaje.setMenAuditusr(coduser);
		swfMensaje.setMenCodusrswf("usertest");
		swfMensaje.setMenRefer(idoperacion);
		swfMensaje.setMenPlano(menPlano);
		swfMensaje.setMenFirmaorigen(idoperacion);
		return swfMensaje;
	}
}
