package gob.bcb.lavado.services;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.client.HandlerGeneratorLauSrv;
import gob.bcb.swift.pojos.SwiftDatos;

public class SwiftBcbParserServiceImplTest {
	private static final Logger log = LoggerFactory.getLogger(SwiftBcbParserServiceImplTest.class);

//	@Test
	public void swfMTDatosFromPlano() {
		try {
			String menPlano = UtilsFile.readFileAsString2("src/test/resources/swifts/swf_conlau.dos");
			SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menPlano);
			log.info("MT : " + swiftDatos.getSwiftMessageAbs().fromMsg());
			log.info("MT : " + swiftDatos.getSwfMensaje().toString());
			log.info("MT : " + swiftDatos.getSwiftMessageAbs().getTagCodeLau() + "  " + swiftDatos.getSwiftMessageAbs().checkSum());
			
			swfMXDatosFromPlano();
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	//@Test
	public void swfMXDatosFromPlano() {
		try {
			String menPlano = UtilsFile.readFileAsString2("src/test/resources/mx/pacs008.xml");
			SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menPlano);
			log.info("MX : " + swiftDatos.getSwiftMessageAbs().fromMsg());
			log.info("MX : " + swiftDatos.getSwfMensaje().toString());
			log.info("MX : " + swiftDatos.getSwiftMessageAbs().getTagCodeLau() + "  " + swiftDatos.getSwiftMessageAbs().checkSum());
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	//@Test
	public void updSignConFirmaMT() {
		try {
			log.info("============= INICIANDO SIGN TEST");
			HandlerGeneratorLauSrv.initCurrentInstance("e:/opt/aplicaciones/lavado", "LAVADO");
			String menPlano = UtilsFile.readFileAsString2("src/test/resources/swifts/swf_conlau.dos");
			log.info(menPlano);
			String codelauPlano = HandlerGeneratorLauSrv.getGeneratorLAU().signLau(menPlano);
			SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menPlano);
			
			String codelau = "861F6CFD4C6180C1FFC83ED54799A2FE5F34D2CACD20D4E7E79CDB9768BFE79E";
			SwiftBcbParserServiceImpl.updSign(swiftDatos, codelauPlano);
			
			log.info("MX : " + swiftDatos.getSwiftMessageAbs().fromMsg());
			log.info("MX MenPlano: " + swiftDatos.getSwfMensaje().getMenPlano());
			log.info("MX MenPlano Abs: " + swiftDatos.getSwiftMessageAbs().getMenPlano());			
			log.info("MX : " + swiftDatos.getSwfMensaje().getMenHash() + " codelau: " + codelau);
			log.info("MX : " + swiftDatos.getSwiftMessageAbs().getTagCodeLau() + "  " + swiftDatos.getSwiftMessageAbs().checkSum());
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}	

	@Test
	public void updSignConFirmaDiffMT() {
		try {
			log.info("============= INICIANDO SIGN TEST");
			HandlerGeneratorLauSrv.initCurrentInstance("e:/opt/aplicaciones/lavado", "LAVADO");
			String menPlano = UtilsFile.readFileAsString2("src/test/resources/swifts/swf_conlaudif.dos");
			log.info(menPlano);
			String codelauPlano = HandlerGeneratorLauSrv.getGeneratorLAU().signLau(menPlano);
			SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menPlano);
			
			String codelau = "861F6CFD4C6180C1FFC83ED54799A2FE5F34D2CACD20D4E7E79CDB9768BFE79E";
			SwiftBcbParserServiceImpl.updSign(swiftDatos, codelauPlano);
			
			log.info("MX : " + swiftDatos.getSwiftMessageAbs().fromMsg());
			log.info("MX MenPlano: " + swiftDatos.getSwfMensaje().getMenPlano());
			log.info("MX MenPlano Abs: " + swiftDatos.getSwiftMessageAbs().getMenPlano());			
			log.info("MX : " + swiftDatos.getSwfMensaje().getMenHash() + " codelau: " + codelau);
			log.info("MX : " + swiftDatos.getSwiftMessageAbs().getTagCodeLau() + "  " + swiftDatos.getSwiftMessageAbs().checkSum());
			
			swiftDatos.getSwiftMessageAbs().createBlock4();
			swiftDatos.getSwiftMessageAbs().getBlock4().forEach(b -> {
				log.info(b.getName() + " " + b.getValue());
			});
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	
	@Test
	public void updSignConFirmaMX() {
		try {
			log.info("============= INICIANDO SIGN TEST");
			HandlerGeneratorLauSrv.initCurrentInstance("e:/opt/aplicaciones/lavado", "LAVADO");
			String menPlano = UtilsFile.readFileAsString2("src/test/resources/mx/pacs.008hdr.xml");
			log.info(menPlano);
			String codelauPlano = HandlerGeneratorLauSrv.getGeneratorLAU().signLau(menPlano);
			SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menPlano);
			
			String codelau = "861F6CFD4C6180C1FFC83ED54799A2FE5F34D2CACD20D4E7E79CDB9768BFE79E";
			SwiftBcbParserServiceImpl.updSign(swiftDatos, codelauPlano);
			
			log.info("MX : " + swiftDatos.getSwiftMessageAbs().fromMsg());
			log.info("MX SIGN: " + swiftDatos.getSwiftMessageAbs().getMenPlanoSign());
			log.info("MX MenPlano: " + swiftDatos.getSwfMensaje().getMenPlano());
			log.info("MX MenPlano Abs: " + swiftDatos.getSwiftMessageAbs().getMenPlano());			
			log.info("MX : " + swiftDatos.getSwfMensaje().getMenHash() + " codelau: " + codelau);
			log.info("MX : " + swiftDatos.getSwiftMessageAbs().getTagCodeLau() + "  " + swiftDatos.getSwiftMessageAbs().checkSum());
			
			swiftDatos.getSwiftMessageAbs().createBlock4();
			swiftDatos.getSwiftMessageAbs().getBlock4().forEach(b -> {
				log.info(b.getName() + " " + b.getValue());
			});
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}	
	
}
