package gob.bcb.lavado.lavadoclient;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.client.ClienteLvd;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.services.SessionsSearcherService;

public class ClienteLvdTest { // extends ConfigBaseTest {
	protected final static Logger log = LoggerFactory.getLogger(ClienteLvdTest.class);
	private String url = "http://10.3.11.82:8881/lavado/";
	ClienteLvd clienteLvd;
	@Autowired
	private SessionsSearcherService sessionsSearcherService;

	@Before
	// @Override
	public void before() throws Throwable {
		// super.before();
		// initDataInicialBaseSearch();
		// url = base.toString();
		// clienteLvd = new ClienteLvd(url, "/opt/aplicaciones/lavado", "SIOCWEB");
	}

//	@Test
	public void registroNoObservadoConCorrelativoSolicitadoTest() throws Exception {
		for (int i = 1; i < 2; i++) {
			log.info("=== registroNoObservadoConCorrelativoSolicitadoTest " + url);
			clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", "SIOCWEB");
			String archSwift = "src/test/resources/mx/mxpacs01.mx"; // src/test/resources/swifts/swf_sinobservacion.dos
			String menPlano = UtilsFile.readFileAsString2(archSwift);

			SearchResponse searchResponse = clienteLvd.getIniSessionLavado("SIOCWEB", "usertest");
			String idsession = searchResponse.getCodoperacion();
			log.info("SESSION LAVADO " + idsession);
			String codigo = String.valueOf(System.currentTimeMillis()).substring(8);

			searchResponse = clienteLvd.solicitarCorrelativo("SIOCWEB", codigo, "usertest", idsession);
			Assert.assertNotNull("searchResponse nulo", searchResponse);
			Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
			Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
			Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

			Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
			log.info("ANTES DE SCAM " + idsession);
			searchResponse = clienteLvd.scanSwiftRegistro("SIOCWEB", "usertest", Integer.valueOf(searchResponse.getCodoperacion()),
					searchResponse.getNrocorr(), codigo, idsession, menPlano);

			Assert.assertNotNull("searchResponse nulo", searchResponse);
			Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
			Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(menCodmen) == 0);
			Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

			log.info("ANTES DE PREAUTO " + idsession);
			searchResponse = clienteLvd.preautorizarSwift("SIOCWEB", "usertest", Integer.valueOf(searchResponse.getCodoperacion()),
					searchResponse.getNrocorr(), codigo, idsession, menPlano);

			searchResponse = clienteLvd.postSessionLavado("SIOCWEB", "usertest", idsession);
			Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
			Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));

		}
	}

//	@Test
	public void testConcurrentTest2() throws Exception {
		log.info("!!!!!!!!!!!!!!!!!! [ INICIO CONCURRENCIA ] !!!!!!!!!!!!!!!!!!");
		Stream<CompletableFuture<Integer>> futureWrite = Arrays.asList(1,2).stream().map(item -> {
			return CompletableFuture.supplyAsync(() -> {
				try {
					log.info("=== " + item + " =============");
					String idApp = "SIOCWEB" + item;
					ClienteLvd clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", idApp);
					String archSwift = "src/test/resources/swifts/swf_sinobservacion.dos";
					String menPlano = UtilsFile.readFileAsString2(archSwift);
					String idoperacion = String.valueOf(System.nanoTime());
					menPlano = menPlano.replace("04054727", idoperacion);

					SearchResponse searchResponse = clienteLvd.getIniSessionLavado(idApp, "usertest");
					String idsession = searchResponse.getCodoperacion();

					String codigo = String.valueOf(System.currentTimeMillis()).substring(8) + item;
					log.info(codigo + " -> SESSION LAVADO " + idsession);
					searchResponse = clienteLvd.solicitarCorrelativo(idApp, codigo, "usertest", idsession);
					Assert.assertNotNull("searchResponse nulo", searchResponse);
					Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
					Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
					Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

					Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
					Integer nrocorr = searchResponse.getNrocorr();
					searchResponse = clienteLvd.postSessionLavado(idApp, "usertest", idsession);

					log.info("**********      {" + item +"}            ********************** " + menCodmen + " " + nrocorr, item);
					searchResponse = clienteLvd.getIniSessionLavado(idApp, "usertest");
					idsession = searchResponse.getCodoperacion();

					log.info("**********1111111111111111{" + item +"}111111111111********************** " + menCodmen + " Nrocorr: " + nrocorr + " idsession: "
							+ idsession);

					searchResponse = clienteLvd.scanSwiftRegistro(idApp, "usertest", menCodmen, nrocorr, codigo, idsession, menPlano);

					searchResponse = clienteLvd.postSessionLavado(idApp, "usertest", idsession);
					log.info("**********222222222222222{" + item +"}22222222222222**********************");
					searchResponse = clienteLvd.getIniSessionLavado(idApp, "usertest");
					idsession = searchResponse.getCodoperacion();

					Assert.assertNotNull("searchResponse nulo", searchResponse);
					Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));

					searchResponse = clienteLvd.preautorizarSwift(idApp, "usertest", menCodmen, nrocorr, codigo, idsession, menPlano);

					searchResponse = clienteLvd.postSessionLavado(idApp, "usertest", idsession);
					Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
					Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
					log.info("FFFFFin {" + item +"} FFFFFFIN");
					return item;
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			});
		});

		List<CompletableFuture<Integer>> priceFutures = futureWrite.collect(Collectors.<CompletableFuture<Integer>>toList());

		log.info("-------------IIIIIIIIII------------------- ");
		priceFutures.stream().map(CompletableFuture::join).count();// collect(Collectors.toList());

//		for (int i = 1; i < 10; i++) {
//			log.info("=== registroNoObservadoConCorrelativoSolicitadoTest2 " + url);
//			clienteLvd = new ClienteLvd(url, "/opt/aplicaciones/lavado", "SIOCWEB");
//			String archSwift = "src/test/resources/swifts/swf_sinobservacion.dos";
//			String menPlano = UtilsFile.readFileAsString2(archSwift);
//
//			SearchResponse searchResponse = clienteLvd.getIniSessionLavado("SIOCWEB", "usertest");
//			String idsession = searchResponse.getCodoperacion();
//			log.info("SESSION LAVADO " + idsession);
//			String codigo = String.valueOf(System.currentTimeMillis()).substring(8);
//
//			searchResponse = clienteLvd.solicitarCorrelativo("SIOCWEB", codigo, "usertest", idsession);
//			Assert.assertNotNull("searchResponse nulo", searchResponse);
//			Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
//			Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
//			Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);
//
//			Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
//			Integer nrocorr = searchResponse.getNrocorr();
//			searchResponse = clienteLvd.postSessionLavado("SIOCWEB", "usertest", idsession);
//
//			log.info("**********      {}            ********************** " + menCodmen + " " + nrocorr, i);
//			searchResponse = clienteLvd.getIniSessionLavado("SIOCWEB", "usertest");
//			idsession = searchResponse.getCodoperacion();
//
//			log.info("**********1111111111111111.111111111111********************** " + menCodmen + " Nrocorr: " + nrocorr + " idsession: " + idsession);
//
//			searchResponse = clienteLvd.scanSwiftRegistro("SIOCWEB", "usertest", menCodmen, nrocorr, codigo, idsession, menPlano);
//
//			searchResponse = clienteLvd.postSessionLavado("SIOCWEB", "usertest", idsession);
//			log.info("**********22222222222222222222222222222**********************");
//			searchResponse = clienteLvd.getIniSessionLavado("SIOCWEB", "usertest");
//			idsession = searchResponse.getCodoperacion();
//
//			Assert.assertNotNull("searchResponse nulo", searchResponse);
//			Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
//
//			searchResponse = clienteLvd.preautorizarSwift("SIOCWEB", "usertest", menCodmen, nrocorr, codigo, idsession, menPlano);
//
//			searchResponse = clienteLvd.postSessionLavado("SIOCWEB", "usertest", idsession);
//			Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
//			Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
//
//		}
	}

	// @Test
	public void registroConCorrelativoSolicitadoTest() throws Exception {
		log.info("=== registroConCorrelativoSolicitadoTest " + url);
		String archSwift = "src/test/resources/swifts/swf_4632_ent.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		SearchResponse searchResponse = clienteLvd.getSessionLavado("TEST", "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);
		String codigo = String.valueOf(System.currentTimeMillis()).substring(8);

		searchResponse = clienteLvd.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
		Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
		Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

		Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());

		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(),
				codigo, idsession, menPlano);

		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
		Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(menCodmen) == 0);
		Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

		searchResponse = clienteLvd.postSessionLavado("TEST", "usertest", idsession);
		Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));

	}

	// @Test
	public void registroConBloqueoYReenvioCorrelativoSolicitadoTest() throws Exception {
		log.info("=== registroConBloqueoYReenvioCorrelativoSolicitadoTest " + url);

		String archSwift = "src/test/resources/swifts/swf_9645_indiv_alias.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		SearchResponse searchResponse = clienteLvd.getSessionLavado("TEST", "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);

		String codigo = String.valueOf(System.currentTimeMillis()).substring(8);
		searchResponse = clienteLvd.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
		Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
		Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

		log.info("===================INI===========================");
		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(),
				codigo, idsession, menPlano);
		log.info("" + searchResponse.getCountRegs() + " " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
		log.info("===================FIN===========================");
		Assert.assertTrue("Registros debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_01));

		// reenvio de la operacion
		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(),
				codigo, idsession, menPlano);
		Assert.assertTrue("Registros debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_02));

		searchResponse = clienteLvd.postSessionLavado("TEST", "usertest", idsession);
		Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
	}

	// @Test
	public void registroSinBloqueoReenvioSinModificacionTest() throws Exception {
		log.info("=== registroSinBloqueoReenvioSinModificacionTest " + url);

		String archSwift = "src/test/resources/swifts/sir2016000011.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		SearchResponse searchResponse = clienteLvd.getSessionLavado("TEST", "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);

		String codigo = String.valueOf(System.currentTimeMillis()).substring(8);
		searchResponse = clienteLvd.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));

		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(),
				codigo, idsession, menPlano);

		Assert.assertTrue("Registros debe ser 0", searchResponse.getCountRegs().compareTo(0) == 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
		log.info("================== REENVIO ========================= ");
		// reenvio de la operacion
		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(),
				codigo, idsession, menPlano);
		Assert.assertTrue("Registros invalido", searchResponse.getCountRegs().compareTo(0) == 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
		searchResponse = clienteLvd.postSessionLavado("TEST", "usertest", idsession);
		Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
	}

	// @Test
	public void registroConCorrelativoYSessionRevalidaEInvalidaTest() throws Exception {
		log.info("=== registroConCorrelativoYSessionRevalidaEInvalidaTest " + url);
		// sessionsSearcherService.initCache(5, TimeUnit.SECONDS);
		String archSwift = "src/test/resources/swifts/swf_4632_ent.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		SearchResponse searchResponse = clienteLvd.getIniSessionLavado("TEST", "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);
		String codigo = String.valueOf(System.currentTimeMillis()).substring(8);

		try {
			log.info("durmiendo zzZZzzzzzz antes de solicitarCorrelativo 3 segs");
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			log.error("Exception thrown while sleeping in between runs of the scan cleanup thread ", e);
		}

		searchResponse = clienteLvd.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
		Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
		Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

		Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
		try {
			log.info("durmiendo zzZZzzzzzz antes de scanSwiftRegistro 3 segs");
			TimeUnit.SECONDS.sleep(3);
		} catch (InterruptedException e) {
			log.error("Exception thrown while sleeping in between runs of the scan cleanup thread ", e);
		}

		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", menCodmen, searchResponse.getNrocorr(), codigo, idsession, menPlano);

		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertTrue("Cod de respuesta invalida se esperaba " + Constants.COD_RESP_ERR_02,
				!searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_02));

		try {
			log.info("durmiendo zzZZzzzzzz antes de segundo scanSwiftRegistro");
			TimeUnit.SECONDS.sleep(6);
		} catch (InterruptedException e) {
			log.error("Exception thrown while sleeping in between runs of the scan cleanup thread ", e);
		}

		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", menCodmen, searchResponse.getNrocorr(), codigo, idsession, menPlano);

		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_02));

		sessionsSearcherService.initCache(Constants.SEC_TIME_LIFE_FOR_SESSIONS_REST, TimeUnit.MINUTES);
	}

	// @Test
	public void testConcurrentClientlvdScanMsgPlanoSingleFromString() {
		String archSwift = "src/test/resources/swifts/swf_4632_ent.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		String archSwift1 = "src/test/resources/swifts/swf_9645_indiv_alias.dos";
		String menPlano1 = UtilsFile.readFileAsString2(archSwift1);

		String archSwift2 = "src/test/resources/swifts/sir2016000011.txt";
		String menPlano2 = UtilsFile.readFileAsString2(archSwift2);

		List<Callable<String>> callableTasks = new ArrayList<>();
		callableTasks.add(execTask("Aaaaa", menPlano));
		callableTasks.add(execTask("Bbbbb", menPlano1));
		callableTasks.add(execTask("Ccccc", menPlano2));

		log.info("Antes de config testConcurrentClientlvd");
		ExecutorService executorService = Executors.newFixedThreadPool(10);
		log.info("Antes de submit concurrentTest");

		List<Future<String>> futures = new ArrayList<>();
		try {
			futures = executorService.invokeAll(callableTasks);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		// executorService.submit(callableTask);
		log.info("despues concurrentTest");
		executorService.shutdown();

		Assert.assertTrue(executorService.isShutdown());

	}

	// @Test
	public void testConcurrentClientlvdRegistroYScan() throws Exception {
		String archSwift = "src/test/resources/swifts/swf_4632_ent.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		String codigo = String.valueOf(System.currentTimeMillis()).substring(8) + "AAAAA";

		String archSwift1 = "src/test/resources/swifts/swf_9645_indiv_alias.dos";
		String menPlano1 = UtilsFile.readFileAsString2(archSwift1);
		String codigo1 = String.valueOf(System.currentTimeMillis()).substring(8) + "BBBBB";

		String archSwift2 = "src/test/resources/swifts/sir2016000011.txt";
		String menPlano2 = UtilsFile.readFileAsString2(archSwift2);
		String codigo2 = String.valueOf(System.currentTimeMillis()).substring(8) + "CCCCC";

		List<Callable<SearchResponse>> callableTasks = new ArrayList<>();
		callableTasks.add(registroYScanConCorrelativo("Aaaaa", menPlano, codigo));
		callableTasks.add(registroYScanConCorrelativo("Bbbbb", menPlano1, codigo1));
		callableTasks.add(registroYScanConCorrelativo("Ccccc", menPlano2, codigo2));

		log.info("Antes de config testConcurrentClientlvdRegistroYScan");
		ExecutorService executorService = Executors.newFixedThreadPool(10);
		log.info("Antes de submit testConcurrentClientlvdRegistroYScan");

		List<Future<SearchResponse>> futures = new ArrayList<>();
		futures = executorService.invokeAll(callableTasks);
		log.info("OOOOOOOO despues testConcurrentClientlvdRegistroYScan OOOOOOOOOO");
		executorService.shutdown();

		Assert.assertTrue(executorService.isShutdown());

	}

	public Callable<String> execTask(String idtask, String menPlano) {
		return () -> {
			int i = (int) (Math.random() * 5);
			log.info("AAAAAAAAATES [" + idtask + " ] en tassssssssssssssk " + i);
			SearchResponse searchResponse = clienteLvd.scanMsgPlanoSingleFromString(menPlano);
			// TimeUnit.MILLISECONDS.sleep(1000 * i);
			log.info("[" + idtask + " ] ======================== " + i);
			log.info("[" + idtask + " ] Despues en tassssssssssssssk " + i);
			log.info("[" + searchResponse.getCodResp() + " ]" + searchResponse.getDescripResp());
			return "Task's execution";
		};
	}

	public Callable<SearchResponse> registroYScanConCorrelativo(String idtask, String menPlano, String codigo) {
		return () -> {
			log.info(idtask + "]] === registroConCorrelativoSolicitado " + url);

			SearchResponse searchResponse = clienteLvd.getSessionLavado("TEST", "usertest");
			String idsession = searchResponse.getCodoperacion();
			log.info("SESSION LAVADO " + idsession);

			searchResponse = clienteLvd.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
			Assert.assertNotNull("searchResponse nulo", searchResponse);
			Assert.assertTrue("Cod de respuesta invalida", !searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_02));
			log.info("[" + idtask + " ] =============Antes scanSwiftRegistro=========== ");
			searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(),
					codigo, idsession, menPlano);

			Assert.assertNotNull("searchResponse nulo", searchResponse);
			Assert.assertTrue("Cod de respuesta invalida", !searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_02));
			log.info("[" + idtask + " ] RESPUESTA [" + searchResponse.getCodResp() + " ]" + searchResponse.getDescripResp());

			log.info("[" + idtask + " ] =============Antes postSessionLavado=========== ");
			searchResponse = clienteLvd.postSessionLavado("TEST", "usertest", idsession);
			Assert.assertNotNull("searchResponse nulo", searchResponse);
			Assert.assertTrue("Cod de respuesta invalida", !searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_02));
			log.info("[" + idtask + " ] ======================== ");
			log.info("[" + idtask + " ] [" + searchResponse.getCodResp() + " ]" + searchResponse.getDescripResp());
			return searchResponse;
		};
	}
}
