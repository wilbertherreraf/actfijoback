package gob.bcb.lavado.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.client.ClienteLvd;
import gob.bcb.lavado.client.HandlerGeneratorLauSrv;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfNumeraswf;
import gob.bcb.lavado.services.SchedulerService;
import gob.bcb.lavado.services.SwiftAdminDaoService;
import gob.bcb.swift.pojos.SwiftDatos;

public class SwfMensajeDaoTest extends ConfigBaseTest {
	private static final Logger log = LoggerFactory.getLogger(SwfMensajeDaoTest.class);
	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
	private String url;
	private ClienteLvd scanSwiftMessage;
	@Autowired 
	private AppProperties appProperties;
	@Autowired
	private SwfNumeraswfDaoImpl swfNumeraswfDao;
	@Before
	@Override
	public void before() throws Throwable {
		super.before();
		//initDataInicialBaseSearch();
		url = base.toString();
		scanSwiftMessage = ClienteLvd.init(url,"/opt/aplicaciones/lavado","SIOCWEB");
	}

	@Test
	public void registroConSolicitudCorrelativoTest() {
		log.info("Happy day: registroConSolicitudCorrelativoTest");
		SwfMensaje swfMensaje = registroSolicitud();
		SwiftDatos swiftDatos = swfMensajeDao.actualizarConPlano(swfMensaje.getMenPlano(), swfMensaje.getMenCodapp(), swfMensaje.getMenCodmen(),
				swfMensaje.getMenNrocorr(), swfMensaje.getMenRefer(), swfMensaje.getMenAuditusr(), "estacion", null, null);
		SwfMensaje swfMensajeNew = swiftDatos.getSwfMensaje(); 
		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertTrue("swfMensaje nulo", !swfMensajeNew.getMenPlano().isEmpty());
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR) == 0);
//		Assert.assertTrue("Se esperaba que hash sea identico ",
//				swfMensajeNew.getMenHash().equalsIgnoreCase(ArchivoUtil.hashString(ArchivoUtil.decodeFromUri(swfMensaje.getMenPlano()))));
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_REGISTRADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0);

		swfMensajeNew = swfMensajeDao.cambiarEstadoPostScan(swfMensajeNew.getMenCodmen(), 0, Constants.PARAM_ACCIONSCAN_BLQ);

		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_VERIFICADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0);

		swiftDatos = swfMensajeDao.preAutorizaSwift(swfMensajeNew.getMenCodmen(), swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				swfMensaje.getMenRefer(), swfMensaje.getMenRefer(), swfMensaje.getMenPlano(), "estacion", null);

		swfMensajeNew = swiftDatos.getSwfMensaje(); 
		
		Assert.assertNotNull("swfMensaje preautorizado nulo", swfMensajeNew);
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR) == 0);
		Assert.assertTrue("Estado mensaje se esperaba " + Constants.TAB_ESTMENSAJE_EN_PROCESO,
				swfMensajeNew.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_EN_PROCESO) == 0);

		Integer procesados = swfMensajeDao.cerrarTransaccion(swfMensaje.getMenRefer());
		Assert.assertTrue("procesados esperados invalido", procesados.compareTo(1) == 0);
		
		List<SwfMensaje> swfMensajeListaAutos = new ArrayList<>();
		swfMensajeListaAutos.add(swfMensajeNew);
		swiftAdminDaoService.grabarEnDirectorioSwift(swfMensajeListaAutos,"usertest","estacion");

		swfMensajeNew = swfMensajeDao.findByCodigo(swfMensajeNew.getMenCodmen());
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0);
		
		
	}

	//@Test(expected = SwiftAdminException.class)
	public void registroConSolicitudCorrelativoBloqueoTest() {
		log.info("registroConSolicitudCorrelativoBloqueoTest");
		SwfMensaje swfMensaje = registroSolicitud();
		SwiftDatos swiftDatos = swfMensajeDao.actualizarConPlano(swfMensaje.getMenPlano(), swfMensaje.getMenCodapp(), swfMensaje.getMenCodmen(),
				swfMensaje.getMenNrocorr(), swfMensaje.getMenRefer(), swfMensaje.getMenAuditusr(), "estacion", null, null);
		SwfMensaje swfMensajeNew = swiftDatos.getSwfMensaje();
		swfMensajeNew = swfMensajeDao.cambiarEstadoPostScan(swfMensajeNew.getMenCodmen(), 1, Constants.PARAM_ACCIONSCAN_BLQ);
		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0);

		swfMensajeDao.preAutorizaSwift(swfMensajeNew.getMenCodmen(), swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				swfMensaje.getMenRefer(), swfMensaje.getMenRefer(), swfMensaje.getMenPlano(), "estacion", null);
	}

	//@Test
	public void registroConSolicitudCorrelativoFalsoPositivoTest() {
		log.info("registroConSolicitudCorrelativoFalsoPositivoTest");
		SwfMensaje swfMensaje = registroSolicitud();
		SwiftDatos swiftDatos = swfMensajeDao.actualizarConPlano(swfMensaje.getMenPlano(), swfMensaje.getMenCodapp(), swfMensaje.getMenCodmen(),
				swfMensaje.getMenNrocorr(), swfMensaje.getMenRefer(), swfMensaje.getMenAuditusr(), "estacion", null, null);
		SwfMensaje swfMensajeNew = swiftDatos.getSwfMensaje();
		swfMensajeNew = swfMensajeDao.cambiarEstadoPostScan(swfMensajeNew.getMenCodmen(), 1, Constants.PARAM_ACCIONSCAN_BLQ);
		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0);

		swfMensajeNew = swfMensajeDao.cambiarEstadoVerificacion(swfMensajeNew.getMenCodmen(), swfMensaje.getMenAuditusr(),
				Constants.TAB_ESTVERIFICA_FALSO_POSITIVO, "estacion");
		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_FALSO_POSITIVO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO) == 0);

		swiftDatos = swfMensajeDao.preAutorizaSwift(swfMensajeNew.getMenCodmen(), swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				swfMensaje.getMenRefer(), null, swfMensaje.getMenPlano(), "estacion", null);
		
		swfMensajeNew = swiftDatos.getSwfMensaje();
		
		Assert.assertNotNull("swfMensaje preautorizado nulo", swfMensajeNew);
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR) == 0);
		Assert.assertTrue("Estado mensaje se esperaba " + Constants.TAB_ESTMENSAJE_PROCESADO,
				swfMensajeNew.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_PROCESADO) == 0);
		
		Integer procesados = swfMensajeDao.cerrarTransaccion(swfMensaje.getMenRefer());
		Assert.assertTrue("procesados esperados invalido", procesados.compareTo(0) == 0);
		
		// se procede a aprobar por scheduler
		List<SwfMensaje> swfMensajeListaAutos = new ArrayList<>();
		swfMensajeListaAutos.add(swfMensajeNew);
		int segundosAdd = 2;
		String hora = UtilsDate.stringFromDate(UtilsDate.addTime(new Date(), segundosAdd, 13), "HH:mm:ss");
		
		swiftAdminDaoService.startScheduling(hora, Constants.PARAM_HORARIOSIMPORT, Constants.SCHEDULER_CRON_EXPRESION);
		
		Assert.assertTrue("Scheduler no se ejecuto", SchedulerService.isRunningScheduler());
		try {
			log.info("Esperando un cachito zzZZzzzZzzz... " );
			TimeUnit.MILLISECONDS.sleep(6000);
		} catch (InterruptedException e) {
			log.error("Error en sleep " + e.getMessage());
		}

		swfMensajeNew = swfMensajeDao.findByCodigo(swfMensajeNew.getMenCodmen());
		Assert.assertTrue("Cron no ejecutado Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0);
		
	}

	//@Test
	public void registroConSolicitudCorrelativoFalsoPositivoCorregidoTest() {
		log.info("registroConSolicitudCorrelativoConBloqueoCorregido");
		SwfMensaje swfMensaje = registroSolicitud();
		SwiftDatos swiftDatos = swfMensajeDao.actualizarConPlano(swfMensaje.getMenPlano(), swfMensaje.getMenCodapp(), swfMensaje.getMenCodmen(),
				swfMensaje.getMenNrocorr(), swfMensaje.getMenRefer(), swfMensaje.getMenAuditusr(), "estacion", null, null);
		SwfMensaje swfMensajeNew = swiftDatos.getSwfMensaje();
		swfMensajeNew = swfMensajeDao.cambiarEstadoPostScan(swfMensajeNew.getMenCodmen(), 1, Constants.PARAM_ACCIONSCAN_BLQ);
		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0);

		swfMensajeNew = swfMensajeDao.cambiarEstadoVerificacion(swfMensajeNew.getMenCodmen(), swfMensaje.getMenAuditusr(),
				Constants.TAB_ESTVERIFICA_FALSO_POSITIVO, "estacion");
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_FALSO_POSITIVO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO) == 0);

		// String codigo =
		// String.valueOf(System.currentTimeMillis()).substring(8);
		// swfMensaje.setMenPlano(swfMensaje.getMenPlano().replace("6180/260816/HVR",
		// codigo + "/260816/HVR"));

		swiftDatos = swfMensajeDao.actualizarConPlano(swfMensaje.getMenPlano(), swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenCodmen(),
				swfMensajeNew.getMenNrocorr(), swfMensajeNew.getMenRefer(), swfMensaje.getMenAuditusr(), "estacion", null, null);

		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertTrue("swfMensaje nulo", !swfMensajeNew.getMenPlano().isEmpty());
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR) == 0);
//		Assert.assertTrue("Se esperaba que hash sea identico ",
//				swfMensajeNew.getMenHash().equalsIgnoreCase(ArchivoUtil.hashString(ArchivoUtil.decodeFromUri(swfMensaje.getMenPlano()))));
		Assert.assertTrue("Estado mensaje se esperaba " + Constants.TAB_ESTMENSAJE_REGISTRADO,
				swfMensajeNew.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_REGISTRADO) == 0);

		swiftDatos = swfMensajeDao.preAutorizaSwift(swfMensajeNew.getMenCodmen(), swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				swfMensaje.getMenRefer(), swfMensaje.getMenRefer(), swfMensaje.getMenPlano(), "estacion", null);
		swfMensajeNew = swiftDatos.getSwfMensaje();
		
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR) == 0);
		Assert.assertTrue("Estado mensaje se esperaba " + Constants.TAB_ESTMENSAJE_EN_PROCESO,
				swfMensajeNew.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_EN_PROCESO) == 0);
		
		Integer procesados = swfMensajeDao.cerrarTransaccion(swfMensaje.getMenRefer());
		Assert.assertTrue("procesados esperados invalido", procesados.compareTo(1) == 0);		
	}

	//@Test
	public void registroConSolicitudCorrelativoReenvioTest() {
		log.info("registroConSolicitudCorrelativoReenvio");
		SwfMensaje swfMensaje = registroSolicitud();
		SwiftDatos swiftDatos = swfMensajeDao.actualizarConPlano(swfMensaje.getMenPlano(), swfMensaje.getMenCodapp(), swfMensaje.getMenCodmen(),
				swfMensaje.getMenNrocorr(), swfMensaje.getMenRefer(), swfMensaje.getMenAuditusr(), "estacion", null, null);
		SwfMensaje swfMensajeNew = swiftDatos.getSwfMensaje();
		swfMensajeNew = swfMensajeDao.cambiarEstadoPostScan(swfMensajeNew.getMenCodmen(), 0, Constants.PARAM_ACCIONSCAN_BLQ);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_VERIFICADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0);

		swiftDatos = swfMensajeDao.actualizarConPlano(swfMensaje.getMenPlano(), swfMensaje.getMenCodapp(), swfMensaje.getMenCodmen(),
				swfMensaje.getMenNrocorr(), swfMensaje.getMenRefer(), swfMensaje.getMenAuditusr(), "estacion", null, null);
		swfMensajeNew = swiftDatos.getSwfMensaje();
//		Assert.assertTrue("Se esperaba que hash sea identico ",
//				swfMensajeNew.getMenHash().equalsIgnoreCase(ArchivoUtil.hashString(ArchivoUtil.decodeFromUri(swfMensaje.getMenPlano()))));
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_VERIFICADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0);

	}

	// ------------------------------------------- //

	//@Test
	public void scanSwiftSolicitadoTest() throws Exception {
		log.info("Happy day: scanSwiftSolicitadoTest");
		SwfMensaje swfMensaje = generarMensaje();
		SearchResponse searchResponse = scanSwiftMessage.getSessionLavado(swfMensaje.getMenCodapp(), 
				swfMensaje.getMenAuditusr());
		String idsesseion = searchResponse.getCodoperacion();
		searchResponse = scanSwiftMessage.solicitarCorrelativo(swfMensaje.getMenCodapp(), swfMensaje.getMenRefer(),
				swfMensaje.getMenAuditusr(), idsesseion);

		SwfMensaje swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		log.info("swfMensajeNew.getMenEstverifica() " + swfMensajeNew.getMenEstverifica());
		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertNull("swfMensaje debe ser nulo", swfMensajeNew.getMenPlano());
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR) == 0);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_REGISTRADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0);

		searchResponse = scanSwiftMessage.scanSwiftRegistro(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenCodmen(),
				swfMensajeNew.getMenNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, swfMensaje.getMenPlano());

		Assert.assertTrue("Codigo de respusta scan incorrecto " + searchResponse.getCodResp(), searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
		Assert.assertTrue("Registros encontrados invalido " + searchResponse.getCountRegs(), searchResponse.getCountRegs().compareTo(0) == 0);

		swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		Assert.assertNotNull("swfMensaje preautorizado nulo", swfMensajeNew);
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR) == 0);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_VERIFICADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0);
		Assert.assertTrue("Codigo swfmensaje diferente el enviado " + Integer.valueOf(searchResponse.getCodoperacion()),
				swfMensajeNew.getMenCodmen().compareTo(Integer.valueOf(searchResponse.getCodoperacion())) == 0);

		SwiftDatos swiftDatos = swfMensajeDao.preAutorizaSwift(swfMensajeNew.getMenCodmen(), swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				swfMensaje.getMenRefer(), idsesseion, swfMensaje.getMenPlano(), "estacion", null);

		swfMensajeNew = swiftDatos.getSwfMensaje();
		
		Assert.assertNotNull("swfMensaje preautorizado nulo", swfMensajeNew);
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR) == 0);
		Assert.assertTrue("Estado mensaje se esperaba " + Constants.TAB_ESTMENSAJE_EN_PROCESO,
				swfMensajeNew.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_EN_PROCESO) == 0);
		
		Integer procesados = swfMensajeDao.cerrarTransaccion(idsesseion);
		Assert.assertTrue("procesados esperados invalido", procesados.compareTo(1) == 0);		
	}

	//@Test
	public void scanRegistraMsgPlanoTest() throws Exception {
		log.info("Happy day: scanRegistraMsgPlanoTest");

		SwfMensaje swfMensajeSol = generarMensaje();
		SearchResponse searchResponse = scanSwiftMessage.getSessionLavado(swfMensajeSol.getMenCodapp(), 
				swfMensajeSol.getMenAuditusr());		
		String idsesseion = searchResponse.getCodoperacion();		
		searchResponse = scanSwiftMessage.solicitarCorrelativo(swfMensajeSol.getMenCodapp(), swfMensajeSol.getMenRefer(),
				swfMensajeSol.getMenAuditusr(), idsesseion);

		SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		searchResponse = scanSwiftMessage.scanSwiftRegistro(swfMensaje.getMenCodapp(), swfMensaje.getMenAuditusr(), swfMensaje.getMenCodmen(),
				swfMensaje.getMenNrocorr(), swfMensaje.getMenRefer(), idsesseion, swfMensajeSol.getMenPlano());

		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertNotNull("Nrocorr nulo", searchResponse.getNrocorr());
		Assert.assertTrue("registros se esperaba mayor a 0 ", searchResponse.getNrocorr() > 0);

		SwfMensaje swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew.getMenPlano());
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR) == 0);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_VERIFICADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0);

		searchResponse = scanSwiftMessage.preautorizarSwift(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, swfMensajeSol.getMenPlano());

		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertNotNull("Nrocorr nulo", searchResponse.getNrocorr());
		Assert.assertTrue("registros se esperaba mayor a 0 ", searchResponse.getNrocorr() > 0);

		swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR) == 0);
	}

	// -------------------TEST LAAAAAAAUUUUUUUU------------------------ //

	//@Test
	public void scanSwiftSolicitadoConProcesoLAUTest() throws Exception {
		log.info("===========Happy day: scanSwiftSolicitadoConProcesoLAUTest==============");
		gob.bcb.lavado.client.ClienteLvd clienteLvd = ClienteLvd.init(url, appProperties.getLavado().getAppdir(),"SIOC");
		
		SwfMensaje swfMensaje = generarMensaje();
		swfMensaje.setMenCodapp("SIOC");
		SearchResponse searchResponse = clienteLvd.getIniSessionLavado(swfMensaje.getMenCodapp(), 
				swfMensaje.getMenAuditusr());
		String idsesseion = searchResponse.getCodoperacion();
		searchResponse = clienteLvd.solicitarCorrelativo(swfMensaje.getMenCodapp(), swfMensaje.getMenRefer(),
				swfMensaje.getMenAuditusr(), idsesseion);

		SwfMensaje swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		log.info("swfMensajeNew.getMenEstverifica() " + swfMensajeNew.getMenEstverifica());
		Assert.assertNotNull("swfMensaje nulo", swfMensajeNew);
		Assert.assertNull("swfMensaje debe ser nulo", swfMensajeNew.getMenPlano());
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR) == 0);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_REGISTRADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0);

		String menPlanoEnviar = swfMensaje.getMenPlano();
		searchResponse = clienteLvd.scanSwiftRegistro(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenCodmen(),
				swfMensajeNew.getMenNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, menPlanoEnviar);

		Assert.assertTrue("Codigo de respusta scan incorrecto " + searchResponse.getCodResp(), searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
		Assert.assertTrue("Registros encontrados invalido " + searchResponse.getCountRegs(), searchResponse.getCountRegs().compareTo(0) == 0);

		swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		Assert.assertNotNull("swfMensaje preautorizado nulo", swfMensajeNew);
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR) == 0);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_VERIFICADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0);
		Assert.assertTrue("Codigo swfmensaje diferente el enviado " + Integer.valueOf(searchResponse.getCodoperacion()),
				swfMensajeNew.getMenCodmen().compareTo(Integer.valueOf(searchResponse.getCodoperacion())) == 0);

		searchResponse = clienteLvd.preautorizarSwift(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, menPlanoEnviar);
		
		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertNotNull("Nrocorr nulo", searchResponse.getNrocorr());
		Assert.assertTrue("registros se esperaba mayor a 0 ", searchResponse.getNrocorr() > 0);

		swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0);

		
		Integer procesados = swfMensajeDao.cerrarTransaccion(idsesseion);
		Assert.assertTrue("procesados esperados invalido", procesados.compareTo(1) == 0);	
		log.info("===========FIN: scanSwiftSolicitadoConProcesoLAUTest==============");		
	}
	
//	@Test
	public void registroClienteSinLauServConLau() throws Exception {
		log.info("===========Happy day: registroClienteSinLauServConLau==============");
		long testTimeLocl = System.currentTimeMillis();		
		gob.bcb.lavado.client.ClienteLvd clienteLvd = ClienteLvd.init(url, appProperties.getLavado().getAppdir(),"SIOC");
		String codeKeyFP2 = "Abcd1234abcd1235";
		String codeKeySP2 = "Abcd1234abcd1235";		
		HandlerGeneratorLauSrv.getGeneratorLAU().updateCodeLau(codeKeyFP2 , codeKeySP2, 90, new Date(),"SIOC, AICOS", "codUsuario", "estacion", false);

		log.info("===========fin HandlerGeneratorLauSrv.updateCodeLau==============");
		
		SwfMensaje swfMensaje = generarMensaje();
		swfMensaje.setMenCodapp("SIOC");
		SearchResponse searchResponse = clienteLvd.getIniSessionLavado(swfMensaje.getMenCodapp(), 
				swfMensaje.getMenAuditusr());
		String idsesseion = searchResponse.getCodoperacion();
		searchResponse = clienteLvd.solicitarCorrelativo(swfMensaje.getMenCodapp(), swfMensaje.getMenRefer(),
				swfMensaje.getMenAuditusr(), idsesseion);

		SwfMensaje swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		log.info("swfMensajeNew.getMenEstverifica() " + swfMensajeNew.getMenEstverifica());

		String menPlanoEnviar = swfMensaje.getMenPlano();
		searchResponse = clienteLvd.scanSwiftRegistro(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenCodmen(),
				swfMensajeNew.getMenNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, menPlanoEnviar);

		Assert.assertTrue("Codigo de respusta scan incorrecto " + searchResponse.getCodResp(), searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));

		swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR) == 0);
		Assert.assertTrue("Estado verificacion se esperaba " + Constants.TAB_ESTVERIFICA_VERIFICADO,
				swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0);

		searchResponse = clienteLvd.preautorizarSwift(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, menPlanoEnviar);
		
		Assert.assertTrue("registros se esperaba mayor a 0 ", searchResponse.getNrocorr() > 0);

		swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));
		Assert.assertTrue("Estado autorizacion se esperaba " + Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT,
				swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0);

		
		Integer procesados = swfMensajeDao.cerrarTransaccion(idsesseion);
		Assert.assertTrue("procesados esperados invalido", procesados.compareTo(1) == 0);	
		log.info("===========FIN: scanSwiftSolicitadoConProcesoLAUTest==============[" + (System.currentTimeMillis() - testTimeLocl) + "] ms");		
	}	
	
	public SwfMensaje registroSolicitud() {
		log.info("registroSolicitud");
		String codapp = "CODAPP";
		String coduser = "1622";
		String idoperacion = String.valueOf(System.currentTimeMillis());
		String menPlano = UtilsFile.readFileAsString2("src/test/resources/swifts/swf_sinobservacion2.dos");
		menPlano = menPlano.replace("1392930010", idoperacion);

		// solicitud del correlativo
		SwfMensaje swfMensaje = swfMensajeDao.solicitarCorrelativo(codapp, coduser, idoperacion, "estacion", idoperacion);
		Assert.assertNotNull("swfMensaje nulo", swfMensaje);
		Assert.assertTrue("correlativo debe ser mayor a 0", swfMensaje.getMenNrocorr() > 0);
		Assert.assertTrue("Estado autorizacion se esperaba 6 ",
				swfMensaje.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR) == 0);

		Integer gestion = UtilsDate.gestionActual();
		Optional<SwfNumeraswf> swfNumeraswf = swfNumeraswfDao.maxNroSwift(gestion);
		Assert.assertTrue("REgistro nulo", swfNumeraswf.isPresent());
		Assert.assertTrue("No existe objeto Correlativo ", swfNumeraswf.get().getNroNroswift().compareTo(swfMensaje.getMenNrocorr()) == 0);
		swfMensaje.setMenPlano(menPlano);
		return swfMensaje;
	}

	public SearchResponse registroSolicitudRest() throws Exception {
		log.info("registroSolicitud");
		// solicitud del correlativo
		SwfMensaje swfMensaje = generarMensaje();
		SearchResponse searchResponse = scanSwiftMessage.solicitarCorrelativo(swfMensaje.getMenCodapp(), swfMensaje.getMenRefer(),
				swfMensaje.getMenAuditusr(), swfMensaje.getMenRefer());
		return searchResponse;
	}

	public SwfMensaje generarMensaje() {
		log.info("generarMensaje"); 
		String codapp = "TEST";
		String coduser = "1622";
		String idoperacion = String.valueOf(System.currentTimeMillis());
		String menPlano = UtilsFile.readFileAsString2("src/test/resources/swifts/swf_sinobservacion2lau.dos");
		menPlano = menPlano.replace("1392930010", idoperacion);

		// solicitud del correlativo
		SwfMensaje swfMensaje = new SwfMensaje();
		swfMensaje.setMenCodapp(codapp);
		swfMensaje.setMenAuditusr(coduser);
		swfMensaje.setMenCodusrswf("usertest");
		swfMensaje.setMenRefer(idoperacion);
		swfMensaje.setMenPlano(menPlano);
		return swfMensaje;
	}
	
}
