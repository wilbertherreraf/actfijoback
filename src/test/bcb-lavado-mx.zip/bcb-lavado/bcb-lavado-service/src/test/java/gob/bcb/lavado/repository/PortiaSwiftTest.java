package gob.bcb.lavado.repository;

import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.axesso.services.JndiDatasourceCreator;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.QL.contbcb.CoinQLBean;
import gob.bcb.lavado.QL.portiaswift.LoaderQLBeanLocal;
import gob.bcb.lavado.QL.portiaswift.entities.Loader;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.ConfigBaseTest;

public class PortiaSwiftTest  extends ConfigBaseTest {
	private static final Logger log = LoggerFactory.getLogger(PortiaSwiftTest.class);
	@Autowired
	private LoaderQLBeanLocal loaderQLBeanLocal;
	
	@Autowired
	private CoinQLBean coinQLBean;
	
	@Test
	public void nuevoCodSwiftTest(){
		log.info("nuevoCodSwiftTest .....");
		Loader loader = loaderQLBeanLocal.nuevoCodSwift("TEST", "iptest", "usertest");
		log.info("loader nuevo ");
		Assert.assertNotNull("Loader nulo", loader);
		
		String aniocurrent =  UtilsDate.stringFromDate(new Date(), "yyyy");
		Date fecha = UtilsDate.dateFromString("01/01/" + aniocurrent, "dd/MM/yyyy");
		Assert.assertFalse("Fecha " + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy")  + " no registrado en contbcb", coinQLBean.isHabil(fecha));		
	}
}
