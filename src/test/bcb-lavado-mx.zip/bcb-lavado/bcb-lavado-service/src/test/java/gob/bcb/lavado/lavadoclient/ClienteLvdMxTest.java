package gob.bcb.lavado.lavadoclient;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.client.ClienteLvd;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.services.SessionsSearcherService;

public class ClienteLvdMxTest {
	protected final static Logger log = LoggerFactory.getLogger(ClienteLvdMxTest.class);
	private String url = "http://10.3.11.82:8881/lavado/";
	ClienteLvd clienteLvd;
	@Autowired
	private SessionsSearcherService sessionsSearcherService;

//	@Test
	public void happyDayCompletCycleTest() throws Exception {
		for (int i = 1; i < 2; i++) {
			log.info("=== registroNoObservadoConCorrelativoSolicitadoTest " + url);
			clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", "SIOCWEB");
			String archSwift = "src/test/resources/mxmapp/103ff.txt"; // src/test/resources/swifts/swf_sinobservacion.dos
			String menPlano = UtilsFile.readFileAsString2(archSwift);

			SearchResponse searchResponse = clienteLvd.getIniSessionLavado("SIOCWEB", "usertest");
			String idsession = searchResponse.getCodoperacion();
			log.info("SESSION LAVADO " + idsession);
			String codigo = String.valueOf(System.currentTimeMillis()).substring(8);

			searchResponse = clienteLvd.solicitarCorrelativo("SIOCWEB", codigo, "usertest", idsession);
			Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
			Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
			Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

			Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
			log.info("ANTES DE SCAM " + idsession + " Operacion " + menCodmen);
			searchResponse = clienteLvd.scanSwiftRegistro("SIOCWEB", "usertest", Integer.valueOf(searchResponse.getCodoperacion()),
					searchResponse.getNrocorr(), codigo, idsession, menPlano);

			Assert.assertNotNull("searchResponse nulo", searchResponse);
			Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
			Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(menCodmen) == 0);
			Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

			log.info("ANTES DE PREAUTO " + idsession);
			searchResponse = clienteLvd.preautorizarSwift("SIOCWEB", "usertest", Integer.valueOf(searchResponse.getCodoperacion()),
					searchResponse.getNrocorr(), codigo, idsession, menPlano);

			searchResponse = clienteLvd.postSessionLavado("SIOCWEB", "usertest", idsession);
			Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
			Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));

		}
	}

	@Test
	public void testConcurrentTest2() throws Exception {
		log.info("!!!!!!!!!!!!!!!!!! [ INICIO CONCURRENCIA ] !!!!!!!!!!!!!!!!!!");
		AtomicInteger ai = new AtomicInteger();
		ai.set(0);
		Stream<CompletableFuture<Integer>> futureWrite = UtilsFile.filesDir("src/test/resources/concu").stream().map(f -> {
			return CompletableFuture.supplyAsync(() -> {
				try {
					String nFile = f.getName();
					int item = ai.addAndGet(1);
					log.info("=== " + nFile + " =============");
					
					String idApp = "SIOCWEB" + item;
					ClienteLvd clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", idApp);
					String archSwift = f.getAbsolutePath();
					String menPlano = UtilsFile.readFileAsString2(archSwift);
					String idoperacion = String.valueOf(System.nanoTime());
					menPlano = menPlano.replace("04054727", idoperacion);

					SearchResponse searchResponse = clienteLvd.getIniSessionLavado(idApp, "usertest");
					String idsession = searchResponse.getCodoperacion();

					String codigo = String.valueOf(System.currentTimeMillis()).substring(8) + item;
					log.info(codigo + " -> SESSION LAVADO " + idsession);
					searchResponse = clienteLvd.solicitarCorrelativo(idApp, codigo, "usertest", idsession);
	
					Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
					Integer nrocorr = searchResponse.getNrocorr();
					searchResponse = clienteLvd.postSessionLavado(idApp, "usertest", idsession);

					log.info("**********      {" + item +"}            ********************** " + menCodmen + " " + nrocorr, item);
					searchResponse = clienteLvd.getIniSessionLavado(idApp, "usertest");
					idsession = searchResponse.getCodoperacion();

					log.info("**********1111111111111111{" + item +"}111111111111********************** " + menCodmen + " Nrocorr: " + nrocorr + " idsession: "
							+ idsession);

					searchResponse = clienteLvd.scanSwiftRegistro(idApp, "usertest", menCodmen, nrocorr, codigo, idsession, menPlano);

					searchResponse = clienteLvd.postSessionLavado(idApp, "usertest", idsession);
					log.info("**********222222222222222{" + item +"}22222222222222**********************");
					searchResponse = clienteLvd.getIniSessionLavado(idApp, "usertest");
					idsession = searchResponse.getCodoperacion();

						searchResponse = clienteLvd.preautorizarSwift(idApp, "usertest", menCodmen, nrocorr, codigo, idsession, menPlano);

					searchResponse = clienteLvd.postSessionLavado(idApp, "usertest", idsession);
					log.info("FFFFFin {" + item +"} FFFFFFIN");
					return item;
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			});
		});

		List<CompletableFuture<Integer>> priceFutures = futureWrite.collect(Collectors.<CompletableFuture<Integer>>toList());

		log.info("-------------IIIIIIIIII------------------- ");
		priceFutures.stream().map(CompletableFuture::join).count();// collect(Collectors.toList());
	}
}
