package gob.bcb.lavado.client;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.client.utils.UtilsFile;

public class ClienteLvdTest { // extends ConfigBaseTest {
	protected final static Logger log = LoggerFactory.getLogger(ClienteLvdTest.class);
	private String url = "http://10.3.11.82:8881/lavado/";
	ClienteLvd clienteLvd;

	@Before
	// @Override
	public void before() throws Throwable {
		// super.before();
		// initDataInicialBaseSearch();
		// url = base.toString();
		clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", "SIOC").getInstance();
	}

	// @Test
	public void registroNoObservadoConCorrelativoSolicitadoTest() throws Exception {
		for (int i = 1; i < 10; i++) {
			log.info("=== registroNoObservadoConCorrelativoSolicitadoTest " + url);
			clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", "SIOC").getInstance();
			String archSwift = "src/test/resources/swifts/swf_sinobservacion.dos";
			String menPlano = UtilsFile.readFileAsString2(archSwift);

			SearchResponse searchResponse = clienteLvd.getSessionLavado("TEST", "usertest");
			String idsession = searchResponse.getCodoperacion();
			log.info("SESSION LAVADO " + idsession);
			String codigo = String.valueOf(System.currentTimeMillis()).substring(8);

			searchResponse = clienteLvd.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
			Assert.assertNotNull("searchResponse nulo", searchResponse);
			Assert.assertTrue("Cod swift debe diferente de nulo", (searchResponse.getCodoperacion() != null && !searchResponse.getCodoperacion().isEmpty()));
			Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
			Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

			Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());

			searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession,
					menPlano);

			Assert.assertNotNull("searchResponse nulo", searchResponse);
			Assert.assertTrue("Cod swift debe diferente de nulo", (searchResponse.getCodoperacion() != null && !searchResponse.getCodoperacion().isEmpty()));
			Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(menCodmen) == 0);
			Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

			searchResponse = clienteLvd.preautorizarSwift("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession,
					menPlano);

			searchResponse = clienteLvd.postSessionLavado("TEST", "usertest", idsession);
			Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
			Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));

		}
	}

	// @Test
	public void registroConCorrelativoSolicitadoTest() throws Exception {
		log.info("=== registroConCorrelativoSolicitadoTest " + url);
		String archSwift = "src/test/resources/swifts/swf_4632_ent.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		SearchResponse searchResponse = clienteLvd.getSessionLavado("TEST", "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);
		String codigo = String.valueOf(System.currentTimeMillis()).substring(8);

		searchResponse = clienteLvd.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertTrue("Cod swift debe diferente de nulo", (searchResponse.getCodoperacion() != null && !searchResponse.getCodoperacion().isEmpty()));
		Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
		Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

		Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());

		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession,
				menPlano);

		Assert.assertNotNull("searchResponse nulo", searchResponse);
		Assert.assertTrue("Cod swift debe diferente de nulo", (searchResponse.getCodoperacion() != null && !searchResponse.getCodoperacion().isEmpty()));
		Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(menCodmen) == 0);
		Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

		searchResponse = clienteLvd.postSessionLavado("TEST", "usertest", idsession);
		Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));

	}

	// @Test
	public void registroConBloqueoYReenvioCorrelativoSolicitadoTest() throws Exception {
		log.info("=== registroConBloqueoYReenvioCorrelativoSolicitadoTest " + url);

		String archSwift = "src/test/resources/swifts/swf_9645_indiv_alias.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		SearchResponse searchResponse = clienteLvd.getSessionLavado("TEST", "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);

		String codigo = String.valueOf(System.currentTimeMillis()).substring(8);
		searchResponse = clienteLvd.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
		Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
		Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

		log.info("===================INI===========================");
		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession,
				menPlano);
		log.info("" + searchResponse.getCountRegs() + " " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
		log.info("===================FIN===========================");
		Assert.assertTrue("Registros debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_01));

		// reenvio de la operacion
		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession,
				menPlano);
		Assert.assertTrue("Registros debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_02));

		searchResponse = clienteLvd.postSessionLavado("TEST", "usertest", idsession);
		Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
	}

	// @Test
	public void registroSinBloqueoReenvioSinModificacionTest() throws Exception {
		log.info("=== registroSinBloqueoReenvioSinModificacionTest " + url);

		String archSwift = "src/test/resources/swifts/sir2016000011.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		SearchResponse searchResponse = clienteLvd.getSessionLavado("TEST", "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);

		String codigo = String.valueOf(System.currentTimeMillis()).substring(8);
		searchResponse = clienteLvd.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));

		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession,
				menPlano);

		Assert.assertTrue("Registros debe ser 0", searchResponse.getCountRegs().compareTo(0) == 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
		log.info("================== REENVIO ========================= ");
		// reenvio de la operacion
		searchResponse = clienteLvd.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession,
				menPlano);
		Assert.assertTrue("Registros invalido", searchResponse.getCountRegs().compareTo(0) == 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
		searchResponse = clienteLvd.postSessionLavado("TEST", "usertest", idsession);
		Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
	}

	// @Test
	public void getSessionLavadoClienteSinLauServSinLau() throws Exception {
		log.info("=== getSessionLavadoClienteSinLauServSinLau " + url);
		clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", "SIOC");
		String archSwift = "src/test/resources/swifts/swf_sinobservacion.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		SearchResponse searchResponse = clienteLvd.getIniSessionLavado("SIOC", "usertest");
		log.info("SESSION LAVADO[{}]: {} {}", searchResponse.getCodoperacion(), searchResponse.getCodResp(), searchResponse.getDescripResp());

	}

	@Test
	public void registroNoObservadoClienteSinLauServConlau() throws Exception {
		log.info("===== registroNoObservadoClienteSinLauServConlau =====");
		String codCliente= "SIOC";
		clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", codCliente);
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().reinitGeneratorLAU();
		
		String archSwift = "src/test/resources/swifts/swf_sinobservacion.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		SearchResponse searchResponse = clienteLvd.getIniSessionLavado(codCliente, "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);
		String codigo = String.valueOf(System.currentTimeMillis()).substring(8);

		searchResponse = clienteLvd.solicitarCorrelativo(codCliente, codigo, "usertest", idsession);
		Assert.assertTrue("Cod swift debe diferente de nulo", (searchResponse.getCodoperacion() != null && !searchResponse.getCodoperacion().isEmpty()));
		Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
		Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

		Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());

		searchResponse = clienteLvd.scanSwiftRegistro(codCliente, "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession,
				menPlano);

		Assert.assertTrue("Cod swift debe diferente de nulo", (searchResponse.getCodoperacion() != null && !searchResponse.getCodoperacion().isEmpty()));
		Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(menCodmen) == 0);
		Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

		searchResponse = clienteLvd.preautorizarSwift(codCliente, "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession,
				menPlano);

		searchResponse = clienteLvd.postSessionLavado(codCliente, "usertest", idsession);
		Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
		Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));
		log.info("===== FIN registroNoObservadoClienteSinLauServConlau =====");
		System.out.println("fin");
	}

}
