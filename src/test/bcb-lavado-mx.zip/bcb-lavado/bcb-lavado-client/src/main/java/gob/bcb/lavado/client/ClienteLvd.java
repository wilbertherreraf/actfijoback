package gob.bcb.lavado.client;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gob.bcb.lavado.client.pojos.SearchResponse;

public class ClienteLvd {
	private final static Logger log = LoggerFactory.getLogger(ClienteLvd.class);

	public final static String SCAN_SWIFT_GET_INISESSION = Constants.PATH_RESOURCE_API_SEARCH
			+ "/lvd-inisesion?codapp={codapp}&coduser={coduser}&tenc={tenc}&ctrlcode={ctrlcode}&ctrldata={ctrldata}";
	public final static String SCAN_SWIFT_GET_SESSION = Constants.PATH_RESOURCE_API_SEARCH
			+ "/lvd-inicia?codapp={codapp}&coduser={coduser}";	
	public final static String SCAN_SWIFT_SOLICITARCORR_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH
			+ "/scan-correlativo?codapp={codapp}&idop={idop}&coduser={coduser}&idsession={idsession}";
	
	public final static String SCAN_SWIFT_SCANREGISTROLAU_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH
			+ "/scan-registro?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}&clau={clau}";	
	public final static String SCAN_SWIFT_SCANREGISTRO_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH
			+ "/scan-registro?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}";
	
	public final static String SCAN_SWIFT_PREAUTLAU_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH
			+ "/scan-preaut?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}&clau={clau}";	
	public final static String SCAN_SWIFT_PREAUT_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH
			+ "/scan-preaut?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}";
	
	public final static String SCAN_SWIFT_END_SESSION = Constants.PATH_RESOURCE_API_SEARCH + "/lvd-fin?codapp={codapp}&coduser={coduser}&idsession={idsession}";

	public final static String SCAN_SWIFT_SINGLE_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH + "/scan-single?query={query}";
	public final static String SCAN_SWIFT_BY_CODSTRATEGY = Constants.PATH_RESOURCE_API_SEARCH + "/scan-field?query={query}&field={field}";

	private String protocol;
	private String host;
	private String nameContextSite;
	private int port;
	private static final Charset UTF_8 = StandardCharsets.UTF_8;
	private static final Charset ISO_8859_1 = StandardCharsets.ISO_8859_1;
	protected static ObjectMapper mapper = new ObjectMapper();
	private RestTemplate template;
	private static ClienteLvd instanceCli = null;
	
	static {
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		log.info("Mapper Json inicializado...");
	}
	
	private static class ClienteLvdHolder{
		public static final ClienteLvd instance = new ClienteLvd();
	}
	
	private ClienteLvd() {
		log.info("Creando instancia  cliente lavado.....");
	}
	
	public static ClienteLvd getInstance() {
		if (instanceCli == null) {
			throw new RuntimeException("Cliente Lavado no inicializado...");
		}
		return ClienteLvdHolder.instance;
	}
	
	public static ClienteLvd init(String url, String pathBase, String idGenerator) {
		if (instanceCli == null) {
			instanceCli = ClienteLvdHolder.instance;
			try {
				HandlerGeneratorLauCli.initCurrentInstance(pathBase, idGenerator);
				URI uri = new URI(url);
				instanceCli.protocol = uri.getScheme();
				instanceCli.host = uri.getHost();
				instanceCli.port = uri.getPort();
				instanceCli.nameContextSite = uri.getPath();
//				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				instanceCli.template = new RestTemplate();
				log.info("inicializado cliente lavado....." + instanceCli.nameContextSite);
			} catch (Exception e) {
				log.error("Error al desparcear URL " + e.getMessage(), e);
			}			
		} 
		
		Boolean existsLau = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().existsLau();

		if (!existsLau ) {
			log.error("Cliente LAU no inicializado...!!!!");
		}

		return ClienteLvdHolder.instance;
	}	

//	public ClienteLvd(String url, String pathBase, String idGenerator) {
//		try {
//			HandlerGeneratorLauCli.initCurrentInstance(pathBase, idGenerator);
//
//			URI uri = new URI(url);
//			this.protocol = uri.getScheme();
//			this.host = uri.getHost();
//			this.port = uri.getPort();
//			this.nameContextSite = uri.getPath();
////			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//			template = new RestTemplate();
//		} catch (Exception e) {
//			log.error("Error al desparcear URL " + e.getMessage(), e);
//		}
//	}

	/**
	 * Solicita sesión en el servidor de lavado, envia el lau de codapp y
	 * coduser
	 * 
	 * @param codapp
	 * @param coduser
	 * @return
	 * @throws Exception
	 */
	public SearchResponse getIniSessionLavado(String codapp, String coduser) throws Exception {
		log.info("======@ getIniSessionLavado @====== ");

		String url = getUrlResouce(SCAN_SWIFT_GET_INISESSION);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);

		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		log.info(searchResponse.toPrint());

		boolean requireSend = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().processResponse(searchResponse);

		if (requireSend) {
			log.info("Reenviando mensaje por razon de respuesta lau");
			params = new HashMap<String, String>();
			params.put("codapp", codapp);
			params.put("coduser", coduser);

			HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);

			searchResponses = template.getForEntity(url, String.class, params).getBody();
			searchResponse = deserialize(searchResponses);

			log.info("respuesta de reenvio: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(), searchResponse.getCodResplau(),
					searchResponse.getDescripResp());
		}

		return searchResponse;
	}

	public SearchResponse getSessionLavado(String codapp, String coduser) throws Exception {
		log.info("======@ getSessionLavado @====== ");

		String url = getUrlResouce(SCAN_SWIFT_GET_SESSION);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		log.info("idresponse: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(), searchResponse.getCodResplau(), searchResponse.getDescripResp());
		return searchResponse;
	}
	
	public SearchResponse solicitarCorrelativo(String codapp, String codoperacion, String coduser, String idsession) throws Exception {
		log.info("======@ solicitarCorrelativo @======");
		String url = getUrlResouce(SCAN_SWIFT_SOLICITARCORR_RESOURCE);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("idop", codoperacion);
		params.put("coduser", coduser);
		params.put("idsession", idsession);

		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		
		log.info(searchResponse.toPrint() + " CORRELATIVO: [Oper: " +codoperacion+" : " + searchResponse.getNrocorr() + "]");
		
		return searchResponse;
	}

	public SearchResponse scanSwiftRegistro(String codapp, String coduser, Integer codlvd, Integer nroswf, String idoperacion, String idsession, String menPlano)
			throws Exception {
		log.info("======@ scanSwiftRegistro @======");
		Map<String, String> params = new HashMap<String, String>();
		String url = getUrlResouce(SCAN_SWIFT_SCANREGISTRO_RESOURCE);
		log.info("Consultando... " + url);
		menPlano = convertToUtf8(menPlano, "ISO-8859-1");
		
		String codelau = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateTokenForMsg(menPlano);
		if (!StringUtils.isBlank(codelau)){
			log.info("->Envio de mensaje con LAU {}", codelau);
			url = getUrlResouce(SCAN_SWIFT_SCANREGISTROLAU_RESOURCE);
			params.put("clau", codelau);
		} else {
			log.warn("Cliente LVD no implementa LAU");
		}
		String menEnc = encodeString(menPlano);
		
		log.info("-----( salida ) -----");
		log.info(menEnc);
		params.put("codapp", codapp);
		params.put("coduser", coduser);
		params.put("codlvd", String.valueOf(codlvd));
		params.put("nroswf", String.valueOf(nroswf));
		params.put("idop", idoperacion);
		params.put("idsession", idsession);
		params.put("swfp", menEnc);

		log.info("Consultando scanSwiftRegistro ... " + url);
		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		log.info(searchResponse.toPrint());
		
		log.info("-----( respuesta ) -----");
		log.info(searchResponse.getMenPlano());
		
		return searchResponse;
	}

	public SearchResponse preautorizarSwift(String codapp, String coduser, Integer codlvd, Integer nroswf, String idoperacion, String idsession, String menPlano)
			throws Exception {
		Map<String, String> params = new HashMap<String, String>();		
		log.info("======@ preautorizarSwift @======");
		String url = getUrlResouce(SCAN_SWIFT_PREAUT_RESOURCE);
		log.info("Consultando... " + url);
		menPlano = convertToUtf8(menPlano, "ISO-8859-1");
		log.info(menPlano);
		
		String codelau = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateTokenForMsg(menPlano);
		if (!StringUtils.isBlank(codelau)){
			log.info("->Envio de mensaje con LAU {}", codelau);
			url = getUrlResouce(SCAN_SWIFT_PREAUTLAU_RESOURCE);
			params.put("clau", codelau);
		}
		
		String menEnc = encodeString(menPlano);
		log.info("Consultando... " + url);

		params.put("codapp", codapp);
		params.put("coduser", coduser);
		params.put("codlvd", String.valueOf(codlvd));
		params.put("nroswf", String.valueOf(nroswf));
		params.put("idop", idoperacion);
		params.put("idsession", idsession);
		params.put("swfp", menEnc);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		log.info(searchResponse.toPrint());
		return searchResponse;
	}

	public SearchResponse postSessionLavado(String codapp, String coduser, String idsession) throws Exception {
		log.info("======@ postSessionLavado @====== ");

		String url = getUrlResouce(SCAN_SWIFT_END_SESSION);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);
		params.put("idsession", idsession);

		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		log.info(searchResponse.toPrint());
		return searchResponse;
	}

	/**
	 * Consulta rest para un mensaje plano retornando cadena url:
	 * /api/_search/scan-single?query={query}
	 * 
	 * @param menPlano
	 *            mensaje swift en formato plano
	 * @return
	 * @throws Exception
	 */
	public SearchResponse scanMsgPlanoSingleFromString(String menPlano) throws Exception {
		log.info("======@ Scan Single Msg Plano @======");
		menPlano = convertToUtf8(menPlano, "ISO-8859-1");
		log.info(menPlano);
		
		String menEnc = encodeString(menPlano);
		String url = getUrlResouce(SCAN_SWIFT_SINGLE_RESOURCE);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("query", menEnc);
		template = new RestTemplate();
		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		log.info(searchResponse.toPrint());
		return searchResponse;
	}

	/**
	 * Consulta rest para una consulta y
	 * /api/_search/scan-field?query={query}&field={field}
	 * 
	 * @param query
	 *            texto a buscar
	 * @param field
	 *            id de la estrategia
	 * @return
	 * @throws Exception
	 */
	public SearchResponse searchQueryByFieldFromString(String query, String field) throws Exception {
		log.info("======@ Scan Field @======");
		log.info("Field: " + field + " " + query);
		String url = getUrlResouce(SCAN_SWIFT_BY_CODSTRATEGY);
		log.info("Consultando... " + url);

		template = new RestTemplate();

		Map<String, String> params = new HashMap<String, String>();
		params.put("query", query);
		params.put("field", field);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);
		log.info(searchResponse.toPrint());
		return searchResponse;
	}

	public static String convertToUtf8(String input, String encoding) {
//		CharsetDecoder decoder = UTF_8.newDecoder();
//		CharsetEncoder encoder = Charset.forName(encoding).newEncoder();
		ByteBuffer tmp;
		try {
			tmp = ISO_8859_1.encode(CharBuffer.wrap(input));
		} catch (Exception e) {
			return input;
		}

		try {
			return UTF_8.decode(tmp).toString();
		} catch (Exception e) {
			return input;
		}

	}

	public String getUrlResouce(String endpoint) throws MalformedURLException {
		log.debug("endpoint " + endpoint);
		String nContextSite = "";
		if (nameContextSite.startsWith("/")) {
			nContextSite = nameContextSite;
		} else {
			nContextSite = "/" + nameContextSite;
		}

		URL base = new URL(protocol, host, port, nContextSite);
		String url = fullUrl(base.toString(), endpoint);

		return url;
	}

	private String fullUrl(String baseUrl, String end) {
		String base = !baseUrl.endsWith("/") ? baseUrl + "/" : baseUrl;
		String newEnd = end.startsWith("/") ? end.substring(1) : end;
		return base + newEnd;
	}

	public static SearchResponse deserialize(String object) {
		try {
			return mapper.readValue(object, SearchResponse.class);
		} catch (IOException e) {
			throw new IllegalArgumentException("Unserializable " + object.getClass().getName() + " -> " + object.toString());
		}
	}

	public static String encodeString(String menPlano) {
		if (StringUtils.isBlank(menPlano)) {
			return "";
		}
		
		byte[] xmlEncBy = Base64.getUrlEncoder().encode(menPlano.getBytes());
		String menEnc = new String(xmlEncBy, UTF_8);
		return menEnc;
	}
}
