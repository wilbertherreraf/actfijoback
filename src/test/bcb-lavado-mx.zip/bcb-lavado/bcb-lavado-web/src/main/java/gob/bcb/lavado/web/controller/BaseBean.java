package gob.bcb.lavado.web.controller;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.model.GenDesctabla;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.services.ReporteSwiftService;
import gob.bcb.lavado.web.security.core.UserDetailsServiceImpl;

public abstract class BaseBean implements Serializable {
	private static final Logger log = LoggerFactory.getLogger(BaseBean.class);

	protected GenDesctabla genDesctablaSelected = new GenDesctabla();
	private String urlBack;
	@Autowired
	private VisitBean visitBean;
	@Autowired
	private AppProperties appProperties;
	@Autowired
	private ReporteSwiftService reporteSwiftService;
	protected UserDetailsServiceImpl userDetailsServiceImpl;
	protected MensajesDatos mensajesDatosSelected = new MensajesDatos();
	private StreamedContent fileDown;

	public void inicializar() {
		try {
			Map<String, String> sesiones = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
			log.info("==> inicializar Ingresando a " + this.getClass().getName() + " :: " + sesiones.get("action"));			
			if (getVisitBean() != null) {
				String act = sesiones.get("action");
				if (!StringUtils.isBlank(act) )
					visitBean.setParametro("VIEW_ACTION", act);
				
				String viewAction = (String) visitBean.getParametro("VIEW_ACTION");
				String viewid = (String) getVisitBean().getParametro("viewid");
				log.info("viewAction= " + viewAction + " viewid:: " + viewid);

				if (visitBean.getParametro("VIEW_ACTION") != null && visitBean.getParametro("urlBack") != null) {
					// si viene de otra pagina y tiene que retornar
					if (!StringUtils.isBlank((String) visitBean.getParametro("urlBack"))) {
						urlBack = (String) visitBean.getParametro("urlBack");
						log.info("urlBack = " + urlBack);
					}
				}
			}
		} catch (Throwable e) {
			log.error("Error al inicializar " + e.getMessage(), e);
		}
	}

	public void removeParmsRequest() {
		visitBean.removeParametro("urlBack");
		visitBean.removeParametro("SwiftadminBean");
	}

	public VisitBean getVisitBean() {
		return visitBean;
	}

	public void setVisitBean(VisitBean visitBean) {
		this.visitBean = visitBean;
	}

	public void recuperarParametros() {
		try {
			Map<String, String> sesiones = getFacesContext().getExternalContext().getRequestParameterMap();
			visitBean.getParametro().putAll(sesiones);
		} catch (Exception e) {
			throw new RuntimeException("Error al recuperar visit " + e.getMessage());
		}
	}

	public FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}

	public void redirect(String outcome, String viewAction) {
		String url = getFacesContext().getViewRoot().getViewId();
		outcome = UtilsGeneric.encodeURL(outcome, "faces-redirect", "true");

		getVisitBean().setParametro("VIEW_ACTION", viewAction);
		visitBean.setParametro("urlBack", url);
		visitBean.setParametro("viewid", getViewId());

		log.info("En redirect url = " + url + " viewAction " + viewAction + " outcome " + outcome);
		getFacesContext().getApplication().getNavigationHandler().handleNavigation(getFacesContext(), null, outcome);
	}

	public String redirectExt(String url, String outcome, String idresource, String viewAction, String viewAction2) {
		String urlGo = UtilsGeneric.encodeURL(url, "url", outcome);
		urlGo = UtilsGeneric.encodeURL(urlGo, "idrec", idresource);
		urlGo = UtilsGeneric.encodeURL(urlGo, "action", viewAction);
		return urlGo;
	}

	public void redirectBack(String viewAction) {
		String urlgoback = goBackUrl();
		getVisitBean().setParametro("VIEW_ACTION", viewAction);
		visitBean.setParametro("viewid", getViewId());
		log.info("en redirectBack = " + urlgoback + " from " + this.getClass().getName());
		getFacesContext().getApplication().getNavigationHandler().handleNavigation(getFacesContext(), null, urlgoback);
	}

	public boolean isAuthorized(String recurso) {
		return getVisitBean().isAutorized(recurso);
	}

	public boolean isInRole(String rol) {
		return getVisitBean().isInRole(rol);
	}

	public String goBackUrl() {
		if (StringUtils.isBlank(urlBack)) {
			return "";
		}
		String urlgoback = UtilsGeneric.encodeURL(urlBack, "faces-redirect", "true");
		log.info("goBack = " + urlgoback + " SwiftadminBean: " + (visitBean.getParametro("SwiftadminBean") != null));
		return urlgoback;
	}

	public String getIdpUrl() {
		return appProperties.getSecurity().getAuthentication().getSaml().getIdpUrl();
	}

	public void addMessageDialogInfo(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail);
		RequestContext.getCurrentInstance().showMessageInDialog(message);
	}

	public void addMessageDialogError(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, detail);
		RequestContext.getCurrentInstance().showMessageInDialog(message);
	}

	public void addMessageDialogError(String summary) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, null);
		RequestContext.getCurrentInstance().showMessageInDialog(message);
	}

	public void addMessageInfo(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail);
		getFacesContext().addMessage(null, message);
	}

	public void showMessageError(String summary, String detail) {
		FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, detail);
		getFacesContext().addMessage(null, msg);
	}

	public String getUrlBack() {
		return urlBack;
	}

	public void setUrlBack(String urlBack) {
		this.urlBack = urlBack;
	}

	private String getViewId() {
		String viewId = getFacesContext().getViewRoot().getViewId();
		String selectedComponent;
		if (viewId != null) {
			selectedComponent = viewId.substring(viewId.lastIndexOf("/") + 1, viewId.lastIndexOf("."));
		} else {
			selectedComponent = null;
		}

		return selectedComponent;
	}

	// auxiliares
	public void chooseDescTabla(Integer codTab) {
		log.info("En chooseDescTabla " + codTab);
		getVisitBean().setParametro("PAR_DESCODTAB", codTab);
		chooseDialog("/view/selectTabla.xhtml");
	}

	public GenDesctabla getGenDesctablaSelected() {
		return genDesctablaSelected;
	}

	public void setGenDesctablaSelected(GenDesctabla genDesctablaSelected) {
		this.genDesctablaSelected = genDesctablaSelected;
	}

	public void chooseDialog(String outcome) {
		log.info("chooseDialogggg " + outcome);
		try {
			Map<String, Object> options = new HashMap<String, Object>();
			options.put("modal", true);
			options.put("draggable", true);
			options.put("resizable", true);
			options.put("contentHeight", 320);
			getVisitBean().setParametro("TEMP_ACTION", "vdialog");
			RequestContext.getCurrentInstance().openDialog(outcome, options, null);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException("Error " + e.getMessage(), e);
		}
	}

	public void scanSwiftMessage(SwfMensaje swfMensaje) {
		log.info("scanSwiftMessage " + swfMensaje.getMenCodmen());
		getVisitBean().setParametro("PAR_MENPLANO", swfMensaje.getMenPlano());
		redirect("/view/ofac/ofac_search?faces-redirect=true", "VIEW_SCANRESPONSE");
	}

	public void verReporte(MensajesDatos mensajesDatos) {
		try {
			log.info("verreporte " + mensajesDatos.getSwfMensaje().getMenCodmen());			
			if (mensajesDatos.getSwfMensaje().getMenPlano() == null)
				throw new RuntimeException("Mensaje RJE nulo");
			
			ArchivoSinple archivoSinplePDF = reporteSwiftService.generarReportePDFFromPlano(mensajesDatos.getSwfMensaje().getMenPlano(),
					visitBean.getUsuario().getUsrLogin(),mensajesDatos.getSwfMensaje().getMenCodmen());
			log.info("reportSwift reporte PDF generado " + archivoSinplePDF.getNameOriginal());

			byte[] data = archivoSinplePDF.getData();
			InputStream inputStream = new ByteArrayInputStream(data);
			String nameFile = "reportSwf_" + mensajesDatos.getSwfMensaje().getMenCodmt() + "_" + mensajesDatos.getSwfMensaje().getMenCodmen() + ".pdf";
			fileDown = new DefaultStreamedContent(inputStream, "application/pdf", nameFile);
			log.info("saliendo de verreporte " + nameFile);

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public StreamedContent getFileDown() {
		log.info("getFileDown: " + (fileDown == null));
		return fileDown;
	}
	
	public UserDetailsServiceImpl getUserDetailsServiceImpl() {
		return userDetailsServiceImpl;
	}

	// @Autowired
	public void setUserDetailsServiceImpl(UserDetailsServiceImpl userDetailsServiceImpl) {
		this.userDetailsServiceImpl = userDetailsServiceImpl;
	}
	
	public MensajesDatos getMensajesDatosSelected() {
		return mensajesDatosSelected;
	}

	public void setMensajesDatosSelected(MensajesDatos mensajesDatosSelected) {
		this.mensajesDatosSelected = mensajesDatosSelected;
	}
	
}
