package gob.bcb.lavado.web.controller;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.QL.rrhh.PlafinQLBean;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.GenDesctabla;
import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.pojos.Asignacion;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.pojos.UnidadOrgCoin;
import gob.bcb.lavado.repository.GenDesctablaDao;
import gob.bcb.lavado.repository.SwfAsignamensajeDao;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.repository.SwfPersonaDao;
import gob.bcb.lavado.rest.LvdSwiftsResource;
import gob.bcb.lavado.services.AdminInOutMsgService;
import gob.bcb.lavado.services.SwiftAdminDaoService;
import gob.bcb.lavado.services.SwiftBcbParserServiceImpl;
import gob.bcb.lavado.services.SwiftBcbSearcherService;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

@ManagedBean(name = "swfLoteFormController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class SwfLoteFormController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(SwfLoteFormController.class);

	private SwfMensaje swfMensajeSelected = new SwfMensaje();
	private SwfAsignamensaje swfAsignamensajeSelected = new SwfAsignamensaje();
	private List<Block4> block4List = new ArrayList<>();
	private List<UnidadOrgCoin> unidadOrgCoinLista;
	private List<Empleado> empleadoLista = new ArrayList<Empleado>();
	private List<Empleado> empleadoListaAll = new ArrayList<Empleado>();
	private Empleado empleadoSelected = new Empleado();
	private Asignacion asignacionSelected = new Asignacion();
	private List<UnidadOrgCoin> unidadOrgCoinSelectedLista = new ArrayList<UnidadOrgCoin>();
	private List<MensajesDatos> mensajesDatosProcsLista = new ArrayList<MensajesDatos>();
	private List<MensajesDatos> mensajesDatosSelectedLista = new ArrayList<MensajesDatos>();
	private List<MensajesDatos> mensajesDatosCampos1Lista = new ArrayList<MensajesDatos>();

	private UploadedFile file;

	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private PlafinQLBean plafinQLBean;
	@Autowired
	private SwfPersonaDao swfPersonaDao;
	@Autowired
	private SwfAsignamensajeDao swfAsignamensajeDao;
	@Autowired
	private AdminInOutMsgService adminInOutMsgService;
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;

	private List<GenDesctabla> genDesctablaList = new ArrayList<GenDesctabla>();
	@Autowired
	private GenDesctablaDao genDesctablaDao;
	
	@Autowired
	private LvdSwiftsResource lvdSwiftsResource;
	private String campoaux1 = "";
	private boolean seleccionarTodo;

	private Date fecInicio;
	private Date fecFin;
	private int corrTabla = 0;

	@PostConstruct
	public void init() {
		try {
			inicializar();
			inicializaObjetos();
//			log.info("XXXXXXXXXXXXXXX XXXXXXXXXXXXXX");
//			genDesctablaList = genDesctablaDao.findByDesCodtab(Constants.TAB_ESTREVISION);
//			log.info("XXXXXXXXXXXXXXX {}---------------",genDesctablaList.size());			
			String viewAction = (String) getVisitBean().getParametro("VIEW_ACTION");
			if (!StringUtils.isBlank(viewAction)) {
				if (viewAction.equals("VIEW_ASIGNA")) {
					// abre el formulario de tareas de asignacion
					findAsigPendientesBoton();
				} else if (viewAction.equals("VIEW_SEARCH")) {
					// abre el form para busquedas de asiganciones
					// inicializaAlAbrir();
				} else if (viewAction.equals("VIEW_OBSERVADOS")) {
					findObservados();
				} else if (viewAction.equals("VIEW_PENDAUTO")) {
					findPendientesAutorizacion();
				}
			}
			getVisitBean().removeParametro("VIEW_ACTION");
		} catch (NullPointerException e) {
			showMessageError("Ocurrió un error inesperado", e.getMessage());
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void findAsigPendientes() {
		// abre el formulario de tareas de asignacion lote_view
		seleccionarTodo = false;
		corrTabla = 0;
		asignacionSelected = new Asignacion();
		mensajesDatosCampos1Lista = new ArrayList<MensajesDatos>();
		swfMensajeSelected = new SwfMensaje();
		swfMensajeSelected.setMenInout(Constants.TIPO_MENSAJE_IN);

		mensajesDatosSelectedLista = new ArrayList<MensajesDatos>();
		List<MensajesDatos> mensajesDatosSelectedListaAux = swfAsignamensajeDao.buscarMensajesAsignados(null, Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp()), null,
				Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp()), Constants.TAB_ESTREVISION_PEND, null, null, null);

		for (MensajesDatos mensajesDatos : mensajesDatosSelectedListaAux) {
			if (mensajesDatos.getSwfMensaje().getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_PROCESADO) != 0){
				mensajesDatosSelectedLista.add(mensajesDatos);
			} 
		}
		
		log.info("Recuperado asignaciones pendientes ... " + mensajesDatosSelectedLista.size());
	}

	public void findAsigPendientesBoton() {
		findAsigPendientes();
		refreshListaCampos();
		if (mensajesDatosSelectedLista.size() == 0) {
			addMessageInfo("No tiene asignaciones de mensajes pendientes", "No tiene asignaciones de mensajes pendientes");
		}
	}

	public void findPendientesAutorizacion() {
		seleccionarTodo = false;
		corrTabla = 0;
		swfMensajeSelected = new SwfMensaje();
		mensajesDatosSelectedLista = new ArrayList<MensajesDatos>();

		swfMensajeDao.findByEstautoriza(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR, Constants.TAB_ESTMENSAJE_PROCESADO).forEach(r -> {
			MensajesDatos mensajesDatos = new MensajesDatos();
			mensajesDatos.setSwfMensaje(r);
			mensajesDatosSelectedLista.add(mensajesDatos);
		});

		log.info("Recuperado asignaciones pendientes ... " + mensajesDatosSelectedLista.size());
	}

	public void refreshListaCampos() {
		mensajesDatosCampos1Lista = new ArrayList<MensajesDatos>();
		Map<String, String> mapa = new HashMap<>();
		for (MensajesDatos mensajesDatos : mensajesDatosSelectedLista) {
			if (mensajesDatos.getSwfMensaje() != null && mensajesDatos.getSwfMensaje().getBlock4List() != null && mensajesDatos.getSwfMensaje().getBlock4List().size() > 0) {
				for (Block4 block4 : mensajesDatos.getSwfMensaje().getBlock4List()) {
					if (!mapa.containsKey(block4.getName())) {
						MensajesDatos mensajesDatosA = new MensajesDatos();
						mensajesDatosA.setMenCampoaux1(block4.getName());
						mensajesDatosA.setMenCampoaux1descrip(block4.getReference());

						mensajesDatosCampos1Lista.add(mensajesDatosA);
						mapa.put(block4.getName(), block4.getName());
					}
				}
			}
		}
	}

	public void findObservados() {
		log.info("Find observados");
		mensajesDatosSelectedLista = swiftAdminDaoService.findObservados(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ);

		log.info("Find observados " + mensajesDatosSelectedLista.size());
	}

	public void search() {
		String idquery = "";
		Integer codempleado = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());
		mensajesDatosSelectedLista = new ArrayList<MensajesDatos>();
		try {
			log.info("en boton search... ");
			if (fecInicio == null || fecFin == null )
				throw new RuntimeException("Intérvalo de fecha inválido");
			
			if (!UtilsDate.entreFechas(fecInicio, UtilsDate.dateFromString("01/01/2017", "dd/MM/yyyy"), new Date()) || !UtilsDate.entreFechas(fecFin, UtilsDate.dateFromString("01/01/2017", "dd/MM/yyyy"), new Date())){
				throw new RuntimeException("Fechas de consulta deben estar entre 01/01/2017 y " + UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy"));
			}
			
			List<SwfMensaje> swfMensajeLista = lvdSwiftsResource.searchSwfMensajes(swfMensajeSelected.getMenPlano(), swfMensajeSelected.getMenInout(), idquery, swfMensajeSelected.getMenEstverifica(),
					fecInicio, fecFin, null);

			for (SwfMensaje swfMensaje : swfMensajeLista) {
				MensajesDatos mensajesDatosProc = swfMensajeDao.mensajeDatosFromSwfMensaje(swfMensaje, null, null, codempleado, null, false);
				mensajesDatosSelectedLista.add(mensajesDatosProc);
			}
			addMessageInfo("Proceso concluido con: " + mensajesDatosSelectedLista.size() + " registros encontrados", "la consulta no produjo resultados");			
		} catch (Exception e) {
			log.error("error al buscar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void buscar() {
		try {
			Integer codempleado = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());
			log.info("Recuperando datos de usuario " + codempleado);
			Integer estRevision = null;

			if (fecInicio == null || fecFin == null )
				throw new RuntimeException("Intérvalo de fecha inválido");
			
			if (!UtilsDate.entreFechas(fecInicio, UtilsDate.dateFromString("01/01/2017", "dd/MM/yyyy"), new Date()) || !UtilsDate.entreFechas(fecFin, UtilsDate.dateFromString("01/01/2017", "dd/MM/yyyy"), new Date())){
				throw new RuntimeException("Fechas de consulta deben estar entre 01/01/2017 y " + UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy"));
			}
			
			if (swfAsignamensajeSelected != null && swfAsignamensajeSelected.getGenDesctablaEstrevision() != null
					&& swfAsignamensajeSelected.getGenDesctablaEstrevision().getId() != null) {
				estRevision = swfAsignamensajeSelected.getGenDesctablaEstrevision().getId().getDesCodigo();
			}
			swfMensajeSelected.setMenInout(Constants.TIPO_MENSAJE_IN);
			// si es administrador se filtra todo, es decir el usuario que carga
			// lotes entrantes
			if (getVisitBean().isAutorized("CARGARLOTE")) {
				mensajesDatosSelectedLista = swfAsignamensajeDao.buscarMensajesAsignados(null, null, empleadoSelected.getNroEmpleado(), codempleado, estRevision, null, fecInicio,
						fecFin);
				
			} else {
				mensajesDatosSelectedLista = swfAsignamensajeDao.buscarMensajesAsignados(null, codempleado, empleadoSelected.getNroEmpleado(), codempleado, estRevision, null,
						fecInicio, fecFin);
			}
			getVisitBean().setParametro("PAR_REPMENRESU", mensajesDatosSelectedLista);
			//if (mensajesDatosSelectedLista.size() == 0)
				addMessageInfo("Proceso concluido con: " + mensajesDatosSelectedLista.size() + " registros encontrados", "la consulta no produjo resultados");
		} catch (Exception e) {
			log.error("error al buscar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void inicializaObjetos() {
		swfMensajeSelected = new SwfMensaje();
		mensajesDatosSelectedLista = new ArrayList<MensajesDatos>();
		swfAsignamensajeSelected = new SwfAsignamensaje();
		empleadoSelected = new Empleado();
		fecInicio = new Date(); // UtilsDate.addTime(new Date(), -8, 5);
		fecFin = new Date();
		getVisitBean().setParametro("PAR_REPMENRESU", mensajesDatosSelectedLista);
		genDesctablaList = genDesctablaDao.findByDesCodtab(Constants.TAB_ESTVERIFICA);
	}

	private void filtrarEmpleados() {
		empleadoLista = adminInOutMsgService.findEmpleadosByCodempCodPte(getVisitBean().getUsuario().getUsrCodemp(), null, getVisitBean().getCurrentUserLogin(),
				getVisitBean().getUsuario().getUsrAuditwst());
		log.info("recuperados empleados " + empleadoLista.size());
	}

	public void actualizarCampoSeleccion(String campo) {
		log.debug("ennn actualizarCampoSeleccion " + campo);
	}

	public void actualizarEmpleadosPorUnids(String codarea) {
		empleadoLista = plafinQLBean.findEmpleadosPorUnid(codarea);
	}

	public void eliminarDestinatario(MensajesDatos mensajesDatos, Asignacion asignacion) {
		try {
			log.info("eliminadno asignacion id= " + asignacion.getSwfAsignamensaje().getId().getResCodmen() + " Codemp: "
					+ asignacion.getSwfAsignamensaje().getId().getResCodemp());

			Integer codempleado = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());
			swfAsignamensajeDao.eliminarAsignacion(asignacion.getSwfAsignamensaje().getId().getResCodmen(), asignacion.getSwfAsignamensaje().getId().getResCodemp(), codempleado);

			List<MensajesDatos> mensajesDatosRes = swfAsignamensajeDao.buscarMensajesAsignados(mensajesDatos.getSwfMensaje().getMenCodmen(), codempleado, null, codempleado, null, null,
					null, null);
			if (mensajesDatosRes.size() > 0)
				mensajesDatos.setAsignacionLista(mensajesDatosRes.get(0).getAsignacionLista());
			else
				mensajesDatos.setAsignacionLista(new ArrayList<Asignacion>());				
		} catch (Throwable e) {
			log.error("Error al eliminar asign " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void seleccionarDestinatarioUpdMail(MensajesDatos mensajesDatos, Asignacion asignacion) {
		mensajesDatosSelected = mensajesDatos;
		SwfPersona swfPersona = swfPersonaDao.findByCodigo(asignacion.getSwfAsignamensaje().getId().getResCodemp());
		asignacionSelected = asignacion;
		asignacionSelected.setSwfPersona(swfPersona);
		swfAsignamensajeSelected = swfMensajeDao.swfAsignamensajeCodigo(asignacion.getSwfAsignamensaje().getId().getResCodmen(),
				asignacion.getSwfAsignamensaje().getId().getResCodemp());
		log.info("swfAsignamensajeSelected " + swfAsignamensajeSelected.getId().getResCodmen() + " area " + swfAsignamensajeSelected.getResArecod());
	}

	public String guardarDestinatarioUpdMail() {
		try {
			log.info("guardarDestinatarioUpdMail ");

			Integer codempleado = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());

			SwfAsignamensaje swfAsignamensajeOld = swfAsignamensajeDao.byCodigo(swfAsignamensajeSelected.getId().getResCodmen(), swfAsignamensajeSelected.getId().getResCodemp());
			if (swfAsignamensajeOld != null) {
				if (swfAsignamensajeOld.getResEstrevision().compareTo(Constants.TAB_ESTREVISION_ENPROC_ASIGNACION) != 0) {
					throw new RuntimeException("Registro no se encuentra en ESTADO de proceso de asignación");
				}
			}
			asignacionSelected.getSwfPersona().setPerArecod(swfAsignamensajeSelected.getResArecod());
			asignacionSelected.getSwfPersona().setPerAuditusr(getVisitBean().getCurrentUserLogin());
			asignacionSelected.getSwfPersona().setPerAuditwst(getVisitBean().getUsuario().getUsrAuditwst());

			swfAsignamensajeSelected.setResAuditusr(getVisitBean().getCurrentUserLogin());
			swfAsignamensajeSelected.setResAuditwst(getVisitBean().getUsuario().getUsrAuditwst());
			
			if (StringUtils.isBlank(asignacionSelected.getSwfPersona().getPerEmail())){
				throw new RuntimeException("Correo inválido, requerido para la asignación del mensaje swift");
			}
			swfPersonaDao.saveorupdate(asignacionSelected.getSwfPersona());
			swfAsignamensajeDao.updateReg(swfAsignamensajeSelected);

			List<MensajesDatos> mensajesDatosRes = swfAsignamensajeDao.buscarMensajesAsignados(mensajesDatosSelected.getSwfMensaje().getMenCodmen(), codempleado, null, codempleado, null, null,
					null, null);
			if (mensajesDatosRes.size() > 0)
				mensajesDatosSelected.setAsignacionLista(mensajesDatosRes.get(0).getAsignacionLista());
			else
				mensajesDatosSelected.setAsignacionLista(new ArrayList<Asignacion>());				
			
			addMessageInfo("Los datos fueron actualizados exitósamente", "Los datos fueron actualizados exitósamente");
			return null;
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			return null;			
		}
	}

	public void selectDestParaAsig(Empleado empleado) {
		log.info("selectDestParaAsig Seleccionado empleado " + empleado.getNroEmpleado());
		try {
			Integer codempleado = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());
			if (codempleado.compareTo(empleado.getNroEmpleado()) == 0) {
				throw new SwiftAdminException("Auto-asignacion: No puede asignarse el mensaje a Ud mismo. Seleccione otro empleado o procese el mensaje");
			}

			swfAsignamensajeDao.crearAsignacion(mensajesDatosSelected.getSwfMensaje(), empleado.getNroEmpleado(), codempleado, empleado.getCodUnidadOrg(),
					Constants.TAB_ESTREVISION_ENPROC_ASIGNACION, getVisitBean().getCurrentUserLogin(), getVisitBean().getUsuario().getUsrAuditwst());

			List<MensajesDatos> mensajesDatosRes = swfAsignamensajeDao.buscarMensajesAsignados(mensajesDatosSelected.getSwfMensaje().getMenCodmen(), codempleado, null, codempleado, null, null,
					null, null);
			if (mensajesDatosRes.size() > 0)
				mensajesDatosSelected.setAsignacionLista(mensajesDatosRes.get(0).getAsignacionLista());
			else
				mensajesDatosSelected.setAsignacionLista(new ArrayList<Asignacion>());				

			addMessageInfo("Asignación exitosa", "Asignación exitosa");
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void selectEmpleado(Empleado empleado) {
		empleadoSelected = empleado;
		empleadoLista = new ArrayList<Empleado>();
	}

	public void seleccionarDetalle(MensajesDatos mensajesDatos) {
		log.debug("en seleccionarDetalle " + mensajesDatos.getMenCodmen());
		mensajesDatosSelected = mensajesDatos;

		block4List = new ArrayList<>();
		try {
			if (mensajesDatos.getSwfMensaje().getMenPlano() == null)
				throw new SwiftAdminException("Mensaje en formato RJE nulo");
			SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(mensajesDatos.getSwfMensaje().getMenPlano());
			swiftDatos.getSwfMensaje().setBlock4List(SwiftDatos.block4ToBlock4Ldv(swiftDatos.getSwiftMessageAbs().createBlock4().getBlock4()));
			SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();

			block4List = swfMensaje.getBlock4List();
			mensajesDatosSelected.getSwfMensaje().setSwiftfPlano(swiftDatos.getSwiftMessageAbs().genMenPlano());
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void seleccionarDestinatarios(MensajesDatos mensajesDatos) {
		log.debug("en seleccionarDestinatarios " + mensajesDatos.getMenCodmen());
		swfAsignamensajeSelected.setResArecod("");
		filtrarEmpleados();
		getUnidadOrgCoinLista();
		mensajesDatosSelected = mensajesDatos;
	}

	public void buscarEmpleado() {
		swfAsignamensajeSelected.setResArecod("");
		filtrarEmpleados();
		getUnidadOrgCoinLista();
	}

	public void irAReporteHTML() {
		log.info("irAReporteHTML");
		getVisitBean().setParametro("PAR_REPMENRESU", mensajesDatosSelectedLista);
		redirect("/view/procesos/repmensajes?faces-redirect=true", "VIEW_REPSEARCH");
		log.info("saliendo de irAReporteHTML");
	}

	public void procesoEnvio() {
		log.info("Entrado a procesoEnvio de asignación ");
		mensajesDatosProcsLista = new ArrayList<MensajesDatos>();
		try {
			if (mensajesDatosSelectedLista.size() == 0) {
				throw new RuntimeException("No existe registros a procesar");
			}

			Integer codEmp = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());
			// control de validaciones
			Collections.sort(mensajesDatosSelectedLista, new BySecuenciaComparator());
			// estado revision asignado
			for (MensajesDatos mensajesDatos : mensajesDatosSelectedLista) {
				if (!mensajesDatos.isSeleccionado()) {
					continue;
				}
				adminInOutMsgService.asignarYEnviarMailDeNotificacion(mensajesDatos, codEmp, getVisitBean().getUsuario().getUsrLogin(),
						getVisitBean().getUsuario().getUsrAuditwst());
				mensajesDatosProcsLista.add(mensajesDatos);
			}
			if (mensajesDatosProcsLista.size() == 0) {
				throw new RuntimeException("No existe registros seleccionados para procesar");
			}
			log.info("FIN de Proceso de asignacion " + mensajesDatosProcsLista.size() + " registros [" + mensajesDatosProcsLista.size() + "] procesados! por codEmp: " + codEmp);
			findAsigPendientes();
			addMessageInfo("La operación se realizó exitósamente", "La operación se realizó exitósamente");
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void procesoGuardarEnImportados() {
		log.info("Entrado a proceso Guardar en importados");
		mensajesDatosProcsLista = new ArrayList<MensajesDatos>();
		List<SwfMensaje> swfMensajeLista = new ArrayList<>();
		try {
			// estado revision asignado
			for (MensajesDatos mensajesDatos : mensajesDatosSelectedLista) {
				if (!mensajesDatos.isSeleccionado()) {
					continue;
				}
				mensajesDatosProcsLista.add(mensajesDatos);
				swfMensajeLista.add(mensajesDatos.getSwfMensaje());
			}

			if (swfMensajeLista.size() == 0) {
				throw new RuntimeException("Sin registros. Seleccione registros para continuar");
			}

			swiftAdminDaoService.grabarEnDirectorioSwift(swfMensajeLista, getVisitBean().getUsuario().getUsrLogin(), getVisitBean().getUsuario().getUsrAuditwst());
			log.info("FIN de Proceso de guardar en importados " + mensajesDatosProcsLista.size() + " registros [" + mensajesDatosProcsLista.size());
			findPendientesAutorizacion();
			addMessageInfo("La operación se realizó exitósamente", "La operación se realizó exitósamente");
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void verProcesados() {
		log.info("XXX:en verProcesados orale!!!" + mensajesDatosProcsLista.size());
	}

	public void procesarMensaje(MensajesDatos mensajesDatos) {
		try {
			log.info("en boton procesar " + mensajesDatos.getSwfMensaje().getMenCodmen());
			swfAsignamensajeDao.procesar(mensajesDatos.getSwfMensaje().getMenCodmen(), Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp()),
					getVisitBean().getUsuario().getUsrLogin(), getVisitBean().getUsuario().getUsrAuditwst());
			findAsigPendientes();
			refreshListaCampos();
			addMessageInfo("La operación se realizó satisfactoriamente", "");
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void scanBloquearMensaje(MensajesDatos mensajesDatos) {
		try {
			Integer codmen = mensajesDatos.getSwfMensaje().getMenCodmen();
			swiftAdminDaoService.bloquearMensaje(mensajesDatos.getSwfMensaje().getMenCodmen(), getVisitBean().getUsuario().getUsrLogin(),
					getVisitBean().getUsuario().getUsrAuditwst());
			findObservados();
			addMessageInfo("Mensaje con código:" + codmen + ", bloqueado exitósamente.", "Mensaje con código:" + codmen + ", bloqueado exitósamente.");
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void scanHabilitarFalsoPositivo(MensajesDatos mensajesDatos) {
		try {
			Integer codmen = mensajesDatos.getSwfMensaje().getMenCodmen();
			swiftAdminDaoService.habilitarMensaje(mensajesDatos.getSwfMensaje().getMenCodmen(), getVisitBean().getUsuario().getUsrLogin(),
					getVisitBean().getUsuario().getUsrAuditwst());
			findObservados();			
			addMessageInfo("Mensaje con código:" + codmen + ", marcado como falso positivo exitósamente." , "Mensaje con código:" + codmen + ", marcado como falso positivo exitósamente.");
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void rechazarMensajePendiente(MensajesDatos mensajesDatos) {
		try {
			log.info("rechazarMensajePendiente " + mensajesDatos.getSwfMensaje().getMenCodmen());
			Integer codmen = mensajesDatos.getSwfMensaje().getMenCodmen();
			swiftAdminDaoService.rechazarMensaje(mensajesDatos.getSwfMensaje().getMenCodmen(), getVisitBean().getUsuario().getUsrLogin(),
					getVisitBean().getUsuario().getUsrAuditwst());
			findPendientesAutorizacion();
			addMessageInfo("Operación realizada exitósamente: " + codmen, "Operación realizada exitósamente: " + codmen);
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void habilitarMensaje(MensajesDatos mensajesDatos) {
		try {
			Integer codEmp = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());
			log.info("habilitar Mensaje id= " + mensajesDatos.getSwfMensaje().getMenCodmen() + " Codemp: " + codEmp);
			// si es administrador se filtra todo, es decir el usuario que carga
			// lotes entrantes
			if (getVisitBean().isAutorized("CARGARLOTE")) {
				swfAsignamensajeDao.habilitar(mensajesDatos.getSwfMensaje().getMenCodmen(), mensajesDatos.getAsignacion().getSwfAsignamensaje().getId().getResCodemp(), Constants.TAB_ESTREVISION_PEND, getVisitBean().getUsuario().getUsrLogin(),
						getVisitBean().getUsuario().getUsrAuditwst());				
			} else {
				swfAsignamensajeDao.habilitar(mensajesDatos.getSwfMensaje().getMenCodmen(), codEmp, Constants.TAB_ESTREVISION_PEND, getVisitBean().getUsuario().getUsrLogin(),
					getVisitBean().getUsuario().getUsrAuditwst());
			}
			buscar();
			addMessageInfo("La operación se realizó satisfactoriamente", "");
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void rechazarMensaje(MensajesDatos mensajesDatos) {
		try {
			Integer codEmp = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());
			log.info("Rechazando mensaje {} por {}", mensajesDatos.getMenCodmen(), codEmp);			
			swfAsignamensajeDao.rechazarAsignacion(mensajesDatos.getMenCodmen(), codEmp, getVisitBean().getUsuario().getUsrLogin(), getVisitBean().getUsuario().getUsrAuditwst());
			findAsigPendientes();
			refreshListaCampos();
			addMessageInfo("La operación se realizó satisfactoriamente", "");
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void seleccionTodo() {
		corrTabla = 0;
		for (MensajesDatos mensajesDatos : mensajesDatosSelectedLista) {
			mensajesDatos.setSecuencia(0);
			if (mensajesDatos.getAsignacionLista() != null && mensajesDatos.getAsignacionLista().size() > 0) {
				mensajesDatos.setSeleccionado(seleccionarTodo);

				if (mensajesDatos.isSeleccionado()) {
					mensajesDatos.setSecuencia(++corrTabla);
				}
			} else {
				mensajesDatos.setSeleccionado(false);
			}
		}

	}

	public void seleccionTodoMens() {
		corrTabla = 0;
		for (MensajesDatos mensajesDatos : mensajesDatosSelectedLista) {
			mensajesDatos.setSecuencia(0);
			mensajesDatos.setSeleccionado(seleccionarTodo);

			if (mensajesDatos.isSeleccionado()) {
				mensajesDatos.setSecuencia(++corrTabla);
			}
		}

	}

	public void seleccionItem(MensajesDatos mensajesDatos) {
		try {
			mensajesDatos.setSecuencia(0);
			if (mensajesDatos.isSeleccionado()) {
				mensajesDatos.setSecuencia(++corrTabla);
			}
			for (Asignacion asignacion : mensajesDatos.getAsignacionLista()) {
				if (StringUtils.isBlank(asignacion.getSwfPersona().getPerEmail())) {
					throw new RuntimeException("Correo invalido");
				}
				UtilsGeneric.validarEmail(asignacion.getSwfPersona().getPerEmail());
			}
			seleccionarTodo = false;
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}

	}

	public void seleccionItemPendientes(MensajesDatos mensajesDatos) {
		try {
			mensajesDatos.setSecuencia(0);
			if (mensajesDatos.isSeleccionado()) {
				mensajesDatos.setSecuencia(++corrTabla);
			}
			seleccionarTodo = false;
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}

	}

	public UploadedFile getFile() {
		return file;
	}

	public void setFile(UploadedFile file) {
		this.file = file;
	}

	public SwfMensaje getSwfMensajeSelected() {
		return swfMensajeSelected;
	}

	public void setSwfMensajeSelected(SwfMensaje swfMensajeSelected) {
		this.swfMensajeSelected = swfMensajeSelected;
	}

	public List<UnidadOrgCoin> getUnidadOrgCoinLista() {
		if (unidadOrgCoinLista == null) {
			unidadOrgCoinLista = plafinQLBean.unidadesOrg();
		}
		return unidadOrgCoinLista;
	}

	public void setUnidadOrgCoinLista(List<UnidadOrgCoin> unidadOrgCoinLista) {
		this.unidadOrgCoinLista = unidadOrgCoinLista;
	}

	public List<Empleado> getEmpleadoLista() {
		return empleadoLista;
	}

	public void setEmpleadoLista(List<Empleado> empleadoLista) {
		this.empleadoLista = empleadoLista;
	}

	public List<MensajesDatos> getMensajesDatosSelectedLista() {
		return mensajesDatosSelectedLista;
	}

	public void setMensajesDatosSelectedLista(List<MensajesDatos> mensajesDatosSelectedLista) {
		this.mensajesDatosSelectedLista = mensajesDatosSelectedLista;
	}

	public String getCampoaux1() {
		return campoaux1;
	}

	public void setCampoaux1(String campoaux1) {
		this.campoaux1 = campoaux1;
	}

	public List<MensajesDatos> getMensajesDatosCampos1Lista() {
		return mensajesDatosCampos1Lista;
	}

	public void setMensajesDatosCampos1Lista(List<MensajesDatos> mensajesDatosCampos1Lista) {
		this.mensajesDatosCampos1Lista = mensajesDatosCampos1Lista;
	}

	public List<UnidadOrgCoin> getUnidadOrgCoinSelectedLista() {
		return unidadOrgCoinSelectedLista;
	}

	public void setUnidadOrgCoinSelectedLista(List<UnidadOrgCoin> unidadOrgCoinSelectedLista) {
		this.unidadOrgCoinSelectedLista = unidadOrgCoinSelectedLista;
	}

	public boolean isSeleccionarTodo() {
		return seleccionarTodo;
	}

	public void setSeleccionarTodo(boolean seleccionarTodo) {
		this.seleccionarTodo = seleccionarTodo;
	}

	public void onDescTablaChosen(SelectEvent event) {
		setGenDesctablaSelected((GenDesctabla) event.getObject());
		if (getGenDesctablaSelected().getId().getDesCodtab().compareTo(Constants.TAB_ESTREVISION) == 0) {
			swfAsignamensajeSelected.setGenDesctablaEstrevision(getGenDesctablaSelected());
		} else if (getGenDesctablaSelected().getId().getDesCodtab().compareTo(Constants.TAB_ESTMENSAJE) == 0) {
			swfMensajeSelected.setGenDesctablaEstmensaje(getGenDesctablaSelected());
		} else if (getGenDesctablaSelected().getId().getDesCodtab().compareTo(Constants.TAB_ESTVERIFICA) == 0) {
			swfMensajeSelected.setGenDesctablaEstmensaje(getGenDesctablaSelected());
			swfMensajeSelected.setMenEstverifica(getGenDesctablaSelected().getId().getDesCodigo());
		}
	}

	public Date getFecInicio() {
		return fecInicio;
	}

	public void setFecInicio(Date fecInicio) {
		this.fecInicio = fecInicio;
	}

	public Date getFecFin() {
		return fecFin;
	}

	public void setFecFin(Date fecFin) {
		this.fecFin = fecFin;
	}

	public SwfAsignamensaje getSwfAsignamensajeSelected() {
		return swfAsignamensajeSelected;
	}

	public void setSwfAsignamensajeSelected(SwfAsignamensaje swfAsignamensajeSelected) {
		this.swfAsignamensajeSelected = swfAsignamensajeSelected;
	}

	public Asignacion getAsignacionSelected() {
		return asignacionSelected;
	}

	public void setAsignacionSelected(Asignacion asignacionSelected) {
		this.asignacionSelected = asignacionSelected;
	}

	public void listarTodosEmpleados() {
		// empleadoListaAll = plafinQLBean.findEmpleadosPorUnid(null);
		getUnidadOrgCoinLista();
		// log.info("encontrados todos empleados " + empleadoListaAll.size());
	}

	public List<MensajesDatos> getMensajesDatosProcsLista() {
		return mensajesDatosProcsLista;
	}

	public void setMensajesDatosProcsLista(List<MensajesDatos> mensajesDatosProcsLista) {
		this.mensajesDatosProcsLista = mensajesDatosProcsLista;
	}

	public Empleado getEmpleadoSelected() {
		return empleadoSelected;
	}

	public void setEmpleadoSelected(Empleado empleadoSelected) {
		this.empleadoSelected = empleadoSelected;
	}

	public List<Block4> getBlock4List() {
		return block4List;
	}

	public void setBlock4List(List<Block4> block4List) {
		this.block4List = block4List;
	}

	public List<Empleado> getEmpleadoListaAll() {
		return empleadoListaAll;
	}

	public List<GenDesctabla> getGenDesctablaList() {
		return genDesctablaList;
	}

	public class BySecuenciaComparator implements Comparator {
		public int compare(Object o1, Object o2) {
			MensajesDatos c1 = (MensajesDatos) o1;
			MensajesDatos c2 = (MensajesDatos) o2;
			return c1.getSecuencia().compareTo(c2.getSecuencia());
		}
	}
}
