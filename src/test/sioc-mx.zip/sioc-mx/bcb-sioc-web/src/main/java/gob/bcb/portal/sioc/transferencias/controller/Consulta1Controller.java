package gob.bcb.portal.sioc.transferencias.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.service.servicioSioc.common.Constants;

public class Consulta1Controller extends BaseBeanController {

	private String mensaje = "";
	private String codeOtp = "";
	private Logger log = Logger.getLogger(Consulta1Controller.class);
	private static final String ESTACION = "";

	@PostConstruct
	public void inicio() {
		try {
			mensaje = "El dia abierto de la aplicacion es " + this.getDiaAbierto() + ".";
			recuperarVisit();
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
		}
	}

	private Date getDiaAbierto() {
		Date dia = null;

		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("consulta", "dia");
		mapaParametros1.put("opcion", "DiaAbierto");

		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: DiaAbierto");
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", ESTACION, "cliente", "query", mapaParametros1, iid1);
			dia = (Date) mapaResultado1.get("dia");
		} catch (Exception e) {
			log.error("Error en Consulta", e);
		}

		return dia;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public void eventoMensajeBpm() {
		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("consulta", "dia");
		Date dia = null;
		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: dia");
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", ESTACION, "cliente", "query", mapaParametros1, iid1);
			dia = (Date) mapaResultado1.get("dia");
		} catch (Exception e) {
			log.error("Error en Consulta", e);
		}
		this.mensaje = "El dia abierto de la aplicacion es " + dia + ".";
	}

	public String eventoMensajeBpm2() {
		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("consulta", "dia");
		Date dia = null;
		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: codeOtp " + codeOtp);
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", ESTACION, "cliente", "query", mapaParametros1, iid1);
			dia = (Date) mapaResultado1.get("dia");

			this.mensaje = "El dia abierto de la aplicacion es " + dia + ".";
			return null;
		} catch (Exception e) {
			log.error("Error en Consulta", e);
			return null;
		}
	}
}
