package gob.bcb.core.jms;

import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.utils.JAXBHelper;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.UtilsNet;
import gob.bcb.core.utils.UtilsXmlBind;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.TemporaryQueue;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
 
public abstract class BcbMsgAbstract {
	private static Logger log = Logger.getLogger(BcbMsgAbstract.class);
	/**
	 * nombre del feature dentro del servicio de negocio o BPM
	 */
	private String nameQueueTopic;
	private Map<String, Object> parameters = new HashMap<String, Object>();
	private Map<String, Object> propiedades = new HashMap<String, Object>();
	private Object mensajeBCBJAXB;
	private Object body;
	private Message jmsMessage;
	private JMSBinding binding = new JMSBinding();
	private MessageConsumer replyConsumer = null;
	private boolean typeDestinationQueue = true;
	private boolean disableReplyTo;
	private boolean printed = true;
	private Destination destination;
	private long startTime;
	private JMSConnectionHandler jMSConnectionHandler; 

	private final static JAXBContext jAXBContext;
	static {
		try {
			jAXBContext = JAXBContext.newInstance("gob.bcb.core.jms.model");
			log.info("Contexto objetos JAXB iniciado");
		} catch (JAXBException e) {
			log.error("Error al inicializar contexto JAXB " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}
	private final static Map<Class<?>, JAXBContext> contexts = new HashMap<Class<?>, JAXBContext>();
	private static DocumentBuilderFactory documentBuilderFactory;

	public BcbMsgAbstract() {
		startTime = System.currentTimeMillis();
//		try {
//			getPropiedades().put("BCBAddress", UtilsNet.getAddressHost());
//			getPropiedades().put("BCBIdemisor", UtilsNet.getNameHost());
//		} catch (Exception e) {
//		}
		getPropiedades().put("BCBIddestinatario", "default");
		getPropiedades().put("BCBIdusuario", "localhost");
		getPropiedades().put("BCBPasswmd5", "");
		getPropiedades().put("BCBIdsistema", "system");
		getPropiedades().put("BCBNrooperacion", UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + UtilsGeneric.generateUUID());
		getPropiedades().put("BCBIdoperacion", "default");
	}

	public BcbMsgAbstract(Message jmsMessage) {
		setJmsMessage(jmsMessage);
	}

//	public BcbMsgAbstract(Message jmsMessage, Session session) {
//		setJmsMessage(jmsMessage);
//	}

	public abstract void setPropiedadesFromMsgBcb();

	public abstract void setMsgBcbFromPropiedades();

	public abstract void updateMsgsistemaresp(String statusCode, String statusDescription, Object tipoJAXBEleASubtituir);

	/**
	 * implementar si el body es nulo que tipo de mensaje se lleva
	 */
	public abstract void setBodyMsgBcb();

	public StatusResponse sendMessage() {
		StatusResponse statusResponse = null;
		startTime = System.currentTimeMillis();
		try {
			send();

			if (!isDisableReplyTo()) {
				statusResponse = procesarResponseMsgIn();
				long endTime = System.currentTimeMillis();
				log.info("Respuesta recibida satisfactoriamente. (" + (endTime - startTime) + " ms.)");
				//jMSConnectionHandler.closeConsumer();
			}
		} catch (NullPointerException e) {
			log.error("error al procesarResponse JMS " + e.getMessage(), e);
			statusResponse = new StatusResponse();
			statusResponse.setStatusCode("NullPointerException");
			statusResponse.setDescrip(e.getMessage());

		} catch (Exception e) {
			log.error("error al cerrar consumers JMS " + e.getMessage(), e);
			statusResponse = new StatusResponse();
			statusResponse.setStatusCode("Exception");
			if (e.getMessage().equalsIgnoreCase("Sin Respuesta de Servicio")){
				statusResponse.setStatusCode(Constants.RESP_JMS_NOT_SEND);
			}
			statusResponse.setDescrip(e.getMessage());

		}

		return statusResponse;
	}

	public void send() {
		try {
			if (jmsMessage == null) {
				Message msgOut = createMessage();
				jmsMessage = msgOut;
			}

				if (isTypeDestinationQueue()) {
					destination = jMSConnectionHandler.getSession().createQueue(nameQueueTopic);
				} else {
					destination = jMSConnectionHandler.getSession().createTopic(nameQueueTopic);
				}

			if (!isDisableReplyTo()) {
				TemporaryQueue confirmQueue = jMSConnectionHandler.getSession().createTemporaryQueue();
				jmsMessage.setJMSReplyTo(confirmQueue);
				replyConsumer = jMSConnectionHandler.createConsumer(confirmQueue, true);

			}
			jMSConnectionHandler.send(destination, jmsMessage, false, 5, 10000);
			// jMSConnectionHandler.send(destination, getJmsMessage());
			if (isPrinted())
				log.info("Mensaje request enviado: \n" + printMessage());
		} catch (Exception e) {
			log.error("error al enviar mensaje: " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public Object extractBodyAndParams(Message message) {
		Object bodyMsgIn = null;
		try {
			if (message == null) {
				log.error("Mensaje NULO");
				throw new RuntimeException("Mensaje NULO");
			}

			setPropiedades(binding.extractHeadersFromJms(message));

			bodyMsgIn = binding.extractBodyFromJms(message);

			if (bodyMsgIn == null) {
				log.error("No se pudo recuperar contenido del mensaje");
				throw new Exception("No se pudo recuperar contenido del mensaje");
			}

			if (bodyMsgIn instanceof String) {
				Object mensajeJAXB = null;
				try {
					mensajeJAXB = JAXBHelper.convertXMLToMsgBcb((String) bodyMsgIn, jAXBContext);
					mensajeBCBJAXB = mensajeJAXB;
				} catch (Exception e) {
					if (getPropiedades().containsKey("JMSType") && (getPropiedades().get("JMSType") != null)
							&& ((String) getPropiedades().get("JMSType")).equals(String.class.getName())) {
						// si tiene el parametro en el header se valida como
						// string
						log.warn("Se valida el contenido del mensaje como string " + e.getMessage(), e);
					} else {
						log.error(e.getMessage(), e);
						throw new RuntimeException(e);
					}
				}

			} else {
				Map<String, Object> params = binding.getParamsFromMessage(message, getPropiedades());
				setRequestElements(params);
				setMsgBcbFromPropiedades();
			}
			setBody(bodyMsgIn);
		} catch (Exception e) {
			log.error("Error en la recepcion del mensaje " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
		return bodyMsgIn;
	}

	public Object procesarMsgIn() {
		Object bodyMsgIn = extractBodyAndParams(jmsMessage);
		return bodyMsgIn;
	}

	protected Message createMessage() throws Exception {

		setBodyMsgBcb();
		Message response = null;
		try {
			if (body instanceof byte[] || body instanceof Map) {
				setPropiedadesFromMsgBcb();
				getRequestElements().putAll(binding.extractParamsFilter(getPropiedades()));
				response = binding.createJmsMessage(body, getRequestElements(), jMSConnectionHandler.getSession());
			} else if (body instanceof String) {
				response = binding.createJmsMessage(body, getRequestElements(), jMSConnectionHandler.getSession());
			} else {
				setPropiedadesFromMsgBcb();
				getRequestElements().putAll(binding.extractParamsFilter(getPropiedades()));
				response = binding.createJmsMessage(getBody(), getRequestElements(), jMSConnectionHandler.getSession());
			}
			response.setJMSCorrelationID(determineCorrelationId(response));
			
			return response;			
		} catch (Exception e) {
			log.error("Error al Generico crear mensaje: " + e.getMessage(), e);
			throw new Exception(e);
		}
	}

	public abstract StatusResponse procesarResponseMsgIn();

	public void setJmsMessage(Message jmsMessage) {
		this.jmsMessage = jmsMessage;
	}
 
	public Message getJmsMessage() {
		return jmsMessage;
	}
 
	public String printMessage() {
		StringBuilder result = new StringBuilder();

		// result.append(getPropiedades().toString());
		// result.append(getRequestElements().toString());
		// Enumeration names;
		// try {
		// names = getJmsMessage().getPropertyNames();
		// } catch (JMSException e) {
		// throw new RuntimeException(e);
		// }
		// while (names.hasMoreElements()) {
		// String name = names.nextElement().toString();
		// try {
		// Object value = getJmsMessage().getObjectProperty(name);
		// result.append(name + " = " + value);
		// } catch (JMSException e) {
		// result.append(name + " = tipo valor desconocido");
		// }
		// result.append("\n");
		// }
		// result.append(" ===================body=======================\n");
		if (body == null) {
			result.append(binding.extractBodyFromJms(jmsMessage));
		} else {
			result.append(body);
		}
		// result.append("\n===================body=======================\n");
		return result.toString();
	}

	private String toString0(Object value) throws JAXBException, ParserConfigurationException, TransformerException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		// Document doc = JAXBHelper.toDocument(value, documentBuilderFactory,
		// getJaxbContext(value));
		Document doc = JAXBHelper.toDocument(value, documentBuilderFactory, getJaxbcontext());
		return UtilsXmlBind.getStringFromDom(doc);

	}

	protected String determineCorrelationId(Message message) throws JMSException {
		final String provisionalCorrelationId = (String) getPropiedades().get("JMSCorrelationID");

		if (provisionalCorrelationId != null) {
			return provisionalCorrelationId;
		}

		final String messageId = message.getJMSMessageID();
		final String correlationId = message.getJMSCorrelationID();
		if (correlationId == null || correlationId.trim().isEmpty()) {
			// correlation id is empty so fallback to message id
			return messageId;
		} else {
			return correlationId;
		}
	}

	private synchronized JAXBContext getJaxbContext(Object value) throws JAXBException {
		Class<?> type = value.getClass();
		JAXBContext context = contexts.get(type);
		if (context == null) {
			context = JAXBContext.newInstance(type);
			contexts.put(type, context);
		}
		return context;
	}

	public void addDescripcionParametro(String paramName, Object objeto) {
		parameters.put(paramName, objeto);
	}

	public String getIdTipoOperacion() {
		return (String) getPropiedades().get("BCBIdoperacion");
	}

	public Map<String, Object> getRequestElements() {
		return this.parameters;
	}

	public void setRequestElements(Map<String, Object> parameters) {
		this.parameters = parameters;
	}

	public void setNameQueueTopic(String nameQueueTopic) {
		this.nameQueueTopic = nameQueueTopic;
	}

	public String getNameQueueTopic() {
		return nameQueueTopic;
	}

	public void setBody(Object body) {
		this.body = body;
	}

	public Object getBody() {
		return body;
	}

	public void setPropiedades(Map<String, Object> propiedades) {
		this.propiedades = propiedades;
	}

	public Map<String, Object> getPropiedades() {
		return propiedades;
	}

	public void setMensajeBCBJAXB(Object mensajeBCBJAXB) {
		this.mensajeBCBJAXB = mensajeBCBJAXB;
	}

	public Object getMensajeBCBJAXB() {
		return this.mensajeBCBJAXB;
	}

	public static JAXBContext getJaxbcontext() {
		return jAXBContext;
	}

	public void setReplyConsumer(MessageConsumer replyConsumer) {
		this.replyConsumer = replyConsumer;
	}

	public MessageConsumer getReplyConsumer() {
		return replyConsumer;
	}

	public void setDisableReplyTo(boolean disableReplyTo) {
		this.disableReplyTo = disableReplyTo;
	}

	public boolean isDisableReplyTo() {
		return disableReplyTo;
	}

	public void setTypeDestinationQueue(boolean typeDestinationQueue) {
		this.typeDestinationQueue = typeDestinationQueue;
	}

	public boolean isTypeDestinationQueue() {
		return typeDestinationQueue;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	public Destination getDestination() {
		return destination;
	}

	public void setPrinted(boolean printed) {
		this.printed = printed;
	}

	public boolean isPrinted() {
		return printed;
	}

	public void setJMSConnectionHandler(JMSConnectionHandler jMSConnectionHandler) {
		this.jMSConnectionHandler = jMSConnectionHandler;
	}

//	public JMSConnectionHandler getJMSConnectionHandler0() {
//		if (jMSConnectionHandler == null) {
//			jMSConnectionHandler = new JMSConnectionHandler();
//		}
//		return jMSConnectionHandler;
//	}

}
