package gob.bcb.swift.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.XPath;
import org.junit.jupiter.api.Test;

import com.prowidesoftware.swift.io.ConversionService;
import com.prowidesoftware.swift.io.IConversionService;
import com.prowidesoftware.swift.model.MxId;
import com.prowidesoftware.swift.model.SwiftBlock3;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field58D;
import com.prowidesoftware.swift.model.mt.AbstractMT;
import com.prowidesoftware.swift.model.mx.AbstractMX;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.CampoFormTable;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.MappingTable;
import gob.bcb.iso20022.translate.FormatEngine;
import gob.bcb.service.config.BaseData;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.pojos.SwiftDatos;

public class CreateSwiftServiceMxTest extends BaseData {
	private static final Log log = LogFactory.getLog(CreateSwiftServiceTest.class);

//	@Test
	public void generateTreeSwfCamposMT103Test() {
		try {
			log.info("================================");
			// F01BCEBBOLPAXXX1000100001}{2:I103SCBLUS33XXXXN
			// F1BCEBBOLPAXXX1000100001}{2:I103SCBLUS33XXXXN
			String socCodigo = "032121";
			SwiftDatos swiftDatos = createSwiftDatos(socCodigo);
			SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
			
			Instruccion instruccion = initSwfParams(swfMensaje);
			SwfMsgParam swfMsgParam = instruccion.getSwfMsgParam();
 			swfMsgParam.setMenFormato("MT");
 			swfMsgParam.setMenTypemessage("103");
 			//swfMsgParam.setMenIdTMessageTx("103A");
			swfMsgParam.setMenFormato("MX");
			swfMsgParam.setMenIdTMessageTx("pacs.009.MTTOMX");
			swfMsgParam.setMenTypemessage("pacs.009.001.09");
			
			CreateSwiftService createSwiftService = new CreateSwiftService(instruccion, swfMencamposIsoDaoImpl);
			createSwiftService.setSessionFactory(sessionFactorySioc);
			
			createSwiftService.initInstruccion();
			MappingTable mappingTable = createSwiftService.getMappingTable();
			
			List<String> l = Arrays.asList("inftrx", "dbtrAgt", "instg", "cdtrAgt", "intrmy", "rmtInf", "chrBear", "instrInf", "dbtr", "cdtr");
			l.forEach(c -> {
				swiftMessageService.obtenerFacts(swiftDatos, c, mappingTable);
			});
			
			SwiftBlock4 blk = swiftMessageService.obtenerCamposBlk4(swiftDatos, instruccion, "4");
//			blk.fields().forEach(f -> {
//				mappingTable.putFact("F" + f.getName(), f);
//			});
			createSwiftService.recuperarSwfCampos(swfMsgParam.getMenIdTMessageTx(), "4");
			createSwiftService.generaHeaderMsg();
			log.info("is mt ? " + instruccion.isMt() + " " + instruccion.getSwfMsgParam().getMenFormato());
//			if (instruccion.isMt()) {
//				AbstractMT mt =  (AbstractMT) instruccion.getMensajeMtMx();
//				mt.getSwiftMessage().setBlock4(blk);
//			}
			createSwiftService.initEngine();
			createSwiftService.createMsgSwift();
			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	
	//@Test
	public void generateTreeSwfCamposMxPacs009Test() {
		try {
			log.info("================================");
			String socCodigo = "030546";
			SwiftDatos swiftDatos = createSwiftDatos(socCodigo);
			SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
			
			Instruccion instruccion = initSwfParams(swfMensaje);
			SwfMsgParam swfMsgParam = instruccion.getSwfMsgParam();
			swfMsgParam.setMenFormato("MX");
			swfMsgParam.setMenIdTMessageTx("pacs.009.MTTOMX");
			swfMsgParam.setMenTypemessage("pacs.009.001.09");
			
			CreateSwiftService createSwiftService = new CreateSwiftService(instruccion, swfMencamposIsoDaoImpl);
			createSwiftService.setSessionFactory(sessionFactorySioc);
			
			createSwiftService.initInstruccion();
			MappingTable mappingTable = createSwiftService.getMappingTable();
			
			List<String> l = Arrays.asList("inftrx", "dbtrAgt", "instg", "cdtrAgt", "intrmy", "rmtInf", "chrBear", "instrInf", "dbtr", "cdtr");
			l.forEach(c -> {
				swiftMessageService.obtenerFacts(swiftDatos, c, mappingTable);
			});
			createSwiftService.recuperarSwfCampos(swfMsgParam.getMenIdTMessageTx(), "8");
			createSwiftService.generaHeaderMsg();
			createSwiftService.initEngine();
			createSwiftService.createMsgSwift();
			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	@Test
	public void generateTreeSwfCamposMT1Test() {
		try {
			log.info("================================");
			Instruccion instruccion = initSwfParams(null);

			CreateSwiftService createSwiftService = new CreateSwiftService(instruccion, swfMencamposIsoDaoImpl);
			createSwiftService.setSessionFactory(sessionFactorySioc);

			instruccion.getTreeMencampos().forEach((k, v) -> {
				log.info(k + " : " + v.toStringID() + " => " + v.getMtfXmltag() + " " + v.getMtfExpresion());
			});

			String socCodigo = "031803";
			SwiftDatos swiftDatos = createSwiftDatos(socCodigo);

			MappingTable mappingTable = new MappingTable(instruccion.getSwfMsgParam().getMenTypemessage(),
					FileFormat.valueOf(instruccion.getSwfMsgParam().getMenFormato()), FileFormat.MX);
			
			mappingTable.putFact("instrucc", instruccion.getSwfMsgParam());
			
			List<String> l = Arrays.asList("inftrx", "dbtrAgt", "instg", "cdtrAgt", "intrmy", "rmtInf", "chrBear", "instrInf", "dbtr", "cdtr");

			l.forEach(c -> {
				swiftMessageService.obtenerFacts(swiftDatos, c, mappingTable);
			});

			mappingTable.getMapFacts().forEach((k, v) -> {
				log.info("FACTS " + k + " => " + v);
			});

			l.forEach(c -> {
				CampoFormTable cft = (CampoFormTable) mappingTable.fact(c);
				if (cft != null)
					cft.getAtrib().forEach((k, v) -> {
						log.info(cft.getTabla() + " ==> " + k + " :: " + v + " " + cft.atrS(k));
					});
			});

			List<SwfMencampos> swfMencamposList = instruccion.getTreeMencampos().values().stream().collect(Collectors.toList());

			FormatEngine formatEngine = FormatEngine.getInstance().readRulesExt(swfMencamposList, instruccion.getSwfMsgParam().getMenFormato())
					.initEngineRules();

			MappingTable mpptab = formatEngine.translate(mappingTable).getMpptabResult();
			mpptab.setTypeMessage(instruccion.getSwfMsgParam().getMenTypemessage());

			Map<String, String> mxProp = mpptab.toProperties();

			log.info("PROP PROP PROP PROP PROP PROP PROP PROP ");
			mxProp.forEach((k, v) -> {
				log.info(k + " => " + v);
			});

			String mxXml = mpptab.toXML();

			log.info("XML XML XML XML XML XML XML XML XML  ");
			log.info(mxXml);

//			SwiftMessageAbstract swiftMessageAbstract = mpptab.returnSwiftMessage();
//			mxXml = swiftMessageAbstract.genMenPlano();
			log.info("MX MX MX MX MX MX MX ");
			MxId id = new MxId("pacs.009.001.09");
			mxXml = "<Document>" + mxXml+"</Document>";
			AbstractMX mx = AbstractMX.parse(mxXml, id);
			log.info("mxxxxxxxxxxxxxxxxxxx  " + (mx == null));
			//MxSwiftMessage mt = new MxSwiftMessage(menPlano);			 
			mxXml = mx.message();
			log.info(mxXml);
			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}

	}

	public static List<SwfMencampos> getRules(Document doc, HashMap<Integer, SwfMencampos> mapCmp, String exprin) {
		String expr = String.format(exprin + "/*");
		XPath xpath = DocumentHelper.createXPath(expr);
		List<Node> nodes = xpath.selectNodes(doc);
		// 3- Make the change on the selected nodes
//        log.info("ssssssss " + nodes.size());
		List<SwfMencampos> nods = new ArrayList<>();
		for (int i = 0; i < nodes.size(); i++) {
			Element e = (Element) nodes.get(i);
			SwfMencampos pos = mapCmp.get(Integer.parseInt(e.getText()));
			nods.add(pos);
		}
		return nods;
	}

	public Instruccion initSwfParams(SwfMensaje swfMensaje) {
		Instruccion instruccion = new Instruccion();

		SwfMsgParam swfMsgParam = new SwfMsgParam();

		swfMsgParam.setMenIdTMessageTx(swfMensaje.getMenCodmt());
		swfMsgParam.setMenEmisor(swfMensaje.getMenBicemisor());
		swfMsgParam.setMenReceiver(swfMensaje.getMenBic());
		swfMsgParam.setMenReceiver(swfMensaje.getMenBic());
		swfMsgParam.setMenCodmen(swfMensaje.getMenCodmen());
		swfMsgParam.setMenCodmenrefer(swfMensaje.getMenCodoperacion());
		String codigoOperacion = String.valueOf(swfMensaje.getMenCodoperacion() + "" + swfMensaje.getMenDetcodigo());
		swfMsgParam.setMenIdoperacion(codigoOperacion);
		swfMsgParam.setMenGestion(swfMensaje.getMenGestion());
		swfMsgParam.setMenNrocorr(swfMensaje.getMenNrocorr());
		swfMsgParam.setMenTypemessage(swfMensaje.getMenCodmt());
		swfMsgParam.setMenEmisor(swfMensaje.getMenBicemisor());
		swfMsgParam.setMenBic(swfMensaje.getMenBic());
		swfMsgParam.setMenCodmon(swfMensaje.getMenCodmonswift());
		swfMsgParam.setMenFecreg(swfMensaje.getMenFecreg());
		swfMsgParam.setMenFecauto(swfMensaje.getMenFecauto());
		swfMsgParam.setMenEstmensaje(swfMensaje.getMenCveestswift());
		swfMsgParam.setMenCodusrswf(swfMensaje.getMenCodusrswf());
		swfMsgParam.setMenPlano(swfMensaje.getMenPlano());
		swfMsgParam.setMenNrocorr(swfMensaje.getMenNrolavado());
		
		instruccion.setSwfMsgParam(swfMsgParam);

		return instruccion;
	}

	public SwiftDatos createSwiftDatos(String socCodigo) {

		Solicitud solicitud = populateSolicitudTO(socCodigo);
		log.info("solic " + solicitud.getSolicitud().getClaEstado());

		SwiftDatos swiftDatos = new SwiftDatos();

		swiftDatos.setAuditusr(solicitud.getSolicitud().getUsrCodigo());
		swiftDatos.setAuditwst(solicitud.getSolicitud().getEstacion());

		swiftDatos.setSolicitudTO(solicitud);
		swiftDatos.setSocDetallessol(solicitud.getSocDetallessolLista().get(0));

//		SwfMensaje swfMensaje = new SwfMensaje();
//		swfMensaje.setMenCodoperacion(solicitud.getSolicitud().getSocCodigo());
//		swfMensaje.setMenDetcodigo(solicitud.getSocDetallessolLista().get(0).getId().getDetCodigo());

		SocDetallessol socDetallessol = solicitud.getSocDetallessolLista().get(0);
		SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
		
		swfMensaje.setMenCodmt(socDetallessol.getDetCodttransfer());
		swfMensaje.setMenMonto(socDetallessol.getDetMontotrans());
		swfMensaje.setMenCodmon(solicitud.getSolicitud().getCodMonedat());
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenFecvalor(solicitud.getSolicitud().getFechaCont());
		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PEND);
		swfMensaje.setMenAuditusr(solicitud.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitud.getCodEstacionAudit());

		SwfMttransfer swfMttransfer = new SwfMttransfer();
		swfMttransfer.setMttCodttransfer(socDetallessol.getDetCodttransfer());
		swfMttransfer.setMttFormato(FileFormat.MT.toString());
		
		swiftDatos.setSwfMttransfer(swfMttransfer);
		swiftDatos.setSwfMensaje(swfMensaje);
		return swiftDatos;
	}

}
