package gob.bcb.core.utils;

import org.junit.jupiter.api.Test;

public class UtilsXMLTest {
	@Test
	public void extractTagXML() {
		String mensajeXML = UtilsFile.readFileAsString2("e:/tmp/V01_03.xml");
		try {
			String keyName = UtilsXML.tagToString(mensajeXML, "servicio_sioc");
			System.out.println(keyName);
			keyName = UtilsXML.tagToString(mensajeXML, "ds:KeyName");
			System.out.println(keyName);
			
			System.out.println("***********************************");
			
			keyName = UtilsXML.valueOfTag(mensajeXML, "servicio_sioc");
			System.out.println(keyName);
			System.out.println(" ******************************** ");
			keyName = UtilsXML.valueOfTag(mensajeXML, "ds:KeyName");
			System.out.println(keyName);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
