package gob.bcb.service.servicioSioc.logic;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.jupiter.api.Test;

import gob.bcb.service.config.BaseData;

public class FacturasTest  extends BaseData {
	private static final Log log = LogFactory.getLog(BeneficiariosTest.class);
	
	@Test
	public void consultaWSBenefs() throws Exception {
		log.info("========== consultaWSBenefs =============");
		iniciarDaos();		
		
		//String filexml = "src/test/resources/mensmefp/C01_MEN.xml";
		String filexml = "src/test/resources/mensmefp/v10_273.xml";
		String cod = System.nanoTime() + "";
		String newstr = readAndChangeCodsolic(filexml, cod);
		procesarXML(newstr); 
		log.info("hechoooooooooooooooooooooooooooooo");
		
		log.info("hechoooooooooooooooooooooooooooooo");
	}	
}
