package gob.bcb.swift.service;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.jupiter.api.Test;

import com.prowidesoftware.swift.model.mt.AbstractMT;

import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.Node;
import gob.bcb.iso20022.swift.CreateFieldSwf;
import gob.bcb.iso20022.swift.TemplateGenFSwf;
import gob.bcb.service.config.BaseData;

public class CreateSwiftServiceTest extends BaseData {
	private static final Log log = LogFactory.getLog(CreateSwiftServiceTest.class);

	
//	//@Test
//	public void generateTreeSwfCamposMTTest() {
//		try {
//			log.info("================================");
//			Instruccion instruccion = initSwfParams();
//			
//			CreateSwiftService createSwiftService = new CreateSwiftService(instruccion);
//			createSwiftService.setSessionFactory(sessionFactorySioc);
//
//			Node padre = Node.createNodeDefault("543", "4");
//			Function<SwfMencampos, Optional<Supplier<Node>>> nextSwfMencamposF = createSwiftService.nextSwfMencampos(null, padre);
//
//			Node nodeResult = createSwiftService.generateTreeSwfCampos((SwfMencampos) nextSwfMencamposF, null);
//			log.info("==============================");
//			nodeResult.print(0);
//
//			
//		} catch (Exception e) {
//			log.error("error " + e.getMessage(), e);
//		}
//		
//	}
//	
////	@Test
//	public void generateTreeSwfCamposMXTest() {
//		try {
//			log.info("================================");
//			Instruccion instruccion = initSwfParams();
//			
//			CreateSwiftService createSwiftService = new CreateSwiftService(instruccion);
//			createSwiftService.setSessionFactory(sessionFactorySioc);
//			//String xml = createSwiftService.toXml("pacs.009.MTTOMX", ""); //pacs.009.MTTOMX
////			log.info("==============================");
////			log.info(xml);
//		} catch (Exception e) {
//			log.error("error " + e.getMessage(), e);
//		}
//		
//	}	
//	//@Test
//	public void createAbstractMT() {
//		try {
//			log.info("================================");
//			Instruccion instruccion = initSwfParams();
//			
//			CreateSwiftService createSwiftService = new CreateSwiftService(instruccion);
//			createSwiftService.setSessionFactory(sessionFactorySioc);
//			
//			createSwiftService.generateMsg();
//			//createSwiftService.settingMT(mt);
//			
//		} catch (Exception e) {
//			log.error("error " + e.getMessage(), e);
//		}
//		
//	}
//	
////	@Test
//	public void createSwiftMT() {
//		try {
//			log.info("================================");
//			Instruccion instruccion = initSwfParams();
//			
//			CreateSwiftService createSwiftService = new CreateSwiftService(instruccion);
//			createSwiftService.setSessionFactory(sessionFactorySioc);
//			
//		
//			createSwiftService.generateMsg();
//			
//		} catch (Exception e) {
//			log.error("error " + e.getMessage(), e);
//		}
//		
//	}
//
//	
//	public Instruccion initSwfParams() {
//		Instruccion instruccion = new Instruccion();
//		
//		SwfMsgParam swfMsgParam = new SwfMsgParam();
//		swfMsgParam.setMenTypemessage("103");
//		swfMsgParam.setMenIdTMessageTx("103A");
//		swfMsgParam.setMenEmisor("BCEBBOLPXXX");
//		swfMsgParam.setMenReceiver("ABNANL2AXXX");
//		
//		instruccion.setSwfMsgParam(swfMsgParam);
//		
//		return instruccion;
//	}
}
