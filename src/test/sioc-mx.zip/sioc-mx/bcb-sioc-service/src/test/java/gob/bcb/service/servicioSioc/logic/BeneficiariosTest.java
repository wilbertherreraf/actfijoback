package gob.bcb.service.servicioSioc.logic;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.jupiter.api.Test;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CarCartascrDao;
import gob.bcb.bpm.pruebaCU.CarCartascrdetDao;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.servicioSioc.common.Constants;

public class BeneficiariosTest extends BaseData {
	private static final Log log = LogFactory.getLog(BeneficiariosTest.class);

//	public void iniciarDaos0() {
//		socDetallessolDao = (SocDetallessolDao) applicationContext.getBean("socDetallessolDao");
//		carCartascrDao = (CarCartascrDao) applicationContext.getBean("carCartascrDao");
//		carCartascrdetDao = (CarCartascrdetDao) applicationContext.getBean("carCartascrdetDao");
//		socSolicitudctasDao = (SocSolicitudctasDao) applicationContext.getBean("socSolicitudctasDao");
//		socSolicitudesDao = (SocSolicitudesDao) applicationContext.getBean("socSolicitudesDao");
//		socCuentassolDao = (SocCuentassolDao) applicationContext.getBean("socCuentassolDao");
//		socOpecomiDao = (SocOpecomiDao) applicationContext.getBean("socOpecomiDao");
//		socBenefsDao = (SocBenefsDao) applicationContext.getBean("socBenefsDao");
//		procesosSolicitud.setSessionFactory(sessionFactorySioc);
//		actualizarAFecha.setSessionFactory(sessionFactorySioc);
//		registrarSolicitud.setSessionFactory(sessionFactorySioc);
//
//		cartasCredService = new CartasCredService(sessionFactorySioc, sessionFactoryCoin);
//
//	}
//
//	// @Test
//	public void consultaWSBenefs() throws Exception {
//		log.info("========== consultaWSBenefs =============");
//		iniciarDaos();
//
//		// String filexml = "src/test/resources/mensmefp/C01_MEN.xml";
//		String filexml = "src/test/resources/mensmefp/FACT_02.XML";
//		String cod = System.nanoTime() + "";
//		String newstr = readAndChangeCodsolic(filexml, cod);
//		// procesarXML(newstr);
//		log.info("hechoooooooooooooooooooooooooooooo");
//
//		log.info("hechoooooooooooooooooooooooooooooo");
//	}
//
	@Test
	public void consultaBenefs() {
		try {
			log.info("========== consultaWSBenefs =============");
			iniciarDaos();
			String benNombre = "";
			String solCodigo = "";
			String ctaNrocuenta = "";
			Short claVigenteBen = Short.valueOf("2");
			Short claVigente = Short.valueOf("2");
			String tipoUso = Constants.CVE_BENTIPOUSO_TE;
			List<Beneficiario> beneficiarios = socBenefsDao.beneficiariosExt(benNombre, solCodigo, ctaNrocuenta, null, claVigente, tipoUso);
			List<String> codBens = beneficiarios.stream().map(b -> b.getSocBenefs().getBenCodigo().trim()).distinct().collect(Collectors.toList());
			
			beneficiarios.forEach(b -> {
				log.info("ben " + b.getBenCodigo()+ " -> " + b.getSocBenefs().getClaVigente());
			});
			
			List<Beneficiario> beneficiarios2 = socBenefsDao.beneficiariosExt(benNombre, solCodigo, ctaNrocuenta, claVigenteBen, null, tipoUso);
			for (Beneficiario ben : beneficiarios2) {
				if (!codBens.stream().anyMatch(s -> s.equalsIgnoreCase(ben.getSocBenefs().getBenCodigo().trim()))) {
					beneficiarios.add(ben);
				}
			}
			
			beneficiarios2.forEach(b -> {
				log.info("	ben " + b.getBenCodigo()+ " -> " + b.getSocBenefs().getClaVigente());
			});
			log.info("hechooo " + beneficiarios.size() + " " + beneficiarios2.size());
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

//	@Test
	public void consultaBenefs0() {
			log.info("========== consultaWSBenefs =============");
	}
}
