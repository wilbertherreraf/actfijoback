package gob.bcb.swift.dao;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.jupiter.api.Test;

import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.swift.CreateFieldSwf;
import gob.bcb.iso20022.swift.FieldSwf;
import gob.bcb.iso20022.swift.FieldSwfMx;
import gob.bcb.iso20022.swift.TemplateGenFSwf;
import gob.bcb.service.config.BaseData;
import gob.bcb.swift.model.SwfMencamposDb;
import gob.bcb.swift.service.SwfMencamposIsoDaoImpl;

public class SwfMencamposDbDaoTest extends BaseData {
	private static final Log log = LogFactory.getLog(SwfMencamposDbDaoTest.class);

	//@Test
	public void findMTTest() {
		try {
			log.info("================================");
			log.info("swfMencamposDbDao " + (swfMencamposDbDao == null));
			List<SwfMencamposDb> list = swfMencamposDbDao.findByMT("103", "4");
			list.forEach(c -> {
				log.info(c.getMtfCodcampo() + " -> " + c.getMtfDescrip());
			});

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}

	}

	@Test
	public void swfcambposToXMLTest() {
		try {
			log.info("================================");
			log.info("swfMencamposDbDao " + (swfMencamposDbDao == null));
			List<SwfMencampos> list = swfMencamposDbDao.findByMT("pacs.009.MTTOMX", "").stream().map(SwfMencamposIsoDaoImpl.cloneSwfMencamposDb()).collect(Collectors.toList());
			
			HashMap<Integer, SwfMencampos> swfCamposMap = new HashMap<Integer, SwfMencampos>();
			HashMap<Integer, SwfMencampos> campos = FieldSwfMx.camposToMap(list, swfCamposMap);
			LinkedHashMap<String, Object> props = FieldSwfMx.toProps(campos, true);
			HashMap<String, Integer> propsI = new HashMap<>();
			
			HashMap<Integer, SwfMencampos> noAssigns = new HashMap<>();
			props.forEach((k, v) -> {
				//log.info(k + " -> " + v);
				propsI.put(k, Integer.parseInt(v.toString()));
			});

			swfCamposMap.forEach((k, v) -> {
			//	log.info(k + " ===> " + v.getMtfXmltag() + " :: "+ v.getMtfNemo());
				if (!propsI.containsValue(k)) {
					noAssigns.put(k, v);
				}
			});
			
			String xml = XmlToMap.xmlFromXPath4J(props);
			log.info("xml xml xml xml xml xml xml xml xml xml xml xml ");
			log.info(xml);
			
			noAssigns.forEach((k,v) -> {
				//log.info(k + " ----> " + v.getMtfXmltag());
			});
			
			List<SwfMencampos> scl = XmlToMap.xmlToTreeList(xml, swfCamposMap);
			log.info("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn ");
			scl.forEach(c -> {
				log.info(c.getMtfId() + " : " + c.getMtfXmltag() + " :: " + c.getMtfNemo());
			});
			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
	
	
}
