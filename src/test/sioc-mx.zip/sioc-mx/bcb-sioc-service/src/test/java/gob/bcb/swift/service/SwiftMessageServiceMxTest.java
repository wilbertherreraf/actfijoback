package gob.bcb.swift.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.Test;

import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.field.Field;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.MappingTable;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.translate.FormatEngine;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.servicioSioc.ClienteLvdSioc;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.model.SwfMencamposDb;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.model.SwfMttransferdet;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.pojos.SwiftMessageBcb;

public class SwiftMessageServiceMxTest extends BaseData {
	private static final Logger log = Logger.getLogger(SwiftMessageServiceMxTest.class);
	private final static String MPPBAS_FILE = "src/test/resources/xls/mppbassioc.xlsx";
	private final static String mt103_pacs008_SHEET = "mt103_pacs.008";
	private final static String mt202_pacs009_SHEET = "mt202_pacs.009";
	private final static Integer firstRowData = 2;

	// @Test
	public void generarSwift103UnqTest() {
		try {
			log.info("inicio ");

			String socCodigo = "032808";
			SwiftDatos swiftDatos = createSwiftDatos(socCodigo);
			swiftDatos.getSwfMensaje().setMenCodmt("103A");

			swiftMessageService.generarMensaje(swiftDatos);
			swiftMessageService.actualizarCampo(swiftDatos, "20", 4, "valorn");

		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	// @Test
	public void generarSwift103XTest() {
		try {
			log.info("inicio {} " + (swfMttransferdetBean == null) + " - " + (swiftMessageService == null));

			String typeMessage = "103";

			FormatEngine formatEngine = FormatEngine.getInstance().configRulesXls(MPPBAS_FILE, mt103_pacs008_SHEET, firstRowData)//
					.readRulesXls("pacs")//
					.initEngineRules()//
			;
			String socCodigo = "032808";
			SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb();
			SwiftDatos swiftDatos = createSwiftDatos(socCodigo);
			SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
			String mt = swiftDatos.getSwfMensaje().getMenCodmt();
			List<SwfMttransferdet> SwfMttransferdetLista = swfMttransferdetBean.findByCodTTransfer(mt, 4);

			MappingTable mappingTable = new MappingTable(typeMessage, FileFormat.MT, FileFormat.MT);
			mappingTable.putFact("sender", swfMensaje.getMenBicemisor());
			mappingTable.putFact("receiver", swfMensaje.getMenBic());

			List<Field> fields = new ArrayList<>();
			swiftDatos.setMappingTable(mappingTable);

			List<SwfMencamposDb> swfMencamposDbList = swfMencamposDbDao.findByMT(swiftDatos.getSwfMensaje().getMenCodmt(), "4");
			swfMencamposDbList.forEach(c -> {
				Field field = swiftMessageService.obtenerValor(swiftDatos, swiftDatos.getSwfMensaje(), c);
				if (field != null) {
					fields.add(field);
				}
			});
			log.info(" ******************** field ************* ");
			fields.forEach(f -> {
				log.info("Field " + f.getName() + " => " + f.getValue());
				mappingTable.putFact("F" + f.getName().toUpperCase(), f);
				mappingTable.addTag(f);

			});

			MappingTable mpptab = formatEngine.translate(mappingTable).getMpptabResult();
			mpptab.setTypeMessage(typeMessage);

			Map<String, String> mxProp = mpptab.toProperties();

			log.info("PROP PROP PROP PROP PROP PROP PROP PROP ");
			mxProp.forEach((k, v) -> {
				log.info(k + " => " + v);
			});

			String mxXml = mpptab.toXML();

			log.info("XML XML XML XML XML XML XML XML XML  ");
			log.info(mxXml);

			SwiftMessageAbstract swiftMessageAbstract = mpptab.returnSwiftMessage();
			mxXml = swiftMessageAbstract.genMenPlano();
			log.info("MX MX MX MX MX MX MX ");
			log.info(mxXml);

		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}

	}

	// @Test
	public void generarSwiftPacs009Test() {
		try {
			log.info("inicio ");
			log.info("inicio {} " + (swfMttransferdetBean == null) + " - " + (swiftMessageService == null));

			String typeMessage = "pacs.009.001.09";
			MappingTable mappingTable = new MappingTable(typeMessage, FileFormat.MT, FileFormat.MX);

			FormatEngine formatEngine = FormatEngine.getInstance().configRulesXls(MPPBAS_FILE, mt202_pacs009_SHEET, firstRowData)//
					.readRulesXls("pacs")//
					.initEngineRules()//
			;

			SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb();
			SwiftDatos swiftDatos = createSwiftDatos("032774");
			SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
			String mt = swiftDatos.getSwfMensaje().getMenCodmt();
			List<SwfMttransferdet> SwfMttransferdetLista = swfMttransferdetBean.findByCodTTransfer(mt, 4);

			mappingTable.putFact("sender", swfMensaje.getMenBicemisor());
			mappingTable.putFact("receiver", swfMensaje.getMenBic());

			List<Field> fields = new ArrayList<>();

			List<SwfMencamposDb> swfMencamposDbList = swfMencamposDbDao.findByMT(swiftDatos.getSwfMensaje().getMenCodmt(), "4");
			swfMencamposDbList.forEach(c -> {
				Field field = swiftMessageService.obtenerValor(swiftDatos, swiftDatos.getSwfMensaje(), c);
				if (field != null) {
					fields.add(field);
				}
			});

			log.info(" ******************** field ************* ");
			fields.forEach(f -> {
				log.info("Field " + f.getName() + " => " + f.getValue());
				mappingTable.putFact("F" + f.getName().toUpperCase(), f);
			});

			MappingTable mpptab = formatEngine.translate(mappingTable).getMpptabResult();

			Map<String, String> mxProp = mpptab.toProperties();

			log.info("PROP PROP PROP PROP PROP PROP PROP PROP ");
			mxProp.forEach((k, v) -> {
				log.info(k + " => " + v);
			});

			String mxXml = mpptab.toXML();

			log.info("XML XML XML XML XML XML XML XML XML  ");
			log.info(mxXml);
			SwiftMessageAbstract swiftMessageAbstract = mpptab.returnSwiftMessage();
			mxXml = swiftMessageAbstract.genMenPlano();
			log.info("MX MX MX MX MX MX MX ");
			log.info(mxXml);

		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}

	}

	@Test
	public void generarSwiftMXMasiveTest() {
		String urlLavado = "http://10.3.11.82:8881/lavado/";
		try {
			List<String> list = Arrays.asList("030583", "030584", "030585", "030586", "030587", "030594", "030590", "030612", "030615", "030621", "030622",
					"030619", "030618", "030620", "030881", "030873", "030892", "030892");

			list.forEach(c -> {

				String socCodigo = c;
				log.info("***************************[ " + c + "] ***************************");
				SwiftDatos swiftDatos = createSwiftDatos(socCodigo);
				swiftDatos.getSwfMensaje().setMenCodmt("pacs.009.MTTOMX");
				long tini = System.currentTimeMillis();
				CreateSwiftService createSwiftService = swiftMessageService.generarMensajeSwift(swiftDatos);
				String msg = createSwiftService.getInstruccion().getMessageHolder().getMenPlano();
				// log.info(msg);

				ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc();
				clienteLvdSioc.initClienteLvd(urlLavado);
				clienteLvdSioc.scanMensaje(msg);
				long tfin = System.currentTimeMillis();
				log.info("duracion " + (tfin - tini) + " (ms.)");
			});

		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	public SwiftDatos createSwiftDatos(String socCodigo) {

		Solicitud solicitud = populateSolicitudTO(socCodigo);
		log.info("solic " + solicitud.getSolicitud().getClaEstado());

		SwiftDatos swiftDatos = new SwiftDatos();

		swiftDatos.setAuditusr(solicitud.getSolicitud().getUsrCodigo());
		swiftDatos.setAuditwst(solicitud.getSolicitud().getEstacion());

		swiftDatos.setSolicitudTO(solicitud);
		swiftDatos.setSocDetallessol(solicitud.getSocDetallessolLista().get(0));

		SocDetallessol socDetallessol = solicitud.getSocDetallessolLista().get(0);
		SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());

		swfMensaje.setMenCodmt(socDetallessol.getDetCodttransfer());
		swfMensaje.setMenMonto(socDetallessol.getDetMontotrans());
		swfMensaje.setMenCodmon(solicitud.getSolicitud().getCodMonedat());
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenFecvalor(solicitud.getSolicitud().getFechaCont());
		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PEND);
		swfMensaje.setMenAuditusr(solicitud.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitud.getCodEstacionAudit());

		SwfMttransfer swfMttransfer = new SwfMttransfer();
		swfMttransfer.setMttCodttransfer(socDetallessol.getDetCodttransfer());
		swfMttransfer.setMttFormato(FileFormat.MT.toString());

		swiftDatos.setSwfMttransfer(swfMttransfer);
		swiftDatos.setSwfMensaje(swfMensaje);
		return swiftDatos;
	}
}
