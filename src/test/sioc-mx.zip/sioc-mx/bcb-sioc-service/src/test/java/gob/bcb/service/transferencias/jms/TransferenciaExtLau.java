package gob.bcb.service.transferencias.jms;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.jupiter.api.Test;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

public class TransferenciaExtLau extends BaseData {
	private static final Log log = LogFactory.getLog(TransferenciaExtLau.class);
	
	//@Test
	public void cargarXMLFromSigepTest(){
		log.info("========== cargarXMLFromSigepTest =============");
		String filexml = "src/test/resources/mensmefp/t01_512.xml";
		SocSolicitudes socSolicitudes = cargarXMLFromSigepTest(filexml);
	}	

	//@Test
	public void actualizarAfechaSolicitudTest() {
		log.info("========== actualizarAfechaSolicitudTest =============");
	
		actualizarAFechaTest("006608");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		actualizarAFechaTest("006608");
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		actualizarAFechaTest("006608");
		//rechazarTest("006491");
	}
	
	@Test
	public void preautorizarSolicitudTest() {
		log.info("========== preautorizarSolicitudTest =============");

		preautorizarTest("032919");
	}
	
	//@Test
	public void autorizarSolicitudTest() {
		log.info("========== autorizarSolicitudTest =============");
	
		autorizarTest("032918");
	}
	
	public void actualizarAFechaTest(String socCodigo) {
		log.info("========== actualizarAFechaTest =============");
		Date fecha = new Date();		
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		solicitudTO.getSolicitud().setFechaCont(fecha);		
		//solicitudTO = procesar(solicitudTO, "ACT_A_FECHA");
		solicitudTO = procesarSinError(solicitudTO, "ACT_A_FECHA");
		if (solicitudTO != null && StringUtils.isBlank(solicitudTO.getSolicitud().getSocCodigo())) {
			throw new BusinessException("El servicio no retorna el codigo de la solicitud");
		}

		//log.info("Fin preautorizarSolicitudTest " + solicitudTO.getSolicitud().getSocCodigo());
	}	
	public void preautorizarTest(String socCodigo) {
		log.info("========== preautorizarTest =============");
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		solicitudTO = procesar(solicitudTO, "REG_SOLICITUD");
		if (StringUtils.isBlank(solicitudTO.getSolicitud().getSocCodigo())) {
			throw new BusinessException("El servicio no retorna el codigo de la solicitud");
		}
		Date fecha = new Date();
		solicitudTO.getSolicitud().setFechaCont(fecha);
		solicitudTO = procesar(solicitudTO, "PREAUT");
		log.info("Fin preautorizarSolicitudTest " + solicitudTO.getSolicitud().getSocCodigo());
	}

	public void autorizarTest(String socCodigo) {
		log.info("========== autorizarTest =============");
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			procesar(solicitudTO, "AUTSWFT");
		}
		log.info("========== autorizarTest =============*********************");
		solicitudTO = populateSolicitudTO(socCodigo);
		procesar(solicitudTO, "AUTSOL");

		log.info("Fin autorizarTest " + solicitudTO.getSolicitud().getSocCodigo());
	}
	
	public void rechazarTest(String socCodigo) {
		log.info("========== rechazarTest =============");
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		procesar(solicitudTO, "RECHAZARSOL");

		log.info("Fin rechazarTest " + solicitudTO.getSolicitud().getSocCodigo());
	}
	
	
	public SocSolicitudes cargarXMLFromSigepTest(String filexml){
		log.info("========== cargarXMLFromSigepTest =============");
		String cod = System.nanoTime() + "";
		String newstr = readAndChangeCodsolic(filexml, cod);
		procesarXML(newstr);
		log.info("hechoooooooooooooooooooooooooooooo");
	
		//iniciarDaos();
		SocSolicitudes socSolicitudes = socSolicitudesDao.getByCodSolicitudorig(cod);
		log.info("Codigo solicitud " + socSolicitudes.getSocCodigo());
		return socSolicitudes;
	}	
	
	public void iniciarDaos0() {
		socDetallessolDao = (SocDetallessolDao) applicationContext.getBean("socDetallessolDao");
		socSolicitudctasDao = (SocSolicitudctasDao) applicationContext.getBean("socSolicitudctasDao");
		socSolicitudesDao = (SocSolicitudesDao) applicationContext.getBean("socSolicitudesDao");
		socCuentassolDao = (SocCuentassolDao) applicationContext.getBean("socCuentassolDao");
		socOpecomiDao = (SocOpecomiDao) applicationContext.getBean("socOpecomiDao");
		socBenefsDao = (SocBenefsDao) applicationContext.getBean("socBenefsDao");
		procesosSolicitud.setSessionFactory(sessionFactorySioc);
		actualizarAFecha.setSessionFactory(sessionFactorySioc);
		registrarSolicitud.setSessionFactory(sessionFactorySioc);
	}
	
	public void iniciarDaosTrans() {
		QueryProcessor.setSessionFactory(sessionFactorySioc);
		SiocCoinService.setSessionFactory(sessionFactoryCoin);

		QueryProcessor.begin();
		SiocCoinService.begin();
	}
	
	public void finalizarDaos() {
		SiocCoinService.commit();
		QueryProcessor.commit();
	}
}
