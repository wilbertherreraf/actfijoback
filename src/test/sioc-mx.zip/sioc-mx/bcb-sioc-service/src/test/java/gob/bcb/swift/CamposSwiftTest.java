package gob.bcb.swift;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;

import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field23B;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field50A;
import com.prowidesoftware.swift.model.field.Field50F;
import com.prowidesoftware.swift.model.field.Field59;
import com.prowidesoftware.swift.model.field.Field71A;
import com.prowidesoftware.swift.model.mt.mt1xx.MT103;

import gob.bcb.core.utils.UtilsDate;

public class CamposSwiftTest {
    public void main00(String[] args) throws Exception {
		/*
		 * Create the MT class, it will be initialized as an outgoing message
		 * with normal priority
		 */
		final MT103 m = new MT103();
	
		/*
		 * Set sender and receiver BIC codes
		 */
		m.setSender("FOOSEDR0AXXX");
		m.setReceiver("FOORECV0XXXX");
	
		/*
		 * Start adding the message's fields in correct order
		 */
		m.addField(new Field20("REFERENCE"));
		m.addField(new Field23B("CRED"));
	
		/*
		 * Add a field using comprehensive setters API
		 */
		Field32A f32A = new Field32A()
			.setDate(Calendar.getInstance())
			.setCurrency("EUR")
			.setAmount("1234567,89");
		m.addField(f32A);
	
		/*
		 * Add the orderer field
		 */
		Field50A f50A = new Field50A()
			.setAccount("12345678901234567890")
			.setBIC("FOOBANKXXXXX");
		m.addField(f50A);
	
		/*
		 * Add the beneficiary field
		 */
		Field59 f59 = new Field59()
			.setAccount("12345678901234567890")
			.setNameAndAddress("JOE DOE");
		m.addField(f59);

		Field field = setField50F("1355", "Banco central de bolivia", "Ayacuho y mercado", "La paz - bolivia");
		m.addField(field);
		/*
		 * Add the commission indication
		 */
		m.addField(new Field71A("OUR"));
	
		
		/*
		 * Create and print out the SWIFT FIN message string
		 */
		System.out.println(m.message());
    }
    
	public static Field setField50F(String ctaNro, String name, String location, String plaza) {
		ctaNro = StringUtils.trim(ctaNro);
		name = StringUtils.trim(name);
		location = StringUtils.trim(location);

		Field50F f = new Field50F();
		f.setComponent1(ctaNro);
		f.setComponent2("1");
		f.setComponent3(name);		
		f.setComponent4("2");
		f.setComponent5(location);		
		f.setComponent6("3");
		f.setComponent7(plaza);		
		//f.setNameAndAddressLine1(nameandlocation);
		return f; // return addField(f);
	}
	
	public static void main(String[] args) {
		BigDecimal montoMN = new BigDecimal("100.00");
		
		BigDecimal redITF = montoMN.divide(BigDecimal.valueOf(1), 0, RoundingMode.HALF_UP);
		
		if (redITF.compareTo(BigDecimal.ZERO) == 0) {
			// el monto es menor a 0.50 bs
			redITF = BigDecimal.ONE;
		}
		
		BigDecimal difCentavos = montoMN.subtract(redITF);
		System.out.println("montoMN " + montoMN.toPlainString() + " redITF: " + redITF.toPlainString() + " difCentavos: " + difCentavos);
		
		UtilsDate.getDifferenceDays(null, null);
	}
}
