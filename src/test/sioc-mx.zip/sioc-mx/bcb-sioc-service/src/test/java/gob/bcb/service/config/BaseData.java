package gob.bcb.service.config;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.StringUtils;

import gob.bcb.bpm.pruebaCU.CarCartascrDao;
import gob.bcb.bpm.pruebaCU.CarCartascrdetDao;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.StatusResponse;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.Utils;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.ActualizarAFecha;
import gob.bcb.service.servicioSioc.logic.CartasCredService;
import gob.bcb.service.servicioSioc.logic.ProcesosSolicitud;
import gob.bcb.service.servicioSioc.logic.RegistrarSolicitud;
import gob.bcb.service.servicioSioc.logic.SwiftSiocService;
import gob.bcb.swift.dao.SwfMencamposDbDao;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.dao.SwfMttransferdetBean;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.service.SwfMencamposIsoDaoImpl;
import gob.bcb.swift.service.SwiftMessageService;

public abstract class BaseData {
	private static final Log log = LogFactory.getLog(BaseData.class);
	protected static ClassPathXmlApplicationContext applicationContext;
	protected ClassPathXmlApplicationContext applicationContextCoin;
	protected static SessionFactory sessionFactorySioc;
	protected static SessionFactory sessionFactoryCoin;
	public static String brokerUrl = "tcp://10.3.11.42:61616?wireFormat.maxInactivityDurationInitalDelay=3"; // "tcp://10.2.11.91:61616?wireFormat.maxInactivityDurationInitalDelay=3";
	// private String brokerUrl = "tcp://localhost:61616";
	public static String requestQueue = "BCB.SUSTANTIVO.BPM.SIOC.QUEUE";
	private static ConnectionFactory connectionFactory;

	public static CartasCredService cartasCredService;
	public static SocSolicitudesDao socSolicitudesDao;
	public static SocDetallessolDao socDetallessolDao;
	public static SocSolicitudctasDao socSolicitudctasDao;
	public static CarCartascrDao carCartascrDao;
	public static CarCartascrdetDao carCartascrdetDao;
	public static SwfMencamposDbDao swfMencamposDbDao = new SwfMencamposDbDao();
	public static SocBenefsDao socBenefsDao;
	public static SwfMttransferdetBean swfMttransferdetBean = new SwfMttransferdetBean();
	public static SwfMttransferBean swfMttransferBean = new SwfMttransferBean();
	public static ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
	public static SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
	public static RegistrarSolicitud registrarSolicitud = new RegistrarSolicitud();
	public static SocOpecomiDao socOpecomiDao;
	public static ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
	public static SwiftMessageService swiftMessageService = new SwiftMessageService();
	public static SwiftSiocService swiftSiocService = new SwiftSiocService();
	public static SwfMencamposIsoDaoImpl swfMencamposIsoDaoImpl = new SwfMencamposIsoDaoImpl();
	public static SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
	
	public static void iniciarDaos() {
		socDetallessolDao = (SocDetallessolDao) applicationContext.getBean("socDetallessolDao");
		carCartascrDao = (CarCartascrDao) applicationContext.getBean("carCartascrDao");
		carCartascrdetDao = (CarCartascrdetDao) applicationContext.getBean("carCartascrdetDao");
		socSolicitudctasDao = (SocSolicitudctasDao) applicationContext.getBean("socSolicitudctasDao");
		socSolicitudesDao = (SocSolicitudesDao) applicationContext.getBean("socSolicitudesDao");
		socCuentassolDao = (SocCuentassolDao) applicationContext.getBean("socCuentassolDao");
		socOpecomiDao = (SocOpecomiDao) applicationContext.getBean("socOpecomiDao");
		socBenefsDao = (SocBenefsDao) applicationContext.getBean("socBenefsDao");
		procesosSolicitud.setSessionFactory(sessionFactorySioc);
		actualizarAFecha.setSessionFactory(sessionFactorySioc);
		registrarSolicitud.setSessionFactory(sessionFactorySioc);
		swfMttransferdetBean.setSessionFactory(sessionFactorySioc);
		swfMttransferBean.setSessionFactory(sessionFactorySioc);
		cartasCredService = new CartasCredService(sessionFactorySioc, sessionFactoryCoin);
		swiftMessageService.setSessionFactory(sessionFactorySioc);
		swiftSiocService.setSessionFactory(sessionFactorySioc);
		swfMencamposDbDao.setSessionFactory(sessionFactorySioc);
		swfMencamposIsoDaoImpl.setSessionFactory(sessionFactorySioc);
		swfMensajeBean.setSessionFactory(sessionFactorySioc);
	}

	@BeforeAll
	public static void setUp() {
		log.info("========== Before setUp =============");
		String pathHome = UtilsProperties.loadFilePropertiesFromClass("service.properties").getProperty("path.home");
		ConfigurationServ.setServiceName(UtilsProperties.loadFilePropertiesFromClass("service.properties").getProperty("service.name"));

		File f = new File(pathHome, ConfigurationServ.CONFIG_PROPERTIES);
		pathHome = StringUtils.cleanPath(new File(f.getAbsolutePath()).getParent());
		ConfigurationServ.setHomeProperty(pathHome);
		ConfigurationServ.init(pathHome);
		log.info("path " + ConfigurationServ.getConfigurationHome());
		brokerUrl = ConfigurationServ.getConfigProperty("jms.broker.url");
		// brokerUrl = "tcp://10.3.11.42:61616";
		gob.bcb.core.jms.Constants.setUrlBroker(brokerUrl);

		applicationContext = new ClassPathXmlApplicationContext("applicationcontextSiocTest.xml", "applicationcontextCoinTest.xml");
		sessionFactorySioc = (SessionFactory) applicationContext.getBean("sessionFactoryBean");
		sessionFactoryCoin = (SessionFactory) applicationContext.getBean("sessionFactoryBeanSiocCoin");

		iniciarDaos();
	}

	// @Test
	public void solicitudesTest() {
		SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) applicationContext.getBean("socSolicitudesDao");

		SocSolicitudes socSolicitudes = socSolicitudesDao.getSolicitud("005219");
		log.info("socSolicitudes " + socSolicitudes.getDetConcepto());
	}

	@AfterAll
	public static void close() {
		log.info("========== After close =============");
		applicationContext.close();
	}

	public static String readAndChangeCodsolic(String archFirmado, String cod) {
		String mensajeXML = UtilsFile.readFileAsString2(archFirmado);
		// String cod = System.nanoTime() + "";
		log.info("Codigo " + cod);
		// String newstr =
		// mensajeXML.replaceAll("(<cod_solicitud_origen>)[^&]*(</cod_solicitud_origen>)",
		// "$1" + cod +"$2");
		mensajeXML = mensajeXML.replaceAll("(<id_mensaje>)[^&]*(</id_mensaje>)", "$1" + cod + "$2");
		return mensajeXML.replaceAll("(<cod_solicitud_origen>)[^&]*(</cod_solicitud_origen>)", "$1" + cod + "$2");
	}

	public static String readAndChangeCodsolic(String archFirmado) {
		String cod = System.nanoTime() + "";
		return readAndChangeCodsolic(archFirmado, cod);
	}

	public static void enviarXMLSigep(String newstr, boolean daemon) throws Exception {
		Map<String, Object> parametrosMsg = new HashMap<String, Object>();

		parametrosMsg.put("opcion", "REG_SOLWS");
		parametrosMsg.put(gob.bcb.service.servicioSioc.common.Constants.COD_IFA_REQUEST, gob.bcb.service.servicioSioc.common.Constants.COD_IFA_MEFP);
		parametrosMsg.put("mensajeXML", newstr);

		thread(new ProducerRunnable(parametrosMsg), daemon);
	}

	public static void procesar(Solicitud solicitudTO, String tipoOperacion, boolean daemon) throws Exception {
		Map<String, Object> parametrosMsg = new HashMap<String, Object>();

		parametrosMsg.put("opcion", tipoOperacion);
		parametrosMsg.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
		parametrosMsg.put(gob.bcb.service.servicioSioc.common.Constants.COD_IFA_REQUEST, gob.bcb.service.servicioSioc.common.Constants.COD_IFA_MEFP);

		thread(new ProducerRunnable(parametrosMsg), daemon);
	}

	public static void thread(Runnable runnable, boolean daemon) {
		log.info("En Treah funcion");
		Thread brokerThread = new Thread(runnable);
		brokerThread.setDaemon(daemon);
		brokerThread.start();
	}

	public static void sendMessage(Map<String, Object> parametrosMsg) throws Exception {
		log.info("En enviar....." + requestQueue);
		// String brokerUrl = "tcp://localhost:61616";
		Map<String, Object> parametros = new HashMap<String, Object>();

		MessageObjectBean messageObjectBean = new MessageObjectBean();
		messageObjectBean.setTransformedMessage(parametrosMsg);

		StatusResponse statusResponse = null;
		if (connectionFactory == null) {
			connectionFactory = initConnectionFactory(brokerUrl);
		}
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(connectionFactory);
		// String usuarioTask = Servicios.getParam("usuarioTask");
		try {
			parametros.put("BCBAddress", "visit.getAddress()");
			parametros.put("BCBIdemisor", "SIOCWS");
			parametros.put("BCBIddestinatario", requestQueue);
			parametros.put("BCBIdusuario", "199");
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOCWS");
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));
			BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"), null,
					null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
			bcbRequestImpl.setDisableReplyTo(false);

			statusResponse = (StatusResponse) bcbRequestImpl.sendMessage();
			if (statusResponse.getResponse() instanceof MessageObjectBean) {
				MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
				Map<String, Object> respuesta = (Map<String, Object>) messageObjectBean1.getTransformedMessage();
				if (respuesta.containsKey("resp_msgerror")) {
					throw new RuntimeException((String) respuesta.get("resp_msgerror"));
				}
				if (respuesta.containsKey("resp_codmsg")) {
					String codRespuesta = (String) respuesta.get("resp_codmsg");
					String descRespuesta = (String) respuesta.get("resp_descripmsg");
					log.info("OOOOOOOOOOO " + codRespuesta + " OOOOOOOOOOOOOO");
					log.info(descRespuesta);
					log.info("OOOOOOOOOOOOOOOOOOOOOOOOO");
				}
				log.info("MMMMMMMMMMMMMMMMMMMMMM");
				// log.info(respuesta);
				log.info("IIIIIIIIIIIIIIIIIIIII");
			} else
				log.info(statusResponse.getDescrip());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			// throw new RuntimeException(e);
		} finally {
			try {
				if (jMSConnectionHandler != null) {
					jMSConnectionHandler.close();
					jMSConnectionHandler.after();
				}
			} catch (Exception e) {
				log.error("Error al cerrar JMS " + e.getMessage(), e);
			}
		}
		log.info("==========================FIN RECIBIDO==========================");
	}

	public static class ProducerRunnable implements Runnable {
		private Map<String, Object> parametrosMsg0 = new HashMap<String, Object>();

		public ProducerRunnable(Map<String, Object> parametrosMsg) {
			this.parametrosMsg0 = parametrosMsg;
		}

		public void run() {
			log.info("En ruuuuuuuuuuuuuuuuuuun.....");
			try {
				sendMessage(parametrosMsg0);
			} catch (Exception e) {
				log.error("error Tread: " + e.getMessage(), e);
				// e.printStackTrace();
			}
		}
	}

	private static ConnectionFactory initConnectionFactory(String urlBroker) {
		// configuracion e inicializacion para colas
		try {
//			Properties props = new Properties();
//			// para el pool
//			props.setProperty("maxConnections", "1");
//			props.setProperty("maximumActive", "2");
//			props.setProperty("brokerURL", urlBroker);
//			ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = new ActiveMQConnectionFactory();
//			
//			amqJNDIPooledConnectionFactory.setProperties(props);
//			log.info("PooledConnectionFactory creado con propiedades " + amqJNDIPooledConnectionFactory.getProperties().toString());
//
//			ConnectionFactory connectionFactory = amqJNDIPooledConnectionFactory;

			ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory(urlBroker);
			log.info("ConnectionFactory creado ::=> \n" + connectionFactory);
			log.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			return activeMQConnectionFactory;
		} catch (Exception e) {
			log.error("Error al crear ConnectionFactory mediante propiedades " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public static Map<String, Object> consultaBPM(String nombreBPM, String ipOrigen, String requester, String feature, Map<String, Object> parametrosMsg,
			String id) {
		StatusResponse statusResponse = null;
		Map<String, Object> parametros = new HashMap<String, Object>();
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();

		log.info("brokerURLbrokerURL " + brokerUrl);
//		if (connectionFactory == null) 
		ConnectionFactory connectionFactory = initConnectionFactory(brokerUrl);

		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(connectionFactory);

		try {
			Thread.sleep(2000);
			jMSConnectionHandler.before();
			parametros.put("BCBAddress", "visit.getAddress()");
			parametros.put("BCBIdemisor", "SIOCWS");
			parametros.put("BCBIddestinatario", requestQueue);
			parametros.put("BCBIdusuario", "199");
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOCWS");
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));
			String nroOperacion = Utils.generateUUID().replaceAll("-", "");

			BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					nroOperacion, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));

			MessageObjectBean messageObjectBean = new MessageObjectBean();
			messageObjectBean.setTransformedMessage(parametrosMsg);

			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
			statusResponse = (StatusResponse) bcbRequestImpl.sendMessage();

			if (statusResponse.getResponse() instanceof MessageObjectBean) {
				MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
				mapaRespuesta = (Map<String, Object>) messageObjectBean1.getTransformedMessage();

			} else {
				mapaRespuesta.put("estado", "-1");
				mapaRespuesta.put("resp_msgerror", statusResponse.getDescrip());

			}

		} catch (Exception e) {
			log.error("Error en mensaje " + nombreBPM, e);
			throw new RuntimeException(e);
		} finally {
			try {
				if (jMSConnectionHandler != null) {
					jMSConnectionHandler.close();
					jMSConnectionHandler.after();
				}
			} catch (Exception e) {
				log.error("Error al cerrar JMS " + e.getMessage(), e);
			}
		}
		return mapaRespuesta;
	}

	public static Solicitud procesar(Solicitud solicitudTO, String tipoOperacion) {
		String codRespuesta = "";
		String descRespuesta = "";
		try {
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", tipoOperacion);
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

			Map<String, Object> respuesta = consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}

			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (NullPointerException e) {
			log.error("NullPointerException error al PROCESAR JMS: " + e.getMessage(), e);
			throw new RuntimeException("NullPointerException error PROCESAR JMS : " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}

	}

	public static Solicitud procesarSinError(Solicitud solicitudTO, String tipoOperacion) {
		String codRespuesta = "";
		String descRespuesta = "";
		try {
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", tipoOperacion);
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

			Map<String, Object> respuesta = consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				return null;
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}

			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}

	}

	public static Solicitud procesarXML(Map<String, Object> mapaParametros) {
		String codRespuesta = "";
		String descRespuesta = "";

		try {
			Map<String, Object> respuesta = consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}
			if (respuesta.containsKey("mensajeXML")) {
				String mensajeXML = (String) respuesta.get("mensajeXML");
				log.info("&&&&&&&&&&&&&&&&& RESPUESTA WS &&&&&&&&&&&&&&&&");
				log.info(mensajeXML);
			}
			log.info(codRespuesta + " - " + descRespuesta);
			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (NullPointerException e) {
			log.error("NullPointerException error al PROCESAR JMS: " + e.getMessage(), e);
			throw new RuntimeException("NullPointerException error PROCESAR JMS : " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}

	}

	public static Solicitud procesarXML(String newstr) {
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "REG_SOLWS");
		mapaParametros.put("mensajeXML", newstr);
		mapaParametros.put(gob.bcb.service.servicioSioc.common.Constants.COD_IFA_REQUEST, gob.bcb.service.servicioSioc.common.Constants.COD_IFA_MEFP);

		return procesarXML(mapaParametros);
	}

	public Solicitud populateSolicitudTO(String socCodigo) {
		Solicitud solicitudTO = procesosSolicitud.recuperarSolicitudSimple(socCodigo);
		SocSolicitudes socSolicitudes = solicitudTO.getSolicitud();
		
		solicitudTO.setsIOCWEB_TIPOPERACION("preauto");

		List<SocSolicitudctas> socSolicitudctasLista = socSolicitudctasDao.getCuentas(socCodigo);
		
		solicitudTO.setSocSolicitudctasLista(socSolicitudctasLista);
		List<SocOpecomi> socOpecomiLista = socOpecomiDao.getByCveTipocomis(socSolicitudes.getSocCodigo(), 0,
				null, "F");
		solicitudTO.setSocOpecomiLista(socOpecomiLista);
		
		for (SocDetallessol socDetallessol : solicitudTO.getSocDetallessolLista()) {
			//log.info("Detalle  Swift " + solicitudTO.getSolicitud().getSocCodigo() + " - " + socDetallessol.getId().getDetCodigo());
			SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(solicitudTO.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo());
			solicitudTO.getSwfMensaje();
		}
		

		return solicitudTO;
	}
	
}
