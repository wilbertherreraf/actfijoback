package gob.bcb.service.servicioSioc.logic;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.Test;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.servicioSioc.ClienteLvdSioc;

public class ClienteLvdSiocTest extends BaseData {
	private static final Logger log = Logger.getLogger(ClienteLvdSiocTest.class);

//	@Test
	public void initCliTest() {
		try {
			ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc();
			clienteLvdSioc.initClienteLvd("http://10.3.11.82:8881/lavado/");
			clienteLvdSioc.getSessionLavado("test");
			SearchResponse searchResponse = clienteLvdSioc.solicitarCorrelativo("codigoOperacion", "test");
			clienteLvdSioc.preautorizarSwift("codigoOperacion", "test", 1000, 10, "plano");
			log.info( "rest " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			clienteLvdSioc.cerrarSession("test");
			
		}catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
	
	@Test
	public void scanSimpleTest() {
		try {
			log.info("ini test scanSimpleTest");
			String filexml = "src/test/resources/mts/M01.txt"; //M01.txt
			String mensajeXML = UtilsFile.readFileAsString2(filexml);
			
			ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc();
			clienteLvdSioc.initClienteLvd("http://10.3.11.82:8881/lavado/");
			try {
			clienteLvdSioc.scanMensaje(mensajeXML);
			}catch (Exception e) {
				log.error("EEEEEE " + e.getMessage());
			}
			log.info("enccccccccccccccccc***********************************************");
			filexml = "src/test/resources/mxpacs01.mx"; //M01.txt
			mensajeXML = UtilsFile.readFileAsString2(filexml);
			
			ClienteLvdSioc clienteLvdSioc2 = new ClienteLvdSioc();
			clienteLvdSioc2.initClienteLvd("http://10.3.11.82:8881/lavado/");
			clienteLvdSioc2.scanMensaje(mensajeXML);
		}catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
}
