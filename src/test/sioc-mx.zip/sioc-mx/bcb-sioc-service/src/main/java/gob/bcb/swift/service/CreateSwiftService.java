package gob.bcb.swift.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prowidesoftware.swift.model.AbstractMessage;

import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.iso20022.dao.SwfMencamposIsoDao;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.swift.CreateFieldSwf;
import gob.bcb.swift.dao.SwfDetmensajeBean;
import gob.bcb.swift.dao.SwfDetmensajeLocal;
import gob.bcb.swift.dao.SwfMencamposDbDao;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMensajeLocal;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.dao.SwfMttransferLocal;
import gob.bcb.swift.dao.SwfPersonactaBean;
import gob.bcb.swift.dao.SwfPersonactaLocal;

@Service("createSwiftService")
public class CreateSwiftService extends CreateFieldSwf {
	private static final Log log = LogFactory.getLog(CreateSwiftService.class);
	
	private SessionFactory sessionFactory;
	@Autowired
	private SwfMencamposDbDao swfMencamposDbDao = new SwfMencamposDbDao();
	
	public CreateSwiftService(Instruccion instruccion, SwfMencamposIsoDao swfMencamposDaoIn) {
		super(instruccion, swfMencamposDaoIn);
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void inicializar() {
		swfMencamposDbDao.setSessionFactory(sessionFactory);
	}

}
