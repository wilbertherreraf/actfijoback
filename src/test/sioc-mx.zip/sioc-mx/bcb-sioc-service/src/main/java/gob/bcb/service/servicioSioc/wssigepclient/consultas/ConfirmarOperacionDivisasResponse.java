
package gob.bcb.service.servicioSioc.wssigepclient.consultas;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for confirmarOperacionDivisasResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="confirmarOperacionDivisasResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="confirmarOperacionDivisasResult" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "confirmarOperacionDivisasResponse", propOrder = {
    "confirmarOperacionDivisasResult"
})
public class ConfirmarOperacionDivisasResponse {

    protected String confirmarOperacionDivisasResult;

    /**
     * Gets the value of the confirmarOperacionDivisasResult property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfirmarOperacionDivisasResult() {
        return confirmarOperacionDivisasResult;
    }

    /**
     * Sets the value of the confirmarOperacionDivisasResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfirmarOperacionDivisasResult(String value) {
        this.confirmarOperacionDivisasResult = value;
    }

}
