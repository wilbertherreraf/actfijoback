package gob.bcb.core.jms.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.MessageAvailableConsumer;
//import org.apache.activemq.pool.AmqJNDIPooledConnectionFactory;
//import org.apache.activemq.pool.PooledConnectionFactory;
import org.apache.log4j.Logger;

public class JMSConnectionHandler {
	// private static final Log log =
	// LogFactory.getLog(JMSConnectionHandler.class);
	private static Logger log = Logger.getLogger(JMSConnectionHandler.class);

	private Session session;
	private MessageProducer producer;
	private MessageConsumer consumer = null;
	private Connection connection;
	private int deliveryMode = DeliveryMode.NON_PERSISTENT;
	private ConnectionFactory connectionFactory;
	// private Properties propiedades;

	public JMSConnectionHandler() {
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = new ActiveMQConnectionFactory();
		// propiedades = amqJNDIPooledConnectionFactory.getProperties();
		// connectionFactory = (PooledConnectionFactory)
		// amqJNDIPooledConnectionFactory;
		connectionFactory = amqJNDIPooledConnectionFactory;
		getPropertiesToString();
	}

	public JMSConnectionHandler(String brokerURL) {
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = new ActiveMQConnectionFactory(brokerURL);
		// propiedades = amqJNDIPooledConnectionFactory.getProperties();
		// connectionFactory = (PooledConnectionFactory)
		// amqJNDIPooledConnectionFactory;
		connectionFactory = amqJNDIPooledConnectionFactory;
		getPropertiesToString();
	}

	public JMSConnectionHandler(ConnectionFactory cf) {
		log.debug("Creando objeto JMSConnectionHandler ");
		if (cf == null) {
			throw new IllegalStateException("ConnectionFactory nulo, inicialice el objeto de conexion JMS");
		}
		connectionFactory = cf;
		// propiedades = activeMQConnectionFactory.getProperties();
		getPropertiesToString();
	}

	public JMSConnectionHandler(Properties prop) {
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = new ActiveMQConnectionFactory();
		amqJNDIPooledConnectionFactory.setProperties(prop);
		// propiedades = amqJNDIPooledConnectionFactory.getProperties();
		// connectionFactory = (PooledConnectionFactory)
		// amqJNDIPooledConnectionFactory;
		connectionFactory = amqJNDIPooledConnectionFactory;
		getPropertiesToString();
	}

	public static synchronized ConnectionFactory initFromPropertiesContext(Properties prop) {
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = null;
		try {
			amqJNDIPooledConnectionFactory = new ActiveMQConnectionFactory();
			amqJNDIPooledConnectionFactory.setProperties(prop);
			log.info("PooledConnectionFactory creado con propiedades " + amqJNDIPooledConnectionFactory.getProperties().toString());
		} catch (Exception e) {
			log.error("Error al iniciar ConnectionFactory " + e.getMessage(), e);
			throw new RuntimeException("Error al iniciar ConnectionFactory " + e.getMessage(), e);
		}

		// return (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
		return amqJNDIPooledConnectionFactory;
	}

	public String getPropertiesToString() {
		log.info("$$$Pool creado con parametros$$$$$");
		ActiveMQConnectionFactory amqJNDIPooledConnectionFactory = (ActiveMQConnectionFactory) connectionFactory;
		log.info("Properties: " + amqJNDIPooledConnectionFactory.getProperties().toString());
		return amqJNDIPooledConnectionFactory.getProperties().toString();
	}

	public void reConnect0() throws JMSException {
		log.info("Intento de reconexion JMS ");
		close();
		session = getSession();
	}

	private Connection getConnection() throws JMSException {
		if (connection == null) {
			connection = connectionFactory.createConnection();
			connection.start();

			log.info("Nueva conexion JMS creada " + connection.getClientID() + "\nMetadata: " + connection);
		}

		return connection;
	}

	public Connection getJmsConnection() {
		return connection;
	}

	protected Session createSession() throws JMSException {
		log.info("Solicitud de Nueva session JMS.");
		return getConnection().createSession(false, Session.AUTO_ACKNOWLEDGE);
	}

	public void send(Destination destination, Message message, boolean persistent, int priority, long timeToLive) throws JMSException {
		log.info("before send to destination: " + destination + " message: " + message);
		producer = session.createProducer(destination);
		producer.send(message, deliveryMode, priority, timeToLive);
		log.info("Sent! to destination: " + destination + " message: " + message);
	}

	public Session getSession() throws JMSException {
		if (session == null) {
			session = createSession();
		}
		return session;
	}

	public MessageConsumer createConsumer(Destination destination, boolean create) throws JMSException {
		consumer = session.createConsumer(destination);
		log.info("Consumer message creado: " + consumer);

		return consumer;
	}

	private void closeConsumer() throws JMSException {
		if (consumer != null) {
			consumer.setMessageListener(null);
			if (consumer instanceof MessageAvailableConsumer) {
				((MessageAvailableConsumer) consumer).setAvailableListener(null);
			}
			consumer.close();
			log.warn("Consumer cerrado...");
		}
	}

	private MessageProducer getProducer() throws JMSException {
		if (producer == null) {
			producer = getSession().createProducer(null);
			producer.setDeliveryMode(deliveryMode);
			log.info("Producer message creado");
		}
		return producer;
	}

	public MessageProducer getJmsProducer() {
		return producer;
	}

	public void close() {
		try {
			if (consumer != null) {
				try {
					consumer.setMessageListener(null);
					if (consumer instanceof MessageAvailableConsumer) {
						((MessageAvailableConsumer) consumer).setAvailableListener(null);
					}
					consumer.close();
					log.warn("Consumer cerrado...");
				} catch (JMSException e) {
					log.error("Exception al cerrar consumer " + e.getMessage(), e);
				}
			}

			if (producer != null) {
				try {
					producer.close();
					log.warn("Producer JMS cerrado...");
				} catch (JMSException e) {
					log.error("Exception al cerrar producer ", e);
				}
			}
			if (session != null) {
				try {
					log.warn("Cerrando Session JMS...");
					session.close();
					log.warn("Session JMS cerrado...");
				} catch (JMSException e) {
					log.error("Exception al cerrar session ", e);
				}
			}

			
		} catch (Exception e) {
			log.error("caught exception closing consumer", e);
		} finally {
			producer = null;
			session = null;
			
		}
	}

	public void after() throws Exception {
		log.info("Despues de ejecutar jms cerrando....." + (connection != null));
		if (connection != null) {
			connection.close();
			log.info("connexion jms cerrado ");
		}
	}

	public void before() throws Exception {
		log.info("Before Nueva conexion JMS antes");
		connection = connectionFactory.createConnection();
		connection.start();
		log.info("Before Nueva conexion JMS creada " + connection.getClientID() + "\nMetadata: " + connection);
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
	}

}
