/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.CartasCredService;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocFacturasDao extends HibernateDaoSupport {
	// private static FactoryDao factoryDao;
	private static final Log log = LogFactory.getLog(SocFacturasDao.class);

	public void saveOrUpdate(SocFacturas pm) {
		// parche: si no existe nom factura y
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void eliminar(SocFacturas pm) {
		// log.info("Eliminando factura... " + pm);
		this.getHibernateTemplate().delete(pm);
	}

	public void eliminarRegs(String codigo) {
		List<SocFacturas> facts = getFacturas(codigo);
		this.getHibernateTemplate().deleteAll(facts);
		int i = 0;
		// while (facts.size() > 0) {
		// SocFacturas fact = facts.get(0);
		// eliminar(fact);
		// facts = getFacturas(codigo);
		// i++;
		// }
		log.debug("Eliminados Facturas [ " + i + " ] regs.");
	}

	public SocFacturas getFactura(String cpbCodigo, Integer renCodigo, String claTipofact) {
		StringBuffer query = new StringBuffer();
		query = query.append("select fa ");
		query = query.append("from SocFacturas fa ");
		query = query.append("where fa.id.cpbCodigo = :cpbCodigo ");
		query = query.append("and fa.id.renCodigo = :renCodigo ");
		query = query.append("and fa.claTipofact = :claTipofact ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("cpbCodigo", cpbCodigo);
		consulta.setParameter("renCodigo", renCodigo);
		consulta.setParameter("claTipofact", claTipofact);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocFacturas) lista.get(0);
		}
		return null;
	}

	public SocFacturas getFacturaByCodigo(String cpbCodigo, Integer renCodigo, Integer facCodigo) {
		StringBuffer query = new StringBuffer();
		query = query.append("select fa ");
		query = query.append("from SocFacturas fa ");
		query = query.append("where fa.id.cpbCodigo = :cpbCodigo ");
		query = query.append("and fa.id.renCodigo = :renCodigo ");
		query = query.append("and fa.id.facCodigo = :facCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("cpbCodigo", cpbCodigo);
		consulta.setParameter("renCodigo", renCodigo);
		consulta.setParameter("facCodigo", facCodigo);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocFacturas) lista.get(0);
		}
		
		throw new RuntimeException("Factura inexistente cpbte: " + cpbCodigo  + " renglon: "  + renCodigo + " factura: " + facCodigo);		
	}	
	public List<SocFacturas> getFacturas(String id) {
		List<SocFacturas> lista = new ArrayList<SocFacturas>();

		StringBuffer query = new StringBuffer();
		query = query.append("select fa ");
		query = query.append("from ");
		query = query.append("SocFacturas fa ");
		query = query.append("where fa.id.cpbCodigo = :codigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codigo", id);

		lista = consulta.list();

		return lista;
	}

	/***********************/
	private Integer getMaxFactura(String cpbCodigo, Integer renCodigo) {
		Integer maxDet = Integer.valueOf(0);
		StringBuffer query = new StringBuffer();
		query = query.append("select max(fa.id.facCodigo) ");
		query = query.append("from SocFacturas fa ");
		query = query.append("where fa.id.cpbCodigo = :cpbCodigo ");
		query = query.append("and fa.id.renCodigo = :renCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("cpbCodigo", cpbCodigo);
		consulta.setParameter("renCodigo", renCodigo);

		log.debug("Entre a getMaxFactura [cpbCodigo=" + cpbCodigo + "] " + consulta.toString());

		List result = consulta.list();
		if (result.size() > 0)
			maxDet = (Integer) result.get(0);

		if (maxDet == null)
			maxDet = 0;

		return maxDet;

	}

	public SocFacturas crearFactura(Solicitud solicitud, SocRengscomp socRengscomp, Integer nroRenglon, String varClaComision, String codConcepto,
			String tipoFactura) {
		// tipoFactura : sin credito (S) o con credito (C)
		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(getSessionFactory());

		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());
		Integer tipoDocid = 5; // NIT
		
		log.info("Factura [" + tipoFactura + "]=> " + solicitud.getSolicitud().getSocCodigo() + ", varClaComision:" + varClaComision
				+ ", codConcepto:" + codConcepto + ", CpbCodigo:" + socRengscomp.getId().getCpbCodigo() + ", renglon:"
				+ socRengscomp.getId().getRenCodigo());

		SocFacturas socFacturas = getFactura(socRengscomp.getId().getCpbCodigo(), nroRenglon, varClaComision);

		if (socFacturas == null) {
			log.debug("Nueva factura CpbCodigo:" + socRengscomp.getId().getCpbCodigo() + ", renglon:" + socRengscomp.getId().getRenCodigo());

			Integer maximo = getMaxFactura(socRengscomp.getId().getCpbCodigo(), nroRenglon);
			maximo++;

			SocFacturasId socFacturasId = new SocFacturasId(socRengscomp.getId().getCpbCodigo(), nroRenglon, maximo);

			socFacturas = new SocFacturas();
			socFacturas.setId(socFacturasId);
		}

		socFacturas.setFacMontoexcento(BigDecimal.ZERO);
		socFacturas.setFacPreciounitario(BigDecimal.ZERO);
		socFacturas.setFacCantidad(1);
		
		SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, varClaComision);
		if (socOpecomi == null) {
			throw new BusinessException(solicitud.getSolicitud().getSocCodigo() + ": Proceso de generacion de facturas: variable " + varClaComision
					+ " inexistente en socOpecomi");
		}

		if (StringUtils.isBlank(socOpecomi.getNit())){
			throw new BusinessException(solicitud.getSolicitud().getSocCodigo() + ": Proceso de generacion de facturas: NIT invalido para " + varClaComision
					+ " inexistente en socOpecomi");			
		}
		//log.info(socOpecomi.getId().getOpeCodigo() + " - " + socOpecomi.getId().getClaComision() + " " + socOpecomi.getTipoDocumento());
		socFacturas.setFacMontomn(socOpecomi.getOcoMonto());
		socFacturas.setFacPreciounitario(socOpecomi.getFacPreciounit());
		socFacturas.setFacCantidad(socOpecomi.getFacCantidad());
		socFacturas.setFacNit(socOpecomi.getNit());
		socFacturas.setFacNombre(socOpecomi.getFactura());
		socFacturas.setTipoDocumento(socOpecomi.getTipoDocumento());
		socFacturas.setTipoDocid(!StringUtils.isBlank(socOpecomi.getTipoDocumento()) && socOpecomi.getTipoDocumento().equals(Constants.CVE_TIPOFACTCOIN_NIT) ? tipoDocid : null);
		socFacturas.setComplemento(socOpecomi.getComplemento());
		socFacturas.setCorreo(socOpecomi.getCorreo());
	 
		Character cveRuc = 'N';
		socFacturas.setCveRuc(!StringUtils.isBlank(socOpecomi.getNroCuenta()) ? socOpecomi.getNroCuenta().charAt(0) : cveRuc);
		socFacturas.setFacMontoiva(socOpecomi.getOcoMontoimpt());

		SocValorescla socValorescla = socValoresclaDao.getValoresByCod(Constants.CLAVE_CONCEPTOFAC, codConcepto);
		String concepto = socValorescla.getValNombre();

		socFacturas.setClaTipofact(varClaComision);
		socFacturas.setFacConcepto(concepto);
		socFacturas.setCodProductoBcb(socValorescla.getFacCodigoBcb());
		
		//whf 20220222 req : en el concepto no se permiten codigos o ids
		
//		if (solicitud.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) || solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)) {
//			CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
//			Solicitud solicitudCC = cartasCredService.recuperarCartaYDetalleParaSolicitud(solicitud.getSolicitud().getSocCodigo());
//			if (solicitudCC.getCarCartascr().getCcrCorrelativo() != null)
//				socFacturas.setFacConcepto(concepto + ", Nro de Carta: " + solicitudCC.getCarCartascr().getCcrCorrelativo());
//		}

		if (tipoFactura.equals("S")) {
			socFacturas.setFacMontoexcento(socOpecomi.getOcoMonto());
			socFacturas.setFacMontoiva(BigDecimal.ZERO);
			socFacturas.setFacPreciounitario(socOpecomi.getTipoCambio());
		}
		
		if (socFacturas.getTipoDocid() == null ) {
			socValorescla = socValoresclaDao.getValoresByCodigo(Constants.CLAVE_TIPODOCCONTA, socFacturas.getTipoDocumento());
			
			if (socValorescla != null && !StringUtils.isBlank(socValorescla.getValNombre())) {
				tipoDocid = NumberUtils.toInt(socValorescla.getValNombre());
			}
			tipoDocid = tipoDocid <= 0 ? 5 : tipoDocid;
			socFacturas.setTipoDocid(tipoDocid);
		}
		this.getHibernateTemplate().saveOrUpdate(socFacturas);
		
		log.info(solicitud.getSolicitud().getSocCodigo() + " Factura creada Cpb["+ socRengscomp.getId().getCpbCodigo() +":" + socRengscomp.getId().getRenCodigo() + "]: " + socFacturas.toString());
		return socFacturas;
	}

	/**
	 * util para modificaciones por el usuario en CC
	 * @param socSolicitudes
	 * @param socFacturasIn
	 */
	public void guardarFactura(SocSolicitudes socSolicitudes,  SocFacturas socFacturasIn) {
		log.info("guardando factura " + socFacturasIn.getFacConcepto() +" " + socFacturasIn.getFacNit() + " " + socFacturasIn.getFacNombre());

		SocFacturas socFacturas = getFacturaByCodigo(socFacturasIn.getId().getCpbCodigo(), socFacturasIn.getId().getRenCodigo(), socFacturasIn.getId().getFacCodigo());
		if (StringUtils.isBlank(socFacturasIn.getFacConcepto())){
			throw new BusinessException("Concepto debe tener un valor.");
		}
		
		if (StringUtils.isBlank(socFacturasIn.getFacNit())){ 
			throw new BusinessException("Nit debe tener un valor.");
		}
		
		if (StringUtils.isBlank(socFacturasIn.getFacNombre())){
			throw new BusinessException("Razón social debe tener un valor.");				
		}
		socFacturas.setFacConcepto(socFacturasIn.getFacConcepto());
		socFacturas.setFacNit(socFacturasIn.getFacNit());			
		socFacturas.setFacNombre(socFacturasIn.getFacNombre());			
		socFacturas.setTipoDocumento(socFacturasIn.getTipoDocumento());
		socFacturas.setComplemento(socFacturasIn.getComplemento());
		socFacturas.setCorreo(socFacturasIn.getCorreo());
		//socFacturas.setFacPreciounitario(socFacturasIn.getFacPreciounitario());		
		saveOrUpdate(socFacturas); 

		log.info("actualizado facturas.............");
	}

}