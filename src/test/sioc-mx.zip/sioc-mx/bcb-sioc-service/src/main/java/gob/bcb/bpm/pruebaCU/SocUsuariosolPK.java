/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author faflores
 */
@Embeddable
public class SocUsuariosolPK implements Serializable {
    @Column(name = "sol_codigo")
    private String solCodigo;
    @Column(name = "login")
    private String login;

    public SocUsuariosolPK() {
    }

    public SocUsuariosolPK(String solCodigo, String login) {
        this.solCodigo = solCodigo;
        this.login = login;
    }

    public String getSolCodigo() {
        return solCodigo;
    }

    public void setSolCodigo(String solCodigo) {
        this.solCodigo = solCodigo;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    
    public int hashCode() {
        int hash = 0;
        hash += (solCodigo != null ? solCodigo.hashCode() : 0);
        hash += (login != null ? login.hashCode() : 0);
        return hash;
    }

    
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SocUsuariosolPK)) {
            return false;
        }
        SocUsuariosolPK other = (SocUsuariosolPK) object;
        if ((this.solCodigo == null && other.solCodigo != null) || (this.solCodigo != null && !this.solCodigo.equals(other.solCodigo))) {
            return false;
        }
        if ((this.login == null && other.login != null) || (this.login != null && !this.login.equals(other.login))) {
            return false;
        }
        return true;
    }

    
    public String toString() {
        return "websiocproduccion.SocUsuariosolPK[solCodigo=" + solCodigo + ", login=" + login + "]";
    }

}
