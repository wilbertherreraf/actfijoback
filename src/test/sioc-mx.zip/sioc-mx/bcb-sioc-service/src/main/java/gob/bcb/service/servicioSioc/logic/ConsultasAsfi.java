package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.bpm.pruebaCU.SocBolsinDao;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.SolicitudBolsin;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.SolicitudesBolsin;

public class ConsultasAsfi {
	private final Logger log = LoggerFactory.getLogger(ConsultasAsfi.class);
	
	public static final Integer DIAS_CONSULTA_ASFI = 7;  
	private final SocBolsinDao socBolsinDao;
	private final SocParametrosDao socParametrosDao;
	private final SessionFactory sessionFactorySioc;
	
	public ConsultasAsfi(SessionFactory sessionFactorySioc) {
		this.socBolsinDao = new SocBolsinDao();
		this.socParametrosDao = new SocParametrosDao();
		
		this.socBolsinDao.setSessionFactory(sessionFactorySioc);
		this.socParametrosDao.setSessionFactory(sessionFactorySioc);
		this.sessionFactorySioc = sessionFactorySioc;
	}
	
	public SolicitudesBolsin obtenerSolsBolsin(Date fechaIni, Date fechaFin){
		long diff = UtilsDate.getDifferenceDays(fechaIni, fechaFin);
		if (diff > DIAS_CONSULTA_ASFI) {
			throw new RuntimeException("Rango de fechas debe ser igual o menor a 7 dias");
		}
		
		SocParametros socParametros = socParametrosDao.getByCodigo("FECCORTEASFI");
		Date fechaCorteAsfi = UtilsDate.dateFromString(socParametros.getParValor(), "dd-MM-yyyy");
		
		boolean isValid = UtilsDate.compara(fechaCorteAsfi, fechaIni) < 0 && UtilsDate.compara(fechaCorteAsfi, fechaFin) < 0;
		if (!isValid) {
			throw new RuntimeException("Rango fuera de fecha corte.");
		}
		
		List<Map<String, Object>> resultado = socBolsinDao.resuSolsEntrefechas(fechaIni, fechaFin);
		SolicitudesBolsin solicitudesBolsin = new SolicitudesBolsin();
		
		for (Map<String, Object> res : resultado) {
			
			SolicitudBolsin solicitudBolsin = new SolicitudBolsin();
			
			solicitudBolsin.setSolCodigo(res.get("soc_codigo").toString());
			solicitudBolsin.setSolCodpersona((String) res.get("sol_codigo").toString());
			Date fecha = (Date) res.get("fechacont");
			BigDecimal ma = (BigDecimal) (res.get("montopresen"));
			solicitudBolsin.setSolFecha(UtilsDate.stringFromDate(fecha, "dd/MM/yyyy"));
			solicitudBolsin.setSolMontoacep(ma);
			solicitudBolsin.setSolMontoadj((BigDecimal) res.get("montoacep"));
			solicitudBolsin.setSolMontosol((BigDecimal) res.get("montoadj"));
			solicitudBolsin.setSolPersona(res.get("sol_persona").toString());
			solicitudBolsin.setSolTipsolic((String) res.get("cla_tipsolic"));
			solicitudBolsin.setSolBeneficiario((String) res.get("beneficiario"));

			log.info("XXX: " + solicitudBolsin.getSolCodigo());
			solicitudesBolsin.getSolicitudBolsin().add(solicitudBolsin);
		}
		return solicitudesBolsin;
	}
}
