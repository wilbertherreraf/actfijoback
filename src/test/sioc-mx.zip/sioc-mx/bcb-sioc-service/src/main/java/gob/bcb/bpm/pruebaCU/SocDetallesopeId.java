package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_detallesope database table.
 * 
 */
@Embeddable
public class SocDetallesopeId implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ope_codigo")
	private String opeCodigo;

	@Column(name="det_codigo")
	private Integer detCodigo;

    public SocDetallesopeId() {
    }
    public SocDetallesopeId(String opeCodigo, int detCodigo) {
        this.opeCodigo = opeCodigo;
        this.detCodigo = detCodigo;
      }
    
	public String getOpeCodigo() {
		return this.opeCodigo;
	}
	public void setOpeCodigo(String opeCodigo) {
		this.opeCodigo = opeCodigo;
	}
	public Integer getDetCodigo() {
		return this.detCodigo;
	}
	public void setDetCodigo(Integer detCodigo) {
		this.detCodigo = detCodigo;
	}
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((detCodigo == null) ? 0 : detCodigo.hashCode());
		result = prime * result + ((opeCodigo == null) ? 0 : opeCodigo.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocDetallesopeId other = (SocDetallesopeId) obj;
		if (detCodigo == null) {
			if (other.detCodigo != null)
				return false;
		} else if (!detCodigo.equals(other.detCodigo))
			return false;
		if (opeCodigo == null) {
			if (other.opeCodigo != null)
				return false;
		} else if (!opeCodigo.equals(other.opeCodigo))
			return false;
		return true;
	}
	
}
