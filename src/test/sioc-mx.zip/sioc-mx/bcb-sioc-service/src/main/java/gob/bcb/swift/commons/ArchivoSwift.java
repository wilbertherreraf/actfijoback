package gob.bcb.swift.commons;

import java.io.ByteArrayInputStream;

import java.io.InputStream;
import java.io.Serializable;

import org.apache.log4j.Logger;

public class ArchivoSwift implements Serializable {
	private static final Logger log = Logger.getLogger(ArchivoSwift.class);

	private byte[] data;
	private String contentType;
	private String name;
	private String contentEncoding;
	private String pathFile;
	private String directory;
	private String hash;	
	private long size;
	private boolean accept;
	private boolean verified = false;	
	public ArchivoSwift() {
	}

	public ArchivoSwift(byte[] data) {
		this.data = data;
		
	}

	public ArchivoSwift(byte[] data, String contentType) {
		this(data);
		this.contentType = contentType;
	}

	public ArchivoSwift(byte[] data, String contentType, String name) {
		this(data, contentType);
		this.name = name;
	}

	public ArchivoSwift(byte[] data, String contentType, String name, String contentEncoding) {
		this(data, contentType, name);
		this.contentEncoding = contentEncoding;
	}

	public InputStream getStream() {
		return new ByteArrayInputStream(this.data);
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContentEncoding() {
		return contentEncoding;
	}

	public void setContentEncoding(String contentEncoding) {
		this.contentEncoding = contentEncoding;
	}

	public String getPathFile() {
		return pathFile;
	}

	public void setPathFile(String pathFile) {
		this.pathFile = pathFile;
	}

	public String getDirectory() {
		return directory;
	}

	public void setDirectory(String directory) {
		this.directory = directory;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public boolean isAccept() {
		return accept;
	}

	public void setAccept(boolean accept) {
		this.accept = accept;
	}

	public boolean isVerified() {
		return verified;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}

}
