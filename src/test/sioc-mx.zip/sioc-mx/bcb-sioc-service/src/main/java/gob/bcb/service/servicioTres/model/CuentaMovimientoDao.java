package gob.bcb.service.servicioTres.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.bpm.pruebaCU.SocRengesq;
import gob.bcb.core.utils.UtilsQNatives;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.CuentaS;

public class CuentaMovimientoDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(CuentaMovimientoDao.class);

	private static CacheCuentas cacheCuentas = new CacheCuentas();

	public static String formatCodigo(String codMovimiento, Integer codMoneda) {
		return StringUtils.trimToEmpty(codMovimiento).concat(String.format("%03d", codMoneda));
	}		
	
	private static class CacheCuentas {
		private final Map<String, CuentaS> cuentas = new ConcurrentHashMap<>();
		private final Map<String, Long> timestamp = new ConcurrentHashMap<>();
		private final int EXPIRES = 60 * 10;
		private final int TIME_CLEAR = 60 * 30;		
		private long lastUpdate = System.currentTimeMillis();  
		//return System.currentTimeMillis() - timestamp >= expires * 1000L;
		public boolean existsCuenta(String codMovimiento, Integer codMoneda) {
			boolean existe = cuentas.containsKey(formatCodigo(codMovimiento.trim(), codMoneda)) && !expired(codMovimiento, codMoneda);
			return existe;
		}
		
		public CuentaS recuperarCuentaSDeCache(String codMovimiento, Integer codMoneda) {
			log.debug(cuentas.size() + " desde cache " + codMovimiento + " "+ codMoneda );
			if (existsCuenta(codMovimiento, codMoneda)){
				CuentaS cuentaS = cuentas.get(formatCodigo(codMovimiento, codMoneda));
				
				CuentaS cuenta = new CuentaS();
				cuenta.setCodPartidas(cuentaS.getCodPartidas());
				cuenta.setAfectSigma(cuentaS.getAfectSigma());
				cuenta.setEsConciliable(cuentaS.getEsConciliable());
				cuenta.setCtaMovi(cuentaS.getCtaMovi());
				cuenta.setClaVigente(cuentaS.getClaVigente());
				cuenta.setMoneda(cuentaS.getMoneda());
				cuenta.setCtaAfectable(cuentaS.getCtaAfectable());
				cuenta.setCtaMayor(cuentaS.getCtaMayor());
				cuenta.setCodMayor(cuentaS.getCodMayor());
				
				return cuenta;
			} else {
				remove(codMovimiento, codMoneda);
				return new CuentaS();
			}
		}
		
		public void setCuenta(CuentaS cuentaS) {
			CuentaS cuenta = new CuentaS();
			cuenta.setCodPartidas(cuentaS.getCodPartidas());
			cuenta.setAfectSigma(cuentaS.getAfectSigma());
			cuenta.setEsConciliable(cuentaS.getEsConciliable());
			cuenta.setCtaMovi(cuentaS.getCtaMovi());
			cuenta.setClaVigente(cuentaS.getClaVigente());
			cuenta.setMoneda(cuentaS.getMoneda());
			cuenta.setCtaAfectable(cuentaS.getCtaAfectable());
			cuenta.setCtaMayor(cuentaS.getCtaMayor());
			cuenta.setCodMayor(cuentaS.getCodMayor());
			log.info(cuentas.size() + " : Cacheando " + cuenta.getCtaMovi() + " "+ cuenta.getMoneda() + " " + cuenta.getCtaAfectable());			
			cuentas.put(formatCodigo(cuenta.getCtaMovi(),cuenta.getMoneda()), cuenta);
			timestamp.put(formatCodigo(cuenta.getCtaMovi(),cuenta.getMoneda()), System.currentTimeMillis());
			lastUpdate = System.currentTimeMillis();
		}
		
	   public boolean expired(String codMovimiento, Integer codMoneda){
		   if (timestamp.containsKey(formatCodigo(codMovimiento, codMoneda))){
			   boolean expire = System.currentTimeMillis() - timestamp.get(formatCodigo(codMovimiento, codMoneda)) >= EXPIRES * 1000L;
			   log.info("Expiro " + codMovimiento + " "+ codMoneda + " " + expire);
		      return expire;			   
		   }
		   return false;
	   }
		
	   public void remove(String codMovimiento, Integer codMoneda){
		   //if (cuentas.containsKey(formatCodigo(codMovimiento, codMoneda))){
		   		//clear();
			   cuentas.remove(formatCodigo(codMovimiento, codMoneda));
			   timestamp.remove(formatCodigo(codMovimiento, codMoneda));
			   log.info("REmoviendo " + codMovimiento + " "+ codMoneda);
		   //}
	   }
	   
	   public void clear(){
		   boolean expire = System.currentTimeMillis() - lastUpdate >= TIME_CLEAR * 1000L;
		   if (expire){
			   log.info("Limpiando todo cache!!!!");
			   cuentas.clear();
			   timestamp.clear();
			   lastUpdate = System.currentTimeMillis();
		   }
			   
	   }
	}
	
	public CuentaMovimiento getCuentaMovimiento(String codMovimiento) {
		log.debug("COIN:getCuentaMovimiento Entre a buscar el objeto con el codMovimiento: "
				+ codMovimiento);

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from CuentaMovimiento cp ");
		query = query.append("where cp.codMovimiento = :codMovimiento ");
		//query = query.append("and cp.cveEstadoCuenta = 'V'  ");		

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaMovimiento) lista.get(0);
		}
		
		log.error("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.Cuenta_Movimiento");
		throw new RuntimeException("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.Cuenta_Movimiento");
	}

	public CuentaMovimiento findCuentaMovimiento(String codMovimiento) {
		log.debug("COIN:getCuentaMovimiento Entre a buscar el objeto con el codMovimiento: "
				+ codMovimiento);

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from CuentaMovimiento cp ");
		query = query.append("where cp.codMovimiento = :codMovimiento ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaMovimiento) lista.get(0);
		}
		log.error("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.Cuenta_Movimiento");		
		return null;
	}
	
	public Boolean IsAfectableSigma(String cuenta) {
		// int sigma = 0;

		String query = "select count(nro_afectable) as sigma ";
		query = query.concat("from afectable_sigma ");
		query = query.concat("where nro_afectable = :cuenta ");
		query = query.concat("and cve_vigente = 'V' ");

		Query consulta = getSession().createSQLQuery(query);
		consulta.setParameter("cuenta", cuenta);

		Long codigo = Long.valueOf(0);

		BigDecimal maxi = BigDecimal.ZERO;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (BigDecimal) result.get(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
		} else {
			codigo = Long.valueOf(0);
		}

		return codigo.compareTo(Long.valueOf(1)) >= 0;
	}

	public List<String> partidaPresup(String cuenta) {
		log.info("Buscando partida presup " + cuenta);
		List<String> result = new ArrayList<String>();
		try {

			String query = "select cod_partida ";
			query = query.concat("from afectable_partida ");
			query = query.concat("where nro_afectable = :cuenta ");
			query = query.concat("and cve_vigente = 'V' ");

			Query consulta = getSession().createSQLQuery(query);
			consulta.setParameter("cuenta", cuenta);

			result = consulta.list();

		} catch (Exception e) {
			throw new RuntimeException("Error al obtener Codigo Part Presup: "
					+ e.getMessage(), e);
		}

		return result;
	}

	public List<CuentaAfectable> cuentasFondosVista() {
		StringBuffer query = new StringBuffer();
		query = query.append("select ca ");
		query = query.append("from CuentaMovimiento cm, CuentaAfectable ca ");
		query = query.append("where cm.codMovimiento = ca.codMovimiento ");
		query = query.append("and cm.cveEstadoCuenta = 'V' ");
		query = query.append("and ca.cveEstadoCuenta = 'V' ");
		query = query.append("and ca.nroCentro = 1 ");
		query = query.append("and cm.codTipoCuenta like '0010%' ");

		Query consulta = getSession().createQuery(query.toString());

		List lista = consulta.list();

		return lista;
	}

	public List<CuentaAfectable> cuentasFondosVistaByCodMoneda(String codMoneda) {
		StringBuffer query = new StringBuffer();
		query = query.append("select ca ");
		query = query.append("from CuentaMovimiento cm, CuentaAfectable ca ");
		query = query.append("where cm.codMovimiento = ca.codMovimiento ");
		query = query.append("and cm.cveEstadoCuenta = 'V' ");
		query = query.append("and ca.cveEstadoCuenta = 'V' ");
		query = query.append("and ca.nroCentro = 1 ");
		query = query.append("and ca.codMoneda = :codMoneda ");		
		query = query.append("and cm.codTipoCuenta like '0010%' ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMoneda", codMoneda);
		
		List lista = consulta.list();

		return lista;
	}
	
	public CuentaAfectable cuentaAfectableByCodMovCodmoneda(String codMovimiento, String codMoneda) {
		StringBuffer query = new StringBuffer();
		query = query.append("select ca ");
		query = query.append("from CuentaAfectable ca ");
		query = query.append("where ca.codMovimiento = :codMovimiento ");
		query = query.append("and ca.codMoneda = :codMoneda ");		
		query = query.append("and ca.cveEstadoCuenta = 'V' ");		

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);		
		consulta.setParameter("codMoneda", codMoneda);
		
		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaAfectable) lista.get(0);
		}
		
		throw new RuntimeException("Cuenta afectable : " + codMovimiento + " - " + codMoneda + "  inexistente en base CONTBCB.Cuenta_Afectable");
	}

	public CuentaAfectable cuentaAfectableByNroAfectable(String nroAfectable) {
		StringBuffer query = new StringBuffer();
		query = query.append("select ca ");
		query = query.append("from CuentaAfectable ca ");
		query = query.append("where ca.nroAfectable = :nroAfectable ");
		query = query.append("and ca.cveEstadoCuenta = 'V' ");		

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("nroAfectable", nroAfectable);		
		
		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaAfectable) lista.get(0);
		}
		
		throw new RuntimeException("Cuenta con nro afectable : " + nroAfectable + "  inexistente en base CONTBCB.Cuenta_Afectable");
	}
	
	public CuentaMayor findByCodMovCuentaMayor(String codMovimiento) {
		StringBuffer query = new StringBuffer();
		query = query.append("select my ");
		query = query.append("from CuentaMovimiento cm, CuentaMayor my ");
		query = query.append("where substr(cm.codTipoCuenta, 1, 4) = my.codMayor ");
		query = query.append("and cm.codMovimiento = :codMovimiento ");		
		query = query.append("and my.nroCentro = 1 ");	
		query = query.append("and cm.cveEstadoCuenta = 'V' ");
		query = query.append("and my.cveEstadoCuenta = 'V' ");		

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaMayor) lista.get(0);
		}
		log.error("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.CuentaMayor");		
		throw new RuntimeException("Inexistente mayor CONTBCB.Cuenta_mayor para cuenta movimiento: " + codMovimiento);
	}

	public boolean nroAfectableEsConciliable(String nroAfectable){

		StringBuffer query = new StringBuffer();
		query = query.append("select nro_afectable ");
		query = query.append("from afectable_concilia ");
		query = query.append("where nro_afectable = :nroAfectable ");
		query = query.append("and cve_estado_cuenta = 'V' ");		

		//log.info("Cuenta es conciliable " + nroAfectable + " " + query.toString());
		
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("nroAfectable", nroAfectable);
		
		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives.convertListToMap(lista, "nro_afectable".split(","));
		
		return (resultadoQuery.size() > 0);
	}	
	
	public CuentaS recuperarDatosCuenta(String codMovimiento, String codMoneda) {

		CuentaAfectable cuentaAfectable = cuentaAfectableByCodMovCodmoneda(codMovimiento, codMoneda);
		CuentaS cuentaS = recuperarDatosCuentaParaNroAfectable(cuentaAfectable);
			
		return cuentaS;
	}
	
	public CuentaS recuperarDatosCuentaParaNroAfectable(String nroAfectable) {
		CuentaAfectable cuentaAfectable = cuentaAfectableByNroAfectable(nroAfectable);
		CuentaS cuentaS = recuperarDatosCuentaParaNroAfectable(cuentaAfectable);
		return cuentaS;
	}
	
	private CuentaS recuperarDatosCuentaParaNroAfectable(CuentaAfectable cuentaAfectable) {
		CuentaS cuentaS = new CuentaS();
		//CuentaAfectable cuentaAfectable = cuentaAfectableByNroAfectable(nroAfectable);
		
		List<String> codPartidas = partidaPresup(cuentaAfectable.getNroAfectable());
		cuentaS.setCodPartidas(codPartidas);
		
		Boolean afectSigma = IsAfectableSigma(cuentaAfectable.getNroAfectable());
		cuentaS.setAfectSigma(afectSigma);			

		//if (cuentaS.getCodPartidas().size() == 0 && !cuentaS.getAfectSigma()) {
			Boolean esConciliable = nroAfectableEsConciliable(cuentaAfectable.getNroAfectable());
			cuentaS.setEsConciliable(esConciliable);				
		//} 

		cuentaS.setCtaAfectable(cuentaAfectable.getNroAfectable());
		cuentaS.setCtaMovi(cuentaAfectable.getCodMovimiento());
		cuentaS.setClaVigente(Short.valueOf("1"));
		Integer codMonedaInt = Integer.valueOf(cuentaAfectable.getCodMoneda().trim());
		cuentaS.setMoneda(codMonedaInt);
		
		CuentaMayor cuentaMayor = findByCodMovCuentaMayor(cuentaAfectable.getCodMovimiento());
		cuentaS.setCtaMayor(cuentaMayor.getNroMayor());
		cuentaS.setCodMayor(cuentaMayor.getCodMayor());		
		
		return cuentaS;
	}
	
	public CuentaS recuperarCuentaSDeCache(String codMovimiento, Integer codMoneda){
		CuentaS cuentaS = cacheCuentas.recuperarCuentaSDeCache(codMovimiento, codMoneda);
		
		log.debug("Esta en cache? " + !StringUtils.isBlank(cuentaS.getCtaAfectable()));
		
		if (StringUtils.isBlank(cuentaS.getCtaAfectable())) {
			String codMonedaStr = String.valueOf(codMoneda);
			cuentaS = recuperarDatosCuenta(codMovimiento, codMonedaStr);
			//log.info("Esta en cuentaS.getAfectSigma() " + cuentaS.getAfectSigma() + ", cuentaS.getEsConciliable(): " + cuentaS.getEsConciliable() + ", cuentaS.getCodPartidas().size(): " + cuentaS.getCodPartidas().size());
//			if (cuentaS.getAfectSigma() || cuentaS.getEsConciliable() || cuentaS.getCodPartidas().size() > 0) {
				cacheCuentas.setCuenta(cuentaS);
				return cuentaS;
			//} 
		} else {
			return cuentaS;			
		}
	}

	public CuentaS recuperarCuentaSDeCache(String nroAfectable){
		CuentaAfectable cuentaAfectable = cuentaAfectableByNroAfectable(nroAfectable);
		CuentaS cuentaS = recuperarCuentaSDeCache(cuentaAfectable.getCodMovimiento(), Integer.valueOf(cuentaAfectable.getCodMoneda().trim()));
		return cuentaS;			
	}
	
	public static void clearCache(){
		cacheCuentas.clear();		
	}
}
