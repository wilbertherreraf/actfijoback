/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "factura_sin_credito")
@NamedQueries({ @NamedQuery(name = "FacturaSinCredito.findAll", query = "SELECT f FROM FacturaSinCredito f") })
public class FacturaSinCredito implements Serializable {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	protected FacturaSinCreditoId id;
	@Basic(optional = false)
	@Column(name = "cve_registro_ruc")
	private char cveRegistroRuc;
	@Column(name = "ruc")
	private String ruc;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "nro_orden")
	private String nroOrden;
	@Column(name = "nro_factura")
	private String nroFactura;
	@Column(name = "cod_factura")
	private String codFactura;
	@Basic(optional = false)
	@Column(name = "fecha_factura")
	@Temporal(TemporalType.DATE)
	private Date fechaFactura;
	@Basic(optional = false)
	@Column(name = "monto_factura")
	private BigDecimal montoFactura;
	@Basic(optional = false)
	@Column(name = "monto_ice")
	private BigDecimal montoIce;
	@Basic(optional = false)
	@Column(name = "cve_estado_factura")
	private char cveEstadoFactura;
	@Basic(optional = false)
	@Column(name = "cod_usuario")
	private String codUsuario;
	@Basic(optional = false)
	@Column(name = "fecha_hora")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaHora;
	@Column(name = "estacion")
	private String estacion;
	@Basic(optional = false)
	@Column(name = "cve_cr_db")
	private char cveCrDb;
	@Basic(optional = false)
	@Column(name = "monto_iva")
	private BigDecimal montoIva;
	@Column(name = "monto_excento")
	private BigDecimal montoExcento;

	@Column(name = "concepto")
	private String concepto;
	@Column(name = "fch_limite")
	@Temporal(TemporalType.DATE)
	private Date fchLimite;
	@Column(name = "llave_sin")
	private String llaveSin;
	@Column(name = "cod_control")
	private String codControl;
	@Column(name = "precio_unitario")
	private BigDecimal precioUnitario;

	public FacturaSinCredito() {
	}

	public FacturaSinCredito(FacturaSinCreditoId id) {
		this.id = id;
	}

	public FacturaSinCredito(FacturaSinCreditoId id, char cveRegistroRuc, Date fechaFactura, BigDecimal montoFactura, BigDecimal montoIce,
			char cveEstadoFactura, String codUsuario, Date fechaHora, char cveCrDb, BigDecimal montoIva, BigDecimal montoExcento) {
		this.id = id;
		this.cveRegistroRuc = cveRegistroRuc;
		this.fechaFactura = fechaFactura;
		this.montoFactura = montoFactura;
		this.montoIce = montoIce;
		this.cveEstadoFactura = cveEstadoFactura;
		this.codUsuario = codUsuario;
		this.fechaHora = fechaHora;
		this.cveCrDb = cveCrDb;
		this.montoIva = montoIva;
		this.montoExcento = montoExcento;
	}

	public FacturaSinCredito(int nroCentro, char cveTipoComprob, String nroComprob, int nroReng, int nroSecuencia) {
		this.id = new FacturaSinCreditoId(nroCentro, cveTipoComprob, nroComprob, nroReng, nroSecuencia);
	}

	public FacturaSinCredito(FacturaSinCreditoId id, char cveRegistroRuc, String ruc, String nombre, String nroOrden, String codFactura,
			String facConcepto, BigDecimal facPreciounitario,
			Date fechaFactura,
			BigDecimal montoFactura, BigDecimal montoIce, char cveEstadoFactura, String codUsuario, Date fechaHora, String estacion, char cveCrDb,
			BigDecimal montoIva, BigDecimal montoExcento) {
		this.id = id;
		this.cveRegistroRuc = cveRegistroRuc;
		this.ruc = ruc;
		this.nombre = nombre;
		this.nroOrden = nroOrden;
		this.codFactura = codFactura;
		this.fechaFactura = fechaFactura;
		this.montoFactura = montoFactura;
		this.montoIce = montoIce;
		this.cveEstadoFactura = cveEstadoFactura;
		this.codUsuario = codUsuario;
		this.fechaHora = fechaHora;
		this.estacion = estacion;
		this.cveCrDb = cveCrDb;
		this.montoIva = montoIva;
		this.montoExcento = montoExcento;
		this.concepto = facConcepto;
		this.precioUnitario = facPreciounitario;
	}

	public FacturaSinCreditoId getId() {
		return id;
	}

	public void setId(FacturaSinCreditoId id) {
		this.id = id;
	}

	public char getCveRegistroRuc() {
		return cveRegistroRuc;
	}

	public void setCveRegistroRuc(char cveRegistroRuc) {
		this.cveRegistroRuc = cveRegistroRuc;
	}

	public String getRuc() {
		return ruc;
	}

	public void setRuc(String ruc) {
		this.ruc = ruc;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNroOrden() {
		return nroOrden;
	}

	public void setNroOrden(String nroOrden) {
		this.nroOrden = nroOrden;
	}

	public String getNroFactura() {
		return nroFactura;
	}

	public void setNroFactura(String nroFactura) {
		this.nroFactura = nroFactura;
	}

	public String getCodFactura() {
		return codFactura;
	}

	public void setCodFactura(String codFactura) {
		this.codFactura = codFactura;
	}

	public Date getFechaFactura() {
		return fechaFactura;
	}

	public void setFechaFactura(Date fechaFactura) {
		this.fechaFactura = fechaFactura;
	}

	public BigDecimal getMontoFactura() {
		return montoFactura;
	}

	public void setMontoFactura(BigDecimal montoFactura) {
		this.montoFactura = montoFactura;
	}

	public BigDecimal getMontoIce() {
		return montoIce;
	}

	public void setMontoIce(BigDecimal montoIce) {
		this.montoIce = montoIce;
	}

	public char getCveEstadoFactura() {
		return cveEstadoFactura;
	}

	public void setCveEstadoFactura(char cveEstadoFactura) {
		this.cveEstadoFactura = cveEstadoFactura;
	}

	public String getCodUsuario() {
		return codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public char getCveCrDb() {
		return cveCrDb;
	}

	public void setCveCrDb(char cveCrDb) {
		this.cveCrDb = cveCrDb;
	}

	public BigDecimal getMontoIva() {
		return montoIva;
	}

	public void setMontoIva(BigDecimal montoIva) {
		this.montoIva = montoIva;
	}

	/**
	 * @return the montoExcento
	 */
	public BigDecimal getMontoExcento() {
		return montoExcento;
	}

	/**
	 * @param montoExcento
	 *            the montoExcento to set
	 */
	public void setMontoExcento(BigDecimal montoExcento) {
		this.montoExcento = montoExcento;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public Date getFchLimite() {
		return fchLimite;
	}

	public void setFchLimite(Date fchLimite) {
		this.fchLimite = fchLimite;
	}

	public String getLlaveSin() {
		return llaveSin;
	}

	public void setLlaveSin(String llaveSin) {
		this.llaveSin = llaveSin;
	}

	public String getCodControl() {
		return codControl;
	}

	public void setCodControl(String codControl) {
		this.codControl = codControl;
	}

	/**
	 * @return the precioUnitario
	 */
	public BigDecimal getPrecioUnitario() {
		return precioUnitario;
	}

	/**
	 * @param precioUnitario
	 *            the precioUnitario to set
	 */
	public void setPrecioUnitario(BigDecimal precioUnitario) {
		this.precioUnitario = precioUnitario;
	}

	
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are not
		// set
		if (!(object instanceof Factura)) {
			return false;
		}
		Factura other = (Factura) object;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

	
	public String toString() {
		return "gob.bcb.service.servicioTres.model.Factura[id=" + id + "]";
	}

}
