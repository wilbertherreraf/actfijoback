/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.servicioSioc.common.Constants;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author wherrera
 * 
 */
public class FacturaDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(FacturaDao.class);

	public void crearFacturas(Comprobante idC, List<SocFacturas> facts) {
		
		if (facts.size() == 0){
			return;
		}
		
		FacturaSinCreditoDao facturaSinCreditoDao = new FacturaSinCreditoDao();
		facturaSinCreditoDao.setSessionFactory(getSessionFactory());

		FacturaConceptoDao facturaCDao = new FacturaConceptoDao();
		facturaCDao.setSessionFactory(getSessionFactory());
		
		for (SocFacturas fact : facts) {
			if (fact.getFacMontoexcento().compareTo(BigDecimal.valueOf(0)) == 0) {
				//Map<String,String> resp = getLoteFacConCredito();
				String ordenSinCredito = "0"; //resp.get("nroorden");
				String codFacSinCredito = "0"; //resp.get("codfactura");

				Factura factura = new Factura(new FacturaId(idC.getComprobanteId().getNroCentro(), idC.getComprobanteId().getCveTipoComprob(), idC
						.getComprobanteId().getNroComprob(), fact.getId().getRenCodigo(), fact.getId().getFacCodigo()), fact.getCveRuc(),
						fact.getFacNit(), fact.getFacNombre(), ordenSinCredito, codFacSinCredito, new Date(), fact.getFacMontomn(), BigDecimal.valueOf(0), 'V',
						idC.getCodUsuario(), new Date(), idC.getEstacion(), 'D', fact.getFacMontoiva());
				factura.setCodTipoDocumento(fact.getTipoDocid());
				factura.setComplemento(fact.getComplemento());
				factura.setEmail(fact.getCorreo());

				//saveOrUpdate(factura);
				this.getHibernateTemplate().save(factura);
				FacturaConcepto factC = new FacturaConcepto(new FacturaConceptoId(idC.getComprobanteId().getNroCentro(), idC.getComprobanteId()
						.getCveTipoComprob(), idC.getComprobanteId().getNroComprob(), fact.getId().getRenCodigo(), fact.getId().getFacCodigo()),
						fact.getFacNit(), fact.getFacNombre(), fact.getFacConcepto());
				
				factC.setPrecioUnitario(fact.getFacPreciounitario() != null && fact.getFacPreciounitario().compareTo(BigDecimal.ZERO) > 0 ? fact.getFacPreciounitario() : fact.getFacMontomn());
				factC.setCantidad(fact.getFacCantidad() != null && fact.getFacCantidad().compareTo(0) > 0 ? fact.getFacCantidad() : 1);
				factC.setCodProductoBcb(fact.getCodProductoBcb() != null && fact.getCodProductoBcb().trim().length() > 0 ? fact.getCodProductoBcb() : "CRO");
				
				facturaCDao.saveOrUpdate(factC);
			} else if (fact.getFacMontoexcento().compareTo(BigDecimal.valueOf(0)) > 0) {
				//Map<String,String> resp = getLoteFacSinCredito();
				String ordenSinCredito = "0"; //resp.get("nroorden");
				String codFacSinCredito = "0"; //resp.get("codfactura");
				
				FacturaSinCredito factura = new FacturaSinCredito(new FacturaSinCreditoId(idC.getComprobanteId().getNroCentro(), idC
						.getComprobanteId().getCveTipoComprob(), idC.getComprobanteId().getNroComprob(), fact.getId().getRenCodigo(), fact.getId()
						.getFacCodigo()), fact.getCveRuc(), fact.getFacNit(), fact.getFacNombre(), ordenSinCredito, codFacSinCredito,
						fact.getFacConcepto(), fact.getFacPreciounitario(), new Date(), fact.getFacMontomn(), BigDecimal.valueOf(0), 'V',
						idC.getCodUsuario(), new Date(), idC.getEstacion(), 'D', fact.getFacMontoiva(), fact.getFacMontoexcento());
				facturaSinCreditoDao.saveOrUpdate(factura);

			}
		}
		log.info("Facturas guardadas [" + idC.getComprobanteId().getNroComprob() + "] " + facts.size());

	}

	public Boolean CrearFactura(RengComprobId idC, List<SocFacturas> facts) {
		Boolean creado = false;
		String orden = null;
		String codFac = null;

		for (SocFacturas fact : facts) {
			if (fact.getFacMontoexcento().compareTo(BigDecimal.valueOf(0)) == 0) {
				orden = "0"; //this.getOrden();
				codFac = "0"; //this.getCodFac();
				Factura factura = new Factura(new FacturaId(idC.getNroCentro(), idC.getCveTipoComprob(), idC.getNroComprob(), idC.getNroReng(), fact
						.getId().getFacCodigo()), fact.getCveRuc(), fact.getFacNit(), fact.getFacNombre(), orden, codFac, new Date(),
						fact.getFacMontomn(), BigDecimal.valueOf(0), 'V', (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), new Date(),
						(String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION), 'D', fact.getFacMontoiva());
				
				factura.setCodTipoDocumento(fact.getTipoDocid());
				factura.setComplemento(fact.getComplemento());
				factura.setEmail(fact.getCorreo());
				
				this.getHibernateTemplate().saveOrUpdate(factura);

				FacturaConcepto factC = new FacturaConcepto(new FacturaConceptoId(idC.getNroCentro(), idC.getCveTipoComprob(), idC.getNroComprob(),
						idC.getNroReng(), fact.getId().getFacCodigo()), fact.getFacNit(), fact.getFacNombre(), fact.getFacConcepto());

				factC.setPrecioUnitario(fact.getFacPreciounitario() != null && fact.getFacPreciounitario().compareTo(BigDecimal.ZERO) > 0 ? fact.getFacPreciounitario() : fact.getFacMontomn());
				factC.setCantidad(fact.getFacCantidad() != null && fact.getFacCantidad().compareTo(0) > 0 ? fact.getFacCantidad() : 1);
				factC.setCodProductoBcb(fact.getCodProductoBcb() != null && fact.getCodProductoBcb().trim().length() > 0 ? fact.getCodProductoBcb() : "CRO");
				
				FacturaConceptoDao facturaCDao = new FacturaConceptoDao();
				facturaCDao.setSessionFactory(getSessionFactory());
				facturaCDao.saveOrUpdate(factC);
				creado = true;
			}
		}
		log.info("Factura guardada: ");
		return creado;
	}

	public Boolean CrearFacturaSinCredito(RengComprobId idC, List<SocFacturas> facts) {
		Boolean creado = false;
		creado = true;
		String orden = null;
		String codFac = null;

		for (SocFacturas fact : facts) {
			if (fact.getFacMontoexcento().compareTo(BigDecimal.valueOf(0)) > 0) {
				orden = "0"; //this.getOrdenSinCredito();
				codFac = "0"; //this.getCodFacSinCredito();
				FacturaSinCredito factura = new FacturaSinCredito(new FacturaSinCreditoId(idC.getNroCentro(), idC.getCveTipoComprob(),
						idC.getNroComprob(), idC.getNroReng(), fact.getId().getFacCodigo()), fact.getCveRuc(), fact.getFacNit(), fact.getFacNombre(),
						orden, codFac, fact.getFacConcepto(), fact.getFacPreciounitario(), new Date(), fact.getFacMontomn(), BigDecimal.valueOf(0),
						'V', (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), new Date(),
						(String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION), 'D', fact.getFacMontoiva(), fact.getFacMontoexcento());
				// FacturaSinCreditoDao facturaSinCreditoDao =
				// (FacturaSinCreditoDao)
				// SiocCoinService.factoryDao.getDao("FacturaSinCreditoDao");
				FacturaSinCreditoDao facturaSinCreditoDao = new FacturaSinCreditoDao();
				facturaSinCreditoDao.setSessionFactory(getSessionFactory());
				facturaSinCreditoDao.saveOrUpdate(factura);

				creado = true;
			}
		}
		log.info("Factura guardada: ");
		return creado;
	}
}