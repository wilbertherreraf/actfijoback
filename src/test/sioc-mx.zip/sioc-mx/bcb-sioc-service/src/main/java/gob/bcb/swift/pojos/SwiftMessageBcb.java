package gob.bcb.swift.pojos;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.prowidesoftware.swift.io.parser.SwiftParser;
import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.SwiftBlock1;
import com.prowidesoftware.swift.model.SwiftBlock2;
import com.prowidesoftware.swift.model.SwiftBlock2Input;
import com.prowidesoftware.swift.model.SwiftBlock3;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftBlock5;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field21;
import com.prowidesoftware.swift.model.field.Field23B;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field33B;
import com.prowidesoftware.swift.model.field.Field50A;
import com.prowidesoftware.swift.model.field.Field50F;
import com.prowidesoftware.swift.model.field.Field50K;
import com.prowidesoftware.swift.model.field.Field52A;
import com.prowidesoftware.swift.model.field.Field52D;
import com.prowidesoftware.swift.model.field.Field53A;
import com.prowidesoftware.swift.model.field.Field53B;
import com.prowidesoftware.swift.model.field.Field53D;
import com.prowidesoftware.swift.model.field.Field54A;
import com.prowidesoftware.swift.model.field.Field54B;
import com.prowidesoftware.swift.model.field.Field54D;
import com.prowidesoftware.swift.model.field.Field56A;
import com.prowidesoftware.swift.model.field.Field56D;
import com.prowidesoftware.swift.model.field.Field57A;
import com.prowidesoftware.swift.model.field.Field57B;
import com.prowidesoftware.swift.model.field.Field57D;
import com.prowidesoftware.swift.model.field.Field58A;
import com.prowidesoftware.swift.model.field.Field58D;
import com.prowidesoftware.swift.model.field.Field59;
import com.prowidesoftware.swift.model.field.Field59F;
import com.prowidesoftware.swift.model.field.Field70;
import com.prowidesoftware.swift.model.field.Field71A;
import com.prowidesoftware.swift.model.field.Field71F;
import com.prowidesoftware.swift.model.field.Field72;
import com.prowidesoftware.swift.model.field.SwiftParseUtils;

import gob.bcb.swift.commons.MensSwiftUtiles;

public class SwiftMessageBcb implements Serializable {
	private static final Logger log = Logger.getLogger(SwiftMessageBcb.class);
	private MtSwiftMessage mtSwiftMessage0;
	private SwiftMessage swiftMessage;
	/**
	 * Block 1
	 */
	private SwiftBlock1 block1;

	/**
	 * Block 2
	 */
	private SwiftBlock2 block2;
	private SwiftBlock2Input swiftBlock2Input;
	/**
	 * Block 3
	 */
	private SwiftBlock3 block3;

	/**
	 * Block 4
	 */
	private SwiftBlock4 block4;

	/**
	 * Block 5
	 */
	private SwiftBlock5 block5;

	public SwiftMessageBcb() {
		inicializar();
	}

	public void inicializar() {
		// crea los bloques estaticos 1, 2, 3
		block1 = new SwiftBlock1();
		block2 = new SwiftBlock2Input();
		swiftBlock2Input = new SwiftBlock2Input();
		block3 = new SwiftBlock3();
		block4 = new SwiftBlock4();
		block5 = new SwiftBlock5();

		// if (mtSwiftMessage == null) {
		// mtSwiftMessage = new MtSwiftMessage();
		// }
		swiftMessage = new SwiftMessage();
		swiftMessage.setBlock1(block1);
		swiftMessage.setBlock2(swiftBlock2Input);
		swiftMessage.setBlock3(block3);
		swiftMessage.setBlock4(block4);
		swiftMessage.setBlock5(block5);

		// mtSwiftMessage.setModelMessage(swiftMessage);
		//
		// mtSwiftMessage.getModelMessage().setBlock1(block1);
		// mtSwiftMessage.getModelMessage().setBlock2(swiftBlock2Input);
		// mtSwiftMessage.getModelMessage().setBlock3(block3);
		// mtSwiftMessage.getModelMessage().setBlock4(block4);
	}

	public void createBlock1(String applicationId, String serviceId, String logicalTerminal, String sessionNumber, String sequenceNumber) {
		block1.setApplicationId(applicationId);
		block1.setServiceId(serviceId);
		block1.setLogicalTerminal(logicalTerminal);
		block1.setSessionNumber(sessionNumber);
		block1.setSequenceNumber(sequenceNumber);
	}

	public void createBlock2(String messageType, String bicReceiver, String messagePriority, String deliveryMonitoring, String obsolescencePeriod) {
		swiftBlock2Input.setMessageType(messageType);

		BIC bicswf = new BIC(bicReceiver);

		swiftBlock2Input.setReceiver(bicswf);
		swiftBlock2Input.setMessagePriority(messagePriority);
	}

	public void createBlock3(String tagname, String value) {
		value = value.trim();
		tagname = tagname.trim();
		Tag tag = new Tag(tagname, value);

		if (block3 == null) {
			List<Tag> tagsBlock3 = new ArrayList<Tag>();
			block3 = new SwiftBlock3();
			block3.setTags(tagsBlock3);
		}
		block3.removeAll(tagname);

		// log.info("removido tag block 3 " + tagname + " value " + v + " value:
		// [" + value + "]");
		block3.getTags().add(tag);

	}

	public Field getField(String fieldName) {
		Field field = block4.getFieldByName(fieldName);
		return field;
	}

	public Field modifyFieldComponent(String fieldName, Integer numberComponent, String value) {

		Field field = getField(fieldName);

		if (field == null) {
			Tag tag = new Tag(fieldName, value);
			field = tag.asField();

			List<String> components = new ArrayList<String>(numberComponent);
			field.setComponents(components);
		}
		field.setComponent(numberComponent, value);

		int v = block4.removeAll(fieldName);
		log.info("removido fieldName " + fieldName + " value " + v);

		block4.append(field);
		return getField(fieldName);
	}

	public Field addField(Field field, boolean replace) {
		if (replace) {
			int count = block4.countByName(field.getName());
			int index = block4.indexOfFirst(field.getName());

			if (count == 1 && index > -1) {
				Tag tag = block4.getTags().set(index, field.asTag());

				log.info("reemplazando index " + field.getName() + " index " + index + " " + field.getValue() + " " + tag.getValue());
			} else {
				block4.removeAll(field.getName());
				block4.append(field);
			}

		} else {
			block4.append(field);
		}

		Field f = getField(field.getName());
		return f;
	}

	public Field addField(Field field) {
		return addField(field, true);
	}

	// public MtSwiftMessage getMtSwiftMessage() {
	// return mtSwiftMessage;
	// }

	public String FIN() {
		// mtSwiftMessage.updateFromModel();
		// swiftMessage.toMT().message();
		// mtSwiftMessage.updateFromFIN();
		return swiftMessage.toMT().message();
	}

	public static Field setField20(String valor) {
		Field20 f = new Field20();
		f.setReference(valor);
		return f; // return addField(f);
	}

	public static Field setField21(String valor) {
		valor = StringUtils.trim(valor);

		Field21 f = new Field21();
		f.setReference(valor);
		return f; // return addField(f);
	}

	public static Field setField23B(String valor) {
		valor = StringUtils.trim(valor);

		Field23B f = new Field23B(valor);
		return f;
	}

	public static Field setField32A(Date fecha, String codMoneda, BigDecimal monto) {
		Field32A f = new Field32A();

		Calendar c = GregorianCalendar.getInstance();
		c.setTime(fecha);
		Currency currency = Currency.getInstance(codMoneda);

		f.setDate(c);
		f.setCurrency(currency);
		f.setAmount(monto);

		return f; // return addField(f);
	}

	public static Field setField33B(String codMoneda, BigDecimal monto) {
		Field33B f = new Field33B();

		Currency currency = Currency.getInstance(codMoneda);

		f.setCurrency(currency.getCurrencyCode());
		f.setAmount(monto);

		return f;
	}

	public static Field setField50A(String bic) {
		bic = StringUtils.trimToEmpty(bic);

		Field50A f = new Field50A();
		BIC bicswf = new BIC(bic);
		f.setComponent2(bicswf);
		
		return f;
	}

	public static Field setField50F(String ctaNro, Map<String, List<String>> mapfieldf) {
		ctaNro = StringUtils.trimToEmpty(ctaNro);

		Field50F f = new Field50F();
		if (ctaNro.startsWith("/")) {
			f.setComponent1(ctaNro);
		} else {
			f.setComponent1("/" + ctaNro);
		}
		if (mapfieldf.get("name") == null || mapfieldf.get("name").size() == 0){
			throw new RuntimeException("Nombre de beneficiario nulo o vacio");
		}
		if (mapfieldf.get("address") == null || mapfieldf.get("address").size() == 0){
			throw new RuntimeException("Direccion de beneficiario nulo o vacio");
		}
		if (mapfieldf.get("country") == null || mapfieldf.get("country").size() == 0){
			throw new RuntimeException("Pais o ciudad de beneficiario nulo o vacio");
		}
		boolean isMatch = Pattern.matches("[A-Z]{2,2}/[^*&@]{1,}", mapfieldf.get("country").get(0));
		
		if (!isMatch) {
			//throw new RuntimeException("Campo 59F [" +mapfieldf.get("name").get(0)+"] Pais o ciudad no cumple el patron AA/AAAAAAAA, " + mapfieldf.get("country").get(0));
		}
		
		f.setComponent2("1").setComponent3(mapfieldf.get("name").get(0));
		if (mapfieldf.get("name").size() > 1){
			f.setComponent4("1").setComponent5(mapfieldf.get("name").get(1));
			f.setComponent6("2").setComponent7(mapfieldf.get("address").get(0));
		}

		if (mapfieldf.get("name").size() == 1 && mapfieldf.get("address").size() >= 1){
			f.setComponent4("2").setComponent5(mapfieldf.get("address").get(0));
			if (mapfieldf.get("address").size() > 1)
				f.setComponent6("2").setComponent7(mapfieldf.get("address").get(1));
		}
		
		f.setComponent8("3").setComponent9(mapfieldf.get("country").get(0));

		return f; // return addField(f);
	}

	public static Field setField50K(String ctaNro, String location) {
		ctaNro = StringUtils.trimToEmpty(ctaNro);
		location = StringUtils.trimToEmpty(location);

		Field50K f = new Field50K();
		f.setAccount(ctaNro);

		List<String> lines = MensSwiftUtiles.splitInLines(MensSwiftUtiles.MAX_LINE_CHARS, location, 4, " ", "", 0);
		// System.out.println("location " + ArrayUtils.toString(lines));
		SwiftParseUtils.setComponentsFromLines(f, 2, 4, 0, lines);

		return f; // return addField(f);
	}

	public static Field setField50K(String ctaNro, String name, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		name = StringUtils.trim(name);
		location = StringUtils.trim(location);

		Field50K f = new Field50K();
		f.setAccount(ctaNro);
		String nameandlocation = name + " " + location;
		f.setNameAndAddressLine1(nameandlocation);
		return f; // return addField(f);
	}

	public static Field setField52A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field52A f = new Field52A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setIdentifierCode(bicswf);
		return f; // return addField(f);
	}

	public static Field setField52D(String valor) {
		valor = StringUtils.trim(valor);

		Field52D f = new Field52D();
		return f; // return addField(f);
	}

	public static Field setField53A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field53A f = new Field53A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setIdentifierCode(bicswf);

		return f; // return addField(f);
	}

	public static Field setField53B(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);

		Field53B f = new Field53B();
		f.setAccount(ctaNro);
		f.setLocation(location);

		SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 35, location);
		return f; // return addField(f);
	}

	public static Field setField53D(String valor) {
		valor = StringUtils.trim(valor);

		Field53D f = new Field53D();
		return f; // return addField(f);
	}

	public static Field setField54A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field54A f = new Field54A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setIdentifierCode(bicswf);
		return f; // return addField(f);
	}

	public static Field setField54B(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);

		Field54B f = new Field54B();
		f.setAccount(ctaNro);
		f.setLocation(location);
		SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 35, location);
		return f; // return addField(f);
	}

	public static Field setField54D(String valor) {
		valor = StringUtils.trim(valor);

		Field54D f = new Field54D();
		return f; // return addField(f);
	}

	public static Field setField56A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field56A f = new Field56A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setIdentifierCode(bicswf);
		return f; // return addField(f);
	}

	public static Field setField56D(String valor) {
		Field56D f = new Field56D();
		return f; // return addField(f);
	}

	public static Field setField57A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field57A f = new Field57A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setIdentifierCode(bicswf);
		return f; // return addField(f);
	}

	public static Field setField57B(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);

		Field57B f = new Field57B();
		f.setAccount(ctaNro);
		f.setLocation(location);
		SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 35, location);
		return f; // return addField(f);
	}

	public static Field setField57D(String ctaNro, String location) {
		if (StringUtils.isBlank(ctaNro)) {
			log.error("Nro de cuenta nulo ");
			return null;
		}
		ctaNro = StringUtils.trim(ctaNro).toUpperCase();
		if (ctaNro.startsWith("FW")) {
			ctaNro = "/".concat(ctaNro);
		}

		Field57D f = new Field57D();
		f.setAccount(ctaNro);

		location = StringUtils.trimToEmpty(location);

		List<String> lines = MensSwiftUtiles.splitInLines(MensSwiftUtiles.MAX_LINE_CHARS, location, 4, " ", "", 0);
		// System.out.println("location " + ArrayUtils.toString(lines));
		SwiftParseUtils.setComponentsFromLines(f, 3, 4, 0, lines);

		return f; // return addField(f);
	}

	public static Field setField58A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field58A f = new Field58A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setIdentifierCode(bicswf);
		return f; // return addField(f);
	}

	public static Field setField58D(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro).toUpperCase();
		location = StringUtils.trim(location).toUpperCase();

		if (ctaNro.startsWith("FW")) {
			ctaNro = "/".concat(ctaNro);
		}

		Field58D f = new Field58D();
		f.setAccount(ctaNro);
		SwiftParseUtils.setComponentsFromTokens(f, 3, 5, 35, location);
		return f; // return addField(f);
	}

	public static Field setField58D(String ctaNro, String name, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		name = StringUtils.trim(name);
		location = StringUtils.trim(location);

		Field58D f = new Field58D();
		f.setAccount(ctaNro);
		String nameandlocation = name + " " + location;
		f.setNameAndAddressLine1(nameandlocation);
		return f; // return addField(f);
	}

	public static Field setField59(String ctaNro, String name, String location) {
		if (StringUtils.isBlank(ctaNro)) {
			log.error("Nro de cuenta nulo ");
			return null;
		}

		ctaNro = StringUtils.trim(ctaNro);
		name = StringUtils.trimToEmpty(name);
		location = StringUtils.trimToEmpty(location);

		// location = name + "\n\r" + location;
		Field59 f = new Field59();
		f.setAccount(ctaNro);

		List<String> lines0 = MensSwiftUtiles.splitInLines(MensSwiftUtiles.MAX_LINE_CHARS, name, 4, " ", "", 0);
		List<String> lines1 = MensSwiftUtiles.splitInLines(MensSwiftUtiles.MAX_LINE_CHARS, location, 4, " ", "", 0);

		List<String> lines = new ArrayList<String>();
		lines.addAll(lines0);
		lines.addAll(lines1);
		SwiftParseUtils.setComponentsFromLines(f, 2, 4, 0, lines);

		return f; // return addField(f);
	}

	public static Field setField59F(String ctaNro, Map<String, List<String>> mapfieldf) {
		ctaNro = StringUtils.trimToEmpty(ctaNro);

		Field59F f = new Field59F();
		f.setAccount(ctaNro);
		if (mapfieldf.get("name").size() == 0){
			throw new RuntimeException("Nombre de beneficiario nulo o vacio");
		}
		if (mapfieldf.get("address").size() == 0){
			throw new RuntimeException("Direccion de beneficiario nulo o vacio");
		}
		if (mapfieldf.get("country").size() == 0){
			throw new RuntimeException("Pais o ciudad de beneficiario nulo o vacio");
		}
		boolean isMatch = Pattern.matches("[A-Z]{2,2}/[^*&@]{1,}", mapfieldf.get("country").get(0));
		
		if (!isMatch) {
			//throw new RuntimeException("Campo 59F [" +mapfieldf.get("name").get(0)+"] Pais o ciudad no cumple el patron AA/AAAAAAAA, " + mapfieldf.get("country").get(0));
		}
		
		int i = 2;
		f.setComponent(i++, "1");//2
		f.setComponent(i++, mapfieldf.get("name").get(0));//3
		if (mapfieldf.get("name").size() > 1){
			f.setComponent(i++, "1");//4
			f.setComponent(i++, mapfieldf.get("name").get(1));//5
		}
		
		f.setComponent(i++, "2");// 4 6
		f.setComponent(i++, mapfieldf.get("address").get(0)); // 5 7
		
		if (mapfieldf.get("address").size() > 1 && i <= 6){
			f.setComponent(i++, "2"); //  
			f.setComponent(i++, mapfieldf.get("address").get(1));
		}

		f.setComponent(i++, "3");
		f.setComponent(i++, mapfieldf.get("country").get(0));
		
//		log.info("XXX: .get(0) " + mapfieldf.get("country").get(0) + " " + f.getValue());
		return f; // return addField(f);
	}

	
	public static Field setField70(String valor) {
		if (StringUtils.isBlank(valor)) {
			return null;
		}
		String valorA = StringUtils.trimToEmpty(valor);
		valorA = borrarCaracteresSpeciales(valorA);
		// whf 20170809: para el campo 70 se reduce la cantidad de lineas de 4 a
		// 3 ya
		// que la ultima linea se la deja para el banco ordenante

		List<String> lines = MensSwiftUtiles.splitInLines(MensSwiftUtiles.MAX_LINE_CHARS - 1, valorA, 4, "", null, 0);
		int i = 1;
		StringBuilder sb = new StringBuilder();
		for(String l : lines) {
			sb.append(l).append(i++ < 4 ? "\r\n" : "");
		};
		Field70 f = new Field70(sb.toString());
		return f; // return addField(f);
	}

	public static Field setField71A(String valor) {
		if (StringUtils.isBlank(valor)) {
			return null;
		}
		valor = StringUtils.trimToEmpty(valor);
		Field71A f = new Field71A(valor);

		return f; // return addField(f);
	}

	public static Field setField71F(String codMoneda, BigDecimal monto) {
		Field71F f = new Field71F();

		Currency currency = Currency.getInstance(codMoneda);

		f.setCurrency(currency);
		f.setAmount(monto);

		return f;
	}

	public static Field setField72(String valor) {

		valor = StringUtils.trimToEmpty(valor);
		Field72 f = new Field72();
		if (StringUtils.isBlank(valor)) {
			return f;
		}

		valor = StringUtils.replaceChars(valor, "\r\n", "  ");
		valor = StringUtils.replace(valor, "//", " ");

		List<String> lines = MensSwiftUtiles.splitInLines(MensSwiftUtiles.MAX_LINE_CHARS, valor, f.componentsPattern().length(), "", "//", 1);
		SwiftParseUtils.setComponentsFromLines(f, 1, f.componentsPattern().length(), 0, lines);
		return f; // return addField(f);
	}

	public static Field setField72SinModificar(String valor) {

		valor = StringUtils.trimToEmpty(valor);
		Field72 f = new Field72(valor);
		return f; // return addField(f);
	}

	public void fromString(String swiftPlano) throws IOException {
		log.debug("fromString " + swiftPlano);
		SwiftParser swiftParser = new SwiftParser(swiftPlano);
		swiftMessage = swiftParser.message();

		// mtSwiftMessage = new MtSwiftMessage(swiftPlano);
		// mtSwiftMessage.setModelMessage(swiftMessage);
		// mtSwiftMessage.updateFromModel();
		// mtSwiftMessage.updateFromFIN();

		// log.info("FIIN " + mtSwiftMessage.getMessage());

		block1 = swiftMessage.getBlock1();
		block2 = swiftMessage.getBlock2();
		swiftBlock2Input = (SwiftBlock2Input) block2;
		block3 = swiftMessage.getBlock3();
		block4 = swiftMessage.getBlock4();

	}

	public void verificarPlano0(String swiftPlano) {
		if (StringUtils.isBlank(swiftPlano)) {
			throw new RuntimeException("Error al verificar mensaje parametro swiftPlano nulo");
		}

		try {
			// log.info("Verificando::\n" + swiftPlano);
			fromString(swiftPlano);

			// SwiftMessage swiftMessage = mtSwiftMessage.getModelMessage();
			if (swiftMessage.getBlockCount() <= 3) {
				throw new RuntimeException("numero de bloques invalido: " + swiftMessage.getBlockCount());
			}

			if (swiftMessage.getType() == null) {
				throw new RuntimeException("tipo de mensaje nulo");
			}

			if (swiftMessage.getSender() == null) {
				throw new RuntimeException("campo sender nulo");
			}

			if (swiftMessage.getReceiver() == null) {
				throw new RuntimeException("campo receiver nulo");
			}

			if (block4 == null || block4.isEmpty() || block4.getTags().size() <= 1) {
				throw new RuntimeException("bloque 4 con campos insuficientes");
			}

		} catch (Exception e) {
			log.error("Error al verificar mensaje plano:" + e.getMessage(), e);
			throw new RuntimeException("Error al verificar swift " + e.getMessage(), e);
		}
	}

	public SwiftBlock1 getBlock1() {
		return block1;
	}

	public void setBlock1(SwiftBlock1 block1) {
		this.block1 = block1;
	}

	public SwiftBlock2 getBlock2() {
		return block2;
	}

	public void setBlock2(SwiftBlock2 block2) {
		this.block2 = block2;
	}

	public SwiftBlock3 getBlock3() {
		return block3;
	}

	public void setBlock3(SwiftBlock3 block3) {
		this.block3 = block3;
	}

	public SwiftBlock4 getBlock4() {
		return block4;
	}

	public void setBlock4(SwiftBlock4 block4) {
		this.block4 = block4;
	}

	public SwiftBlock5 getBlock5() {
		return block5;
	}

	public void setBlock5(SwiftBlock5 block5) {
		this.block5 = block5;
	}

	public SwiftBlock2Input getSwiftBlock2Input() {
		return swiftBlock2Input;
	}

	public void setSwiftBlock2Input(SwiftBlock2Input swiftBlock2Input) {
		this.swiftBlock2Input = swiftBlock2Input;
	}

	public SwiftMessage getSwiftMessage() {
		return swiftMessage;
	}

	public void setSwiftMessage(SwiftMessage swiftMessage) {
		this.swiftMessage = swiftMessage;
	}

	public static String borrarCaracteresSpeciales(String concepto) {
		// int i = 0;
		concepto = StringUtils.trimToEmpty(concepto).toUpperCase();

		String s = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,-( )/?\'+:";
		StringBuffer a = new StringBuffer();
		for (int i = 0; i < concepto.length(); i++) {
			boolean esta = false;
			char c = concepto.charAt(i);
			for (int j = 0; j < s.length(); j++) {
				// flog.info(c + " " + s.charAt(j));
				if (c == s.charAt(j)) {
					esta = true;
				}
			}
			if (esta) {
				a.append(c);
			} else {
				if (c == 'Á' || c == 'á')
					a.append('A');
				else if (c == 'É' || c == 'é')
					a.append('E');
				else if (c == 'Í' || c == 'í')
					a.append('I');
				else if (c == 'Ó' || c == 'ó')
					a.append('O');
				else if (c == 'Ú' || c == 'ú')
					a.append('U');
				else if (c == 'Ñ' || c == 'ñ')
					a.append('N');
				else
					a.append(' ');
			}
		}
		return a.toString();

	}


}
