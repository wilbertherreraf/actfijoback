//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci de la referencia de enlace (JAXB) XML v2.2.8-b130911.1802 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2021.08.11 a las 04:48:30 PM BOT 
//


package gob.bcb.service.servicioSioc.ws.xml.consultasolic;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para solicitud_bolsin complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="solicitud_bolsin">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sol_codigo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sol_codpersona" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sol_persona" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sol_fecha" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sol_montosol" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="sol_montoacep" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="sol_montoadj" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="sol_beneficiario" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sol_tipsolic" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "solicitud_bolsin", propOrder = {
    "solCodigo",
    "solCodpersona",
    "solPersona",
    "solFecha",
    "solMontosol",
    "solMontoacep",
    "solMontoadj",
    "solBeneficiario",
    "solTipsolic"
})
public class SolicitudBolsin {

    @XmlElement(name = "sol_codigo", required = true)
    protected String solCodigo;
    @XmlElement(name = "sol_codpersona", required = true)
    protected String solCodpersona;
    @XmlElement(name = "sol_persona", required = true)
    protected String solPersona;
    @XmlElement(name = "sol_fecha", required = true)
    protected String solFecha;
    @XmlElement(name = "sol_montosol", required = true)
    protected BigDecimal solMontosol;
    @XmlElement(name = "sol_montoacep", required = true)
    protected BigDecimal solMontoacep;
    @XmlElement(name = "sol_montoadj", required = true)
    protected BigDecimal solMontoadj;
    @XmlElement(name = "sol_beneficiario")
    protected String solBeneficiario;
    @XmlElement(name = "sol_tipsolic")
    protected String solTipsolic;

    /**
     * Obtiene el valor de la propiedad solCodigo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSolCodigo() {
        return solCodigo;
    }

    /**
     * Define el valor de la propiedad solCodigo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSolCodigo(String value) {
        this.solCodigo = value;
    }

    /**
     * Obtiene el valor de la propiedad solCodpersona.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSolCodpersona() {
        return solCodpersona;
    }

    /**
     * Define el valor de la propiedad solCodpersona.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSolCodpersona(String value) {
        this.solCodpersona = value;
    }

    /**
     * Obtiene el valor de la propiedad solPersona.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSolPersona() {
        return solPersona;
    }

    /**
     * Define el valor de la propiedad solPersona.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSolPersona(String value) {
        this.solPersona = value;
    }

    /**
     * Obtiene el valor de la propiedad solFecha.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSolFecha() {
        return solFecha;
    }

    /**
     * Define el valor de la propiedad solFecha.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSolFecha(String value) {
        this.solFecha = value;
    }

    /**
     * Obtiene el valor de la propiedad solMontosol.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSolMontosol() {
        return solMontosol;
    }

    /**
     * Define el valor de la propiedad solMontosol.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSolMontosol(BigDecimal value) {
        this.solMontosol = value;
    }

    /**
     * Obtiene el valor de la propiedad solMontoacep.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSolMontoacep() {
        return solMontoacep;
    }

    /**
     * Define el valor de la propiedad solMontoacep.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSolMontoacep(BigDecimal value) {
        this.solMontoacep = value;
    }

    /**
     * Obtiene el valor de la propiedad solMontoadj.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSolMontoadj() {
        return solMontoadj;
    }

    /**
     * Define el valor de la propiedad solMontoadj.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSolMontoadj(BigDecimal value) {
        this.solMontoadj = value;
    }

    /**
     * Obtiene el valor de la propiedad solBeneficiario.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSolBeneficiario() {
        return solBeneficiario;
    }

    /**
     * Define el valor de la propiedad solBeneficiario.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSolBeneficiario(String value) {
        this.solBeneficiario = value;
    }

    /**
     * Obtiene el valor de la propiedad solTipsolic.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSolTipsolic() {
        return solTipsolic;
    }

    /**
     * Define el valor de la propiedad solTipsolic.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSolTipsolic(String value) {
        this.solTipsolic = value;
    }

}
