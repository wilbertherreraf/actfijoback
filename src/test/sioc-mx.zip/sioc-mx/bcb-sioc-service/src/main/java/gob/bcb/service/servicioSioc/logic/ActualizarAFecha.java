package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;

import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiId;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

public class ActualizarAFecha {
	private static final Log log = LogFactory.getLog(ActualizarAFecha.class);
	
	private CalcularVariables calcularVariables;
	private SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
	private SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
	private SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
	private SocComprobanteDao comprobanteDao = new SocComprobanteDao();
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		calcularVariables = new CalcularVariables(getSessionFactory());
		socSolicitudctasDao.setSessionFactory(getSessionFactory());
		socSolicitudesDao.setSessionFactory(getSessionFactory());
		socOpecomiDao.setSessionFactory(getSessionFactory());
		comprobanteDao.setSessionFactory(getSessionFactory());
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
	public Solicitud actualizarAFecha(Solicitud solicitudTO) {
		Date fecha = solicitudTO.getSolicitud().getFechaCont();
		log.info("oo==>Inicio : actualizarAFecha " + solicitudTO.getSolicitud().getSocCodigo() + " Fecha: " + fecha);

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}

		solicitudOld.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		solicitudOld.setEstacion(solicitudTO.getCodEstacionAudit());

		if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			// verificamos si se modifica el correlativo
			if (solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)
					|| solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_APROBADO)) {

				if (solicitudOld.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
					log.info("Actualizando CITE " + solicitudTO.getSolicitud().getReferencia());
					solicitudOld.setReferencia(solicitudTO.getSolicitud().getReferencia());
					solicitudOld = socSolicitudesDao.getHibernateTemplate().merge(solicitudOld);
				}

				// actualizamos si es en monedas
				if ((solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))) {

					String tipoNegaocia = socSolicitudesDao.getTipoDeNegociacionSolicitud(solicitudOld);
					solicitudOld.setSocTipnegociacion(tipoNegaocia);

					solicitudOld = socSolicitudesDao.getHibernateTemplate().merge(solicitudOld);

					log.info("Actualizando datos Monedas:::: " + solicitudOld.getSocCodigo());
					SocSolicitudctas socSolicitudctasBENEFMT = solicitudTO.getSocSolicitudctasMapa().get(Constants.COD_CLAVE_BENEFMT);

					socSolicitudctasDao.completarTipoCtaBenefMT(solicitudOld, socSolicitudctasBENEFMT);

					if (solicitudOld.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
						String codVaria = String.valueOf(0).concat(Constants.COD_VAR_TOTTRANSMT);
						SocOpecomi socOpecomi = solicitudTO.getSocOpecomiMap().get(codVaria);
						if (socOpecomi != null) {
							if (socOpecomi.getId() == null) {
								SocOpecomiId socOpecomiId = new SocOpecomiId();
								socOpecomi.setId(socOpecomiId);
							}
							socOpecomi.getId().setOpeCodigo(solicitudOld.getSocCodigo());
							socOpecomi.getId().setDetCodigo(0);
							socOpecomi.getId().setClaComision(Constants.COD_VAR_TOTTRANSMT);
							socOpecomi.setCveTipocomis("V");
							socOpecomi.setClaEstadovar("C");
							socOpecomi.setFechaHora(new Date());
							socOpecomi.setOcoMonto(BigDecimal.ZERO);
							socOpecomi.setOcoMontoimpt(BigDecimal.ZERO);
							socOpecomi.setTipoCambio(BigDecimal.ZERO);

							socOpecomi.setEstacion(solicitudTO.getCodEstacionAudit());
							socOpecomi.setUsrCodigo(solicitudTO.getCodUsuarioAudit());

							socOpecomi = socOpecomiDao.getHibernateTemplate().merge(socOpecomi);
						}
					} else {
						// si es normal se camvia su esatado a regostrado para
						// que se acutlice
						SocOpecomi socOpecomi = socOpecomiDao.findByCveTipocomis(solicitudOld.getSocCodigo(), 0, Constants.COD_VAR_TOTTRANSMT, null);
						if (socOpecomi != null) {
							socOpecomi.setClaEstadovar("R");
							socOpecomi = socOpecomiDao.getHibernateTemplate().merge(socOpecomi);
						}
					}
				}
			}
		}

		solicitudTO.setSolicitud(solicitudOld);
		if (!solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			// control si el uuario es un solicitante
			if (!solicitudTO.getSolicitud().getSolEntsolic().equals(solicitudTO.getCodPersonaAudit())) {
				throw new BusinessException("Solicitud no fue generada por el solicitante [" + solicitudTO.getCodPersonaAudit()
						+ "]no puede continuar " + solicitudTO.getSolicitud().getSocCodigo());
			}
		}

		if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)
				|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {

			fecha = new Date();

			if (solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
				if (!solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
					SocSolicitudctas socSolicitudctasMOVPROVISION = socSolicitudctasDao.getCuenta(solicitudOld.getSocCodigo(),
							Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);
					if (socSolicitudctasMOVPROVISION.getNroCuenta().equals(Constants.CTA_TRANSIT_PROV)
							|| socSolicitudctasMOVPROVISION.getNroCuenta().equals(Constants.CTA_TRANSIT_SECPUBGOI)) {
						// si la cuenta no le pertenece al solicitante es decir
						// es cuenta transitoria no se contabiliza
						log.info("XXX: FECHA CONT NULO POR " + socSolicitudctasMOVPROVISION.getNroCuenta());
						fecha = null;
					}
					if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)){
						SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
						socSolicitanteDao.setSessionFactory(getSessionFactory());
						SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudOld.getSolCodigo());
						if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
							// si es transfrencia del exterior y es del sistema financiero no se contabiliza
							fecha = null;
							solicitudOld.setFechaCont(fecha);
							socSolicitudesDao.saveOrUpdate(solicitudTO.getSolicitud());
							solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());
							solicitudTO.setSolicitud(solicitudOld);							
							log.info("solicitud actualizada para fecha operacion " + solicitudTO.getSolicitud().getSocCodigo());
							
							return solicitudTO;							
						}
					}
				}
			}
		}
		
		solicitudTO = calcularVariables.guardarVariablesSolicitud(solicitudTO, null);

		if (fecha != null) {
			solicitudOld.setFechaCont(fecha);
			socSolicitudesDao.saveOrUpdate(solicitudTO.getSolicitud());
		}
		
		solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		solicitudOld.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		solicitudOld.setEstacion(solicitudTO.getCodEstacionAudit());

		solicitudTO.setSolicitud(solicitudOld);

		if (solicitudOld.getFechaCont() != null) {
			Boolean esCartas = (solicitudTO.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
					|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS));
			
			if (esCartas) {
				CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
				cartasCredService.actualizarAFecha(solicitudTO);
			} 
			
			log.info("fecha contable asignada  " + solicitudTO.getSolicitud().getSocCodigo() + " Fecha: " + solicitudOld.getFechaCont());
			if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
				if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
					if (solicitudTO.getSolicitud().getSolEntsolic().equals(Constants.COD_BCB)) {
						// pertenece al bcb
						if (solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)) {
							generarMensSwift(solicitudTO);
						}
					} else {
						if (solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_APROBADO)) {
							generarMensSwift(solicitudTO);
						}
					}
				}
			}

		}

		comprobanteDao.procesarSolicitud(solicitudTO);

		log.info("solicitud actualizada para fecha operacion " + solicitudTO.getSolicitud().getSocCodigo());
		return solicitudTO;
	}

	private Solicitud generarMensSwift(Solicitud solicitudTO) {
		if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			log.info("==>GENERAR MENSAJES SWIFTS " + solicitudTO.getSolicitud().getSocCodigo());
			SwiftSiocService swiftSiocService = new SwiftSiocService();
			swiftSiocService.setSessionFactory(getSessionFactory());

			swiftSiocService.generarMensSwift(solicitudTO);
		}
		return solicitudTO;
	}

	public Solicitud actualizarAFechaPreContab(Solicitud solicitudTO) {
		log.info("=====oo [actualizarAFechaPreContab] oo===== " + solicitudTO.getSolicitud().getSocCodigo());

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}
		solicitudTO.setSolicitud(solicitudOld);
		boolean esCartas = solicitudTO.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS) 
		|| solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);
		
		if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {

			actualizarAFecha(solicitudTO);
		} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				actualizarAFecha(solicitudTO);
			}
		} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				// si es uusario bcb
				// la soslicitud fue fenerada por el bcb
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}
				actualizarAFecha(solicitudTO);
			} 		
		} else if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT) && !esCartas) {
			// CAMBIA de acuerdo al usuario que genera la operacion en el
			// cliente
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				// si es uusario bcb
				// la soslicitud fue fenerada por el bcb
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}
				actualizarAFecha(solicitudTO);
			} else {
				// el usuario es el solicitante
				if (!solicitudTO.getSolicitud().getSolEntsolic().equals(solicitudTO.getCodPersonaAudit())) {
					throw new BusinessException(
							"Solicitud no fue generada por el solicitante [" + solicitudTO.getCodPersonaAudit()
									+ "]no puede continuar " + solicitudTO.getSolicitud().getSocCodigo());
				}

				if (!solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
					throw new BusinessException("Solicitud no fue creada por el solicitante ["
							+ solicitudTO.getSolicitud().getCveTipctasolic() + "]no puede continuar "
							+ solicitudTO.getSolicitud().getSocCodigo());
				}

				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_VERIFICADO)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "] no puede continuar " + solicitudTO.getSolicitud().getSocCodigo() + " requiere estado: " + Constants.CLAVE_ESTSOLIC_VERIFICADO);
				}
				actualizarAFecha(solicitudTO);
			}
		} else if (esCartas) {
			if (solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				if (UtilsDate.compara(solicitudTO.getSolicitud().getFechaCont(), new Date()) != 0) {
					throw new BusinessException("Fecha de contabilización difiere a fecha actual, actualice los datos.");					
				}
				
				if (!solicitudTO.getSolicitud().getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PREAUT)) {
					throw new BusinessException(
							"Solicitud con estado invalido [" + solicitudTO.getSolicitud().getClaEstado()
									+ "]no puede autorizar " + solicitudTO.getSolicitud().getSocCodigo());
				}
				CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
				cartasCredService.obtenerRegistroDetallePreautorizado(solicitudTO.getSolicitud().getSocCodigo());
				
				actualizarAFecha(solicitudTO);
			}						
		}

		return solicitudTO;
	}
	
}
