//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci de la referencia de enlace (JAXB) XML v2.2.8-b130911.1802
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2021.08.11 a las 02:27:16 PM BOT 
//


package gob.bcb.service.servicioSioc.ws.xml.consultasolic;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para solicitudes_bolsin complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="solicitudes_bolsin">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="solicitud_bolsin" type="{}solicitud_bolsin" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "solicitudes_bolsin", propOrder = {
    "solicitudBolsin"
})
public class SolicitudesBolsin {

    @XmlElement(name = "solicitud_bolsin")
    protected List<SolicitudBolsin> solicitudBolsin;

    /**
     * Gets the value of the solicitudBolsin property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the solicitudBolsin property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSolicitudBolsin().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SolicitudBolsin }
     * 
     * 
     */
    public List<SolicitudBolsin> getSolicitudBolsin() {
        if (solicitudBolsin == null) {
            solicitudBolsin = new ArrayList<SolicitudBolsin>();
        }
        return this.solicitudBolsin;
    }

}
