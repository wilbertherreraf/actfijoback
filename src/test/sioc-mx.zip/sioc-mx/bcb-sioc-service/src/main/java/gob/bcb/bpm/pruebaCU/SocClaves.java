package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the soc_claves database table.
 * 
 */
@Entity
@Table(name="soc_claves")
public class SocClaves implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cla_codigo")
	private String claCodigo;

	@Column(name="cla_nombre")
	private String claNombre;

	private String estacion;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocClaves() {
    }

	public String getClaCodigo() {
		return this.claCodigo;
	}

	public void setClaCodigo(String claCodigo) {
		this.claCodigo = claCodigo;
	}

	public String getClaNombre() {
		return this.claNombre;
	}

	public void setClaNombre(String claNombre) {
		this.claNombre = claNombre;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

}