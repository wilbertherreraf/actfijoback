/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SocBenefsregDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocBenefsregDao.class);

	public void saveOrUpdate(SocBenefs socBenefs, SocBenefsreg socBenefsreg) {
		log.info("Saving or updating " + socBenefsreg);

		SocBenefsreg socBenefsregOld = getBenefsregByCodBen(socBenefsreg.getSolCodigo(), socBenefsreg.getBenCodigo(), socBenefsreg.getCuentab());

		if (socBenefsregOld == null) {
			Integer cod = generarCodigo();

			socBenefsreg.setNroRegbenef(cod);
			socBenefsreg.setBenCodigo(socBenefs.getBenCodigo());
		}

		this.getHibernateTemplate().saveOrUpdate(socBenefsreg);
	}

	public SocBenefsreg getBenefsregByCodigo(Integer nroRegbenef) {

		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBenefsreg be ");
		query = query.append("where be.nroRegbenef = :nroRegbenef ");

		log.debug("Entre a buscar getBenefsregByCod id: " + nroRegbenef);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("nroRegbenef", nroRegbenef);
		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocBenefsreg) lista.get(0);
		}

		return null;
	}

	public SocBenefsreg getBenefsregByCodBen(String solCodigo, String benCodigo, String cuentab) {

		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBenefsreg be ");
		query = query.append("where be.benCodigo = :benCodigo ");
		query = query.append("and be.solCodigo = :solCodigo ");
		query = query.append("and be.cuentab = :cuentab ");

		log.debug("Entre a buscar getBenefsregByCod id: " + solCodigo + " " + benCodigo);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("benCodigo", benCodigo);
		consulta.setParameter("solCodigo", solCodigo);
		consulta.setParameter("cuentab", cuentab);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocBenefsreg) lista.get(0);
		}

		return null;
	}

	public Integer getBenefsregPend(String solCodigo, String benCodigo, String cuentab, Integer codMoneda, Integer ctaCodigobco) {

		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBenefsreg be ");
		query = query.append("where be.benCodigo = :benCodigo ");
		query = query.append("and be.solCodigo = :solCodigo ");
		query = query.append("and be.cuentab = :cuentab ");
		query = query.append("and be.codMoneda = :codMoneda ");
		query = query.append("and be.ctaCodigobco = :ctaCodigobco ");
		query = query.append("and be.benEstcta in ('1') ");

		query = query.append("and not exists (select 1 ");
		query = query.append("from SocBenefsreg be2 ");
		query = query.append("where be2.benCodigo = be.benCodigo ");
		query = query.append("and be2.solCodigo = be.solCodigo ");
		query = query.append("and be2.cuentab = be.cuentab ");
		query = query.append("and be2.codMoneda = be.codMoneda ");
		query = query.append("and be2.ctaCodigobco = be.ctaCodigobco ");
		query = query.append("and be2.benEstcta = 'A' ) ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("benCodigo", benCodigo);
		consulta.setParameter("solCodigo", solCodigo);
		consulta.setParameter("cuentab", cuentab);
		consulta.setParameter("codMoneda", codMoneda);
		consulta.setParameter("ctaCodigobco", ctaCodigobco);

		List lista = consulta.list();

		// log.info("Entre a buscar getBenefsregPend id: " + solCodigo + " " + benCodigo
		// + " cta: " +cuentab + "["+codMoneda+"] cta: " + ctaCodigobco + " -> " +
		// lista.size());
		return lista.size();
	}

	public Solicitud registrarBeneficiario(Solicitud solicitudTO) {
		log.info("Registro de nuevo beneficiario " + solicitudTO.getBeneficiario().getSocBenefs().toString());

		Beneficiario beneficiario = solicitudTO.getBeneficiario();

		SocCuentas socCuentas = beneficiario.getSocCuentas();
		
		verificaEstCta(socCuentas, Constants.CLAVE_VIGENTE_PENDAUTO);
		verificaBenef(socCuentas);
		verificaBanco(socCuentas);
		
		socCuentas.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socCuentas.setEstacion(solicitudTO.getCodEstacionAudit());

		// seteamos a en modificacion
		socCuentas.setClaVigente(Constants.CLAVE_VIGENTE_PENDAUTO);
		SocCuentas socCuentasNew = actualizarCuenta(socCuentas);

		SocBenefsreg socBenefsreg = crearBenefsReg(solicitudTO, socCuentasNew);
		actSolBenefs(socCuentasNew);

		beneficiario.setSocCuentas(socCuentasNew);
		solicitudTO.setBeneficiario(beneficiario);

		elaborarCorreoCta(socCuentasNew);
		log.info("Fin registro de nuevo beneficiario " + socBenefsreg.toString());
		return solicitudTO;
	}

	public Solicitud autorizarBenef(Solicitud solicitudTO) {
		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());

		log.info("autorizarBenef beneficiario ");
		Beneficiario beneficiario = solicitudTO.getBeneficiario();

		SocCuentas socCuentasIn = beneficiario.getSocCuentas();
		verificaEstCta(socCuentasIn, Constants.CLAVE_VIGENTE_VIG);
		
		SocCuentas socCuentas = socCuentasDao.getSocCuentasByCodigo(socCuentasIn.getCtaCodigo());
		verificaBenef(socCuentas);
		verificaBanco(socCuentas);
		
		socCuentas.setClaVigente(Constants.CLAVE_VIGENTE_VIG);
		socCuentas.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socCuentas.setEstacion(solicitudTO.getCodEstacionAudit());
		
		SocCuentas socCuentasNew = actualizarCuenta(socCuentas);

//		SocBenefsreg socBenefsreg = getBenefsregByCodigo(solicitudTO.getBeneficiario().getSocBenefsreg().getNroRegbenef());
//		socBenefsreg.setBenEstcta(Constants.CVE_ESTBENEF_AUT);
//		socBenefsreg.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
//		socBenefsreg.setEstacion(solicitudTO.getCodEstacionAudit());
//		socBenefsreg.setFechaHora(new Date());
//
//		this.getHibernateTemplate().saveOrUpdate(socBenefsreg);

		log.info("Autorizando registro cuenta beneficiao..." + socCuentasNew.getCtaCodigo());
		elaborarCorreoCta(socCuentasNew);
		
		return solicitudTO;
	}

	public Solicitud rechazarRegBenef(Solicitud solicitudTO) {
		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());

		Beneficiario beneficiario = solicitudTO.getBeneficiario();

		SocCuentas socCuentasIn = beneficiario.getSocCuentas();
		
		log.info("Rechanzado registro beneficiario " + solicitudTO.getBeneficiario().getSocBenefsreg().getNroRegbenef());

		verificaEstCta(socCuentasIn, Constants.CLAVE_VIGENTE_ENMOD);
		
		SocCuentas socCuentas = socCuentasDao.getSocCuentasByCodigo(socCuentasIn.getCtaCodigo());
		socCuentas.setClaVigente(Constants.CLAVE_VIGENTE_ENMOD);
		socCuentas.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socCuentas.setEstacion(solicitudTO.getCodEstacionAudit());

		SocCuentas socCuentasNew = actualizarCuenta(socCuentas);

//		SocBenefsreg socBenefsreg = getBenefsregByCodigo(solicitudTO.getBeneficiario().getSocBenefsreg().getNroRegbenef());
//		socBenefsreg.setBenEstcta(Constants.CVE_ESTBENEF_REG);
//		socBenefsreg.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
//		socBenefsreg.setEstacion(solicitudTO.getCodEstacionAudit());
//		socBenefsreg.setFechaHora(new Date());
//
//		this.getHibernateTemplate().saveOrUpdate(socBenefsreg);

		log.info("Rechazado registro beneficiao..." + socCuentas.getCtaCodigo());
		elaborarCorreoCta(socCuentasNew);
		return solicitudTO;
	}

	public Solicitud actualizaCuentaBenef(Solicitud solicitudTO) {
		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());

		log.info("autorizarBenef beneficiario ");
		Beneficiario beneficiario = solicitudTO.getBeneficiario();
		SocCuentas socCuentas = socCuentasDao.getSocCuentasByCodigo(beneficiario.getSocCuentas().getCtaCodigo());

		socCuentas.setClaVigente(beneficiario.getSocCuentas().getClaVigente());
		socCuentas.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socCuentas.setEstacion(solicitudTO.getCodEstacionAudit());
		
		socCuentasDao.saveOrUpdateSolo(socCuentas);
		SocCuentas socCuentasNew = socCuentasDao.getSocCuentasByCodigo(beneficiario.getSocCuentas().getCtaCodigo());

		log.info("actualizando cuenta..." + beneficiario.getSocCuentas().getCtaCodigo());
		elaborarCorreoCta(socCuentasNew);
		
		return solicitudTO;
	}

	private void validarDato(SocBenefsreg socBenefsreg) {
		if (StringUtils.isBlank(socBenefsreg.getSolCodigo())) {
			throw new BusinessException("Codigo de solicitante invalido");
		}
		if (StringUtils.isBlank(socBenefsreg.getIdent())) {
			throw new BusinessException("Tipo cuenta banco invalido");
		}

		if (StringUtils.isBlank(socBenefsreg.getBcoCodigo())) {
			if (StringUtils.isBlank(socBenefsreg.getBanco())) {
				throw new BusinessException("Banco con nombre invalido");
			}
			if (StringUtils.isBlank(socBenefsreg.getPlaza())) {
				throw new BusinessException("Plaza con nombre invalido");
			}
			if (socBenefsreg.getIdent().equals(Constants.CVE_TIPOBCOINST_BIC)) {
				if (StringUtils.isBlank(socBenefsreg.getBic())) {
					// throw new BusinessException("BIC banco beneficiario invalido");
				}
			}
		}

		if (StringUtils.isBlank(socBenefsreg.getCuentab())) {
			throw new BusinessException("Numero cuenta beneficiario invalido");
		}
		if (socBenefsreg.getCodMoneda() == null) {
			throw new BusinessException("Moneda cuenta beneficiario invalido");
		}
		if (socBenefsreg.getIdent().equals(Constants.CVE_TIPOBCOINST_ABA)) {
			if (StringUtils.isBlank(socBenefsreg.getBcoNrocuentaben())) {
				throw new BusinessException("Nro cta banco beneficiario invalido");
			}
		}
		if (StringUtils.isBlank(socBenefsreg.getBenTipoctainst())) {
//			throw new BusinessException("Tipo de intermediario invalido");
		}

		if (socBenefsreg.getIdent().equals(Constants.CVE_TIPOBCOINST_INTER) ) {
			if (StringUtils.isBlank(socBenefsreg.getBcoCodigointer())) {
				if (StringUtils.isBlank(socBenefsreg.getBancoInt())) {
					throw new BusinessException("Banco Intermediario con nombre invalido");
				}
				if (StringUtils.isBlank(socBenefsreg.getPlazaInt())) {
					// throw new BusinessException("Banco Intermediario con Plaza invalido");
				}
				if (StringUtils.isBlank(socBenefsreg.getBicInt())) {
					// throw new BusinessException("Banco Intermediario con BIC invalido");
				}
			}
		}
	}

	private void verificaEstCta(SocCuentas socCuentas, Short claVigenteNew) {
		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());
		
		if (socCuentas.getCtaCodigo() == null) {
			return;
		}
		
		SocCuentas socCuentasOld = socCuentasDao.getSocCuentasByCodigo(socCuentas.getCtaCodigo());
		if (socCuentasOld == null) {
			throw new BusinessException("Cuenta beneficiario inexistente " + socCuentas.getCtaCodigo() );
		}
		
		if (claVigenteNew.compareTo(Constants.CLAVE_VIGENTE_PENDAUTO) == 0) {
			if (socCuentasOld.getClaVigente().compareTo(Constants.CLAVE_VIGENTE_PENDAUTO) == 0) {
				throw new BusinessException("Cuenta beneficiario con estado " + socCuentasOld.getClaVigente() + ", se esperaba diferente a estado " + Constants.CLAVE_VIGENTE_PENDAUTO);
			}
		} else if (claVigenteNew.compareTo(Constants.CLAVE_VIGENTE_VIG) == 0) {
			if (socCuentasOld.getClaVigente().compareTo(Constants.CLAVE_VIGENTE_ENMOD) == 0 //
					|| socCuentasOld.getClaVigente().compareTo(Constants.CLAVE_VIGENTE_SUSP) == 0 ) {
				throw new BusinessException("Cuenta con estado " + socCuentasOld.getClaVigente() + ", se esperaba estado 1,3");
			}
		}
	}
	
	private void verificaBenef(SocCuentas socCuentas) {
		SocBenefsDao socBenefsDao   = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());
		
		SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(socCuentas.getBenCodigo());
		if (socBenefs == null) {
			throw new BusinessException("Beneficiario inexistente " + socCuentas.getBenCodigo());
		}
		
		if (socBenefs.getClaVigente() == null || socBenefs.getClaVigente().compareTo(Constants.CLAVE_VIGENTE_VIG) != 0) {
			throw new BusinessException("Beneficiario con estado invalido " + socBenefs.getClaVigente());
		}
	}
	
	private void verificaBanco(SocCuentas socCuentas) {
		SocBancosDao socBancosDao   = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());
		
		List<BancoPlaza> bancoPlazaList = socBancosDao.getBancosPlazas(socCuentas.getBcoCodigo(), null);

		if (bancoPlazaList.size() == 0) {
			throw new BusinessException("Banco inexistente " + socCuentas.getBcoCodigo());
		}

		SocPlazas socBancos = bancoPlazaList.get(0).getSocPlazas();		
		if (socBancos.getClaVigente() == null || socBancos.getClaVigente().compareTo(Constants.CLAVE_VIGENTE_VIG) != 0) {
			throw new BusinessException("Banco Beneficiario "+ socCuentas.getBcoCodigo() +" con estado invalido " + socBancos.getClaVigente());
		}
		
		if (!StringUtils.isBlank(socCuentas.getBcoCodigointer())){
			bancoPlazaList = socBancosDao.getBancosPlazas(socCuentas.getBcoCodigointer(), null);

			if (bancoPlazaList.size() == 0) {
				throw new BusinessException("Banco intermediario inexistente " + socCuentas.getBcoCodigointer());
			}
			socBancos = bancoPlazaList.get(0).getSocPlazas();
			if (socBancos.getClaVigente() == null || socBancos.getClaVigente().compareTo(Constants.CLAVE_VIGENTE_VIG) != 0) {
				throw new BusinessException("Banco Intermediario "+ socCuentas.getBcoCodigointer() +" con estado invalido " + socBancos.getClaVigente());
			}			
		}
		
	}
	
	private Integer generarCodigo() {
		StringBuffer query = new StringBuffer();
		query = query.append("select max(nro_regbenef) ");
		query = query.append("from soc_benefsreg ");

		Query consulta = getSession().createSQLQuery(query.toString());

		log.debug("Entre a generarCod " + consulta.toString());

		String codSolicitud = "0";
		Long codigo = Long.valueOf(0);

		Integer maxi = null;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (Integer) result.get(0);

		if (maxi == null) {
			maxi = 0;
		}

		maxi++;

		// codSolicitud = String.format("%06d", codigo);
		// Integer codBen = Integer.valueOf(codSolicitud);
		log.info("Cod registro benef nuevo: " + codigo);
		return maxi;
	}

	private void elaborarCorreoCta(SocCuentas socCuentas) {
		SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
		socUsuariosolDao.setSessionFactory(getSessionFactory());

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());
		
		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socCuentas.getSolCodigo());

		SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(socCuentas.getBenCodigo());
		
		SocValorescla socValorescla = socValoresclaDao.getValoresByCod(Constants.CLA_VIGENTE, socCuentas.getClaVigente().toString());
		
		String tipoMensajemail = "REGBENEF";
		String content = "Se registro en el sistema SIOC cambios en cuenta de beneficiario " + "\r\n";
		content += "\r\n";
		content += "Beneficiario:" + socBenefs.getBenNombre();
		content += "\r\n";
		content += "Entidad:" + socSolicitante.getSolPersona();
		content += "\r\n";
		content += "Cuenta:" + socCuentas.getCtaNrocuenta() + ", estado: " + socValorescla.getValNombre().toUpperCase();
		content += "\r\n";
		content += "Usuario:" + socCuentas.getUsrCodigo();
		String subject = "Se registro cambios en cuenta de beneficiario al exterior:" + socBenefs.getBenCodigo();
		socUsuariosolDao.formarMail(tipoMensajemail, subject, content, "'900'");
	}

	private SocCuentas actualizarCuenta(SocCuentas socCuentas) {
		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());
		//bcocodigoben
		socCuentas.setPlaCodigo(1);
		// socCuentas.setClaVigente(Short.valueOf("0"));

		SocCuentas socCuentasnew = socCuentasDao.saveOrUpdate(socCuentas);
		return socCuentasnew;
	}

	private SocBenefsreg crearBenefsReg(Solicitud solicitudTO, SocCuentas socCuentas) {
		log.info("Nueva solicitud de MOD cuenta REG " + socCuentas.getCtaCodigo());

		Beneficiario beneficiario = solicitudTO.getBeneficiario();

		SocBenefsreg socBenefsreg = beneficiario.getSocBenefsreg();
		socBenefsreg.setCtaCodigobco(socCuentas.getCtaCodigo());
		socBenefsreg.setBcoCodigo(socCuentas.getBcoCodigo());
		socBenefsreg.setBcoCodigointer(socCuentas.getBcoCodigointer());
		socBenefsreg.setBcoNrocuentaben(socCuentas.getBcoNrocuentaben());
		log.info("XXX " + socCuentas.getBcoNrocuentaben());
		socBenefsreg.setSolCodigo(socCuentas.getSolCodigo());
		socBenefsreg.setCuentab(socCuentas.getCtaNrocuenta());
		socBenefsreg.setCodMoneda(socCuentas.getMoneda());
		socBenefsreg.setInfo(socCuentas.getCtaInfo());
		socBenefsreg.setIdent(socCuentas.getCveTipbcoben());

		// 3. registro de datos temporales del registro del beneficiario
		socBenefsreg.setBenEstcta(Constants.CVE_ESTBENEF_VERIF);
		socBenefsreg.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socBenefsreg.setEstacion(solicitudTO.getCodEstacionAudit());
		socBenefsreg.setFechaHora(new Date());

		validarDato(socBenefsreg);

		if (socBenefsreg.getNroRegbenef() == null) {
			Integer cod = generarCodigo();
			socBenefsreg.setNroRegbenef(cod);

			Integer contPend = getBenefsregPend(socBenefsreg.getSolCodigo(), socBenefsreg.getBenCodigo(), socBenefsreg.getCuentab(),
					socBenefsreg.getCodMoneda(), socBenefsreg.getCtaCodigobco());
			if (contPend.compareTo(0) > 0) {
				throw new BusinessException("Existen registros de cuenta pendientes de autorizacion. benef: " + socBenefsreg.getBenCodigo());
			}
		}

		this.getHibernateTemplate().saveOrUpdate(socBenefsreg);
		SocBenefsreg socBenefsregNew = getBenefsregByCodigo(socBenefsreg.getNroRegbenef());

		// elaborarCorreoCta(socCuentas, SocBenefsreg socBenefsreg);
		log.info("Fin registro de nuevo beneficiario " + socBenefsregNew.toString());
		return socBenefsregNew;
	}

	private void actSolBenefs(SocCuentas socCuentas) {
		SocSolbenefsDao socSolbenefsDao = new SocSolbenefsDao();
		socSolbenefsDao.setSessionFactory(getSessionFactory());

		SocSolbenefsId socSolbenefsId = new SocSolbenefsId();
		socSolbenefsId.setBenCodigo(socCuentas.getBenCodigo());
		socSolbenefsId.setSolCodigo(socCuentas.getSolCodigo());

		SocSolbenefs socSolbenef = new SocSolbenefs();
		socSolbenef.setId(socSolbenefsId);

		socSolbenef.setClaVigente(Short.valueOf("1"));
		socSolbenef.setCtaCodigobco(socCuentas.getCtaCodigo());
		socSolbenef.setEstacion(socCuentas.getEstacion());
		socSolbenef.setUsrCodigo(socCuentas.getUsrCodigo());

		// ******** salvando relacion solicitante beneficiario *********//
		socSolbenefsDao.saveOrUpdate(socSolbenef);

	}
}
