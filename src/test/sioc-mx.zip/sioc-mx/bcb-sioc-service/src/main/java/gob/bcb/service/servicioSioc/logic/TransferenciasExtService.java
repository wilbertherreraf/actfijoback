package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.commons.lang.StringUtils;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

public class TransferenciasExtService {
	private final Logger log = LoggerFactory.getLogger(TransferenciasExtService.class);

	private final SocDetallessolDao socDetallessolDao;
	private final SocSolicitudesDao socSolicitudesDao;
	private final SocEsquemasDao socEsquemasDao;
	private final SocSolicitudctasDao socSolicitudctasDao;
	private final SocCuentassolDao socCuentassolDao;
	private final SocBenefsDao socBenefsDao;
	private final SocSolicitanteDao socSolicitanteDao;
	private final SocOpecomiDao socOpecomiDao;
	private final SocBancosDao socBancosDao;
	private final SessionFactory sessionFactorySioc;
	private final SessionFactory sessionFactoryCoin;

	private final CartasCredSolicitudService cartasCredSolicitudService;

	public static final Integer ESQ_CODIGO_PAGO = 281;
	public static final Integer ESQ_CODIGO_ENMIENDA_AMPLIACION = 283;

	public TransferenciasExtService(SessionFactory sessionFactorySioc, SessionFactory sessionFactoryCoin) {
		this.socDetallessolDao = new SocDetallessolDao();
		this.socDetallessolDao.setSessionFactory(sessionFactorySioc);

		this.sessionFactorySioc = sessionFactorySioc;
		this.sessionFactoryCoin = sessionFactoryCoin;

		this.socEsquemasDao = new SocEsquemasDao();
		this.socEsquemasDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitudesDao = new SocSolicitudesDao();
		this.socSolicitudesDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitudctasDao = new SocSolicitudctasDao();
		this.socSolicitudctasDao.setSessionFactory(sessionFactorySioc);

		this.socCuentassolDao = new SocCuentassolDao();
		this.socCuentassolDao.setSessionFactory(sessionFactorySioc);

		this.socBenefsDao = new SocBenefsDao();
		this.socBenefsDao.setSessionFactory(sessionFactorySioc);

		this.socSolicitanteDao = new SocSolicitanteDao();
		this.socSolicitanteDao.setSessionFactory(sessionFactorySioc);

		this.socOpecomiDao = new SocOpecomiDao();
		this.socOpecomiDao.setSessionFactory(sessionFactorySioc);

		this.socBancosDao = new SocBancosDao();
		this.socBancosDao.setSessionFactory(sessionFactorySioc);

		this.cartasCredSolicitudService = new CartasCredSolicitudService(sessionFactorySioc, sessionFactoryCoin);
	}

	public Function<SocSolicitudes, Solicitud> recuperarDatosSocCodigoEsquema(SocSolicitudes socSolicitudesInit, SocEsquemas socEsquemas,
			Consumer<Solicitud> procesoComplementario) {
		return socSolicitudes -> {

			Solicitud solicitud = cartasCredSolicitudService.recuperarOCrearSolicitud().apply(socSolicitudes);
			completarSocSolicitudesNuevo(socSolicitudesInit).andThen(recuperarDatosComplementariosSolicitud()).accept(solicitud);

			procesoComplementario.accept(solicitud);
			return solicitud;
		};
	}

	public Solicitud recuperarDatosSocCodigoEsquema0(String socCodigo, Integer esqcodigo) {
		log.info("Recuperando " + socCodigo + " : " + esqcodigo);

		Solicitud solicitud = cartasCredSolicitudService.recuperarSolicitudOpt(socCodigo, esqcodigo);

		// return
		// cartasCredSolicitudService.recuperarDatosComplementariosSolicitud(solicitud);
		return null;
	}

	public Function<SocSolicitudes, List<SocSolicitante>> listaSolicitantes(SocSolicitudes socSolicitudesInit, String claTipoEntidad) {
		return socSolicitudes -> {
			List<SocSolicitante> socSolicitanteLista = new ArrayList<SocSolicitante>();
			Boolean seListaSolicitantes = esNuevo(socSolicitudes) && esGeneradoPorUsuarioBCB(socSolicitudesInit);

			if (seListaSolicitantes) {
				Supplier<List<SocSolicitante>> con = () -> {
					return socSolicitanteDao.solicitantesByCod(null, claTipoEntidad);
				};

				socSolicitanteLista = socSolicitanteDao.solicitantesByCod(null, claTipoEntidad);
			}
			Boolean solCodigoValido = !esNuevo(socSolicitudes) && socSolicitudes.getSolCodigo() != null && socSolicitudes.getSolCodigo().trim().length() > 0;

			if (solCodigoValido) {
				socSolicitanteLista = socSolicitanteDao.solicitantesByCod(socSolicitudes.getSolCodigo(), null);
			}

			Boolean solCodigoValidoNuevo = esNuevo(socSolicitudes) && !esGeneradoPorUsuarioBCB(socSolicitudesInit)
					&& socSolicitudesInit.getSolEntsolic() != null && socSolicitudesInit.getSolEntsolic().trim().length() > 0;

			if (solCodigoValidoNuevo) {
				socSolicitanteLista = socSolicitanteDao.solicitantesByCod(socSolicitudesInit.getSolEntsolic(), null);
			}
			return socSolicitanteLista;
		};
	}

	public Function<SocSolicitudes, List<Beneficiario>> listaBeneficiarios(SocDetallessol socDetallessol) {
		// List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();
		return socSolicitudes -> {
			List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();

			Boolean validaPorNuevo = esNuevo(socSolicitudes) && socSolicitudes.getSolCodigo() != null && socSolicitudes.getSolCodigo().trim().length() > 0;
			Boolean monedaValido = socSolicitudes.getCodMonedat() != null && !socSolicitudes.getCodMonedat().equals(0);

			Boolean validoPorModificable = esModificable(socSolicitudes) && monedaValido;

			if ((validaPorNuevo && monedaValido) || validoPorModificable) {
				beneficiarios = socBenefsDao.beneficiariosExternosSolicitante(socSolicitudes.getSolCodigo(), null, socSolicitudes.getCodMonedat(), null,
						false);
			}

			Boolean beneficiarioValido = socDetallessol.getBenCodigo() != null && socDetallessol.getBenCodigo().trim().length() > 0;
			if (!esNuevo(socSolicitudes) && !esModificable(socSolicitudes)) {
				if (beneficiarioValido) {
					beneficiarios = socBenefsDao.beneficiariosExternosSolicitante(socSolicitudes.getSolCodigo(), socDetallessol.getBenCodigo(), null, null,
							false);
				}
			}

			return beneficiarios;
		};
	}

	public Function<SocSolicitudes, List<SocCuentassol>> listaCuentasSolicitante() {
		return socSolicitudes -> {
			Boolean validaPorNuevo = esNuevo(socSolicitudes) && socSolicitudes.getSolCodigo() != null && socSolicitudes.getSolCodigo().trim().length() > 0;
			Boolean monedaValido = socSolicitudes.getCodMonedat() != null && !socSolicitudes.getCodMonedat().equals(0);
			Boolean validoPorModificable = esModificable(socSolicitudes) && monedaValido;
			Boolean validaCodigoSolic = socSolicitudes.getSolCodigo() != null && socSolicitudes.getSolCodigo().trim().length() > 0;

			List<SocCuentassol> socCuentassolLista = new ArrayList<SocCuentassol>();
			if (esBCBSolicitante(socSolicitudes)) {
				List<SocCuentassol> socCuentassolListaACREE = socCuentassolDao.findByClaveCuenta(Constants.COD_CLAVE_CTAACREEDORES);
				List<SocCuentassol> socCuentassolListaACREEBCB = socCuentassolDao.findByClaveCuenta(Constants.COD_CLAVE_CTAACREEDORESBCB);

				socCuentassolLista.addAll(socCuentassolListaACREE);
				socCuentassolLista.addAll(socCuentassolListaACREEBCB);
			} else {
				if (validaCodigoSolic)
					socCuentassolLista = socCuentassolDao.ctasSolicitante(socSolicitudes.getSolCodigo(), null, null, socSolicitudes.getCodMonedat(), null,
							null, null);
			}
			return socCuentassolLista;
		};
	}

	public Solicitud recuperarListasSolicitante(SocSolicitudes socSolicitudes) {

		return null;
	}

	public static boolean esPendiente(SocSolicitudes socSolicitudes) {
		return socSolicitudes.getClaEstado() != null && socSolicitudes.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE);
	}

	public static boolean esModificable(SocSolicitudes socSolicitudes) {
		return socSolicitudes.getSocCodigo() != null && socSolicitudes.getSocCodigo().trim().length() > 0 && esPendiente(socSolicitudes);
	}

	public static boolean esNuevo(SocSolicitudes socSolicitudes) {
		return socSolicitudes.getSocCodigo() == null || socSolicitudes.getSocCodigo().trim().length() == 0;
	}

	public static boolean esGeneradoPorUsuarioBCB(SocSolicitudes socSolicitudes) {
		return socSolicitudes.getSolEntsolic() != null && socSolicitudes.getSolEntsolic().trim().equals(Constants.COD_BCB);
	}

	public static boolean esBCBSolicitante(SocSolicitudes socSolicitudes) {
		return socSolicitudes.getSolCodigo() != null && socSolicitudes.getSolCodigo().trim().equals(Constants.COD_BCB);
	}

	public Consumer<Solicitud> completarSocSolicitudesNuevo(SocSolicitudes socSolicitudesInit) {
		return solicitud -> {
			// Boolean seListaSolicitantes = esNuevo(socSolicitudes);
			if (esNuevo(solicitud.getSolicitud())) {
				solicitud.getSolicitud().setClaEstadows(Constants.CLAVE_ESTWS_PROCESADO);
				// socSolicitudes.setFecha(new Date());
				// socSolicitudes.setFechaReg(new Date());
				// para enmiendas fecha sera el saldo
				// socSolicitudes.setSocMontome(BigDecimal.ZERO);
				// socSolicitudes.setCodMoneda(Constants.COD_MONEDA_USD);
				// socSolicitudes.setSocMontoord(BigDecimal.ZERO);
				// socSolicitudes.setSocMontomn(BigDecimal.ZERO);
				solicitud.getSolicitud().setCodMonedat(Constants.COD_MONEDA_USD);
				solicitud.getSolicitud().setSolEntsolic(socSolicitudesInit.getSolEntsolic());
				solicitud.getSolicitud().setTipoConcepto("O"); // ojoooo
				solicitud.getSolicitud().setCveTipctasolic(Constants.CLAVE_GENERADOPOR_SISTEMA);
				solicitud.getSolicitud().setSocTipnegociacion(Constants.CLAVE_TIPNEGOCIA_NORMAL);
				// socSolicitudes.setClaTipo(Constants.CLAVE_SUBTIPOOPER_TRAEXT);
				// socSolicitudes.setCveSubtipooper(Constants.CLAVE_SUBTIPOOPER_TRAEXT);
				solicitud.getSolicitud().setTipoRetencion(Constants.CLAVE_TIPORETENCION_SINDESC);
				solicitud.getSolicitud().setEsqCodigo(socSolicitudesInit.getEsqCodigo());

				if (!esGeneradoPorUsuarioBCB(socSolicitudesInit)) {
					solicitud.getSolicitud().setSolCodigo(socSolicitudesInit.getSolEntsolic());
				}

				SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(socSolicitudesInit.getEsqCodigo());

				solicitud.getSolicitud().setClaTipo(socEsquemas.getCodTipooper());
				solicitud.getSolicitud().setCveSubtipooper(socEsquemas.getCveSubtipooper());
			}
		};
	}

	public Consumer<Solicitud> recuperarDatosComplementariosSolicitud() {
		return solicitud -> {
			if (solicitud != null && solicitud.getSolicitud() != null && !StringUtils.isBlank(solicitud.getSolicitud().getSolCodigo())) {
				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(solicitud.getSolicitud().getSolCodigo());
				solicitud.setSocSolicitante(socSolicitante);
			}

			SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitud.getSolicitud().getEsqCodigo());
			solicitud.setSocEsquemas(socEsquemas);

		};
	}

}
