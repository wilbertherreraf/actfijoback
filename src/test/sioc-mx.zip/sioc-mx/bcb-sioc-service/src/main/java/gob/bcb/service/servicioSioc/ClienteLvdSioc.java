package gob.bcb.service.servicioSioc;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;

import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.lavado.client.ClienteLvd;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfMensaje;

public class ClienteLvdSioc {
	private static Logger log = Logger.getLogger(ClienteLvdSioc.class);
	private ClienteLvd clienteLvd;
	private String idsession = null;

	public ClienteLvdSioc() {
	}

	public ClienteLvd initClienteLvd(String urlResource) {
		String pathBase = ConfigurationServ.getConfigurationHome();
		if (StringUtils.isBlank(pathBase)) {
			throw new SwiftAdminException("Directorio base de configuracion no inicializado.");
		}
		log.info("Creando objeto ClienteLvdSioc " + urlResource + " dir: " + pathBase);
		try {
			clienteLvd = ClienteLvd.init(urlResource, pathBase, Constants.CODAPP_SIOC);
		} catch (NullPointerException e) {
			throw new SwiftAdminException(e);
		} catch (Exception e) {
			throw new SwiftAdminException(e);
		}

		return clienteLvd;
	}

	public String getSessionLavado(String codUsuario) {

		if (clienteLvd != null) {
			try {
				SearchResponse searchResponse = clienteLvd.getIniSessionLavado(Constants.CODAPP_SIOC, codUsuario);
				idsession = searchResponse.getCodoperacion();
				if (StringUtils.isBlank(searchResponse.getCodoperacion()) || !searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
					throw new SwiftAdminException("Error al obtener sesion LAVADO: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
				}
				return idsession;
			} catch (Exception e) {
				throw new SwiftAdminException(e.getMessage(), e);
			}
		}
		return idsession;
	}

	public SearchResponse solicitarCorrelativo(String codoperacion, String coduser) {
		try {
			SearchResponse searchResponse = clienteLvd.solicitarCorrelativo(Constants.CODAPP_SIOC, codoperacion, coduser, idsession);
			if (!searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO) || Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) <= 0) {
				throw new SwiftAdminException("Error al obtener correlativo LAVADO: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}

			log.info("Nro swift LAVADO asignado " + searchResponse.getCodoperacion() + " Nrocorr==> " + searchResponse.getNrocorr());
			return searchResponse;
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}

	}

	public SearchResponse scanMensaje(SwfMensaje swfMensaje) {
		String codigoOperacion = String.valueOf(swfMensaje.getMenCodoperacion() + "" + swfMensaje.getMenDetcodigo());
		return scanMensaje(codigoOperacion, swfMensaje.getMenAuditusr(), swfMensaje.getMenNrolavado(), swfMensaje.getMenNrocorr(), swfMensaje.getMenPlano());
	}

	public SearchResponse scanMensaje(String codigoOperacion, String codusuario, Integer nroLavado, Integer nroCorrelativo, String menPlano) {
		try {
			SearchResponse searchResponse = clienteLvd.scanSwiftRegistro(Constants.CODAPP_SIOC, codusuario, nroLavado, nroCorrelativo, codigoOperacion,
					idsession, menPlano);

			if (searchResponse.getCountRegs().compareTo(0) > 0 || !searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
				throw new SwiftAdminException("Error Scaneo LAVADO: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}
			return searchResponse;
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public void preautorizarSwift(SwfMensaje swfMensaje) {
		String codigoOperacion = String.valueOf(swfMensaje.getMenCodoperacion() + "" + swfMensaje.getMenDetcodigo());
		preautorizarSwift(codigoOperacion, swfMensaje.getMenAuditusr(), swfMensaje.getMenNrolavado(), swfMensaje.getMenNrocorr(), swfMensaje.getMenPlano());
	}

	public void preautorizarSwift(String codigoOperacion, String codusuario, Integer nroLavado, Integer nroCorrelativo, String menPlano) {
		if (clienteLvd == null)
			return;
		try {
			log.info("codusuario: " + codusuario + ", nroLavado:" + nroLavado + " , nroCorrelativo: " + nroCorrelativo + " , codigoOperacion: "
					+ codigoOperacion + ", idsession:" + idsession + ", menPlano");

			SearchResponse searchResponse = clienteLvd.preautorizarSwift(Constants.CODAPP_SIOC, codusuario, nroLavado, nroCorrelativo, codigoOperacion,
					idsession, menPlano);

			if (searchResponse.getCountRegs().compareTo(0) > 0 || !searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
				throw new SwiftAdminException("Error en APROBAR: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public void cerrarSession(String coduser) {
		if (clienteLvd == null)
			return;
		try {
			SearchResponse searchResponse = clienteLvd.postSessionLavado(Constants.CODAPP_SIOC, coduser, idsession);
			if (!searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
				throw new SwiftAdminException("Error Post Scaneo LAVADO: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public void scanMensaje(String menPlano) {
		if (clienteLvd == null)
			return;
		try {
			SearchResponse searchResponse = clienteLvd.scanMsgPlanoSingleFromString(menPlano);

			if (searchResponse.getCountRegs().compareTo(0) > 0 || !searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
				throw new SwiftAdminException("Error Scaneo Sinple LAVADO: " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public String getIdsession() {
		return idsession;
	}

	public ClienteLvd getClienteLvd() {
		return clienteLvd;
	}

}
