package gob.bcb.swift.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentas;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.Block4;
import gob.bcb.iso20022.swift.MappingTable;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.utils.ValidatorCodes;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.ClienteLvdSioc;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.CartasCredService;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.commons.MensSwiftUtiles;
import gob.bcb.swift.dao.SwfDetmensajeBean;
import gob.bcb.swift.dao.SwfDetmensajeLocal;
import gob.bcb.swift.dao.SwfMencamposDbDao;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMensajeLocal;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.dao.SwfMttransferLocal;
import gob.bcb.swift.dao.SwfPersonactaBean;
import gob.bcb.swift.dao.SwfPersonactaLocal;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfDetmensaje;
import gob.bcb.swift.model.SwfMencamposDb;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.pojos.SwiftMessageBcb;

@Service("swiftMessageServiceLocal")
@Transactional
public class SwiftMessageService implements SwiftMessageServiceLocal {
	private static final Logger log = Logger.getLogger(SwiftMessageService.class);

	@Autowired
	private SocBancosDao socBancosDao = new SocBancosDao();
	@Autowired
	private SocBenefsDao socBenefsDao = new SocBenefsDao();
//	@Autowired
//	private SwfMttransferdetLocal swfMttransferdetLocal0 = new SwfMttransferdetBean();
	@Autowired
	private SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
	@Autowired
	private SwfMttransferLocal swfMttransferLocal = new SwfMttransferBean();
	@Autowired
	private SwfPersonactaLocal swfPersonactaLocal = new SwfPersonactaBean();
	@Autowired
	private SwfDetmensajeLocal swfDetmensajeLocal = new SwfDetmensajeBean();
	@Autowired
	private SwfMencamposDbDao swfMencamposDbDao = new SwfMencamposDbDao();
	private SwfMencamposIsoDaoImpl swfMencamposIsoDaoImpl = new SwfMencamposIsoDaoImpl();
	private SessionFactory sessionFactory;
	public final static List<String> namesFacst = Arrays.asList("inftrx", "dbtrAgt", "instg", "cdtrAgt", "intrmy", "rmtInf", "chrBear", "instrInf", "dbtr", "cdtr");
	// private FormatEngine formatEngine;

	public SwiftMessageService() {
	}

	public SwiftMessageService(EntityManager entityManager) {
	}

	public SwfMensaje generarMensaje(SwiftDatos swiftDatos) {
		log.info("En generarMensaje swiftDatos inicio de generar Swift " + swiftDatos.getSwfMensaje().getMenCodmt() + " "
				+ swiftDatos.getSwfMensaje().getMenCodoperacion() + " " + swiftDatos.getSwfMensaje().getMenCodusrswf());

		CreateSwiftService createSwiftService = generarMensajeSwift(swiftDatos);
	
		Instruccion instruccion = createSwiftService.getInstruccion();
		String menPlano = instruccion.getMessageHolder().getMenPlano();
		log.info("FIN " + menPlano);		
		swiftDatos.getSwfMensaje().setMenPlano(menPlano);
		swiftDatos.getSwfMensaje().setMenFormato(instruccion.getSwfMsgParam().getMenFormato());
		
		SwfMensaje swfMensaje = guardarSwiftObjectMx(swiftDatos, instruccion);

		return swfMensaje;

	}

	public CreateSwiftService generarMensajeSwift(SwiftDatos swiftDatos) {
		log.info("En generarMensaje swiftDatos inicio de generar Swift " + swiftDatos.getSwfMensaje().getMenCodmt() + " "
				+ swiftDatos.getSwfMensaje().getMenCodoperacion() + " " + swiftDatos.getSwfMensaje().getMenCodusrswf());

		Instruccion instruccion = new Instruccion();
		SwfMsgParam swfMsgParam = recMsgParms(swiftDatos.getSwfMensaje());
		instruccion.setSwfMsgParam(swfMsgParam);

		CreateSwiftService createSwiftService = new CreateSwiftService(instruccion, swfMencamposIsoDaoImpl);
		createSwiftService.setSessionFactory(getSessionFactory());
		
		createSwiftService.initInstruccion();
		MappingTable mappingTable = createSwiftService.getMappingTable();

		obtenerCamposMppTb(swiftDatos, mappingTable);
		
		createSwiftService.generaHeaderMsg();
		
		try {
			if (instruccion.isMt()) {
				String bloque = "4";
				SwiftBlock4 block4List = obtenerCamposBlk4(swiftDatos, instruccion, bloque);
				instruccion.setBlock4(block4List);
				//campos pcon reglas para evaluar
				createSwiftService.recuperarSwfCampos(swfMsgParam.getMenIdTMessageTx(), "8");				
			} else if (instruccion.isMx()) {
				String bloque = "4";
				SwiftBlock4 block4List = obtenerCamposBlk4(swiftDatos, instruccion, bloque);
				
				for (Tag tag : block4List) {
					String nFact = tag.getName();
					nFact = nFact.replaceAll(".", "").replace(" ", "");
					mappingTable.putFact("F" + nFact, tag.getValue());
				}
				//campos pcon reglas para evaluar
				createSwiftService.recuperarSwfCampos(swfMsgParam.getMenIdTMessageTx(), "8");
			}
			long tini = System.currentTimeMillis();
			createSwiftService.initEngine();
			log.info("duracion engine : " + (System.currentTimeMillis() - tini) + " (ms.)");
		} catch (Exception e) {
			throw new BusinessException("Error al inicializar traductor(MT o MX) " + e.getMessage(), e);
		}
		long tini = System.currentTimeMillis();
		createSwiftService.translate();
		log.info("duracion translate : " + (System.currentTimeMillis() - tini) + " (ms.)");
		createSwiftService.createMsgSwift();
		//log.info("FIN " + menPlano);

		return createSwiftService;

	}
	public SwiftBlock4 obtenerCamposBlk4(SwiftDatos swiftDatos, Instruccion instruccion, String bloque) {
		log.info("En obtenerCamposBlk4 " + instruccion.getSwfMsgParam().getMenIdTMessageTx());
		SwiftBlock4 block4List = new SwiftBlock4();
		List<SwfMencamposDb> swfMencamposDbList = swfMencamposDbDao.findByMT(instruccion.getSwfMsgParam().getMenIdTMessageTx(), bloque);
		
		if (swfMencamposDbList.size() == 0) {
			log.warn("ATENCION!! No se recupero ningun registro de campos swift para " + instruccion.getSwfMsgParam().getMenIdTMessageTx() + " Bloque: " + bloque);
			return block4List;
		}
		
		swfMencamposDbList.forEach(c -> {
			Field field = obtenerValor(swiftDatos, swiftDatos.getSwfMensaje(), c);
			if (field != null) {
				block4List.append(field.asTag());
			}
		});
		return block4List;
	}

	public void obtenerCamposMppTb(SwiftDatos swiftDatos, MappingTable mappingTable) {
		log.info("En obtenerCamposMppTb " + swiftDatos.getSwfMensaje().getMenCodmt());
	
		namesFacst.forEach(c -> {
			obtenerFacts(swiftDatos, c, mappingTable);
		});
	}

	public Field obtenerValor(SwiftDatos swiftDatos, SwfMensaje swfMensaje, SwfMencamposDb swfMencamposDb) {
		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());

		String campo = swfMencamposDb.getMtfCodcampo();
		String typeMsg = swfMencamposDb.getMtfCodmt();
		String valCampo = swfMencamposDb.getMtfDefault();

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		log.info("==>Obtener Valor " + typeMsg + " campo:" + campo);
		Field field = null;
		boolean requerido = true;
		if (campo.equals("20")) {
			// ref transaccion
			String idMensaje = fieldCorrelativo(swfMensaje);
			field = SwiftMessageBcb.setField20(idMensaje);
		} else if (campo.equals("21")) {
			// referencia original
			field = SwiftMessageBcb.setField21(valCampo);
		} else if (campo.equals("23B")) {
			// Codigo sta operacion bancaria
			// ktte CRED
			field = SwiftMessageBcb.setField23B(valCampo);
		} else if (campo.equals("32A")) {
			// FECHA MONEDA IMPORTE
			field = SwiftMessageBcb.setField32A(swfMensaje.getMenFecvalor(), swfMensaje.getMenCodmonswift(), swfMensaje.getMenMonto());
		} else if (campo.equals("33B")) {
			// monto ordenado
			requerido = false;
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
				socOpecomiDao.setSessionFactory(getSessionFactory());

				SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0, "MONTOORD");
				if (socOpecomi == null || socOpecomi.getMontoMo().compareTo(BigDecimal.valueOf(0)) <= 0) {
					throw new BusinessException(
							"No se puede hallar MONTOORD para Solicitud con descuento " + swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
				}

				GenMonedaDao genMonedaDao = new GenMonedaDao();
				genMonedaDao.setSessionFactory(getSessionFactory());

				GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
				BigDecimal montoOrd = socOpecomi.getMontoMo();

				BigDecimal monto = montoOrd.setScale(2, RoundingMode.HALF_UP);

				field = SwiftMessageBcb.setField33B(genMoneda.getMonSigla(), monto);
			}
		} else if (campo.equals("50A")) {
			field = SwiftMessageBcb.setField50A(swiftDatos.getSolicitudTO().getSocSolicitante().getSolBic());
		} else if (campo.equals("50F")) {
			String cta = "";
			SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(),
					Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);
			// 3987
			if (socSolicitudctas == null) {
				throw new BusinessException("Nro Cuenta de provision de solicitante " + swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo()
						+ " nulo, revise la cuenta MOVPROVISION");
			}
			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(socSolicitudctas.getSolCodigo());
			if (socSolicitante != null) {
				if (!StringUtils.isBlank(socSolicitante.getSolCodigo()) && socSolicitante.getSolCodigo().trim().equals(Constants.COD_BCB)) {
					cta = socSolicitudctas.getNroCuenta();
				} else {
					if (!StringUtils.isBlank(socSolicitante.getClaEntidad())) {
						if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
							cta = socSolicitudctas.getNroLibreta();
						} else if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTPUBLICO)) {
							cta = socSolicitudctas.getNroCuenta();
						}
					} else {
						throw new BusinessException("Error de parametrizacion, solicitante " + socSolicitudctas.getSolCodigo() + " sin tipo de entidad");
					}
				}
			} else {
				log.error("solicitante inexistente en socsolicitante " + socSolicitudctas.getSolCodigo());
				cta = socSolicitudctas.getNroCuenta();
			}

			if (StringUtils.isBlank(cta)) {
				throw new BusinessException("Nro Cuenta de provision de solicitante " + swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo()
						+ " nulo, revise la cuenta MOVPROVISION");
			}

			Map<String, List<String>> mapfieldf = new HashMap<>();
			List<String> lin1Name = MensSwiftUtiles.splitInLines(33, swiftDatos.getSolicitudTO().getSocSolicitante().getSolPersona(), 2, " ", "", 0);
			List<String> lin2Dir = MensSwiftUtiles.splitInLines(33, swiftDatos.getSolicitudTO().getSocSolicitante().getSolDireccion(), 2, " ", "", 0);
			List<String> lin3CtryTown = MensSwiftUtiles.splitInLines(33, swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza(), 1, " ", "", 0);

			mapfieldf.put("name", lin1Name);
			mapfieldf.put("address", lin2Dir);
			mapfieldf.put("country", lin3CtryTown);
			
			field = SwiftMessageBcb.setField50F(cta, mapfieldf);

		} else if (campo.equals("50K")) {

			String cta = "";
			SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(),
					Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(socSolicitudctas.getSolCodigo());
			if (socSolicitante != null) {
				if (!StringUtils.isBlank(socSolicitante.getSolCodigo()) && socSolicitante.getSolCodigo().trim().equals(Constants.COD_BCB)) {
					cta = socSolicitudctas.getNroCuenta();
				} else {
					if (!StringUtils.isBlank(socSolicitante.getClaEntidad())) {
						if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
							cta = socSolicitudctas.getNroLibreta();
						} else if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTPUBLICO)) {
							cta = socSolicitudctas.getNroCuenta();
						}
					} else {
						throw new BusinessException("Error de parametrizacion, solicitante " + socSolicitudctas.getSolCodigo() + " sin tipo de entidad");
					}
				}
			} else {
				log.error("solicitante inexistente en socsolicitante " + socSolicitudctas.getSolCodigo());
				cta = socSolicitudctas.getNroCuenta();
			}

			if (StringUtils.isBlank(cta)) {
				throw new BusinessException("Nro Cuenta de provision de solicitante " + swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo()
						+ " nulo, revise la cuenta MOVPROVISION");
			}
			String nameAndLocation = StringUtils.trimToEmpty(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPersona()) + " ";
			nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(swiftDatos.getSolicitudTO().getSocSolicitante().getSolDireccion()) + " ";
			nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza());
			nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);

			field = SwiftMessageBcb.setField50K(cta, nameAndLocation);

		} else if (campo.equals("52A")) {
			//dbtragt
			field = SwiftMessageBcb.setField52A(null, swiftDatos.getSolicitudTO().getSocSolicitante().getSolBic());
		} else if (campo.equals("53B")) {
			SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
			socCuentassolDao.setSessionFactory(getSessionFactory());

			SocCuentas socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(swiftDatos.getSolicitudTO().getSolicitud(), swfMensaje.getMenCodmon(), null);

			if (socCuentas != null) {
				BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByCod(Constants.COD_BCB_SWIFT);

				field = SwiftMessageBcb.setField53B(socCuentas.getCtaNrocuenta(), bancoPlazaSender.getBcoNombre());
			}
		} else if (campo.equals("56A")) {
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBancointer());
			field = SwiftMessageBcb.setField56A(null, bancoPlaza.getPlaBic());
		} else if (campo.startsWith("57")) {
			if (swiftDatos.getSocDetallessol() != null) {
				BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBanco());
				if (campo.equals("57A")) {
					if (bancoPlaza == null) {
						throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con banco "
								+ swiftDatos.getSocDetallessol().getCodBanco() + " sin registro en bancos");
					}
					if (StringUtils.isBlank(bancoPlaza.getPlaBic())) {
						throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con Banco "
								+ swiftDatos.getSocDetallessol().getCodBanco() + " sin BIC requerido para Campo " + campo + " MT " + typeMsg);
					}
					field = SwiftMessageBcb.setField57A(null, bancoPlaza.getPlaBic());
				} else if (campo.equals("57D")) {

					if (bancoPlaza == null) {
						throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con banco "
								+ swiftDatos.getSocDetallessol().getCodBanco() + " sin registro en bancos");
					}
					if (StringUtils.isBlank(swiftDatos.getSocDetallessol().getNroCuentabcointer())) {
						throw new SwiftAdminException(
								"Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con Banco " + swiftDatos.getSocDetallessol().getCodBanco()
										+ " sin Nro de cta o FW registrado, requerido para Campo " + campo + " MT " + typeMsg);
					}

					String nameAndLocation = StringUtils.trimToEmpty(bancoPlaza.getBcoNombre()) + " ";
					nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(bancoPlaza.getPlaNombre());
					nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);

					field = SwiftMessageBcb.setField57D(swiftDatos.getSocDetallessol().getNroCuentabcointer(), nameAndLocation);
				}
			}
		} else if (campo.equals("58A")) {
			boolean esCartas = swiftDatos.getSolicitudTO().getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
					|| swiftDatos.getSolicitudTO().getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);

			BancoPlaza bancoPlaza = null;
			String nroCtaBco = "";
			if (esCartas) {
				CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
				Solicitud solicitud = cartasCredService.recuperarCartaYDetalleParaSolicitud(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
				bancoPlaza = socBancosDao.bancoPlazaByCod(solicitud.getCarCartascrdet().getCcdCodbcoreceptor());

				if (bancoPlaza == null) {
					throw new SwiftAdminException(
							"Entidad beneficiaria " + solicitud.getCarCartascrdet().getCcdCodbcoreceptor() + " sin registro en socbancos");
				}
				nroCtaBco = swiftDatos.getSocDetallessol().getNroCuentabco();
			} else {
				bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getNroCuentabco());

				if (bancoPlaza == null) {
					throw new SwiftAdminException("Entidad beneficiaria " + swiftDatos.getSocDetallessol().getNroCuentabco() + " sin registro en socbancos");
				}
			}

			if (StringUtils.isBlank(bancoPlaza.getPlaBic())) {
				throw new SwiftAdminException(
						"Entidad beneficiaria " + bancoPlaza.getSocBancos().getBcoCodigo() + " sin BIC, requerido para Campo " + campo + " MT " + typeMsg);
			}

			field = SwiftMessageBcb.setField58A(nroCtaBco, bancoPlaza.getPlaBic());
		} else if (campo.equals("58D")) {
			SocBenefsDao socBenefsDao = new SocBenefsDao();
			socBenefsDao.setSessionFactory(getSessionFactory());
			SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(swiftDatos.getSocDetallessol().getBenCodigo());

			field = SwiftMessageBcb.setField58D(swiftDatos.getSocDetallessol().getNroCuentabco(), socBenefs.getBenNombre());

		} else if (campo.equals("59")) {
			SocBenefsDao socBenefsDao = new SocBenefsDao();
			socBenefsDao.setSessionFactory(getSessionFactory());

			List<Beneficiario> beneficiarios = socBenefsDao.beneficiariosExternosSolicitante(swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo(),
					swiftDatos.getSocDetallessol().getBenCodigo(), swfMensaje.getMenCodmon(), null, false);

			if (beneficiarios.size() > 0) {

				if (StringUtils.isBlank(beneficiarios.get(0).getBenDireccion()) || StringUtils.isBlank(beneficiarios.get(0).getBenPlaza())) {
					throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " - "
							+ beneficiarios.get(0).getBenNombre() + " sin registro de direccion o plaza");
				}

				String nameAndLocation = StringUtils.trimToEmpty(beneficiarios.get(0).getBenDireccion()) + ", ";
				nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(beneficiarios.get(0).getBenPlaza());

				nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);

				field = SwiftMessageBcb.setField59(swiftDatos.getSocDetallessol().getNroCuentabco(), beneficiarios.get(0).getBenNombre(), nameAndLocation);
			} else {
				throw new SwiftAdminException(swiftDatos.getSocDetallessol().getId().getDetCodigo() + ":: Campo " + campo + " MT " + typeMsg
						+ " beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " sin registro para ");
			}
		} else if (campo.equals("59F")) {
			SocBenefsDao socBenefsDao = new SocBenefsDao();
			socBenefsDao.setSessionFactory(getSessionFactory());

			List<Beneficiario> beneficiarios = socBenefsDao.beneficiariosExternosSolicitante(swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo(),
					swiftDatos.getSocDetallessol().getBenCodigo(), swfMensaje.getMenCodmon(), null, false);

			if (beneficiarios.size() > 0) {

				if (StringUtils.isBlank(beneficiarios.get(0).getBenDireccion()) || StringUtils.isBlank(beneficiarios.get(0).getBenPlaza())) {
					throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " - "
							+ beneficiarios.get(0).getBenNombre() + " sin registro de direccion o plaza");
				}

				String nameAndLocation = StringUtils.trimToEmpty(beneficiarios.get(0).getBenDireccion()) + ", ";
				nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(beneficiarios.get(0).getBenPlaza());

				nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);
				Map<String, List<String>> mapfieldf = new HashMap<>();
				List<String> lin1Name = MensSwiftUtiles.splitInLines(33, beneficiarios.get(0).getBenNombre(), 2, " ", "", 0);
				List<String> lin2Dir = MensSwiftUtiles.splitInLines(33, beneficiarios.get(0).getBenDireccion(), 2, " ", "", 0);
				List<String> lin3CtryTown = MensSwiftUtiles.splitInLines(33, beneficiarios.get(0).getBenPlaza(), 1, " ", "", 0);

				mapfieldf.put("name", lin1Name);
				mapfieldf.put("address", lin2Dir);
				mapfieldf.put("country", lin3CtryTown);

				field = SwiftMessageBcb.setField59F(swiftDatos.getSocDetallessol().getNroCuentabco(), mapfieldf);
			} else {
				throw new SwiftAdminException(swiftDatos.getSocDetallessol().getId().getDetCodigo() + ":: Campo " + campo + " MT " + typeMsg
						+ " beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " sin registro para ");
			}
		} else if (campo.equals("70")) {
			requerido = false;
			if (!StringUtils.isBlank(swiftDatos.getSocDetallessol().getDetConcepto())) {
				String valor = swiftDatos.getSocDetallessol().getTipoConcepto();
				if (!StringUtils.isBlank(valor) && valor.equals("INV")) {
					valor = "/" + swiftDatos.getSocDetallessol().getTipoConcepto() + "/";
					valor = valor.concat(swiftDatos.getSocDetallessol().getDetConcepto().trim());
				} else {
					valor = swiftDatos.getSocDetallessol().getDetConcepto().trim();
				}
				field = SwiftMessageBcb.setField70(valor);
			}
		} else if (campo.equals("71A")) {
			field = SwiftMessageBcb.setField71A(valCampo);
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				if (swiftDatos.getSolicitudTO().getSolicitud().getCodMonedat().compareTo(Constants.COD_MONEDA_USD) != 0) {
					field = SwiftMessageBcb.setField71A("BEN");
				}
			}

		} else if (campo.equals("71F")) {
			requerido = false;
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				if (swiftDatos.getSolicitudTO().getSolicitud().getCodMonedat().compareTo(Constants.COD_MONEDA_USD) != 0) {

					SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
					socOpecomiDao.setSessionFactory(getSessionFactory());

					SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0,
							"MONTOORDCOMIS");
					if (socOpecomi == null || socOpecomi.getMontoMo().compareTo(BigDecimal.valueOf(0)) <= 0) {
						throw new BusinessException(
								"No se puede hallar MONTOORDCOMIS para Solicitud con descuento " + swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
					}

					GenMonedaDao genMonedaDao = new GenMonedaDao();
					genMonedaDao.setSessionFactory(getSessionFactory());

					GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
					BigDecimal montoOrd = socOpecomi.getMontoMo();

					BigDecimal monto = montoOrd.setScale(2, RoundingMode.HALF_UP);

					field = SwiftMessageBcb.setField71F(genMoneda.getMonSigla(), monto);
				}
			}
		} else if (campo.equals("72")) {
			boolean esCartas = swiftDatos.getSolicitudTO().getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
					|| swiftDatos.getSolicitudTO().getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);
			if (esCartas || swiftDatos.getSolicitudTO().getSolicitud().getEsqCodigo().compareTo(Constants.CODESQ_TRANSFEXT_SISTFIN) == 0
					|| swiftDatos.getSolicitudTO().getSolicitud().getEsqCodigo().compareTo(Constants.CODESQ_TRANSFEXT_OPERSBCB) == 0) {
				field = SwiftMessageBcb.setField72SinModificar(swiftDatos.getSocDetallessol().getDetInfo());
			} else {
				field = SwiftMessageBcb.setField72(swiftDatos.getSocDetallessol().getDetInfo());
			}
			requerido = false;
		} else {
			throw new SwiftAdminException("Campo " + campo + " Cod MT " + typeMsg + " no implementado, Avise a sistemas ");
		}

		if (requerido && (field == null || field.isEmpty())) {
			throw new SwiftAdminException("Campo " + campo + " Cod MT " + typeMsg + " sin definicion de valor, avise a sistemas");
		}

		if (field != null) {
			log.info("Valor obtenido: " + typeMsg + ":" + campo + " => " + field.getValue());
		}

		if (field == null || field.isEmpty()) {
			return null;
		}

		return field;
	}

	private SwfMensaje guardarSwiftObjectMx(SwiftDatos swiftDatos, Instruccion instruccion) {
		log.info("Guardando mensaje y detalles swift:: " + swiftDatos.getSwfMensaje().getMenCodoperacion() + " " + swiftDatos.getSwfMensaje().getMenCodmen());
		try {
			String menPlano = swiftDatos.getSwfMensaje().getMenPlano();
			log.info("Guardando swift:: \n" + menPlano);

			SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swiftDatos.getSwfMensaje());

			// se elimina todos los detalles
			swfDetmensajeLocal.borrarDetalles(swfMensajeNew.getMenCodmen());
			List<Block4> block4 = instruccion.getMessageHolder().createBlock4().getBlock4();
			for (Block4 t : block4) {
				// barremos todos los campos del BLOCK4
				swfDetmensajeLocal.actualizarCampo(swfMensajeNew.getMenCodmen(), t.getName(), 4, t.getValue(), swfMensajeNew.getMenAuditusr(),
						swfMensajeNew.getMenAuditwst());
			}

			SwfMensaje swfMensaje = swfMensajeLocal.findByCodigo(swfMensajeNew.getMenCodmen());
			swiftDatos.setSwfMensaje(swfMensaje);

			log.info("SWIFT Salvado hecho ... " + swfMensaje.getMenCodmen() + " " + swfMensaje.getMenCodoperacion());
			return swfMensaje;
		} catch (Exception e) {
			log.error("Error al actualizar swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar swift " + e.getMessage());
		}
	}

	public void obtenerFacts(SwiftDatos swiftDatos, String campo, MappingTable mappingTable) {
		
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		Map<String, Object> inftrxProps = new HashMap<>();
		Map<String, Object> dbtrProps = new HashMap<>();
		Map<String, Object> dbtrAgtProps = new HashMap<>();
		Map<String, Object> instgAgtProps = new HashMap<>();
//		Map<String, Object> instdProps = new HashMap<>();

		Map<String, Object> cdtrAgtProps = new HashMap<>();
		Map<String, Object> cdtrProps = new HashMap<>();
		Map<String, Object> intrmyProps = new HashMap<>();
		Map<String, Object> rmtInfProps = new HashMap<>();
		Map<String, Object> chrBearProps = new HashMap<>();
		Map<String, Object> instrInfProps = new HashMap<>();

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

//		log.info("==>Obtener Valor campo:" + campo);
		if (campo.equals("inftrx")) {
			// ref transaccion
			String idMensaje = fieldCorrelativo(swfMensaje);
			inftrxProps.put("msgid", idMensaje);

			// FECHA MONEDA IMPORTE
			inftrxProps.put("amt", swfMensaje.getMenMonto());
			inftrxProps.put("amtccy", swfMensaje.getMenCodmonswift());
			inftrxProps.put("dt", swfMensaje.getMenFecvalor());

			// monto ordenado
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
				socOpecomiDao.setSessionFactory(getSessionFactory());

				SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0, "MONTOORD");
				if (socOpecomi != null) {
					GenMonedaDao genMonedaDao = new GenMonedaDao();
					genMonedaDao.setSessionFactory(getSessionFactory());

					GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
					BigDecimal montoOrd = socOpecomi.getMontoMo();

					BigDecimal monto = montoOrd.setScale(2, RoundingMode.HALF_UP);

					inftrxProps.put("instramt", monto);
					inftrxProps.put("instramtccy", genMoneda.getMonSigla());
				}
			}
			mappingTable.newFactAtribs(campo, inftrxProps);
		} else if (campo.equals("dbtr")) {
			dbtrProps.put("bic", swiftDatos.getSolicitudTO().getSocSolicitante().getSolBic());
			String cta = "";
			SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(),
					Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);
			// 3987
			if (socSolicitudctas != null) {
				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(socSolicitudctas.getSolCodigo());
				if (socSolicitante != null) {
					if (!StringUtils.isBlank(socSolicitante.getSolCodigo()) && socSolicitante.getSolCodigo().trim().equals(Constants.COD_BCB)) {
						cta = socSolicitudctas.getNroCuenta();
					} else {
						if (!StringUtils.isBlank(socSolicitante.getClaEntidad())) {
							if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
								cta = socSolicitudctas.getNroLibreta();
							} else if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTPUBLICO)) {
								cta = socSolicitudctas.getNroCuenta();
							}
						} else {
							throw new BusinessException("Error de parametrizacion, solicitante " + socSolicitudctas.getSolCodigo() + " sin tipo de entidad");
						}
					}
				} else {
					log.error("solicitante inexistente en socsolicitante " + socSolicitudctas.getSolCodigo());
					cta = socSolicitudctas.getNroCuenta();
				}

				if (!StringUtils.isBlank(cta)) {
					dbtrProps.put("acct", cta);
				}
			}
			dbtrProps.put("name", swiftDatos.getSolicitudTO().getSocSolicitante().getSolPersona());
			dbtrProps.put("address", swiftDatos.getSolicitudTO().getSocSolicitante().getSolDireccion());
			dbtrProps.put("ctry", swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza());
			dbtrProps.put("town", swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza().substring(0, 2));

			mappingTable.newFactAtribs(campo, dbtrProps);
		} else if (campo.equals("dbtrAgt")) {
			dbtrAgtProps.put("bic", swiftDatos.getSolicitudTO().getSocSolicitante().getSolBic());
			mappingTable.newFactAtribs(campo, dbtrAgtProps);
		} else if (campo.equals("instgAgt")) {
			SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
			socCuentassolDao.setSessionFactory(getSessionFactory());

			SocCuentas socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(swiftDatos.getSolicitudTO().getSolicitud(), swfMensaje.getMenCodmon(), null);

			if (socCuentas != null) {
				BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByCod(Constants.COD_BCB_SWIFT);

				instgAgtProps.put("acct", socCuentas.getCtaNrocuenta());
				instgAgtProps.put("name", bancoPlazaSender.getBcoNombre());
			}
			mappingTable.newFactAtribs(campo, instgAgtProps);
		} else if (campo.equals("intrmy")) {
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBancointer());
			if (bancoPlaza != null) {
				intrmyProps.put("bic", bancoPlaza.getPlaBic());
				intrmyProps.put("name", bancoPlaza.getBcoNombre());
				intrmyProps.put("address", bancoPlaza.getPlaNombre());
			}
			mappingTable.newFactAtribs(campo, intrmyProps);
		} else if (campo.startsWith("cdtrAgt")) {
			if (swiftDatos.getSocDetallessol() != null) {
				BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBanco());
				if (bancoPlaza != null) {
					cdtrAgtProps.put("bic", bancoPlaza.getPlaBic());
					cdtrAgtProps.put("name", bancoPlaza.getBcoNombre());
					cdtrAgtProps.put("address", bancoPlaza.getPlaNombre());
					String acct = StringUtils.trimToEmpty(swiftDatos.getSocDetallessol().getNroCuentabcointer()).toUpperCase();

					if (acct.startsWith("FW")) {
						cdtrAgtProps.put("cd", swiftDatos.getSocDetallessol().getNroCuentabcointer().substring(0, 1));
						cdtrAgtProps.put("id", swiftDatos.getSocDetallessol().getNroCuentabcointer().substring(1));
					} else {
						cdtrAgtProps.put("acct", swiftDatos.getSocDetallessol().getNroCuentabcointer());
					}
				}
			}
			mappingTable.newFactAtribs(campo, cdtrAgtProps);
		} else if (campo.equals("cdtr")) {
			boolean esCartas = swiftDatos.getSolicitudTO().getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
					|| swiftDatos.getSolicitudTO().getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);

			BancoPlaza bancoPlaza = null;

			if (esCartas) {
				CartasCredService cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
				Solicitud solicitud = cartasCredService.recuperarCartaYDetalleParaSolicitud(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
				bancoPlaza = socBancosDao.bancoPlazaByCod(solicitud.getCarCartascrdet().getCcdCodbcoreceptor());

				if (bancoPlaza == null) {
					throw new SwiftAdminException(
							"Entidad beneficiaria " + solicitud.getCarCartascrdet().getCcdCodbcoreceptor() + " sin registro en socbancos");
				}

				cdtrProps.put("acct", swiftDatos.getSocDetallessol().getNroCuentabco());
				cdtrProps.put("bic", bancoPlaza.getPlaBic());
			} else {
				bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getNroCuentabco());

				if (bancoPlaza != null) {
					cdtrProps.put("bic", bancoPlaza.getPlaBic());
				} else {
					cdtrProps.put("acct", swiftDatos.getSocDetallessol().getNroCuentabco());
				}
			}

			SocBenefsDao socBenefsDao = new SocBenefsDao();
			socBenefsDao.setSessionFactory(getSessionFactory());
			SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(swiftDatos.getSocDetallessol().getBenCodigo());

			if (socBenefs != null) {
				cdtrProps.put("name", socBenefs.getBenNombre());
				cdtrProps.put("adress", socBenefs.getBenDireccion());
			}

			List<Beneficiario> beneficiarios = socBenefsDao.beneficiariosExternosSolicitante(swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo(),
					swiftDatos.getSocDetallessol().getBenCodigo(), swfMensaje.getMenCodmon(), null, false);

			if (beneficiarios.size() > 0) {
				cdtrProps.put("name", beneficiarios.get(0).getBenNombre());
				cdtrProps.put("address", beneficiarios.get(0).getBenDireccion());
				cdtrProps.put("ctry", beneficiarios.get(0).getBenPlaza());
				cdtrProps.put("town", beneficiarios.get(0).getBenPlaza());
			}
			mappingTable.newFactAtribs(campo, cdtrProps);
		} else if (campo.equals("rmtInf")) {
			if (!StringUtils.isBlank(swiftDatos.getSocDetallessol().getDetConcepto())) {
				String valor = swiftDatos.getSocDetallessol().getTipoConcepto();
				if (!StringUtils.isBlank(valor) && valor.equals("INV")) {
					rmtInfProps.put("cd", valor);
					rmtInfProps.put("concept", swiftDatos.getSocDetallessol().getDetConcepto().trim());
				} else {
					rmtInfProps.put("concept", swiftDatos.getSocDetallessol().getDetConcepto().trim());
				}
			}
			mappingTable.newFactAtribs(campo, rmtInfProps);
		} else if (campo.equals("chrBear")) {
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				if (swiftDatos.getSolicitudTO().getSolicitud().getCodMonedat().compareTo(Constants.COD_MONEDA_USD) != 0) {
					chrBearProps.put("cd", "CRED");

					SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
					socOpecomiDao.setSessionFactory(getSessionFactory());

					SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0,
							"MONTOORDCOMIS");
					if (socOpecomi != null) {
						GenMonedaDao genMonedaDao = new GenMonedaDao();
						genMonedaDao.setSessionFactory(getSessionFactory());

						GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
						BigDecimal montoOrd = socOpecomi.getMontoMo();

						BigDecimal monto = montoOrd.setScale(2, RoundingMode.HALF_UP);

						chrBearProps.put("amt", monto);
						chrBearProps.put("amtccy", genMoneda.getMonSigla());
					}
				}
			}
			mappingTable.newFactAtribs(campo, chrBearProps);
		} else if (campo.equals("instrInf")) {
			instrInfProps.put("info", swiftDatos.getSocDetallessol().getDetInfo());
			mappingTable.newFactAtribs(campo, instrInfProps);
		}
		
//		mappingTable.newFactAtribs("inftrx", inftrxProps);
//		mappingTable.newFactAtribs("dbtrAgt", dbtrAgtProps);
//		mappingTable.newFactAtribs("instrInf", instrInfProps);
//		mappingTable.newFactAtribs("cdtrAgt", cdtrAgtProps);
//		mappingTable.newFactAtribs("intrmy", intrmyProps);
//		mappingTable.newFactAtribs("rmtInf", rmtInfProps);
//		mappingTable.newFactAtribs("chrBear", chrBearProps);
//		mappingTable.newFactAtribs("dbtr", dbtrProps);
//		mappingTable.newFactAtribs("cdtr", cdtrProps);
		
	}

	public SwfMensaje actualizarCampo(SwiftDatos swiftDatos, String codCampo, Integer demBloque, String valorCampo) {
		log.info("actualizarCampo:: " + swiftDatos.getSwfMensaje().getMenCodmen() + " codCampo: " + codCampo + " demBloque:" + demBloque);
		try {
			SwiftMessageAbstract sma = FactoryParser.createParser(swiftDatos.getSwfMensaje().getMenPlano());
			
			String idMensaje = fieldCorrelativo(swiftDatos.getSwfMensaje());
			sma.updInstrId(codCampo, idMensaje);
			String menPlano = sma.getMenPlano();
			
			log.info("Guardando swift:: menPlano:: " + menPlano);

			swiftDatos.getSwfMensaje().setMenPlano(menPlano);

			SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swiftDatos.getSwfMensaje());

			SwfDetmensaje swfDetmensaje = swfDetmensajeLocal.actualizarCampo(swiftDatos.getSwfMensaje().getMenCodmen(), codCampo, demBloque, idMensaje,
					swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenAuditwst());

			swiftDatos.setSwfMensaje(swfMensajeNew);

			log.debug("Detalle mensaje acutliazado ::" + swfDetmensaje.toString());

			return swfMensajeNew;

		} catch (Exception e) {
			log.error("Error al actualizar campo swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar campo swift " + e.getMessage(), e);
		}
	}

	private void generarCorrelativoSwiftLavado(SwiftDatos swiftDatos, ClienteLvdSioc clienteLvdSioc) {
		log.info("Inicio actualizar LVD nro swift " + swiftDatos.getSwfMensaje().getMenCodmen());
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		// // LAVDO
		String codigoOperacion = String.valueOf(swfMensaje.getMenCodoperacion() + "" + swfMensaje.getMenDetcodigo());

		SearchResponse searchResponse = clienteLvdSioc.solicitarCorrelativo(codigoOperacion, swfMensaje.getMenAuditusr());

		swfMensaje.setMenNrocorr(searchResponse.getNrocorr());
		swfMensaje.setMenNrolavado(Integer.valueOf(searchResponse.getCodoperacion()));

		//SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swfMensaje);

		//swiftDatos.setSwfMensaje(swfMensajeNew);
		log.info("Mensaje con correlativo LAVADO: " + swfMensaje.getMenCodmen() + " con nro lavado : " + swfMensaje.getMenNrolavado()
				+ " y nro correlativo swift : " + swfMensaje.getMenNrocorr());
		//return swfMensajeNew;
	}

	public SwfMensaje actualizarCorrelativo(SwfMensaje swfMensajePar, String pathSwift, ClienteLvdSioc clienteLvdSioc) {
		log.info("Inicio actualizar correlativo  " + swfMensajePar.getMenCodmen());

		SwiftDatos swiftDatos = swfMensajeLocal.swiftDatosFromSwfMensaje(swfMensajePar);
		swiftDatos.getSwfMensaje().setMenAuditusr(swfMensajePar.getMenAuditusr());
		swiftDatos.getSwfMensaje().setMenAuditwst(swfMensajePar.getMenAuditwst());

		swiftDatos.setAuditusr(swfMensajePar.getMenAuditusr());
		swiftDatos.setAuditwst(swfMensajePar.getMenAuditwst());

		requiereCorrelativo(swiftDatos.getSwfMensaje());
		// **** LAVADO ****//
		generarCorrelativoSwiftLavado(swiftDatos, clienteLvdSioc);

		SwfMensaje swfMensaje = actualizarCampo(swiftDatos, "20", 4, null);
			// se realiza el scaneo
		SearchResponse searchResponse = clienteLvdSioc.scanMensaje(swfMensaje);

		if (!StringUtils.isBlank(searchResponse.getMenPlano())) {
			swfMensaje.setMenPlano(searchResponse.getMenPlano());
		}
		
		swfMensaje = swfMensajeLocal.preAutorizarSwift(swfMensaje, pathSwift);

		log.info("Correlativo SWIFT Actualizado... " + swfMensajePar.getMenCodmen());
		return swfMensaje;
	}

	private static boolean requiereCorrelativo(SwfMensaje swfMensaje) {
		if (StringUtils.isBlank(swfMensaje.getMenCveestswift()) || swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)
				|| swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_RECH)) {
			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
			throw new SwiftAdminException(
					"Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
		}

		if (StringUtils.isBlank(swfMensaje.getMenCodusrswf())) {
			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
		}

		return true;
	}

	public static String fieldCorrelativo(SwfMensaje swfMensaje) {
		String userIniciales = StringUtils.trim(swfMensaje.getMenCodusrswf());

		String corr = String.format("%04d", (swfMensaje.getMenNrocorr() == null ? 0 : swfMensaje.getMenNrocorr()));
		String fecStr = UtilsDate.stringFromDate(new Date(), "ddMMyy");

		String valor = corr + "/" + fecStr + "/" + userIniciales;

		return valor;
	}
	
	public SwfMensaje autorizarMensaje(SwfMensaje swfMensajePar, String pathSwift) {
		SwfMensaje swfMensaje = swfMensajeLocal.autorizarSwift(swfMensajePar, pathSwift);

		return swfMensaje;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public SwfMsgParam recMsgParms(SwfMensaje swfMensaje) {
		SwfMttransfer swfMttransfer = swfMttransferLocal.findByCodigo(swfMensaje.getMenCodmt());
		if (swfMttransfer == null) {
			throw new SwiftAdminException("Tipo de mensaje " + swfMensaje.getMenCodmt() + " no parametrizado en SwfMttransfer.");
		}
		
		SwfMsgParam swfMsgParam = new SwfMsgParam();

		swfMsgParam.setMenTypemessage(swfMttransfer.getMttCodmt());
		swfMsgParam.setMenIdTMessageTx(swfMttransfer.getMttCodttransfer());
		swfMsgParam.setMenEmisor(swfMensaje.getMenBicemisor());
		swfMsgParam.setMenReceiver(swfMensaje.getMenBic());
		swfMsgParam.setMenBic(swfMensaje.getMenBic());		
		swfMsgParam.setMenCodmen(swfMensaje.getMenCodmen());
		swfMsgParam.setMenCodmenOrig(swfMensaje.getMenCodmen() != null ? swfMensaje.getMenCodmen().toString() : null);
		swfMsgParam.setMenCodmenrefer(swfMensaje.getMenCodoperacion());
		String codigoOperacion = String.valueOf(swfMensaje.getMenCodoperacion() + "" + swfMensaje.getMenDetcodigo());
		swfMsgParam.setMenIdoperacion(codigoOperacion);
		swfMsgParam.setMenGestion(swfMensaje.getMenGestion());
		swfMsgParam.setMenNrocorr(swfMensaje.getMenNrocorr());
//		swfMsgParam.setMenMonto              (swfMensaje.getMenMonto          ());
//		swfMsgParam.setMenCodmon             (swfMensaje.getMenCodmon         ());
		swfMsgParam.setMenCodmon(swfMensaje.getMenCodmonswift());
		swfMsgParam.setMenFecreg(swfMensaje.getMenFecreg());
		swfMsgParam.setMenFecauto(swfMensaje.getMenFecauto());
//		swfMsgParam.setMenFecvalor           (swfMensaje.getMenFecvalor       ());
		swfMsgParam.setMenEstmensaje(swfMensaje.getMenCveestswift());
		swfMsgParam.setMenCodusrswf(swfMensaje.getMenCodusrswf());
		swfMsgParam.setMenPlano(swfMensaje.getMenPlano());
		swfMsgParam.setMenNrocorr(swfMensaje.getMenNrolavado());
		swfMsgParam.setMenFormato(swfMttransfer.getMttFormato());

		return swfMsgParam;
	}

	public void inicializar() {
		swfMttransferLocal.setSessionFactory(getSessionFactory());
//		swfMttransferdetLocal.setSessionFactory(getSessionFactory());
		swfPersonactaLocal.setSessionFactory(getSessionFactory());
		swfMensajeLocal.setSessionFactory(getSessionFactory());
		swfDetmensajeLocal.setSessionFactory(getSessionFactory());
		socBancosDao.setSessionFactory(getSessionFactory());
		socBenefsDao.setSessionFactory(getSessionFactory());
		swfMencamposDbDao.setSessionFactory(getSessionFactory());
		swfMencamposIsoDaoImpl.setSessionFactory(sessionFactory);		
	}
	public static void main(String[] args) {
		BigDecimal d = BigDecimal.valueOf(BigDecimal.valueOf(450.99999).intValue());
		System.out.println(d);
	}
}
