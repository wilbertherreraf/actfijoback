/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.Detallesol;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.Factura;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.ServicioSioc;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.service.servicioSiocCoin.dao.ConsultasComunes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

//import org.hibernate.Query;

/**
 * @author wherrera
 * 
 */
@Transactional
public class SocOpecomiDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocOpecomiDao.class);

	public void eliminarRegs(String opecodigo, String cve_tipocomis) {
		// cve_tipocomis ; V = Variable
		List<SocOpecomi> lista = getByCveTipocomis(opecodigo, null, null, cve_tipocomis);
		List<SocOpecomi> listaRemove = new ArrayList<SocOpecomi>();
		for (SocOpecomi socOpecomi : lista) {
			if (socOpecomi.getClaEstadovar() == null || !socOpecomi.getClaEstadovar().equals("C")) {
				listaRemove.add(socOpecomi);
			}
		}
		if (listaRemove.size() > 0) {
			this.getHibernateTemplate().deleteAll(listaRemove);
			log.info("Eliminando soc_opecomi... " + opecodigo + " cve_tipocomis: " + cve_tipocomis + " len : " + listaRemove.size());
		}

	}

	public void saveOrUpdate(SocOpecomi pm) {
		// pm.setFechaHora(new Date());
		if (UserSessionHolder.get(Constants.AUDIT_USER_ESTACION) != null)
			pm.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

		if (UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID) != null)
			pm.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));

		this.getHibernateTemplate().merge(pm);
	}

	public void saveOrUpdateSolo(SocOpecomi pm) {
		this.getHibernateTemplate().saveOrUpdate(pm);
	}
	
	public List<SocOpecomi> getComis(String opeCodigo) {
		List<SocOpecomi> lista = new ArrayList<SocOpecomi>();

		StringBuffer query = new StringBuffer();

		query = query.append("select co ");
		query = query.append("from SocOpecomi co ");
		query = query.append("where co.id.opeCodigo = :opeCodigo ");

		log.info("Consulta lista comisiones getComis opeCodigo: " + opeCodigo + " --> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);

		lista = consulta.list();

		return lista;
	}

	public List<SocOpecomi> getOpeComisByDetCodClaComis(String opeCodigo, Integer detCodigo, String claComision) {
		List<SocOpecomi> lista = new ArrayList<SocOpecomi>();

		StringBuffer query = new StringBuffer();

		query = query.append("select co ");
		query = query.append("from SocOpecomi co ");
		query = query.append("where co.id.opeCodigo = :opeCodigo ");

		if (detCodigo != null)
			query = query.append("and co.id.detCodigo = :detCodigo ");
		else
			query = query.append("and co.id.detCodigo >= 0 ");
		
		if (!StringUtils.isBlank(claComision)) {
			query = query.append("and co.id.claComision = :claComision ");
		}

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);

		if (detCodigo != null)
			consulta.setParameter("detCodigo", detCodigo);

		if (!StringUtils.isBlank(claComision)) {
			consulta.setParameter("claComision", claComision);
		}

		lista = consulta.list();

		return lista;
	}

	public SocOpecomi findByCveTipocomis(String opeCodigo, Integer detCodigo, String claComision, String cveTipocomis) {
		List<SocOpecomi> lista = getByCveTipocomis(opeCodigo, detCodigo, claComision, cveTipocomis);
		if (lista.size() == 1) {
			return lista.get(0);
		}
		return null;
	}

	public List<SocOpecomi> getByCveTipocomis(String opeCodigo, Integer detCodigo, String claComision, String cveTipocomis) {
		List<SocOpecomi> lista = new ArrayList<SocOpecomi>();
		if (!StringUtils.isBlank(opeCodigo)) {
			return lista;
		}
		StringBuffer query = new StringBuffer();

		query = query.append("select co ");
		query = query.append("from SocOpecomi co ");
		query = query.append("where co.id.opeCodigo = :opeCodigo ");

		if (detCodigo != null)
			query = query.append("and co.id.detCodigo = :detCodigo ");
		else 
			query = query.append("and co.id.detCodigo >= 0 ");
		
		if (!StringUtils.isBlank(claComision)) {
			query = query.append("and co.id.claComision = :claComision ");
		}

		if (!StringUtils.isBlank(cveTipocomis)) {
			query = query.append("and co.cveTipocomis = :cveTipocomis ");
		}

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);

		if (detCodigo != null)
			consulta.setParameter("detCodigo", detCodigo);

		if (!StringUtils.isBlank(claComision)) {
			consulta.setParameter("claComision", claComision);
		}

		if (!StringUtils.isBlank(cveTipocomis)) {
			consulta.setParameter("cveTipocomis", cveTipocomis);
		}

		lista = consulta.list();

		return lista;
	}

	public List<SocOpecomi> getByCveTipocomis(String opeCodigo, String cveTipocomis) {
		List<SocOpecomi> lista = new ArrayList<SocOpecomi>();
		if (StringUtils.isBlank(opeCodigo)) {
			return lista;
		}
		StringBuffer query = new StringBuffer();

		query = query.append("select co ");
		query = query.append("from SocOpecomi co ");
		query = query.append("where co.id.opeCodigo = :opeCodigo ");
		query = query.append("and co.id.detCodigo >= 0 ");
		query = query.append("and co.cveTipocomis = :cveTipocomis ");
		query = query.append("and co.claEstadovar != 'C' ");
		
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);
		consulta.setParameter("cveTipocomis", cveTipocomis);

		lista = consulta.list();

		return lista;
	}

	public List<SocOpecomi> comisionesPorComisionopecomi(String opeCodigo, Integer codCargo) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT oc ");
		query = query.append("from SocOpecomi oc, SocComitipoope cto ");
		query = query.append("where oc.id.claComision = cto.claComisionopecomi ");
		query = query.append("and oc.id.opeCodigo = :opeCodigo ");
		query = query.append("and oc.id.detCodigo = 0 ");		
		query = query.append("and cto.id.codCargo = :codCargo ");		
		
		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("opeCodigo", opeCodigo);
		consulta.setParameter("codCargo", codCargo);		

		List result = consulta.list();

		return result;
	}
	
	public SocOpecomi getOpeComisByDetCodClaCom(String opeCodigo, Integer detCodigo, String claComision) {
		List<SocOpecomi> lista = getOpeComisByDetCodClaComis(opeCodigo, detCodigo, claComision);
		if (lista.size() == 1) {
			return lista.get(0);
		}
		return null;
	}
	
	public SocOpecomi getOpeComisByDetCodClaComOpt(String opeCodigo, Integer detCodigo, String claComision) {
		List<SocOpecomi> lista = getOpeComisByDetCodClaComis(opeCodigo, detCodigo, claComision);
		if (lista.size() == 1) {
			return lista.get(0);
		}
		SocOpecomi socOpecomi = new SocOpecomi();
		socOpecomi.setId(new SocOpecomiId());		
		return socOpecomi;
	}
	
	public SocOpecomi crearRegistro(Solicitud solicitud, String opeCodigo, Integer detCodigo, String claComision, BigDecimal ocoMonto, BigDecimal montoMo,
			Integer codMoneda, String glosa, String nit, String factura, String ctaCodigo, String cveTipocomis, BigDecimal tipoCambio) {
		// ojooo falta valores auditoria
//		SocOpecomi socOpecomiOld = nuevoRegistro(opeCodigo, detCodigo, claComision, ocoMonto, montoMo, codMoneda, glosa, nit, factura, ctaCodigo, cveTipocomis, tipoCambio);
		SocOpecomi socOpecomiOld = getOpeComisByDetCodClaCom(opeCodigo, detCodigo, claComision);
		if (socOpecomiOld == null) {
			// encontrado
			SocOpecomiId socOpecomiId = new SocOpecomiId(claComision, opeCodigo, detCodigo);
			socOpecomiOld = new SocOpecomi();
			socOpecomiOld.setId(socOpecomiId);
			socOpecomiOld.setClaEstadovar("P");

		}
		socOpecomiOld.setOcoMonto(ocoMonto);
		socOpecomiOld.setMontoMo(montoMo);
		socOpecomiOld.setCodMoneda(codMoneda);
		socOpecomiOld.setNit(nit);
		socOpecomiOld.setFactura(factura);
		socOpecomiOld.setNroCuenta(ctaCodigo);
		socOpecomiOld.setTipoCambio((tipoCambio != null ? tipoCambio.setScale(7, BigDecimal.ROUND_HALF_UP) : tipoCambio));
		socOpecomiOld.setCveTipocomis(cveTipocomis);
		socOpecomiOld.setFechaHora(new Date());
		socOpecomiOld.setUsrCodigo(solicitud.getCodUsuarioAudit());
		socOpecomiOld.setEstacion(solicitud.getCodEstacionAudit());		
//		socOpecomiOld.setUsrCodigo(solicitud.getSolicitud().getUsrCodigo());
//		socOpecomiOld.setEstacion(solicitud.getSolicitud().getEstacion());

		saveOrUpdate(socOpecomiOld);

		return socOpecomiOld;
	}

	public void crearSocOpecomiLista(SocSolicitudes socSolicitudes, List<SocOpecomi> socOpecomiLista) {
		for (SocOpecomi socOpecomi : socOpecomiLista) {
			log.info("Guardando socOpecomi " + socSolicitudes.getSocCodigo() + " tipo " + socOpecomi.getId().getClaComision());

			socOpecomi.getId().setOpeCodigo(socSolicitudes.getSocCodigo());
			socOpecomi.setUsrCodigo(socSolicitudes.getUsrCodigo());
			socOpecomi.setEstacion(socSolicitudes.getEstacion());
			socOpecomi.setFechaHora(new Date());

			this.getHibernateTemplate().merge(socOpecomi);
		}
	}

	public List<SocOpecomi> fromServicioSiocFactura(SocSolicitudes socSolicitudes, ServicioSioc servicioSioc) {
		if (servicioSioc.getDatosOperacion().getSolicitud().getFacturaciones() == null || servicioSioc.getDatosOperacion().getSolicitud().getFacturaciones().getFactura() == null
				|| servicioSioc.getDatosOperacion().getSolicitud().getFacturaciones().getFactura().size() == 0) {
			throw new BusinessException("Solicitud sin datos de facturaciones ");
		}

		List<Factura> facturaLista = servicioSioc.getDatosOperacion().getSolicitud().getFacturaciones().getFactura();

		log.info("Mapeando from ServicioSioc Facturas " + facturaLista.size());
		List<SocOpecomi> socOpecomiLista = new ArrayList<SocOpecomi>();

		for (Factura factura : facturaLista) {
			SocOpecomiId socOpecomiId = new SocOpecomiId(factura.getTipoFactura(), socSolicitudes.getSocCodigo(), 0);
			SocOpecomi socOpecomiOld = new SocOpecomi();
			socOpecomiOld.setId(socOpecomiId);
			socOpecomiOld.setClaEstadovar("P");
			// por defecto factura N no registrado en coin
			socOpecomiOld.setNroCuenta("N");
			socOpecomiOld.setOcoMonto(BigDecimal.ZERO);
			socOpecomiOld.setMontoMo(BigDecimal.ZERO);
			socOpecomiOld.setNit(factura.getNit());
			socOpecomiOld.setTipoDocumento(factura.getTipoDocumento());
			socOpecomiOld.setComplemento(factura.getComplemento());
			socOpecomiOld.setCorreo(factura.getCorreo());
			
			if (StringUtils.isBlank(factura.getNit())) {
				throw new BusinessException("Solicitud en tipo factura " + factura.getTipoFactura() + " con nit nulo");
			}

			socOpecomiOld.setFactura(factura.getRazonSocial());
			if (StringUtils.isBlank(factura.getRazonSocial())) {
				throw new BusinessException("Solicitud en tipo factura " + factura.getTipoFactura() + " con razon social nulo");
			}
			socOpecomiOld.setCveTipocomis(Constants.COD_TIPOREGVARIABLE_FACT);

			socOpecomiLista.add(socOpecomiOld);
		}

		log.info("Despues de facturitas " + socOpecomiLista.size());

		return socOpecomiLista;
	}

	public void recuperarFacturas(SocSolicitudes socSolicitudes, List<SocDetallessol> socDetallessolLista) {
		log.info("En recuperar Facturas " + socSolicitudes.getSolCodigo());

		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		SocComitipoopeDao socComitipoopeDao = new SocComitipoopeDao();
		socComitipoopeDao.setSessionFactory(getSessionFactory());

		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(getSessionFactory());
		// ***************************************//
		SocOpecomi socOpecomiSolic = recuperarDatosFacturasSolicitante(socSolicitudes);
		
		if (socSolicitudes.getEsqCodigo() == null) {
			throw new BusinessException("Solicitud [" + socSolicitudes.getSocCodigo() + "] sin codigo de esquema");
		}

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(socSolicitudes.getEsqCodigo());
		List<SocRengesq> socRengesqLista = socRengesqDao.getRengsEsquema(socSolicitudes.getEsqCodigo());

		for (SocRengesq socRengesq : socRengesqLista) {
			if (socRengesq.getEsqDh() == null || socRengesq.getEsqDh() != 'H') {
				continue;
			}
			
			SocCuentassol socCuentassol = socCuentassolDao.getByClaveCuenta(socRengesq.getClaCuenta(), Constants.COD_MONEDA_BS);
			if (socCuentassol == null || StringUtils.isBlank(socCuentassol.getCveImptiva())) {
				continue;
			}

			if (!socCuentassol.getCveImptiva().equals("C") && !socCuentassol.getCveImptiva().equals("S")) {
				continue;
			}
			
			SocComitipoope socComitipoope = socComitipoopeDao.comisionByCargoClaCuenta(socEsquemas.getCodCargo(), socRengesq.getClaCuenta());
			
			if (socComitipoope == null) {
				socComitipoope = socComitipoopeDao.comisionByCargoClaComisionopecomi(socEsquemas.getCodCargo(), socRengesq.getEsqDefinicion());
			}
			
			// verificamos si existe registrado la variable de faturas
			SocOpecomi socOpecomi = null;			
			if (socComitipoope == null) {
				// no existe
				if (!socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_VENTA)) {
					throw new BusinessException("Variable de cargo [" + socRengesq.getClaCuenta() +"] no declarado en SocComitipoope para cargo " + socEsquemas.getCodCargo());					
				}
				socOpecomi = getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, Constants.CLAVE_TIPOFACT_VDD);
			} else {
				socOpecomi = getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, socComitipoope.getClaComisvarfact());				
			}
			
			if (socOpecomi != null) {
				// ya fue registrado se verifica que exista en coin
				if (socSolicitudes.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_WS)) {
					continue;
				}
			} else {

				socOpecomi = nuevoRegFactura(socSolicitudes);
				if (socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_VENTA)) {
					socOpecomi.getId().setClaComision(Constants.CLAVE_TIPOFACT_VDD);					
				} else {
					socOpecomi.getId().setClaComision(socComitipoope.getClaComisvarfact());					
				}
			}
			// no existe o se debe actualizar
			
			if (socRengesq.getClaCuenta().equalsIgnoreCase(Constants.CLAVE_CLACTA_VENTA)) {
				// venta de divisas siempre va al solicitante
				socOpecomi.setNit(socOpecomiSolic.getNit());
				socOpecomi.setFactura(socOpecomiSolic.getFactura());
				socOpecomi.setTipoDocumento(socOpecomiSolic.getTipoDocumento());
				socOpecomi.setComplemento(socOpecomiSolic.getComplemento());
				socOpecomi.setCorreo(socOpecomiSolic.getCorreo());
				socOpecomi.setNroCuenta(socOpecomiSolic.getNroCuenta());
			} else {
				// control de la cuenta que asume la comision
				SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(socSolicitudes.getSocCodigo(), socComitipoope.getSctTipocuenta(), null, null, null, null);

				if (socSolicitudctas == null) {
					throw new BusinessException("Solicitud no registra cuenta " + socComitipoope.getSctTipocuenta() + " en socsolicitudctas");
				}

				if (StringUtils.isBlank(socSolicitudctas.getCveTipocomis())) {
					throw new BusinessException("Solicitud [" + socSolicitudes.getSocCodigo() + "] con Cuenta " + socComitipoope.getSctTipocuenta()
							+ " con valor invalido debe ser (B o S) en campo socSolicitudctas.CveTipocomis,  avise a sistemas");
				}
				
				if (socSolicitudctas.getCveTipocomis().equals(Constants.CLAVE_TIPOCOMIS_SOLIC)) {
					socOpecomi.setNit(socOpecomiSolic.getNit());
					socOpecomi.setFactura(socOpecomiSolic.getFactura());
					socOpecomi.setTipoDocumento(socOpecomiSolic.getTipoDocumento());
					socOpecomi.setComplemento(socOpecomiSolic.getComplemento());
					socOpecomi.setCorreo(socOpecomiSolic.getCorreo());					
					socOpecomi.setNroCuenta(socOpecomiSolic.getNroCuenta());
					
				} else if (socSolicitudctas.getCveTipocomis().equals(Constants.CLAVE_TIPOCOMIS_BENEF)) {
					// la cuenta de comision es del beneficiario
					if (socDetallessolLista.size() != 1) {
						throw new BusinessException(
								"Solicitud [" + socSolicitudes.getSocCodigo() + "] con Factura al beneficiario con [" + socDetallessolLista.size() + "] beneficiarios registrados");
					}

					socOpecomi.setNit(null);
					socOpecomi.setFactura(null);					
					socOpecomi.setTipoDocumento(null);
					socOpecomi.setComplemento(null);
					socOpecomi.setCorreo(null);
					
					Beneficiario beneficiario = socBenefsDao.recuperarBeneficiario(socSolicitudes, socDetallessolLista.get(0));

					if (beneficiario != null) {
						log.warn("Beneficiario [" + socDetallessolLista.get(0).getBenCodigo() + "] existente para " + socSolicitudes.getCveSubtipooper());

						socOpecomi.setFactura(beneficiario.getBenFactura());
						if (StringUtils.isBlank(beneficiario.getBenFactura())) {
							socOpecomi.setFactura(beneficiario.getBenNombre());
						}
						socOpecomi.setNit(beneficiario.getBenNit());
						socOpecomi.setTipoDocumento(Constants.CVE_TIPOFACTCOIN_NIT);
					}
					if (!StringUtils.isBlank(socOpecomi.getNit())) {
						socOpecomi.setTipoDocumento(StringUtils.isBlank(beneficiario.getTipoDocumento()) ? Constants.CVE_TIPOFACTCOIN_NIT : beneficiario.getTipoDocumento());
					}
				} 
			}
			
			SocOpecomi socOpecomiNew = this.getHibernateTemplate().merge(socOpecomi);
			log.info(socSolicitudes.getSocCodigo() + "::Registrando factura : " + socRengesq.getClaCuenta() + " tipoFactura =" + socOpecomiNew.getId().getClaComision() + " nit: "
					+ socOpecomiNew.getNit() + " razon:" + socOpecomiNew.getFactura());
			log.info("Reg factura opecomi " + socOpecomiNew.toString());
		}

		SocOpecomi socOpecomi = getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, Constants.CLAVE_CLACTA_VENTA);
		
		if (socOpecomi == null) {
			SocOpecomi socOpecomiFact = getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, Constants.CLAVE_TIPOFACT_VDD);
			if (socOpecomiFact != null) {
				socOpecomi = nuevoRegFactura(socSolicitudes);
				socOpecomi.getId().setClaComision(Constants.CLAVE_CLACTA_VENTA);
				socOpecomi.setNit(socOpecomiFact.getNit());
				socOpecomi.setFactura(socOpecomiFact.getFactura());
				socOpecomi.setNroCuenta(socOpecomiFact.getNroCuenta());
				socOpecomi.setTipoDocumento(socOpecomiFact.getTipoDocumento());
				socOpecomi.setComplemento(socOpecomiFact.getComplemento());
				socOpecomi.setCorreo(socOpecomiFact.getCorreo());
				
				this.getHibernateTemplate().merge(socOpecomi);
			}			
		}

		log.info("Fin En recuperarFacturaSolicitante " + socSolicitudes.getSolCodigo());		
	}
	
	private SocOpecomi recuperarDatosFacturasSolicitante(SocSolicitudes socSolicitudes) {
		log.info("En recuperarDatosFacturasSolicitante " + socSolicitudes.getSolCodigo());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());
		
		SocOpecomi socOpecomi = nuevoRegFactura(socSolicitudes);
		
		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socSolicitudes.getSolCodigo().trim());
		socOpecomi.setCorreo(!StringUtils.isBlank(socSolicitante.getCorreo()) ? socSolicitante.getCorreo() : null);
		socOpecomi.setFactura(!StringUtils.isBlank(socSolicitante.getSolFactura()) ? socSolicitante.getSolFactura() : null);
		socOpecomi.setNit(!StringUtils.isBlank(socSolicitante.getSolNit()) ? socSolicitante.getSolNit() : null);
		socOpecomi.setFactura(!StringUtils.isBlank(socOpecomi.getFactura()) ? socOpecomi.getFactura() : socSolicitante.getSolPersona());
		if (!StringUtils.isBlank(socSolicitante.getSolNit())) {
			socOpecomi.setTipoDocumento(!StringUtils.isBlank(socSolicitante.getTipoDocumento()) ? socSolicitante.getTipoDocumento() : Constants.CVE_TIPOFACTCOIN_NIT);			
		}
		
		Map<String, Object> result = null;
		
		if (StringUtils.isBlank(socSolicitante.getSolNit()) || StringUtils.isBlank(socSolicitante.getCorreo())) {
			ConsultasComunes consultasComunes = new ConsultasComunes();
			consultasComunes.setSessionFactory(SiocCoinService.getSessionFactory());
			
			result = consultasComunes.persona(socSolicitudes.getSolCodigo().trim());
			
			boolean solModifica = false;
			if (result != null) {
				if (StringUtils.isBlank(socSolicitante.getSolNit())) {
					socOpecomi.setNit(result.get("ruc") != null && result.get("ruc").toString().trim().length() > 0 ? result.get("ruc").toString().trim() : null);
					socOpecomi.setFactura(result.get("nompersona") != null && result.get("nompersona").toString().trim().length() > 0 ? result.get("nompersona").toString().trim() : null);
					// origen factura P: persona contbcb
					socOpecomi.setNroCuenta("P");
					
					Integer tipodoc = result.get("tipodoc") != null ? (Integer) result.get("tipodoc") : 5;
					
					SocValorescla socValorescla = socValoresclaDao.getValoresByValNombre(Constants.CLAVE_TIPODOCCONTA, tipodoc.toString());
					if (socValorescla != null && StringUtils.isBlank(socValorescla.getValNombre())) {
						socOpecomi.setTipoDocumento(socValorescla.getValNombre());	
					}		
					socSolicitante.setSolFactura(socOpecomi.getFactura());
					socSolicitante.setSolNit(socOpecomi.getNit());
					socSolicitante.setTipoDocumento(socOpecomi.getTipoDocumento());
					solModifica = true;
				}
				
				if (StringUtils.isBlank(socSolicitante.getCorreo())) {
					socOpecomi.setCorreo(result.get("email") != null && result.get("email").toString().trim().length() > 0 ? result.get("email").toString().trim() : null);
					socSolicitante.setCorreo(socOpecomi.getCorreo());
					solModifica = true;
				}
				
				if (solModifica) {
					socSolicitanteDao.saveOrUpdate(socSolicitante);
					log.info("Consulta en CONTBCB de Nit " + socOpecomi.getNit() + " razon: " + socOpecomi.getFactura() + " email: " + socOpecomi.getCorreo());				
				}				
			}
		}
		
		return socOpecomi;
	}
	
	public void recuperarFacturaSolicitante(SocSolicitudes socSolicitudes, String claComision) {
		SocOpecomi socOpecomiOld = getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, claComision);
		if (socOpecomiOld != null) {
			return;
		}
		
		SocOpecomi socOpecomi = recuperarDatosFacturasSolicitante(socSolicitudes);
		socOpecomi.getId().setClaComision(claComision);
		if (StringUtils.isBlank(socOpecomi.getNit()) || StringUtils.isBlank(socOpecomi.getFactura())) {
			throw new BusinessException("Datos de Nit o Factura invalidos para solicitante " + socSolicitudes.getSolCodigo());			
		}
		this.getHibernateTemplate().merge(socOpecomi);
	}
	
	private static SocOpecomi nuevoRegFactura(SocSolicitudes socSolicitudes) {
		SocOpecomiId socOpecomiId = new SocOpecomiId();
		socOpecomiId.setDetCodigo(0);
		socOpecomiId.setOpeCodigo(socSolicitudes.getSocCodigo());

		SocOpecomi socOpecomi = new SocOpecomi();
		socOpecomi.setId(socOpecomiId);

		// N ; no registrado factura en agenda coin
		socOpecomi.setClaEstadovar("P");
		socOpecomi.setNroCuenta("N");
		socOpecomi.setOcoMonto(BigDecimal.ZERO);
		socOpecomi.setMontoMo(BigDecimal.ZERO);
		socOpecomi.setCveTipocomis(Constants.COD_TIPOREGVARIABLE_FACT);
		socOpecomi.setTipoDocumento(Constants.CVE_TIPOFACTCOIN_NIT);
		socOpecomi.setFechaHora(new Date());
		socOpecomi.setEstacion(socSolicitudes.getEstacion());
		socOpecomi.setUsrCodigo(socSolicitudes.getUsrCodigo());
		
		return socOpecomi; 
	}
	
	public List<Detallesol> obtenerComisiones(SocSolicitudes socSolicitudes) {
		List<Detallesol> detallesolLista = new ArrayList<Detallesol>();
		if (StringUtils.isBlank(socSolicitudes.getSocCodigo())) {
			return detallesolLista;
		}
		
		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(getSessionFactory());
	
		SocComitipoopeDao socComitipoopeDao = new SocComitipoopeDao();
		socComitipoopeDao.setSessionFactory(getSessionFactory());

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(socSolicitudes.getEsqCodigo());		
		List<SocOpecomi> socOpecomiLista = comisionesPorComisionopecomi(socSolicitudes.getSocCodigo(), socEsquemas.getCodCargo());
		
		for (SocOpecomi socOpecomi : socOpecomiLista) {
			Detallesol detallesol = new Detallesol();
			detallesol.setSocOpecomi(socOpecomi);
			
			SocComitipoope socComitipoope = socComitipoopeDao.comisionByCargoClaComisionopecomi(socEsquemas.getCodCargo(), socOpecomi.getId().getClaComision());
			if (socComitipoope != null) {
				detallesol.setSocComitipoope(socComitipoope);
				detallesolLista.add(detallesol);				
			}			
		}
		return detallesolLista;		
	}

	public List<Detallesol> obtenerComisionesEmisiones(SocSolicitudes socSolicitudes) {
		List<Detallesol> detallesolLista = obtenerVariablesDeLista(socSolicitudes, Arrays.asList(Constants.COD_VAR_MONTOCOMEMISCARTCREDMT, Constants.COD_VAR_MONTOCOMEMISCARTCREDSLD));
		
		return detallesolLista;
	}
	
	public List<Detallesol> obtenerVariablesDeLista(SocSolicitudes socSolicitudes, List<String> variables) {
		List<Detallesol> detallesolLista = new ArrayList<Detallesol>();
		if (StringUtils.isBlank(socSolicitudes.getSocCodigo())) {
			return detallesolLista;
		}
		for(String vari : variables) {
			Detallesol detallesol = new Detallesol();			
			SocOpecomi socOpecomi = getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, vari);
			if (socOpecomi != null) {
				if (socOpecomi.getMontoMo() != null && socOpecomi.getMontoMo().compareTo(BigDecimal.ZERO) != 0) {
					detallesol.setSocOpecomi(socOpecomi);
					detallesolLista.add(detallesol);					
				}
			}
		}
		return detallesolLista;		
	}
}
