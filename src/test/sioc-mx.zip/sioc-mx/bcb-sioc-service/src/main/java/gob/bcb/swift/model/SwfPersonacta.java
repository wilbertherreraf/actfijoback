package gob.bcb.swift.model;

import gob.bcb.bpm.pruebaCU.SocBancos;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "swf_personacta")
public class SwfPersonacta implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SwfPersonactaPK id;
	@Column(name = "pec_descripcta")
	private String pecDescripcta;
	@Column(name = "pec_codmoncta")
	private String pecCodmoncta;
	@Column(name = "pec_tipoctainst")
	private String pecTipoctainst;
	@Column(name = "pec_codinstinter")
	private String pecCodinstinter;
	@Column(name = "pec_nroctainter")
	private String pecNroctainter;

	@Column(name = "pec_estadocta")
	private String pecEstadocta;
	
	@Column(name = "pec_codttransfer")
	private String pecCodttransfer;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "pec_auditfho")
	private Date pecAuditfho;

	@Column(name = "pec_auditusr")
	private String pecAuditusr;

	@Column(name = "pec_auditwst")
	private String pecAuditwst;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="pec_codinst", insertable = false, updatable = false)
	private SocBancos socBancoscodinst; 

	public SwfPersonacta() {

	}

	public SwfPersonactaPK getId() {
		return id;
	}

	public void setId(SwfPersonactaPK id) {
		this.id = id;
	}

	public String getPecDescripcta() {
		return pecDescripcta;
	}

	public void setPecDescripcta(String pecDescripcta) {
		this.pecDescripcta = pecDescripcta;
	}

	public String getPecCodmoncta() {
		return pecCodmoncta;
	}

	public void setPecCodmoncta(String pecCodmoncta) {
		this.pecCodmoncta = pecCodmoncta;
	}

	public String getPecTipoctainst() {
		return pecTipoctainst;
	}

	public void setPecTipoctainst(String pecTipoctainst) {
		this.pecTipoctainst = pecTipoctainst;
	}

	public String getPecCodinstinter() {
		return pecCodinstinter;
	}

	public void setPecCodinstinter(String pecCodinstinter) {
		this.pecCodinstinter = pecCodinstinter;
	}

	public String getPecNroctainter() {
		return pecNroctainter;
	}

	public void setPecNroctainter(String pecNroctainter) {
		this.pecNroctainter = pecNroctainter;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Date getPecAuditfho() {
		return pecAuditfho;
	}

	public void setPecAuditfho(Date pecAuditfho) {
		this.pecAuditfho = pecAuditfho;
	}

	public String getPecAuditusr() {
		return pecAuditusr;
	}

	public void setPecAuditusr(String pecAuditusr) {
		this.pecAuditusr = pecAuditusr;
	}

	public String getPecAuditwst() {
		return pecAuditwst;
	}

	public void setPecAuditwst(String pecAuditwst) {
		this.pecAuditwst = pecAuditwst;
	}

//	public Institucion getInstitucionCodinst() {
//		return institucionCodinst;
//	}
//
//	public void setInstitucionCodinst(Institucion institucionCodinst) {
//		this.institucionCodinst = institucionCodinst;
//	}
//
//	public Institucion getInstitucionCodinstinter() {
//		return institucionCodinstinter;
//	}
//
//	public void setInstitucionCodinstinter(Institucion institucionCodinstinter) {
//		this.institucionCodinstinter = institucionCodinstinter;
//	}

	public String getPecEstadocta() {
		return pecEstadocta;
	}

	public void setPecEstadocta(String pecEstadocta) {
		this.pecEstadocta = pecEstadocta;
	}

	public String getPecCodttransfer() {
		return pecCodttransfer;
	}

	public void setPecCodttransfer(String pecCodttransfer) {
		this.pecCodttransfer = pecCodttransfer;
	}

	public SocBancos getSocBancoscodinst() {
		return socBancoscodinst;
	}

	public void setSocBancoscodinst(SocBancos socBancoscodinst) {
		this.socBancoscodinst = socBancoscodinst;
	}

}
