//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci de la referencia de enlace (JAXB) XML v2.2.8-b130911.1802 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2021.08.11 a las 02:27:16 PM BOT 
//


package gob.bcb.service.servicioSioc.ws.xml.consultasolic;
 
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para respuesta_operacion complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="respuesta_operacion">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cod_entidad" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nom_solicitante" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="beneficiarios" type="{}beneficiarios" minOccurs="0"/>
 *         &lt;element name="solicitudes_bolsin" type="{}solicitudes_bolsin" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "respuesta_operacion", propOrder = {
    "codEntidad",
    "nomSolicitante",
    "beneficiarios",
    "solicitudesBolsin"
})
public class RespuestaOperacion {

    @XmlElement(name = "cod_entidad")
    protected String codEntidad;
    @XmlElement(name = "nom_solicitante")
    protected String nomSolicitante;
    protected Beneficiarios beneficiarios;
    @XmlElement(name = "solicitudes_bolsin")
    protected SolicitudesBolsin solicitudesBolsin;

    /**
     * Obtiene el valor de la propiedad codEntidad.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodEntidad() {
        return codEntidad;
    }

    /**
     * Define el valor de la propiedad codEntidad.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodEntidad(String value) {
        this.codEntidad = value;
    }

    /**
     * Obtiene el valor de la propiedad nomSolicitante.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomSolicitante() {
        return nomSolicitante;
    }

    /**
     * Define el valor de la propiedad nomSolicitante.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomSolicitante(String value) {
        this.nomSolicitante = value;
    }

    /**
     * Obtiene el valor de la propiedad beneficiarios.
     * 
     * @return
     *     possible object is
     *     {@link Beneficiarios }
     *     
     */
    public Beneficiarios getBeneficiarios() {
        return beneficiarios;
    }

    /**
     * Define el valor de la propiedad beneficiarios.
     * 
     * @param value
     *     allowed object is
     *     {@link Beneficiarios }
     *     
     */
    public void setBeneficiarios(Beneficiarios value) {
        this.beneficiarios = value;
    }

    /**
     * Obtiene el valor de la propiedad solicitudesBolsin.
     * 
     * @return
     *     possible object is
     *     {@link SolicitudesBolsin }
     *     
     */
    public SolicitudesBolsin getSolicitudesBolsin() {
        return solicitudesBolsin;
    }

    /**
     * Define el valor de la propiedad solicitudesBolsin.
     * 
     * @param value
     *     allowed object is
     *     {@link SolicitudesBolsin }
     *     
     */
    public void setSolicitudesBolsin(SolicitudesBolsin value) {
        this.solicitudesBolsin = value;
    }

}
