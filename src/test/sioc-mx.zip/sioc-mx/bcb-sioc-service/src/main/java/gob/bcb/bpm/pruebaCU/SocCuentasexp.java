package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the soc_cuentasexp database table.
 * 
 */
@Entity
@Table(name="soc_cuentasexp")
public class SocCuentasexp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cta_codigo")
	private Integer ctaCodigo;

	@Column(name="bco_codigo")
	private String bcoCodigo;

	@Column(name="bco_codigo1")
	private String bcoCodigo1;

	@Column(name="cla_tipocuenta")
	private String claTipocuenta;

	@Column(name="cla_vigente")
	private short claVigente;

	@Column(name="cta_nrocuenta")
	private String ctaNrocuenta;

	@Column(name="cta_nrocuenta1")
	private String ctaNrocuenta1;

	private String estacion;

	@Temporal( TemporalType.TIMESTAMP)	
	@Column(name="fecha_hora")
	private Date fechaHora;

	private Integer moneda;

	private Integer moneda1;

	private String observ;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocCuentasexp() {
    }

	public Integer getCtaCodigo() {
		return this.ctaCodigo;
	}

	public void setCtaCodigo(Integer ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public String getBcoCodigo() {
		return this.bcoCodigo;
	}

	public void setBcoCodigo(String bcoCodigo) {
		this.bcoCodigo = bcoCodigo;
	}

	public String getBcoCodigo1() {
		return this.bcoCodigo1;
	}

	public void setBcoCodigo1(String bcoCodigo1) {
		this.bcoCodigo1 = bcoCodigo1;
	}

	public String getClaTipocuenta() {
		return this.claTipocuenta;
	}

	public void setClaTipocuenta(String claTipocuenta) {
		this.claTipocuenta = claTipocuenta;
	}

	public short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(short claVigente) {
		this.claVigente = claVigente;
	}

	public String getCtaNrocuenta() {
		return this.ctaNrocuenta;
	}

	public void setCtaNrocuenta(String ctaNrocuenta) {
		this.ctaNrocuenta = ctaNrocuenta;
	}

	public String getCtaNrocuenta1() {
		return this.ctaNrocuenta1;
	}

	public void setCtaNrocuenta1(String ctaNrocuenta1) {
		this.ctaNrocuenta1 = ctaNrocuenta1;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Integer getMoneda() {
		return this.moneda;
	}

	public void setMoneda(Integer moneda) {
		this.moneda = moneda;
	}

	public Integer getMoneda1() {
		return this.moneda1;
	}

	public void setMoneda1(Integer moneda1) {
		this.moneda1 = moneda1;
	}

	public String getObserv() {
		return this.observ;
	}

	public void setObserv(String observ) {
		this.observ = observ;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}
}