package gob.bcb.swift.service;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.iso20022.dao.SwfMencamposIsoDao;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.swift.dao.SwfDetmensajeBean;
import gob.bcb.swift.dao.SwfDetmensajeLocal;
import gob.bcb.swift.dao.SwfMencamposDbDao;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMensajeLocal;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.dao.SwfMttransferLocal;
import gob.bcb.swift.dao.SwfPersonactaBean;
import gob.bcb.swift.dao.SwfPersonactaLocal;
import gob.bcb.swift.model.SwfMencamposDb;

public class SwfMencamposIsoDaoImpl implements SwfMencamposIsoDao {
	private static final Log log = LogFactory.getLog(CreateSwiftService.class);

	private SessionFactory sessionFactory;
	@Autowired
	private SwfMencamposDbDao swfMencamposDbDao = new SwfMencamposDbDao();
	@Autowired
	private SocBancosDao socBancosDao = new SocBancosDao();
	@Autowired
	private SocBenefsDao socBenefsDao = new SocBenefsDao();
	@Autowired
	private SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
	@Autowired
	private SwfMttransferLocal swfMttransferLocal = new SwfMttransferBean();
	@Autowired
	private SwfPersonactaLocal swfPersonactaLocal = new SwfPersonactaBean();
	@Autowired
	private SwfDetmensajeLocal swfDetmensajeLocal = new SwfDetmensajeBean();

	public List<SwfMencampos> opcionesDeCampo(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		return swfMencamposDbDao.opcionesDeCampo(mtfCodmt, mtfNro, mtfGrpopt, mtfBloque).stream().map(cloneSwfMencamposDb()).collect(Collectors.toList());
	}

	public Optional<SwfMencampos> nextGrpoptSwfMencampos(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfCodcampo, String mtfBloque) {
		Optional<SwfMencamposDb> tOpt = swfMencamposDbDao.nextGrpoptSwfMencamposDb(mtfCodmt, mtfNro, mtfGrpopt, mtfCodcampo, mtfBloque);
		return tOpt.flatMap(tt -> Optional.of(cloneSwfMencamposDb().apply(tt)));
	}

	public Optional<SwfMencampos> nextNroSwfMencampos(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		Optional<SwfMencamposDb> tOpt = swfMencamposDbDao.nextNroSwfMencamposDb(mtfCodmt, mtfNro, mtfGrpopt, mtfBloque);
		return tOpt.flatMap(tt -> Optional.of(cloneSwfMencamposDb().apply(tt)));
	}

	public Optional<SwfMencampos> nextNroSwfMencampos(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque, Integer mtfNivel) {
		Optional<SwfMencamposDb> tOpt = swfMencamposDbDao.nextNroSwfMencamposDb(mtfCodmt, mtfNro, mtfGrpopt, mtfBloque, mtfNivel);
		return tOpt.flatMap(tt -> Optional.of(cloneSwfMencamposDb().apply(tt)));
	}

	public List<SwfMencampos> findByMT(String mtfCodmt, String mtfBloque) {
		return swfMencamposDbDao.findByMT(mtfCodmt, mtfBloque).stream().map(cloneSwfMencamposDb()).collect(Collectors.toList());
	}

	public List<SwfMencampos> findByCodigoBlk(String mtfCodmt, String mtfCodcampo, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		return swfMencamposDbDao.findByCodigoBlk(mtfCodmt, mtfCodcampo, mtfNro, mtfGrpopt, mtfBloque).stream().map(cloneSwfMencamposDb())
				.collect(Collectors.toList());
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void inicializar() {
		swfMttransferLocal.setSessionFactory(getSessionFactory());
		// swfMttransferdetLocal.setSessionFactory(getSessionFactory());
		swfPersonactaLocal.setSessionFactory(getSessionFactory());
		swfMensajeLocal.setSessionFactory(getSessionFactory());
		swfDetmensajeLocal.setSessionFactory(getSessionFactory());
		socBancosDao.setSessionFactory(getSessionFactory());
		socBenefsDao.setSessionFactory(getSessionFactory());
		swfMencamposDbDao.setSessionFactory(sessionFactory);
	}

	@Override
	public List<SwfMencampos> findById(Integer mtfId) {
		// TODO Auto-generated method stub
		return null;
	}

	public static Function<SwfMencamposDb, SwfMencampos> cloneSwfMencamposDb() {
		return (swfMencamposDbOld) -> {
			if (swfMencamposDbOld == null) {
				return null;
			}

			SwfMencampos swfMencamposDbNew = new SwfMencampos();
			swfMencamposDbNew.setMtfId(swfMencamposDbOld.getMtfId());
			swfMencamposDbNew.setMtfCodmt(swfMencamposDbOld.getMtfCodmt());
			swfMencamposDbNew.setMtfNro(swfMencamposDbOld.getMtfNro());
			swfMencamposDbNew.setMtfGrpopt(swfMencamposDbOld.getMtfGrpopt());
			swfMencamposDbNew.setMtfCodcampo(swfMencamposDbOld.getMtfCodcampo());
			swfMencamposDbNew.setMtfNemo(swfMencamposDbOld.getMtfNemo());
			swfMencamposDbNew.setMtfBloque(swfMencamposDbOld.getMtfBloque());
			swfMencamposDbNew.setMtfCondicion(swfMencamposDbOld.getMtfCondicion());
			swfMencamposDbNew.setMtfDatoadic(swfMencamposDbOld.getMtfDatoadic());
			swfMencamposDbNew.setMtfDefault(swfMencamposDbOld.getMtfDefault());
			swfMencamposDbNew.setMtfDescrip(swfMencamposDbOld.getMtfDescrip());
			swfMencamposDbNew.setMtfExpresion(swfMencamposDbOld.getMtfExpresion());
			swfMencamposDbNew.setMtfFormato(swfMencamposDbOld.getMtfFormato());
			swfMencamposDbNew.setMtfReglaswf(swfMencamposDbOld.getMtfReglaswf());
			swfMencamposDbNew.setMtfReglavalid(swfMencamposDbOld.getMtfReglavalid());
			swfMencamposDbNew.setMtfSecpadre(swfMencamposDbOld.getMtfSecpadre());
			swfMencamposDbNew.setMtfStatus(swfMencamposDbOld.getMtfStatus());
			swfMencamposDbNew.setMtfTipocampo(swfMencamposDbOld.getMtfTipocampo());
			swfMencamposDbNew.setMtfEstado(swfMencamposDbOld.getMtfEstado());
			swfMencamposDbNew.setMtfIndexiso(swfMencamposDbOld.getMtfIndexiso());
			swfMencamposDbNew.setMtfNivel(swfMencamposDbOld.getMtfNivel());
			swfMencamposDbNew.setMtfXmltag(swfMencamposDbOld.getMtfXmltag());
			swfMencamposDbNew.setMtfCardinal(swfMencamposDbOld.getMtfCardinal());
			swfMencamposDbNew.setMtfCambiavalor(swfMencamposDbOld.getMtfCambiavalor());
			swfMencamposDbNew.setMtfMinimo(swfMencamposDbOld.getMtfMinimo());
			swfMencamposDbNew.setMtfValidacionerror(swfMencamposDbOld.getMtfValidacionerror());
			swfMencamposDbNew.setMtfCambiatipousr(swfMencamposDbOld.getMtfCambiatipousr());
			swfMencamposDbNew.setMtfCardinalmult(swfMencamposDbOld.getMtfCardinalmult());
			swfMencamposDbNew.setMtfSinonimos(swfMencamposDbOld.getMtfSinonimos());
			swfMencamposDbNew.setMtfConvalornoreq(swfMencamposDbOld.getMtfConvalornoreq());
			swfMencamposDbNew.setMtfEsopcional(swfMencamposDbOld.getMtfEsopcional());
			swfMencamposDbNew.setMtfEsadicional(swfMencamposDbOld.getMtfEsadicional());
			swfMencamposDbNew.setMtfSubaction1(swfMencamposDbOld.getMtfSubaction());
			swfMencamposDbNew.setMtfSubaction2(swfMencamposDbOld.getMtfSubaction2());
			swfMencamposDbNew.setMtfSubaction3(swfMencamposDbOld.getMtfSubaction3());
			swfMencamposDbNew.setMtfSubaction4(swfMencamposDbOld.getMtfSubaction4());
			swfMencamposDbNew.setMtfSubaction5(swfMencamposDbOld.getMtfSubaction5());

			return swfMencamposDbNew;
		};
	}

}
