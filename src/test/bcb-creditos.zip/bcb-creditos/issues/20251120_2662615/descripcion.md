# SDAPO 2662615

## AJUSTAR REPORTE DE SERVICIO DE DEUDA

### Cambios aplicados
- Seleccionar el menú ***Pago de Cuota*** en la acción ***Búsqueda por Nro de Crédito*** ingrese el numero ***14***  de acuerdo al siguiente detalle:.

![1.png](./screenshots/1.png)

- Seleccione el reporte del registro numero 11
![2.png](./screenshots/2.png)

- Se genera el reporte con los ajustes requeridos
![3.png](./screenshots/3.png)  



