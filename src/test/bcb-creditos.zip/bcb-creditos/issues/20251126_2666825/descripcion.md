# SDAPO 2666825

## AJUSTAR MODULO DE DEVENGADOS

### Cambios aplicados
- Seleccionar el menú ***Devengado de Creditos*** en la pestaña ***Devengado Manual - Todos*** seleccione la fecha  y presione el boton ***Ejecutar***  de acuerdo al siguiente detalle:.

![1.png](./screenshots/1.png)

- Una vez realizado el registro ir a la pestaña ***Devengado por Credito***, seleccione el credito y presione el boton ***Ver Comprobante/Preautorizar/Autorizar*** 
![2.png](./screenshots/2.png)

- Verificar los datos de ***Importe intéres devengado*** y ***N° de días devengados***
![3.png](./screenshots/3.png)  

### ADICION DE OPCION PARA REGULARIZAR EL REGISTRO DE CONTABILIZACIÓN

- Seleccionar el menú ***Busqueda de créditos***, buscar el credito requerido y seleccione la opción ***ver devengados*** 

![4.png](./screenshots/4.png)  

El sistema lista los dos ultimos registros de contabilizacion realizados por el usuario. 
Para realizar el registro o edicion de los datos presione los botones de ***NUEVO*** o ***EDITAR***

![5.png](./screenshots/5.png)

![6.png](./screenshots/6.png)