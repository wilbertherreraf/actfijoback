
<%@ page session="true"%>

Usuario '<%=request.getRemoteUser()%>' sali�.
<%-- <% //session.invalidate(); %> --%>
<% request.logout(); %>
<% request.getSession(false).invalidate(); %>

<script>
    document.execCommand("ClearAuthenticationCache");
    window.location.replace("index.html");
</script>

