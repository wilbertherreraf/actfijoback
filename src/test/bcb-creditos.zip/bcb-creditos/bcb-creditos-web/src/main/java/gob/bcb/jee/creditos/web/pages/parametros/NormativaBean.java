/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-web
 * gob.bcb.jee.creditos.web.pages.parametros.NormativaBean
 * 31/03/2016 - 15:29:51
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.web.pages.parametros;

import gob.bcb.jee.creditos.BL.*;
import gob.bcb.jee.creditos.core.comunes.webManage.ManageGenericBean;
import gob.bcb.jee.creditos.entidades.Empresa;
import gob.bcb.jee.creditos.entidades.Normativa;
import gob.bcb.jee.creditos.entidades.NormativaEmpresa;
import gob.bcb.jee.creditos.entidades.ValorDominio;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.web.util.ContextActions;
import gob.bcb.jee.creditos.web.util.CttesAuditoria;
import gob.bcb.jee.creditos.web.util.Recurso;
import lombok.Getter;
import lombok.Setter;
import org.apache.log4j.Logger;


import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Inject;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Managed Bean para la vista de Normativa
 *
 * @author ysalinas
 */
@SuppressWarnings("serial")
@ManagedBean(name = "normativaBean")
@ViewScoped
@Getter
@Setter
public class NormativaBean
        extends ManageGenericBean<Normativa, Integer> {

    //region Propiedad(es)
    private String THOUSAND_SEPARATOR = ".";
    @Inject
    NormativaBLLocal normativaBLLocal;
    @Inject
    NormativaEmpresaBLLocal normativaEmpresaBLLocal;

    private List<SelectItem> lstTipoNormativa;
    private List<SelectItem> lstGarantias;
    private List<SelectItem> lstMonedas;
    private List<Empresa> lstEmpresas;

    private boolean esNuevo;

    private boolean tipoNormativaSimple = false;
    private boolean visibilidadNormativa = true;
    private String montoTexto;

    private NormativaEmpresa empresaActual;

   // private UploadedFile archivo;

    private static final Logger log = Logger.getLogger(NormativaBean.class);

    private static final String TIPO_NORMATIVA_COD_DATO_LEY = "LEY";
    //endregion

    //region Constructor(es)
    public NormativaBean() {
       // super(Recurso.PARAM_NORMATIVAS);
    }
    //endregion

    //region Metodo(s) protegido(s)
    @Override
    protected GenericBLLocal getBL() {
        return normativaBLLocal;
    }
    //endregion

    //region Metodo(s) Publico(s)
    @PostConstruct
    @Override
    public void initBean() {
        log.debug("Iniciando NormativaBean");
        esNuevo = true;
        super.postConstruct();
        find();
        if (this.getPermiso().isEjecucion()) {
            ContextActions.primeContext("PF('my-column-filter').selectValue('"
                    + Estado.P.toString() + "');");
        }
        if (lstTipoNormativa == null || lstTipoNormativa.size() == 0) {
            lstTipoNormativa = new ArrayList<SelectItem>();
            // try {
                // List<ValorDominio> lstClaves = valorDominioBLLocal
                //         .listarValoresDominioByDominioAutorizado(Cttes.DOM_TIPO_NORMATIVA);
                // lstTipoNormativa.add(new SelectItem(null, "Todos"));
                // for (ValorDominio item : lstClaves) {
                //     lstTipoNormativa.add(new SelectItem(item.getId()
                //             .getCodDato(), item.getValorDato()));
                // }
            // } catch (OperationException e) {
            //     log.error(
            //             "Error al obtener claves " + Cttes.DOM_TIPO_NORMATIVA,
            //             e);
            // }
        }

        if (lstGarantias == null || lstGarantias.size() == 0) {
            lstGarantias = new ArrayList<SelectItem>();

                // List<ValorDominio> lstClaves = valorDominioBLLocal
                //         .listarValoresDominioByDominioAutorizado(Cttes.DOM_TIPO_GARANTIA);
                // lstGarantias.add(new SelectItem(null, "Ninguna"));
                // for (ValorDominio item : lstClaves) {
                //     lstGarantias.add(new SelectItem(item.getId().getCodDato(),
                //             item.getValorDato()));
                // }

        }
        if (lstMonedas == null || lstMonedas.size() == 0) {
            lstMonedas = new ArrayList<SelectItem>();

                // List<ValorDominio> lstClaves = valorDominioBLLocal
                //         .listarValoresDominioByDominioAutorizado(Cttes.DOM_TIPO_MONEDA);
                // //lstMonedas.add(new SelectItem(null, "Ninguna"));
                // for (ValorDominio item : lstClaves) {
                //     lstMonedas.add(new SelectItem(item.getId().getCodDato(),
                //             item.getValorDato()));
                // }

        }
        if (lstEmpresas == null || lstEmpresas.size() == 0) {
            lstEmpresas = new ArrayList<Empresa>();
            // try {
            //     lstEmpresas = empresaBLLocal.list();
            // } catch (OperationException e) {
            //     log.error("Error al obtener las empresas", e);
            // }
        }
        log.debug("Finalizando NormativaBean");
    }

    public void prepararVerif(Normativa item) {
        try {
            log.info("Ingresando a la clase " + getClass().getSimpleName()
                    + " al metodo prepararVerificacion()");
            log.info("Normativa actual: " + itemActual);
            editando = true;
            itemActual = item;
            log.info("Quedó itemActual: " + itemActual);
        } catch (Exception e) {
            log.error("Error al preparar verificacion", e);
            ContextActions.sendError(e.getMessage());
        }
    }

    /**
     * Metodo para Habilitar o Suspender una garamtoa
     */
    public void habilitarOSuspender() {
        log.debug("Ingresando a la clase " + getClass().getSimpleName()
                + " al metodo habilitarOSuspender()");
        try {
//            Estado estado;
//            if (!itemActual.getEstado().equals(Estado.S)) {
//                estado = Estado.S;
//            } else {
//                estado = Estado.A;
//            }
//            normativaBLLocal.changeEstate(itemActual.getId(), estado);
//            ContextActions.primeContext("PF('dlgSuspenderHabilitar').hide();");
//            ContextActions
//                    .sendDialogInfo(estado.equals(Estado.A) ? ContextActions.HABILITACION_OK
//                            : ContextActions.SUSPENSION_OK);
        } catch (Exception e) {
            log.error(
                    "Error al cambiar el estado de la documentacion requerida.",
                    e);
            ContextActions.sendError(ContextActions.CAMBIO_DE_ESTADO_NOK);
        }
        find();
    }

    /**
     * verifica la documentacion requerida para ser autorizado
     */
    public void verificar() {
        itemActual.setLogAuditoria(getLogAuditoria(CttesAuditoria.AUTORIZACION_DATOS, itemActual.getLogAuditoria()));
        super.autorizar();
        find();
        ContextActions.primeContext("PF('dlgAutorizar').hide();");
        ContextActions
                .sendDialogInfo(autorizado ? ContextActions.AUTORIZACION_OK
                        : ContextActions.RECHAZO_OK);
    }

    @Override
    public void save() {
        log.info("Guardará: " + itemActual);
     //  RequestContext context = RequestContext.getCurrentInstance();
//        FacesMessage message = null;
//        // Validamos las empresas seleccionadas
//        if (this.operacionExistosa && itemActual.getEmpresas().size() > 0) {
//            itemActual.setEstado(Estado.P);
//
//            super.save();
//            ContextActions.sendDialogInfo(ContextActions.GUARDADO);
//            visibilidadNormativa = false;
//        //    context.addCallbackParam("normativa", true);
//        } else {
//            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Debe agregar una empresa a la normativa", "Debe agregar una empresa a la normativa");
//            FacesContext.getCurrentInstance().addMessage(null, message);
//          //  context.addCallbackParam("normativa", false);
//        }

    }

    @Override
    public void find() {
        super.find();
    }

    public void eliminarNormativa() {
        log.debug("Ingresando a la clase " + getClass().getSimpleName()
                + " metodo eliminarNormativa()");
        try {
            normativaBLLocal.delete(itemActual.getId(), this.getSessionBean()
                    .getUsuarioSesion().getLogin());
            ContextActions.primeContext("PF('dlgEliminarNormativa').hide();");
            ContextActions.sendDialogInfo(ContextActions.ELIMINACION_OK);
            find();
            log.debug("Eliminada la Normativa " + itemActual.getNombre());
        } catch (Exception e) {
            log.error(
                    "Error al eliminar la normativa." + itemActual.getNombre(),
                    e);
            ContextActions.sendError(ContextActions.ELIMINACION_NOK);
        }
    }

    @Override
    public void createNew() {
        super.createNew();
        visibilidadNormativa = false;
        tipoNormativaSimple = true;
    }

    @Override
    public void edit() {
//        super.edit();
        visibilidadNormativa = true;
        tipoNormativaSimple = true;
        esNuevo = false;
        editando = true;
        log.info("Item Actual " + itemActual);
        if (itemActual.getEmpresas() == null)
            itemActual.setEmpresas(new ArrayList<NormativaEmpresa>());
        log.info("Empresa actual " + empresaActual);
//        if (itemActual.getTipoNormativa().equalsIgnoreCase(
//                TIPO_NORMATIVA_COD_DATO_LEY)) {
//            tipoNormativaSimple = true;
//        } else {
//            tipoNormativaSimple = false;
//        }
    }


    public void editEmpresa() {
        esNuevo = false;
        log.info("Item Actual " + itemActual);
        if (itemActual.getEmpresas() == null)
            itemActual.setEmpresas(new ArrayList<NormativaEmpresa>());
        log.info("Institución actual " + empresaActual);
    }

    public void createNewEmpresa() {
        empresaActual = new NormativaEmpresa();
        esNuevo = true;

    }

    @SuppressWarnings("SpellCheckingInspection")
    public void saveEmpresa() {
//        RequestContext context = RequestContext.getCurrentInstance();
//        FacesMessage message = null;
        boolean existeError = false;
     //  RequestContext context = RequestContext.getCurrentInstance();
        FacesMessage message = null;
        if (itemActual.getEmpresas() == null)
            itemActual.setEmpresas(new ArrayList<NormativaEmpresa>());

        List<NormativaEmpresa> empresas = itemActual.getEmpresas();
        for (NormativaEmpresa empresa : empresas) {
            if (empresa.getEmpresa().getId().equals(empresaActual.getEmpresa().getId()) && esNuevo) {
                //Lanzamos una exepcion de validacion indicando que la empresa ya se encuentra registrada para esta ley
                message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "La empresa ya encuentra registrada", "La empresa ya encuentra registrada");
                FacesContext.getCurrentInstance().addMessage(null, message);
                existeError = true;
            //    context.addCallbackParam("errorEmpresa", false);
            }else{
              //  context.addCallbackParam("errorEmpresa", true);
            }
        }
        if (esNuevo && !existeError) {
          //  context.addCallbackParam("errorEmpresa", true);
            itemActual.getEmpresas().add(empresaActual);
        }

        log.info("Agregado item " + empresaActual + "Num items: " + itemActual.getEmpresas().size());
        this.operacionExistosa = true;

    }

    public String getTiponormativaLabel(String cod) {
        for (SelectItem item : lstTipoNormativa) {
            if (cod.equals(item.getValue())) {
                return item.getLabel();
            }
        }
        return "-";
    }

    public String getTipoGarantiaLabel(String cod) {
        log.info("cod garantia recibido: " + cod);
        for (SelectItem item : lstGarantias) {
            if (cod.equals(item.getValue())) {
                return item.getLabel();
            }
        }
        return "-";
    }

    public ArrayList<NormativaEmpresa> getNormativaEmpresaByNormativa(
            Integer normativaId) {
        List<NormativaEmpresa> lstNormativaEmpresa = new ArrayList<NormativaEmpresa>();
        try {
            lstNormativaEmpresa = normativaEmpresaBLLocal
                    .listByNormativa(normativaId);
        } catch (OperationException e) {
            log.error(
                    "Error al obtener NormativaEmpresa con normativaId = "
                            + normativaId, e);
        }
        return (ArrayList<NormativaEmpresa>) lstNormativaEmpresa;

    }

    public BigDecimal convertToBigDecimal(String number) {
        // quitamos signo de miles
        number = number.replace(THOUSAND_SEPARATOR, "");
        try {
            return new BigDecimal(number);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }


    public void eliminarEmpresa() {



        for (int i = 0; i < itemActual.getEmpresas().size(); i++) {
            if(itemActual.getEmpresas().get(i).getEmpresa().getId() == empresaActual.getEmpresa().getId()){
                itemActual.getEmpresas().remove(i);
            }
        }

    }
    //endregion


}
