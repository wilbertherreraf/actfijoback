package gob.bcb.jee.creditos.converters;

/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-web
 * gob.bcb.jee.creditos.converters.UpperCaseConverter
 * 25/03/2016 - 15:25:03
 * Creado por ysalinas
 */

import java.util.Locale;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

/**
 * Converter que transforma a mayusculas las cadenas ingredadas en pantalla
 * 
 * @author ysalinas
 */
@FacesConverter("upperCaseConverter")
public class UpperCaseConverter implements Converter
{

  public Object getAsObject(FacesContext fx, UIComponent component,
      String value) throws ConverterException
  {
    if (value == null)
      return null;

    Locale locale = fx.getExternalContext().getRequestLocale();
    return value.toUpperCase(locale);
  }

  public String getAsString(FacesContext cx, UIComponent component,
      Object value) throws ConverterException
  {
    if (value == null)
    {
      return null;
    }
    return value.toString();
  }
}
