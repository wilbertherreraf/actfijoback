package gob.bcb.jee.creditos.web.pages.gestion;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import gob.bcb.jee.creditos.model.PrePrestamos;
import lombok.Getter;
import lombok.Setter;

@ManagedBean(name = "prePrestamosSessionBean")
@Getter
@Setter
//@Named
@SessionScoped
public class PrePrestamosSessionBean implements Serializable {
    private static final long serialVersionUID = 1L;
    private PrePrestamos prePrestamosSelected;


}
