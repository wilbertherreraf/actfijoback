package gob.bcb.jee.creditos.web.pages.gestion;

import gob.bcb.jee.creditos.entidades.PreRegistrogarantias;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class PreRegistrogarantiasService {

    @PersistenceContext
    private EntityManager entityManager;

    public PreRegistrogarantias findByCoddsb(Integer coddsb) {
        return entityManager.createQuery("SELECT pr FROM PreRegistrogarantias pr WHERE pr.coddsb.id = :coddsb and pr.estado<>4 ", PreRegistrogarantias.class)
                .setParameter("coddsb", coddsb)
                .getSingleResult();
    }
}
