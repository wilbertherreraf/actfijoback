package gob.bcb.jee.creditos.web.pages.gestion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.jee.creditos.BL.AuxPlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocalImpl;
import gob.bcb.jee.creditos.BL.PreDesembolsoDetalleBLLocal;
import gob.bcb.jee.creditos.BL.PrePagocuotaBLLocal;
import gob.bcb.jee.creditos.BL.PrePlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreReprogramaBLLocal;
import gob.bcb.jee.creditos.BL.PreTasaspreBLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocalImpl;
import gob.bcb.jee.creditos.entidades.EstadoDesembolsosQuery;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.entidades.VPVPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.VPVPlanPagosDsbQuery;
import gob.bcb.jee.creditos.entidades.VPlanPagosConsolQuery;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.pojo.PreDesembolsoDto;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "PagoAnticipadoBean")
@ViewScoped
@Getter
@Setter
public class PagoAnticipadoCreditoBean implements Serializable {
	private static final Logger log = LoggerFactory.getLogger(CobroCreditoBean.class);
	private static final long serialVersionUID = 1L;

	@Inject
	private GenTipProductoBLLocal genTipProductoBLLocal;

	@Inject
	private GenDesctablaBLLocal genDesctablaBLLocal;

	@Inject
	private AuxPlanpagosBLLocal auxPlanpagosLocal;
	@Inject
	private GenMonedaBLLocal genMonedaBLLocal;

	@Inject
	private PrePrestamosBLLocal prePrestamosBLLocal;

	@Inject
	private PreDesembBLLocal preDesembBLLocal;

	@Inject
	private CliPersonaBLLocal service;

	@Inject
	private PreTasaspreBLLocal preTasaspreBLLocal;

	@Inject
	private PrePlanpagosBLLocal prePlanpagosLocal;
	@Inject
	private PrePlanpagosQLLocal prePlanpagosQLLocal;
	@Inject
	private PreReprogramaBLLocal preReprogramaBLLocal;
	@Inject
	private PreDesembolsoDetalleBLLocal preDesembolsoDetalleBLLocal;

	@Inject
	private PrePagocuotaBLLocal prePagocuotaBLLocal;

	private List<CliPersona> products = new ArrayList<>();;

	private List<VPVPlanPagosDsbQuery> vpPlanpagosDsb = new ArrayList<>();
	private VPlanPagosConsolQuery vPlanpConsolTotals = new VPlanPagosConsolQuery();

	private VPVPlanPagosDsbQuery vPlanpDsbTotals = new VPVPlanPagosDsbQuery();
	private VPVPlanPagosConsolQuery vpPlanpDsbTotals = new VPVPlanPagosConsolQuery();
	private List<VPlanPagosConsolQuery> vPlanpagosConsol = new ArrayList<>();
	private List<EstadoDesembolsosQuery> listEstadoDesembolsos = new ArrayList<>();
	private EstadoDesembolsosQuery estadoDesembolsosTots = new EstadoDesembolsosQuery();
	// List<VPVPlanPagosConsolQuery> planpagosPVVctos;
	private PrePrestamos itemActual;

	private PreReprograma preReprograma = new PreReprograma();
	private List<PreReprograma> listPreReprograma = new ArrayList<>();

	private List<PrePrestamos> listPrePrestamos = new ArrayList<>();;
	private CliPersona cliPersona = new CliPersona();
	private String cliente;
	private List<GenTipproducto> listGenTipproductos = new ArrayList<>();
	private String igenTipproducto;

	private PreDesemb preDesembSelected;
	private List<PreDesembolsoDto> preDesembolsoDtoList = new ArrayList<>();

	private Integer codigoPrestamo;
	private String contrato;

	private String CSC = Cttes.CONTRA_SIGUIENTE_CUOTA;
	private String DESC_CSC = Cttes.DESCRIPCION_CONTRA_SIGUIENTE_CUOTA;
	private String DLC = Cttes.DISTRIBUCION_LINEAL_CUOTA;
	private String DESC_DLC = Cttes.DESCRIPCION_DISTRIBUCION_LINEAL_CUOTA;
	private boolean preliminar = false;

	public PagoAnticipadoCreditoBean() {
	}

	@PostConstruct
	public void init() {
		try {
			listGenTipproductos = genTipProductoBLLocal.list();
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		}

		catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void inicializaObjetos() {
		itemActual = null;		
		limpiar();
		listPrePrestamos.clear();
	}

	private void limpiar() {
		vpPlanpagosDsb.clear();
		preDesembSelected = null;
		preDesembolsoDtoList.clear();
		vPlanpagosConsol.clear();
		listEstadoDesembolsos.clear();
	}

	public void seleccionarItem(PrePrestamos prestamos) {
		try {
			Log.Info("Prestamos seleccionado " + prestamos.getPrePrestamosPK().getPreCodcred());
			limpiar();
			itemActual = prePrestamosBLLocal.prestamoById(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());
			listPreReprograma = recuperarPantis(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());

			vPlanpConsolTotals = PrePlanpagosQLLocalImpl.sumarConStreamsPpConsol(vPlanpagosConsol);
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
		}
	}

	public void iniciar() {
	}

	public void verPagosAnticipados(Integer codcred, Integer codmod) {
		vpPlanpagosDsb.clear();
		preDesembSelected = null;
		preDesembolsoDtoList.clear();
		vPlanpagosConsol.clear();
		listEstadoDesembolsos.clear();		
		try {
			itemActual = prePrestamosBLLocal.prestamoById(codcred, codmod);			
			listPreReprograma = recuperarPantis(codcred, codmod);
			verPPConsolPV(itemActual);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void inicioRegistroPanti(Integer codcred, Integer codmod) {
			preReprograma = new PreReprograma();
			preReprograma.setRdsCodcred(codcred);
			preReprograma.setRdsCodmod(codmod);
			preReprograma.setRdsFecini(new Date());
			preReprograma.setRdsValor(BigDecimal.ZERO);
			preReprograma.setRdsTipoPago(DLC);					
			preReprograma.setRdsTabtiporepro(59);
			preReprograma.setRdsTiporepro(2);
			preReprograma.setRdsTabtrxstaau(30);
			preReprograma.setRdsTrxstaau(1);

	}

	public void cancelarRegPanti() {
		verPPConsolPP(itemActual);
	}

	public void grabarPagoAnticipado(Integer codcred, Integer codmod) {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("En crear nuevo pago anticip {} usr {}", codcred, usuario.getLogin());

			preReprograma.setId(preReprogramaBLLocal.nuevoId());
			preReprograma.setRdsAuditusr(usuario.getLogin());
			preReprograma.setRdsAuditfho(new Date());
			preReprograma.setRdsAuditwst(UtilWeb.getIPRemoto());

			prePrestamosBLLocal.pagoAnticipadoNuevo(preReprograma, codmod, preReprograma.getRdsCodrepro(), new Date(),
					usuario.getLogin(), UtilWeb.getIPRemoto());

			listPreReprograma = recuperarPantis(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod());
			verPPConsolPV(itemActual);

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información",
					"Creado el pago anticipado correctamente");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void preautorizar(PreReprograma reprograma) {

		try {
			preReprograma = reprograma;
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Pago aantiicpado preautorizando cred {} repro {}", reprograma.getRdsCodcred(),
					reprograma.getRdsCodrepro());
			// preReprograma.setRdsTrxstaau(2);
			preReprograma.setRdsAuditusr(usuario.getLogin());
			preReprograma.setRdsAuditfho(new Date());
			preReprograma.setRdsAuditwst(UtilWeb.getIPRemoto());

			prePrestamosBLLocal.preAutoPagAnticip(preReprograma.getRdsCodmod(), preReprograma.getRdsCodrepro(),
					preReprograma.getRdsFecini(), usuario.getLogin(), UtilWeb.getIPRemoto());

			listPreReprograma = recuperarPantis(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod());

			verPPConsolPV(itemActual);

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información",
					"Creado el pago anticipado correctamente");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void autorizar(PreReprograma reprograma) {
		try {
			log.info("Pago aantiicpado autorizando cred {} repro {}", reprograma.getRdsCodcred(),
					reprograma.getRdsCodrepro());
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			preReprograma = reprograma;
			prePrestamosBLLocal.autorizarPagAnticip(preReprograma.getRdsCodmod(), preReprograma.getRdsCodrepro(),
					preReprograma.getRdsFecini(), usuario.getLogin(), UtilWeb.getIPRemoto());
			listPreReprograma = recuperarPantis(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod());

			verPPConsolPP(itemActual);

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información",
					"Pago anticipado realizado correctamente");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void eliminarReprogramacion(PreReprograma reprograma) {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {
			preReprograma = reprograma;
			Log.Info("Pago anticipado a eliminar:" + reprograma.getRdsCodrepro());
			prePrestamosBLLocal.eliminarAutoPagAnticip(9, reprograma.getRdsCodrepro(), preReprograma.getRdsFecini(),
					usuario.getLogin(),
					UtilWeb.getIPRemoto());
			// iniciarVerReprogramacion(itemActual.getId().getPreCodcred(),
			// itemActual.getId().getPreCodmod());
			listPreReprograma = recuperarPantis(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod());
			verPPConsolPV(itemActual);

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Pago anticipado rechazado",
					"Satisfactorio");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void verPPConsolPV(PrePrestamos prestamos) {
		// pp aux
		try {
			preDesembolsoDtoList.clear();
			vpPlanpagosDsb.clear();
			preDesembSelected = null;
			vPlanpagosConsol.clear();
			listEstadoDesembolsos.clear();
			itemActual = prePrestamosBLLocal.prestamoById(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());
			vPlanpagosConsol = prePlanpagosQLLocal.planpagosPPOPV(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());
			vPlanpConsolTotals = PrePlanpagosQLLocalImpl.sumarConStreamsPpConsol(vPlanpagosConsol);
			preliminar = true;
		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void verPPConsolPP(PrePrestamos prestamos) {
		// pp de oficial
		try {
			preDesembolsoDtoList.clear();
			vpPlanpagosDsb.clear();
			preDesembSelected = null;
			vPlanpagosConsol.clear();
			listEstadoDesembolsos.clear();
			listPreReprograma.clear();
			vPlanpagosConsol = prePlanpagosQLLocal.planConsolPorCodmodYCodcred(
					prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());
			vPlanpConsolTotals = PrePlanpagosQLLocalImpl.sumarConStreamsPpConsol(vPlanpagosConsol);
			preliminar = false;
		} catch (Exception e) {
			log.error("Erroe " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public List<VPVPlanPagosConsolQuery> recuperarPVPPConsol(PrePrestamos prestamos) {
		try {
			List<VPVPlanPagosConsolQuery> planpagosVctos = prePlanpagosQLLocal.planVPConsolPorCodmodYCodcred(
					prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());
			preliminar = true;
			return planpagosVctos;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	public void recuperarDesembolsos(PrePrestamos prestamos) {
		Map<String, Object> valores = new HashMap<>();
		valores.put("valor1", prestamos.getPrePrestamosPK().getPreCodcred());
		valores.put("valor2", prestamos.getPrePrestamosPK().getPreCodmod());

		try {
			preDesembolsoDtoList.clear();
			vpPlanpagosDsb.clear();
			vPlanpagosConsol.clear();
			listEstadoDesembolsos.clear();
			preDesembSelected = null;

			List<PreDesemb> auxListDesembolso = preDesembBLLocal.listByNamedQuery(PreDesemb.NQ_LIST_BY_CREDITO,
					valores);
			for (PreDesemb dato : auxListDesembolso) {
				PreDesembolsoDto dto = new PreDesembolsoDto();
				dto.setDesembolso(dato);
				dto.setDesembolsoDetalle(preDesembolsoDetalleBLLocal.obtenerPorCodDesembolso(dato.getDsbCoddsb()));

				preDesembolsoDtoList.add(dto);
			}
		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void recuperarPlanesFecha(PrePrestamos prestamos, Date fecha) {
		try {
			preDesembolsoDtoList.clear();
			listEstadoDesembolsos.clear();
			vPlanpagosConsol.clear();
			preDesembSelected = null;

			vpPlanpagosDsb = prePlanpagosQLLocal.planpagosPPOPVAFecha(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod(),fecha,3);
					
			vPlanpDsbTotals = PrePlanpagosQLLocalImpl.sumarConStreamsPvDsb(vpPlanpagosDsb);

		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}


	private List<VPlanPagosConsolQuery> recuperarPPConsol(PrePrestamos prestamos) {
		try {
			List<VPlanPagosConsolQuery> planpagosVctos = prePlanpagosQLLocal.planConsolPorCodmodYCodcred(
					prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());
			return planpagosVctos;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}


	private List<PreReprograma> recuperarPantis(Integer codcred, Integer codmod) {
		Map<String, Object> valores = new HashMap<>();
		valores.put("valor1", codcred);
		valores.put("valor2", codmod);
		valores.put("valor3", 2);// reprogramacion

		try {
			return preReprogramaBLLocal.listByNamedQuery(PreReprograma.NQ_GET_BY_CRED, valores);
		} catch (OperationException e) {

		}
		return new ArrayList<>();
	}

	public void selectCliPersonaFromDialog(CliPersona product) {
		try {
			// cliPersona = product;
			limpiar();
			cliente = cliPersona.getCliNombre();
			contrato = "";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());
			itemActual = null;
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
			preDesembolsoDtoList.clear();
		}

		catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDeContrato() {
		try {
			limpiar();
			cliente = "";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
			itemActual = null;
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);
			preDesembolsoDtoList.clear();
		}

		catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDePrestamo() {
		try {
			cliente = "";
			contrato = "";
			limpiar();
			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			itemActual = null;
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);
			preDesembolsoDtoList.clear();
		}

		catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarClientes() {
		try {
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public VPVPlanPagosDsbQuery getvPlanpDsbTotals() {
		return vPlanpDsbTotals;
	}

	public void setvPlanpDsbTotals(VPVPlanPagosDsbQuery vPlanpDsbTotals) {
		this.vPlanpDsbTotals = vPlanpDsbTotals;
	}

	public VPlanPagosConsolQuery getvPlanpConsolTotals() {
		return vPlanpConsolTotals;
	}

	public void setvPlanpConsolTotals(VPlanPagosConsolQuery vPlanpConsolTotals) {
		this.vPlanpConsolTotals = vPlanpConsolTotals;
	}

	public List<VPlanPagosConsolQuery> getvPlanpagosConsol() {
		return vPlanpagosConsol;
	}

	public void setvPlanpagosConsol(List<VPlanPagosConsolQuery> vPlanpagosConsol) {
		this.vPlanpagosConsol = vPlanpagosConsol;
	}
	public boolean isPreliminar() { return preliminar; }

	private void recuperarEstServDeudaXDsb(PrePrestamos prestamos, Date fecha) {
		try {
			preDesembolsoDtoList.clear();
			listEstadoDesembolsos.clear();
			vPlanpagosConsol.clear();
			preDesembSelected = null;
			vpPlanpagosDsb.clear();
			actListDesembolsos(fecha, prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());

		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}
	private void actListDesembolsos(Date fecha, Integer codcred, Integer codmod) {
		listEstadoDesembolsos.clear();
		if (fecha == null || codcred == null || codmod == null)
			return;
		Integer tipoproc = 3; // reporte
		log.info("En recuperar [{}]lista de estados a fecha {}", codcred, fecha);
		prePagocuotaBLLocal.generarDevengadosCredito(codcred, codmod, fecha, fecha, tipoproc);

		listEstadoDesembolsos = preDesembBLLocal.estadoDesembolsosAFecha(codcred, codmod, null, fecha);
		estadoDesembolsosTots = PreDesembBLLocalImpl.sumarConStreams(listEstadoDesembolsos);
	}
	private void verPlanDePagosDesemb(PreDesemb desemb) {
		try {
			listEstadoDesembolsos.clear();
			preDesembSelected = desemb;
			vpPlanpagosDsb = prePlanpagosQLLocal.planVPDsbPorCodmodYCodcred(preDesembSelected.getDsbCodcred(),
					preDesembSelected.getDsbCodmod(),
					preDesembSelected.getDsbCoddsb());

			vPlanpDsbTotals = PrePlanpagosQLLocalImpl.sumarConStreamsPvDsb(vpPlanpagosDsb);

		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}


}
