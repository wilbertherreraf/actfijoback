package gob.bcb.jee.creditos.web.pages.gestion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocalImpl;
import gob.bcb.jee.creditos.BL.PrePagocuotaBLLocal;
import gob.bcb.jee.creditos.BL.PrePrccontaBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.QL.GenPrcparamsQLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocalImpl;
import gob.bcb.jee.creditos.entidades.EstadoDesembolsosQuery;
import gob.bcb.jee.creditos.entidades.GenPrcparams;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.entidades.VPVPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.VPVPlanPagosDsbQuery;
import gob.bcb.jee.creditos.entidades.VPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.pojo.ComprobanteDet;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.PrePrcconta;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "DevengadoCreditoBean")
@ViewScoped
@Getter
@Setter
public class DevengadoCreditoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(DevengadoCreditoBean.class);

	@Inject
	private CliPersonaBLLocal service;

	@Inject
	private PrePrestamosBLLocal prePrestamosBLLocal;

	@Inject
	private PrePrccontaBLLocal prePrccontaBLLocal;
	@Inject
	private PrePagocuotaBLLocal prePagocuotaBLLocal;
	@Inject
	private PreDesembBLLocal preDesembBLLocal;
	@Inject
	private PrePlanpagosQLLocal prePlanpagosQLLocal;

	@Inject
	private GenPrcparamsQLLocal genPrcparamsQLLocal;

	private VPVPlanPagosDsbQuery vPlanpDsbTotals = new VPVPlanPagosDsbQuery();
	private VPVPlanPagosConsolQuery vpPlanpDsbTotals = new VPVPlanPagosConsolQuery();
	private List<VPlanPagosConsolQuery> vPlanpagosConsol = new ArrayList<>();

	private VPlanPagosConsolQuery vPlanpConsolTotals = new VPlanPagosConsolQuery();

	private Integer codigoPrestamo;
	private String contrato;
	private Date fechaDevTodos;
	private CliPersona cliPersona = new CliPersona();
	private String cliente;
	private List<CliPersona> clientesList;
	private PrePrestamos itemActual;
	private EstadoDesembolsosQuery estadoDesembolsosTots = new EstadoDesembolsosQuery();
	private List<EstadoDesembolsosQuery> listEstadoDesembolsos = new ArrayList<>();

	private boolean onDevengar;
	private PrePrcconta prePrcconta;
	private List<Object[]> datosComprobanteCoin;
	private CliPersona clienteActivo;
	private Date fechaDevengado;
	private Date fechaRecCoin;
	private Date fechaUltimoDevengado;
	private List<Object[]> DatosFechaDevengado;
	private boolean operacionExitosa;
	private boolean editando;
	private List<ComprobanteDet> listRenglones = new ArrayList<>();
	private List<PrePrestamos> listPrePrestamos = new ArrayList<>();
	private List<PrePrcconta> listaDevengados = new ArrayList<>();

	private BigDecimal debeSuma = BigDecimal.valueOf(0.00);
	private BigDecimal haberSuma = BigDecimal.valueOf(0.00);

	public DevengadoCreditoBean() {
	}

	@PostConstruct
	public void init() {
		inicializaObjetos();
	}

	public void inicializaObjetos() {
		itemActual = null;
		cliente = "";
		contrato = "";
		codigoPrestamo = null;
		onDevengar = false;
		limpiar();
		prePrcconta = null;
		fechaDevTodos = new Date();
		fechaDevengado = new Date();
		listPrePrestamos.clear();
		try {
			clientesList = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (OperationException e) {
		}
	}

	private void limpiar() {
		listRenglones.clear();
		listaDevengados.clear();
		listEstadoDesembolsos.clear();
		vPlanpagosConsol.clear();
	}

	public void seleccionarItem(PrePrestamos prestamos) {
		try {
			log.info("Prestamos seleccionado " + prestamos.getPrePrestamosPK().getPreCodcred());
			onDevengar = false;
			limpiar();
			itemActual = prePrestamosBLLocal.prestamoById(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
		}
	}

	public void devengarCredito(PrePrestamos prestamos) {
		try {
			onDevengar = false;
			limpiar();
			prePrcconta = null;
			if (fechaDevengado == null) {
				fechaDevengado = new Date();
			}
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActual = prePrestamosBLLocal.prestamoById(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());

			log.info("inicio devengado CREDITO usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred() + " a fecha " + fechaDevengado.toString()
					+ " con PR? " + (prestamos.getPrcconta() != null));

			if (prestamos.getPrcconta() != null && prestamos.getPrcconta().getPrcCodprc() != null
					&& prestamos.getPrcconta().getPrcFecha2() != null) {
				List<PrePrcconta> prccontaPendList = prePrccontaBLLocal.devsGenerados(
						itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(), 1, prestamos.getPrcconta().getPrcFecha2());

				itemActual.setPrcconta(null);
				if (prccontaPendList.size() > 0) {
					itemActual.setPrcconta(prccontaPendList.get(0));
					prePrcconta = prccontaPendList.get(0);
				}
			}

			if (itemActual.getPrcconta() != null) {
				Integer tipoproc = 3; // proceso consulta
				listEstadoDesembolsos = recuperarVwResu(itemActual.getPrcconta().getPrcFecha2(),
						itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(), tipoproc);
				estadoDesembolsosTots = PreDesembBLLocalImpl.sumarConStreams(listEstadoDesembolsos);
				prePrcconta = itemActual.getPrcconta();
			} else {
				prePrcconta = prePrccontaBLLocal.buscarPorFechaDeven(itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(), fechaDevengado);

				Integer tipoproc = 2; // proceso devengamiento mensual
				listEstadoDesembolsos = recuperarVwResu(fechaDevengado, itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(), tipoproc);
				estadoDesembolsosTots = PreDesembBLLocalImpl.sumarConStreams(listEstadoDesembolsos);
				if (prePrcconta != null) {
					if (StringUtils.isBlank(prePrcconta.getPrcNroComprob())) {
						prePrcconta.setPrcEstado(1);
						prePrcconta.setPrcCodcmp(3);
						prePrcconta.setPrcCveTipoComprob(null);
						prePrcconta.setPrcMontodeven(estadoDesembolsosTots.getIntDevengado());
						prePrcconta.setPrcFecinideven(estadoDesembolsosTots.getAcrFecini());
						prePrcconta.setPrcFecha(new Date());
						prePrcconta.setPrcAuditusrgen(usuario.getLogin());
						prePrcconta.setPrcAuditfhogen(new Date());
						prePrcconta.setPrcAuditwstgen(UtilWeb.getIPRemoto());
					} else {

					}

				} else {
					crearActualizarPrcconta(estadoDesembolsosTots);
				}

				itemActual.setPrcconta(prePrcconta);
			}

			log.info("Devengado credito heccho {} monto {}", itemActual.getPrePrestamosPK().getPreCodcred(),
					estadoDesembolsosTots.getIntDevengado());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de devengados ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void btnIrADetalleComprob(PrePrcconta prcconta) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Recuperando renglones prcconta {} usr {}", prcconta.getId(), usuario.getLogin());

			itemActual = prePrestamosBLLocal.prestamoById(prcconta.getPrcCodcred(), prcconta.getPrcCodmod());
			prePrcconta = prePrccontaBLLocal.buscarPorId(prcconta.getPrcCodprc());
			listRenglones = recuperarRengsOper(prcconta);

			if (listRenglones.size() == 0) {
				if (prePrcconta.getPrcEstado().equals(Cttes.ESTOPER_AUTO)) {
					prePrccontaBLLocal.cambiarEstadoOperComprob(prePrcconta.getPrcCodcmp(), prePrcconta.getPrcCodprc(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(), null, prePrcconta.getPrcFecha2(), prePrcconta.getPrcEstado(), usuario.getLogin(), UtilWeb.getIPRemoto());			

					prePrcconta = prePrccontaBLLocal.buscarPorId(prcconta.getPrcCodprc());
					listRenglones = recuperarRengsOper(prePrcconta);
				}
			}
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void generarOperacionPrcConta() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("GEnerando prcconta {} usr {}", prePrcconta.getId(), usuario.getLogin());
			prePrcconta.setPrcAuditusrgen(usuario.getLogin());
			prePrcconta.setPrcAuditfhogen(new Timestamp(new Date().getTime()));
			prePrcconta.setPrcAuditwstgen(UtilWeb.getIPRemoto());
			prePrcconta.setPrcAuditusrgen(usuario.getLogin());
			prePrcconta.setPrcAuditfhogen(new Timestamp(new Date().getTime()));
			prePrcconta.setPrcAuditwstgen(UtilWeb.getIPRemoto());

			prePrcconta = prePrccontaBLLocal.guardarPrcconta(prePrcconta);

			prePagocuotaBLLocal.generarOperContCred( prePrcconta.getPrcCodcmp(), prePrcconta.getPrcCodprc(), prePrcconta.getPrcCodcred(),
					prePrcconta.getPrcCodmod(), null, prePrcconta.getPrcFecha2(), null, usuario.getLogin(),
					UtilWeb.getIPRemoto());
			prePrcconta = prePrccontaBLLocal.buscarPorId(prePrcconta.getPrcCodprc());
			listRenglones = recuperarRengsOper(prePrcconta);
			actPrestConDevsAFechaDev(prePrcconta.getPrcFecha2());			

			log.info("Operacion de devengado generada id {} cred {}", prePrcconta.getPrcCodprc(), prePrcconta.getPrcCodcred());			
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	private void crearActualizarPrcconta(EstadoDesembolsosQuery estadoD) {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

		prePrcconta = new PrePrcconta();
		prePrcconta.setPrcCodcred(itemActual.getId().getPreCodcred());
		prePrcconta.setPrcCodmod(itemActual.getId().getPreCodmod());
		prePrcconta.setPrcTabestado(1902);
		prePrcconta.setPrcNroCentro(1);
		prePrcconta.setPrcEstado(1);
		prePrcconta.setPrcCodcmp(3);
		prePrcconta.setPrcCveTipoComprob('G');
		prePrcconta.setPrcFecha2(estadoD.getFecha());
		prePrcconta.setPrcMontodeven(estadoD.getIntDevengado());
		prePrcconta.setPrcFecinideven(estadoD.getAcrFecini());
		prePrcconta.setPrcFecha(new Date());
		prePrcconta.setPrcAuditusrgen(usuario.getLogin());
		prePrcconta.setPrcAuditfhogen(new Date());
		prePrcconta.setPrcAuditwstgen(UtilWeb.getIPRemoto());

	}

	public void btnGuardarPrcconta() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Salvando prcconta {} usr {}", prePrcconta.getPrcCodprc(), usuario.getLogin());
			prePrcconta.setPrcAuditusrgen(usuario.getLogin());
			prePrcconta.setPrcAuditfhogen(new Timestamp(new Date().getTime()));
			prePrcconta.setPrcAuditwstgen(UtilWeb.getIPRemoto());
			prePrcconta.setPrcAuditusrgen(usuario.getLogin());
			prePrcconta.setPrcAuditfhogen(new Timestamp(new Date().getTime()));
			prePrcconta.setPrcAuditwstgen(UtilWeb.getIPRemoto());

			prePrcconta = prePrccontaBLLocal.guardarPrcconta(prePrcconta);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO,
							"Registro salvado",
							"Codigo: " + prePrcconta.getPrcCodprc()));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void btnCancelarPrcconta() {
		try {
			log.info("cancelando prcconta {}", prePrcconta.getPrcCodprc());

			prePrcconta = prePrccontaBLLocal.buscarPorId(prePrcconta.getPrcCodprc());

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Edición cancelada", "No se guardaron cambios"));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void btnGuardarGenparams(GenPrcparams genprcparams) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Salvando Genprcparams {} codgen {}", prePrcconta.getPrcCodprc(), genprcparams.getPrpCodtpr());
			GenPrcparams genprcp = genPrcparamsQLLocal.saveUpdateGenP(genprcparams);
			prePrcconta = prePrccontaBLLocal.buscarPorId(genprcparams.getPrpCodprc());
			listRenglones = recuperarRengsOper(prePrcconta);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO,
							"Registro salvado",
							"Código renglón: " + genprcp.getPrpCodprc()));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void btnCancelarGenparams(GenPrcparams genprcparams) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Cancelando Genprcparams {} codgen {}", prePrcconta.getPrcCodprc(), genprcparams.getPrpCodtpr());

			listRenglones = recuperarRengsOper(prePrcconta);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Edición cancelada", "No se guardaron cambios"));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void generarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio generarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			prePrcconta.setPrcAuditusrgen(usuario.getLogin());
			prePrcconta.setPrcAuditfhogen(new Date());
			prePrcconta.setPrcAuditwstgen(UtilWeb.getIPRemoto());

			prePrcconta = prePrccontaBLLocal.generarComprobanteDevengado(prePrcconta);
			PrePrcconta prePrccontanew = prePrccontaBLLocal.buscarPorId(prePrcconta.getPrcCodprc());
			log.info("prePrccontanew {} comprob {}", prePrccontanew.getPrcCodprc(), prePrccontanew.getPrcNroComprob());
			actPrestConDevsAFechaDev(prePrccontanew.getPrcFecha2());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de generación de comprobante COIN ejecutado correctamente, con nro Comprobante "
							+ prePrccontanew.getPrcNroComprob(),
					"");
			FacesContext.getCurrentInstance().addMessage(null, message);
			operacionExitosa = true;
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

			operacionExitosa = false;
		}
		return;
	}

	public void eliminarDevengado() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio eliminarDevengado usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			prePrccontaBLLocal.cambiarEstadoOperComprob(prePrcconta.getPrcCodcmp(), prePrcconta.getPrcCodprc(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(), null, new Date(), 5, usuario.getLogin(), UtilWeb.getIPRemoto());

			actPrestConDevsAFechaDev(fechaDevengado);

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"La cancelación del comprobante se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			operacionExitosa = true;
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

			operacionExitosa = false;
		}
		return;
	}

	public void rechazarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio rechazarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());
			prePrccontaBLLocal.cambiarEstadoOperComprob(prePrcconta.getPrcCodcmp(), prePrcconta.getPrcCodprc(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(), null, new Date(), 4, usuario.getLogin(), UtilWeb.getIPRemoto());

			actPrestConDevsAFechaDev(fechaDevengado);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"El rechazo del comprobante se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			operacionExitosa = true;
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

			operacionExitosa = false;
		}
		return;
	}

	public void preAutorizarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio preAutorizarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			prePrccontaBLLocal.cambiarEstadoOperComprob(prePrcconta.getPrcCodcmp(), prePrcconta.getPrcCodprc(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(), null, new Date(), 2, usuario.getLogin(), UtilWeb.getIPRemoto());

			prePrcconta = prePrccontaBLLocal.buscarPorId(prePrcconta.getPrcCodprc());

			actPrestConDevsAFechaDev(prePrcconta.getPrcFecha2());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"La preautorzacíón del comprobante se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			operacionExitosa = true;
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

			operacionExitosa = false;
		}
		return;
	}

	public void autorizarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio autorizarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			prePrccontaBLLocal.cambiarEstadoOperComprob(prePrcconta.getPrcCodcmp(), prePrcconta.getPrcCodprc(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(), null, new Date(), 3, usuario.getLogin(), UtilWeb.getIPRemoto());

			prePrcconta = prePrccontaBLLocal.buscarPorId(prePrcconta.getPrcCodprc());

			actPrestConDevsAFechaDev(prePrcconta.getPrcFecha2());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"La autorización se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			operacionExitosa = true;
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

			operacionExitosa = false;
		}
		return;
	}

	public void verDevengados(PrePrestamos prestamos) {
		try {
			fechaRecCoin = new Date();
			onDevengar = true;
			limpiar();
			// prePrcconta = null;
			itemActual = prePrestamosBLLocal.prestamoById(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());

			listaDevengados = prePrccontaBLLocal.devengadosContByCred(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	private List<ComprobanteDet>  recuperarRengsOper(PrePrcconta prcconta) {
		try {
			List<GenPrcparams> rengs = genPrcparamsQLLocal.findByCodPrcAndTipoProc(prcconta.getPrcCodprc(),
					prcconta.getPrcCodcmp());
			log.info("rengs comprog" + rengs.size());
			debeSuma = BigDecimal.ZERO;
			haberSuma = BigDecimal.ZERO;
			List<ComprobanteDet> listRengs = rengs.stream().map(p -> {
				ComprobanteDet cd = new ComprobanteDet();
				cd.setRenCodigo(p.getPrpNroreng());
				cd.setMovi(p.getPrpCtamov() + " - " + p.getPrpValue());
				cd.setDebe(BigDecimal.ZERO);
				cd.setHaber(BigDecimal.ZERO);

				if (p.getPrpDh() != null && p.getPrpDh().equals("D")) {
					cd.setDebe(p.getPrpMontomn());
				} else {
					cd.setHaber(p.getPrpMontomn());
				}
				debeSuma = debeSuma.add(cd.getDebe());
				haberSuma = haberSuma.add(cd.getHaber());
				cd.setRenGlosa(p.getPrpGlosa());
				cd.setNroCP(p.getPrpNrocp());
				cd.setGenPrcparams(p);
				return cd;
			}).collect(Collectors.toList());
		return listRengs;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public void inicioRegistroManual() {
		prePrcconta = new PrePrcconta();
		prePrcconta.setPrcCodcmp(3);
		prePrcconta.setPrcCodcred(itemActual.getId().getPreCodcred());
		prePrcconta.setPrcCodmod(itemActual.getId().getPreCodmod());
		prePrcconta.setPrcHora(new Timestamp(new Date().getTime()));
		prePrcconta.setPrcTabestado(1902);
		prePrcconta.setPrcEstado(Cttes.ESTOPER_ENREV);
		prePrcconta.setPrcNroCentro(1);
		prePrcconta.setPrcCveTipoComprob('G');

		operacionExitosa = false;
	}

	public void iniciarModificarDevengado(PrePrcconta prcconta) {
		prePrcconta = prePrccontaBLLocal.buscarPorId(prcconta.getPrcCodprc());
		operacionExitosa = false;
	}

	public void guardarDevengadoManual() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			if (prePrcconta.getPrcCodprc() != null) {
				PrePrcconta prcold = prePrccontaBLLocal.buscarPorId(prePrcconta.getPrcCodprc());				
				if (prcold == null)
					prePrcconta.setPrcCodprc(null);
			}
			prePrcconta.setPrcHora(new Timestamp(new Date().getTime()));
			prePrcconta.setPrcAuditusrgen(usuario.getLogin());
			prePrcconta.setPrcAuditfhogen(new Timestamp(new Date().getTime()));
			prePrcconta.setPrcAuditwstgen(UtilWeb.getIPRemoto());
			prePrcconta.setPrcEstado(Cttes.ESTOPER_PEND);
			log.info("en registro de devengado manual cred {} cmpb: {} ", prePrcconta.getPrcCodcred(),
					prePrcconta.getPrcNroComprob());

			prePrcconta = prePrccontaBLLocal.procesarDevengadoManual(prePrcconta, usuario.getLogin(),
					UtilWeb.getIPRemoto());

			listaDevengados = prePrccontaBLLocal.devengadosContByCred(prePrcconta.getPrcCodcred(),
					prePrcconta.getPrcCodmod());
			actPrestConDevsAFechaDev(fechaDevengado);

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente",
					"Comprobante: " + prePrcconta.getPrcNroComprob());

			FacesContext.getCurrentInstance().addMessage(null, message);
			operacionExitosa = true;
			log.info("registro de devengado manual hecho ..." + prePrcconta.getPrcCodprc());
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

			operacionExitosa = false;
		}
	}
	public void rechazarDevengadoManual(PrePrcconta prcconta) {
		try {
			log.info("Rechazando registro dev manual {}", prcconta.getPrcCodprc());
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			prcconta.setPrcHora(new Timestamp(new Date().getTime()));
			prcconta.setPrcAuditusrgen(usuario.getLogin());
			prcconta.setPrcAuditfhogen(new Timestamp(new Date().getTime()));
			prcconta.setPrcAuditwstgen(UtilWeb.getIPRemoto());

			prePrccontaBLLocal.cambiarEstadoOperComprob(prcconta.getPrcCodcmp(), prcconta.getPrcCodprc(),
					prcconta.getPrcCodcred(),
					prcconta.getPrcCodmod(), null, prcconta.getPrcFecha2(), Cttes.ESTOPER_RECHAZADO, usuario.getLogin(), UtilWeb.getIPRemoto());

			listaDevengados = prePrccontaBLLocal.devengadosContByCred(prcconta.getPrcCodcred(),
					prcconta.getPrcCodmod());
			actPrestConDevsAFechaDev(fechaDevengado);
			operacionExitosa = true;
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}	

	public void btnCancelarDevManual() {
		try {
			log.info("cancelando registro dev manual {}", prePrcconta.getPrcCodprc());

			listaDevengados = prePrccontaBLLocal.devengadosContByCred(prePrcconta.getPrcCodcred(),
					prePrcconta.getPrcCodmod());
			actPrestConDevsAFechaDev(fechaDevengado);
			operacionExitosa = true;
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}
	private List<EstadoDesembolsosQuery> recuperarVwResu(Date fecha, Integer codcred, Integer codmod,
			Integer tipoproc) {
		estadoDesembolsosTots = PreDesembBLLocalImpl.initEstDsb();
		if (fecha == null || codcred == null || codmod == null)
			return new ArrayList<>();
		log.info("Dev: En devengar y recuperar [{}] lista de estados a fecha {}", codcred, fecha);
		prePagocuotaBLLocal.generarDevengadosCredito(codcred, codmod, fecha, fecha, tipoproc);

		List<EstadoDesembolsosQuery> listEst = preDesembBLLocal.estadoDesembolsosAFecha(codcred, codmod, null, fecha);
		return listEst;
	}

	public void verPPConsolPP(PrePrestamos prestamos) {
		// pp de oficial
		try {
			limpiar();
			onDevengar = false;
			vPlanpagosConsol = prePlanpagosQLLocal.planConsolPorCodmodYCodcred(
					prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());

			vPlanpConsolTotals = PrePlanpagosQLLocalImpl.sumarConStreamsPpConsol(vPlanpagosConsol);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void actualizarListaDeven(ValueChangeEvent event) {
		Date nuevaFecha = (Date) event.getNewValue();
		actPrestConDevsAFechaDev(nuevaFecha);
	}

	// Método para p:ajax listener
	public void actualizarListaDeven(SelectEvent event) {
		Date fechaSeleccionada = (Date) event.getObject();
		// Lógica para actualizar la lista
		actPrestConDevsAFechaDev(fechaSeleccionada);
	}

	public void actualizarFechaDevManual(SelectEvent event) {
		Date fechaSeleccionada = (Date) event.getObject();
		// Lógica para actualizar la lista
		prePrcconta.setPrcFecha2(fechaSeleccionada);;
	}	
	private void actPrestConDevsAFechaContab(Date fecha) {
		if (fecha == null)
			return;
		fechaDevengado = fecha;
		for (PrePrestamos prePrestamo : listPrePrestamos) {
			List<PrePrcconta> prccontaPendList = prePrccontaBLLocal.devsGenerados(
					prePrestamo.getPrePrestamosPK().getPreCodcred(),
					prePrestamo.getPrePrestamosPK().getPreCodmod(), 2, fecha);

			prePrestamo.setPrcconta(null);
			if (prccontaPendList.size() > 0) {
				prePrestamo.setPrcconta(prccontaPendList.get(0));
			}
		}
	}

	public void actPrestConDevsAFechaDev(Date fecha) {
		if (fecha == null)
			return;
		fechaDevengado = fecha;
		for (PrePrestamos prePrestamo : listPrePrestamos) {
			List<PrePrcconta> prccontaPendList = prePrccontaBLLocal.devsGenerados(
					prePrestamo.getPrePrestamosPK().getPreCodcred(),
					prePrestamo.getPrePrestamosPK().getPreCodmod(), 1, fecha);

			prePrestamo.setPrcconta(null);
			if (prccontaPendList.size() > 0) {
				prePrestamo.setPrcconta(prccontaPendList.get(0));
			}
		}
	}

	public void buscarPorNroDePrestamo() {
		try {
			cliente = "";
			contrato = "";
			onDevengar = false;
			itemActual = null;
			limpiar();
			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);
			actPrestConDevsAFechaContab(new Date());
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void buscarPorNroDeContrato() {
		try {
			cliente = "";
			this.codigoPrestamo = 0;
			onDevengar = false;
			itemActual = null;
			limpiar();
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());

			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);
			actPrestConDevsAFechaContab(new Date());
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void buscarClientes() {
		try {
			clientesList = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void selectCliPersonaFromDialog(CliPersona product) {
		try {
			// cliPersona = product;
			onDevengar = false;
			this.codigoPrestamo = 0;
			itemActual = null;
			limpiar();
			cliente = cliPersona.getCliNombre();
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());

			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
			actPrestConDevsAFechaContab(new Date());
			clienteActivo = product;
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Beneficiario seleccionado",
					"Nombre:" + cliPersona.getCliNombre());
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public List<VPlanPagosConsolQuery> getvPlanpagosConsol() {
		return vPlanpagosConsol;
	}

	public void setvPlanpagosConsol(List<VPlanPagosConsolQuery> vPlanpagosConsol) {
		this.vPlanpagosConsol = vPlanpagosConsol;
	}

	public VPVPlanPagosDsbQuery getvPlanpDsbTotals() {
		return vPlanpDsbTotals;
	}

	public void setvPlanpDsbTotals(VPVPlanPagosDsbQuery vPlanpDsbTotals) {
		this.vPlanpDsbTotals = vPlanpDsbTotals;
	}

	public VPlanPagosConsolQuery getvPlanpConsolTotals() {
		return vPlanpConsolTotals;
	}

	public void setvPlanpConsolTotals(VPlanPagosConsolQuery vPlanpConsolTotals) {
		this.vPlanpConsolTotals = vPlanpConsolTotals;
	}

	public boolean tieneComprobante() {
		boolean conComprobante = prePrcconta != null && prePrcconta.getPrcCodprc() != null
				&& prePrcconta.getPrcCodprc().compareTo(0) > 0;
		conComprobante = conComprobante && prePrcconta.getPrcNroComprob() != null
				&& !prePrcconta.getPrcNroComprob().isBlank();
		conComprobante = conComprobante && prePrcconta.getPrcNroCentro() != null
				&& prePrcconta.getPrcNroCentro().compareTo(0) > 0;

		return conComprobante;
	}

	public boolean isConCmpb(PrePrcconta pagocuota) {
		boolean estHabil = pagocuota != null && pagocuota.getPrcEstado() != null && (pagocuota.getPrcEstado().equals(1)
				|| pagocuota.getPrcEstado().equals(2) || pagocuota.getPrcEstado().equals(3));
		return pagocuota != null && !StringUtils.isBlank(pagocuota.getPrcNroComprob()) && estHabil;
	}

	public String getFechaDevengadoFormateada() {
		if (fechaDevengado == null)
			return "";
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(fechaDevengado);
	}

	public boolean isEditando() {
		return editando;
	}

	/************************ */

	private void devengarTodosAFecha() {
		try {
			onDevengar = false;
			limpiar();
			Integer TIPO_DIARIO = 1;
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			List<PrePrestamos> prestList = prePrestamosBLLocal.prestamosVig(0);
			log.info("inicio devengarTodosAFecha usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " a fecha "
					+ fechaDevTodos.toString() + " nro: " + prestList.size());
			for (PrePrestamos prePrestamos : prestList) {
				long begin = System.currentTimeMillis();
				log.info("Inicio devengado {}", prePrestamos.getPrePrestamosPK().getPreCodcred());
				prePagocuotaBLLocal.devengarCredito(prePrestamos.getPrePrestamosPK().getPreCodcred(),
						prePrestamos.getPrePrestamosPK().getPreCodmod(), fechaDevTodos, fechaDevTodos, TIPO_DIARIO);
				log.info("Duracion devengar {} time (seconds): {}", prePrestamos.getPrePrestamosPK().getPreCodcred(),
						(System.currentTimeMillis() - begin) / 1000);
			}
			log.info("Proceso de devengados ejecutado correctamente");
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de devengados ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Throwable e) {
			log.error("Error en procesos devengados " + e.getStackTrace());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	private void recuperarDatosContbcb() {
		// en veremos no borrar recupera devengados de coin
		try {
			Integer tipoproc = 6; // devengados coin
			if (fechaRecCoin == null) {
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
						"Gestion a recuperar requerido");
				FacesContext.getCurrentInstance().addMessage(null, message);
				return;
			}
			prePagocuotaBLLocal.generarDevengadosCredito(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), fechaRecCoin, fechaRecCoin, tipoproc);

			listaDevengados = prePrccontaBLLocal.devengadosContByCred(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod());
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	private void verDistribucionDev(PrePrcconta prePrccontaIn) {
		// no borrar para explicar devengado
		try {
			onDevengar = false;
			vPlanpagosConsol.clear();
			prePrcconta = prePrccontaIn;
			listEstadoDesembolsos = recuperarVwResu(prePrccontaIn.getPrcFecha2(), prePrccontaIn.getPrcCodcred(),
					prePrccontaIn.getPrcCodmod(), 3);
			estadoDesembolsosTots = PreDesembBLLocalImpl.sumarConStreams(listEstadoDesembolsos);

		} catch (Exception e) {
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return;

	}

}
