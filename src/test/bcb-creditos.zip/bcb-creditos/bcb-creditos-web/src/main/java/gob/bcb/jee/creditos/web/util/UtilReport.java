package gob.bcb.jee.creditos.web.util;


/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.web.util
 * 08/10/2016 - 10:37 AM
 * Creado por aescobar
 */

import gob.bcb.jee.creditos.BL.VConexionParNegocioBLLocal;
import gob.bcb.jee.creditos.util.Log;
import net.sf.jasperreports.engine.*;

import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.oasis.JROdtExporter;
import net.sf.jasperreports.engine.util.JRLoader;

import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import javax.faces.context.FacesContext;
import javax.inject.Inject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.HashMap;


public class UtilReport {

    @Inject
    VConexionParNegocioBLLocal vConexionParNegocioBLLocal;

    public enum TipoArchivo{PDF, EXCEL, HTML, ODS}


    public StreamedContent generarReporte(HashMap parametrosReporte, String nombreReporte, String nombreReporteSalida, TipoArchivo tipoArchivo, Connection conexion) throws OperationException {
        StreamedContent archivoFinal = null;

        try {

            FacesContext context = FacesContext.getCurrentInstance();
            String pathReportes = context.getExternalContext().getRealPath("WEB-INF/reportes/proyectos");
            String pathJasper = pathReportes + File.separator + nombreReporte + ".jasper";
            String pathReporteGenerado = null;

            JasperReport reporteJasper = (JasperReport) JRLoader.loadObject(new File(pathJasper));
            parametrosReporte.put("BaseDir", new File (pathReportes + File.separator));
            JasperPrint jasperPrint= JasperFillManager.fillReport(reporteJasper, parametrosReporte, conexion);
            JRExporter tipoArchivoExportado = null;
            String extensionArchivo = "";
            File archivoGenerado = null;

            nombreReporteSalida = nombreReporteSalida.replace("/","-");
            nombreReporteSalida = nombreReporteSalida.replace("\\","-");

            switch (tipoArchivo) {
                case PDF:
                    tipoArchivoExportado = new JRPdfExporter();
                    extensionArchivo = "pdf";
                    break;             
                case EXCEL:
                    tipoArchivoExportado = new JRXlsExporter();
                    extensionArchivo = "xls";
                    break;
                case ODS:
                    tipoArchivoExportado = new JROdtExporter();
                    extensionArchivo = "ods";
                    break;
                default:
                    tipoArchivoExportado = new JRPdfExporter();
                    extensionArchivo = "pdf";
                    break;
            }
            pathReporteGenerado = pathReportes + File.separator + nombreReporteSalida + "." + extensionArchivo;
            archivoGenerado = new java.io.File(pathReporteGenerado);
            tipoArchivoExportado.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
            tipoArchivoExportado.setParameter(JRExporterParameter.OUTPUT_FILE, archivoGenerado);
            tipoArchivoExportado.exportReport();
            archivoGenerado.deleteOnExit();

            InputStream contenidoReporte = new FileInputStream(archivoGenerado);
          //  archivoFinal = new DefaultStreamedContent(contenidoReporte, "application/" + extensionArchivo, nombreReporteSalida + "." + extensionArchivo);
        } catch (JRException e) {
            throw new OperationException("No es posible generar el reporte" + e, e);
        } catch (FileNotFoundException e) {
            throw new OperationException("Error al generar el reporte.", e);
        }
        return archivoFinal;
    }

    public StreamedContent generarDataSourceReporte(HashMap parametrosReporte, String nombreReporte, String nombreReporteSalida, TipoArchivo tipoArchivo) throws OperationException {
        return generarDataSourceReporte(parametrosReporte, nombreReporte, nombreReporteSalida, tipoArchivo, null);
    }

    public StreamedContent generarDataSourceReporte(HashMap parametrosReporte, String nombreReporte, String nombreReporteSalida, TipoArchivo tipoArchivo, Connection conexion) throws OperationException {
        StreamedContent archivoFinal = null;
        FacesContext context = FacesContext.getCurrentInstance();
        String pathReportes = context.getExternalContext().getRealPath("WEB-INF/reportes/proyectos");
        String pathJasper = pathReportes + File.separator + nombreReporte + ".jasper";
        String pathReporteGenerado = null;

        parametrosReporte.put("BaseDir", new File (pathReportes + File.separator));

        JasperReport report = null;
        try {
            report = (JasperReport) JRLoader.loadObject(new File(pathJasper));
        } catch (JRException e) {
            Log.Info(e.getMessage());
        }
        try {
            JasperPrint jasperPrint = null;
            if(conexion != null){
                jasperPrint = JasperFillManager.fillReport(report, parametrosReporte, conexion);
            } else{
                jasperPrint = JasperFillManager.fillReport(report, parametrosReporte, new JREmptyDataSource());
            }

            JRExporter tipoArchivoExportado = null;
            String extensionArchivo = "";
            File archivoGenerado = null;

            switch (tipoArchivo) {
                case PDF:
                    tipoArchivoExportado = new JRPdfExporter();
                    extensionArchivo = "pdf";
                    break;               
                case EXCEL:
                    tipoArchivoExportado = new JRXlsExporter();
                    extensionArchivo = "xls";
                    break;
                case ODS:
                    tipoArchivoExportado = new JROdtExporter();
                    extensionArchivo = "ods";
                    break;
                default:
                    tipoArchivoExportado = new JRPdfExporter();
                    extensionArchivo = "pdf";
                    break;
            }
            pathReporteGenerado = pathReportes + File.separator + nombreReporteSalida + "." + extensionArchivo;
            archivoGenerado = new java.io.File(pathReporteGenerado);
            tipoArchivoExportado.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
            tipoArchivoExportado.setParameter(JRExporterParameter.OUTPUT_FILE, archivoGenerado);
            tipoArchivoExportado.exportReport();
            archivoGenerado.deleteOnExit();

            InputStream contenidoReporte = new FileInputStream(archivoGenerado);
          //  archivoFinal = new DefaultStreamedContent(contenidoReporte, "application/" + extensionArchivo, nombreReporteSalida + "." + extensionArchivo);
        } catch (JRException e) {
            throw new OperationException("No es posible generar el reporte", e);
        } catch (FileNotFoundException e) {
            throw new OperationException("Error al generar el reporte.", e);
        } catch (Exception e){
            throw new OperationException("No es posible generar el reporte", e);
        }

        return archivoFinal;
    }

    }
