package gob.bcb.jee.creditos.schedule;

import java.text.ParseException;
import java.util.Date;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.jobs.ee.ejb.EJB3InvokerJob;

import gob.bcb.jee.creditos.BL.DevengadoBLLocal;
import gob.bcb.jee.creditos.BL.DevengadoBLLocalImpl;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.util.UtilEJB;
import gob.bcb.jee.creditos.web.util.UtilJobs;

public class DevengadosJob extends EJB3InvokerJob implements Job {

    public final static String JOB_NAME = "DevengadosJob";

    DevengadoBLLocal devengadoBLLocal;

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        Log.Info("inicia devengados");
        try {
            devengadoBLLocal = getLook();
            Log.Info("Devengado automatico iniciado " + new Date());
            devengadoBLLocal.generarDevengadosTodos(1, new Date());
            Log.Info("Devengado finalizado correctamente");
        } catch (Throwable e) {
            Log.Error("Error en la ejecución del spl job EX " + e.getMessage());
            
        }
    }

    protected DevengadoBLLocal getLook() throws Exception {
        if (devengadoBLLocal == null) {
            devengadoBLLocal = (DevengadoBLLocal) UtilEJB.lookup(DevengadoBLLocalImpl.class);
        }
        return devengadoBLLocal;
    }

    public void programarJob(String nombre, String horaEjecucion) throws ParseException {
        try {
            Scheduler scheduler = new StdSchedulerFactory().getScheduler();
            UtilJobs.programarJobAtHourAndMinuteForDay(scheduler, nombre, this.getClass(), horaEjecucion);
        } catch (SchedulerException e) {
            Log.Error(e.getMessage());
        }
    }
}
