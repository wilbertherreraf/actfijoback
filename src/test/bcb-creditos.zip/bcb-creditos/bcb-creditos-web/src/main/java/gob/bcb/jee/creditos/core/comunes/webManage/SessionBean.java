/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-plantillaWebEE-web
 * gob.bcb.jee.creditos.plantillaWebEE.bean.SessionBean
 * 07/03/2016 - 08:30:00
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.core.comunes.webManage;

import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;


import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Clase utilizada para el control y manejo de la sesion en la aplicacion
 * 
 * @author ysalinas
 * 
 */
@SuppressWarnings("serial")
@ManagedBean(name = "sessionBean")
@Getter
@Setter
@SessionScoped
public class SessionBean implements Serializable
{

  public String mensajeExcepcion;

  public Usuario getUsuarioSesion()
  {
    return ((Usuario) UtilWeb
        .getVariableSession(CttesWeb.VariablesSesion.USUARIO));
  }

  public String getDateTimeServer()
  {
    ApplicationBean appBean = (ApplicationBean) FacesContext.getCurrentInstance().getExternalContext().getApplicationMap().get("applicationBean");
    SimpleDateFormat isoFormat = new SimpleDateFormat(appBean.getPatternDateTime());
    Date fecha = new Date();
    return isoFormat.format(fecha);
  }

  public String getDateTimeServerJS()
  {
    SimpleDateFormat isoFormat = new SimpleDateFormat("EEE dd MMM yyyy HH:mm:ss Z", Locale.US);
    Date fecha = new Date();
    return isoFormat.format(fecha);
  }
}
