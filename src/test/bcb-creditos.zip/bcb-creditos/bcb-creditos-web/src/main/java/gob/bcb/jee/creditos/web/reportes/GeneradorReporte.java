package gob.bcb.jee.creditos.web.reportes;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.Serializable;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.ServletContext;

import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

//import gob.bcb.jee.mvdb.negocioBL.VOperacionParNegocioBLLocal;
import gob.bcb.jee.creditos.BL.VConexionParNegocioBLLocal;
import gob.bcb.jee.creditos.util.Log;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.fill.JRFileVirtualizer;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.util.SimpleFileResolver;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;


/**
 * Objeto <code>ManagedBean</code> encargado de la generacion de reportes con <tt>Jasperreports</tt>.
 * @author rruiz
 *
 */
@SuppressWarnings("serial")
@ManagedBean(name = "generadorReporte")
//@SessionScoped
@ViewScoped
public class GeneradorReporte implements Serializable {
	
	/**
	 * Conexion a la base de datos, para envio como parametro, al reporte plantilla.
	 */
	@Inject
	private VConexionParNegocioBLLocal vConexionParNegocioBLLocal;



	

	/**
	 * Constructor por defecto para la inicializacion de variables basicas.
	 */
	public GeneradorReporte() {
		//
	}
	
	/**
	 * Metodo para la generacion de reporte, en un objeto <code>StreamedContent</code> (normalmente se usa con primefaces).
	 * @param reportePlantilla nombre del reporte plantilla utilizado para gegerar el reporte.
	 * @param parametros objeto <code>Map</code> de parametros para la consulta, donde puede ser null en caso de que la consulta no tenga parametros
	 * @param formato formato de reporte a generar, los cuales pueden ser: <tt>pdf/xlsx/docx</tt>, caso contrario el procedimiento retorna nulo.
	 * @param nombreArchivo nombre del archivo reporte.
	 * @return retorna un objeto de tipo <code>StreamedContent</code> correspondiente al reporte generado.
	 */
//	public StreamedContent obtenerStreamedContent(String reportePlantilla, Map<String, Object> parametros, String formato, String nombreArchivo) {
//		StreamedContent streamedContent = null;
//		if(formato!=null && ("pdf".equals(formato) || "xlsx".equals(formato) || "docx".equals(formato))) {
//			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
//			ByteArrayOutputStream baos = prvt_generarReporteByteArrayOutputStream(reportePlantilla, parametros, formato, nombreArchivo);
//			if(baos!=null) {
//				ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
//				if("pdf".equals(formato)) {
//					streamedContent = new DefaultStreamedContent(bais, "application/pdf", nombreArchivo + timeStamp + ".pdf");
//				} else if("xlsx".equals(formato)) {
//					streamedContent = new DefaultStreamedContent(bais, "application/xlsx", nombreArchivo + timeStamp + ".xlsx");
//				} else if("docx".equals(formato)) {
//					streamedContent = new DefaultStreamedContent(bais, "application/docx", nombreArchivo + timeStamp + ".docx");
//				}
//			}
//		}
//		return streamedContent;
//	}
	
	/**
	 * Metodo para la generacion de reporte, en un objeto <code>StreamedContent</code> (normalmente se usa con primefaces).
	 * @param reportePlantilla nombre del reporte plantilla utilizado para gegerar el reporte.
	 * @param parametros objeto <code>Map</code> de parametros para la consulta, donde puede ser null en caso de que la consulta no tenga parametros.
	 * @param formato formato de reporte a generar, los cuales pueden ser: <tt>pdf/xlsx/docx</tt>, caso contrario el procedimiento retorna nulo.
	 * @param nombreArchivo nombre del archivo reporte.

	 * @return retorna un objeto de tipo <code>StreamedContent</code> correspondiente al reporte generado.
	 */
	public StreamedContent obtenerStreamedContent(String reportePlantilla, Map<String, Object> parametros, String formato, String nombreArchivo) {
		StreamedContent streamedContent = null;
		if(formato!=null && ("pdf".equals(formato) || "xlsx".equals(formato) || "docx".equals(formato))) {
			Log.Info("Antes de reporte: " + reportePlantilla + " nombreArchivo: " + nombreArchivo + " parms: " +  (parametros != null ? parametros.toString() : ""));
			
			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
			ByteArrayOutputStream baos = prvt_generarReporteByteArrayOutputStream(reportePlantilla, parametros, formato, nombreArchivo);
			if(baos!=null) {
				ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
				if("pdf".equals(formato.toLowerCase())) {
					streamedContent = DefaultStreamedContent.builder().stream(() ->bais).contentType("application/pdf")
					.name(nombreArchivo + timeStamp + ".pdf")
					.build();
					//new DefaultStreamedContent(bais, "application/pdf", nombreArchivo + timeStamp + ".pdf");
					/*streamedContent = DefaultStreamedContent.
							builder().
							name(nombreArchivo + timeStamp + ".pdf").
							contentType("application/pdf").
							stream(()->FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream(bais)).
							build();*/
				
						//	new DefaultStreamedContent(bais, "application/pdf", nombreArchivo + timeStamp + ".pdf");
				} else if("xlsx".equals(formato) || "xls".equals(formato)) {
					streamedContent = DefaultStreamedContent.builder().stream(() ->bais).contentType("application/xlsx")
					.name(nombreArchivo + timeStamp + ".xlsx")
					.build();
					//streamedContent = new DefaultStreamedContent(bais, "application/xlsx", nombreArchivo + timeStamp + ".xlsx");
					//streamedContent = new DefaultStreamedContent(bais, "application/xlsx", nombreArchivo + timeStamp + ".xlsx");
				} else if("docx".equals(formato)) {
					//streamedContent = new DefaultStreamedContent(bais, "application/docx", nombreArchivo + timeStamp + ".docx");
				}
			}
		}
		return streamedContent;
	}
	
	/**
	 * Metodo para la generacion de reporte, en un objeto <tt>ByteArrayOutputStream</tt>.
	 * @param reportePlantilla Nombre del reporte que se abrira.
	 * @param parametros objeto <code>Map</code> de parametros para la consulta, donde puede ser null en caso de que la consulta no tenga parametros
	 * @param formato formato de reporte a generar, los cuales pueden ser: <tt>pdf/xlsx/docx</tt>, caso contrario el procedimiento retorna nulo.
	 * @param nombreArchivo nombre del archivo reporte.
	 * @return retorna uhn objeto de tipo <code>ByteArrayOutputStream</code>.
	 */
	public ByteArrayOutputStream obtenerByteArrayOutputStream(String reportePlantilla, Map<String, Object> parametros, String formato, String nombreArchivo) {
		ByteArrayOutputStream baos = prvt_generarReporteByteArrayOutputStream(reportePlantilla, parametros, formato, nombreArchivo);
		return baos;
	}
	
	/**
	 * Metodo privado para la generacion de reportes con la libreria de <tt>jasperreports</tt>.
	 * @param reportePlantilla Nombre del reporte que se abrira.
	 * @param parametros objeto <code>Map</code> de parametros para la consulta, donde puede ser null en caso de que la consulta no tenga parametros
	 * @param formato formato de reporte a generar, los cuales pueden ser: <tt>pdf/xlsx/docx</tt>, caso contrario el procedimiento retorna nulo.
	 * @param nombreArchivo nombre del archivo reporte.
	 * @return retorna uhn objeto de tipo <code>ByteArrayOutputStream</code>.
	 */
	private ByteArrayOutputStream prvt_generarReporteByteArrayOutputStream(String reportePlantilla, Map<String, Object> parametros, String formato, String nombreArchivo) {
		ByteArrayOutputStream baos = null;
		if(parametros==null) {
			parametros = new HashMap<String, Object>();
		}
		//byte vecBytes[] = null;
		FacesContext facesContext = FacesContext.getCurrentInstance();
		ServletContext servletContext = (ServletContext) facesContext.getExternalContext().getContext();
		//String imagen = servletContext.getRealPath("reportes").concat("/img/Logo-BCB-chico-gold.jpg");
		String imagen = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/resources/img/").concat(File.separator);
		String carpetaReporte = servletContext.getRealPath("WEB-INF").concat(File.separator)+("reportes").concat(File.separator)+("jasper").concat(File.separator);
		//TODO: Corregir path para que sea dinamico
		//carpetaReporte = "D:\\aescobar\\workspace\\BCBCreditos\\bcb-creditos-web\\src\\main\\webapp\\WEB-INF\\reportes\\proyectos\\";

		/*File reportsDir = new File(imagen);
		if (!reportsDir.exists()) {
			 try {
				 throw new FileNotFoundException(String.valueOf(reportsDir));
			 } catch (FileNotFoundException e) {
				 
			 }
		}*/
		try {
			Connection cnn = null;

			cnn = vConexionParNegocioBLLocal.obtenerConnectionCreditos();
			
			parametros.put("REPORT_FILE_RESOLVER", new SimpleFileResolver(new File(servletContext.getRealPath("/"))));
			parametros.put("REPORT_VIRTUALIZER", new JRFileVirtualizer(10));
			parametros.put("SUBREPORT_CONNECTION", cnn);
			parametros.put("IMAGE_DIR", imagen);
			parametros.put("URL_SUBREPORT", carpetaReporte);
			Log.Info("Imagen " + imagen);
			Log.Info("Subreporte " + carpetaReporte);

			//File file = new File(carpetaReporte + "/" + reportePlantilla + ".jasper");
			File file = new File(carpetaReporte + reportePlantilla + ".jasper");
			JasperReport jasperReport = (JasperReport) JRLoader.loadObject(file);			
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parametros, cnn);
			

			if("pdf".equals(formato)) {
				
				ByteArrayOutputStream baosAux = new ByteArrayOutputStream();
				JasperExportManager.exportReportToPdfStream(jasperPrint, baosAux);
				baos = baosAux;
				
				
			} else if("xlsx".equals(formato)) {
				ByteArrayOutputStream baosAux = new ByteArrayOutputStream();
				JRXlsxExporter xlsxExporter = new JRXlsxExporter();
				xlsxExporter.setExporterInput(new SimpleExporterInput(jasperPrint));
				xlsxExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(baosAux));

//				xlsxExporter.setParameter(JRXlsExporterParameter.IGNORE_PAGE_MARGINS, Boolean.TRUE);
//				xlsxExporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE);
//				xlsxExporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
//				xlsxExporter.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.FALSE);
//				xlsxExporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);
//				//xlsxExporter.setParameter(JExcelApiExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
//				//xlsxExporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
//				xlsxExporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
//				xlsxExporter.setParameter(JRExporterParameter.OUTPUT_STREAM, baosAux);
				
				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);// Set configuration as
				configuration.setIgnorePageMargins(true);
				configuration.setWhitePageBackground(false);
				configuration.setRemoveEmptySpaceBetweenRows(true);
				
				xlsxExporter.setConfiguration(configuration);		
				xlsxExporter.exportReport();
				baos = baosAux;
			} else if("docx".equals(formato)) {
				ByteArrayOutputStream baosAux = new ByteArrayOutputStream();
				JRDocxExporter docxExporter = new JRDocxExporter();
				docxExporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
				docxExporter.setParameter(JRExporterParameter.OUTPUT_STREAM, baosAux);
				docxExporter.exportReport();
				baos = baosAux;
			}
			cnn.close();
		} catch (Exception e) {
			Log.Error("ERROR: runReporte " + e.getMessage());
			throw new RuntimeException(e);
			
		}
		return baos;
	}
	
	
}
