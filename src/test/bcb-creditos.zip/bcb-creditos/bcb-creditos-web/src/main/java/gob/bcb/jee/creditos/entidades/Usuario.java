/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-plantillaWebEE-web
 * gob.bcb.jee.creditos.plantillaWebEE.common.Usuario
 * 07/03/2016 - 08:30:00
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import gob.bcb.jee.creditos.numeradores.CodRecurso;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase que adminsitra la informacion del usuario con ingreso al sistema
 *
 * @author ysalinas
 */
@SuppressWarnings("serial")
@Getter
@Setter
public class Usuario implements Serializable {
    private String login;
    private Integer usuarioId;
    private List<Rol> roles;

    public Usuario() {
    }

    public Usuario(String login, Integer usuarioId, List<Rol> roles) {
        this.login = login;
        this.usuarioId = usuarioId;
        this.roles = roles;
    }

    public Recurso getRecursoByCod(CodRecurso codRecurso) {
        for (Rol rol : roles) {
            for (Recurso recurso : rol.getRecursos()) {
                if (recurso.getCodRecurso().equals(codRecurso.getCodigoRecurso()))
                    return recurso;
            }
        }
        return null;
    }

    public List<Recurso> getRecursos() {
        List<Recurso> recursos = new ArrayList<Recurso>();
        for (Rol rol : roles) {
            for (Recurso recurso : rol.getRecursos()) {
                if (!recursos.contains(recurso)) {
                    recursos.add(recurso);
                }
            }
        }
        return recursos;
    }


    @Override
    public String toString() {
        return "Usuario{" +
                "login='" + login + '\'' +
                ", roles=" + roles +
                '}';
    }
}
