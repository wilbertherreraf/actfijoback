package gob.bcb.jee.creditos.core.comunes.webManage;

import java.util.Enumeration;
import java.util.MissingResourceException;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpSession;

//import org.primefaces.context.RequestContext;

/**
 * Clase que permite el limpiar el cache de los objeto que fueron cargados a
 * session
 * 
 * @author ysalinas
 * 
 */
public class UtilesLocales {

	/**
	 * Metodo que realiza la limpieza de ManagedBean que fueron creados del tipo
	 * Session que llevan el sufijo Bean
	 * 
	 * @param session
	 */
	public static void limpiarCache(HttpSession session) {

		if (session != null) {

			Enumeration<String> e = session.getAttributeNames();

			String objeto = "";

			while (e.hasMoreElements()) {
				objeto = e.nextElement();
				if (objeto != null && objeto.contains("Bean")) {
					session.removeAttribute(objeto);
				}

			}

		}

	}

	/**
	 * Funcion que Crea un Mensaje del lado del cliente que sera mostrado en un
	 * componente Growl o Messages
	 * 
	 * @author flinares
	 * @param String strMsg
	 * @param String srtTitle
	 * @param boolean sinErrores
	 */
	public static void CrearMsgWARN(String strMsg, String srtTitle,
			boolean sinErrores) {
		FacesMessage message = null;
		message = new FacesMessage(FacesMessage.SEVERITY_WARN, srtTitle, strMsg);
		FacesContext.getCurrentInstance().addMessage(null, message);
		CrearVariableJavascript("sinErrores", sinErrores);
	}
	
	/**
	 * Crea un mensaje del lado del cliente que sera mostrado en un
	 * componente Growl o Messages
	 * 
	 * @author lcoaquira
	 * @param String strMsg
	 * @param String strSeveridad (INFO, WARN, ERROR, FATAL)
	 * @param String srtTitle
	 * @param boolean sinErrores
	 */
	public static void CrearMsgAplicacion(String strSeveridad, String srtTitle, String strMsg, 
			boolean sinErrores) {
		FacesMessage message = null;
		
		if (strSeveridad.equals("INFO")) {
			message = new FacesMessage(FacesMessage.SEVERITY_INFO, srtTitle, strMsg);
		} else if (strSeveridad.equals("WARN")) {
			message = new FacesMessage(FacesMessage.SEVERITY_WARN, srtTitle, strMsg);
		} else if (strSeveridad.equals("ERROR")){
			message = new FacesMessage(FacesMessage.SEVERITY_ERROR, srtTitle, strMsg);
		} else if (strSeveridad.equals("FATAL")){
			message = new FacesMessage(FacesMessage.SEVERITY_FATAL, srtTitle, strMsg);
		}
		
		FacesContext.getCurrentInstance().addMessage(null, message);
		CrearVariableJavascript("sinErrores", sinErrores);
	}

	/**
	 * Funcion que Crea una Variable javascript para el lado del cliente
	 * 
	 * @author flinares
	 * 
	 * @param String
	 *            nomVariable
	 * @param Object
	 *            Valor
	 */
	public static void CrearVariableJavascript(String nomVariable, Object Valor) {
		//RequestContext context = RequestContext.getCurrentInstance();
	//	context.addCallbackParam(nomVariable, Valor);
	}

	/**
	 * Metodo que realiza la obtencion de una parametro del archivo
	 * resources.properties
	 * 
	 * @param keyParametro
	 * @return
	 */
	public static String obtenerParametro(String keyParametro) {
		String valorParametro = "";

		try {

			FacesContext facesContext = FacesContext.getCurrentInstance();

			// recupernado parametro de resources
			ResourceBundle bundle = facesContext.getApplication()
					.getResourceBundle(facesContext, "msgs");

			// verificadno si el sistema se logeara usando captcha
			if (bundle != null && bundle.getString(keyParametro) != null) {
				valorParametro = bundle.getString(keyParametro);
			}

		} catch (Exception e) {
			
		}

		return valorParametro;
	}

	@SuppressWarnings("unchecked")
	public static <Ejb> Ejb consumirEJBSeguridad(Class<Ejb> ejbRemoto) {
		try {
			Properties props = new Properties();
			props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
			InitialContext ctx = new InitialContext(props);
			String appName = "bcb-seguridad-ear";
			String moduleName = "bcb-seguridad-ejb-1.0-SNAPSHOT";
			String distinctName = "";
			String beanName = ejbRemoto.getSimpleName().substring(0,
					ejbRemoto.getSimpleName().length() - 6);
			String remoteBeanName = ejbRemoto.getName();
			String jndi = "ejb:" + appName + "/" + moduleName + "/"
					+ distinctName + "/" + beanName + "!" + remoteBeanName;
			Ejb ejb = (Ejb) ctx.lookup(jndi);
			return ejb;
		} catch (Exception e) {
			
		}
		return null;
	}

	public static String getNombreSistema() {
		try {
			return getResourceBundle().getString("nombre_aplicacion");
		} catch (MissingResourceException e) {
			return "";
		}
	}

	private static ResourceBundle getResourceBundle() {
		return ResourceBundle.getBundle("resources");
	}

}
