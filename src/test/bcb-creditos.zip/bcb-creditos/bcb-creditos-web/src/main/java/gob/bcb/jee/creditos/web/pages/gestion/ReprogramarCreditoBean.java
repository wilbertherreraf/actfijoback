package gob.bcb.jee.creditos.web.pages.gestion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Inject;

import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.jee.creditos.BL.AuxPlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenModuloBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocal;
import gob.bcb.jee.creditos.BL.PrePagocuotaBLLocal;
import gob.bcb.jee.creditos.BL.PrePlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreReprogramaBLLocal;
import gob.bcb.jee.creditos.BL.PreTasaspreBLLocal;
import gob.bcb.jee.creditos.QL.AuxPlanpagosQLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocalImpl;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.entidades.VPVPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.VPVPlanPagosDsbQuery;
import gob.bcb.jee.creditos.entidades.VPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.VPlanPagosDsbQuery;
import gob.bcb.jee.creditos.model.AuxPlanpagos;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenModulo;
import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PrePrestamosPK;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.model.PreTasaspre;
import gob.bcb.jee.creditos.model.PreTasasprePK;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "ReprogramarCreditoBean")
@ViewScoped
@Getter
@Setter
public class ReprogramarCreditoBean implements Serializable {
	private static final Logger log = LoggerFactory.getLogger(DesembolsoCreditoBean.class);
	private static final long serialVersionUID = 1L;

	@Inject
	private GenTipProductoBLLocal genTipProductoBLLocal;

	@Inject
	private GenDesctablaBLLocal genDesctablaBLLocal;

	@Inject
	private GenMonedaBLLocal genMonedaBLLocal;

	@Inject
	private PrePrestamosBLLocal prePrestamosBLLocal;

	@Inject
	private CliPersonaBLLocal service;

	@Inject
	private PreTasaspreBLLocal preTasaspreBLLocal;

	@Inject
	private PreDesembBLLocal preDesembBLLocal;
	@Inject
	private PrePlanpagosBLLocal prePlanpagosLocal;
	@Inject
	private AuxPlanpagosQLLocal auxPlanpagosQLLocal;
	@Inject
	private PreReprogramaBLLocal preReprogramaBLLocal;

	@Inject
	private AuxPlanpagosBLLocal auxPlanpagosLocal;
	@Inject
	private PrePlanpagosQLLocal prePlanpagosQLLocal;
	@Inject
	private PrePagocuotaBLLocal prePagocuotaBLLocal;
	private List<CliPersona> products;
	private Integer dsbCodsbSelected = null;
	private List<PreDesemb> desembolsos = new ArrayList<>();
	private List<PreTasaspre> listPreTasaspre;
	private List<VPlanPagosConsolQuery> vPlanpagosConsol = new ArrayList<>();
	private VPlanPagosConsolQuery vPlanpConsolTotals = new VPlanPagosConsolQuery();
	private List<VPlanPagosDsbQuery> vpPlanpagosDsb = new ArrayList<>();

	private VPlanPagosDsbQuery vPlanpDsbTotals = new VPlanPagosDsbQuery();

	private PrePrestamos itemActual = new PrePrestamos();

	private PreReprograma preReprograma = new PreReprograma();
	private List<PreReprograma> listPreReprograma;
	private PreTasaspre preTasaspre = new PreTasaspre();

	private List<PrePrestamos> listPrePrestamos;
	private CliPersona cliPersona = new CliPersona();
	private String cliente;
	private String igenTipproducto;

	private List<GenModulo> listGenModulo;
	private Integer igenGenMoneda;

	private Integer igenGenModulo;
	private Integer codigoPrestamo;
	private String contrato;
	// Totales para sumatorias
	private List<SelectItem> fechasCapitalItems; // en lugar de List<Date>

	private List<GenDesctabla> listGenDesctablaPlazo;
	private List<Date> calendarioVctos = new ArrayList<>();
	private boolean preliminar = false;

	public ReprogramarCreditoBean() {
	}

	@PostConstruct
	public void init() {
		try {
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
			iniciarTiposPlz();
			preTasaspre = new PreTasaspre();
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	private void iniciarTiposPlz() {
		try {
			Map<String, Object> valores0 = new HashMap<>();
			valores0.put("valor1", 1703);
			listGenDesctablaPlazo = genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores0);
			listGenDesctablaPlazo = listGenDesctablaPlazo.stream()
					.sorted((x, y) -> x.getDesDescrip().compareTo(y.getDesDescrip())).collect(Collectors.toList());
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void btnIniciarDlgPP(PrePrestamos prestamos) {
		try {
			Integer C_TIPOREPRO_TEMPO = 5;
			itemActual = prePrestamosBLLocal.prestamoById(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());
			initPP();
			preReprograma.setRdsCodcred(itemActual.getPrePrestamosPK().getPreCodcred());
			preReprograma.setRdsCodmod(itemActual.getPrePrestamosPK().getPreCodmod());
			preReprograma.setRdsTiporepro(C_TIPOREPRO_TEMPO);

			iniciarDatosDlgPP(prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							"Error al generar el plan: " + e.getMessage()));
			vPlanpagosConsol.clear();
		}
	}

	public void generarPlan() {
		try {
			// Validaciones de fechas
			Integer C_TIPOREPRO_REPRO = 1;
			log.info("en generar plan " + preReprograma.getRdsFecini());
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			preReprograma.setRdsAuditusr(usuario.getLogin());
			preReprograma.setRdsAuditfho(new Date());
			preReprograma.setRdsAuditwst(UtilWeb.getIPRemoto());
			preReprograma.setRdsTiporepro(C_TIPOREPRO_REPRO);
			Integer tipoproc = 3; // reporte
			
			prePagocuotaBLLocal.generarDevengadosCredito(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod(),
					preReprograma.getRdsFecinidif(), preReprograma.getRdsFecinidif(), tipoproc);

			preReprograma = prePlanpagosLocal.genCalendarioGetVencimientos(preReprograma, preReprograma.getRdsTiporepro(),
					usuario.getLogin(), UtilWeb.getIPRemoto());

			recuperarPlanPagosPPOPV(itemActual, null, true);
			List<Date> fechas = vPlanpagosConsol.stream().map(v -> v.getFechavencuo()).collect(Collectors.toList());
			actualizarFechasCapital(fechas);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Plan generado correctamente."));

		} catch (Exception e) {
			log.error("Error en gen plan: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							"Error al generar el plan: " + e.getMessage()));
		}
	}

	public void eliminarReprogramacion(PreReprograma preReprogramaaux) {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {
			Log.Info("Reprogramacion a eliminar: " + preReprogramaaux.getId());
			prePrestamosBLLocal.procesarReprogramacion(9, preReprogramaaux.getId(), new Date(), usuario.getLogin(),
					UtilWeb.getIPRemoto());
			iniciarVerReprogramacion(preReprogramaaux.getRdsCodcred(), preReprogramaaux.getRdsCodmod());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Reprogramación rechazada",
					"Satisfactorio");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void guardarReprogramacion() {
		try {
			log.info("guardando repro " + preReprograma.getRdsCodrepro());
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

			prePrestamosBLLocal.procesarReprogramacion(1, preReprograma.getId(), new Date(), usuario.getLogin(),
					UtilWeb.getIPRemoto());
			preReprograma = preReprogramaBLLocal.get(preReprograma.getId());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información",
					"Reprogramación creada satisfactoriamente");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void iniciarVerReprogramacion(Integer codcred, Integer codmod) {
		try {
			itemActual = prePrestamosBLLocal.prestamoById(codcred, codmod);
			listPreReprograma = preReprogramaBLLocal.reprosByCred(codcred, codmod, 1);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void preAutorizar() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			preReprograma.setRdsTrxstaau(2);
			preReprograma.setRdsAuditusr(usuario.getLogin());
			preReprograma.setRdsAuditfho(new Date());
			preReprograma.setRdsAuditwst(UtilWeb.getIPRemoto());

			prePrestamosBLLocal.procesarReprogramacion(2, preReprograma.getId(), new Date(), usuario.getLogin(),
					UtilWeb.getIPRemoto());
			preReprograma = preReprogramaBLLocal.get(preReprograma.getId());
			iniciarVerReprogramacion(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información",
					"Preautorizado satisfactoriamente");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			//
		}
	}

	public void btnVerReproPlanDePagos(PreReprograma repro) {
		try {
			if (repro.getRdsCodrepro() != null) {
				preReprograma = preReprogramaBLLocal.findByCodRepro(repro.getRdsCodrepro());
				iniciarDatosDlgPP(repro.getRdsCodcred(), repro.getRdsCodmod());					
			} else {
				btnIniciarDlgPP(itemActual);
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							"Error al generar el plan: " + e.getMessage()));
		}
	}

	public void Autorizar() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			preReprograma.setRdsTrxstaau(3);
			preReprograma.setRdsAuditusr(usuario.getLogin());
			preReprograma.setRdsAuditfho(new Date());
			preReprograma.setRdsAuditwst(UtilWeb.getIPRemoto());

			preTasaspre.setId(new PreTasasprePK(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod(),
					preReprograma.getRdsFeciniint()));
			preTasaspre.setMtpTbase(preReprograma.getRdsTasa());
			preTasaspre.setMtpTspread(0.0);
			preTasaspre.setMtpTabintmdias(20);
			preTasaspre.setMtpIntmdias(1);
			preTasaspre.setMtpTabintydias(21);
			preTasaspre.setMtpTabtrxstaau(30);
			preTasaspre.setMtpTrxstaau(1);
			preTasaspre.setMtpIntydias(preTasaspreBLLocal
					.obtenerUltimaTasa(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod()).getMtpIntydias());
			preTasaspre.setMtpAuditusr(usuario.getLogin());
			preTasaspre.setMtpAuditwst(UtilWeb.getIPRemoto());
			preTasaspre.setMtpAuditfho(new Timestamp(new Date().getTime()));
			// preTasaspreBLLocal.persist(preTasaspre,usuario.getLogin()); ya no es
			// necesario
			prePrestamosBLLocal.procesarReprogramacion(3, preReprograma.getId(), new Date(), usuario.getLogin(),
					UtilWeb.getIPRemoto());
			preReprograma = preReprogramaBLLocal.get(preReprograma.getId());
			iniciarVerReprogramacion(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información",
					"Autorizado satisfactoriamente");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	private boolean mostrarDiasIregular = true;

	public void seleccionarPlazoCapital(SelectEvent id_mod) {
		int id = Integer.parseInt(id_mod.getObject().toString());
		if (id == 1)
			this.mostrarDiasIregular = false;
		else
			this.mostrarDiasIregular = true;

	}

	public void limpiar() {
		cliPersona = new CliPersona();
		cliente = "";
	}

	public void initPP() {
		preReprograma = new PreReprograma();
		preReprograma.setRdsFeculttrx(itemActual.getPreFeculttrx()); // hoy
		// Para el ejemplo, ponemos fechas coherentes
		Date hoy = new Date();
		preReprograma.setRdsFecinidif(hoy);
		preReprograma.setRdsFeciniint(itemActual.getPreFecemi());
		preReprograma.setRdsFecini(itemActual.getPreFecemi());
		preReprograma.setRdsTasa(itemActual.getPreTasapac());
		preReprograma.setRdsUnidplaz(itemActual.getPreUnidplaz()); // mensual
		preReprograma.setRdsNroperiodos(itemActual.getPreNroperiodos());
		preReprograma.setRdsSaldo(itemActual.getPreSaldo());
		preReprograma.setRdsTrxstaau(1);
		preliminar = false;
		fechasCapitalItems = new ArrayList<>();

	}

	private void iniciarDatosDlgPP(Integer codcred, Integer codmod) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer C_TIPOREPRO_TEMPO = 5;

			dsbCodsbSelected = null;
			recuperarPlanPagosPPOPV(itemActual, dsbCodsbSelected, false);

			if (vPlanpagosConsol.size() == 0) {
				prePlanpagosLocal.genCalendarioGetVencimientos(preReprograma, C_TIPOREPRO_TEMPO,
						usuario.getLogin(),
						UtilWeb.getIPRemoto());
				recuperarPlanPagosPPOPV(itemActual, dsbCodsbSelected, true);
			}

			desembolsos = preDesembBLLocal.dsbByCodCred(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod());

			if (vPlanpagosConsol.size() > 0) {
				preReprograma.setRdsFecini(vPlanpagosConsol.get(vPlanpagosConsol.size() - 1).getFechavencuo());
				preReprograma.setRdsFeciniint(vPlanpagosConsol.get(vPlanpagosConsol.size() - 1).getFechavencuo());
			}
			List<Date> fechas = vPlanpagosConsol.stream().map(v -> {
				if (v.getAmortizacion().compareTo(BigDecimal.ZERO) > 0
						&& preReprograma.getRdsFecini().after(v.getFechavencuo())) {
					preReprograma.setRdsFecini(v.getFechavencuo());
				}
				if (v.getInteres().compareTo(BigDecimal.ZERO) > 0
						&& preReprograma.getRdsFeciniint().after(v.getFechavencuo())) {
					preReprograma.setRdsFeciniint(v.getFechavencuo());
				}
				return v.getFechavencuo();
			}).collect(Collectors.toList());

			actualizarFechasCapital(fechas);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Cierra el diálogo
	 */
	public void cerrarDialogo() {

	}

	/**
	 * Actualiza la lista de fechas disponibles para el combo de capital
	 * en función de rdsFeciniint y rdsNroperiodos.
	 */
	private void actualizarFechasCapital(List<Date> fechas) {
		try {
			// List<Date> fechas =
			// prePlanpagosLocal.generarFechasVencimiento(preReprograma.getRdsCodcred(),preReprograma.getRdsCodmod());
			calendarioVctos = new ArrayList<>();
			fechas.forEach(l -> {
				Calendar cal = Calendar.getInstance();
				cal.setTime(l);
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
				calendarioVctos.add(cal.getTime());
			});
			if (preReprograma.getRdsFecini() == null) {
				preReprograma.setRdsFecini(preReprograma.getRdsFeciniint());
			}
			fechasCapitalItems = new ArrayList<>();
			int posK = 0;
			int posI = 0;
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			int i = -1;
			for (Date d : calendarioVctos) {
				i++;
				fechasCapitalItems.add(new SelectItem(d, sdf.format(d)));
				if (d.compareTo(preReprograma.getRdsFeciniint()) == 0) {
					posI = i;
				}
				if (d.compareTo(preReprograma.getRdsFecini()) == 0) {
					posK = i;
				}
			}

			// Seleccionar al interes
			if (!calendarioVctos.isEmpty() && !calendarioVctos.contains(preReprograma.getRdsFecini())) {
				if (posI > 0)
					preReprograma.setRdsFecini(calendarioVctos.get(posI));
				else
					preReprograma.setRdsFecini(calendarioVctos.get(0));
			}
		} catch (Exception e) {
			fechasCapitalItems = new ArrayList<>();
		}
	}


	/**
	 * Genera el plan de pagos llamando al servicio y actualiza sumatorias
	 */
	public void generarPlanModListCap() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			// Validaciones de fechas
			vPlanpagosConsol.clear();
			prePlanpagosLocal.genCalendarioGetVencimientos(preReprograma, 12,
					usuario.getLogin(), UtilWeb.getIPRemoto());

			List<Date> fechasVto = prePlanpagosLocal.generarFechasVencimiento(preReprograma.getRdsCodcred(),
					preReprograma.getRdsCodmod());

			List<AuxPlanpagos> planp = auxPlanpagosQLLocal.obtCalendarioPP(preReprograma.getRdsCodcred(),
					preReprograma.getRdsCodmod());
			planp.forEach(p -> {
				VPlanPagosConsolQuery resultado = PrePlanpagosQLLocalImpl.initPPConsol();
				resultado.setFechavencuo(p.getAcuFecvencuo());
				vPlanpagosConsol.add(resultado);
			});

			vPlanpConsolTotals = PrePlanpagosQLLocalImpl.sumarConStreamsPpConsol(vPlanpagosConsol);
			actualizarFechasCapital(fechasVto);

		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							"Error al generar el plan: " + e.getMessage()));
		}
	}

	public void btnVerPPPVDesembolso(SelectEvent event) {
		try {
			Integer coddsb = null;
			if (event.getObject() != null)
				coddsb = (Integer) event.getObject();
			log.info("Seelc " + coddsb);

			recuperarPlanPagosPPOPV(itemActual, coddsb, preliminar);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error: " + e.getMessage()));
		}
	}

	private void recuperarPlanPagosPPOPV(PrePrestamos prestamos, Integer coddsb, boolean prelim) {
		vpPlanpagosDsb.clear();
		vPlanpagosConsol.clear();
		vPlanpDsbTotals = PrePlanpagosQLLocalImpl.initVPPDsb();
		vPlanpConsolTotals = PrePlanpagosQLLocalImpl.initPPConsol();
		preliminar = prelim;
		dsbCodsbSelected = coddsb;
		if (coddsb == null) {
			if (prelim) {
				vPlanpagosConsol = prePlanpagosQLLocal.planpagosPPOPV(prestamos.getPrePrestamosPK().getPreCodcred(),
						prestamos.getPrePrestamosPK().getPreCodmod());

			} else {
				vPlanpagosConsol = prePlanpagosQLLocal.planConsolPorCodmodYCodcred(
						prestamos.getPrePrestamosPK().getPreCodcred(),
						prestamos.getPrePrestamosPK().getPreCodmod());
			}
			vPlanpConsolTotals = PrePlanpagosQLLocalImpl.sumarConStreamsPpConsol(vPlanpagosConsol);
		} else {
			if (prelim) {
				vpPlanpagosDsb = prePlanpagosQLLocal.planDsbPorCodmodYCodcredPV(
						prestamos.getPrePrestamosPK().getPreCodcred(),
						prestamos.getPrePrestamosPK().getPreCodmod(), coddsb);
			} else {
				vpPlanpagosDsb = prePlanpagosQLLocal.planDsbPorCodmodYCodcred(
						prestamos.getPrePrestamosPK().getPreCodcred(),
						prestamos.getPrePrestamosPK().getPreCodmod(), coddsb);
			}
			vPlanpDsbTotals = PrePlanpagosQLLocalImpl.sumarConStreams(vpPlanpagosDsb);
		}
		log.info("Plan recup dsb: " + dsbCodsbSelected + " prelim " + preliminar + " conunt: " + vpPlanpagosDsb.size()
				+ " " + vPlanpagosConsol.size());
	}

	public void selectCliPersonaFromDialog(CliPersona product) {
		try {
			// cliPersona = product;
			cliente = cliPersona.getCliNombre();
			contrato = "";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarClientes() {
		try {

			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDeContrato() {
		try {
			cliente = "";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDePrestamo() {
		try {
			// String []valoresTipoProducto=igenTipproducto.split("-");
			// igenGenModulo= Integer.parseInt(valoresTipoProducto[0].trim());
			cliente = "";
			contrato = "";
			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			// valores.put("pre_codmod", igenGenModulo);
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	// Getters y setters
	public PreReprograma getPreReprograma() {
		return preReprograma;
	}

	public void setPreReprograma(PreReprograma preReprograma) {
		this.preReprograma = preReprograma;
	}

	public boolean isValidRepro() {
		boolean isVal = preReprograma != null && preReprograma.getRdsFecini() != null;
		if (!isVal)
			return false;
		isVal = !calendarioVctos.isEmpty() && !calendarioVctos.contains(preReprograma.getRdsFecini());

		return isVal;
	}

	public VPlanPagosConsolQuery getvPlanpConsolTotals() {
		return vPlanpConsolTotals;
	}

	public void setvPlanpConsolTotals(VPlanPagosConsolQuery vPlanpConsolTotals) {
		this.vPlanpConsolTotals = vPlanpConsolTotals;
	}

	public List<VPlanPagosConsolQuery> getvPlanpagosConsol() {
		return vPlanpagosConsol;
	}

	public void setvPlanpagosConsol(List<VPlanPagosConsolQuery> vPlanpagosConsol) {
		this.vPlanpagosConsol = vPlanpagosConsol;
	}

	public VPlanPagosDsbQuery getvPlanpDsbTotals() {
		return vPlanpDsbTotals;
	}

	public void setvPlanpDsbTotals(VPlanPagosDsbQuery vPlanpDsbTotals) {
		this.vPlanpDsbTotals = vPlanpDsbTotals;
	}

	public boolean isPreliminar() {
		return preliminar;
	}
}
