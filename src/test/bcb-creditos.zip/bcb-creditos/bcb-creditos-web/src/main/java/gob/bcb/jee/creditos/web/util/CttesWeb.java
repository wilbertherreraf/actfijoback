package gob.bcb.jee.creditos.web.util;

/**
 * Clase encargada de proveer datos constantes para la aplicacion
 * 
 * @author ysalinas
 */
public class CttesWeb
{

  public enum VariablesSesion
  {
    USUARIO,
    ITEM_SELECTED,
    PROYECTO_SELECTED,
    DESEMBOLSO_SELECTED,
    ACTION_TYPE,
    GARANTIAS
  }

  public static void init(String urlIndex)
  {
    URL_INDEX = urlIndex;
    URL_ERROR_LOGIN = URL_INDEX + "/errorPages/errorLogin.jsf";
    URL_ERROR_LOGIN_APLICACION = URL_INDEX + "/errorPages/errorLoginAplicacion.jsf";
    URL_ERROR_LOGIN_BLOQUEADO = URL_INDEX + "/errorPages/errorLoginBloqueado.jsf";
    URL_CAMBIAR_CONTRASENIA = URL_INDEX + "/seguridad/cambioPassword.jsf";
    URL_ERROR_EXCEPCION_FATAL = URL_INDEX + "/errorPages/errorExcepcionFatal.jsf";
    URL_ERROR_NO_AUTORIZADO = URL_INDEX + "/errorPages/error403.jsf";

    //URL´s SISTEMA
    URL_REGISTRO_DESEMBOLSO = URL_INDEX + "/pages/proyectos/registroDesembolso.jsf";
    URL_REGISTRO_PROYECTO = URL_INDEX + "/pages/proyectos/registroProyecto.jsf";
    URL_LISTADO_DESEMBOLSOS  = URL_INDEX + "/pages/proyectos/listadoDesembolsos.jsf";
    URL_LISTADO_PROYECTOS  = URL_INDEX + "/pages/proyectos/listadoProyectos.jsf";
    URL_LISTADO_DEVENGADOS  = URL_INDEX + "/pages/proyectos/listadoDevengados.jsf";
    URL_LISTADO_PAGOS = URL_INDEX + "/pages/proyectos/listadoPagos.jsf";
    URL_REGISTRO_PAGO = URL_INDEX + "/pages/proyectos/registroPago.jsf";
    URL_REGISTRO_PAGO = URL_INDEX + "/pages/proyectos/registroPago.jsf";
  }

  public static String URL_INDEX, URL_ERROR_LOGIN, URL_ERROR_LOGIN_BLOQUEADO,
      URL_ERROR_LOGIN_APLICACION;
  public static String URL_CAMBIAR_CONTRASENIA, URL_ERROR_EXCEPCION_FATAL,
      URL_ERROR_NO_AUTORIZADO;
  public static String URL_REGISTRO_PAGO, URL_LISTADO_PAGOS, URL_LISTADO_DEVENGADOS,
          URL_LISTADO_DESEMBOLSOS, URL_REGISTRO_DESEMBOLSO,
          URL_LISTADO_PROYECTOS, URL_REGISTRO_PROYECTO;

  // Variables de contexto utilizados
  public static final String KEY_MAP_OPCION_SELECCIONADA = "opcionMenuSeleccionada";
  public static final String KEY_MAP_MSJ_ERROR = "msjError";

  // Formato de la fecha
  public static final String DATE_FORMAT = "dd-MM-yyyy";

  // Constantes para la administracion de contraseñas
  public static final String AXESSO_ESTADO_REGISTRO_VIGENTE = "V";
  public static final String AXESSO_ESTADO_REGISTRO_SUSPENDIDO = "S";

  public static final Integer AXESSO_ESTADO_PASSWORD_VIGENTE = 1;
  public static final Integer AXESSO_ESTADO_PASSWORD_SUSPENDIDO = 2;

  // Constante de ubicacion de las imagenes de reportes
  public static final String URL_LOGO_REPORT = "/resources/img/LogoBCBReporte.jpg";

  /*
   * ***************************** CTTES PARA AXESSO *****************************
   */
  public static final String AXESSO_COD_APP = "CREDITOS"; // EL CODIGO DE LA

  // APLICACION QUE SE
  // ENCUENTRA REGISTRA
  // EN BASE DE DATOS

  /*
   * ***************************** CTTES PARA PARAMETROS REQUEST
   * *****************************
   */
  public enum ParametrosRequest
  {
    REQ_PARAM_SOLICITUD_CREDITO
  }

  public enum ActionType
  {
    NUEVO_REGISTRO,
    MODIFICACION,
    VISUALIZACION,
    AUTORIZACION,
    PROTOCOLIZACION
  }

  public static final String OPCION_SI = "S";
  public static final String OPCION_NO = "N";

  public static final String PAGO_INTERES_DESPUES_GRACIA = "D";
  public static final String PAGO_INTERES_ULTIMA_CUOTA = "U";

  public static final String TIPO_CALCULO_GLOBAL = "G";
  public static final String TIPO_CALCULO_INDIVIDUAL = "I";

  public static final String TIPO_GARANTIA_BONOS = "B";
  public static final String TIPO_GARANTIA_DEBITO = "D";

}
