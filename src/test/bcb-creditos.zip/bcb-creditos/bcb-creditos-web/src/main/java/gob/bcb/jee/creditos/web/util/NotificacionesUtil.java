package gob.bcb.jee.creditos.web.util;


public class NotificacionesUtil
{


  /**
   * 
   * Método encargado de enviar notificaciones a un participante.
   * 
   * @param participante
   * @param titulo
   * @param cuerpo
   */
//  public static void enviarNotificacionesParticipante(
//      Participante participante, String titulo, String cuerpo)
//  {
//  }

}
