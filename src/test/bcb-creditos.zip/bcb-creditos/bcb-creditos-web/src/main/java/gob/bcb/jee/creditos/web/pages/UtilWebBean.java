package gob.bcb.jee.creditos.web.pages;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenModuloBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.BL.LeyBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreReprogramaBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctablaPK;
import gob.bcb.jee.creditos.model.GenTipproductoPK;
import gob.bcb.jee.creditos.model.Ley;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "UtilWebBean")
@ViewScoped
@Getter
@Setter
public class UtilWebBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private GenTipProductoBLLocal genTipProductoBLLocal;

	@Inject
	private GenDesctablaBLLocal genDesctablaBLLocal;

	@Inject
	private GenMonedaBLLocal genMonedaBLLocal;

	@Inject
	private PrePrestamosBLLocal prePrestamosBLLocal;

	@Inject
	private GenModuloBLLocal genModuloBLLocal;

	@Inject
	private CliPersonaBLLocal service;

	@Inject
	private PreReprogramaBLLocal preReprogramaBLLocal;

	@Inject
	private LeyBLLocal leyBLLocal;

	private List<PrePrestamos> listPrePrestamos;

	private List<CliPersona> products;

	private String contrato;
	private Integer igenGenModulo;
	private String igenTipproducto;
	private Integer codigoPrestamo;

	public UtilWebBean() {
	}

	@PostConstruct
	public void init() {

	}

	public double plazo(Integer periodicidad, Integer nroPeriodos) {
		try {
			if (periodicidad == null || nroPeriodos == null || periodicidad == 0 || nroPeriodos == 0) {
				return 0;
			}
			int valor = prePrestamosBLLocal.getValorPeriodicidad(periodicidad);
			double plazo = (double) (nroPeriodos) / (double) (valor);
			return plazo;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return 0;
		}
	}

	public String obtenerLeyesArray(String valor) {
		String variable = "";
		if (valor == null || valor.trim().length() == 0) {
			return "";
		}
		try {
			String[] valor1 = valor.split(",");
			for (String v : valor1) {
				if (!v.trim().equals("")) {
					Integer val = Integer.parseInt(v.trim());
					Ley ley = leyBLLocal.get(val);
					if (ley != null && ley.getLey() != null)
						variable = variable + ley.getLey() + ", ";
				}
			}
		} catch (Exception e) {
			// UtilWeb.getErrorCause(e);
		}
		if (!variable.equals(""))
			variable = variable.substring(0, variable.length() - 2);
		return variable;
	}

	public String obtenerDatosLeyesDevengado(PrePrestamos prePrestamos) {
		String variable = "";
		try {
			// ley, RD N° 110:,Contrato: y demas
			// parametros.put("ley", item.getPreNumconv()+", "+item.getPreNumresol()+",
			// "+item.getPreNumcontra());
			variable = obtenerLeyesArray(prePrestamos.getPreNumconv());
			variable = variable + " RD N° " + prePrestamos.getPreNumresol() + ", Contrato: "
					+ prePrestamos.getPreNumcontra();
			// preDescrdcr
			if (prePrestamos.getPreDescrdcr() != null && !prePrestamos.getPreDescrdcr().isEmpty())
				variable = variable + " ," + prePrestamos.getPreDescrdcr();
			List<Object[]> listObj = preReprogramaBLLocal.obtenerContratos(prePrestamos.getId().getPreCodcred(),
					prePrestamos.getId().getPreCodmod());

			for (Object[] obj : listObj) {
				variable = variable + ", " + obj[0].toString();
			}

		} catch (Exception e) {

		}
		return variable;
	}

	public double gracia(Integer periodicidad, Integer graciaValor) {
		try {
			if(periodicidad == null || graciaValor == null || periodicidad == 0 || graciaValor == 0) {
				return 0;
			}
			int valor = prePrestamosBLLocal.getValorPeriodicidad(periodicidad);
			double gracia = (double) (graciaValor) / (double) (valor);
			return gracia;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return 0;
		}
	}

	public boolean isOperador() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		if (usuario.getRoles().stream().filter(x -> x.getCodigo() != null && x.getCodigo().equals("OPERADOR")).count() > 0)
			return true;
		return false;
	}

	public boolean isAutorizador() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		if (usuario.getRoles().stream().filter(x -> x.getCodigo() != null && x.getCodigo().equals("AUTORIZADOR")).count() > 0)
			return true;
		return false;
	}

	public boolean isPreAutorizador() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		if (usuario.getRoles().stream().filter(x -> x.getCodigo() != null && x.getCodigo().equals("PREAUTORIZADOR")).count() > 0)
			return true;
		return false;
	}

	public boolean isRolHabil(String rol, Integer status, Integer statusExpected) {
		String rolEval = "";
		boolean hasRol = false;
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

		if (rol.equalsIgnoreCase("MODIFICA")) {
			hasRol = isOperador() || isPreAutorizador();
		} else {
			hasRol = usuario.getRoles().stream().filter(x -> x.getCodigo() != null && x.getCodigo().equalsIgnoreCase(rol)).count() > 0;
		}
		status = status == null ? 0 :status;
		boolean taskIsModif = status.compareTo(statusExpected) == 0 || statusExpected.compareTo(0) <= 0;
	

		return hasRol && taskIsModif;
	}

	public String getMoneda(Integer codmon) {
		try {
			if (codmon != null && codmon != 0) {
				String valor = genMonedaBLLocal.get(codmon).getMonDescrip();
				return valor;
			}
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String getLey(Integer id_ley) {
		try {
			if (id_ley != null && id_ley != 0) {
				String valor = leyBLLocal.get(id_ley).getLey();
				return valor;
			}
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String getTipModulo(Integer codmod) {
		try {
			if (codmod != null && codmod != 0) {
				String valor = genModuloBLLocal.get(codmod).getModNombre();
				return valor;
			}
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String getDescTabla(Integer codtab, Integer cod) {
		try {
			if (cod != null && codtab != null && codtab != 0 && cod != 0) {
				GenDesctablaPK pk = new GenDesctablaPK();
				pk.setDesCodtab(codtab);
				pk.setDesCodigo(cod);
				String valor = genDesctablaBLLocal.get(pk).getDesDescrip();
				return valor;
			}

		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String getTipProducto(Integer codmod, Integer codprod) {
		try {
			if (codmod != null && codprod != null && codmod != 0 && codprod != 0) {
				GenTipproductoPK pk = new GenTipproductoPK();
				pk.setTpdCodmod(codmod);
				pk.setTpdCodprod(codprod);
				String valor = genTipProductoBLLocal.get(pk).getTpdDescrip();
				return valor;
			}
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String getCliente(Integer codcli) {
		try {
			if (codcli != null && codcli != 0) {
				CliPersona cliente = service.get(codcli);
				String valor = cliente.getCliNombre();
				return valor;
			}

		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String getClienteSigla(Integer codcli) {
		try {
			if (codcli != null && codcli != 0) {
				CliPersona cliente = service.get(codcli);
				String valor = cliente.getCliIdentifica();
				return valor;
			}

		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public void buscarClientes() {
		try {
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			
		}

	}

	public void buscarPorNroDeContrato() {
		try {
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			
		}
	}

	public void buscarPorNroDePrestamo() {
		try {
			// String []valoresTipoProducto=igenTipproducto.split("-");
			// igenGenModulo= Integer.parseInt(valoresTipoProducto[0].trim());

			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			// valores.put("pre_codmod", igenGenModulo);
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			
		}
	}

	public boolean isZero(Object a, Object b) {
		BigDecimal a1 = new BigDecimal(a.toString());
		BigDecimal b1 = new BigDecimal(b.toString());
		if (a1.add(b1).compareTo(BigDecimal.ZERO) == 0)
			return true;
		return false;
	}

	public boolean isZero(Object a) {
		BigDecimal a1 = new BigDecimal(a.toString());
		if (a1.compareTo(BigDecimal.ZERO) == 0)
			return true;
		return false;
	}

	public static String trim(Object o) {
		if (o != null) {
			return o.toString().trim();
		}
		return "";
	}

	public BigDecimal sumaPosicion(List<Object[]> list, Integer position) {
		try {
			BigDecimal totalSuma = list.stream()
					.map(x -> (BigDecimal) x[position] == null ? BigDecimal.ZERO : (BigDecimal) x[position])
					.reduce(BigDecimal.ZERO, BigDecimal::add);
			return totalSuma;
		} catch (Exception e) {
			return BigDecimal.ZERO;
		}
	}
}
