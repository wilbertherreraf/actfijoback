package gob.bcb.jee.creditos.web.pages.gestion;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenModuloBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.BL.PreCobrosBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreTramonBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.PreCobros;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PreTramon;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "TransaccionCreditoBean")
@ViewScoped
@Getter
@Setter
public class TransaccionCreditoBean  implements Serializable {

    private static final long serialVersionUID = 1L;
  
    @Inject
    private GenTipProductoBLLocal genTipProductoBLLocal;
    
    @Inject
    private GenDesctablaBLLocal genDesctablaBLLocal;
    
    @Inject
    private GenMonedaBLLocal genMonedaBLLocal;
    
    @Inject
    private PrePrestamosBLLocal prePrestamosBLLocal;
    
    @Inject
    private GenModuloBLLocal genModuloBLLocal;
    
    @Inject
    private CliPersonaBLLocal service;
    
    @Inject
    private PreTramonBLLocal preTramonBLLocal;
    
    @Inject
    private PreCobrosBLLocal preCobrosBLLocal;
    
    private List<CliPersona> products;
    
    private PrePrestamos itemActual;
    
    private PrePrestamos prePrestamos=new PrePrestamos();
    private List<PrePrestamos> listPrePrestamos;
    private List<PreTramon> listPreTramon=new ArrayList<>();
    private List<PreCobros> listPreCobros=new ArrayList<>();
    
    private boolean habilitadoCampos=true;
    private CliPersona cliPersona= new CliPersona();
    private String cliente;
    private List<GenTipproducto> listGenTipproductos=new ArrayList<>();
    private GenTipproducto genTipproducto;
    private String igenTipproducto;
    
    private List<GenMoneda> listGenMoneda=new ArrayList<>();
    private GenMoneda genGenMoneda;
    private Integer igenGenMoneda;
    
    private Integer igenGenModulo;
    private Integer codigoPrestamo;
    private String contrato;
    
//    private List<GenDesctabla> listGenDesctablaRubro=new ArrayList<>();
//    private GenDesctabla genDesctablaRubro;
//    private Integer igenDesctablaRubro;
//    
//    private List<GenDesctabla> listGenDesctablaDestino=new ArrayList<>();
//    private GenDesctabla genDesctablaDestino;
//    private Integer igenDesctablaDestino;

    public TransaccionCreditoBean() {
    }

    @PostConstruct
    public void init() {     
    	try {
			listGenTipproductos=genTipProductoBLLocal.list();
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		}  catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}     	
    }
  
 
    public void iniciar() {
    	try {
    		
    		genTipproducto=new GenTipproducto();
    		genGenMoneda=new GenMoneda();

//    		genDesctablaRubro=new GenDesctabla();
//    		genDesctablaDestino=new GenDesctabla();

    		listGenTipproductos=genTipProductoBLLocal.list();
    		Map<String,Object> valores=new HashMap<>();
//    		valores.put("valor1", 160);
//    		listGenDesctablaRubro=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
//    		valores.replace("valor1", 1750);
//    		listGenDesctablaDestino =genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores); 
    		valores.replace("valor1", 1704);
    		//listGenDesctablaEstado=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
    		products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
    		listGenMoneda =genMonedaBLLocal.list();
		}  catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		} 
    	  	
    }
   
    private String transacciones="Transacciones";
    private BigDecimal totalTrx1=BigDecimal.ZERO;
    private BigDecimal totalTrx2=BigDecimal.ZERO;
    public void cargarTramon() {
    	totalTrx1=BigDecimal.ZERO;
    	totalTrx2=BigDecimal.ZERO;
    	try {
    		
    		listPreTramon=new ArrayList<>();
	    	Map<String,Object> valores=new HashMap<>();
			valores.put("valor1", itemActual.getPrePrestamosPK().getPreCodcred());
			valores.put("valor2", itemActual.getPrePrestamosPK().getPreCodmod());
	    	listPreTramon=preTramonBLLocal.listByNamedQuery(PreTramon.NQ_GET_BY_ID, valores);
	    	transacciones="Transacciones "+listPreTramon.size();
	    	totalTrx1=listPreTramon.stream().map(x->x.getTmoValor()==null?BigDecimal.ZERO:x.getTmoValor()).reduce(BigDecimal.ZERO,BigDecimal::add);
	    	totalTrx2=listPreTramon.stream().map(x->x.getTmoImporte()==null?BigDecimal.ZERO:x.getTmoImporte()).reduce(BigDecimal.ZERO,BigDecimal::add);
    	}
    	 catch (Exception e) {
 			Log.Error(e);
 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
 		    FacesContext.getCurrentInstance().addMessage(null, message);
 			 		
    	}
    }
   
    public void revertirCobro(Integer codcred,Integer codmod,Integer numtrx,Integer tipo, Date d) {
    	try {
    		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO); 
    	//	if(tipo==4)//diferimiento
    	//	{
    			preTramonBLLocal.reversaTransaccionDif(codcred, codmod, tipo,d, usuario.getLogin(), UtilWeb.getIPRemoto());
    	//	}
    		//else {
    		//	preTramonBLLocal.reversaTransaccion(codcred, codmod, numtrx, new Date(), usuario.getLogin(), UtilWeb.getIPRemoto());
    	//	}    		   
    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información", "Operación revertida");
		    FacesContext.getCurrentInstance().addMessage(null, message);
    		cargarTramon();
    	}
    	 catch (Exception e) {
 			Log.Error(e);
 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
 		    FacesContext.getCurrentInstance().addMessage(null, message);
 			 		
    	}
    }
  
    private String creditos="Créditos";
    public void selectCliPersonaFromDialog(CliPersona product) {    
    	try {
      //  cliPersona =  product;
        cliente=cliPersona.getCliNombre();
        contrato="";
        this.codigoPrestamo=0;
        Map<String,Object> valores=new HashMap<>();
		valores.put("valor1", cliPersona.getCliCodigo());
    	listPrePrestamos=prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
    	cobros="Cobros";
    	transacciones="Transacciones";
    	creditos="Créditos "+listPrePrestamos.size();
    	listPreCobros=new ArrayList<>();
    	listPreTramon=new ArrayList<>();
    	totalTrx1=BigDecimal.ZERO;
    	totalTrx2=BigDecimal.ZERO;
    	totalCobros=BigDecimal.ZERO;
    	}
    	 catch (Exception e) {
 			Log.Error(e);
 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
 		    FacesContext.getCurrentInstance().addMessage(null, message);
 			
 		} 
     	
    }
    private String cobros="Cobros";
    private BigDecimal totalCobros=BigDecimal.ZERO;
    public void selectTramo(PreTramon pre) {
    	totalCobros=BigDecimal.ZERO;
    	try {
	    	 Map<String,Object> valores=new HashMap<>();
	    	 
	 		valores.put("valor1", pre.getId().getTmoNumtrx());
	 		listPreCobros=preCobrosBLLocal.listByNamedQuery(PreCobros.NQ_GET_BY_TRX, valores);
	 		totalCobros=listPreCobros.stream().map(x->x.getCobValor()==null?BigDecimal.ZERO:x.getCobValor()).reduce(BigDecimal.ZERO,BigDecimal::add);
	 		cobros="Cobros "+listPreCobros.size();	 		
    	}
    	catch(Exception e) {
    		Log.Error(e);
 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
 		    FacesContext.getCurrentInstance().addMessage(null, message);
 			
    	}
    }
    
    public void buscarClientes() {
    	try {
    	products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
    	}
    	 catch (Exception e) {
 			Log.Error(e);
 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
 		    FacesContext.getCurrentInstance().addMessage(null, message);
 			
 		} 
     	
    }
    public void buscarPorNroDeContrato() {
    	try {
    		cliente="";
    		this.codigoPrestamo=0;
    	Map<String,Object> valores=new HashMap<>();
		valores.put("valor1", contrato.toUpperCase());
    	listPrePrestamos=prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);
    	cobros="Cobros";
    	transacciones="Transacciones";
    	creditos="Créditos "+listPrePrestamos.size();
    	listPreCobros=new ArrayList<>();
    	listPreTramon=new ArrayList<>();
    	totalTrx1=BigDecimal.ZERO;
    	totalTrx2=BigDecimal.ZERO;
    	totalCobros=BigDecimal.ZERO;
    	}
    	 catch (Exception e) {
 			Log.Error(e);
 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
 		    FacesContext.getCurrentInstance().addMessage(null, message);
 			
 		} 	
    }
    public void buscarPorNroDePrestamo() {    	 
    	try {
//	    	String []valoresTipoProducto=igenTipproducto.split("-");
//			igenGenModulo= Integer.parseInt(valoresTipoProducto[0].trim());
    		cliente="";
    		contrato="";
			Map<String,Object> valores=new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
		//	valores.put("pre_codmod", igenGenModulo);
	    	listPrePrestamos=prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);
	    	cobros="Cobros";
	    	transacciones="Transacciones";
	    	creditos="Créditos "+listPrePrestamos.size();
	    	listPreCobros=new ArrayList<>();
	    	listPreTramon=new ArrayList<>();
	    	totalTrx1=BigDecimal.ZERO;
	    	totalTrx2=BigDecimal.ZERO;
	    	totalCobros=BigDecimal.ZERO;
    	}
    	 catch (Exception e) {
 			Log.Error(e);
 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
 		    FacesContext.getCurrentInstance().addMessage(null, message);
 			
 		} 
     	
    }
    
    public void limpiar() {
    	cliPersona =  new CliPersona();
        cliente="";
        prePrestamos=new PrePrestamos();
        habilitadoCampos=true;
        creditos="Créditos";
		cobros="Cobros";
    	transacciones="Transacciones";
    }
}
