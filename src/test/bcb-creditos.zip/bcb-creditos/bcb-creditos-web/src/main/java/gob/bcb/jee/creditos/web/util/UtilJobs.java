package gob.bcb.jee.creditos.web.util;

import static org.quartz.TriggerBuilder.newTrigger;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.joda.time.DateTime;
import org.quartz.CronScheduleBuilder;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;


public class UtilJobs {
	public static final String NAME_SCHEDULER = "SISCREDJOBS";
 
    public static void programarJobAtHourAndMinuteForDay(Scheduler scheduler, String jobName, Class<? extends Job> jobClass, String horaEjecucion) throws SchedulerException, ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        Date hora = sdf.parse(horaEjecucion);
        programarJobAtHourAndMinuteForDay(scheduler, jobName, jobClass, hora);
    }

    public static void programarJobAtHourAndMinuteForDay(Scheduler scheduler, String jobName, Class<? extends Job> jobClass, Date horaEjecucion) throws SchedulerException {
        //Creación del job
        DateTime horaEjecucionDT = new DateTime(horaEjecucion);

        JobDetail job = getJobDetail(scheduler, jobName, jobClass);

        //Creacion del Trigger
        TriggerKey triggerKey = new TriggerKey("T" + jobName, jobClass.getSimpleName());
        Trigger trigger;
        boolean existTrigger = scheduler.checkExists(triggerKey);
        if (existTrigger) {
            Trigger oldTrigger = scheduler.getTrigger(triggerKey);
            TriggerBuilder newTriggerBuilder = oldTrigger.getTriggerBuilder();
            newTriggerBuilder.withSchedule(CronScheduleBuilder.dailyAtHourAndMinute(horaEjecucionDT.getHourOfDay(), horaEjecucionDT.getMinuteOfHour()));
            Trigger newTrigger = newTriggerBuilder.build();
            scheduler.rescheduleJob(triggerKey, newTrigger);
        } else {
            TriggerBuilder triggerBuilder = newTrigger()
                    .withIdentity(triggerKey)
                    .forJob(job);
            triggerBuilder = triggerBuilder.withSchedule(CronScheduleBuilder.dailyAtHourAndMinute(horaEjecucionDT.getHourOfDay(), horaEjecucionDT.getMinuteOfHour()));
            trigger = triggerBuilder.build();
            scheduler.scheduleJob(job, trigger);
        }
    }


    private static JobDetail getJobDetail(Scheduler scheduler, String jobName, Class<? extends Job> jobClass) throws SchedulerException {
        JobKey jobKey = new JobKey(jobName, jobClass.getSimpleName());
        boolean existJob = scheduler.checkExists(jobKey);
        JobDetail job;
        if (existJob) {
            job = scheduler.getJobDetail(jobKey);
        } else {
            job = JobBuilder.newJob(jobClass)
                    .withIdentity(jobKey)
                    .withDescription(jobClass.getSimpleName())
                    .storeDurably(false)
                    .build();
        }
        return job;
    }

    public static void programarJobNow(Scheduler scheduler, String jobName, Class<? extends Job> jobClass) throws SchedulerException {
        programarJobNow(scheduler, jobName, jobClass, null);
    }

    public static void programarJobNow(Scheduler scheduler, String jobName, Class<? extends Job> jobClass, Map map) throws SchedulerException {
        programarJobNow(scheduler, jobName, jobClass, new JobDataMap(map));
    }

    public static void programarJobNow(Scheduler scheduler, String jobName, Class<? extends Job> jobClass, JobDataMap dataMap) throws SchedulerException {
        //Creación del job
       // DateTime horaEjecucionDT = new DateTime(horaEjecucion);
        JobDetail job = getJobDetail(scheduler, jobName, jobClass);
        if(dataMap != null) {
            scheduler.getContext().putAll(dataMap);
        }
        //Creacion del Trigger
        TriggerKey triggerKey = new TriggerKey("T" + jobName, jobClass.getSimpleName());
        Trigger trigger;

        boolean existTrigger = scheduler.checkExists(triggerKey);
        if (existTrigger) {
            Trigger oldTrigger = scheduler.getTrigger(triggerKey);
            TriggerBuilder newTriggerBuilder = oldTrigger.getTriggerBuilder();
            newTriggerBuilder.startNow();
            Trigger newTrigger = newTriggerBuilder.build();
            scheduler.rescheduleJob(triggerKey, newTrigger);
        } else {
            TriggerBuilder triggerBuilder = newTrigger()
                    .withIdentity(triggerKey)
                    .forJob(job);
            triggerBuilder = triggerBuilder.startNow();
            trigger = triggerBuilder.build();
            scheduler.scheduleJob(job, trigger);
        }
    }



    public void stopJob(String jobName, Class<? extends Job> jobClass) throws SchedulerException {
        Scheduler scheduler = new StdSchedulerFactory().getScheduler(UtilJobs.NAME_SCHEDULER);
        scheduler.interrupt(new JobKey(jobName, jobClass.getSimpleName()));
    }

}
