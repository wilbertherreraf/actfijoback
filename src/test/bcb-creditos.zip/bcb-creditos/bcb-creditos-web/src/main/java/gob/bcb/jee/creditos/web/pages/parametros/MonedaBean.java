package gob.bcb.jee.creditos.web.pages.parametros;


import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenDesctablaPK;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;


import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "MonedaBean")
@ViewScoped
@Getter
@Setter
public class MonedaBean  implements Serializable {

    private static final long serialVersionUID = 1L;
  

    @Inject
    private GenMonedaBLLocal genMonedaBLLocal;

    
    
    private List<GenMoneda> listGenMoneda;
    
    private GenMoneda genMoneda= new GenMoneda();
        
    
    public MonedaBean() {
    }

    @PostConstruct
    public void init() {     
    	try {
    		listGenMoneda=genMonedaBLLocal.list();
		} 
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}     	
    }
   
    public void iniciarNuevo() {
    	genMoneda= new GenMoneda();    	
    }
    
   
    public void guardar() {
    	try {    		
	    	if(genMoneda.getMonCodmon()==null) {
	    		int codigo=genMonedaBLLocal.getIdNewId();
	    		genMoneda.setMonCodmon(codigo);	    		
	    		genMonedaBLLocal.persist(genMoneda, "");	    		
	    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente","");
	    	    FacesContext.getCurrentInstance().addMessage(null, message);
	    	}
	    	else {
	    		genMonedaBLLocal.merge(genMoneda, "");
	    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro modificado satisfactoriamente","");
	    	    FacesContext.getCurrentInstance().addMessage(null, message);
	    	}
	    	Log.Info("Registro guardado:"+genMoneda);
				
	    limpiar();
	    init();
		} 
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		} 
    	
    	
    }
    
  
    public void limpiar() {
    	genMoneda =  new GenMoneda();        
       			
    }
}
