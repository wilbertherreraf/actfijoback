package gob.bcb.jee.creditos.web.pages.parametros;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;

import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenParametroBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.entidades.GenParametro;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PrePrestamosPK;
import gob.bcb.jee.creditos.pojo.GenParametroDto;
import gob.bcb.jee.creditos.pojo.RespuestaOperacion;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;

/**
 * GenParametro
 *
 * @author mcramos
 * 13/01/2025
 */
@ManagedBean(name = "genParametroBean")
@ViewScoped
@Getter
@Setter
public class GenParametroBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final Logger log = Logger.getLogger(GenParametroBean.class);

    @Inject
    GenParametroBLLocal genParametroBLLocal;

    @Inject
    private CliPersonaBLLocal service;

    @Inject
    private PrePrestamosBLLocal prePrestamosBLLocal;

    PrePrestamos prePrestamosAux = new PrePrestamos();
    private GenParametroDto genParametroDto;
    GenParametro genParametroDesembolso = new GenParametro();
    private boolean insercion;

    public void iniciarNuevo(PrePrestamos pPrestamo) {
        prePrestamosAux = pPrestamo;
        this.insercion = Boolean.TRUE;
        this.genParametroDto = new GenParametroDto();
    }

    public String obtenerInstitucion(Integer institucion) throws OperationException {
        return service.obtenerInstitucion(institucion);
    }

    public void guardar() {
        try {
            log.info("guardar|| Ingresa a guardar GenParametro");
            Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
            RespuestaOperacion vRespuesta = new RespuestaOperacion();

            if (this.insercion){
                vRespuesta = genParametroBLLocal.guardarParametros(this.genParametroDto, prePrestamosAux.getId().getPreCodcred(), prePrestamosAux.getId().getPreCodmod() , usuario.getLogin(), UtilWeb.getIPRemoto());
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro agregado con éxito","" );
                FacesContext.getCurrentInstance().addMessage(null, message);
            }else {
                vRespuesta = genParametroBLLocal.modificarParametros(this.genParametroDto, prePrestamosAux.getId().getPreCodcred(), prePrestamosAux.getId().getPreCodmod() , usuario.getLogin(), UtilWeb.getIPRemoto());
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro modificado con éxito","" );
                FacesContext.getCurrentInstance().addMessage(null, message);
            }


            if (vRespuesta.isEsValid()){

                try {

                    //CODIGO PARA SETEAR setPreEstadoParametros =1 EN CASO DE MODIFICACION O INSERCION DE DATOS
                    prePrestamosAux.setPreAuditusr(usuario.getLogin());
                    prePrestamosAux.setPreAuditfho(new Timestamp(new Date().getTime()));
                    prePrestamosAux.setPreAuditwst(UtilWeb.getIPRemoto());
                    prePrestamosAux.setPreEstadoParametros(1);
                    prePrestamosBLLocal.merge(prePrestamosAux, usuario.getLogin());

                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "El registro debe ser preautorizado y autorizado","" );
                    FacesContext.getCurrentInstance().addMessage(null, message);
                } catch (Exception e) {
                    Log.Error(e);
                    FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",UtilWeb.getErrorCause(e));
                    FacesContext.getCurrentInstance().addMessage(null, message);
                }


                //ContextActions.primeContext("PF('dlgAdm').hide();");
            }else{
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrio un problema al procesar el registro","" );
            }
            log.info("guardar|| Sale a guardar GenParametro");
        }catch (Exception e) {
            Log.Error(e);
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
            FacesContext.getCurrentInstance().addMessage(null, message);
            
        }


    }

    @SneakyThrows
    public void seleccionarModificacion(PrePrestamos pPrestamo) throws OperationException {
        if (pPrestamo == null) return;
        this.insercion = false;
        prePrestamosAux = pPrestamo;
        log.info("seleccionarModificacion|| Recuperamos parametros");
        this.genParametroDto = genParametroBLLocal.recuperarPorCodCredito(pPrestamo.getId().getPreCodcred());
        PrimeFaces.current().ajax().update(":dlgAdm");
    }

    public boolean mostrarBoton(PrePrestamosPK prePrestamosPK) throws OperationException{
        // Lista de parametros que verificaremos
        List<Integer> indices = Arrays.asList(1, 2, 18, 3, 4, 19, 5, 6, 7, 8, 20, 9, 10, 11, 21, 12, 13, 22, 14, 15, 23, 16, 17, 24, 43, 44, 45, 46, 26, 25);

        // Verificamos que todos los valores en esos índices sean "S/D"
        for (Integer indice : indices) {
            String valor = prePrestamosBLLocal.obtenerValorMatrizParametro(prePrestamosPK.getPreCodcred(), indice);
            if (!"S/D".equals(valor)) {
                return false;
            }
        }
        return true;
    }
}
