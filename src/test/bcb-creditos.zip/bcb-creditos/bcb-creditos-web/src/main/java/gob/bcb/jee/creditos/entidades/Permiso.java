package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * Entidad Permiso
 *
 * @author ysalinas
 */
@SuppressWarnings("serial")
// @Entity
// @Table(name = "PERMISO")
@Getter
@Setter
public class Permiso implements Serializable{

    public static final String ENTITY = "Permiso";

    private Recurso recurso;

    private String permiso;

    private String codPermiso;

    @Override
    public String toString() {
        return "Permiso{" +
                "recurso=" + recurso +
                ", permiso='" + permiso + '\'' +
                ", codPermiso='" + codPermiso + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Permiso)) return false;

        Permiso permiso1 = (Permiso) o;

        if (recurso != null ? !recurso.equals(permiso1.recurso) : permiso1.recurso != null) return false;
        if (permiso != null ? !permiso.equals(permiso1.permiso) : permiso1.permiso != null) return false;
        return !(codPermiso != null ? !codPermiso.equals(permiso1.codPermiso) : permiso1.codPermiso != null);

    }

    @Override
    public int hashCode() {
        int result = recurso != null ? recurso.hashCode() : 0;
        result = 31 * result + (permiso != null ? permiso.hashCode() : 0);
        result = 31 * result + (codPermiso != null ? codPermiso.hashCode() : 0);
        return result;
    }
}
