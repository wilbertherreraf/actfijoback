/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mvdb-web
 * gob.bcb.jee.creditos.web.pages.DialogBean
 * 23/03/2016 - 10:41:16
 * Creado por vluque
 */
package gob.bcb.jee.creditos.web.pages;

import gob.bcb.jee.creditos.web.util.ContextActions;

import java.io.Serializable;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import lombok.Getter;
import lombok.Setter;


/**
 * 
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 * 
 * 
 * @author vluque
 * 
 */
@ManagedBean(name = "dialog")
@Getter
@Setter
@ViewScoped
public class DialogBean implements Serializable
{
  /**
   * 
   */
  private static final long serialVersionUID = 1L;

 
  // variables que se usaran en el despliegue del mensaje
  private String titulo;
  private String mensaje;
  private String btnIcono;
  private String btnMensaje;

  /**
   * 
   */
  public DialogBean()
  {
  }

  @PostConstruct
  public void iniciar()
  {
    Map<String, String[]> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterValuesMap();
    String[] aux = params.get(ContextActions.DIALOG);
    titulo = aux[ContextActions.DIALOG_TITULO];
    mensaje = aux[ContextActions.DIALOG_MENSAJE];
    btnIcono = aux[ContextActions.DIALOG_BOTON_ICONO];
    btnMensaje = aux[ContextActions.DIALOG_BOTON_MENSAJE];
  }

  public void cierraDialog()
  {
   // RequestContext.getCurrentInstance().closeDialog("Cierra");
  }

}
