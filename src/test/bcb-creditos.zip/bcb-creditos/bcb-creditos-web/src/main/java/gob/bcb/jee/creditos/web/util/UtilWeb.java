/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-plantillaWebEE-web
 * gob.bcb.jee.creditos.plantillaWebEE.util.UtilWeb
 * 12/03/2016 - 18:34:00
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.web.util;

//import gob.bcb.tciabcb.util.BeanUsuario;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import gob.bcb.jee.creditos.util.Log;


/**
 * Clase encargada de proveer funciones generales para la aplicacion
 *
 * @author ysalinas
 */
public class UtilWeb {
 
    public static final String MD5  = "MD5";
    public static final String SHA1 = "SHA1";

    /**
     * Redirecciona a una pagina determinada.
     *
     * @param <code>String</code> url
     */
    public static void redireccionarURL(String url) {
        Log.Trace("Redireccionando a: " + url);

        try {
            FacesContext fc = FacesContext.getCurrentInstance();
            ExternalContext ec = fc.getExternalContext();

            ec.redirect(url);

            Log.Trace("Redireccionamiento satisfactorio.");
            Log.Info("Redireccionamiento satisfactorio.");
        } catch (IOException e) {
            Log.Error("Error en la redireccion a url: " + url + ". " + e.getMessage().toString());
        }
    }

    /**
     * Obtiene el mensaje de error global, almacenado en sesion que puede ser
     * visualizado en toda la aplicación.
     *
     * @return
     */
    public static String obtenerMensajeError() {
        Log.Trace("Obteniendo mensaje de error...");

        String msj = "";
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        msj = (String) request.getSession().getAttribute(CttesWeb.KEY_MAP_MSJ_ERROR);

        Log.Trace("El mensaje obtenido es: " + msj);
        return msj;
    }

    /**
     * Metodo que carga la lista de propiedades de un archivo .properties
     *
     * @param nombrePropiedades
     * @return
     */
    public Properties cargarPropiedades(String nombrePropiedades) {
        InputStream inputStream = null;
        Properties properties = new Properties();
        try {
            ClassLoader classLoader = this.getClass().getClassLoader();
            // inputStream = new
            // FileInputStream(classLoader.getResource(nombrePropiedades).getFile());
            inputStream = classLoader.getResourceAsStream("/" + nombrePropiedades);
            InputStreamReader reader = new InputStreamReader(inputStream, "UTF-8");
            properties.load(reader);
        } catch (Exception e) {
            Log.Error("Error al cargar propiedades"+ e);
        } finally {
            if (inputStream != null)
                try {
                    inputStream.close();
                } catch (IOException e) {
                    Log.Error("Error al cerrar el archivo de propiedades"+ e);
                }
        }
        return properties;
    }

    /**
     * Metodo que realiza el almacenamiento de una variable de sesion
     *
     * @param name
     * @param value
     */
    public static void setVariableSession(CttesWeb.VariablesSesion name,
                                          Object value) {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        session.setAttribute(name.toString(), value);
    }

    /**
     * Metodo que realiza la obtencion de una variable de sesion
     *
     * @param name
     * @return
     */
    public static Object getVariableSession(CttesWeb.VariablesSesion name) {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        return session.getAttribute(name.toString());
    }


    /**
     * Metodo que realiza el almacenamiento de un parametro
     *
     * @param key
     * @param value
     */
    public static void putParametroRequest(CttesWeb.ParametrosRequest key,
                                           String value) {
        FacesContext.getCurrentInstance().getExternalContext()
                .getRequestParameterMap().put(key.toString(), value);
    }

    /**
     * Metodo que realiza la obtencion de un parametro
     *
     * @param key
     * @return
     */
    public static String getParametroRequest(CttesWeb.ParametrosRequest key) {
        return FacesContext.getCurrentInstance().getExternalContext()
                .getRequestParameterMap().get(key.toString());
    }


    /**
     * Metodo que realiza la obtencion de un valor de sesion a traves de un
     * Servlet request
     *
     * @param name
     * @param request
     * @return
     */
    public static Object getVariableSessionOfRequest(
            CttesWeb.VariablesSesion name, ServletRequest request) {
        HttpServletRequest servletRequest = (HttpServletRequest) request;
        HttpSession session = servletRequest.getSession(true);
        return session.getAttribute(name.toString());

    }

    /**
     * Metodo que realiza la generacion de un hash a partir de un String
     *
     * @param msg
     * @return
     */
    public static String getHashMD5(String msg) {
        String res = "";
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            byte[] buffer = msg.getBytes();
            messageDigest.reset();
            messageDigest.update(buffer);
            byte[] resumen = messageDigest.digest();

            res = "";
            for (int i = 0; i < resumen.length; i++) {
                res += Integer.toHexString((resumen[i] >> 4) & 0xf);
                res += Integer.toHexString(resumen[i] & 0xf);
            }
        } catch (java.security.NoSuchAlgorithmException e) {
            Log.Error("Error al generar HASH para:" + msg+ e);
        }
        return res;
    }

    /**
     * Metodo que obtiene un objeto BeanUsuario a partir de el login y el ip
     * remoto
     *
     *
     * @return
     */
    //TODO: Verificar uso de este bean
//  public static BeanUsuario getBeanActualUserTCIA()
//  {
//    Usuario usuario = (Usuario) getVariableSession(CttesWeb.VariablesSesion.USUARIO);
//    BeanUsuario beanUsuario = new BeanUsuario(usuario.getLogin(), getIPRemoto());
//    return beanUsuario;
//  }

    /**
     * Obtiene el IP del cliente que se conecta a la aplicacion.
     *
     * @return
     */
    public static String getIPRemoto() {
        try {
            HttpServletRequest httpServletRequest = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            String ip = httpServletRequest.getRemoteAddr();
            return ip;
        } catch (Exception e) {
            Log.Error("Error al obtener el IP remoto"+ e);
            return null;
        }
    }

    /**
     * Metodo para ejecutar un javascript
     *
     * @param script
     */
    public static void executeScript(String script) {
       // RequestContext requestContext = RequestContext.getCurrentInstance();
       // requestContext.execute(script);
    }

    /**
     * Metodo que cuenta el numero de coincidencias de una cadena en otra
     *
     * @param cadena
     * @param buscar
     * @return
     */
    public static Integer countString(String cadena, String buscar) {
        int count = 0;
        int idx = 0;

        while ((idx = cadena.indexOf(buscar, idx)) != -1) {
            idx++;
            count++;
        }
        return count;
    }

    private static final BigDecimal MAX_BIG_DECIMAL = new BigDecimal("9999999999999.15");

    public static BigDecimal getMaxBigDecimal() {
        return MAX_BIG_DECIMAL;
    }

    /**
     * Obtiene el primer dia del mes actual
     *
     * @return
     */
    public static Date getFirstDateOfCurrentMonth() {
        Calendar aCalendar = Calendar.getInstance();

        aCalendar.set(Calendar.DATE, 1);
        aCalendar.set(Calendar.HOUR_OF_DAY, 0);
        aCalendar.set(Calendar.MINUTE, 0);
        aCalendar.set(Calendar.SECOND, 0);
        return aCalendar.getTime();
    }

    public static Date getLastHourFromNow() {
        Calendar aCalendar = Calendar.getInstance();
        aCalendar.set(Calendar.HOUR_OF_DAY, aCalendar.get(Calendar.HOUR_OF_DAY) - 1);
        return aCalendar.getTime();
    }

    /**
     * Obtiene el utlimo dia del mes actual
     *
     * @return
     */
    public static Date getLastDateOfCurrentMonth() {
        Calendar aCalendar = Calendar.getInstance();

        aCalendar.set(Calendar.DATE, aCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        aCalendar.set(Calendar.HOUR_OF_DAY, 23);
        aCalendar.set(Calendar.MINUTE, 59);
        aCalendar.set(Calendar.SECOND, 59);
        return aCalendar.getTime();
    }

    /**
     * Obtiene la Hora inicial del Dia
     *
     * @return
     */
    public static Date getFirstDayHour() {
        Calendar calendar = Calendar.getInstance();

        calendar.set(Calendar.DATE, Calendar.getInstance().get(Calendar.DATE));
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    /**
     * Obtiene la ultima hora del dia
     *
     * @return
     */
    public static Date getLastDayHour() {
        Calendar calendar = Calendar.getInstance();

        calendar.set(Calendar.DATE, Calendar.getInstance().get(Calendar.DATE));
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        return calendar.getTime();
    }

    /**
     * Validador de formatos de emails
     */
    public static boolean emailValidator(String email) {
        try {
            Pattern patron = Pattern.compile("^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,3})$");
            Matcher matcher = patron.matcher(email);
            return matcher.matches();
        } catch (NullPointerException e) {
            return false;
        }
    }


    public static String getHash(String mensaje, String algoritmo)
    {
        String hash = null;
        try
        {
            MessageDigest messageDigest = MessageDigest.getInstance(algoritmo);
            messageDigest.update(mensaje.getBytes());
            byte[] digest = messageDigest.digest();
            StringBuffer sb = new StringBuffer();
            for (byte b : digest)
                sb.append(String.format("%02x", b & 0xff));
            hash = sb.toString().toUpperCase();
        }
        catch (Exception e)
        {
            
        }
        return hash;
    }
    public static String getErrorCause(Throwable e)
    {
        Throwable t = e.getCause();
	    String Error="";
	    String ErrorSQL="";
	    while(t != null) {	    	
	    	Error=Error+" "+"Causa: " + t +" \n";	    	
	    	if(t instanceof SQLException) {
	    		if(!(t+"").equals("java.sql.SQLException"))
	    			ErrorSQL=ErrorSQL+" "+"Causa: " + t +" \n";
	    	}
	    	t = t.getCause();	    	
	    }
	    if(!ErrorSQL.equals("")) {
	    	Error=ErrorSQL;
	    }
	    else
	    	Error=e.getMessage();
	    
	    return Error;
    }
    public static String trim(Object o) {
    	if(o!=null) {
    		return o.toString().trim();
    	}
    	return "";
    }
}
