package gob.bcb.jee.creditos.web.pages.gestion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Inject;

import org.primefaces.event.SelectEvent;

import gob.bcb.jee.creditos.BL.ArticuloBLLocal;
import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenModuloBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.BL.PrePrccontaBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreTasaspreBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.Articulo;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenDesctablaPK;
import gob.bcb.jee.creditos.model.GenModulo;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.PrePrcconta;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PrePrestamosPK;
import gob.bcb.jee.creditos.model.PreTasaspre;
import gob.bcb.jee.creditos.model.PreTasasprePK;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.pages.UtilWebBean;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "DatosCreditoBean")
@ViewScoped
@Getter
@Setter
public class DatosCreditoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	UtilWebBean utilWebBean;

	@Inject
	private GenTipProductoBLLocal genTipProductoBLLocal;

	@Inject
	private GenDesctablaBLLocal genDesctablaBLLocal;

	@Inject
	private GenMonedaBLLocal genMonedaBLLocal;

	@Inject
	private PrePrestamosBLLocal prePrestamosBLLocal;

	@Inject
	private GenModuloBLLocal genModuloBLLocal;
	
	@Inject
	private CliPersonaBLLocal service;
	@Inject
	private ArticuloBLLocal articuloBLLocal;
	@Inject
	private PreTasaspreBLLocal preTasaspreBLLocal;
	@Inject
	private PrePrccontaBLLocal prePrccontaBLLocal;

	private List<CliPersona> products;

	private PrePrestamos itemActual = new PrePrestamos();

	private Double plazo;
	private Double gracia;
	private Double graciaint;

	private PrePrestamos prePrestamos = new PrePrestamos();
	private List<PreTasaspre> listTasas;
	PreTasaspre tasa = new PreTasaspre();
	private List<PrePrestamos> listPrePrestamos;
	private List<PrePrestamos> filterListPrePrestamos;
	private boolean habilitadoCampos = true;
	private CliPersona cliPersona = new CliPersona();
	private String cliente;
	private List<GenTipproducto> listGenTipproductos;
	private GenTipproducto genTipproducto;
	private String igenTipproducto;

	private List<GenModulo> listGenModulo;

	private List<GenMoneda> listGenMoneda;
	private GenMoneda genGenMoneda;
	private Integer igenGenMoneda;

	private Integer igenGenModulo;
	private Integer codigoPrestamo;
	private String contrato;

	// private List<GenDesctabla> listGenDesctablaRubro;
	private GenDesctabla genDesctablaRubro;
	private Integer igenDesctablaRubro;
	private String txt1;
	// private List<GenDesctabla> listGenDesctablaDestino;
	// private GenDesctabla genDesctablaDestino;
	private Integer igenDesctablaDestino;
	private List<GenDesctabla> listGenDesctablaPlazo;
	private List<GenDesctabla> listGenDesctablaCapitalizacion;
	private List<String> listSeleccionados = new ArrayList<String>();
	private List<SelectItem> listLeyesSelect = new ArrayList<SelectItem>();
	private List<Object[]> listLeyes = new ArrayList<>();

	public DatosCreditoBean() {
	}

	@PostConstruct
	public void init() {
		try {
			listGenTipproductos = genTipProductoBLLocal.list();
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void verTasas() {
		try {
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", itemActual.getId().getPreCodcred());
			valores.put("valor2", itemActual.getId().getPreCodmod());
			listTasas = preTasaspreBLLocal.listByNamedQuery(PreTasaspre.NQ_GET_BY_ID, valores);
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void iniciar() {
		try {
			genTipproducto = new GenTipproducto();
			genGenMoneda = new GenMoneda();

			genDesctablaRubro = new GenDesctabla();
			// genDesctablaDestino=new GenDesctabla();

			listGenTipproductos = genTipProductoBLLocal.list();
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", 160);
			// listGenDesctablaRubro=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB,
			// valores);
			// valores.replace("valor1", 1750);
			// listGenDesctablaDestino
			// =genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB,
			// valores);
			// valores.replace("valor1", 1704);
			// listGenDesctablaEstado=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB,
			// valores);
			listGenMoneda = genMonedaBLLocal.list();

			valores.put("valor1", 413);
			listGenDesctablaCapitalizacion = genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB,
					valores);

		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void preAutorizar() {
		try {
			if (itemActual.getPreFecfirmconv() == null) {
				if (!validarMontoAutorizar(itemActual.getPreMonto(), itemActual.getPreNumconv(),
						itemActual.getPreCodcli())) {
					FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							"No puede superar el monto de la ley");
					FacesContext.getCurrentInstance().addMessage(null, message);
					return;
				}
			}
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActual.setPreAuditusr(usuario.getLogin());
			itemActual.setPreAuditfho(new Timestamp(new Date().getTime()));
			itemActual.setPreAuditwst(UtilWeb.getIPRemoto());
			itemActual.setPreTrxstaau(2);

			prePrestamosBLLocal.merge(itemActual, usuario.getLogin());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Registro preautorizado satisfactoriamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void refrescarMontoArticulos(BigDecimal monto, String seleccionado, Integer cliente) throws Exception {
		try {
			BigDecimal big = BigDecimal.ZERO;
			String[] vec = seleccionado.split(",");
			Map<String, Object> valores = new HashMap<>();

			for (String v : vec) {
				valores.put("valor1", Integer.parseInt(v));
				valores.put("valor2", cliente);
				List<Articulo> listArticulo = articuloBLLocal.listByNamedQuery(Articulo.NQ_GET_BY_CLI_LEY, valores);
				if (listArticulo.size() > 0) {
					Articulo articulo = listArticulo.get(0);
					if (articulo.getSaldo().compareTo(monto) >= 0) {
						articulo.setSaldo(articulo.getSaldo().subtract(monto));
						articulo.setMontoOtorgado(articulo.getMontoOtorgado().add(monto));
						articuloBLLocal.merge(articulo, "");
						return;
					} else {
						big = articulo.getSaldo();
						articulo.setSaldo(articulo.getSaldo().subtract(big));
						articulo.setMontoOtorgado(articulo.getMontoOtorgado().add(big));
						articuloBLLocal.merge(articulo, "");
						monto = monto.subtract(big);
					}

				}
			}
		} catch (Exception e) {
			UtilWeb.getErrorCause(e);
			throw new Exception(e);
		}
	}

	public boolean validarMontoAutorizar(BigDecimal monto, String valores, Integer idCliente) {
		try {
			listLeyes = articuloBLLocal.obtenerLeyesRelacionadas(idCliente);
			BigDecimal big = BigDecimal.ZERO;
			for (Object[] obj : listLeyes) {
				String[] vec = valores.split(",");
				for (String v : vec) {
					if (obj[0].toString().equals(v)) {
						big = big.add(new BigDecimal(obj[4].toString()));
					}
				}
			}
			if (monto.compareTo(big) <= 0) {
				return true;
			}
		} catch (OperationException e) {
			UtilWeb.getErrorCause(e);
		}

		return false;
	}

	public void autorizar() {
		try {
			if (itemActual.getPreFecfirmconv() == null) {
				if (!validarMontoAutorizar(itemActual.getPreMonto(), itemActual.getPreNumconv(),
						itemActual.getPreCodcli())) {
					FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							"No puede superar el monto de la ley");
					FacesContext.getCurrentInstance().addMessage(null, message);
					return;
				}
			}
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActual.setPreAuditusr(usuario.getLogin());
			itemActual.setPreAuditfho(new Timestamp(new Date().getTime()));
			itemActual.setPreAuditwst(UtilWeb.getIPRemoto());
			itemActual.setPreTrxstaau(3);

			prePrestamosBLLocal.merge(itemActual, usuario.getLogin());

			if (itemActual.getPreFecfirmconv() == null) {
				refrescarMontoArticulos(itemActual.getPreMonto(), itemActual.getPreNumconv(),
						itemActual.getPreCodcli());
				itemActual.setPreFecfirmconv(new Date());
				prePrestamosBLLocal.merge(itemActual, usuario.getLogin());
			} else {
				Log.Info("ya se realizo la reduccion a los articulos:" + itemActual);
			}
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Registro autorizado satisfactoriamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void guardarPrestamo() {
		try {
			if (itemActual.getPreFecfirmconv() == null) {
				if (!validarMonto(itemActual.getPreMonto())) {
					FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",
							"No puede superar el monto de la ley");
					FacesContext.getCurrentInstance().addMessage(null, message);
					return;
				}
			}

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActual.setPreAuditusr(usuario.getLogin());
			itemActual.setPreAuditfho(new Timestamp(new Date().getTime()));
			itemActual.setPreAuditwst(UtilWeb.getIPRemoto());

			int valor = prePrestamosBLLocal.getValorPeriodicidad(itemActual.getPreUnidplaz());

			itemActual.setPreNroperiodos((int) ((double) valor * plazo));
			itemActual.setPreNrogracia((int) ((double) valor * gracia));
			itemActual.setPreNrograciaint((int) ((double) valor * graciaint));
			// int
			// valor=prePrestamosBLLocal.getValorPeriodicidad(itemActual.getPreUnidplaz());
			int numeroPagos = (itemActual.getPreNroperiodos()) - itemActual.getPreNrogracia();
			itemActual.setPreNropagos(numeroPagos);
			itemActual.setPreTabtrxstaau(30);
			itemActual.setPreTrxstaau(1);

			itemActual.setPreNumconv(listSeleccionados.stream().collect(Collectors.joining(",")));
			prePrestamosBLLocal.merge(itemActual, usuario.getLogin());
			Log.Info("Registro modificado:" + itemActual.toString());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Registro modificado satisfactoriamente",
					"El registro requiere de la preautorización y autorización");
			FacesContext.getCurrentInstance().addMessage(null, message);
			limpiar();
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public boolean validarMonto(BigDecimal monto) {
		BigDecimal big = BigDecimal.ZERO;
		for (Object[] obj : listLeyes) {
			String[] vec = listSeleccionados.stream().collect(Collectors.joining(",")).split(",");
			for (String v : vec) {
				if (obj[0].toString().equals(v)) {
					big = big.add(new BigDecimal(obj[4].toString()));
				}
			}
		}
		if (monto.compareTo(big) <= 0) {
			return true;
		}
		return false;
	}

	public void modificarPrestamo() {
		try {

			listSeleccionados.clear();
			listLeyes = articuloBLLocal.obtenerLeyesRelacionadas(itemActual.getPreCodcli());
			listLeyesSelect.clear();
			for (Object[] to : listLeyes) {
				listLeyesSelect.add(new SelectItem(to[0],
						to[1].toString() + " Art." + to[7] + ", Saldo:" + new DecimalFormat("#,###.00").format(to[4])));
				// listLeyesSelect.add(new SelectItem(to[0], to[1].toString()+", Saldo:"+new
				// DecimalFormat("#,###.00").format(to[4] )));
			}
			if (itemActual.getPreNumconv() != null) {
				String[] vec = itemActual.getPreNumconv().split(",");

				for (String v : vec) {
					listSeleccionados.add(v);
				}
			} else {
				listSeleccionados.clear();
			}
			listGenModulo = genModuloBLLocal.list();
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", itemActual.getId().getPreCodmod());
			listGenTipproductos = genTipProductoBLLocal.listByNamedQuery(GenTipproducto.NQ_GET_BY_ID_MOD, valores);
			listGenMoneda = genMonedaBLLocal.list();
			valores.put("valor1", 1703);
			listGenDesctablaPlazo = genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
			listGenDesctablaPlazo = listGenDesctablaPlazo.stream()
					.sorted((x, y) -> x.getDesDescrip().compareTo(y.getDesDescrip())).collect(Collectors.toList());
			valores.put("valor1", 413);
			listGenDesctablaCapitalizacion = genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB,
					valores);
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
			int valor = prePrestamosBLLocal.getValorPeriodicidad(itemActual.getPreUnidplaz());
			plazo = (double) (itemActual.getPreNroperiodos() == null ? 0 : itemActual.getPreNroperiodos())
					/ (double) (valor);
			gracia = (double) (itemActual.getPreNrogracia() == null ? 0 : itemActual.getPreNrogracia())
					/ (double) (valor);
			graciaint = (double) (itemActual.getPreNrograciaint() == null ? 0 : itemActual.getPreNrograciaint())
					/ (double) (valor);
			// prePrestamos.setPreNroperiodos((int)((double)valor*plazo));
			// prePrestamos.setPreNrogracia((int)((double)valor*gracia));
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	private boolean mostrarDiasIregular = true;

	public void seleccionarPlazoCapital(SelectEvent id_mod) {
		int id = Integer.parseInt(id_mod.getObject().toString());
		if (id == 1)
			this.mostrarDiasIregular = false;
		else
			this.mostrarDiasIregular = true;

	}

	public boolean permitirModificar(Integer codtab, Integer cod) {
		try {
			if (codtab != 0 && cod != 0) {
				GenDesctablaPK pk = new GenDesctablaPK();
				pk.setDesCodtab(codtab);
				pk.setDesCodigo(cod);
				String valor = genDesctablaBLLocal.get(pk).getDesDescrip();
				if (valor.toUpperCase().trim().equals("VIGENTE"))
					return true;
			}

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}

		return false;
	}

	public void selectCliPersonaFromDialog(CliPersona product) {
		try {
			// cliPersona = product;
			cliente = cliPersona.getCliNombre();
			filterListPrePrestamos = null;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void selectCliPersonaFromDialogTodo(CliPersona product) {
		try {

			// cliPersona = product;
			cliente = cliPersona.getCliNombre();
			this.contrato = "";
			filterListPrePrestamos = null;
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE_R, valores);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarClientes() {
		try {
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDeContrato() {
		try {
			cliente = "";
			this.contrato = "";
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDeContratoTodo() {
		try {
			cliente = "";
			this.codigoPrestamo = 0;
			filterListPrePrestamos = null;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO_R, valores);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDePrestamo() {
		try {
			// String []valoresTipoProducto=igenTipproducto.split("-");
			// igenGenModulo= Integer.parseInt(valoresTipoProducto[0].trim());
			cliente = "";
			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			// valores.put("pre_codmod", igenGenModulo);
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDePrestamoTodo() {
		try {
			// String []valoresTipoProducto=igenTipproducto.split("-");
			// igenGenModulo= Integer.parseInt(valoresTipoProducto[0].trim());
			cliente = "";
			filterListPrePrestamos = null;
			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			// valores.put("pre_codmod", igenGenModulo);
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID_R, valores);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void iniciarNuevaTasa() {
		tasa = new PreTasaspre();
		tasa.setId(new PreTasasprePK(itemActual.getId().getPreCodcred(), itemActual.getId().getPreCodmod(), null));
	}

	private boolean modificarTasaPaso = false;
	private PreTasasprePK pkTasas = new PreTasasprePK();

	public void iniciarModificarTasa() {
		modificarTasaPaso = true;
		pkTasas = new PreTasasprePK(tasa.getId().getMtpCodcred(), tasa.getId().getMtpCodmod(),
				tasa.getId().getMtpFechavig());
	}


	public void guardarTasa() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

			tasa.setMtpAuditusr(usuario.getLogin());
			tasa.setMtpAuditfho(new Timestamp(new Date().getTime()));
			tasa.setMtpAuditusr(UtilWeb.getIPRemoto());
			tasa.setMtpTabintmdias(20);
			tasa.setMtpIntmdias(1);
			tasa.setMtpTabintydias(21);
			// preTasaspre.setMtpIntydias(360);
			tasa.setMtpTabtrxstaau(30);
			tasa.setMtpTrxstaau(1);
			tasa.setMtpTspread(0.0);

			if (modificarTasaPaso) {
				preTasaspreBLLocal.update(pkTasas.getMtpCodcred(), pkTasas.getMtpCodmod(), pkTasas.getMtpFechavig(),
						tasa.getId().getMtpFechavig(), tasa.getMtpTbase(), tasa.getMtpIntydias());
				modificarTasaPaso = false;
				pkTasas = new PreTasasprePK();
			} else {
				preTasaspreBLLocal.persist(tasa, "");
			}

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente",
					"");
			FacesContext.getCurrentInstance().addMessage(null, message);
			tasa = new PreTasaspre();
			verTasas();
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void limpiar() {
		cliPersona = new CliPersona();
		cliente = "";
		prePrestamos = new PrePrestamos();
		prePrestamos.setPrePrestamosPK(new PrePrestamosPK());
		habilitadoCampos = true;
		listSeleccionados.clear();

		listLeyesSelect.clear();
	}
}
