package gob.bcb.jee.creditos.web.pages.parametros;


import gob.bcb.jee.creditos.BL.ArticuloBLLocal;
import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.LeyBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.Articulo;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenDesctablaPK;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.Ley;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;


import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "ArticuloBean")
@ViewScoped
@Getter
@Setter
public class ArticuloBean  implements Serializable {

    private static final long serialVersionUID = 1L;
  

    @Inject
    private ArticuloBLLocal articuloBLLocal;
    @Inject
    private LeyBLLocal leyBLLocal;
    @Inject
    private CliPersonaBLLocal cliPersonaBLLocal;
    
    private List<Articulo> listArticulo;
    private List<CliPersona> listCliPersona;
    private List<Ley> listLey;
    
    private Ley ley= new Ley();
    private Articulo articulo= new Articulo();
    private CliPersona cliPersona= new CliPersona();
       
      

    @PostConstruct
    public void init() {     
    	try {
    		listArticulo=articuloBLLocal.list();
    		listCliPersona = cliPersonaBLLocal.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
    		listLey=leyBLLocal.list();
		} 
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}     	
    }
   
    public void iniciarNuevo() {
    	articulo= new Articulo();    	
    }
    
   
    public void guardar() {
    	try {    			    	
    		 Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
    		 articulo.setTabtrxstaau(30);
    		 articulo.setTrxstaau(1);
    		 articulo.setAuditusr(usuario.getLogin());
    		 articulo.setAuditfho(new Timestamp(new Date().getTime()));
    		 articulo.setAuditwst(UtilWeb.getIPRemoto());
    		 if(articulo.getId()!=null) {
    			 articulo.setSaldo(articulo.getMontoRegistrado().subtract(articulo.getMontoOtorgado()));
    			 articuloBLLocal.merge(articulo, "");
    			 
    		 }
	    		else {
	    			articulo.setId(articuloBLLocal.getIdNuevo());
	    			articulo.setMontoOtorgado(BigDecimal.ZERO);
	    			articulo.setSaldo(articulo.getMontoRegistrado());
	    			articulo=articuloBLLocal.persist(articulo, "");
	    		}
	    			   	
	    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente","");
	    	    FacesContext.getCurrentInstance().addMessage(null, message);
	    		    	
	    	Log.Info("Registro guardado:"+articulo);
				
	    limpiar();
	    init();
		} 
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		} 
    	
    	
    }
    
  
    public void limpiar() {
    	articulo= new Articulo();         
       			
    }
}
