package gob.bcb.jee.creditos.web.pages.gestion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.primefaces.PrimeFaces;

import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenParametroBLLocal;
import gob.bcb.jee.creditos.BL.PreCustodiaGarantiaBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocal;
import gob.bcb.jee.creditos.BL.PrePlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.PrePrccontaBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreRegistrogarantiasBLLocal;
import gob.bcb.jee.creditos.BL.PreRetiroGarantiaBLLocal;
import gob.bcb.jee.creditos.entidades.PreRegistrogarantias;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.PreCustodiaGarantia;
import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.model.PrePrcconta;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PreRetiroGarantia;
import gob.bcb.jee.creditos.pojo.PlanPagoDto;
import gob.bcb.jee.creditos.pojo.PreCustodiaGarantiaDto;
import gob.bcb.jee.creditos.pojo.PreRetiroGarantiaDto;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "RegistroGarantiasBean")
@ViewScoped
@Getter
@Setter
public class RegistroGarantiasBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Inject
	private CliPersonaBLLocal service;

	@Inject
	private PrePrestamosBLLocal prePrestamosBLLocal;

	@Inject
	private PrePrccontaBLLocal prePrccontaBLLocal;

	/** codigo añadido para ver desembolsos **/
	@Inject
	private PreDesembBLLocal preDesembBLLocal;

	@Inject
	private PreRegistrogarantiasBLLocal preRegistrogarantiasBLLocal;

	@Inject
	private PrePlanpagosBLLocal prePlanpagosLocal;

	@Inject
	private GenParametroBLLocal genParametroBLLocal;

	@Inject
	private PreRegistrogarantiasService preRegistrogarantiasService; // Inyección del servicio

	@Inject
	private PreCustodiaGarantiaBLLocal preCustodiaGarantiaBLLocal;

	@Inject
	private PreRetiroGarantiaBLLocal preRetiroGarantiaBLLocal;

	private Integer codigoPrestamo;
	private String contrato;
	// private Date fechaUlt;
	private Date fecha;
	private Date fecha2;
	private CliPersona cliPersona = new CliPersona();
	private String cliente;
	private List<CliPersona> products;
	private PrePrestamos itemActual = new PrePrestamos();

	// hpanique SDAPO 1520473
	private Integer codigoProcComprobante;

	private String certpres;

	private List<Object[]> DatosComprobante;
	private Integer nro_desembolsos;
	private Integer nro_dias;
	private BigDecimal total_interes_devengado;
	private BigDecimal total_desembolsado;
	private BigDecimal total_saldocapital;

	private Integer estadoProcesoComprobante;
	private Integer resultado;
	private boolean devengamientoOk;
	private boolean showComprobante;
	private boolean showOperador;
	private boolean showPreautorizador;
	private boolean showAutorizador;
	PrePrcconta prePrcconta;
	private List<Object[]> datosComprobanteCoin;
	private String glosaCoin;
	private String glosaDebe;
	private String glosaHaber;
	private Integer opcionActiva;
	private CliPersona clienteActivo;
	private Date fechaDevengado;

	//

	private List<PrePrestamos> listPrePrestamos;

	/** -------------------------------------------------- **/
	private List<Object[]> listPrePlanpagosDSB = new ArrayList<>();
	private List<PreDesemb> listDesembolso;
	private BigDecimal valorDisponibleDesembolso;

	private List<PreCustodiaGarantiaDto> listCustodiaGarantia = new ArrayList<>();
	private List<PreRetiroGarantiaDto> listaRetiroGarantia = new ArrayList<>();

	private PreDesemb itemActualPreD = new PreDesemb();

	private List<Object[]> ParamsComprobante;
	private List<Object[]> totalBonosValorGarantia;

	private Integer numeroCentro;
	private String tipoComprobante;
	private String parametroGlosa;
	private Integer numeroDesembolso;
	private Integer totalBonos;
	private BigDecimal valorGarantia;
	private String numeroSerie;
	private String nroComprobanteCOIN;

	private PreRegistrogarantias preRegistrogarantias;
	private PreRegistrogarantias preRegistrogarantiasForm;
	private String ctaDebe;
	private String ctaHaber;
	private String nombreCorto;

	private Integer nroDesembolso;
	private PreCustodiaGarantia itemActualCustodiaGarantia = new PreCustodiaGarantia();
	private String parametroGlosaCustodiaGarantia;
	private String descProyecto;
	private List<PlanPagoDto> listPrePlanpagosDSBPorGestion = new ArrayList<>();
	private String fechaVencimientoSeleccionado;
	private boolean existeRegistroTransGarantiaAutorizado = Boolean.FALSE;

	private PreRetiroGarantia itemActualRetiroGarantia = new PreRetiroGarantia();

	public RegistroGarantiasBean() {
	}

	@PostConstruct
	public void init() {
		try {
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
			fecha = new Date();
			fecha2 = new Date();
			devengamientoOk = false;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void buscarClientes() {
		try {
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	/** busquesda por numero de credito **/
	public void buscarPorNroDePrestamo() {
		try {
			cliente = "";
			contrato = "";
			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);

			opcionActiva = 3;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	/** busqueda por beneficiario **/
	public void selectCliPersonaFromDialog(CliPersona product) {
		try {

			cliente = cliPersona.getCliNombre();
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);

			opcionActiva = 1;
			clienteActivo = product;

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Beneficiario seleccionado",
					"Nombre:" + cliPersona.getCliNombre());
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	/** busqueda por numero de contrato **/
	public void buscarPorNroDeContrato() {
		try {
			cliente = "";
			// this.contrato="";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);

			opcionActiva = 2;
			//
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void iniciarVerDesembolsos() {

		Log.Info("valor de itemActual " + itemActual);

		try {
			listPrePlanpagosDSB = new ArrayList<>();
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", itemActual.getPrePrestamosPK().getPreCodcred());
			valores.put("valor2", itemActual.getPrePrestamosPK().getPreCodmod());
			listDesembolso = preDesembBLLocal.listByNamedQuery(PreDesemb.NQ_LIST_BY_CREDITO, valores);
			valorDisponibleDesembolso = preDesembBLLocal.getDisponibleDesembolso(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod());

			if (listDesembolso.size() > 0) {
				// preparamos lista para custodia de garantia
				listCustodiaGarantia = new ArrayList<>();

				// preparamos la lista para retiro de garantia
				listaRetiroGarantia = new ArrayList<>();

				for (PreDesemb preDesemb : listDesembolso) {
					PreCustodiaGarantiaDto custodiaGarantiaDto = new PreCustodiaGarantiaDto();
					custodiaGarantiaDto.setDesembolso(preDesemb);
					custodiaGarantiaDto.setCustodiaGarantia(
							preCustodiaGarantiaBLLocal.obtenerPorCodDesembolso(preDesemb.getDsbCoddsb()));
					listCustodiaGarantia.add(custodiaGarantiaDto);

					PreRetiroGarantiaDto retiroGarantiaDto = new PreRetiroGarantiaDto();
					retiroGarantiaDto.setDesembolso(preDesemb);
					retiroGarantiaDto.setRetiroGarantia(
							preRetiroGarantiaBLLocal.obtenerPorCodDesembolso(preDesemb.getDsbCoddsb()));

					if (retiroGarantiaDto.getRetiroGarantia() != null
							&& retiroGarantiaDto.getRetiroGarantia().getEstado() == Cttes.ESTOPER_AUTO.intValue()) {
						Log.Info(
								"iniciarVerDesembolsos|| verifiamos si se realizo el pago de la cuota de fecha de vencimiento");
						PlanPagoDto planPagoDtoRecuperado = prePlanpagosLocal.recuperarPlanDePagoPorParametros(
								retiroGarantiaDto.getRetiroGarantia().getCodcred(),
								retiroGarantiaDto.getRetiroGarantia().getCodmod(),
								retiroGarantiaDto.getRetiroGarantia().getCoddsb().getDsbCoddsb(),
								retiroGarantiaDto.getRetiroGarantia().getFechaVencimiento());
						if (planPagoDtoRecuperado.getEstadoCuota().trim().toUpperCase().equals("CANCELADO")) {
							retiroGarantiaDto.getRetiroGarantia().setCuotaPagada(1);
						} else {
							retiroGarantiaDto.getRetiroGarantia().setCuotaPagada(0);
						}
					} else {
						retiroGarantiaDto.getRetiroGarantia().setCuotaPagada(0);
					}

					listaRetiroGarantia.add(retiroGarantiaDto);
				}
			}
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void registroTransitorioGarantia(PreDesemb desembolso) {

		preRegistrogarantias = new PreRegistrogarantias();

		Log.Info("Método registroTransitorioGarantia() invocado.");

		try {
			this.itemActualPreD = desembolso;

			// Lógica del método
			Log.Info("valor de itemActual " + itemActual);
			Log.Info("valor de itemActualPreD " + itemActualPreD);

			/** codigo para obtener el parametro de la glosa de la tabla gen_comprobante **/

			ParamsComprobante = preRegistrogarantiasBLLocal.getParametrosGlosa(Cttes.REGISTRO_TRANSITORIO_DE_BONOS);
			for (Object[] result : ParamsComprobante) {
				numeroCentro = (int) result[2];
				tipoComprobante = (String) result[3];
				parametroGlosa = (String) result[4];
			}

			/** Codigo para obtener el cantidad total de desembolsos **/
			numeroDesembolso = preRegistrogarantiasBLLocal.getNumeroTotalDesembolso(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod());
			if (numeroDesembolso == 0) { // verifica si existen desembolsos =0
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No existen desembolsos Registrados, Preautorizados/Autorizados."));
				return; // Detiene la ejecución aquí
			}

			/**
			 * Codigo para obtener los valores de total de bonos y total valor de la
			 * garantia
			 **/
			totalBonosValorGarantia = prePlanpagosLocal.getTotalBonoValorGarantia(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
					itemActualPreD.getDsbCoddsb());
			for (Object[] result : totalBonosValorGarantia) {
				totalBonos = ((Number) result[0]).intValue();
				valorGarantia = (BigDecimal) result[1];
			}

			if (totalBonos == 0) { // verifica si existen desembolsos =0
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No existen registrados Planes de Pago por Desembolso."));
				return; // Detiene la ejecución aquí
			}

			/** Codigo para obtener el Numero de Serie del desembolso **/
			numeroSerie = preRegistrogarantiasBLLocal.getNumeroSerieGarantia(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
					itemActualPreD.getDsbCoddsb());
			if (numeroSerie == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Numero de Serie de la garantía."));
				return; // Detiene la ejecución aquí
			}

			/** Codigo para obtener el Numero de DEBE y HABER **/
			ctaDebe = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.REGISTRO_TRANSITORIO_DE_BONOS_CUENTA_DEBE);
			if (ctaDebe == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Numero de Cuenta DEBE del credito."));
				return; // Detiene la ejecución aquí
			}

			ctaHaber = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.REGISTRO_TRANSITORIO_DE_BONOS_CUENTA_HABER);
			if (ctaHaber == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Numero de Cuenta HABER del credito."));
				return; // Detiene la ejecución aquí
			}

			// abre la ventana emergente con el formulario de registro transitorio de
			// garantia
			PrimeFaces.current().executeScript(
					"PF('dlgNuevoRegistroTransitorio').show();  document.getElementById('frmDialogRegTransitorio:notaSolicitud').focus();");

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void generarComprobante() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {

			Log.Info("Inicio generarComprobante  REGISTRO TRANSITORIO DE GARANTIAS usr: " + usuario.getLogin()
					+ ", IP: " + UtilWeb.getIPRemoto() + " cred: " + itemActual.getId().getPreCodcred()
					+ " a fecha (devengado) " + fecha2.toString() + " en fecha " + new Date().toString());

			// int id =preDesembBLLocal.getIdNewId();
			/**
			 * CODIGO PARA REGISTRO DE DATOS EN LA TABLA d_creditos.pre_registrogarantias
			 **/
			preRegistrogarantias.setCodcred(itemActual.getId().getPreCodcred());
			preRegistrogarantias.setCodmod(itemActual.getId().getPreCodmod());			
			preRegistrogarantias.setCoddsb(itemActualPreD);
			preRegistrogarantias.setFecha(new Date());
			preRegistrogarantias.setValorTotalGarantia(valorGarantia);

			preRegistrogarantias.setCantidadBonos(totalBonos);
			preRegistrogarantias.setNumeroDesembolso(numeroDesembolso);
			preRegistrogarantias.setEstado(Cttes.ESTOPER_PEND);

			preRegistrogarantias.setAuditUsuario(usuario.getLogin());
			preRegistrogarantias.setAuditFechahora(new Timestamp(new Date().getTime()));
			preRegistrogarantias.setAuditHost(UtilWeb.getIPRemoto());

			preRegistrogarantias.setAuditUsuarioGenera(usuario.getLogin());
			preRegistrogarantias.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			preRegistrogarantias.setAuditHostGenera(UtilWeb.getIPRemoto());
			preRegistrogarantias.setRggCodcmp(Cttes.REGISTRO_TRANSITORIO_DE_GARANTIAS);
			preRegistrogarantiasBLLocal.persist(preRegistrogarantias, usuario.getLogin());

			/** codigo para generar comprobante **/

			// obtenemos el numero corto
			nombreCorto = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.DESCRIPCION_CORTA_CREDITO);
			if (nombreCorto == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Nombre Corto del credito."));
				return; // Detiene la ejecución aquí
			}

			// obtenemos la glosa con las variables obtenidas lineas arriba
			String resultadoGlosa = parametroGlosa
					.replace("#P1", String.valueOf(totalBonos))
					.replace("#P2", numeroSerie)
					.replace("#P3", String.valueOf(numeroDesembolso))
					.replace("#P4", nombreCorto)
					.replace("#P5", preRegistrogarantias.getNotaSolicitud().trim())
					.replace("#P6", preRegistrogarantias.getNumeroTramite().trim())
					.replace("#P7", itemActual.getPreNumresol().trim())
					.replace("#P8", itemActual.getPreNumcontra().trim());

			Log.Info("glosa " + resultadoGlosa);

			preRegistrogarantias.setGlosaCoin(resultadoGlosa);
			/** codigo para generar el numero de comprobante en el COIN **/

			preRegistrogarantias = preRegistrogarantiasBLLocal.generarCmpbRegGar(preRegistrogarantias,
					usuario.getLogin(), UtilWeb.getIPRemoto());

			// recarga la tabla
			iniciarVerDesembolsos();

			PrimeFaces.current().executeScript("PF('dlgNuevoRegistroTransitorio').hide();");

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de generación de comprobante COIN ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Info(
					"generarComprobante|| Se genero excepcion al generar el comprobante en COIN, cancelamos el registro");
			preRegistrogarantias.setEstado(Cttes.ESTOPER_CANC);
			preRegistrogarantias.setAuditUsuario(usuario.getLogin());
			preRegistrogarantias.setAuditFechahora(new Timestamp(new Date().getTime()));
			preRegistrogarantias.setAuditHost(UtilWeb.getIPRemoto());
			try {
				preRegistrogarantiasBLLocal.merge(preRegistrogarantias, usuario.getLogin());
				preRegistrogarantias = new PreRegistrogarantias();
				PrimeFaces.current().executeScript("PF('dlgNuevoRegistroTransitorio').hide();");
				// recarga la tabla
				iniciarVerDesembolsos();
			} catch (Exception e1) {
				e.getMessage();
			}

			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error al generar el comprobante: ",
					UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
		return;
	}

	public Integer verificarEstado(Integer codcred, Integer codmod, Integer coddsb) throws OperationException {
		this.existeRegistroTransGarantiaAutorizado = Boolean.FALSE;
		Integer valor = preRegistrogarantiasBLLocal.getEstadoGarantia(codcred, codmod, coddsb);

		if (valor != null && valor.intValue() == 3) {// 3=estado autorizado
			this.existeRegistroTransGarantiaAutorizado = Boolean.TRUE;
		}
		return valor;

	}

	public Date getFechaPuestaProduccion() throws OperationException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // Formato de la fecha

		try {
			Date fechaProduccion = sdf.parse(Cttes.FECHA_REGISTRO_TRANSITORIO_GARANTIAS); // Convertir String a Date
			// Log.Info("Fecha puesta produccion: " + fechaProduccion);
			return fechaProduccion;
		} catch (ParseException e) {
			// Manejo de excepciones
		}

		return new Date();
	}

	public void cargarDetallesRegistro(PreDesemb opedsb) {
		if (opedsb != null && opedsb.getDsbCoddsb() != null) {
			try {
				this.itemActualPreD = opedsb;

				/** Codigo para obtener el Numero de DEBE y HABER **/
				ctaDebe = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.REGISTRO_TRANSITORIO_DE_BONOS_CUENTA_DEBE);
				if (ctaDebe == "") {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No esta registrado el Numero de Cuenta DEBE del credito."));
					return; // Detiene la ejecución aquí
				}

				ctaHaber = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(),
						Cttes.REGISTRO_TRANSITORIO_DE_BONOS_CUENTA_HABER);
				if (ctaHaber == "") {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No esta registrado el Numero de Cuenta HABER del credito."));
					return; // Detiene la ejecución aquí
				}

				// preRegistrogarantias =
				// preRegistrogarantiasService.findByCoddsb(opedsb.getDsbCoddsb());
				preRegistrogarantias = preRegistrogarantiasBLLocal.obtenerPorCodDesembolso(opedsb.getDsbCoddsb());

				Log.Info("preRegistrogarantias ->" + preRegistrogarantias);
			} catch (Exception e) {
				// Manejo de excepciones, puedes registrar el error o mostrar un mensaje
				// O usa un logger
			}
		}
	}

	public PreRegistrogarantias getPreRegistrogarantias() {
		return preRegistrogarantias;
	}

	public void preAutorizarRegistroTransitorio(PreRegistrogarantias itemActual) {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = preRegistrogarantias.getId();
			/** CODIGO PARA PREAUTORIZAR COMPROBANTE **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(preRegistrogarantias.getId(),
					Cttes.REGISTRO_TRANSITORIO_DE_GARANTIAS,
					preRegistrogarantias.getCodcred(),
					preRegistrogarantias.getCodmod(),
					Cttes.PREAUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());

			preRegistrogarantias = preRegistrogarantiasBLLocal.get(id);
			FacesMessage message;

			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante PREAUTORIZADO satisfactoriamente", "");
			PrimeFaces.current().executeScript("PF('dlgDetallesRegistro').hide();");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void autorizarRegistroTransitorio(PreRegistrogarantias itemActual) {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = preRegistrogarantias.getId();
			/** CODIGO PARA AUTORIZAR COMPROBANTE **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(preRegistrogarantias.getId(),
					Cttes.REGISTRO_TRANSITORIO_DE_GARANTIAS,
					preRegistrogarantias.getCodcred(),
					preRegistrogarantias.getCodmod(),
					Cttes.AUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message;
			preRegistrogarantias = preRegistrogarantiasBLLocal.get(id);
			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante AUTORIZADO satisfactoriamente", "");

			PrimeFaces.current().executeScript("PF('dlgDetallesRegistro').hide();");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void rechazarComprobante() {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = preRegistrogarantias.getId();
			/** CODIGO PARA RECHAZAR COMPROBANTE **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(preRegistrogarantias.getId(),
					Cttes.REGISTRO_TRANSITORIO_DE_GARANTIAS,
					preRegistrogarantias.getCodcred(),
					preRegistrogarantias.getCodmod(),
					Cttes.RECHAZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());
			preRegistrogarantias = preRegistrogarantiasBLLocal.get(id);
			FacesMessage message;
			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante RECHAZADO satisfactoriamente", "");

			PrimeFaces.current().executeScript("PF('dlgDetallesRegistro').hide();");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void registroCustodiaGarantia(PreDesemb desembolso, Integer nroCorrelativo) {

		preRegistrogarantias = new PreRegistrogarantias();

		Log.Info("Ingresa a método registroCustodiaGarantia.");

		try {
			this.itemActualPreD = desembolso;
			this.nroDesembolso = nroCorrelativo;
			Log.Info("itemmActuall===== " + itemActual.toString());

			// Lógica del método
			Log.Info("valor de itemActual " + itemActual);
			Log.Info("valor de itemActualPreD " + itemActualPreD);

			/**
			 * codigo para obtener el parametro de la glosa de la tabla gen_comprobante de
			 * CUSTODIA
			 **/

			ParamsComprobante = preRegistrogarantiasBLLocal
					.getParametrosGlosa(Cttes.REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA);
			for (Object[] result : ParamsComprobante) {
				numeroCentro = (int) result[2];
				tipoComprobante = (String) result[3];
				parametroGlosaCustodiaGarantia = (String) result[4];
			}

			/** Codigo para obtener el cantidad total de desembolsos **/
			numeroDesembolso = preRegistrogarantiasBLLocal.getNumeroTotalDesembolso(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod());
			if (numeroDesembolso == 0) { // verifica si existen desembolsos =0
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No existen desembolsos Registrados, Preautorizados/Autorizados."));
				return; // Detiene la ejecución aquí
			}

			/**
			 * Codigo para obtener los valores de total de bonos y total valor de la
			 * garantia
			 **/
			totalBonosValorGarantia = prePlanpagosLocal.getTotalBonoValorGarantia(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
					itemActualPreD.getDsbCoddsb());
			for (Object[] result : totalBonosValorGarantia) {
				totalBonos = ((Number) result[0]).intValue();
				valorGarantia = (BigDecimal) result[1];
			}

			if (totalBonos == 0) { // verifica si existen desembolsos =0
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No existen registrados Planes de Pago por Desembolso."));
				return; // Detiene la ejecución aquí
			}

			/** Codigo para obtener el Numero de Serie del desembolso **/
			numeroSerie = preRegistrogarantiasBLLocal.getNumeroSerieGarantia(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
					itemActualPreD.getDsbCoddsb());
			if (numeroSerie == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Numero de Serie de la garantía."));
				return; // Detiene la ejecución aquí
			}

			/** Codigo para obtener el Numero de DEBE y HABER **/

			ctaDebe = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_DEBE);
			if (ctaDebe == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Numero de Cuenta DEBE del credito."));
				return; // Detiene la ejecución aquí
			}

			ctaHaber = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_HABER);
			if (ctaHaber == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Numero de Cuenta HABER del credito."));
				return; // Detiene la ejecución aquí
			}

			// abre la ventana emergente con el formulario de registro transitorio de
			// garantia
			PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteCustodiaGarantia').show()");

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void guardarCustodiaGarantia() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

			Log.Info("Inicio guardarCustodiaGarantia  usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred() + " a fecha (devengado) " + fecha2.toString()
					+ " en fecha " + new Date().toString());

			itemActualCustodiaGarantia.setCodcred(itemActualPreD.getDsbCodcred());
			itemActualCustodiaGarantia.setCodmod(itemActualPreD.getDsbCodmod());
			itemActualCustodiaGarantia.setFecha(new Date());
			itemActualCustodiaGarantia.setValorTotalGarantia(this.valorGarantia);
			itemActualCustodiaGarantia.setEstado(Cttes.ESTOPER_PEND);
			itemActualCustodiaGarantia.setAuditUsuario(usuario.getLogin());
			itemActualCustodiaGarantia.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualCustodiaGarantia.setAuditHost(UtilWeb.getIPRemoto());
			itemActualCustodiaGarantia.setAuditUsuarioGenera(usuario.getLogin());
			itemActualCustodiaGarantia.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			itemActualCustodiaGarantia.setAuditHostGenera(UtilWeb.getIPRemoto());
			itemActualCustodiaGarantia.setDsbCoddsb(itemActualPreD);
			itemActualCustodiaGarantia.setCugCodcmp(Cttes.REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA);
			preCustodiaGarantiaBLLocal.persist(itemActualCustodiaGarantia, usuario.getLogin());
			Log.Info("Registro guardado:" + itemActualCustodiaGarantia.getId().toString());

			generarComprobanteCustodiaGarantia();

			// recarga la tabla
			iniciarVerDesembolsos();

			PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteCustodiaGarantia').hide();");

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
		return;
	}

	public void generarComprobanteCustodiaGarantia() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {
			Log.Info("Inicio generarComprobante  REGISTRO CONTROBANTE CUSTODIA DE GARANTIA usr: " + usuario.getLogin()
					+ ", IP: " + UtilWeb.getIPRemoto() + " cred: " + itemActual.getId().getPreCodcred() + " en fecha "
					+ new Date().toString());

			// obtenemos el nombre corto
			nombreCorto = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.DESCRIPCION_CORTA_CREDITO);
			if (nombreCorto == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Nombre Corto del credito."));
				return; // Detiene la ejecución aquí
			}

			// obtenemos la glosa con las variables obtenidas lineas arriba
			// INGRESO A CUSTODIA DE #P1 BTS CUOTAS #P2 - #P3 POR EL #P4 DESEMB. A #P5 POR
			// BS. #P6 CLAVE DE SERIE #P7 SG. ACTA DE DEP. #P8 EN EL MARCO DE LA RD #P9,
			// CONT. #P10.
			String resultadoGlosa = parametroGlosaCustodiaGarantia
					.replace("#P1", String.valueOf(totalBonos))
					.replace("#P2", String.valueOf(numeroDesembolso))
					.replace("#P3", nombreCorto)
					.replace("#P4", formatearMonto(itemActualPreD.getDsbValor()))
					.replace("#P5", numeroSerie)
					.replace("#P6", this.itemActualCustodiaGarantia.getActaDeposito())
					.replace("#P7", itemActual.getPreNumresol().trim())
					.replace("#P8", itemActual.getPreNumcontra().trim());

			Log.Info("glosa " + resultadoGlosa);
			Log.Info("numero contrato " + itemActual.getPreNumcontra().trim());
			itemActualCustodiaGarantia.setGlosaCoin(resultadoGlosa);
			/** codigo para generar el numero de comprobante en el COIN **/
			itemActualCustodiaGarantia = preRegistrogarantiasBLLocal.generarCmpbCustGar(itemActualCustodiaGarantia,
					usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de generación de comprobante COIN ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Info(
					"generarComprobanteCustodiaGarantia|| Se genero excepcion al generar el comprobante en COIN custodia garantia, cancelamos el registro");
			itemActualCustodiaGarantia.setEstado(Cttes.ESTOPER_CANC);
			itemActualCustodiaGarantia.setAuditUsuario(usuario.getLogin());
			itemActualCustodiaGarantia.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualCustodiaGarantia.setAuditHost(UtilWeb.getIPRemoto());
			try {
				preCustodiaGarantiaBLLocal.merge(itemActualCustodiaGarantia, usuario.getLogin());
				itemActualCustodiaGarantia = new PreCustodiaGarantia();
				PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteCustodiaGarantia').hide();");
				// recarga la tabla
				iniciarVerDesembolsos();
			} catch (Exception e1) {
				e.getMessage();
			}

			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Error",
					"Se generó excepción al generar el comprobante de custodía garantia en COIN, cancelaremos el registro.");
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
		return;
	}

	public static String formatearMonto(BigDecimal valor) {
		DecimalFormatSymbols symbols = new DecimalFormatSymbols();
		symbols.setGroupingSeparator('.');
		symbols.setDecimalSeparator(',');

		DecimalFormat formateador = new DecimalFormat("#,##0.00", symbols);
		return formateador.format(valor);
	}

	public String recuperarDescripcionEstado(Integer pEstado) {
		switch (pEstado) {
			case 1:
				return "REGISTRADO";
			case 2:
				return "PREAUTORIZADO";
			case 3:
				return "AUTORIZADO";
			default:
				return null;
		}
	}

	public Integer verificarEstadoCustodiaGarantia(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {

		Integer valor = preCustodiaGarantiaBLLocal.getEstadoCustodiaGarantia(codcred, codmod, coddsb);
		return valor;

	}

	public void cargarDetallesCustodiaGarantia(PreDesemb opedsb) {
		if (opedsb != null && opedsb.getDsbCoddsb() != null) {
			try {
				Log.Info("itemActual==== " + itemActual.toString());
				this.descProyecto = itemActual.getPreDescrip();
				this.itemActualPreD = opedsb;
				itemActualCustodiaGarantia = preCustodiaGarantiaBLLocal.obtenerPorCodDesembolso(opedsb.getDsbCoddsb());
				Log.Info("itemActualCustodiaGarantia ->" + itemActualCustodiaGarantia);

				/** Codigo para obtener el cantidad total de desembolsos **/
				numeroDesembolso = preRegistrogarantiasBLLocal.getNumeroTotalDesembolso(
						itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod());
				if (numeroDesembolso == 0) { // verifica si existen desembolsos =0
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No existen desembolsos Registrados, Preautorizados/Autorizados."));
					return; // Detiene la ejecución aquí
				}

				/**
				 * Codigo para obtener los valores de total de bonos y total valor de la
				 * garantia
				 **/
				totalBonosValorGarantia = prePlanpagosLocal.getTotalBonoValorGarantia(
						itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
						itemActualPreD.getDsbCoddsb());
				for (Object[] result : totalBonosValorGarantia) {
					totalBonos = ((Number) result[0]).intValue();
					valorGarantia = (BigDecimal) result[1];
				}

				if (totalBonos == 0) { // verifica si existen desembolsos =0
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No existen registrados Planes de Pago por Desembolso."));
					return; // Detiene la ejecución aquí
				}

				/** Codigo para obtener el Numero de Serie del desembolso **/
				numeroSerie = preRegistrogarantiasBLLocal.getNumeroSerieGarantia(
						itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
						itemActualPreD.getDsbCoddsb());
				if (numeroSerie == "") {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No esta registrado el Numero de Serie de la garantía."));
					return; // Detiene la ejecución aquí
				}

				/** Codigo para obtener el Numero de DEBE y HABER **/

				ctaDebe = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(),
						Cttes.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_DEBE);
				if (ctaDebe == "") {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No esta registrado el Numero de Cuenta DEBE del credito."));
					return; // Detiene la ejecución aquí
				}

				ctaHaber = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(),
						Cttes.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_HABER);
				if (ctaHaber == "") {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No esta registrado el Numero de Cuenta HABER del credito."));
					return; // Detiene la ejecución aquí
				}

			} catch (Exception e) {
				// Manejo de excepciones, puedes registrar el error o mostrar un mensaje
				// O usa un logger
			}
		}
	}

	public void preAutorizarRegistroCustodiaGarantia() {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = itemActualCustodiaGarantia.getId();
			/** CODIGO PARA PREAUTORIZAR COMPROBANTE CUSTODIA GARANTIA **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualCustodiaGarantia.getId(),
					Cttes.REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA, itemActualCustodiaGarantia.getCodcred(),
					itemActualCustodiaGarantia.getCodmod(),
					Cttes.PREAUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message;
			itemActualCustodiaGarantia = preCustodiaGarantiaBLLocal.get(id);
			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante PREAUTORIZADO satisfactoriamente", "");

			// recarga la tabla
			iniciarVerDesembolsos();
			PrimeFaces.current().executeScript("PF('dlgDetalleComprobanteCustodiaGarantia').hide();");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void autorizarRegistroCustodiaGarantia() {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = itemActualCustodiaGarantia.getId();
			/** CODIGO PARA AUTORIZAR COMPROBANTE CUSTODIA GARANTIA **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualCustodiaGarantia.getId(),
					Cttes.REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA, itemActualCustodiaGarantia.getCodcred(),
					itemActualCustodiaGarantia.getCodmod(),
					Cttes.AUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message;
			itemActualCustodiaGarantia = preCustodiaGarantiaBLLocal.get(id);

			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante AUTORIZADO satisfactoriamente", "");

			// recarga la tabla
			iniciarVerDesembolsos();

			PrimeFaces.current().executeScript("PF('dlgDetalleComprobanteCustodiaGarantia').hide();");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void rechazarComprobanteRegistroCustodiaGarantia() {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = itemActualCustodiaGarantia.getId();
			/** CODIGO PARA RECHAZAR COMPROBANTE CUSTODIA GARANTIA **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualCustodiaGarantia.getId(),
					Cttes.REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA, itemActualCustodiaGarantia.getCodcred(),
					itemActualCustodiaGarantia.getCodmod(),
					Cttes.RECHAZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message;
			itemActualCustodiaGarantia = preCustodiaGarantiaBLLocal.get(id);

			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante RECHAZADO satisfactoriamente", "");

			// recarga la tabla
			iniciarVerDesembolsos();

			PrimeFaces.current().executeScript("PF('dlgDetalleComprobanteCustodiaGarantia').hide();");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public Integer verificarTipoCliente(PrePrestamos item) throws OperationException {
		Integer valor = 0;
		if (item.getPreCodcli().intValue() == Cttes.YACIMIENTOS_PETROLIFEROS_FISCALES_BOLIVIANOS ||
				item.getPreCodcli().intValue() == Cttes.FONDO_NACIONAL_DE_DESARROLLO_REGIONAL) {
			valor = 0;
		} else {
			valor = 1;
		}
		return valor;

	}

	public Integer verificarEstadoRetiroGarantia(Integer codcred, Integer codmod, Integer coddsb, Date fechaVencimiento)
			throws OperationException {
		Integer valor = preRetiroGarantiaBLLocal.getEstadoRetiroGarantia(codcred, codmod, coddsb);

		return valor;

	}

	public void registroRetiroGarantia(PreDesemb desembolso, Integer nroCorrelativo) {

		preRegistrogarantias = new PreRegistrogarantias();

		Log.Info("Ingresa a método registroRetiroGarantia.");

		try {
			this.itemActualPreD = desembolso;
			this.nroDesembolso = nroCorrelativo;

			// Lógica del método
			Log.Info("valor de itemActualPreD " + itemActualPreD);

			/**
			 * codigo para obtener el parametro de la glosa de la tabla gen_comprobante de
			 * RETIRO
			 **/

			ParamsComprobante = preRegistrogarantiasBLLocal
					.getParametrosGlosa(Cttes.REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA);
			for (Object[] result : ParamsComprobante) {
				numeroCentro = (int) result[2];
				tipoComprobante = (String) result[3];
				parametroGlosaCustodiaGarantia = (String) result[4];
			}

			/** Codigo para obtener el Numero de Serie del desembolso **/
			numeroSerie = preRegistrogarantiasBLLocal.getNumeroSerieGarantia(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
					itemActualPreD.getDsbCoddsb());
			if (numeroSerie == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Numero de Serie de la garantía."));
				return; // Detiene la ejecución aquí
			}

			/**
			 * Codigo para obtener los valores de total de bonos y total valor de la
			 * garantia
			 **/
			totalBonosValorGarantia = prePlanpagosLocal.getTotalBonoValorGarantia(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
					itemActualPreD.getDsbCoddsb());
			for (Object[] result : totalBonosValorGarantia) {
				totalBonos = ((Number) result[0]).intValue();
				valorGarantia = (BigDecimal) result[1];
			}

			/** Codigo para obtener el Numero de cuenta del DEBE y HABER para el retiro **/
			ctaDebe = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_DEBE);
			if (ctaDebe == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Numero de Cuenta DEBE del credito."));
				return; // Detiene la ejecución aquí
			}

			ctaHaber = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_HABER);
			if (ctaHaber == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Numero de Cuenta HABER del credito."));
				return; // Detiene la ejecución aquí
			}

			/**
			 * Codigo para recuperar las fechas de vencimiento y monto del valor de la cuota
			 **/
			listPrePlanpagosDSBPorGestion = prePlanpagosLocal.mostrarPlanDePagosPorGestionSinCancelar(
					this.itemActualPreD.getDsbCodcred(),
					this.itemActualPreD.getDsbCodmod(), this.itemActualPreD.getDsbCoddsb(), LocalDate.now().getYear());

			this.itemActualRetiroGarantia = new PreRetiroGarantia();
			this.fechaVencimientoSeleccionado = null;

			// abre la ventana emergente con el formulario de retiro de garantia
			PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteRetiroGarantia').show()");

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void guardarRetiroGarantia() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			Log.Info("Inicio guardarRetiroGarantia  usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred() + " a fecha (devengado) " + fecha2.toString()
					+ " en fecha " + new Date().toString());

			Log.Info("guardarRetiroGarantia|| antes de guardar verificamos si no tiene un registro para Coddsb:"
					+ itemActualPreD.getDsbCoddsb() + ", Codcred: " + itemActualPreD.getDsbCodcred() + ", Codmod: "
					+ itemActualPreD.getDsbCodmod() + ", fecha vencimiento: "
					+ sdf.parse(this.fechaVencimientoSeleccionado));
			Boolean existeRetiro = preRetiroGarantiaBLLocal.tieneRetiroGarantia(itemActualPreD.getDsbCodcred(),
					itemActualPreD.getDsbCodmod(), itemActualPreD.getDsbCoddsb(),
					sdf.parse(this.fechaVencimientoSeleccionado));
			if (existeRetiro) {
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Advertencia",
						"Ya existe un registro de retiro de garantía para la fecha de vencimiento "
								+ this.fechaVencimientoSeleccionado);
				FacesContext.getCurrentInstance().addMessage(null, message);
				return;
			}

			Log.Info(
					"guardarRetiroGarantia|| validamos que el valor total de la garantía sea mayor a cero (eso porque puede hacer períodos de gracia donde si hay interes pero el pago es cero) ");
			if (itemActualRetiroGarantia.getValorCuota().equals(BigDecimal.ZERO)) {
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Advertencia",
						"El valor total de la garantía es cero. Por favor, revise el plan de pagos.");
				FacesContext.getCurrentInstance().addMessage(null, message);
				return;
			}

			Log.Info(
					"guardarRetiroGarantia|| validamos que no exista un nro de serie para un comprobante distinto de) ");
			Boolean existeNroSerie = preRetiroGarantiaBLLocal.existeNroClaveSerie(this.numeroSerie);
			if (existeNroSerie) {
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Advertencia",
						"Ya fue generado un comprobante de pago para el Nro.de serie " + this.numeroSerie);
				FacesContext.getCurrentInstance().addMessage(null, message);
				return;
			}

			itemActualRetiroGarantia.setCodcred(itemActualPreD.getDsbCodcred());
			itemActualRetiroGarantia.setCodmod(itemActualPreD.getDsbCodmod());
			itemActualRetiroGarantia.setFecha(new Date());
			itemActualRetiroGarantia.setNroClaveSerie(this.numeroSerie);
			itemActualRetiroGarantia.setFechaVencimiento(sdf.parse(this.fechaVencimientoSeleccionado));
			itemActualRetiroGarantia.setEstado(Cttes.ESTOPER_PEND);
			itemActualRetiroGarantia.setAuditUsuario(usuario.getLogin());
			itemActualRetiroGarantia.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualRetiroGarantia.setAuditHost(UtilWeb.getIPRemoto());
			itemActualRetiroGarantia.setAuditUsuarioGenera(usuario.getLogin());
			itemActualRetiroGarantia.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			itemActualRetiroGarantia.setAuditHostGenera(UtilWeb.getIPRemoto());
			itemActualRetiroGarantia.setCoddsb(itemActualPreD);
			itemActualRetiroGarantia.setRtgCodcmp(Cttes.REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA);
			preRetiroGarantiaBLLocal.persist(itemActualRetiroGarantia, usuario.getLogin());
			Log.Info("Registro guardado:" + itemActualRetiroGarantia.getId().toString());

			generarComprobanteRetiroGarantia();

			// recarga la tabla
			iniciarVerDesembolsos();

			PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteRetiroGarantia').hide();");
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
		return;
	}

	public void generarComprobanteRetiroGarantia() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {
			Log.Info("Inicio generarComprobante  REGISTRO CONTROBANTE RETIRO DE GARANTIA usr: " + usuario.getLogin()
					+ ", IP: " + UtilWeb.getIPRemoto() + " cred: " + itemActual.getId().getPreCodcred() + " en fecha "
					+ new Date().toString());

			// obtenemos el nombre corto
			nombreCorto = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.DESCRIPCION_CORTA_CREDITO);
			if (nombreCorto == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Nombre Corto del credito."));
				return; // Detiene la ejecución aquí
			}

			LocalDate localDateFechaSeleccionada = LocalDate.parse(fechaVencimientoSeleccionado,
					DateTimeFormatter.ofPattern("dd-MM-yyyy"));
			// Formatear a dd-MM-yyyy
			String fechaVencimientoFormateada = localDateFechaSeleccionada
					.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));

			// obtenemos la glosa con las variables obtenidas lineas arriba
			// RETIRO DE CUSTODIA DEL BT CON LA CLAVE DE SERIE #P1 CUOTA #P2 FECHA DE VCTO
			// #P3 ACTA DE RETIRO #P4, DEL #P5° DESEMB. DEL CRED. #P6 POR BS. #P7 EN EL
			// MARCO DE LA RD. #P8, CONT. #P9 Y DOC. ADJ.
			String resultadoGlosa = parametroGlosaCustodiaGarantia
					.replace("#P1", numeroSerie)
					.replace("#P2", String.valueOf(itemActualRetiroGarantia.getCuota()))
					.replace("#P3", fechaVencimientoFormateada)
					.replace("#P4", itemActualRetiroGarantia.getActaRetiro())
					.replace("#P5", String.valueOf(this.nroDesembolso))
					.replace("#P6", nombreCorto)
					.replace("#P7", formatearBigDecimal(this.itemActualPreD.getDsbValor()))
					.replace("#P8", itemActual.getPreNumresol().trim())
					.replace("#P9", itemActual.getPreNumcontra().trim());

			Log.Info("glosa " + resultadoGlosa);
			itemActualRetiroGarantia.setGlosaCoin(resultadoGlosa);
			/** codigo para generar el numero de comprobante en el COIN **/
			itemActualRetiroGarantia = preRegistrogarantiasBLLocal.generarCmpbRetGar(itemActualRetiroGarantia,
					usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de generación de comprobante COIN ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			Log.Info(
					"generarComprobanteRetiroGarantia|| Se genero excepcion al generar el comprobante en COIN retiro garantia, cancelamos el registro");
			itemActualRetiroGarantia.setEstado(Cttes.ESTOPER_CANC);
			itemActualRetiroGarantia.setAuditUsuario(usuario.getLogin());
			itemActualRetiroGarantia.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualRetiroGarantia.setAuditHost(UtilWeb.getIPRemoto());
			try {
				preRetiroGarantiaBLLocal.merge(itemActualRetiroGarantia, usuario.getLogin());
				itemActualRetiroGarantia = new PreRetiroGarantia();
				PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteRetiroGarantia').hide();");
				// recarga la tabla
				iniciarVerDesembolsos();
			} catch (Exception e1) {
				e1.getMessage();
				Log.Info("excepcion en el segundo catch:: " + e1.getMessage());
			}

			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Error",
					"Se generó excepción al generar el comprobante de retiro garantia en COIN, cancelaremos el registro.");
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
		return;
	}

	public static String formatearBigDecimal(BigDecimal valor) {
		DecimalFormatSymbols symbols = new DecimalFormatSymbols();
		symbols.setGroupingSeparator('.');
		symbols.setDecimalSeparator(',');

		DecimalFormat formateador = new DecimalFormat("#,##0.00", symbols);
		return formateador.format(valor);
	}

	public void actualizarValorCuota() {

		if (fechaVencimientoSeleccionado.equals("0")) {
			itemActualRetiroGarantia.setValorCuota(null);
			return;
		}

		for (PlanPagoDto plan : listPrePlanpagosDSBPorGestion) {
			if (plan.getFechaVencimientoCuota().equals(this.fechaVencimientoSeleccionado)) {
				itemActualRetiroGarantia.setValorCuota(plan.getCuota());
				break;
			}
		}
	}

	public void rechazarComprobanteRegistroRetiroGarantia() {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = itemActualRetiroGarantia.getId();
			/** CODIGO PARA RECHAZAR COMPROBANTE RETIRO GARANTIA **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualRetiroGarantia.getId(),
					Cttes.REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA, itemActualRetiroGarantia.getCodcred(),
					itemActualRetiroGarantia.getCodmod(),
					Cttes.RECHAZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message;
			itemActualRetiroGarantia = preRetiroGarantiaBLLocal.get(id);
			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante RECHAZADO satisfactoriamente", "");

			// recarga la tabla
			iniciarVerDesembolsos();

			PrimeFaces.current().executeScript("PF('dlgDetalleComprobanteRetiroGarantia').hide();");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error cancelar retiro",
					UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void preAutorizarRegistroRetiroGarantia() {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = itemActualRetiroGarantia.getId();
			/** CODIGO PARA PREAUTORIZAR COMPROBANTE RETIRO GARANTIA **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualRetiroGarantia.getId(),
					Cttes.REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA, itemActualRetiroGarantia.getCodcred(),
					itemActualRetiroGarantia.getCodmod(),
					Cttes.PREAUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message;
			itemActualRetiroGarantia = preRetiroGarantiaBLLocal.get(id);
			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante PREAUTORIZADO satisfactoriamente", "");

			// recarga la tabla
			iniciarVerDesembolsos();
			PrimeFaces.current().executeScript("PF('dlgDetalleComprobanteRetiroGarantia').hide();");
			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error preautorizacion retiro",
					UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void autorizarRegistroRetiroGarantia() {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = itemActualRetiroGarantia.getId();
			/** CODIGO PARA AUTORIZAR COMPROBANTE RETIRO GARANTIA **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualRetiroGarantia.getId(),
					Cttes.REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA, itemActualRetiroGarantia.getCodcred(),
					itemActualRetiroGarantia.getCodmod(),
					Cttes.AUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message;
			itemActualRetiroGarantia = preRetiroGarantiaBLLocal.get(id);
			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante AUTORIZADO satisfactoriamente", "");

			// recarga la tabla
			iniciarVerDesembolsos();

			PrimeFaces.current().executeScript("PF('dlgDetalleComprobanteRetiroGarantia').hide();");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error autorizar retiro ",
					UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void cargarDetallesRetiroGarantia(PreDesemb desembolso, Integer nroCorrelativo) {
		if (desembolso != null && desembolso.getDsbCoddsb() != null) {
			preRegistrogarantias = new PreRegistrogarantias();

			Log.Info("Ingresa a método registroRetiroGarantia.");

			try {
				this.itemActualPreD = desembolso;
				this.nroDesembolso = nroCorrelativo;
				itemActualRetiroGarantia = preRetiroGarantiaBLLocal.obtenerPorCodDesembolso(desembolso.getDsbCoddsb());
				Log.Info("itemActualRetiroGarantia ->" + itemActualRetiroGarantia);
				// Lógica del método
				Log.Info("valor de itemActualPreD " + itemActualPreD);

				/**
				 * codigo para obtener el parametro de la glosa de la tabla gen_comprobante de
				 * RETIRO
				 **/

				ParamsComprobante = preRegistrogarantiasBLLocal
						.getParametrosGlosa(Cttes.REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA);
				for (Object[] result : ParamsComprobante) {
					numeroCentro = (int) result[2];
					tipoComprobante = (String) result[3];
					parametroGlosaCustodiaGarantia = (String) result[4];
				}

				/** Codigo para obtener el Numero de Serie del desembolso **/
				numeroSerie = preRegistrogarantiasBLLocal.getNumeroSerieGarantia(
						itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
						itemActualPreD.getDsbCoddsb());
				if (numeroSerie == "") {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No esta registrado el Numero de Serie de la garantía."));
					return; // Detiene la ejecución aquí
				}

				/**
				 * Codigo para obtener los valores de total de bonos y total valor de la
				 * garantia
				 **/
				totalBonosValorGarantia = prePlanpagosLocal.getTotalBonoValorGarantia(
						itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(),
						itemActualPreD.getDsbCoddsb());
				for (Object[] result : totalBonosValorGarantia) {
					totalBonos = ((Number) result[0]).intValue();
					valorGarantia = (BigDecimal) result[1];
				}

				/** Codigo para obtener el Numero de cuenta del DEBE y HABER para el retiro **/
				ctaDebe = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(),
						Cttes.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_DEBE);
				if (ctaDebe == "") {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No esta registrado el Numero de Cuenta DEBE del credito."));
					return; // Detiene la ejecución aquí
				}

				ctaHaber = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
						itemActual.getPrePrestamosPK().getPreCodmod(),
						Cttes.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_HABER);
				if (ctaHaber == "") {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
							"ERROR", "No esta registrado el Numero de Cuenta HABER del credito."));
					return; // Detiene la ejecución aquí
				}

				/**
				 * Codigo para recuperar las fechas de vencimiento y monto del valor de la cuota
				 **/
				listPrePlanpagosDSBPorGestion = prePlanpagosLocal.mostrarPlanDePagosPorGestionSinCancelar(
						this.itemActualPreD.getDsbCodcred(),
						this.itemActualPreD.getDsbCodmod(), this.itemActualPreD.getDsbCoddsb(),
						LocalDate.now().getYear());

			} catch (Exception e) {
				Log.Error(e);
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
				FacesContext.getCurrentInstance().addMessage(null, message);

			}
		}
	}

} // END CLASS
