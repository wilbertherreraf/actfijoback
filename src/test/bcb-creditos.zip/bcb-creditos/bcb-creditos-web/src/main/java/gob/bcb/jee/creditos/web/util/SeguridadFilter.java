package gob.bcb.jee.creditos.web.util;

import gob.bcb.jee.creditos.entidades.Recurso;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.util.Log;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;

/**
 * Clase de filtro para control de permisos
 */
public class SeguridadFilter implements Filter {


    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        Log.Trace("Iniciando Filtro");
        String urlAcceso = ((HttpServletRequest) request).getRequestURI();
        if (urlAcceso.endsWith(".png") || urlAcceso.endsWith(".jpg") || urlAcceso.endsWith(".css")) {
            chain.doFilter(request, response);
            return;
        }
        if (urlAcceso.endsWith("install.jsf")) {
            chain.doFilter(request, response);
            return;
        }
        if (urlAcceso.endsWith("viewClientes.jsf")) {
            chain.doFilter(request, response);
            return;
        }
        if (urlAcceso.contains("adviceDialog")) {
            chain.doFilter(request, response);
            return;
        }
        if (urlAcceso.contains("modalClientes")) {
            chain.doFilter(request, response);
            return;
        }

        Usuario usuario = (Usuario) UtilWeb.getVariableSessionOfRequest(CttesWeb.VariablesSesion.USUARIO, request);

        if (usuario == null) {
            ((HttpServletResponse) response).sendRedirect(CttesWeb.URL_INDEX);
            return;
        } else {
            if (urlAcceso.endsWith("index.jsf")) {
                chain.doFilter(request, response);
                return;
            }
            if (urlAcceso.endsWith("cambioPassword.jsf")) {
                chain.doFilter(request, response);
                return;
            }
            boolean tieneAcceso = false;
            for (gob.bcb.jee.creditos.entidades.Recurso recurso : usuario.getRecursos()) {
                //Log.Info("==>recurso:" + recurso.getCodRecurso() + " " + Arrays.toString(recurso.getUrl()));
                for (String urlPermiso : recurso.getUrl()) {
                    if (urlAcceso.endsWith(urlPermiso)) {
                        tieneAcceso = true;
                        break;
                    }
                }
                if (tieneAcceso) {
                    break;
                }
                //for (Recurso subRecurso : recurso.getSubRecursos()) {
                    //Log.Info("\tsubrecurso:" + subRecurso.getCodRecurso() + " " + Arrays.toString(subRecurso.getUrl()));
                    for (String urlPermiso : recurso.getUrl()) {
                        if (urlAcceso.toUpperCase().contains(urlPermiso.toUpperCase())) {
                            tieneAcceso = true;
                            break;
                        }
                    }
                //}
                if (tieneAcceso) {
                    break;
                }                
            }
            if (!tieneAcceso) {
                ((HttpServletResponse) response).sendRedirect(CttesWeb.URL_ERROR_NO_AUTORIZADO);
                return;
            }
        }
        chain.doFilter(request, response);
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
    }

}
