/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-plantillaWebEE-web
 * gob.bcb.jee.creditos.plantillaWebEE.web.pages.LoginBean
 * 06/03/2016 - 08:30:00
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.web.pages;


import gob.bcb.jee.axesso.entidades.Participante;
import gob.bcb.jee.axesso.remoto.AgenciaEjbRemoto;
import gob.bcb.jee.creditos.core.comunes.webManage.SessionBean;
import gob.bcb.jee.creditos.entidades.Permiso;
import gob.bcb.jee.creditos.entidades.Recurso;
import gob.bcb.jee.creditos.entidades.Rol;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.remoto.ServicioAxessoRemotoAdapter;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.SeguridadBean;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Managed Bean para autenticar el usuario
 *
 * @author ysalinas
 */

@ManagedBean
@ViewScoped
@Getter
@Setter
public class LoginBean implements Serializable {

    private static final long serialVersionUID = -2441611430737573407L;

    // variables que almacenan el usuario y password
    private String usuario;
    private String password;

    /**
     * objeto que controla las sesiones en la aplicacion
     */
    @ManagedProperty(value = "#{sessionBean}")
    protected SessionBean sessionBean;

    /**
     * objeto que controla las sesiones sobre el TCIABCB
     */
    @ManagedProperty(value = "#{seguridadBean}")
    protected SeguridadBean seguridadBean;

    @Inject
    private ServicioAxessoRemotoAdapter servicioAxessoRemoto;

  /*
   * Inyeccion de EJB's locales
   */

  /*
   * Inyeccion de EJB's remotos
   */
//  private EjbContraseniaRemoto ejbContraseniaRemoto;
//  private ServiciosWebLIPRemoto serviciosWebLIPRemoto;

    private AgenciaEjbRemoto agenciaEjbRemoto;

  /* ************************************************************ */

    /**
     * Constructor por defecto
     */
    public LoginBean() {
    }

    /**
     * Controla el evento de loguear usuario.
     */
    public void eventoLogin() {
        try {
            Log.Info("Validando usuario...");
            //servicioAxessoRemoto.lisUsuariosLike(this.usuario);
            if (this.loginUsrPass(this.usuario, this.password)) {
                // Verificamos si el ususario es vigente
                // TODO: adiciobar validacion de vigencia de password al metodo loginUsrPass
                UtilWeb.redireccionarURL(CttesWeb.URL_INDEX + "/pages/index.jsf?e=true");


                //TODO: Adicionar lógica para cambio de contraseña
//                Log.Trace("Validacion de usuario correcta");
//                log.debug("Ingreso del usuario:" + this.usuario);
//
//                Log.Info("Ingreso del usuario:" + this.usuario);
//                // Verifica si tiene que cambiar contraseña o no
//                if (!this.userChangePassword(this.usuario)) {
//                    Log.Info("Ingreso del usuario pass:" + this.usuario);
//                    // si necesita cambiar contraseña
//                    UtilWeb.redireccionarURL(CttesWeb.URL_CAMBIAR_CONTRASENIA);
//                } else {
//                    if (sessionBean.getUsuarioSesion().getRoles().size() <= 0) {
//                        // si no es usuario de la aplicacion
//                        UtilWeb.redireccionarURL(CttesWeb.URL_ERROR_LOGIN_APLICACION);
//                    } else {
//                        // si no necesita cambiar contraseña
//                        Log.Info("CREA SESION ");
//                        seguridadBean.createSession();
//                        UtilWeb.redireccionarURL("index.jsf");
//                    }
//                }
            } else{
                UtilWeb.redireccionarURL(CttesWeb.URL_CAMBIAR_CONTRASENIA);

            }

        } catch (OperationException e) {
            Log.Error("Error al iniciar sesion en AXESSO"+ e);
            UtilWeb.redireccionarURL(CttesWeb.URL_ERROR_LOGIN);
        } catch (Exception e) {
            Log.Error("Error en la validacion. "+ e);
            UtilWeb.redireccionarURL(CttesWeb.URL_ERROR_LOGIN);
        }
    }


    /**
     * Metodo que realiza la verificacion si el usuario ingresa o no al sistema
     *
     * @param u
     * @param p
     * @return
     * @throws Exception
     */
    private boolean loginUsrPass(String u, String p) throws Exception,
            OperationException {
        Log.Info("Iniciará sesión con usuario " + u);

        // Validando usuario en JAAS
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();

        // Verificar si existe sesiones anteriores y los limpia si es existe
        if (request.getUserPrincipal() != null) {
            request.logout();
        }
        boolean respuesta = false;
        // Inicia sesion JAAS
        try {
            request.login(u, p);
            gob.bcb.jee.axesso.entidades.Usuario usuarioAxesso = servicioAxessoRemoto.getUsuarioByLogin(u);
            Log.Info("Inició sesión JAAS con usuario " + u );
            //Log.Info("Inició sesión JAAS con usuario " + u + " roles " + (usuarioAxesso.getRoles() != null ? usuarioAxesso.getRoles().size() : "ROLES NULO"));            
            
            // genera el objeto de usuario
            Log.Trace("Genera el objet   o de usuario");
            gob.bcb.jee.creditos.entidades.Usuario usuario = new gob.bcb.jee.creditos.entidades.Usuario();
            usuario.setLogin(u);
            usuario.setUsuarioId(usuarioAxesso.getId());
            // generacion de permisos, roles y recursos
            List<Rol> roles = new ArrayList<Rol>();
            List<gob.bcb.jee.axesso.entidades.Rol> rolesUsuarioAxesso = servicioAxessoRemoto.listRolesByUsuario(usuarioAxesso.getId());
            Log.Info("roles de consulta =====>" + rolesUsuarioAxesso.size());
            if (rolesUsuarioAxesso.size() > 0) {
                for (gob.bcb.jee.axesso.entidades.Rol rolAxesso : rolesUsuarioAxesso) {
                    Rol rol = new Rol();
                    rol.setCodigo(rolAxesso.getId().getRolId());
                    rol.setDescripcion(rolAxesso.getDescripcion());
                    List<gob.bcb.jee.axesso.entidades.Recurso> recursosAxesso = servicioAxessoRemoto.listRecursosByRol(rolAxesso.getId().getRolId());
                    List<Recurso> recursos = new ArrayList<Recurso>();
                    //Log.Info("ROOOL buscado " + rolAxesso.getId().getRolId() + " --> recs" + recursosAxesso.size());
                    for (gob.bcb.jee.axesso.entidades.Recurso recursoAxesso : recursosAxesso) {
                        try {
                            Recurso recurso = new Recurso(recursoAxesso.getRecursoPadreId(), gob.bcb.jee.creditos.web.util.Recurso.valueOf
                                    (recursoAxesso.getId().getRecursoId()), recursoAxesso.getDescripcion());
                            //recurso.setNombre(recursoAxesso.getNombre());
                            recurso.setEstado(recursoAxesso.getEstado().getValor());
                            //Log.Info("RECCC buscado padre: " + recurso.getPadre() + " codrec "+ recurso.getCodRecurso() + " --> recuuuuusr ESTADI " + recurso.getEstado());
                            //Log.Info("rol: "+rol.getCodigo() + " recurso: " + recurso.getCodRecurso());
                            //List<gob.bcb.jee.axesso.entidades.Permiso> permisosAxesso = servicioAxessoRemoto.listPermisosByRolAndRecurso(rol.getCodigo(), recurso.getCodRecurso());
                            List<Permiso> permisos = new ArrayList<Permiso>();
                            recurso.setPermisos(permisos);
                            recursos.add(recurso);
                         } catch (Exception e) {
                             Log.Error("El recurso rol-recurso: " +rolAxesso.getId().getRolId() +" - "+ recursoAxesso.getId().getRecursoId() + " no puede ser cargado "+ e.getMessage());
                         }
                    }

                    for (Recurso recurso : recursos) {
                        recurso.setSubRecursos(getSubRecursos(recurso, recursos));
                    }

                    rol.setRecursos(recursos);
                    roles.add(rol);
                }
                usuario.setRoles(roles);
                UtilWeb.setVariableSession(CttesWeb.VariablesSesion.USUARIO, usuario);
                if(servicioAxessoRemoto.isPasswordVigente(usuarioAxesso.getId())){
                    respuesta = true;
                }
            } else {
                String error = "El usuario no tiene acceso al sistema comuniquese con el administrado";
                Log.Error(error);
                throw new Exception(error);
            }
        Log.Info("FIIIIIIIIIIIIIIIIIIIIIIIIN " + u);            
        } catch (OperationException e) {
            Log.Error("Error al consumir el TCIABCB"+e);
            request.logout();
            throw new Exception("Error al consumir el TCIABCB", e);
        } catch (ServletException e) {
            request.logout();
//            EjbUsuarioRemoto ejbUsuarioRemoto;
//
//            try {
//                ejbUsuarioRemoto = UtilRemoto.consumirEJBTCIABCB(EjbUsuarioRemoto.class);
//            } catch (Exception etcia) {
//                throw new Exception("Error en los servicios remotos de TCIABCB. " + etcia.getMessage());
//            }
//
//            // Obteniendo el usuario logueado
//            Usuario usuarioObj = ejbUsuarioRemoto.buscarUsuario(u);
//
//            if (usuarioObj == null) {
//                Log.Error("Usuario ingresado inexistente.", e);
//                throw new Exception("Usuario ingresado inexistente.");
//            }
//            Log.Error("Ocurrio algun error en el servlet de login", e);
            throw new Exception(e);
        } catch (IllegalArgumentException exc) {
            Log.Error("Error en iniciacion sesion"+ exc);
            request.logout();
            throw exc;
        } catch (Exception exc) {
            Log.Error("Error en iniciacion sesion"+ exc);
            request.logout();
            throw new Exception("Usuario ingresado inexistente.");
        }
        return respuesta;
    }



    /**
     * Metodo que realiza la verificacion si un usuario necesita relizar el cambio
     * de contraseña
     *
     * @param usuario -> login de usuario
     * @return true: si necesita cambio, false: no necesita cambio
     */
    private boolean userChangePassword(String usuario) throws Exception {
//    Log.Trace("Iniciando validacion de cambiode contraseña");
//    boolean respuesta = false;
//    try
//    {
//      ejbContraseniaRemoto = UtilRemoto.consumirEJBTCIABCB(EjbContraseniaRemoto.class);
//
//      respuesta = ejbContraseniaRemoto.esUnicaContrasenia(usuario);
//      log.debug("respuesta: " + respuesta);
//    }
//    catch (Exception e)
//    {
//      Log.Error("Error en la verifiacion de cambio de contraseña. " + e.getMessage().toString());
//      
//    }
//    Log.Trace("Fin de validacion de cambio de contraseña");
//    return respuesta;
        return true;
    }


//

    /**
     * Metodo que obtiene los recursos de primer nivel de la lista de TCIA
     *
     * @param recursos
     * @return
     */
    private List<gob.bcb.jee.axesso.entidades.Recurso> getResourceFirstLevel(
            List<gob.bcb.jee.axesso.entidades.Recurso> recursos) {
        List<gob.bcb.jee.axesso.entidades.Recurso> recursosPrimerNivel =
                new ArrayList<gob.bcb.jee.axesso.entidades.Recurso>();
        Set<String> codigoRecursos = new HashSet<String>();
        for (gob.bcb.jee.axesso.entidades.Recurso recurso : recursos) {
            if (recurso.getRecursoPadreId() == null) {
                if (!codigoRecursos.contains(recurso)) {
                    recursosPrimerNivel.add(recurso);
                    codigoRecursos.add(recurso.getId().getRecursoId());
                }
            }
        }
        return recursosPrimerNivel;
    }

    /**
     * Metodo que obtiene la lista de los recursos hijos segun el recurso padre
     *
     * @param recursos
     * @param padre
     * @return
     */
    private List<gob.bcb.jee.axesso.entidades.Recurso> getResourceByParent(
            List<gob.bcb.jee.axesso.entidades.Recurso> recursos, String padre) {
        List<gob.bcb.jee.axesso.entidades.Recurso> recursosPadre = new ArrayList<gob.bcb.jee.axesso.entidades.Recurso>();
        for (gob.bcb.jee.axesso.entidades.Recurso recurso : recursos) {
            if (recurso.getRecursoPadreId().equals(padre)) {
                recursosPadre.add(recurso);
            }
        }
        return recursosPadre;
    }

    public List<Recurso> getSubRecursos(Recurso recursoPadre, List<Recurso> recursos) {
        List<Recurso> recursosHijos = new ArrayList<Recurso>();
        for (Recurso recurso : recursos) {
            if (recursoPadre.getCodRecurso().equals(recurso.getPadre())) {
                recursosHijos.add(recurso);
                recurso.setPadre(recursoPadre.getCodRecurso());
            }
        }
        return recursosHijos;
    }

}
