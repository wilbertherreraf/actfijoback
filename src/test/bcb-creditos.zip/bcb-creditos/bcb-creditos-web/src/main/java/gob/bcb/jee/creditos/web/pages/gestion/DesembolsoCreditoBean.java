package gob.bcb.jee.creditos.web.pages.gestion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.primefaces.PrimeFaces;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.jee.creditos.BL.AuxPlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenParametroBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembolsoDetalleBLLocal;
import gob.bcb.jee.creditos.BL.PreGarantiadBLLocal;
import gob.bcb.jee.creditos.BL.PrePlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreRegistrogarantiasBLLocal;
import gob.bcb.jee.creditos.BL.PreTramonBLLocal;
import gob.bcb.jee.creditos.QL.GenPrcparamsQLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocal;
import gob.bcb.jee.creditos.entidades.GenPrcparams;
import gob.bcb.jee.creditos.entidades.PrePagocuota;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.entidades.pojo.ComprobanteDet;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.AuxPlanpagos;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenModulo;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;
import gob.bcb.jee.creditos.model.PreGarantiad;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PreTramon;
import gob.bcb.jee.creditos.pojo.PreDesembolsoDto;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "DesembolsoCreditoBean")
@ViewScoped
@Getter
@Setter
public class DesembolsoCreditoBean implements Serializable {
    private static final Logger log = LoggerFactory.getLogger(DesembolsoCreditoBean.class);
	private static final long serialVersionUID = 1L;

	@Inject
	private PrePrestamosBLLocal prePrestamosBLLocal;

	@Inject
	private PreDesembBLLocal preDesembBLLocal;

	@Inject
	private PreGarantiadBLLocal preGarantiadBLLocal;

	@Inject
	private PreTramonBLLocal preTramonBLLocal;

	@Inject
	private CliPersonaBLLocal service;

	@Inject
	private AuxPlanpagosBLLocal auxPlanpagosLocal;

	@Inject
	private PrePlanpagosBLLocal prePlanpagosLocal;
	@Inject
	private PrePlanpagosQLLocal prePlanpagosQlLocal;

	@Inject
	private PreDesembolsoDetalleBLLocal preDesembolsoDetalleBLLocal;

	@Inject
	private GenParametroBLLocal genParametroBLLocal;

	@Inject
	private PreRegistrogarantiasBLLocal preRegistrogarantiasBLLocal;
	@Inject
	private GenPrcparamsQLLocal genPrcparamsQLLocal;
	private List<CliPersona> products;
	private List<PreDesembolsoDto> listDesembolso = new ArrayList<>();

	private PrePrestamos itemActual = new PrePrestamos();

	private PreDesemb itemActualPreD = new PreDesemb();
	private PreDesembolsoDetalle itemActualDesembolsoDetalle = new PreDesembolsoDetalle();

	private PrePrestamos prePrestamos = new PrePrestamos();
	private List<PrePrestamos> listPrePrestamos;
	private boolean habilitadoCampos = true;
	private CliPersona cliPersona = new CliPersona();
	private String cliente;
	private List<GenTipproducto> listGenTipproductos;
	private GenTipproducto genTipproducto;
	private String igenTipproducto;

	private List<GenMoneda> listGenMoneda;
	private GenMoneda genGenMoneda;
	private PreDesemb preDesemb;
	private PreGarantiad preGarantiad;

	private Integer igenGenMoneda;

	private Integer igenGenModulo;
	private Integer codigoPrestamo;
	private String contrato;
	private boolean mostrarDiasIregular = true;

	private Integer planDePagosSeleccionado = 0;

	private List<GenDesctabla> listGenDesctablaPlazoInt;

	private List<Object[]> listAuxPlanpagosO;

	private List<Object[]> listAuxPlanpagosDisponible;

	private List<AuxPlanpagos> listAuxPlanpagosMod;

	private List<Object[]> listPrePlanpagosO = new ArrayList<>();
	private List<Object[]> listPrePlanpagosDSB = new ArrayList<>();

	private List<GenModulo> listGenModulo;
	private BigDecimal valorDisponibleDesembolso;

	private List<Date> rangeC;
	private List<Date> rangeI;

	// IP SDAPO 1548522 --Datos de garantias

	private boolean habilitarGarantia = true;
	private String claveSerie;
	private String tituloGarantia;
	private boolean garantiaNegociable = false;
	private boolean sinDatosGarantia = true;

	//
	private Integer codCliente;
	private String ctaDebe;
	private String ctaHaber;
	private String nombreCorto;
	private String parametroGlosa;
	private Integer totalDesembolsos;
	private Integer numeroDesembolso;
	private String nroComprobanteCOIN;
	private List<Object[]> ParamsComprobante;
	private Integer numeroCentro;
	private String tipoComprobante;
	private String numeroSerie;

	private List<ComprobanteDet> listRenglones = new ArrayList<>();	
	private BigDecimal debeSuma = BigDecimal.valueOf(0.00);
	private BigDecimal haberSuma = BigDecimal.valueOf(0.00);

	public DesembolsoCreditoBean() {
	}

	@PostConstruct
	public void init() {
		try {

			// listGenTipproductos=genTipProductoBLLocal.list();
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void iniciarDesembolso() {
		try {

			this.habilitarGarantia = true;
			this.claveSerie = "";
			this.tituloGarantia = "";
			preDesemb = new PreDesemb();
			preGarantiad = new PreGarantiad();

			preDesemb.setDsbCodcred(itemActual.getPrePrestamosPK().getPreCodcred());
			preDesemb.setDsbCodmod(itemActual.getPrePrestamosPK().getPreCodmod());

			preGarantiad.setGardCodcred(itemActual.getPrePrestamosPK().getPreCodcred());
			preGarantiad.setGardCodmod(itemActual.getPrePrestamosPK().getPreCodmod());

			valorDisponibleDesembolso = preDesembBLLocal.getDisponibleDesembolso(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod());
			Map<String, Object> valores = new HashMap<>();

			valores.put("valor1", itemActual.getPrePrestamosPK().getPreCodcred());
			valores.put("valor2", itemActual.getPrePrestamosPK().getPreCodmod());
			// listDesembolso=preDesembBLLocal.listByNamedQuery(PreDesemb.NQ_LIST_BY_CREDITO,
			// valores);
			List<PreDesemb> auxListDesembolso = preDesembBLLocal.listByNamedQuery(PreDesemb.NQ_LIST_BY_CREDITO,
					valores);
			for (PreDesemb dato : auxListDesembolso) {
				PreDesembolsoDto dto = new PreDesembolsoDto();
				dto.setDesembolso(dato);
				try {
					dto.setDesembolsoDetalle(preDesembolsoDetalleBLLocal.obtenerPorCodDesembolso(dato.getDsbCoddsb()));
				} catch (Exception e) {
					log.info("No encontro un detalle registrado");
					dto.setDesembolsoDetalle(new PreDesembolsoDetalle());
				}
				listDesembolso.add(dto);
			}

		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void eliminarCuota(Date cuota) {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {
			prePlanpagosLocal.quitarCuota(itemActualPreD.getDsbCodcred(), itemActualPreD.getDsbCodmod(),
					itemActualPreD.getId(), cuota, usuario.getLogin(), UtilWeb.getIPRemoto());
			log.info("Cuota eliminada" + cuota + " " + itemActualPreD.getDsbCodcred() + " "
					+ itemActualPreD.getDsbCodmod() + " " + itemActualPreD.getId());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Cuota eliminada exitosamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void modificarDesembolso() {
		try {

			valorDisponibleDesembolso = preDesembBLLocal.getDisponibleDesembolso(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod());
			Map<String, Object> valores = new HashMap<>();

			getDatosGarantia();
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public boolean verificarOperaciones(Integer codcred, Integer codmod, Integer coddsb) {
		try {
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", codcred);
			valores.put("valor2", codmod);
			valores.put("valor3", 1705);
			valores.put("valor4", 1);
			valores.put("valor5", 0);
			valores.put("valor6", coddsb);
			List<PreTramon> listPreTramon = preTramonBLLocal.listByNamedQuery(PreTramon.NQ_LIST_TRAMDSB, valores);
			if (listPreTramon.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return false;
	}

	public boolean verificarPlanDePagosAux(Integer coddesem) {
		try {
			int cantidadAux = auxPlanpagosLocal.getCantidad(coddesem);
			if (cantidadAux > 0) {
				return true;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

		return false;
	}

	public boolean verificarPlanDePagosPre(Integer coddesem) {
		try {
			int cantidadPre = prePlanpagosLocal.getCantidad(coddesem);
			if (cantidadPre > 0) {
				return true;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

		return false;
	}

	public boolean verificarPlanDePagosAutorizado(Integer coddesem, Integer codgenerado, Integer codaut) {
		try {
			int cantidadAux = auxPlanpagosLocal.getCantidadAutorizado(coddesem, codgenerado, codaut);
			if (cantidadAux > 0) {
				return true;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

		return false;
	}

	public boolean verificarPlanDePagos(Integer coddesem) {
		try {
			int cantidadAux = auxPlanpagosLocal.getCantidad(coddesem);
			int cantidadPre = prePlanpagosLocal.getCantidad(coddesem);

			if (cantidadAux > 0) {
				return true;
			}
			if (cantidadPre > 0)
				return true;
		}

		catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

		return false;
	}

	public void generarPlanDePagosDsb(Integer coddesem) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			int valorhash = usuario.getLogin().hashCode();
			int registros = preDesembBLLocal.generarPlanDePagosDsb(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), coddesem, valorhash, usuario.getLogin(),
					UtilWeb.getIPRemoto());
			log.info("Plan de pagos generado cantidad:" + registros);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Plan de pagos generado exitosamente",
					"");
			FacesContext.getCurrentInstance().addMessage(null, message);
			iniciarVerDesembolsos();
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void preAutorizarPlanDePagos(Integer coddesem, Integer codseleccionado) {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			auxPlanpagosLocal.preautorizar(coddesem, usuario.getLogin(), new Timestamp(new Date().getTime()), 2,
					codseleccionado);
			log.info("Plan de pagos preautorizado correctamente");
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Plan de pagos preautorizado exitosamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			iniciarVerDesembolsos();
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void autorizarPlanDePagos(Integer coddesem, Integer codseleccionado) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			auxPlanpagosLocal.preautorizar(coddesem, usuario.getLogin(), new Timestamp(new Date().getTime()), 3,
					codseleccionado);
			int valorhash = usuario.getLogin().hashCode();
			preDesembBLLocal.aprobarPlanDePagos(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), coddesem, codseleccionado,
					usuario.getLogin().toString(), UtilWeb.getIPRemoto());
			log.info("Plan de pagos generado correctamente");
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Plan de pagos generado exitosamente",
					"");
			FacesContext.getCurrentInstance().addMessage(null, message);
			iniciarVerDesembolsos();
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void verPlanDePagosAux(Integer coddesem, Integer codMod) {
		try {
			planDePagosSeleccionado = codMod;
			listAuxPlanpagosO = auxPlanpagosLocal.mostrarPlanDePagosAux(itemActual.getPrePrestamosPK().getPreCodcred(),
					coddesem, codMod);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void verPlanDePagosAuxDisponibles(Integer coddesem) {
		try {
			listAuxPlanpagosDisponible = auxPlanpagosLocal
					.mostrarPlanDePagosDisponibles(itemActual.getPrePrestamosPK().getPreCodcred(), coddesem);
			if (listAuxPlanpagosDisponible == null) {
				listAuxPlanpagosDisponible = new ArrayList<>();
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void modificarPlanDePagosAuxiliar(Integer coddesem) {
		try {


		}catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void adicionarFechasAlPlanDePagosAuxiliar(Integer coddesem) {
		try {
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void verPlanDePagosPre(Integer coddesem) {
		try {
			listPrePlanpagosDSB = prePlanpagosLocal.mostrarPlanDePagos(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), coddesem);
			getDatosGarantia(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), coddesem);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void eliminarDesembolso(Integer coddesem) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			preDesembBLLocal.eliminarDesembolso(coddesem, usuario.getLogin(), UtilWeb.getIPRemoto());
			getDatosGarantia();
			if (!sinDatosGarantia)
				preGarantiadBLLocal.delete(preGarantiad.getId(), usuario.getLogin());
			iniciarVerDesembolsos();
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void verPlanDePagosPreG(Integer coddesem) {
		try {
			listPrePlanpagosO = prePlanpagosLocal.mostrarPlanDePagosGeneral(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod(), 0);
			log.info("Plan de pagos generado correctamente");

		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void actualizarPlanDePagosPreG() {
		try {
			// prePlanpagosLocal.actualizarPlanDePagos0(itemActual.getPrePrestamosPK().getPreCodcred(),
			// itemActual.getPrePrestamosPK().getPreCodmod());
			verPlanDePagosPreG(0);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public boolean verificarAprobarDesembolso(BigDecimal dsbValor, BigDecimal dsbUndsb, Integer codDsb) {

		try {
			int cantidadPre = prePlanpagosLocal.getCantidad(codDsb);
			if (cantidadPre == 0)
				return true;
		}

		catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

		if (dsbValor.compareTo(dsbUndsb) == 0) {
			return true;
		} else if (dsbUndsb.compareTo(BigDecimal.ZERO) == 0) {
			return false;
		}
		return false;
	}

	public void operacionDeDesembolso(Integer coddesem) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

			preDesembBLLocal.aprobarDesembolso(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), coddesem, itemActualPreD.getDsbFecdsb(), new Date(),
					1, usuario.getLogin(), UtilWeb.getIPRemoto());
			aprobarGarantia(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), coddesem, usuario.getLogin(),
					new Timestamp(new Date().getTime()), UtilWeb.getIPRemoto());
			iniciarVerDesembolsos();
			log.info("Ejecutado la operación de desembolso exitosamente");
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Ejecutado la operación de desembolso exitosamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}

		catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void iniciarVerDesembolsos() {
		try {
			listPrePlanpagosDSB = new ArrayList<>();
			listDesembolso = new ArrayList<>();
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", itemActual.getPrePrestamosPK().getPreCodcred());
			valores.put("valor2", itemActual.getPrePrestamosPK().getPreCodmod());
			// listDesembolso=preDesembBLLocal.listByNamedQuery(PreDesemb.NQ_LIST_BY_CREDITO,
			// valores);
			List<PreDesemb> auxListDesembolso = preDesembBLLocal.listByNamedQuery(PreDesemb.NQ_LIST_BY_CREDITO,
					valores);
			totalDesembolsos = auxListDesembolso.size();
			for (PreDesemb dato : auxListDesembolso) {
				PreDesembolsoDto dto = new PreDesembolsoDto();
				dto.setDesembolso(dato);
				try {
					dto.setDesembolsoDetalle(preDesembolsoDetalleBLLocal.obtenerPorCodDesembolso(dato.getDsbCoddsb()));
				} catch (Exception e) {
					log.info("No encontro un detalle registrado");
					dto.setDesembolsoDetalle(new PreDesembolsoDetalle());
				}

				listDesembolso.add(dto);
			}
			valorDisponibleDesembolso = preDesembBLLocal.getDisponibleDesembolso(
					itemActual.getPrePrestamosPK().getPreCodcred(), itemActual.getPrePrestamosPK().getPreCodmod());
		}

		catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void preAutorizarDesembolso() {
		try {
			itemActualPreD.setDsbTrxstaau(2);
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActualPreD.setDsbAuditusr(usuario.getLogin());
			itemActualPreD.setDsbAuditfho(new Timestamp(new Date().getTime()));
			itemActualPreD.setDsbAuditwst(UtilWeb.getIPRemoto());
			preDesembBLLocal.merge(itemActualPreD, usuario.getLogin());
			log.info("Ejecutado la operación de preautorizacionDesembolso");
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Ejecutado la operación de preautorización exitosamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error(e.getMessage());
			itemActualPreD.setDsbTrxstaau(1);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void autorizarDesembolso() {
		try {
			itemActualPreD.setDsbTrxstaau(3);
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActualPreD.setDsbAuditusr(usuario.getLogin());
			itemActualPreD.setDsbAuditfho(new Timestamp(new Date().getTime()));
			itemActualPreD.setDsbAuditwst(UtilWeb.getIPRemoto());
			preDesembBLLocal.merge(itemActualPreD, usuario.getLogin());
			log.info("Ejecutado la operación de autorizacionDesembolso");
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Ejecutado la operación de autorización exitosamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public boolean verificarAutorizador() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		if (itemActualPreD.getDsbTrxstaau() != null) {
			int estado = itemActualPreD.getDsbTrxstaau();
			if (estado == 2) {
				if (usuario.getRoles().stream().filter(x -> x.getCodigo().equals("AUTORIZADOR")).count() > 0)
					return true;
			}
		}
		return false;
	}

	public boolean verificarPreautorizador() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		if (itemActualPreD.getDsbTrxstaau() != null) {
			int estado = itemActualPreD.getDsbTrxstaau();
			if (estado == 1) {
				if (usuario.getRoles().stream().filter(x -> x.getCodigo().equals("PREAUTORIZADOR")).count() > 0)
					return true;
			}
		}
		return false;
	}

	public boolean isDesembolsable(Integer preCodcred, Integer preCodmod, BigDecimal valor) {
		try {
			BigDecimal disponible = preDesembBLLocal.getDisponibleDesembolso(preCodcred, preCodmod);
			if (valor.compareTo(disponible) >= 0) {
				return true;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

		return false;
	}

	public void guardarModificarDesembolso() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActualPreD.setDsbTrxstaau(1);
			itemActualPreD.setDsbAuditusr(usuario.getLogin());
			itemActualPreD.setDsbAuditfho(new Timestamp(new Date().getTime()));
			itemActualPreD.setDsbAuditwst(UtilWeb.getIPRemoto());
			preDesembBLLocal.merge(itemActualPreD, usuario.getLogin());
			log.info("Registro modificado:" + itemActualPreD.toString());

			if (!sinDatosGarantia) {
				if (!preGarantiad.isGardHabilita()) {
					preGarantiad.setGardTitulo("");
					preGarantiad.setGardClaveSerie("");
					preGarantiad.setGardNegociable(false);
				}
				preGarantiad.setGardAuditusr(usuario.getLogin());
				preGarantiad.setGardAuditfho(new Timestamp(new Date().getTime()));
				preGarantiad.setGardAuditwst(UtilWeb.getIPRemoto());
				preGarantiadBLLocal.merge(preGarantiad, usuario.getLogin());
			}

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Registro modificado satisfactoriamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			limpiar();
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void generarDesembolso() {
		try {
			if (preDesemb.getDsbFecdsb().after(preDesemb.getDsbFecini())) {
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"La fecha inicial debe ser mayor a la fecha de desembolso", "");
				FacesContext.getCurrentInstance().addMessage(null, message);
				return;
			}
			if (preDesemb.getDsbValor().compareTo(valorDisponibleDesembolso) > 0) {
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"El valor monto a desembolsar debe ser menor o igual al monto disponible a desembolsar", "");
				FacesContext.getCurrentInstance().addMessage(null, message);
				return;
			}
			if (preDesemb.getDsbFeciniint() == null) {
				preDesemb.setDsbTabunidplazint(null);
				preDesemb.setDsbUnidplazint(null);
			}

			// if(preDesemb.getDsbFecFin().after(preDesemb.getDsbFecini())) {
			// FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "La
			// fecha fin debe ser mayor a hoy","");
			// FacesContext.getCurrentInstance().addMessage(null, message);
			// }

			int id = preDesembBLLocal.getIdNewId();
			preDesemb.setId(id);
			preDesemb.setDsbTasa(0.0);
			preDesemb.setDsbTabmethodcapi(413);
			preDesemb.setDsbUnidplaz(13);
			preDesemb.setDsbUnidplazint(13);
			preDesemb.setDsbTipodsb(1);// capital
			preDesemb.setDsbTabunidplaz(1703);
			preDesemb.setDsbTabunidplazint(1703);
			preDesemb.setDsbTabmonpag(15);
			preDesemb.setDsbMonpag(1);
			preDesemb.setDsbTabtrxstaau(30);
			preDesemb.setDsbTrxstaau(1);
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			preDesemb.setDsbAuditusr(usuario.getLogin());
			preDesemb.setDsbAuditfho(new Timestamp(new Date().getTime()));
			preDesemb.setDsbAuditwst(UtilWeb.getIPRemoto());

			preDesembBLLocal.persist(preDesemb, usuario.getLogin());

			// Datos Garantia
			preGarantiad.setId(preGarantiadBLLocal.getIdNewId());
			preGarantiad.setGardHabilita(this.habilitarGarantia);
			if (habilitarGarantia == false) {
				this.claveSerie = "";
				this.tituloGarantia = "";
			}
			preGarantiad.setGardCoddsb(preDesemb.getId());
			preGarantiad.setGardClaveSerie(this.claveSerie);
			preGarantiad.setGardTitulo(this.tituloGarantia);
			preGarantiad.setGardNegociable(this.garantiaNegociable);
			preGarantiad.setGardTabtrxstaau(30);
			preGarantiad.setGardTrxstaau(1);
			preGarantiad.setGardAuditusr(usuario.getLogin());
			preGarantiad.setGardAuditfho(new Timestamp(new Date().getTime()));
			preGarantiad.setGardAuditwst(UtilWeb.getIPRemoto());
			preGarantiadBLLocal.persist(preGarantiad, usuario.getLogin());
			//

			itemActual.setPreStatus(2);
			prePrestamosBLLocal.merge(itemActual, usuario.getLogin());
			log.info("Registro guardado:" + preDesemb.toString());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente",
					"Pendiente de preautorización plan de pagos");
			FacesContext.getCurrentInstance().addMessage(null, message);
			limpiar();
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void selectCliPersonaFromDialog(CliPersona product) {
		try {
			// cliPersona = product;
			cliente = cliPersona.getCliNombre();
			contrato = "";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void generarOperacionPrcConta() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("GEnerando prcconta {} usr {}", itemActualDesembolsoDetalle.getId(), usuario.getLogin());
			itemActualDesembolsoDetalle.setFecha(new Date());
			itemActualDesembolsoDetalle.setAuditUsuario(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHost(UtilWeb.getIPRemoto());
			itemActualDesembolsoDetalle.setAuditUsuarioGenera(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHostGenera(UtilWeb.getIPRemoto());			
			// itemActualDesembolsoDetalle = itemActualDesembolsoDetalleBLLocal.guardarPrcconta(itemActualDesembolsoDetalle);

			// prePagocuotaBLLocal.generarOperContCred( itemActualDesembolsoDetalle.getPrcCodcmp(), itemActualDesembolsoDetalle.getPrcCodprc(), itemActualDesembolsoDetalle.getPrcCodcred(),
			// 		itemActualDesembolsoDetalle.getPrcCodmod(), null, itemActualDesembolsoDetalle.getPrcFecha2(), null, usuario.getLogin(),
			// 		UtilWeb.getIPRemoto());
			// itemActualDesembolsoDetalle = itemActualDesembolsoDetalleBLLocal.buscarPorId(itemActualDesembolsoDetalle.getPrcCodprc());
			// listRenglones = recuperarRengsOper(itemActualDesembolsoDetalle);
			// actPrestConDevsAFechaDev(itemActualDesembolsoDetalle.getPrcFecha2());			

			//log.info("Operacion de devengado generada id {} cred {}", itemActualDesembolsoDetalle.getPrcCodprc(), itemActualDesembolsoDetalle.getPrcCodcred());			
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}
	public void btnGuardarPrcconta() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Salvando prcconta {} usr {}", itemActualDesembolsoDetalle.getId(), usuario.getLogin());
			itemActualDesembolsoDetalle.setFecha(new Date());
			itemActualDesembolsoDetalle.setAuditUsuario(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHost(UtilWeb.getIPRemoto());
			itemActualDesembolsoDetalle.setAuditUsuarioGenera(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHostGenera(UtilWeb.getIPRemoto());

			//itemActualDesembolsoDetalle = prePagocuotaBLLocal.guardarPagocuota(itemActualDesembolsoDetalle);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO,
							"Registro salvado",
							"Codigo: " + itemActualDesembolsoDetalle.getId()));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void btnCancelarPrcconta() {
		try {
			log.info("cancelando prcconta {}", itemActualDesembolsoDetalle.getId());

			//itemActualDesembolsoDetalle = prePagocuotaBLLocal.findCuotaById(itemActualDesembolsoDetalle.getId());

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Edición cancelada", "No se guardaron cambios"));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}
		
	public void btnGuardarGenparams(GenPrcparams genprcparams) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Salvando Genprcparams {} codgen {}", itemActualDesembolsoDetalle.getId(), genprcparams.getPrpCodtpr());
			GenPrcparams genprcp = genPrcparamsQLLocal.saveUpdateGenP(genprcparams);
			listRenglones = recuperarRengsOper(itemActualDesembolsoDetalle);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO,
							"Registro salvado",
							"Código renglón: " + genprcp.getPrpCodprc()));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void btnCancelarGenparams(GenPrcparams genprcparams) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Cancelando Genprcparams {} codgen {}", itemActualDesembolsoDetalle.getId(), genprcparams.getPrpCodtpr());
			listRenglones = recuperarRengsOper(itemActualDesembolsoDetalle);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Edición cancelada", "No se guardaron cambios"));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}	
	public void generarComprobante0() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {
			log.info("Inicio generarComprobante cobro o pago anticipado usr: " + usuario.getLogin()
					+ ", IP: " + UtilWeb.getIPRemoto() + " cred: " + itemActual.getId().getPreCodcred() + " ID PGOCTA: "
					+ itemActualDesembolsoDetalle.getId());
			itemActualDesembolsoDetalle.setFecha(new Date());
			itemActualDesembolsoDetalle.setAuditUsuario(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHost(UtilWeb.getIPRemoto());
			itemActualDesembolsoDetalle.setAuditUsuarioGenera(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHostGenera(UtilWeb.getIPRemoto());

			// itemActualDesembolsoDetalle = prePagocuotaBLLocal.guardarPagocuota(itemActualDesembolsoDetalle);
			// Integer idPcta = itemActualDesembolsoDetalle.getId();
			// prePagocuotaBLLocal.generarOperacionYContaBL(itemActualDesembolsoDetalle.getPcuTipocmp(),itemActualDesembolsoDetalle, itemActualDesembolsoDetalle.getGlosaCoin());

			// listEstadoDesembolsos.clear();
			// itemActualDesembolsoDetalle = prePagocuotaBLLocal.findCuotaById(idPcta);

			// actListDesembolsos(itemActualDesembolsoDetalle.getFechaVencimiento(), itemActualDesembolsoDetalle.getCodcred(),
			// 		itemActualDesembolsoDetalle.getCodmod());

			PrimeFaces.current().executeScript("PF('dlgCmpbRengs').hide();");

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de generación de comprobante COIN ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void eliminarOperacion() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio eliminarDevengado usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			// prePrccontaBLLocal.cambiarEstadoOperComprob(itemActualDesembolsoDetalle.getPcuTipocmp(), itemActualDesembolsoDetalle.getId(),
			// 		itemActual.getId().getPreCodcred(),
			// 		itemActual.getId().getPreCodmod(), itemActualDesembolsoDetalle.getCoddsb(), itemActualDesembolsoDetalle.getFechaVencimiento(), 7, usuario.getLogin(), UtilWeb.getIPRemoto());

			// planpagosVctos = recuperarSgtesVctos(itemActualDesembolsoDetalle.getCodcred(), itemActualDesembolsoDetalle.getCodmod());
			// planpagosVctos = completarPPVctos(planpagosVctos);											
			// actListDesembolsos(itemActualDesembolsoDetalle.getFechaVencimiento(), itemActualDesembolsoDetalle.getCodcred(),
			// 		itemActualDesembolsoDetalle.getCodmod());


			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"La cancelación del comprobante se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
		return;
	}

	public void rechazarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio rechazarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());
			// prePrccontaBLLocal.cambiarEstadoOperComprob(itemActualDesembolsoDetalle.getPcuTipocmp(), itemActualDesembolsoDetalle.getId(),
			// 		itemActual.getId().getPreCodcred(),
			// 		itemActual.getId().getPreCodmod(),itemActualDesembolsoDetalle.getCoddsb(), itemActualDesembolsoDetalle.getFechaVencimiento(), 4, usuario.getLogin(), UtilWeb.getIPRemoto());

			// planpagosVctos = recuperarSgtesVctos(itemActualDesembolsoDetalle.getCodcred(), itemActualDesembolsoDetalle.getCodmod());
			// planpagosVctos = completarPPVctos(planpagosVctos);														

			// actListDesembolsos(itemActualDesembolsoDetalle.getFechaVencimiento(), itemActualDesembolsoDetalle.getCodcred(),
			// 		itemActualDesembolsoDetalle.getCodmod());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"El rechazo del comprobante se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return;
	}

	public void preAutorizarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio preAutorizarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			// prePrccontaBLLocal.cambiarEstadoOperComprob(itemActualDesembolsoDetalle.getPcuTipocmp(), itemActualDesembolsoDetalle.getId(),
			// 		itemActual.getId().getPreCodcred(),
			// 		itemActual.getId().getPreCodmod(), itemActualDesembolsoDetalle.getCoddsb(), itemActualDesembolsoDetalle.getFechaVencimiento(), 2, usuario.getLogin(), UtilWeb.getIPRemoto());

			// itemActualDesembolsoDetalle = prePagocuotaBLLocal.findCuotaById(itemActualDesembolsoDetalle.getId());

			// planpagosVctos = recuperarSgtesVctos(itemActualDesembolsoDetalle.getCodcred(), itemActualDesembolsoDetalle.getCodmod());
			// planpagosVctos = completarPPVctos(planpagosVctos);								
			// actListDesembolsos(itemActualDesembolsoDetalle.getFechaVencimiento(), itemActualDesembolsoDetalle.getCodcred(),
			// 		itemActualDesembolsoDetalle.getCodmod());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"La preautorzacíón del comprobante se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return;
	}

	public void autorizarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio autorizarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			// prePrccontaBLLocal.cambiarEstadoOperComprob(itemActualDesembolsoDetalle.getPcuTipocmp(), itemActualDesembolsoDetalle.getId(),
			// 		itemActual.getId().getPreCodcred(),
			// 		itemActual.getId().getPreCodmod(),itemActualDesembolsoDetalle.getCoddsb(), itemActualDesembolsoDetalle.getFechaVencimiento(), 3, usuario.getLogin(), UtilWeb.getIPRemoto());

			// itemActualDesembolsoDetalle = prePagocuotaBLLocal.findCuotaById(itemActualDesembolsoDetalle.getId());

			// planpagosVctos = recuperarSgtesVctos(itemActualDesembolsoDetalle.getCodcred(), itemActualDesembolsoDetalle.getCodmod());
			// planpagosVctos = completarPPVctos(planpagosVctos);											
			// actListDesembolsos(itemActualDesembolsoDetalle.getFechaVencimiento(), itemActualDesembolsoDetalle.getCodcred(),
			// 		itemActualDesembolsoDetalle.getCodmod());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"La autorización se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return;
	}

	public void buscarClientes() {
		try {
			listPrePlanpagosO = new ArrayList<>();
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDeContrato() {
		try {
			cliente = "";
			this.codigoPrestamo = 0;
			listPrePlanpagosO = new ArrayList<>();
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDePrestamo() {
		try {
			// String []valoresTipoProducto=igenTipproducto.split("-");
			// igenGenModulo= Integer.parseInt(valoresTipoProducto[0].trim());
			//
			cliente = "";
			contrato = "";
			listPrePlanpagosO = new ArrayList<>();
			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			// valores.put("pre_codmod", igenGenModulo);
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void limpiar() {
		cliPersona = new CliPersona();
		cliente = "";
		prePrestamos = new PrePrestamos();
		preDesemb = new PreDesemb();
		preGarantiad = new PreGarantiad();
		habilitadoCampos = true;
	}

	public void OnOffCheckboxGarantia() {
		if (this.habilitarGarantia == false) {
			claveSerie = "";
			tituloGarantia = "";
		}
	}

	public void getDatosGarantia() {
		try {
			preGarantiad = preGarantiadBLLocal.GetByDsb(itemActualPreD.getDsbCodcred(), itemActualPreD.getDsbCodmod(),
					itemActualPreD.getDsbCoddsb());
			if (preGarantiad == null)
				sinDatosGarantia = true;
			else
				sinDatosGarantia = false;
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void aprobarGarantia(Integer valor1, Integer valor2, Integer valor3, String valor4, Timestamp valor5,
			String valor6) {
		try {
			preGarantiad = preGarantiadBLLocal.GetByDsb(valor1, valor2, valor3);
			if (preGarantiad == null)
				return;
			else {
				preGarantiad.setGardTrxstaau(3);
				preGarantiad.setGardAuditusr(valor4);
				preGarantiad.setGardAuditfho(valor5);
				preGarantiad.setGardAuditwst(valor6);
				preGarantiadBLLocal.merge(preGarantiad, valor4);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void getDatosGarantia(Integer valor1, Integer valor2, Integer valor3) {
		try {
			preGarantiad = preGarantiadBLLocal.GetByDsb(valor1, valor2, valor3);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void verificarTipoEntidadDesembolso(PreDesemb pPreDesembolso) {
		try {
			log.info("verificamos si el monto desembolsado es mayor a cero");
			if (pPreDesembolso.getDsbUndsb().compareTo(BigDecimal.ZERO) > 0) {
				this.itemActualPreD = pPreDesembolso;
				log.info(
						"verificarTipoEntidadDesembolso||verificamos si tiene un registro de detalle para recuperar y mostrar");
				this.itemActualDesembolsoDetalle = preDesembolsoDetalleBLLocal
						.obtenerPorCodDesembolso(pPreDesembolso.getDsbCoddsb());
				log.info("Verificamos que tipo de cliente es para habilitar formulario de registro ");
				this.codCliente = preDesembBLLocal.obtenerCodClientePorCodDesembolso(itemActualPreD.getDsbCoddsb());
				if (codCliente != null) {
					/** Codigo para obtener el Numero de DEBE y HABER **/
					if (ctaDebe == null) {
						ctaDebe = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
								itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.REGISTRO_DESEMBOLSOS_CUENTA_DEBE);
						if (ctaDebe == "") {
							FacesContext.getCurrentInstance().addMessage(null,
									new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
											"No esta registrado el Numero de Cuenta DEBE del credito."));
							return; // Detiene la ejecución aquí
						}
					}

					if (ctaHaber == null) {
						ctaHaber = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
								itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.REGISTRO_DESEMBOLSOS_CUENTA_HABER);
						if (ctaHaber == "") {
							FacesContext.getCurrentInstance().addMessage(null,
									new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
											"No esta registrado el Numero de Cuenta HABER del credito."));
							return; // Detiene la ejecución aquí
						}
					}

					/** Codigo para obtener el Numero de Serie del desembolso **/
					numeroSerie = preRegistrogarantiasBLLocal.getNumeroSerieGarantia(
							itemActual.getPrePrestamosPK().getPreCodcred(),
							itemActual.getPrePrestamosPK().getPreCodmod(), itemActualPreD.getDsbCoddsb());
					if (numeroSerie == "") {
						FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
								"ERROR", "No esta registrado el Numero de Serie de la garantía."));
						return; // Detiene la ejecución aquí
					}

					if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) {
						PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteDesembolsoMefp').show();");
					} else {
						PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteDesembolsoEpnes').show();");
					}
				} else {
					FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Advertencia",
							"El desembolso no corresponde a ningun EPNES ni al MEFP");
					FacesContext.getCurrentInstance().addMessage(null, message);
				}
			} else {
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Advertencia",
						"Antes de generar el comprobante, debe Realizar la operación de desembolso");
				FacesContext.getCurrentInstance().addMessage(null, message);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error ", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void guardarRegistroContableDesembolsoMefp() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActualDesembolsoDetalle.setDsbCoddsb(itemActualPreD);
			itemActualDesembolsoDetalle.setCodcred(itemActualPreD.getDsbCodcred());
			itemActualDesembolsoDetalle.setCodmod(itemActualPreD.getDsbCodmod());
			itemActualDesembolsoDetalle.setFecha(new Date());
			itemActualDesembolsoDetalle.setMontoDesembolsar(itemActualPreD.getDsbValor());
			itemActualDesembolsoDetalle.setEstado(1);
			itemActualDesembolsoDetalle.setAuditUsuario(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHost(UtilWeb.getIPRemoto());
			itemActualDesembolsoDetalle.setAuditUsuarioGenera(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHostGenera(UtilWeb.getIPRemoto());
			itemActualDesembolsoDetalle.setPdsCodcmp(Cttes.REGISTRO_CONTABLE_DESEMBOLSOS_MEFP);

			preDesembolsoDetalleBLLocal.persist(itemActualDesembolsoDetalle, usuario.getLogin());

			log.info("Registro guardado:" + itemActualDesembolsoDetalle.getId().toString());
			generarComprobante();

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente",
					"");
			FacesContext.getCurrentInstance().addMessage(null, message);
			this.itemActualDesembolsoDetalle = new PreDesembolsoDetalle();

			PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteDesembolsoMefp').hide();");

		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void guardarRegistroContableDesembolsoEpne() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActualDesembolsoDetalle.setDsbCoddsb(itemActualPreD);
			itemActualDesembolsoDetalle.setCodcred(itemActualPreD.getDsbCodcred());
			itemActualDesembolsoDetalle.setCodmod(itemActualPreD.getDsbCodmod());
			itemActualDesembolsoDetalle.setFecha(new Date());
			itemActualDesembolsoDetalle.setMontoDesembolsar(itemActualPreD.getDsbValor());
			itemActualDesembolsoDetalle.setEstado(1);
			itemActualDesembolsoDetalle.setAuditUsuario(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHost(UtilWeb.getIPRemoto());
			itemActualDesembolsoDetalle.setAuditUsuarioGenera(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHostGenera(UtilWeb.getIPRemoto());
			itemActualDesembolsoDetalle.setPdsCodcmp(Cttes.REGISTRO_CONTABLE_DESEMBOLSOS_EPNES);
			preDesembolsoDetalleBLLocal.persist(itemActualDesembolsoDetalle, usuario.getLogin());
			log.info("Registro guardado:" + itemActualDesembolsoDetalle.getId().toString());
			// iniciarVerDesembolsos();
			generarComprobante();

			PrimeFaces.current().executeScript("PF('dlgRegistroComprobanteDesembolsoEpnes').hide();");

		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void generarComprobante() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {
			log.info("Inicio generarComprobante  REGISTRO CONTROBANTE DESEMBOLSO usr: " + usuario.getLogin() + ", IP: "
					+ UtilWeb.getIPRemoto() + " cred: " + itemActual.getId().getPreCodcred() + " en fecha "
					+ new Date().toString());

			// obtenemos el nombre corto
			nombreCorto = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
					itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.DESCRIPCION_CORTA_CREDITO);
			if (nombreCorto == "") {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "ERROR",
						"No esta registrado el Nombre Corto del credito."));
				return; // Detiene la ejecución aquí
			}

			String resultadoGlosa = "";
			if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) { // MEFP

				/** codigo para obtener el parametro de la glosa de la tabla gen_comprobante **/
				ParamsComprobante = preRegistrogarantiasBLLocal
						.getParametrosGlosa(itemActualDesembolsoDetalle.getPdsCodcmp());
				for (Object[] result : ParamsComprobante) {
					numeroCentro = (int) result[2];
					tipoComprobante = (String) result[3];
					parametroGlosa = (String) result[4];
				}

				/** obtenemos las leyes asociadas al credito **/
				List<String> leyes = preDesembolsoDetalleBLLocal.getLeyesPrestamo(itemActual.getPreNumconv());
				StringBuilder concatenatedString = new StringBuilder();

				// Verificamos que la lista no sea null
				if (leyes != null) {
					// Recorremos la lista
					for (String ley : leyes) {
						// Verificamos que el elemento ley no sea null
						if (ley != null) {
							// Si no es el primer elemento, agregamos una coma para separar
							if (concatenatedString.length() > 0) {
								concatenatedString.append(" - ");
							}
							// Concatenamos el valor
							concatenatedString.append(ley);
						}
					}
				}
				// Convertimos el StringBuilder a String si es necesario
				String resultadoLeyes = concatenatedString.toString();
				log.info("resultadoFinal -> " + resultadoLeyes);

				// INGRESO A CUSTODIA DE {#P1} BTS CUOTAS {#P2} POR EL {#P3} DESEMB. A {#P4}
				// POR{#P5} CLAVE DE SERIE {#P6} SG. ACTA DE DEP. {#P7} EN EL MARCO DE LA
				// RD{#P8}.
				resultadoGlosa = parametroGlosa
						.replace("#P1", String.valueOf(totalDesembolsos))
						.replace("#P2", nombreCorto)
						.replace("#P3", itemActualDesembolsoDetalle.getNotaSolicitud())
						.replace("#P4", itemActualDesembolsoDetalle.getNumeroTramite())
						.replace("#P5", itemActual.getPreNumresol())
						.replace("#P6", itemActual.getPreNumcontra())
						.replace("#P7", resultadoLeyes);
			} else { // EPNES
						// #P1° DESEMBOLSO DE RECURSOS A #P2, NOTAS CITE: #P3 Y #P4 (#P5), CONT.#P6 E
						// INFORMES BCB #P7 Y #P8 DEL #P9.
				/** codigo para obtener el parametro de la glosa de la tabla gen_comprobante **/
				ParamsComprobante = preRegistrogarantiasBLLocal
						.getParametrosGlosa(itemActualDesembolsoDetalle.getPdsCodcmp());
				for (Object[] result : ParamsComprobante) {
					numeroCentro = (int) result[2];
					tipoComprobante = (String) result[3];
					parametroGlosa = (String) result[4];
				}

				resultadoGlosa = parametroGlosa
						.replace("#P1", String.valueOf(totalDesembolsos))
						.replace("#P2", nombreCorto)
						.replace("#P3", itemActualDesembolsoDetalle.getNotaSolicitud().trim())
						.replace("#P4", itemActualDesembolsoDetalle.getNotaSolicitudMcs().trim())
						.replace("#P5", itemActualDesembolsoDetalle.getNumeroTramite().trim())
						.replace("#P6", itemActual.getPreNumresol().trim())
						.replace("#P7", itemActual.getPreNumcontra().trim())
						.replace("#P8", itemActualDesembolsoDetalle.getInformeGom().trim())
						.replace("#P9", itemActualDesembolsoDetalle.getInformeGal().trim());
			}

			log.info("glosa " + resultadoGlosa);

			/** codigo para generar el numero de comprobante en el COIN **/
			itemActualDesembolsoDetalle.setGlosaCoin(resultadoGlosa);

			itemActualDesembolsoDetalle = preRegistrogarantiasBLLocal.generarCmpbDsbDet(itemActualDesembolsoDetalle, usuario.getLogin(), UtilWeb.getIPRemoto());

			if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) {
				PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoMefp').hide();");
			} else {
				PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoEpnes').hide();");
			}

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de generación de comprobante COIN ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.info(
					"generarComprobanteRetiroGarantia|| Se genero excepcion al generar el comprobante en COIN EPNE/MEFP, cancelamos el registro");
			itemActualDesembolsoDetalle.setEstado(Cttes.ESTOPER_CANC);
			itemActualDesembolsoDetalle.setAuditUsuario(usuario.getLogin());
			itemActualDesembolsoDetalle.setAuditFechahora(new Timestamp(new Date().getTime()));
			itemActualDesembolsoDetalle.setAuditHost(UtilWeb.getIPRemoto());
			try {
				preDesembolsoDetalleBLLocal.merge(itemActualDesembolsoDetalle, usuario.getLogin());
				itemActualDesembolsoDetalle = new PreDesembolsoDetalle();
				if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) {
					PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoMefp').hide();");
				} else {
					PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoEpnes').hide();");
				}
				// recarga la tabla
				iniciarVerDesembolsos();
			} catch (Exception e1) {
				e.getMessage();
			}

			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
		return;
	}

	public void cargarDetallesRegistro(PreDesemb pPreDesembolso) {
		if (pPreDesembolso != null && pPreDesembolso.getDsbCoddsb() != null) {
			try {
				itemActualPreD = pPreDesembolso;
				try {
					itemActualDesembolsoDetalle = preDesembolsoDetalleBLLocal
							.obtenerPorCodDesembolso(pPreDesembolso.getDsbCoddsb());
				} catch (Exception e) {
					log.info("No encontro un detalle registrado");
					e.getMessage();
				}

				if (ctaDebe == null) {
					ctaDebe = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
							itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.REGISTRO_DESEMBOLSOS_CUENTA_DEBE);
					if (ctaDebe == "") {
						FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
								"ERROR", "No esta registrado el Numero de Cuenta DEBE del credito."));
						return; // Detiene la ejecución aquí
					}
				}

				if (ctaHaber == null) {
					ctaHaber = genParametroBLLocal.getNumeroCuenta(itemActual.getPrePrestamosPK().getPreCodcred(),
							itemActual.getPrePrestamosPK().getPreCodmod(), Cttes.REGISTRO_DESEMBOLSOS_CUENTA_HABER);
					if (ctaHaber == "") {
						FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
								"ERROR", "No esta registrado el Numero de Cuenta HABER del credito."));
						return; // Detiene la ejecución aquí
					}
				}

				log.info("Verificamos que tipo de cliente es para habilitar formulario de registro ");
				this.codCliente = preDesembBLLocal.obtenerCodClientePorCodDesembolso(itemActualPreD.getDsbCoddsb());
				if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) {
					PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoMefp').show();");
				} else {
					PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoEpnes').show();");
				}
			} catch (Exception e) {
				e.getMessage();
			}
		}
	}

	private List<ComprobanteDet> recuperarRengsOper(PreDesembolsoDetalle prcconta) {
		try {
			List<GenPrcparams> rengs = genPrcparamsQLLocal.findByCodPrcYTipoProc(prcconta.getId(),
					prcconta.getPdsCodcmp());
			log.info("rengs comprog " + rengs.size());
			debeSuma = BigDecimal.ZERO;
			haberSuma = BigDecimal.ZERO;
			List<ComprobanteDet> listRengs = rengs.stream().map(p -> {
				ComprobanteDet cd = new ComprobanteDet();
				cd.setRenCodigo(p.getPrpNroreng());
				cd.setMovi(p.getPrpCtamov() + " - " + p.getPrpValue());
				cd.setDebe(BigDecimal.ZERO);
				cd.setHaber(BigDecimal.ZERO);

				if (p.getPrpDh() != null && p.getPrpDh().equals("D")) {
					cd.setDebe(p.getPrpMontomn());
				} else {
					cd.setHaber(p.getPrpMontomn());
				}
				debeSuma = debeSuma.add(cd.getDebe());
				haberSuma = haberSuma.add(cd.getHaber());
				cd.setRenGlosa(p.getPrpGlosa());
				cd.setNroCP(p.getPrpNrocp());
				cd.setGenPrcparams(p);
				return cd;
			}).collect(Collectors.toList());
		return listRengs;
		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			throw new RuntimeException(e);
		}
	}	
		
	public Integer verificarEstado(Integer codcred, Integer codmod, Integer coddsb) throws OperationException {
		Integer resultado = preDesembolsoDetalleBLLocal.getEstadoDesembolsoDetalle(codcred, codmod, coddsb);
		return resultado;
	}

	public Integer verificarRegistroTransitorioGarantias(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {
		Integer resultado = preRegistrogarantiasBLLocal.verificarRegistroTransitorioGarantias(codcred, codmod, coddsb);
		return resultado;
	}

	public void preAutorizarRegistroDesembolso() {
		log.info("Ingreso a preautorizar");
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = itemActualDesembolsoDetalle.getId();
			/** CODIGO PARA PREAUTORIZAR COMPROBANTE EN COIN **/
			Boolean respuesta = Boolean.FALSE;
			if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) { // MEFP
				respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualDesembolsoDetalle.getId(),
						itemActualDesembolsoDetalle.getPdsCodcmp(), itemActualDesembolsoDetalle.getCodcred(),
						itemActualDesembolsoDetalle.getCodmod(),
						Cttes.PREAUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());
			} else {// EPNES
				respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualDesembolsoDetalle.getId(),
						itemActualDesembolsoDetalle.getPdsCodcmp(), itemActualDesembolsoDetalle.getCodcred(),
						itemActualDesembolsoDetalle.getCodmod(),
						Cttes.PREAUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());
			}
			itemActualDesembolsoDetalle = preDesembolsoDetalleBLLocal.get(id);

			FacesMessage message;

			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante PREAUTORIZADO satisfactoriamente", "");

			if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) { // MEFP
				PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoMefp').hide();");
			} else {// EPNES
				PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoEpnes').hide();");
			}

			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void autorizarRegistroDesembolso() {
		log.info("Ingreso a preautorizar");

		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = itemActualDesembolsoDetalle.getId();
			/** CODIGO PARA AUTORIZAR COMPROBANTE **/
			Boolean respuesta = Boolean.FALSE;
			if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) { // MEFP
				respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualDesembolsoDetalle.getId(),
						itemActualDesembolsoDetalle.getPdsCodcmp(), itemActualDesembolsoDetalle.getCodcred(),
						itemActualDesembolsoDetalle.getCodmod(),
						Cttes.AUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());
			} else {// EPNES
				respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(itemActualDesembolsoDetalle.getId(),
						itemActualDesembolsoDetalle.getPdsCodcmp(), itemActualDesembolsoDetalle.getCodcred(),
						itemActualDesembolsoDetalle.getCodmod(),
						Cttes.AUTORIZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());
			}
			itemActualDesembolsoDetalle = preDesembolsoDetalleBLLocal.get(id);
			FacesMessage message;
			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante AUTORIZADO satisfactoriamente", "");

			if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) { // MEFP
				PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoMefp').hide();");
			} else {// EPNES
				PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoEpnes').hide();");
			}

			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void rechazarRegistroDesembolso() {
		try {

			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			Integer id = itemActualDesembolsoDetalle.getId();
			/** CODIGO PARA RECHAZAR COMPROBANTE **/
			Boolean respuesta = preRegistrogarantiasBLLocal.cambiarEstadoOperComprob(
					itemActualDesembolsoDetalle.getId(), itemActualDesembolsoDetalle.getPdsCodcmp(),
					itemActualDesembolsoDetalle.getCodcred(), itemActualDesembolsoDetalle.getCodmod(),
					Cttes.RECHAZAR_COMPROBANTE_COIN, usuario.getLogin(), UtilWeb.getIPRemoto());

			FacesMessage message;
			itemActualDesembolsoDetalle = preDesembolsoDetalleBLLocal.get(id);
			message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Comprobante RECHAZADO satisfactoriamente", "");

			if (codCliente.intValue() == Cttes.MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS.intValue()) { // MEFP
				PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoMefp').hide();");
			} else {// EPNES
				PrimeFaces.current().executeScript("PF('dlgVerComprobanteDesembolsoEpnes').hide();");
			}

			FacesContext.getCurrentInstance().addMessage(null, message);

		} catch (Exception e) {
			log.error(e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

}
