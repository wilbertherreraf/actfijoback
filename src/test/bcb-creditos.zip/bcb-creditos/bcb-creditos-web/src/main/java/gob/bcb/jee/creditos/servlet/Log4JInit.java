package gob.bcb.jee.creditos.servlet;

import java.io.FileInputStream;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Configurator;

/**
 * Clase que permite la inicializacion de log4j
 * 
 * @author ysalinas
 * 
 */
@WebServlet(name = "InitLog4j", urlPatterns = { "/initLog4j" }, initParams = { @WebInitParam(name = "log4j-init-file", value = "/WEB-INF/log4j2/log4j2.xml") }, loadOnStartup = 1)
public class Log4JInit extends HttpServlet
{

  /**
	 * 
	 */
  private static final long serialVersionUID = 1L;

  @Override
  public void init(ServletConfig config) throws ServletException
  {

    // Obtiene el parametro de inicio
    String log4jFile = config.getInitParameter("log4j-init-file");

    // Obtiene la ruta real del archivo (ruta absoluta)
    ServletContext context = config.getServletContext();
    log4jFile = context.getRealPath(log4jFile);

    System.out.println("log4jFile: " + log4jFile);

    try
    {
      ConfigurationSource source = new ConfigurationSource(
          new FileInputStream(log4jFile));
      Configurator.initialize(null, source);
    }
    catch (Exception e)
    {
      System.out.println("Configuracion Basica");
    }

    super.init(config);
  }

}
