package gob.bcb.jee.creditos.web.pages;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import gob.bcb.jee.creditos.BL.PreDesembBLLocal;
import gob.bcb.jee.creditos.BL.PrePagocuotaBLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocal;
import gob.bcb.jee.creditos.QL.PrePrestamosQLLocal;
import gob.bcb.jee.creditos.entidades.EstadoDesembolsosQuery;
import gob.bcb.jee.creditos.entidades.PrePagocuota;
import gob.bcb.jee.creditos.entidades.VPlanPagosConsolQuery;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.util.UtilDate;
import lombok.Getter;
import lombok.Setter;

@ManagedBean(name = "dashboardBean")
@ViewScoped
@Getter
@Setter

public class DashboardBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @Inject
    private PrePlanpagosQLLocal prePlanpagosQLLocal;
    @Inject
    private PrePagocuotaBLLocal prePagocuotaBLLocal;
    @Inject
    private PrePrestamosQLLocal prePrestamosQLLocal;
	@Inject
	private PreDesembBLLocal preDesembBLLocal;    
    // Variables para las tarjetas
    private Integer numeroCreditosVigentes;
    private BigDecimal montoTotalRecuperar;
    private BigDecimal montoTotalOtorgado;
    private BigDecimal montoPeriodoDevengado;    
    private Integer proximosVencimientos;
    private List<VPlanPagosConsolQuery> listaProximosVencimientos = new ArrayList<>();
    private Integer diasVcto = 45;
    @PostConstruct
    public void init() {
        cargarDatosDashboard();
        cargarTablaVencimientos();
    }

    private void cargarDatosDashboard() {
        numeroCreditosVigentes = prePrestamosQLLocal.presVigentes();
        montoTotalRecuperar = prePrestamosQLLocal.mntPorRecuperar();
        montoTotalOtorgado = prePrestamosQLLocal.mntOtorgado();
        montoPeriodoDevengado = preDesembBLLocal.devengadoPorCredAFech(new Date());

        cargarVencimientosReales();
    }

    private void cargarVencimientosReales() {

    }

    private List<VPlanPagosConsolQuery> vctosPendientes() {
        try {
            Date hoy = new Date();
            Date hoyMasXdias = UtilDate.addTime(hoy, diasVcto, 5);
            Date ayer = UtilDate.addTime(hoy, -1, 5);
            List<VPlanPagosConsolQuery> planpagosVctos = prePlanpagosQLLocal.cuotasVencPendOSgtes(ayer, hoyMasXdias)
                    .stream().filter(pc -> {
                        PrePrestamos pre = prePrestamosQLLocal.prestamoById(pc.getCodcred(), pc.getCodmod());
                        pc.setPrestamos(pre);
                        if (pre.getPreStatus() == 9) {
                            return false;
                        }
                        boolean consaldo = (pc.getAmortizacionSaldo().compareTo(BigDecimal.ZERO) > 0)
                                || (pc.getInteresSaldo().compareTo(BigDecimal.ZERO) > 0);
                        if (consaldo) {
                            return true;
                        }
                        Optional<PrePagocuota> pcSinCmpbList = prePagocuotaBLLocal
                                .cuotasPendientesSinCmp(pc.getCodcred(), pc.getCodmod(), pc.getFechavencuo())
                                .stream().filter(p -> {
                                    return StringUtils.isBlank(p.getNroComprobanteCoin());
                                }).findFirst();
                        return pcSinCmpbList.isPresent();
                    }).collect(Collectors.toList());

            return planpagosVctos;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void cargarTablaVencimientos() {
        listaProximosVencimientos = vctosPendientes();
        proximosVencimientos = listaProximosVencimientos.size();
    }

    public String verDetalleVencimiento(EstadoDesembolsosQuery vencimiento) {
        Map<String, Object> sessionMap = FacesContext.getCurrentInstance()
                .getExternalContext().getSessionMap();
        sessionMap.put("vencimientoSeleccionado", vencimiento);
        return "/vencimientos/detalleVencimiento.xhtml?faces-redirect=true";
    }


    public void actualizarDashboard() {
        cargarDatosDashboard();
        cargarTablaVencimientos();
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Dashboard actualizado",
                        "Los datos han sido actualizados correctamente"));
    }

    public Integer getNumeroCreditosVigentes() {
        return numeroCreditosVigentes;
    }

    public void setNumeroCreditosVigentes(Integer numeroCreditosVigentes) {
        this.numeroCreditosVigentes = numeroCreditosVigentes;
    }

    public BigDecimal getMontoTotalRecuperar() {
        return montoTotalRecuperar;
    }

    public void setMontoTotalRecuperar(BigDecimal montoTotalRecuperar) {
        this.montoTotalRecuperar = montoTotalRecuperar;
    }

    public BigDecimal getMontoTotalOtorgado() {
        return montoTotalOtorgado;
    }

    public void setMontoTotalOtorgado(BigDecimal montoTotalOtorgado) {
        this.montoTotalOtorgado = montoTotalOtorgado;
    }

    public Integer getProximosVencimientos() {
        return proximosVencimientos;
    }

    public void setProximosVencimientos(Integer proximosVencimientos) {
        this.proximosVencimientos = proximosVencimientos;
    }

}