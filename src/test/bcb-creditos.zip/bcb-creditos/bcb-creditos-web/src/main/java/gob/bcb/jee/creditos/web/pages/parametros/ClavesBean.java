package gob.bcb.jee.creditos.web.pages.parametros;


import gob.bcb.jee.creditos.BL.SacClavesBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.SacClaves;
import gob.bcb.jee.creditos.schedule.CttesQuartz;
import gob.bcb.jee.creditos.schedule.DevengadosJob;
import gob.bcb.jee.creditos.schedule.InitJob;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilJobs;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;


import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.joda.time.DateTime;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "ClavesBean")
@ViewScoped
@Getter
@Setter
public class ClavesBean  implements Serializable {

    private static final long serialVersionUID = 1L;
  
    @Inject
    private SacClavesBLLocal sacClavesBLLocal;    
    
   
    
    private SacClaves sacClaves= new SacClaves();
    
    private List<SacClaves> listSacClaves=new ArrayList<>();    
    
    public ClavesBean() {
    }

    @PostConstruct
    public void init() {     
    	try {
    		listSacClaves=sacClavesBLLocal.list();
		}  
    
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}     	
    }
   
    public void iniciarNuevo() {
    	sacClaves= new SacClaves();
    }
           
   
    public void guardar() {
    	try {
    		
    		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
    		sacClaves.setClvAuditusr(usuario.getLogin());
    		sacClaves.setClvAuditfho(new Timestamp(new Date().getTime()));
    		sacClaves.setClvAuditwst(UtilWeb.getIPRemoto());
    		
	    	sacClaves.setClvCodclv(sacClaves.getClvCodclv().toUpperCase());
	    	sacClaves.setClvDescrip(sacClaves.getClvDescrip().toUpperCase());
	    	sacClaves.setClvValor(sacClaves.getClvValor().toUpperCase());
	    	sacClaves.setClvAbrev(sacClaves.getClvAbrev().toUpperCase());
	    		sacClavesBLLocal.persist(sacClaves, usuario.getLogin());
	    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente","");
	    	    FacesContext.getCurrentInstance().addMessage(null, message);
	    	
	    	Log.Info("Registro guardado:"+sacClaves.getClvCodclv());
			if(sacClaves.getClvCodclv().equals("JOB_DEVENGADO"))	{
				String []hora=sacClaves.getClvValor().split(":");	
				Log.Info("Hora de ejecución: " + Arrays.toString(hora));
				if(hora.length!=3) {
					Log.Error("Horario no permitido");					
				    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Horario no permitido"));
				    return;
				}
				DevengadosJob devJob=new DevengadosJob();
				devJob.programarJob(sacClaves.getClvCodclv().trim(), sacClaves.getClvValor());				
			}
	    	
            
	    limpiar();
	    init();
		} 

    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		} 
    	
    	
    }    
  
    public void limpiar() {
    	sacClaves =  new SacClaves();        
    	listSacClaves=new ArrayList<>();					
    }
}
