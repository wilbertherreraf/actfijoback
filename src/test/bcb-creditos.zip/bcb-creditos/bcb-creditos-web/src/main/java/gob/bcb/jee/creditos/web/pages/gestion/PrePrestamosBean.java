package gob.bcb.jee.creditos.web.pages.gestion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Inject;

import gob.bcb.jee.creditos.util.Log;

import gob.bcb.jee.creditos.BL.ArticuloBLLocal;
import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenModuloBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.BL.PrePrccontaBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreTasaspreBLLocal;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenModulo;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.PrePrcconta;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PreTasaspre;
import gob.bcb.jee.creditos.web.pages.UtilWebBean;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

@ManagedBean(name = "prePrestamosBean")
@ViewScoped
@Getter
@Setter
public class PrePrestamosBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @Inject
    UtilWebBean utilWebBean;

    @Inject
    private GenTipProductoBLLocal genTipProductoBLLocal;

    @Inject
    private GenDesctablaBLLocal genDesctablaBLLocal;

    @Inject
    private GenMonedaBLLocal genMonedaBLLocal;

    @Inject
    private PrePrestamosBLLocal prePrestamosBLLocal;

    @Inject
    private GenModuloBLLocal genModuloBLLocal;

    @Inject
    private CliPersonaBLLocal service;
    @Inject
    private ArticuloBLLocal articuloBLLocal;
    @Inject
    private PreTasaspreBLLocal preTasaspreBLLocal;
    @Inject
    private PrePrccontaBLLocal prePrccontaBLLocal;
    @Inject 
    private PrePrestamosSessionBean prePrestamosSessionBean;
    private List<CliPersona> products;

    private Double plazo;
    private Double gracia;
    private Double graciaint;

    private PrePrestamos prestamosSelected = new PrePrestamos();
    private List<PreTasaspre> listTasas;
    PreTasaspre tasa = new PreTasaspre();
    private List<PrePrestamos> listPrePrestamos;
    private List<PrePrestamos> filterListPrePrestamos;
    private boolean habilitadoCampos = true;
    private CliPersona cliPersona = new CliPersona();
    private String cliente;
    private List<GenTipproducto> listGenTipproductos;
    private GenTipproducto genTipproducto;
    private String igenTipproducto;

    private List<GenModulo> listGenModulo;

    private List<GenMoneda> listGenMoneda;
    private GenMoneda genGenMoneda;
    private Integer igenGenMoneda;

    private Integer igenGenModulo;
    private Integer codigoPrestamo;
    private String contrato;

    // private List<GenDesctabla> listGenDesctablaRubro;
    private GenDesctabla genDesctablaRubro;
    private Integer igenDesctablaRubro;
    private String txt1;
    // private List<GenDesctabla> listGenDesctablaDestino;
    // private GenDesctabla genDesctablaDestino;
    private Integer igenDesctablaDestino;
    private List<GenDesctabla> listGenDesctablaPlazo;
    private List<GenDesctabla> listGenDesctablaCapitalizacion;
    private List<String> listSeleccionados = new ArrayList<String>();
    private List<SelectItem> listLeyesSelect = new ArrayList<SelectItem>();
    private List<Object[]> listLeyes = new ArrayList<>();

    private List<PrePrcconta> listaDevengados;
    PrePrcconta devengado = new PrePrcconta();
    PrePrcconta modifDevengado = new PrePrcconta();

    private Date fechaUltDevengadoCredito;

    @PostConstruct
    public void init() {
        Log.Info("pre prestamos cread...");
        if (prePrestamosSessionBean != null && prePrestamosSessionBean.getPrePrestamosSelected() != null) {
            Log.Info("IIIIIIIIIIII " + prePrestamosSessionBean.getPrePrestamosSelected().getId().getPreCodcred());
        } else {
            Log.Info("Nulooooooooooooooooooooooo ");
        }
    }

    public void load(PrePrestamos prePrestamos) {
        Log.Info("En loaaaaaaaaaaaaad " + prePrestamos.getId().getPreCodcred());
        try {
            Map<String, Object> valores = new HashMap<>();
            valores.put("pre_codcred", prePrestamos.getId().getPreCodcred());
            listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID_R, valores);
            PrePrestamos prestamosSelected = listPrePrestamos.get(0);
            prePrestamosSessionBean.setPrePrestamosSelected(prestamosSelected);
        } catch (Exception e) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }
}
