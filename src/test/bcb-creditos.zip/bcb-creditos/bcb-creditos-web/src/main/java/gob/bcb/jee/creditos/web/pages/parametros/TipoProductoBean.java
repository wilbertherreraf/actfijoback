package gob.bcb.jee.creditos.web.pages.parametros;


import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenModuloBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenDesctablaPK;
import gob.bcb.jee.creditos.model.GenModulo;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.GenTipproductoPK;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;


import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "TipoProductoBean")
@ViewScoped
@Getter
@Setter
public class TipoProductoBean  implements Serializable {

    private static final long serialVersionUID = 1L;
  

    @Inject
    private GenModuloBLLocal genModuloBLLocal;

    @Inject
    private GenTipProductoBLLocal genTipoProductoBLLocal;
    
    private List<GenModulo> listGenModulo;
    private List<GenTipproducto> listGenTipoProducto;
    
    private GenTipproducto genTipoProducto= new GenTipproducto();
    private GenTipproductoPK genTipoProductoPK= new GenTipproductoPK();  
    
    public TipoProductoBean() {
    }

    @PostConstruct
    public void init() {     
    	try {
    		genTipoProducto.setId(genTipoProductoPK);
    		listGenTipoProducto=genTipoProductoBLLocal.list();
    		listGenModulo=genModuloBLLocal.list();
		} 
    
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}     	
    }
   
    public void iniciarNuevo() {
    	genTipoProducto= new GenTipproducto();   
    	genTipoProductoPK=new GenTipproductoPK();
    	genTipoProducto.setId(genTipoProductoPK);
    	
    }
    
   
    public void guardar() {
    	try {    		
    		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
    		genTipoProducto.setTpdAuditusr(usuario.getLogin());
    		genTipoProducto.setTpdAuditfho(new Timestamp(new Date().getTime()));
    		genTipoProducto.setTpdAuditwst(UtilWeb.getIPRemoto());
	    	if( genTipoProducto.getId().getTpdCodprod()==null) {
	    		int codigo=genTipoProductoBLLocal.getIdNewId(genTipoProducto.getId().getTpdCodmod());	   
	    		genTipoProducto.getId().setTpdCodprod(codigo);
	    		genTipoProductoBLLocal.persist(genTipoProducto, "");	    		
	    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente","");
	    	    FacesContext.getCurrentInstance().addMessage(null, message);
	    	}
	    	else {
	    		genTipoProductoBLLocal.merge(genTipoProducto, "");
	    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro modificado satisfactoriamente","");
	    	    FacesContext.getCurrentInstance().addMessage(null, message);
	    	}
	    	Log.Info("Registro guardado:"+genTipoProducto);
				
	    limpiar();
	    init();
		}  
    
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		} 
    	
    	
    }
    
  
    public void limpiar() {
    	genTipoProducto =  new GenTipproducto();        
       			
    }
}
