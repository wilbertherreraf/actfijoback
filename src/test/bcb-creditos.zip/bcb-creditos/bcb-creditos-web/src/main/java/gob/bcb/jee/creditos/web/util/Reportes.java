package gob.bcb.jee.creditos.web.util;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

public class Reportes implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String DIRECC_REPORTES = "/WEB-INF/reportes/";

	private String tituloReporte;
	private String nombreReportePrincipal;
	private String direccionReporte;
	private String direccionLogo;



	private HashMap<String, Object> datosReporte;
	private HashMap<String, Object> parametros;
	private HashMap<String, Object> direccSubReportes;

	private JasperPrint jasperPrint;

	public Reportes() {
		this.datosReporte = new HashMap<String, Object>();
		this.parametros = new HashMap<String, Object>();
	}

	private void iniciar(HashMap<String, Object> datosParametricos) throws JRException {
		String direccRealReporte = null;
		String direccRealLogoBcb = null;
		String direccRealSubreporte = null;
		String direccRealCarpetaReporte = null;

		ExternalContext externalContext;
		JRBeanCollectionDataSource dataSource;
		List<HashMap<String, Object>> listaDatosReporte = new ArrayList<HashMap<String, Object>>();

		externalContext = FacesContext.getCurrentInstance()
				.getExternalContext();

		direccRealReporte = externalContext.getRealPath(DIRECC_REPORTES
				+ this.direccionReporte + this.nombreReportePrincipal);

		direccRealCarpetaReporte = externalContext.getRealPath(DIRECC_REPORTES
				+ this.direccionReporte)
				+ "/";

		if (this.direccionLogo != null && !this.direccionLogo.isEmpty()) {
			direccRealLogoBcb = externalContext.getRealPath(this.direccionLogo);
		}

		this.parametros.put("P_DIRECC_REPORTE", direccRealCarpetaReporte);
		this.parametros.put("P_DIRECC_LOGO", direccRealLogoBcb);

		if (datosParametricos != null && !datosParametricos.isEmpty()) {
			this.parametros.putAll(datosParametricos);
		}

		if (this.direccSubReportes != null && !this.direccSubReportes.isEmpty()) {
			for (Entry<String, Object> direccion : this.direccSubReportes.entrySet()) {
				direccRealSubreporte = externalContext
						.getRealPath(DIRECC_REPORTES + direccion.getValue())
						+ "/";
				this.parametros.put(direccion.getKey(), direccRealSubreporte);
			}
		}

		listaDatosReporte.add(this.datosReporte);

		dataSource = new JRBeanCollectionDataSource(listaDatosReporte);

		this.jasperPrint = JasperFillManager.fillReport(direccRealReporte,
				this.parametros, dataSource);
	}

	private void enviarDatosCabeceraReporte() {
		HashMap<String, Object> datos = new HashMap<String, Object>();
		List<HashMap<String, Object>> listaDatos = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> datosReporte = new HashMap<String, Object>();

		//TODO: Parametrizar nombre del sistema en base o en archivo de configuracion
		datos.put("nombreSistema", "SISCRED Sistema de Administracion de Créditos a Entidades y Empresas del Sector Público");
		datos.put("tituloReporte", this.tituloReporte);
		listaDatos.add(datos);
		datosReporte.put("DATOS_CABECERA", listaDatos);

		this.adicionarColeccionDatosReporte(datosReporte);
	}

	private void enviarDatosPiePaginaReporte() {
		HashMap<String, Object> datos = new HashMap<String, Object>();
		List<HashMap<String, Object>> listaDatos = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> datosReporte = new HashMap<String, Object>();

		datos.put("usuario", "Pepito Perez - pperez");
		listaDatos.add(datos);
		datosReporte.put("DATOS_PIE_PAGINA", listaDatos);

		this.adicionarColeccionDatosReporte(datosReporte);
	}

	public void generarReporteExcel() throws JRException, IOException {
		this.generarReporteExcel(null);
	}

	public void generarReporteExcel(HashMap<String, Object> datosParametricos) throws JRException,
			IOException {
		ServletOutputStream output;
		HttpServletResponse response;
		JRXlsxExporter xlsExporter = new JRXlsxExporter();

		this.enviarDatosCabeceraReporte();
		this.enviarDatosPiePaginaReporte();
		this.iniciar(datosParametricos);

		response = (HttpServletResponse) FacesContext.getCurrentInstance()
				.getExternalContext().getResponse();

		output = response.getOutputStream();

		response.addHeader("Content-disposition",
				"attachment; filename=report.xls");

		xlsExporter.setParameter(JRXlsExporterParameter.JASPER_PRINT,
				this.jasperPrint);
		xlsExporter.setParameter(JRXlsExporterParameter.OUTPUT_STREAM, output);

		xlsExporter.exportReport();

		FacesContext.getCurrentInstance().responseComplete();
	}

	public void generarReportePdf() throws JRException, IOException {
		this.generarReportePdf(null);
	}

	public void generarReportePdf(HashMap<String, Object> datosParametricos) throws JRException,
			IOException {
		HttpServletResponse response;
		ServletOutputStream output;

		this.enviarDatosCabeceraReporte();
		this.enviarDatosPiePaginaReporte();
		this.iniciar(datosParametricos);

		response = (HttpServletResponse) FacesContext.getCurrentInstance()
				.getExternalContext().getResponse();

		output = response.getOutputStream();

		response.addHeader("Content-disposition",
				"attachment; filename=report.pdf");

		JasperExportManager.exportReportToPdfStream(this.jasperPrint, output);

		FacesContext.getCurrentInstance().responseComplete();
	}

	public void adicionarColeccionDatosReporte(
			HashMap<String, Object> coleccionDatosReporte) {
		this.datosReporte.putAll(coleccionDatosReporte);
	}

	public void setDatosReporte(HashMap<String, Object> datosReporte) {
		this.datosReporte = datosReporte;
	}

	public String getTituloReporte() {
		return tituloReporte;
	}

	public void setTituloReporte(String tituloReporte) {
		this.tituloReporte = tituloReporte;
	}

	public String getNombreReportePrincipal() {
		return nombreReportePrincipal;
	}

	public void setNombreReportePrincipal(String nombreReportePrincipal) {
		this.nombreReportePrincipal = nombreReportePrincipal;
	}

	public String getDireccionReporte() {
		return direccionReporte;
	}

	public void setDireccionReporte(String direccionReporte) {
		this.direccionReporte = direccionReporte;
	}

	public String getDireccionLogo() {
		return direccionLogo;
	}

	public void setDireccionLogo(String direccionLogo) {
		this.direccionLogo = direccionLogo;
	}

	public HashMap<String, Object> getParametros() {
		return parametros;
	}

	public void setParametros(HashMap<String, Object> parametros) {
		this.parametros = parametros;
	}

	public HashMap<String, Object> getDatosReporte() {
		return datosReporte;
	}

	public HashMap<String, Object> getDireccSubReportes() {
		return direccSubReportes;
	}

	public void setDireccSubReportes(HashMap<String, Object> direccSubReportes) {
		this.direccSubReportes = direccSubReportes;
	}

}
