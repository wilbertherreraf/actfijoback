package gob.bcb.jee.creditos.web.pages;

import gob.bcb.jee.axesso.entidades.Password;
import gob.bcb.jee.axesso.entidades.pojo.DatosAuditoria;
import gob.bcb.jee.axesso.excepciones.EntityValidationException;
import gob.bcb.jee.axesso.excepciones.OperationException;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.remoto.ServicioAxessoRemotoAdapter;
import gob.bcb.jee.creditos.web.util.ContextActions;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.SeguridadBean;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import java.io.Serializable;
import java.util.Date;

/**
 * Clase para el control de cambio de contraseña
 */
@SuppressWarnings("serial")
@ManagedBean(name = "cambiarPasswordBean")
@Getter
@Setter
@ViewScoped
public class CambiarPasswordBean implements Serializable {
 
    // almacena la contraseña anterior
    private String passwordBef;
    // almacena la contraseña nueva
    private String passwordNew;
    // almacena la repeticion de la contraseña nueva
    private String passwordRep;
    // switch de control si la operacion ha sido exitosa
    private boolean operacionExitosa;
    // switch de control para saber si el dialogo se muestra o no
    private boolean mostrarDialogo;
    // mensaje del dialogo
    private String mensajeDialogo;
    /*
     * Inyecciones remotas
     */
    @Inject
    ServicioAxessoRemotoAdapter servicioAxessoRemoto;
    /**
     * objeto que controla las sesiones en la aplicacion
     */
    @ManagedProperty(value = "#{seguridadBean}")
    SeguridadBean seguridadBean;
    /**
     * objeto Contrasenia del TCIA
     */
    Password passwordAxesso;

    public void verificarPassword() {

    }

    /**
     * Metodo que realiza la el cambio de contraseña
     */
    public void changePassword() {
        Log.Trace("Iniciando cambio de contraseña");
        this.operacionExitosa = false;
        this.mostrarDialogo = false;
        try {
            // obtiene el objeto Usuario desde sesion

            Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
            // validacion de valores de formulario.
            if (validateForm(usuario)) {
                Log.Trace("Iniciando comunicacion con Axesso");
                // Realiza el proceso de actualizacion de contraseña

                DatosAuditoria datosAuditoria = new DatosAuditoria();
                datosAuditoria.setFecha(new Date());
                datosAuditoria.setHost(UtilWeb.getIPRemoto());
                datosAuditoria.setUsuario(usuario.getLogin());

                // cambia de estado a la anterior contraseña
                //servicioAxessoRemoto.cambiarEstadoRegistroContrasenia(passwordAxesso.getContraseniaid(), CttesWeb.TCIABCB_ESTADO_CONTRASENIA_BLOQUEADO, Cttes.COD_TRANSACCION_BLOQUEO_CONTRASENIA, UtilWeb.getBeanActualUserTCIA());

                // ingresa la nueva contraseña para el usuario
                servicioAxessoRemoto.asignarPassword(usuario.getUsuarioId(), this.passwordNew, datosAuditoria);
                //agregarContrasenia(newPassword, this.passwordNew, UtilWeb.getBeanActualUserTCIA());

                this.operacionExitosa = true;
                this.mensajeDialogo = "Contraseña modificada exitosamente, para continuar debe autenticarse nuevamente";
                Log.Trace("Proceso de cambio de contraseña completado");
                Log.Debug("operacionExitosa=" + this.operacionExitosa);
                UtilWeb.redireccionarURL(CttesWeb.URL_INDEX + "/logout");
            }
        }  catch (OperationException e) {
            Log.Info("Error: " + e.getMessage());
        } catch (EntityValidationException e) {
            
            for (String error : e.getFieldErrors()){
                ContextActions.sendError(error);
            }
        }
        if (this.operacionExitosa) {
            Log.Trace("Muestra dialogo");
            this.mostrarDialogo = true;
            this.mensajeDialogo = "El cambio ";
            ContextActions.primeContext("PF('w_dglConfirmarCambio').hide();");
            ContextActions.sendDialogInfo(ContextActions.EDITADO);
            //ContextActions.primeContext("PF('dlgRespuesta').initPosition(); PF('dlgRespuesta').show();");
        }else{
            ContextActions.primeContext("PF('w_dglConfirmarCambio').hide();");
        }
        Log.Trace("Finalizando cambio de contraseña");
    }

    /**
     * Metodo que realiza el cierre del dialogo de respuesta en caso que sea
     * exitoso redirecciona a login caso contrario limpia el formulario
     */
    public void closeDialog() {
//    Log.Trace("Iniciando cierre de dialogo");
//    try
//    {
//      if (operacionExitosa)
//      {
//        seguridadBean.removeSession();
//        UtilWeb.redireccionarURL(CttesWeb.URL_INDEX);
//      }
//    }
//    catch (Exception e)
//    {
//      Log.Error("Error en la limpieza de la sesion", e);
//      ContextActions.sendDialogGenericError("Ha ocurrido un error en la limpieza de la sesion");
//    }
//    Log.Trace("Finalizando cierre de dialogo");
    }

    /**
     * Metodo que realiza la validacion del formulario de cambio de contraseña
     *
     * @return
     */
    private boolean validateForm(Usuario usuario) {
        boolean respuesta = true;
        Log.Trace("Iniciando validacion de formulario");
        try {
            // validacion de existencia de campos
            if (this.passwordBef.equals(null) || this.passwordBef.isEmpty()) {
                ContextActions.sendError("La CONTRASEÑA ACTUAL es vacia");
                respuesta = false;
            }
            if (this.passwordNew.equals(null) || this.passwordNew.isEmpty()) {
                ContextActions.sendError("La CONTRASEÑA NUEVA es vacia");
                respuesta = false;
            } else {
                // validacion del numero de caracteres de la nueva contraseña
                if (this.passwordNew.length() < 8) {
                    ContextActions.sendError("La CONTRASEÑA NUEVA debe tener minimo ocho caracteres");
                    respuesta = false;
                }
            }
            if (this.passwordRep.equals(null) || this.passwordRep.isEmpty()) {
                ContextActions.sendError("La REPETICION de la contraseña es vacia");
                respuesta = false;
            }
            // validacion si la contraseña nueva y su repeticion coinciden
            if (!this.passwordNew.equals(this.passwordRep)) {
                ContextActions.sendError("La REPETICION de la contraseña y la CONTRASEÑA no tienen el mismo valor");
                respuesta = false;
            }

            if (respuesta) {
                Log.Debug("Iniciando validacion desde el Axesso");
                // validacion si la contraseña actual es correcta
                this.passwordAxesso = servicioAxessoRemoto.getPasswordByUsuarioAndPasseord(
                        usuario.getLogin(), this.passwordBef);
                if (passwordAxesso == null) {
                    ContextActions.sendError("La CONTRASEÑA ACTUAL es incorrecta");
                    return false;
                }
                // validacion si la contraseña nueva no existe en los 8 ultimos

                Log.Trace("Finalizacion de validacion desde el Axesso");
            }
        } catch (Throwable e) {
            Log.Error("Existen problemas de comunicacion"+ e);
            ContextActions.sendDialogGenericError("Ha ocurrido un error en la comunicación");
            return false;
        }
        Log.Trace("Finalizacion de validacion de formulario");
        return respuesta;
    }

}
