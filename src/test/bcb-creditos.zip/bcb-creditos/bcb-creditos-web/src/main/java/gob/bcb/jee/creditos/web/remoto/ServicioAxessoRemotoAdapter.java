package gob.bcb.jee.creditos.web.remoto;

import gob.bcb.jee.axesso.entidades.Agencia;
import gob.bcb.jee.axesso.entidades.Participante;
import gob.bcb.jee.axesso.entidades.Password;
import gob.bcb.jee.axesso.entidades.Permiso;
import gob.bcb.jee.axesso.entidades.Recurso;
import gob.bcb.jee.axesso.entidades.Rol;
import gob.bcb.jee.axesso.entidades.Usuario;
import gob.bcb.jee.axesso.entidades.pojo.DatosAuditoria;
import gob.bcb.jee.axesso.excepciones.EntityValidationException;
import gob.bcb.jee.axesso.excepciones.OperationException;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Date;
import java.util.List;

/**
 * Adaptador CDI para el servicio remoto de Axesso.
 */
@ApplicationScoped
public class ServicioAxessoRemotoAdapter {

    @Inject
    private ServicioAxessoRemoto servicioAxessoRemoto;

    public Usuario getUsuario(Integer usuarioId) throws Exception {
        return servicioAxessoRemoto.getUsuario(usuarioId);
    }

    public Usuario getUsuarioByLogin(String login) throws Exception {
        return servicioAxessoRemoto.getUsuarioByLogin(login);
    }

    public List<Rol> listRolesByUsuario(Integer usuarioId) throws Exception {
        return servicioAxessoRemoto.listRolesByUsuario(usuarioId);
    }

    public List<Recurso> listRecursosByRol(String codRol) throws Exception {
        return servicioAxessoRemoto.listRecursosByRol(codRol);
    }

    public List<Permiso> listPermisosByRolAndRecurso(String codRol, String codRecurso) throws Exception {
        return servicioAxessoRemoto.listPermisosByRolAndRecurso(codRol, codRecurso);
    }

    public Participante getParticipanteByLoginUsuario(String loginUsuario) throws Exception {
        return servicioAxessoRemoto.getParticipanteByLoginUsuario(loginUsuario);
    }

    public Password getPasswordByUsuarioAndPasseord(String loginUsuario, String passwordUsuario) throws Exception {
        return servicioAxessoRemoto.getPasswordByUsuarioAndPasseord(loginUsuario, passwordUsuario);
    }

    public void asignarPassword(Integer usuarioId, String password, DatosAuditoria datosAuditoria)
            throws EntityValidationException, OperationException {
        servicioAxessoRemoto.asignarPassword(usuarioId, password, datosAuditoria);
    }

    public void registrarUsuario(Usuario entity, List<Rol> roles, boolean generarPassword, boolean email)
            throws EntityValidationException, OperationException {
        servicioAxessoRemoto.registrarUsuario(entity, roles, generarPassword, email);
    }

    public Agencia getAgencias(Integer usuarioId) throws OperationException {
        return servicioAxessoRemoto.getAgencias(usuarioId);
    }

    public void modificarUsuario(Usuario entity, boolean email) throws EntityValidationException, OperationException {
        servicioAxessoRemoto.modificarUsuario(entity, email);
    }

    public boolean isPasswordVigente(Integer usuarioId) throws OperationException {
        return servicioAxessoRemoto.isPasswordVigente(usuarioId);
    }

    public void lisUsuariosLike(String usuario) throws OperationException {
        servicioAxessoRemoto.lisUsuariosLike(usuario);
    }
}
