package gob.bcb.jee.creditos.web.util;

import java.sql.SQLException;

import javax.ejb.ApplicationException;

/**
 * Exception del tipo aplicacion, que la misma propagada marca para realizar un
 * rollback de la misma
 * 
 * @author ysalinas
 * 
 */
@ApplicationException(rollback = true)
public class PlantillaWebEEException extends Exception
{

  @SuppressWarnings("unused")
  private Object objetoError;

  /**
	 * 
	 */
  private static final long serialVersionUID = 1L;

  /**
   * Se debe de utilizar solo cuando se controle una exception del tipo
   * EJBException y se necesite cargar el objeto que dio la excepcion, si se
   * 
   * @param objetoError
   * @param cause
   */
  public PlantillaWebEEException(Object objetoError, Throwable cause)
  {

    super(obtenerMensaje(cause), cause);
    this.objetoError = objetoError;

  }

  /**
   * Se debe de utilizar solo cuando se controle una exception la cual sabemos
   * cual es el mensaje en concreto de la excepcion
   * 
   * @param message
   */
  public PlantillaWebEEException(String message)
  {
    super(message);

  }

  /**
   * Se debe de utilizar solo cuando no se sepa el mensaje y se trara de una
   * excepcion generica
   * 
   * @param message
   * @param cause
   */
  public PlantillaWebEEException(Throwable cause)
  {

    super(cause);

  }

  /**
   * Metodo que arma mensaje que son del tipo SQL, las que estan dentro de las
   * excepciones del tipo EJBException
   * 
   * @param throwable
   * @return
   */
  private static String obtenerMensaje(Throwable throwable)
  {
    String mensaje = "";

    StringBuilder mensajeException = new StringBuilder();
    int count = 0;
    for (Throwable cause = throwable; (cause != null && cause != cause
        .getCause()); cause = cause.getCause())
    {

      if (cause instanceof SQLException)
      {

        if (count > 0)
        {
          mensajeException.append(", ");
        }

        mensajeException.append(cause.getMessage());

        count++;

      }
    }

    return mensaje;
  }

}
