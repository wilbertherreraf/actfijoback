/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-plantillaWebEE-web
 * gob.bcb.jee.creditos.plantillaWebEE.web.util.Seguridad
 * 01/12/2016 - 18:32:00
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.web.util;

import gob.bcb.jee.axesso.entidades.Rol;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.remoto.ServicioAxessoRemotoAdapter;

import javax.annotation.PostConstruct;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.util.List;

//import gob.bcb.tciabcb.entidades.Recurso;
//import gob.bcb.tciabcb.entidades.Rol;

@ApplicationScoped
@ManagedBean
public class SeguridadBean implements Serializable
{
  private static final long serialVersionUID = 7697786159145169686L;


  @Inject
  private ServicioAxessoRemotoAdapter servicioAxessoRemoto;

  private final int segInactivosExpiracion = 900;

  public SeguridadBean()
  {
  }

  @PostConstruct
  public void initBean()
  {
    Log.Trace("Iniciando" + SeguridadBean.class.getSimpleName() + "... ");

    Log.Trace(SeguridadBean.class.getSimpleName() + " iniciado.");
  }

  /**
   * Obtiene el usuario principal que hizo el login.
   * 
   * @return
   */
  public String getUser()
  {
    try
    {
      String usrPrincipal = FacesContext.getCurrentInstance().getExternalContext().getUserPrincipal().getName();
      if (usrPrincipal == null || usrPrincipal == "")
      {
        throw new Exception("Error en la obtencion del usuario logueado. Usuario Nulo.");
      }
      Log.Debug("Usuario logueado: " + usrPrincipal);
      return usrPrincipal;
    }
    catch (Exception e)
    {
      Log.Error("Error en la obtencion del usuario logueado. Usuario Nulo."+ e);
      UtilWeb.redireccionarURL(CttesWeb.URL_INDEX);
      return null;
    }
  }

  /**
   * Verifica si el usuario logueado pertenece a un determinado rol
   * 
   * @param <code>String</code> rol
   * @return <code>boolean</code> true si pertenece al rol, false en caso
   *         contrario. Si existe un error la excepcion se propaga.
   */
  public boolean isUserInRol(String rol) throws Exception
  {
    return FacesContext.getCurrentInstance().getExternalContext().isUserInRole(rol);
  }

  /**
   * Obtiene el IP del cliente que se conecta a la aplicacion.
   * 
   * @return <code>String</code> IP.
   */
  public String getIPRemoto()
  {
    try
    {
      HttpServletRequest httpServletRequest = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
      String ip = httpServletRequest.getRemoteAddr();
      Log.Debug("IP conectado: " + ip);

      return ip;
    }
    catch (Exception e)
    {
      Log.Error("Error en la obtencion del IP de la terminal conectada. "+ e);
      UtilWeb.redireccionarURL(CttesWeb.URL_ERROR_EXCEPCION_FATAL);
      return null;
    }
  }

  /**
   * Obtiene el Host asignado al IP del cliente que se conecta a la aplicacion.
   * 
   * @return <code>String</code> Host.
   */
  public String getHostRemoto() throws Exception
  {
    try
    {
      HttpServletRequest httpServletRequest = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
      String host = httpServletRequest.getRemoteHost();
      Log.Debug("Host conectado:" + httpServletRequest.getRemoteHost());
      return host;
    }
    catch (Exception e)
    {
      Log.Error("Error en la obtencion del Host de la terminal conectada. "+ e);
      UtilWeb.redireccionarURL(CttesWeb.URL_ERROR_EXCEPCION_FATAL);
      return null;
    }
  }

  public Integer getSegInactivosExpiracion()
  {
    return segInactivosExpiracion;
  }

  /**
   * Caduca la sesion luego de un cierto tiempo de inactividad.
   * 
   */
  public void removeSession()
  {
    Log.Debug("remueve sesion");
    this.cleanSession();
    Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
    if (usuario != null)
    {
      Log.Debug("Sesion caducada.");
      String codUsuario = usuario.getLogin();
      try
      {
        Log.Debug("codUsuario" + codUsuario);
        //TODO: Modificar lista de recursos
        //servicioAxessoRemoto.limpiarSessionAbierta(codUsuario, CttesWeb.AXESSO_COD_APP);
      }
      catch (Exception e)
      {
        Log.Error("Error al limpiar sesion en TCIA"+ e);
      }

    }
    UtilWeb.redireccionarURL(CttesWeb.URL_INDEX);
    Log.Debug("Sesion caducada.");
  }

  /**
   * COntinua con la sesion activa
   * 
   * 
   */
  public void keepSession()
  {
    Log.Debug("Sesion activa");
  }

  /**
   * Limpia la sesion creada.
   * 
   * 
   */
  public void cleanSession()
  {
    HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
    try
    {
      request.getSession().invalidate();
      request.logout();

      Log.Debug("Cierre de sesion completo.");
    }
    catch (Exception e)
    {
      Log.Error("Error al caducar sesion. "+ e);
      UtilWeb.redireccionarURL(CttesWeb.URL_ERROR_EXCEPCION_FATAL);
    }
  }

  /**
   * Metodo que realiza la inicializacion de la sesion en el TCIBCB
   * 
   */
  public void createSession() throws OperationException
  {
    try
    {
      String codUsuario = ((Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO)).getLogin();
      Log.Debug("llamando servicio tcia registrarSesionAbierta con app=" + CttesWeb.AXESSO_COD_APP + "; usuario = " + codUsuario);
      //TODO: Modificar lista de recursos
      //return null;
      //servicioAxessoRemoto.registrarSesionAbierta(CttesWeb.AXESSO_COD_APP, codUsuario);
    }
    catch (Exception e)
    {
      Log.Error("Error en los EJB Remotos. "+ e);
      throw new OperationException("Error en los EJB Remotos", e);
    }
  }

  /**
   * Metodo que realiza la busqueda de los roles de los cuales el usuario
   * corresponde en la aplicacion
   * 
   * 
   * @return
   * @throws OperationException
   */
  public List<Rol> getUserRols(Integer usuarioId) throws OperationException
  {
    try
    {
      //TODO: Modificar lista de recursos
      //return null;
      return servicioAxessoRemoto.listRolesByUsuario(usuarioId);
    }
    catch (Exception e)
    {
      Log.Error("Error al obtener los roles del usuario:" + usuarioId+ e);
      throw new OperationException("Error al obtener los roles del usuario:" + usuarioId, e);
    }
  }

  /**
   * Metodo para obtener la lista de recursos por aplicacion
   * 
   * 
   * @param codApp
   * @return
   * @throws OperationException
   */
  public List<Recurso> getListResourceByApp(String codApp)
      throws OperationException
  {
    try
    {
      //TODO: Modificar lista de recursos
      return null;
      //return servicioAxessoRemoto.obtenerListaRecursosAplicacion(codApp);
    }
    catch (Exception e)
    {
      Log.Error("Error al obtener los recursos de la app:" + codApp+ e);
      throw new OperationException("Error al obtener los recursos de la app:" + codApp, e);
    }
  }

  /**
   * Metodo para obtener la lista de recursos por rol
   * 
   * 
   * @param codRol
   * @return
   * @throws OperationException
   */
  public List<Recurso> getListRecourceByRol(String codRol)
      throws OperationException
  {
    try
    {
      //TODO: Modificar lista de recursos
      return null;
      //return servicioAxessoRemoto.obtenerListaRecursosPorRol(codRol);

    }
    catch (Exception e)
    {
      Log.Error("Error al obtener los recursos del rol:" + codRol+ e);
      throw new OperationException("Error al obtener los recursos del rol:" + codRol, e);
    }
  }
}
