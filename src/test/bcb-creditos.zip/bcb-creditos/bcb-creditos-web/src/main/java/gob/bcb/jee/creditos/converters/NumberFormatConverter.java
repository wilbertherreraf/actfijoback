package gob.bcb.jee.creditos.converters;

/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-web
 * gob.bcb.jee.creditos.converters.UpperCaseConverter
 * 25/03/2016 - 15:25:03
 * Creado por ysalinas
 */

import java.math.BigDecimal;
import java.text.DecimalFormat;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import gob.bcb.jee.creditos.util.Log;

/**
 * Banco Central de Bolivia Usuario: Ariel Escobar Fecha: 7/6/2016 Hora:
 * 16:23:51
 */

@FacesConverter("numberFormatConverter")
public class NumberFormatConverter implements Converter {


	public Object getAsObject(FacesContext fx, UIComponent component,
			String value) throws ConverterException {
		if (value == null)
			return null;
		try {
			BigDecimal number = new BigDecimal(value);
			// TODO: Consumir decimales de parametros
			number = number.setScale(2);
			DecimalFormat format = new DecimalFormat();
			format.setMaximumFractionDigits(2);
			format.setMinimumFractionDigits(0);
			format.setGroupingUsed(false);
			String result = format.format(number);
			return result;
		} catch (Exception ex) {
			Log.Error("Error al formatear número " + value + ex);
			return "";
		}
	}

	public String getAsString(FacesContext cx, UIComponent component,
			Object value) throws ConverterException {
		if (value == null) {
			return null;
		}
		return value.toString();
	}
}
