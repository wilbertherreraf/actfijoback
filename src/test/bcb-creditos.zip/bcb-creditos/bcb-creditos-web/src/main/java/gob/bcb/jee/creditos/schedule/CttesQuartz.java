package gob.bcb.jee.creditos.schedule;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.schedule
 * 14/11/2016 - 04:07 PM
 * Creado por aescobar
 */
public class CttesQuartz {

    public final static String SCHEDULER_NAME = "CreditosScheduler";
    public final static String CREDITOS_GROUP = "CreditosGroup";
    public final static String FIN_MES_TRIGGER = "FinMesTrigger";


}
