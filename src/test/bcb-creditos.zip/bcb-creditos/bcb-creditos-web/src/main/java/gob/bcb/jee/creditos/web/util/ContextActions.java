/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-plantillaWebEE-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.util.ContextActions
 * 25/11/2016 - 10:06:58
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.web.util;

//import org.primefaces.PrimeFaces;
//import org.primefaces.context.RequestContext;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;

import gob.bcb.jee.creditos.util.Log;

import java.util.*;

public class ContextActions {

    public static Properties properties;
    public static Properties propertiesMsj;
    public static String TITULO_PROPERTIES = "titulos.properties";
    public static String MENSAJES_PROPERTIES = "mensajes.properties";

    /**
     * Mandar acciones de contexto sobre la pantalla
     *
     * @param accion
     */
    public static void primeContext(String accion) {
    //	PrimeFaces pf = PrimeFaces.current();
      //  RequestContext context = RequestContext.getCurrentInstance();
 
        //context.execute(accion);
    }

    private static void getPropertiesTitulos() {
        // obtenemos las propiedades de titulos
        UtilWeb util = new UtilWeb();
        properties = util.cargarPropiedades(TITULO_PROPERTIES);
    }

    private static void getPropertiesMensajes() {
        // obtenemos las propiedades de titulos
        UtilWeb util = new UtilWeb();
        propertiesMsj = util.cargarPropiedades(MENSAJES_PROPERTIES);
    }

    /**
     * Constuimos el metodo encargado de mandar los mensajes en pantalla
     */
    public static void buildMensaje(int typeAdvice, String property,
                                    Boolean keepMessage) {
        FacesMessage message = new FacesMessage();
        getPropertiesMensajes();
        property = (typeAdvice == INFO || typeAdvice == WARN || typeAdvice == ERROR) ? property : propertiesMsj.getProperty(property);
        //property = StringUtils.convertFromUTF8(property);
        switch (typeAdvice) {
            case INFO:
                message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", property);
                break;
            case WARN:
                message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", property);
                break;
            case ERROR:
                message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", property);
                break;
            case INFO_GENERIC:
                message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Info", property);
                break;
            case WARN_GENERIC:
                message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", property);
                break;
            case ERROR_GENERIC:
                message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", property);
                break;
        }
        FacesContext context = FacesContext.getCurrentInstance();
        if (keepMessage) {
            // You can use the flash to keep messages even if redirect.
            context.getExternalContext().getFlash().setKeepMessages(true);
        }
        context.addMessage(null, message);
    }

    /**
     * Mensajes a nivel de cabeceras
     *
     * @param property
     */

    public static void sendWarn(String property) {
        buildMensaje(WARN, property, false);
    }

    public static void sendError(String property) {
        buildMensaje(ERROR, property, false);
    }

    public static void sendGenericInfo(String cadena) {
        buildMensaje(INFO_GENERIC, cadena, false);
    }

    public static void sendGenericWarn(String cadena) {
        buildMensaje(WARN_GENERIC, cadena, false);
    }

    public static void sendGenericError(String cadena) {
        buildMensaje(ERROR_GENERIC, cadena, false);
    }

  /* Fin de mensajes */

    /**
     * Contructor de Dialogos para mensajeria
     *
     * @param type
     * @param property
     */
    public static void buildDialog(int type, String property) {
        Map<String, Object> options = new HashMap<String, Object>();
        Map<String, List<String>> paramMap = new HashMap<String, List<String>>();
        options.put("width", 300);
        options.put("modal", true);
        options.put("closable", false);
        options.put("draggable", false);
        options.put("resizable", false);
        options.put("contentHeight", 120);
        options.put("contentWidth", 300);
        getPropertiesMensajes();
        property = (type == INFO || type == WARN || type == ERROR) ? property : propertiesMsj.getProperty(property);

        switch (type) {
            case INFO:
                paramMap.putAll(paramsDialog("mensaje.titulo", property, "aceptar", "aceptar.titulo"));
                break;
            case WARN:
                paramMap.putAll(paramsDialog("agregar.titulo", property, "cancelar", "cerrar.titulo"));
                break;
            case ERROR:
                paramMap.putAll(paramsDialog("error.titulo", property, "cancelar", "cerrar.titulo"));
                break;
            case INFO_GENERIC:
                paramMap.putAll(paramsDialog("mensaje.titulo", property, "aceptar", "aceptar.titulo"));
                break;
            case WARN_GENERIC:
                paramMap.putAll(paramsDialog("agregar.titulo", property, "cancelar", "cerrar.titulo"));
                break;
            case ERROR_GENERIC:
                paramMap.putAll(paramsDialog("error.titulo", property, "cancelar", "cerrar.titulo"));
                break;
        }
        Log.Info("abre el panel con la lista:" + paramMap);
    //    RequestContext.getCurrentInstance().openDialog("/adviceDialog", options, paramMap);
    }

    /**
     * Metodo q agrega el listado de propiedades que tendra el panel de dialogo
     *
     * @param titulo
     * @param mensaje
     * @param btnIcono
     * @param btnMesnaje
     * @return
     */
    private static Map<String, List<String>> paramsDialog(String titulo,
                                                          String mensaje, String btnIcono, String btnMesnaje) {
        getPropertiesTitulos();
        // listamos los campos principales del panel de dialogo
        Map<String, List<String>> paramMap = new HashMap<String, List<String>>();
        List<String> listParam = new ArrayList<String>();
        listParam.add(DIALOG_TITULO, properties.getProperty("dialogo." + titulo));
        listParam.add(DIALOG_MENSAJE, propertiesMsj.getProperty(mensaje));
        listParam.add(DIALOG_BOTON_ICONO, properties.getProperty("icono." + btnIcono));
        listParam.add(DIALOG_BOTON_MENSAJE, properties.getProperty("boton." + btnMesnaje));
        paramMap.put(DIALOG, listParam);
        Log.Info("lista param: " + listParam);
        return paramMap;
    }

    /**
     * metodo encargado de cerrar un panel de dialogo
     *
     * @param name del widgetVar
     */
    public static void cierraDialogo(String name) {
        String dialogWidget = "PF('" + name + "').hide()";
        System.err.println("el dialogo a cerar es:" + dialogWidget);
      //  RequestContext.getCurrentInstance().execute(dialogWidget);
        System.err.println("-- Paso --");
    }

    /**
     * Mensajes en dialogos
     *
     * @param property
     */
    public static void sendDialogInfo(String property) {
        buildDialog(INFO, property);
    }

    public static void sendDialogWarn(String property) {
        buildDialog(WARN, property);
    }

    public static void sendDialogError(String property) {
        buildDialog(ERROR, property);
    }

    public static void sendDialogGenericInfo(String cadena) {
        buildDialog(INFO_GENERIC, cadena);
    }

    public static void sendDialogGenericWarn(String cadena) {
        buildDialog(WARN_GENERIC, cadena);
    }

    public static void sendDialogGenericError(String cadena) {
        buildDialog(ERROR_GENERIC, cadena);
    }

    @Deprecated
    public static void sendDialogGeneric(String cadena) {
        buildDialog(4, cadena);
    }

    /**
     * Constructor de mensajes de error por campo
     *
     * @param type
     * @param id
     * @param cadena
     */
    public static void sendDialogInputError(String id, String cadena) {
    	Log.Info("ingresa a buildMsgValidaCampo");
        FacesContext facesContext = FacesContext.getCurrentInstance();
        UIComponent root = facesContext.getViewRoot();
        Log.Info("ingresa component ui in");
        UIInput component = (UIInput) findComponent(root, id);
        if (component == null) {
            sendGenericError(ERROR_DIALOGO);
            return;
        }
        Log.Info("component es :" + component);
        component.setValid(false);
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, cadena, null);
        facesContext.addMessage(component.getClientId(), message);
        Log.Info("termina buildMsgValidaCampo");
    }

    private static UIComponent findComponent(UIComponent root, String id) {

        UIComponent result = null;
        if (root.getId().equals(id))
            return root;

        for (UIComponent child : root.getChildren()) {
            if (child.getId().equals(id)) {
                result = child;
                break;
            }
            result = findComponent(child, id);
            if (result != null)
                break;
        }
        return result;
    }

    /**
     * Niveles de importacia de mensajes
     */
    public static final int INFO = 1;
    public static final int WARN = 2;
    public static final int ERROR = 3;
    public static final int INFO_GENERIC = 4;
    public static final int WARN_GENERIC = 5;
    public static final int ERROR_GENERIC = 6;

    /**
     * Se agrega cada una de las llaves de los mensajes
     */
    public static String EDITADO = "mensaje.edicion.OK";
    public static String GUARDADO = "mensaje.guardado.OK";
    public static String EDITADO_NOK = "mensaje.edicion.NOK";
    public static String GUARDADO_NOK = "mensaje.guardado.NOK";
    public static String ERROR_GENERICO_NOK = "mensaje.error.NOK";
    public static String ERROR_SEGURIDAD_NOK = "mensaje.error.seguridad.NOK";
    public static String ERROR_DIALOGO = "mensaje.error.dialogo";


    //Mensajes propios de creditos
    public static String CRED_PROTOCOL_VENCIDA = "mensaje.protocolizacion.vencida";

    public static int DIALOG_TITULO = 0;
    public static int DIALOG_MENSAJE = 1;
    public static int DIALOG_BOTON_ICONO = 2;
    public static int DIALOG_BOTON_MENSAJE = 3;
    public static String DIALOG = "DIALOG";

    /* Cambio de Estados */
    public static String CAMBIO_DE_ESTADO_OK = "mensaje.cambio.estado.OK";
    public static String CAMBIO_DE_ESTADO_NOK = "mensaje.cambio.estado.NOK";
    public static String SUSPENSION_OK = "mensaje.suspension.OK";
    public static String SUSPENSION_NOK = "mensaje.suspension.NOK";
    public static String HABILITACION_OK = "mensaje.habilitacion.OK";
    public static String HABILITACION_NOK = "mensaje.habilitacion.NOK";
    /* Autorizacion */
    public static String AUTORIZACION_OK = "mensaje.autorizacion.OK";
    public static String AUTORIZACION_NOK = "mensaje.autorizacion.NOK";
    /**/
    public static String RECHAZO_OK = "mensaje.rechazo.OK";

    /* Eliminar */
    public static String ELIMINACION_OK = "mensaje.eliminado.OK";
    public static String ELIMINACION_NOK = "mensaje.eliminado.NOK";

    /* Busqueda */
    public static String BUSQUEDA_REQUIRED = "mensaje.requeido";
    public static String BUSQUEDA_NOK = "mensaje.busqueda.NOK";
}
