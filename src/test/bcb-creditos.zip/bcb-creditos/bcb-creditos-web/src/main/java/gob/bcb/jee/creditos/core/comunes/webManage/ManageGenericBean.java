/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-web
 * gob.bcb.jee.creditos.core.comunes.web.ManageGenericBean
 * 07/03/2016 - 11:52:12
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.core.comunes.webManage;

import gob.bcb.jee.creditos.BL.GenericBLLocal;
import gob.bcb.jee.creditos.BL.TransaccionAuditoriaBLLocal;
import gob.bcb.jee.creditos.entidades.*;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.numeradores.CodRecurso;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.ContextActions;
import gob.bcb.jee.creditos.web.util.Instantiator;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

import javax.faces.bean.ManagedProperty;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

/**
 * Clase managed generica para el manejo de roles y recursos web
 *
 * @author ysalinas
 */
@Getter
@Setter
public abstract class ManageGenericBean<T extends Entidad, ID extends Serializable>
        implements Serializable {

    private static final long serialVersionUID = 1L;

    @ManagedProperty(value = "#{applicationBean}")
    protected ApplicationBean applicationBean;

    @ManagedProperty(value = "#{sessionBean}")
    protected SessionBean sessionBean;

    @Inject
    protected TransaccionAuditoriaBLLocal transaccionAuditoriaBLLocal;

    protected abstract GenericBLLocal getBL();

    protected T itemActual;

    private String errorValidacion;

    private CodRecurso codRecurso;

    /* Listas */
    protected List<T> lstItems;
    protected List<Estado> lstEstado;

    protected boolean editando;

    protected boolean insercion;

    protected boolean visualizacion;

    protected boolean autorizacion;

    protected boolean autorizado;

    protected boolean muestraItem;

    protected boolean operacionExistosa;

    private String tituloDialogo;

    public boolean isMuestraGridBusqueda() {
        return lstItems != null && !lstItems.isEmpty();
    }

    protected String filtroBusqueda;

    protected Recurso permiso;

    protected Usuario usuario;

    @Deprecated
    public ManageGenericBean() {
    }

    @SuppressWarnings("unchecked")
    public ManageGenericBean(CodRecurso codRecurso) {
        this.codRecurso = codRecurso;
        this.itemActual = (T) Instantiator.instantiate(codRecurso.getClazz());
    }

    public void postConstruct() {
        this.usuario = sessionBean.getUsuarioSesion();
        this.permiso = sessionBean.getUsuarioSesion().getRecursoByCod(codRecurso);
    }

    public abstract void initBean();

    /**
     * Metodo que realiza la obtencion de listados para cada entidad
     */
    @SuppressWarnings("unchecked")
    public void find() {
        try {
            this.operacionExistosa = false;
            this.muestraItem = false;
            filtroBusqueda = filtroBusqueda != null ? filtroBusqueda.trim()
                    : "";
            Log.Debug("Inicia busqueda con filtro: " + filtroBusqueda);
            lstItems = getBL().list(filtroBusqueda);
            Log.Debug("Econtro " + lstItems.size() + " registros");
            if (lstItems.size() < 1) {
                ContextActions.sendDialogWarn("No se encontraton registros");
            }
            this.operacionExistosa = true;

        } catch (Exception e) {
            Log.Error("Error en la busqueda"+ e);
            ContextActions.sendDialogError(ContextActions.GUARDADO_NOK);
        }
    }

    /**
     * Metodo que realiza la persistencia (adicion, modificacion) de un objeto
     * para cada entidad
     */
    @SuppressWarnings("unchecked")
    public void save() {
        try {
            Log.Info("Inicio de persistencia de " + itemActual);
            this.operacionExistosa = false;
            // this.itemActual.setUsuarioModificacion(sessionBean.getUsuarioSesion().getLogin());
            // if (this.itemActual.getId() == null)
            // {
            // this.itemActual.setUsuarioAlta(sessionBean.getUsuarioSesion()
            // .getLogin());
            // }
            getBL().persist(itemActual, this.getSessionBean().getUsuarioSesion().getLogin());
            // ContextActions.sendDialogInfo(ContextActions.GUARDADO);
            // actualiza la lista
            find();
            this.operacionExistosa = true;
        } catch (OperationException e) {
            Log.Error("Error en la persistencia"+ e);
            ContextActions.sendError(e.getMessage());
        } catch (EntityValidationException e) {
            //Log.Error("Error en la validación del registro", e);
            for (String error : e.getFieldErrors()) {
                ContextActions.sendError(error);
            }
        } catch (Exception e) {
            Log.Error("exception class: " + e.getClass().getName());
            Log.Error("Error en la persistencia"+ e);
            ContextActions.sendGenericError(ContextActions.GUARDADO_NOK);
        }
    }

    @SuppressWarnings("unchecked")
    public void autorizar() {
        Log.Debug("Ingresando a la clase " + getClass().getSimpleName()
                + " metodo verificar con item: " + itemActual);
        this.operacionExistosa = false;
        try {
            getBL().authorize(itemActual,
                    this.getSessionBean().getUsuarioSesion().getLogin(),
                    autorizado);
            this.operacionExistosa = true;
        } catch (OperationException e) {
            Log.Error("Error al autorizar el participante"+ e);
            ContextActions.sendError(e.getMessage());
        }
    }

    /**
     * Metodo que habilita la creacion de un nuevo objeto para cada entidad
     */
    @SuppressWarnings("unchecked")
    public void createNew() {
        try {
            Log.Debug("Ingresa a createNew");
            Log.Info("Ingresa a createNew");
            this.operacionExistosa = false;
            this.insercion = true;
            this.editando = true;
            this.autorizacion = false;
            itemActual = (T) Instantiator.instantiate(codRecurso.getClazz());
            this.operacionExistosa = true;
            // ContextActions.primeContext("fijarPaginadorTodos();");
            Log.Debug("Termina a createNew");
            Log.Info("Termina a createNew");
        } catch (Exception e) {
            Log.Error("Error al iniciar formulario"+e);
            ContextActions.sendGenericError(ContextActions.GUARDADO_NOK);
        }
    }

    /**
     * Metodo que permite la visualizacion de la ventana emergente en modo
     * "Vista de detalles"
     */
    public void showDetail() {
        try {
            this.operacionExistosa = false;
            this.insercion = false;
            this.editando = false;
            this.autorizacion = false;
            if (this.itemActual.isLazyLoading()) {
                this.itemActual = (T) getBL().getLazy(this.itemActual.getId());
            }
            Log.Debug("Show item: " + this.itemActual);
            this.operacionExistosa = true;
        } catch (Exception e) {
            Log.Error("Error al iniciar formulario"+ e);
            ContextActions.sendGenericError(ContextActions.GUARDADO_NOK);
        }
    }

    /**
     * Metodo que habilita la edicion de un obejto para cada entidad
     */
    public void edit() {
        try {
            this.operacionExistosa = false;
            this.insercion = false;
            this.autorizacion = false;
            this.editando = true;
            if (this.itemActual.isLazyLoading()) {
                Log.Info("entra aqui::");
                this.itemActual = (T) getBL().getLazy(this.itemActual.getId());
            } else {
                Log.Info("entra aqui::222");
                Log.Info("este es el item" + this.itemActual);
                this.itemActual = (T) getBL().get(this.itemActual.getId());
            }
            Log.Info("Edit item: " + this.itemActual);
            this.operacionExistosa = true;

        } catch (Exception e) {
            Log.Error("Error al iniciar formulario de edicion"+ e);
            ContextActions.sendGenericError(ContextActions.GUARDADO_NOK);
        }
    }

    /**
     * Metodo que habilita posibilidad de autorización de un objeto
     */
    public void initAutorizar() {
        try {
            this.operacionExistosa = false;
            this.insercion = false;
            this.editando = false;
            this.autorizacion = true;
            if (this.itemActual.isLazyLoading()) {
                this.itemActual = (T) getBL().getLazy(this.itemActual.getId());
            } else {
                this.itemActual = (T) getBL().get(this.itemActual.getId());
            }
            Log.Info("Autorizar item: " + this.itemActual);
            this.operacionExistosa = true;

        } catch (Exception e) {
            Log.Error("Error al iniciar formulario de edicion"+ e);
            ContextActions.sendGenericError(ContextActions.GUARDADO_NOK);
        }
    }

    /**
     * Metodo para obtener el titulo de la ventana emergente de adicion,
     * modificacion o visualizacion
     *
     * @return
     */
    public String getTituloDialogo() {
        String respuesta = "";
        if (!applicationBean.getTitulosProperties().isEmpty())
            if (this.editando) {
                if (this.insercion)
                    respuesta = applicationBean.getTitulosProperties()
                            .getProperty("dialogo.agregar.titulo");
                else
                    respuesta = applicationBean.getTitulosProperties()
                            .getProperty("dialogo.modificar.titulo");
            } else
                respuesta = applicationBean.getTitulosProperties().getProperty(
                        "dialogo.consultar.titulo");
        return respuesta;
    }

    /**
     * Meotodo que habilita el formulario de registro y/o modificacion
     */
    @SuppressWarnings("unchecked")
    public void openForm(ActionEvent event) {
        Log.Debug("Ingresando a abrir el dialogo del formulario");
        if (insercion) {
            // Cuando esta insertando
            itemActual = (T) Instantiator.instantiate(codRecurso.getClazz());
        } else {
            // Cuando esta editando
        }
        Log.Debug("Fin de abrir el dialogo del formulario");
    }

    public void updateForm() {

    }

    public LogAuditoria getLogAuditoria(String codTransAuditoria, LogAuditoria logAuditoriaAnterior) {
        LogAuditoria logAuditoria = new LogAuditoria();
        logAuditoria.setCodUsuario(getUsuario().getLogin());
        logAuditoria.setEstacion(UtilWeb.getIPRemoto());
        logAuditoria.setFechaHora(new Date());
        if(logAuditoriaAnterior != null)
            logAuditoria.setLogAnteriorId(logAuditoriaAnterior.getId());
        try {
            logAuditoria.setTransaccionAuditoria(transaccionAuditoriaBLLocal.get(codTransAuditoria));
        } catch (OperationException e) {
            Log.Error("Error al obtener Transaccion Auditoria"+ e);
        }
        return logAuditoria;
    }

    public boolean isVisualizacion() {
        if (insercion || editando)
            return false;
        else
            return true;
    }

   

    public BigInteger getNumDecCalc() {

        try {
            BigInteger numDec = new BigInteger(applicationBean.getParamsSistema().get(Cttes.PARAM_NUM_DECIMALES_CALC));
            return numDec;
        } catch (Exception ex) {
            Log.Error("No puede leerse correctamente el número de decimales");
        }
        return new BigInteger("2");
    }

}
