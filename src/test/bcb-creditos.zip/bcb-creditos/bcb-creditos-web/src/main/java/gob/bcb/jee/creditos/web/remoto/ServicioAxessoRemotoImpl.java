package gob.bcb.jee.creditos.web.remoto;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;

import gob.bcb.jee.axesso.entidades.Agencia;
import gob.bcb.jee.axesso.entidades.Participante;
import gob.bcb.jee.axesso.entidades.Password;
import gob.bcb.jee.axesso.entidades.Permiso;
import gob.bcb.jee.axesso.entidades.Recurso;
import gob.bcb.jee.axesso.entidades.Rol;
import gob.bcb.jee.axesso.entidades.Usuario;
import gob.bcb.jee.axesso.entidades.pojo.DatosAuditoria;
import gob.bcb.jee.axesso.excepciones.EntityValidationException;
import gob.bcb.jee.axesso.excepciones.OperationException;
import gob.bcb.jee.axesso.remoto.AgenciaEjbRemoto;
import gob.bcb.jee.axesso.remoto.ParticipanteEjbRemoto;
import gob.bcb.jee.axesso.remoto.PasswordEjbRemoto;
import gob.bcb.jee.axesso.remoto.PermisoEjbRemoto;
import gob.bcb.jee.axesso.remoto.RecursoEjbRemoto;
import gob.bcb.jee.axesso.remoto.RolEjbRemoto;
import gob.bcb.jee.axesso.remoto.UsuarioEjbRemoto;
import gob.bcb.jee.axesso.util.UtilRemoto;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.web.remoto
 * 06/07/2016 - 06:01 PM
 * Código base:
 * Creado por aescobar
 */
@Stateless
public class ServicioAxessoRemotoImpl implements ServicioAxessoRemoto {

    private UsuarioEjbRemoto usuarioEjbRemoto = UtilRemoto.consumirEJBAXESSO(UsuarioEjbRemoto.class);
    private RolEjbRemoto rolEjbRemoto = UtilRemoto.consumirEJBAXESSO(RolEjbRemoto.class);
    private RecursoEjbRemoto recursoEjbRemoto = UtilRemoto.consumirEJBAXESSO(RecursoEjbRemoto.class);
    private PermisoEjbRemoto permisoEjbRemoto = UtilRemoto.consumirEJBAXESSO(PermisoEjbRemoto.class);
    private ParticipanteEjbRemoto participanteEjbRemoto = UtilRemoto.consumirEJBAXESSO(ParticipanteEjbRemoto.class);
    private PasswordEjbRemoto passwordEjbRemoto = UtilRemoto.consumirEJBAXESSO(PasswordEjbRemoto.class);
    private AgenciaEjbRemoto agenciaEjbRemoto = UtilRemoto.consumirEJBAXESSO(AgenciaEjbRemoto.class);


    @Override
    public Usuario getUsuario(Integer usuarioId) throws Exception {
        try {
            Usuario usuario = usuarioEjbRemoto.getLazy(usuarioId);
            return usuario;
        } catch (Exception e) {
            String msjError = "Error en los servicios remotos de AXESSO.";
            Log.Error(msjError+ e);
            throw new OperationException(msjError, e);
        }
    }

    @Override
    public Usuario getUsuarioByLogin(String login) throws Exception {
        try {
            Usuario usuario = usuarioEjbRemoto.getByLogin(login);
            return usuario;
        } catch (Exception e) {
            String msjError = "Error en los servicios remotos de AXESSO.";
            Log.Error(msjError+ e);
            throw new OperationException(msjError, e);
        }
    }

    @Override
    public List<Rol> listRolesByUsuario(Integer usuarioId) throws Exception {
        try {
            List<Rol> roles = rolEjbRemoto.listByUsuario(usuarioId, CttesWeb.AXESSO_COD_APP);
            return roles;
        } catch (Exception e) {
            String msjError = "Error en los servicios remotos de AXESSO.";
            Log.Error(msjError+ e);
            throw new OperationException(msjError, e);
        }
    }

    @Override
    public List<Recurso> listRecursosByRol(String rolId) throws Exception {
        try {
            List<Recurso> recursos = recursoEjbRemoto.listByRol(rolId, CttesWeb.AXESSO_COD_APP);
            return recursos;
        } catch (Exception e) {
            String msjError = "Error en los servicios remotos de AXESSO.";
            Log.Error(msjError+ e);
            throw new OperationException(msjError, e);
        }
    }

    @Override
    public List<Permiso> listPermisosByRolAndRecurso(String rolId, String recursoId) throws Exception {
        try {
            List<Permiso> permisos = permisoEjbRemoto.listByRolAndRecurso(rolId, recursoId);
            return permisos;
        } catch (Exception e) {
            String msjError = "Error en los servicios remotos de AXESSO.";
            Log.Error(msjError+e);
            throw new OperationException(msjError, e);
        }
    }

    @Override
    public Participante getParticipanteByLoginUsuario(String loginUsuario) throws Exception {
        try {
            Participante participante = participanteEjbRemoto.getByUsuario(loginUsuario);
            return participante;
        } catch (Exception e) {
            String msjError = "Error en los servicios remotos de AXESSO.";
            Log.Error(msjError+ e);
            throw new OperationException(msjError, e);
        }
    }

    @Override
    public Password getPasswordByUsuarioAndPasseord(String loginUsuario, String passwordUsuario) throws Exception {
        try {
            Password password = passwordEjbRemoto.getPasswordByLoginAndPassword(loginUsuario, passwordUsuario);
            return password;
        } catch (Exception e) {
            String msjError = "Error en los servicios remotos de AXESSO.";
            Log.Error(msjError+ e);
            throw new OperationException(msjError, e);
        }
    }

    @Override
    public void asignarPassword(Integer usuarioId, String password, DatosAuditoria datosAuditoria) throws EntityValidationException, OperationException {
        String sads = passwordEjbRemoto.asignarPassword(usuarioId, password, datosAuditoria, true, false);
    }

    @Override
    public void registrarUsuario(Usuario entity, List<Rol> roles, boolean generarPassword, boolean email) throws EntityValidationException, OperationException {
        Usuario usuario = usuarioEjbRemoto.persist(entity, roles, generarPassword, email);
    }

    @Override
    public Agencia getAgencias(Integer usuarioId) throws OperationException {
        return agenciaEjbRemoto.getByUsuarioId(usuarioId);
    }

    @Override
    public void modificarUsuario(Usuario entity, boolean email) throws EntityValidationException, OperationException {
        Usuario usuario = usuarioEjbRemoto.merge(entity, email);
    }

    @Override
    public boolean isPasswordVigente(Integer usuarioId) throws OperationException {
        return passwordEjbRemoto.isPasswordVigente(usuarioId, new Date());
    }

    @Override
    public void lisUsuariosLike(String usuario) throws OperationException {
        //TODO: Eliminar este bloque de codigo
//        List<Usuario> usuarios = usuarioEjbRemoto.listByParticipanteIdAndAppIdAndPlazaIdAndEstadoApp(usuario, "SVD", "200", null);
//        List<Usuario> usuarios = usuarioEjbRemoto.listByLikeLogin(usuario, "SVD", "913", null);
        //List<ResumenUsuarioRol> usuarios = usuarioEjbRemoto.listResumenUsuarioRol("913","SVD", "200", null);
       // List<ResumenUsuarioRol> usuarios = usuarioEjbRemoto.listResumenUsuarioRol("913","SVD", null, null);
//        rolEjbRemoto.listByAplicacionIdAndEstado("SVD", Estado.VIGENTE);        
    }

}

