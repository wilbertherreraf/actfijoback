package gob.bcb.jee.creditos.web.pages.gestion;

import gob.bcb.jee.creditos.entidades.PrePagocuota;
import gob.bcb.jee.creditos.entidades.PreRegistrogarantias;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class PrePagocuotaService {

    @PersistenceContext
    private EntityManager entityManager;

    public PrePagocuota findByCoddsb(Integer coddsb) {
        return entityManager.createQuery("SELECT pr FROM PrePagocuota pr WHERE pr.coddsb.id = :coddsb and pr.estado<>4 and pr.estado<>5 ", PrePagocuota.class)
                .setParameter("coddsb", coddsb)
                .getSingleResult();
    }
}
