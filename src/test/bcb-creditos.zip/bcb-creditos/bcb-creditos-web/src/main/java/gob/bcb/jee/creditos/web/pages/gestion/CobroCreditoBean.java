package gob.bcb.jee.creditos.web.pages.gestion;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
//import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenModuloBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenParametroBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocalImpl;
import gob.bcb.jee.creditos.BL.PreDesembolsoDetalleBLLocal;
import gob.bcb.jee.creditos.BL.PrePagocuotaBLLocal;
import gob.bcb.jee.creditos.BL.PrePlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.PrePrccontaBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreRegistrogarantiasBLLocal;
import gob.bcb.jee.creditos.BL.PreTramonBLLocal;
import gob.bcb.jee.creditos.QL.GenDesctablaQLLocal;
import gob.bcb.jee.creditos.QL.GenPrcparamsQLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocal;
import gob.bcb.jee.creditos.entidades.EstadoDesembolsosQuery;
import gob.bcb.jee.creditos.entidades.GenPrcparams;
import gob.bcb.jee.creditos.entidades.PrePagocuota;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.entidades.VPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.pojo.ComprobanteDet;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenModulo;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.pojo.PreDesembolsoDto;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.UtilDate;
import gob.bcb.jee.creditos.web.pages.UtilWebBean;
import gob.bcb.jee.creditos.web.reportes.GeneradorReporte;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "CobroCreditoBean")
@ViewScoped
@Getter
@Setter
public class CobroCreditoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	// private static final org.apache.log4j.Logger log =
	// Logger.getLogger(CobroCreditoBean.class);
	private static final Logger log = LoggerFactory.getLogger(CobroCreditoBean.class);
	@Inject
	private GenTipProductoBLLocal genTipProductoBLLocal;

	@Inject
	private GenDesctablaBLLocal genDesctablaBLLocal;

	@Inject
	private GenMonedaBLLocal genMonedaBLLocal;

	@Inject
	private PrePrestamosBLLocal prePrestamosBLLocal;

	@Inject
	private GenModuloBLLocal genModuloBLLocal;

	@Inject
	private CliPersonaBLLocal service;
@Inject
	private PrePrccontaBLLocal prePrccontaBLLocal;
	@Inject
	private PreTramonBLLocal preTramonBLLocal;
	@Inject
	private PrePlanpagosBLLocal prePlanpagosLocal;

	@Inject
	private GeneradorReporte generadorReporte;
	@Inject
	private PreDesembolsoDetalleBLLocal preDesembolsoDetalleBLLocal;

	@Inject
	private UtilWebBean utilWebBean;

	@Inject
	private PreDesembBLLocal preDesembBLLocal;

	@Inject
	private PrePagocuotaBLLocal prePagocuotaBLLocal;

	@Inject
	private GenParametroBLLocal genParametroBLLocal;

	@Inject
	private PrePagocuotaService prePagocuotaService; // Inyección del servicio

	@Inject
	private PreRegistrogarantiasBLLocal preRegistrogarantiasBLLocal;

	@Inject
	private GenDesctablaQLLocal genDesctablaQLLocal;

	@Inject
	private GenPrcparamsQLLocal genPrcparamsQLLocal;
	@Inject
	private PrePlanpagosQLLocal prePlanpagosQLLocal;
	private List<CliPersona> products;

	private PrePrestamos itemActual;

	private List<PrePrestamos> listPrePrestamos = new ArrayList<>();

	private CliPersona cliPersona = new CliPersona();
	private String cliente;
	private List<GenTipproducto> listGenTipproductos;
	private GenTipproducto genTipproducto;
	private String igenTipproducto;

	private List<GenMoneda> listGenMoneda;
	private GenMoneda genGenMoneda;
	private PreDesemb preDesemb;
	private Integer igenGenMoneda;

	private Integer codigoPrestamo;
	private String contrato;
	private boolean mostrarDiasIregular = true;

	private Integer planDePagosSeleccionado = 0;
	// private List<GenDesctabla> listGenDesctablaRubro;
	// private GenDesctabla genDesctablaRubro;
	private Integer igenDesctablaRubro;

	// private List<GenDesctabla> listGenDesctablaDestino;
	// private GenDesctabla genDesctablaDestino;
	private Integer igenDesctablaDestino;

	private List<GenDesctabla> listGenDesctablaCapitalizacion;
	private Integer igenDesctablaCapitalizacion;

	private List<GenDesctabla> listGenDesctablaValores;
	private Integer igenDesctablaValores;

	private List<GenDesctabla> listGenDesctablaPlazo;
	private Integer igenDesctablaPlazo;

	private List<GenDesctabla> listGenDesctablaPlazoInt;

	private Integer igenDesctablaPlazoInt;

	private List<Object[]> listPrePlanpagosO;

	private List<GenModulo> listGenModulo;
	private List<ComprobanteDet> listRenglones = new ArrayList<>();
	/** DECLARAR VARIABLES PARA DESEMBOLSOS **/

	private List<PreDesemb> listDesembolso;
	private List<PreDesembolsoDto> preDesembolsoDtoList = new ArrayList<>();
	private BigDecimal valorDisponibleDesembolso;
	private EstadoDesembolsosQuery estadoDesembolsosTots = new EstadoDesembolsosQuery();
	private List<EstadoDesembolsosQuery> listEstadoDesembolsos = new ArrayList<>();
	private PreDesemb itemPreDesemb = new PreDesemb();

	private PrePagocuota prePagocuota0;
	private PrePagocuota prePagocuotaDetalle;

	private List<Object[]> ParamsCobroDesembolso;

	private Date fechaVencimiento;
	private Date fechaVencimientoDesemb0;
	private BigDecimal totalCuotaVencimiento;
	private BigDecimal pagoImporteCapital;
	private BigDecimal pagoImporteIntereses;

	private BigDecimal interesesGestionActual;
	private BigDecimal interesesGestionAnterior;
	private BigDecimal totalSaldo;

	private String ctaDebe;
	private String ctaHaber;
	private String ctaHaberInteres;

	private String cpGestAnt;
	private String cpGestAct;

	private String nombreCorto;
	private String nroComprobanteCOIN;

	private List<Object[]> ParamsComprobante;

	private Integer numeroCentro;
	private String tipoComprobante;
	private String parametroGlosa;
	private String numeroSerie;
	private Integer numeroDesembolso;
	private Integer numeroCuota;
	private Date fechaEstDesembolso;
	private BigDecimal debeSuma = BigDecimal.valueOf(0.00);
	private BigDecimal haberSuma = BigDecimal.valueOf(0.00);

	private List<VPlanPagosConsolQuery> planpagosConsol = new ArrayList<>();
	private List<VPlanPagosConsolQuery> planpagosVctos = new ArrayList<>();

	public CobroCreditoBean() {
	}

	@PostConstruct
	public void init() {
		try {
			listGenTipproductos = genTipProductoBLLocal.list();
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
			fechaVencimiento = new Date();
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void inicializaObjetos() {
		limpiar();
		itemActual = null;
	}

	private void limpiar() {
		listPrePrestamos.clear();
		planpagosVctos.clear();
		fechaVencimiento = new Date();
		listEstadoDesembolsos.clear();
		preDesembolsoDtoList.clear();
	}

	public void seleccionarItem(PrePrestamos prestamos) {
		try {
			log.info("Prestamos seleccionado " + prestamos.getPrePrestamosPK().getPreCodcred());
			planpagosVctos.clear();
			listEstadoDesembolsos.clear();			
			itemActual = prePrestamosBLLocal.prestamoById(prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());			
			planpagosVctos = recuperarSgtesVctos(prestamos.getPrePrestamosPK().getPreCodcred(),prestamos.getPrePrestamosPK().getPreCodmod());
			planpagosVctos = completarPPVctos(planpagosVctos);			
			if (planpagosVctos.size() == 0) {
				planpagosVctos = prePlanpagosQLLocal.planConsolPorCodmodYCodcred(
						prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());
			}
			actListDesembolsos(new Date(), prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
		}
	}

	public void iniciarVerDesembolsos(PrePrestamos prestamos){
		try{
			log.info("Prestamos seleccionado " + prestamos.getPrePrestamosPK().getPreCodcred());
			planpagosVctos.clear();
			listEstadoDesembolsos.clear();						
			itemActual = prePrestamosBLLocal.prestamoById(prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());			

			//planpagosVctos = recuperarSgtesVctos(prestamos.getPrePrestamosPK().getPreCodcred(),prestamos.getPrePrestamosPK().getPreCodmod());
			List<PrePagocuota> pcSinCmpbList = prePagocuotaBLLocal.cuotasPendientesSinCmp(prestamos.getPrePrestamosPK().getPreCodcred(),prestamos.getPrePrestamosPK().getPreCodmod(), new Date());
			if (pcSinCmpbList.size()> 0) {
				actListDesembolsos(pcSinCmpbList.get(0).getFechaVencimiento(), prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());
			} else {
				actListDesembolsos(new Date(), prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());
			}

		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
		}			
	}

	public void iniciarVerDsbCobrados(Integer codcred, Integer codmod, Date fechaVen, Integer tipotrxpar){
		try{
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("retcuperando regns " +codcred);
			planpagosVctos.clear();
			listEstadoDesembolsos.clear();						
			itemActual = prePrestamosBLLocal.prestamoById(codcred, codmod);			
			List<PrePagocuota> pcSinCmpbList = prePagocuotaBLLocal.cuotasConCmpb(codcred,codmod, fechaVen);
			if (pcSinCmpbList.size() == 0) {
				prePagocuotaBLLocal.actualizarRengs(8, codcred, codmod, fechaVen, tipotrxpar, usuario.getLogin(),
					UtilWeb.getIPRemoto());
			}

			actListDesembolsos(fechaVen, codcred, codmod);

		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
		}			
	}

	public void recuperarEstServDeudaXDsb(PrePrestamos prestamos,Date fecha) {
		try {
			actListDesembolsos(fecha, prestamos.getPrePrestamosPK().getPreCodcred(),
					prestamos.getPrePrestamosPK().getPreCodmod());

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void verEstadoSrvDeuda(Integer codcred, Integer codmod, Date fecha) {
		try {
			listEstadoDesembolsos.clear();
			actListDesembolsos(fecha, codcred, codmod);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void listarVctosPendientes(PrePrestamos prestamos) {
		try {
			planpagosVctos = recuperarSgtesVctos(prestamos.getPrePrestamosPK().getPreCodcred(),prestamos.getPrePrestamosPK().getPreCodmod());
			planpagosVctos = completarPPVctos(planpagosVctos);			

			if (planpagosVctos.size() == 0) {
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN,
						"No existe cuotas vencidas o próximos(30 días)", "");
				FacesContext.getCurrentInstance().addMessage(null, message);
			}
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void listarPPCobros(PrePrestamos prestamos) {
		try {
			planpagosVctos = prePlanpagosQLLocal.planConsolPorCodmodYCodcred(
					prestamos.getPrePrestamosPK().getPreCodcred(), prestamos.getPrePrestamosPK().getPreCodmod());
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void btnGuardarPrcconta() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Salvando prcconta {} usr {}", prePagocuotaDetalle.getId(), usuario.getLogin());
			prePagocuotaDetalle.setFecha(new Date());
			prePagocuotaDetalle.setAuditUsuario(usuario.getLogin());
			prePagocuotaDetalle.setAuditFechahora(new Timestamp(new Date().getTime()));
			prePagocuotaDetalle.setAuditHost(UtilWeb.getIPRemoto());
			prePagocuotaDetalle.setAuditUsuarioGenera(usuario.getLogin());
			prePagocuotaDetalle.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			prePagocuotaDetalle.setAuditHostGenera(UtilWeb.getIPRemoto());

			prePagocuotaDetalle = prePagocuotaBLLocal.guardarPagocuota(prePagocuotaDetalle);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO,
							"Registro salvado",
							"Codigo: " + prePagocuotaDetalle.getId()));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void btnCancelarPrcconta() {
		try {
			log.info("cancelando prcconta {}", prePagocuotaDetalle.getId());

			prePagocuotaDetalle = prePagocuotaBLLocal.findCuotaById(prePagocuotaDetalle.getId());

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Edición cancelada", "No se guardaron cambios"));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}
		
	public void btnGuardarGenparams(GenPrcparams genprcparams) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Salvando Genprcparams {} codgen {}", prePagocuotaDetalle.getId(), genprcparams.getPrpCodtpr());
			GenPrcparams genprcp = genPrcparamsQLLocal.saveUpdateGenP(genprcparams);
			listRenglones = recuperarRengsOper(prePagocuotaDetalle);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO,
							"Registro salvado",
							"Código renglón: " + genprcp.getPrpCodprc()));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void btnCancelarGenparams(GenPrcparams genprcparams) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Cancelando Genprcparams {} codgen {}", prePagocuotaDetalle.getId(), genprcparams.getPrpCodtpr());
			listRenglones = recuperarRengsOper(prePagocuotaDetalle);

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Edición cancelada", "No se guardaron cambios"));

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}	

	public void generarComprobante() {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {
			log.info("Inicio generarComprobante cobro o pago anticipado usr: " + usuario.getLogin()
					+ ", IP: " + UtilWeb.getIPRemoto() + " cred: " + itemActual.getId().getPreCodcred() + " ID PGOCTA: "
					+ prePagocuotaDetalle.getId());
			prePagocuotaDetalle.setFecha(new Date());
			prePagocuotaDetalle.setAuditUsuario(usuario.getLogin());
			prePagocuotaDetalle.setAuditFechahora(new Timestamp(new Date().getTime()));
			prePagocuotaDetalle.setAuditHost(UtilWeb.getIPRemoto());
			prePagocuotaDetalle.setAuditUsuarioGenera(usuario.getLogin());
			prePagocuotaDetalle.setAuditFechahoraGenera(new Timestamp(new Date().getTime()));
			prePagocuotaDetalle.setAuditHostGenera(UtilWeb.getIPRemoto());

			prePagocuotaDetalle = prePagocuotaBLLocal.guardarPagocuota(prePagocuotaDetalle);
			Integer idPcta = prePagocuotaDetalle.getId();
			prePagocuotaBLLocal.generarOperacionYContaBL(prePagocuotaDetalle.getPcuTipocmp(),prePagocuotaDetalle, prePagocuotaDetalle.getGlosaCoin());

			listEstadoDesembolsos.clear();
			prePagocuotaDetalle = prePagocuotaBLLocal.findCuotaById(idPcta);

			actListDesembolsos(prePagocuotaDetalle.getFechaVencimiento(), prePagocuotaDetalle.getCodcred(),
					prePagocuotaDetalle.getCodmod());

			PrimeFaces.current().executeScript("PF('dlgCmpbRengs').hide();");

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de generación de comprobante COIN ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public void eliminarOperacion() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio eliminarDevengado usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			prePrccontaBLLocal.cambiarEstadoOperComprob(prePagocuotaDetalle.getPcuTipocmp(), prePagocuotaDetalle.getId(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(), prePagocuotaDetalle.getCoddsb(), prePagocuotaDetalle.getFechaVencimiento(), 7, usuario.getLogin(), UtilWeb.getIPRemoto());

			planpagosVctos = recuperarSgtesVctos(prePagocuotaDetalle.getCodcred(), prePagocuotaDetalle.getCodmod());
			planpagosVctos = completarPPVctos(planpagosVctos);											
			actListDesembolsos(prePagocuotaDetalle.getFechaVencimiento(), prePagocuotaDetalle.getCodcred(),
					prePagocuotaDetalle.getCodmod());


			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"La cancelación del comprobante se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
		return;
	}

	public void rechazarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio rechazarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());
			prePrccontaBLLocal.cambiarEstadoOperComprob(prePagocuotaDetalle.getPcuTipocmp(), prePagocuotaDetalle.getId(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(),prePagocuotaDetalle.getCoddsb(), prePagocuotaDetalle.getFechaVencimiento(), 4, usuario.getLogin(), UtilWeb.getIPRemoto());

			planpagosVctos = recuperarSgtesVctos(prePagocuotaDetalle.getCodcred(), prePagocuotaDetalle.getCodmod());
			planpagosVctos = completarPPVctos(planpagosVctos);														

			actListDesembolsos(prePagocuotaDetalle.getFechaVencimiento(), prePagocuotaDetalle.getCodcred(),
					prePagocuotaDetalle.getCodmod());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"El rechazo del comprobante se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return;
	}

	public void preAutorizarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio preAutorizarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			prePrccontaBLLocal.cambiarEstadoOperComprob(prePagocuotaDetalle.getPcuTipocmp(), prePagocuotaDetalle.getId(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(), prePagocuotaDetalle.getCoddsb(), prePagocuotaDetalle.getFechaVencimiento(), 2, usuario.getLogin(), UtilWeb.getIPRemoto());

			prePagocuotaDetalle = prePagocuotaBLLocal.findCuotaById(prePagocuotaDetalle.getId());

			planpagosVctos = recuperarSgtesVctos(prePagocuotaDetalle.getCodcred(), prePagocuotaDetalle.getCodmod());
			planpagosVctos = completarPPVctos(planpagosVctos);								
			actListDesembolsos(prePagocuotaDetalle.getFechaVencimiento(), prePagocuotaDetalle.getCodcred(),
					prePagocuotaDetalle.getCodmod());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"La preautorzacíón del comprobante se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return;
	}

	public void autorizarComprobante() {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Inicio autorizarComprobante usr: " + usuario.getLogin() + ", IP: " + UtilWeb.getIPRemoto()
					+ " cred: " + itemActual.getId().getPreCodcred());

			prePrccontaBLLocal.cambiarEstadoOperComprob(prePagocuotaDetalle.getPcuTipocmp(), prePagocuotaDetalle.getId(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(),prePagocuotaDetalle.getCoddsb(), prePagocuotaDetalle.getFechaVencimiento(), 3, usuario.getLogin(), UtilWeb.getIPRemoto());

			prePagocuotaDetalle = prePagocuotaBLLocal.findCuotaById(prePagocuotaDetalle.getId());

			planpagosVctos = recuperarSgtesVctos(prePagocuotaDetalle.getCodcred(), prePagocuotaDetalle.getCodmod());
			planpagosVctos = completarPPVctos(planpagosVctos);											
			actListDesembolsos(prePagocuotaDetalle.getFechaVencimiento(), prePagocuotaDetalle.getCodcred(),
					prePagocuotaDetalle.getCodmod());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"La autorización se ha ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return;
	}

	private List<VPlanPagosConsolQuery> recuperarSgtesVctos(Integer codcred, Integer codmod) {
		try {
			Date hoy = new Date();
			Date hoyMasXdias = UtilDate.addTime(hoy, 30, 5);
			return prePlanpagosQLLocal.cuotasVencPendOSgtes(codcred, codmod, hoyMasXdias);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private List<VPlanPagosConsolQuery> completarPPVctos(List<VPlanPagosConsolQuery> ppList) {
		try {
			List<VPlanPagosConsolQuery> planpagosVctos = ppList.stream().filter(pc -> {
				boolean consaldo = (pc.getAmortizacionSaldo().compareTo(BigDecimal.ZERO) > 0)
						|| (pc.getInteresSaldo().compareTo(BigDecimal.ZERO) > 0);
				if (consaldo) {
					return true;
				}
				Optional<PrePagocuota> pcSinCmpbList = prePagocuotaBLLocal
						.cuotasPendientesSinCmp(pc.getCodcred(), pc.getCodmod(), pc.getFechavencuo())
						.stream().filter(p -> {
							return StringUtils.isBlank(p.getNroComprobanteCoin());
						}).findFirst();
				return pcSinCmpbList.isPresent();
			}).collect(Collectors.toList());

			return planpagosVctos;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public void realizarCobroVcto(Integer codcred, Integer codmod, Date fechaVen, Integer tipotrxpar) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("En realizar vcobro " + codcred + "-" + codmod + ", fecha: " + fechaVen + " tipo: " + tipotrxpar
					+ " usuario: " + usuario.getLogin());

			prePlanpagosLocal.realizarCobro(codcred, codmod, fechaVen, new Date(), tipotrxpar, usuario.getLogin(),
					UtilWeb.getIPRemoto());
			planpagosVctos = recuperarSgtesVctos(codcred, codmod);
			planpagosVctos = completarPPVctos(planpagosVctos);					
			actListDesembolsos(fechaVen, codcred, codmod);

			log.info("Registro cobrado exitosamente: " + itemActual.getPrePrestamosPK().getPreCodcred() + " "
					+ itemActual.getPrePrestamosPK().getPreCodmod());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro cobrado satisfactoriamente",
					"");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void btnIrADetalleComprob(PrePagocuota prcconta) {
		try {
			Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			log.info("Recuperando renglones prcconta {} usr {}", prcconta.getId(), usuario.getLogin());

			itemActual = prePrestamosBLLocal.prestamoById(prcconta.getCodcred(), prcconta.getCodmod());
			prePagocuotaDetalle = prePagocuotaBLLocal.findCuotaById(prcconta.getId());
			listRenglones = recuperarRengsOper(prcconta);

			if (listRenglones.size() == 0) {
				if (prePagocuotaDetalle.getEstado().equals(Cttes.ESTOPER_AUTO)) {
					prePrccontaBLLocal.cambiarEstadoOperComprob(prePagocuotaDetalle.getPcuTipocmp(), prePagocuotaDetalle.getId(),
					itemActual.getId().getPreCodcred(),
					itemActual.getId().getPreCodmod(), null, prePagocuotaDetalle.getFechaVencimiento(), prePagocuotaDetalle.getEstado(), usuario.getLogin(), UtilWeb.getIPRemoto());			

					prePagocuotaDetalle = prePagocuotaBLLocal.findCuotaById(prcconta.getId());
					listRenglones = recuperarRengsOper(prePagocuotaDetalle);
				}
			}
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void recuperarRenglones(PrePagocuota prcconta) {
		try {
			itemActual = prePrestamosBLLocal.prestamoById(prcconta.getCodcred(), prcconta.getCodmod());
			prePagocuotaDetalle = prePagocuotaBLLocal.findCuotaById(prcconta.getId());
			listRenglones = recuperarRengsOper(prePagocuotaDetalle);
			log.info("recuprado s " + listRenglones.size());
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	private List<ComprobanteDet> recuperarRengsOper(PrePagocuota prcconta) {
		try {
			List<GenPrcparams> rengs = genPrcparamsQLLocal.findByCodPrcYTipoProc(prcconta.getId(),
					prcconta.getPcuTipocmp());
			log.info("rengs comprog " + rengs.size());
			debeSuma = BigDecimal.ZERO;
			haberSuma = BigDecimal.ZERO;
			List<ComprobanteDet> listRengs = rengs.stream().map(p -> {
				ComprobanteDet cd = new ComprobanteDet();
				cd.setRenCodigo(p.getPrpNroreng());
				cd.setMovi(p.getPrpCtamov() + " - " + p.getPrpValue());
				cd.setDebe(BigDecimal.ZERO);
				cd.setHaber(BigDecimal.ZERO);

				if (p.getPrpDh() != null && p.getPrpDh().equals("D")) {
					cd.setDebe(p.getPrpMontomn());
				} else {
					cd.setHaber(p.getPrpMontomn());
				}
				debeSuma = debeSuma.add(cd.getDebe());
				haberSuma = haberSuma.add(cd.getHaber());
				cd.setRenGlosa(p.getPrpGlosa());
				cd.setNroCP(p.getPrpNrocp());
				cd.setGenPrcparams(p);
				return cd;
			}).collect(Collectors.toList());
		return listRengs;
		} catch (Exception e) {
			log.error("Error " + e.getMessage(),e);
			throw new RuntimeException(e);
		}
	}	
	private void actListDesembolsos(Date fecha, Integer codcred, Integer codmod) {
		listEstadoDesembolsos.clear();
		if (fecha == null || codcred == null || codmod == null)
			return;
		fechaVencimiento = fecha;
		Integer tipoproc = 3; // reporte
		log.info("En recuperar [{}]lista de estados a fecha {}", codcred, fechaVencimiento);
		prePagocuotaBLLocal.generarDevengadosCredito(codcred, codmod, fecha, fecha, tipoproc);

		listEstadoDesembolsos = preDesembBLLocal.estadoDesembolsosAFecha(codcred, codmod, null, fecha);
		listEstadoDesembolsos.forEach(e -> {
			List<PrePagocuota> lpc = prePagocuotaBLLocal.findByCredDsbVcto(e.getCodcred(), e.getCodmod(), e.getCoddsb(), e.getFecha());
			e.setCuotasLista(lpc);
		});
		estadoDesembolsosTots = PreDesembBLLocalImpl.sumarConStreams(listEstadoDesembolsos);
	}

	// Método con valueChangeListener
	public void actualizarListaDesemb(ValueChangeEvent event) {
		Date nuevaFecha = (Date) event.getNewValue();
		if (itemActual == null)
			return;
		actListDesembolsos(nuevaFecha, itemActual.getPrePrestamosPK().getPreCodcred(),
				itemActual.getPrePrestamosPK().getPreCodmod());
	}

	// Método para p:ajax listener
	public void actualizarListaDesemb(SelectEvent event) {
		Date fechaSeleccionada = (Date) event.getObject();
		if (itemActual == null)
			return;
		// Lógica para actualizar la lista
		actListDesembolsos(fechaSeleccionada, itemActual.getPrePrestamosPK().getPreCodcred(),
				itemActual.getPrePrestamosPK().getPreCodmod());
	}

	public void buscarPorNroDeContrato() {
		try {
			limpiar();
			itemActual = null;			
			cliente = "";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);
		}catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarPorNroDePrestamo() {
		try {
			limpiar();
			itemActual = null;			
			cliente = "";
			contrato = "";
			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void buscarClientes() {
		try {

			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}

	}

	public void selectCliPersonaFromDialog(CliPersona product) {
		try {
			limpiar();
			cliente = cliPersona.getCliNombre();
			contrato = "";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
			itemActual = null;

		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}

	public StreamedContent repEstaServDeuda(Integer codcred, Integer codmod, Date fechaVen, String formato) {
		StreamedContent sc = null;
		try {
			String nombreReporte = "reporteDetalleCobroPorDesenbolso";
			String tipoReporte = formato;
			String fecVcto = new SimpleDateFormat("yyyy-MM-dd").format(fechaVen);

			log.info("repEstaServDeuda cod: " + codcred + " fecha : " + fecVcto);
			Integer tipoproc = 3; // reporte
			prePagocuotaBLLocal.generarDevengadosCredito(codcred, codmod, fechaVen, fechaVen, tipoproc);

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("fecha", fecVcto);
			parametros.put("ley", utilWebBean.obtenerDatosLeyesDevengado(itemActual));
			parametros.put("codcred", codcred);
			parametros.put("codmod", codmod);
			parametros.put("fecha_vencimiento", fecVcto);
			// parametros.put("codmod", item.getId().getPreCodmod());
			sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte,
					nombreReporte + tipoReporte);
			return sc;
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public boolean isActualizableCuotaPend(VPlanPagosConsolQuery pc) {
		boolean cancelado = pc.getAmortizacionSaldo() != null
				&& (pc.getAmortizacionSaldo().compareTo(BigDecimal.ZERO) == 0
						&& pc.getInteresSaldo().compareTo(BigDecimal.ZERO) == 0);
		if (!cancelado) {
			return false;
		}
		Optional<PrePagocuota> pcConCmpbList = prePagocuotaBLLocal
				.cuotasPendientesSinCmp(pc.getCodcred(), pc.getCodmod(), pc.getFechavencuo())
				.stream().filter(p -> {
					return p.getPcuNumtrx() != null && p.getPcuNumtrx().compareTo(0) > 0 && p.getEstado() != null
							&& p.getEstado().equals(1);
				}).findFirst();

		return cancelado && pcConCmpbList.isPresent();
	}

	public boolean isConCmpb(PrePagocuota pagocuota) {
		boolean estHabil = pagocuota != null && pagocuota.getEstado() != null && (pagocuota.getEstado().equals(1)
				|| pagocuota.getEstado().equals(2) || pagocuota.getEstado().equals(3));
		return pagocuota != null && !StringUtils.isBlank(pagocuota.getNroComprobanteCoin()) && estHabil;
	}

	public boolean isCuotaVencHabil(VPlanPagosConsolQuery pp) {
		if (pp == null)
			return false;
		boolean conSaldo = pp.getAmortizacionSaldo() != null
				&& ((pp.getAmortizacionSaldo().compareTo(BigDecimal.ZERO) > 0) || (pp.getInteresSaldo().compareTo(BigDecimal.ZERO) > 0));

		boolean diferido = pp.getTipotrx().equals(4);
		boolean vctoOPanti = pp.getTipotrx().equals(2) || pp.getTipotrx().equals(3);

		return conSaldo && vctoOPanti;
	}

	private void actRengsValsGenParams(Integer tipoproc, Integer codcred, Integer codmod, Date fechaVen, Integer tipotrxpar) {
		Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		try {
			log.info("Inicio actRengsValsGenParams usr: " + usuario.getLogin()
					+ ", IP: " + UtilWeb.getIPRemoto() + " cred: " + itemActual.getId().getPreCodcred() + " en fecha "
					+ new Date().toString());

			prePagocuotaBLLocal.actualizarRengs(tipoproc, codcred, codmod, fechaVen, tipotrxpar, usuario.getLogin(),
					UtilWeb.getIPRemoto());

			planpagosVctos = recuperarSgtesVctos(codcred, codmod);
			planpagosVctos = completarPPVctos(planpagosVctos);
			actListDesembolsos(fechaVen, codcred, codmod);

			PrimeFaces.current().executeScript("PF('dlgCmpbRengs').hide();");			
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Proceso de actualización ejecutado correctamente", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			log.error("Error {}", e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);

		}
	}	
}
