package gob.bcb.jee.creditos.web.util;

import gob.bcb.jee.creditos.util.Log;

/**
 * Clase de instanciacion de la clase particular actual
 * 
 * @author ysalinas
 * 
 */
public class Instantiator
{

  /**
   * Metodo que realiza la instanciacion de la clase actual
   * 
   * @param clazz
   * @return
   */
  public static <T> T instantiate(Class<T> clazz)
  {
    try
    {
      return clazz.newInstance();
    }
    catch (InstantiationException e)
    {
      Log.Error("Error en la intanciacion de la clase. " + e.getMessage().toString());
      return null;
    }
    catch (IllegalAccessException e)
    {
      Log.Error("Error en la intanciacion de la clase. " + e.getMessage().toString());
      return null;
    }
  }

}
