package gob.bcb.jee.creditos.web.pages.gestion;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenModuloBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.BL.PrePlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreReprogramaBLLocal;
import gob.bcb.jee.creditos.BL.PreTasaspreBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenModulo;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.model.PreTasaspre;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "DiferimientoBean")
@ViewScoped
@Getter
@Setter
public class DiferimientoCreditoBean  implements Serializable {

    private static final long serialVersionUID = 1L;
  
    @Inject
    private GenTipProductoBLLocal genTipProductoBLLocal;
    
    @Inject
    private GenDesctablaBLLocal genDesctablaBLLocal;
    
    @Inject
    private GenMonedaBLLocal genMonedaBLLocal;
    
    @Inject
    private PrePrestamosBLLocal prePrestamosBLLocal;
    
    @Inject
    private GenModuloBLLocal genModuloBLLocal;
    
    @Inject
    private CliPersonaBLLocal service;
    
    @Inject
    private PreTasaspreBLLocal preTasaspreBLLocal;

    @Inject
    private PrePlanpagosBLLocal prePlanpagosLocal;
    
    @Inject
    private PreReprogramaBLLocal preReprogramaBLLocal;
    
    private List<CliPersona> products;
    
    private List<PreTasaspre> listPreTasaspre;
    
    private PrePrestamos itemActual=new PrePrestamos();
    
    private PreReprograma preReprograma=new PreReprograma();
    private List<PreReprograma> listPreReprograma; 
    private PreTasaspre preTasaspre=new PreTasaspre();
    private Double plazo;
    private Double gracia;
    
    private PrePrestamos prePrestamos=new PrePrestamos();
    private List<PrePrestamos> listPrePrestamos;
    private boolean habilitadoCampos=true;
    private CliPersona cliPersona= new CliPersona();
    private String cliente;
    private List<GenTipproducto> listGenTipproductos;
    private GenTipproducto genTipproducto;
    private String igenTipproducto;
    
    private List<GenModulo> listGenModulo;
    
    private List<GenMoneda> listGenMoneda;
    private GenMoneda genGenMoneda;
    private Integer igenGenMoneda;
    
    private Integer igenGenModulo;
    private Integer codigoPrestamo;
    private String contrato;
    
//    private List<GenDesctabla> listGenDesctablaRubro;
//    private GenDesctabla genDesctablaRubro;
//    private Integer igenDesctablaRubro;
//    
//    private List<GenDesctabla> listGenDesctablaDestino;
//    private GenDesctabla genDesctablaDestino;
//    private Integer igenDesctablaDestino;
    private List<GenDesctabla> listGenDesctablaPlazo; 
    private List<GenDesctabla> listGenDesctablaCapitalizacion;    
    private List<Object[]> listPrePlanpagosO;
    private Integer idReprogramacion=0;
    private BigDecimal valorPago;
    private Date fechaInicio;    
    private Date fechaFin;
    public DiferimientoCreditoBean() {
    }

    @PostConstruct
    public void init() {     
    	try {    		
			listGenTipproductos=genTipProductoBLLocal.list();
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		}
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}     	
    }
  
 
    public void iniciar() {
    	try {    		
    		genTipproducto=new GenTipproducto();
    		genGenMoneda=new GenMoneda();

    	//	genDesctablaRubro=new GenDesctabla();
    		//genDesctablaDestino=new GenDesctabla();

    		listGenTipproductos=genTipProductoBLLocal.list();
    		Map<String,Object> valores=new HashMap<>();
    	//	valores.put("valor1", 160);
    	//	listGenDesctablaRubro=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
    	//	valores.replace("valor1", 1750);
    	//	listGenDesctablaDestino =genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores); 
    		valores.replace("valor1", 1704);
    		//listGenDesctablaEstado=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
    		listGenMoneda =genMonedaBLLocal.list();
    		
    		valores.put("valor1", 413);
    		listGenDesctablaCapitalizacion=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
    		
    		
    		
		}
    	
    	catch (Exception e) {
    		Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		} 
    	  	
    }
    
    public void verPlanDePagosPreG(Integer codcred,Integer codmod,Integer coddesem) {
		try {
		listPrePlanpagosO=prePlanpagosLocal.mostrarPlanDePagosGeneral(codcred, codmod, coddesem);	
		}
		 catch (Exception e) {
				Log.Error(e);
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			    FacesContext.getCurrentInstance().addMessage(null, message);
				
			} 
	    	
		
	}
    
    public void verDiferimientos(Integer codcred,Integer codmod){
   	 try {   		
   		 Map<String,Object> valores=new HashMap<>();
				valores.put("valor1", codcred);
				valores.put("valor2", codmod);
				valores.put("valor3", 3);//reprogramacion
			 listPreReprograma=preReprogramaBLLocal.listByNamedQuery(PreReprograma.NQ_GET_BY_CRED, valores);
   	 } 
   	 catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}
   	
   }
   
	 public void grabarDiferimiento(Integer codcred,Integer codmod) {
		 
		 try {
			 //valorPago
			 Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);	
			 
			 preReprograma=new PreReprograma();
			 preReprograma.setId(preReprogramaBLLocal.nuevoId());
			 preReprograma.setRdsCodcred(codcred);
			 preReprograma.setRdsCodmod(codmod);
			 preReprograma.setRdsFecini(this.fechaInicio);
			 preReprograma.setRdsFecfin(this.fechaFin);
			 preReprograma.setRdsNrodoc(this.contrato);
			 preReprograma.setRdsTabtiporepro(59);
			 preReprograma.setRdsTiporepro(3);
			 preReprograma.setRdsTabtrxstaau(30);
			 preReprograma.setRdsTrxstaau(1);
			 preReprograma.setRdsAuditusr(usuario.getLogin());
			 preReprograma.setRdsAuditfho(new Date());
			 preReprograma.setRdsAuditwst(UtilWeb.getIPRemoto());
			 //preReprogramaBLLocal.persist(preReprograma,usuario.getLogin());
			 this.fechaInicio=fechaFin=null;
			 this.contrato=null;
			 prePrestamosBLLocal.diferimiento(preReprograma,1,new Date(),this.fechaInicio, this.fechaFin,usuario.getLogin(),UtilWeb.getIPRemoto());			 
			 FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información","Diferimiento creado correctamente");
			 FacesContext.getCurrentInstance().addMessage(null, message);			
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}
	 }
	 
	 public void preautorizar() {
		 try {
			 Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);					
			 preReprograma.setRdsTrxstaau(2);
			 preReprograma.setRdsAuditusr(usuario.getLogin());
			 preReprograma.setRdsAuditfho(new Date());
			 preReprograma.setRdsAuditwst(UtilWeb.getIPRemoto());									 
			 //preReprogramaBLLocal.merge(preReprograma,usuario.getLogin());
			 prePrestamosBLLocal.diferimiento(preReprograma,2,new Date(),this.fechaInicio, this.fechaFin,usuario.getLogin(),UtilWeb.getIPRemoto());	
			 verDiferimientos(preReprograma.getRdsCodcred(),preReprograma.getRdsCodmod());			 
			 FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información","Preautorizado el diferimiento correctamente");
			 FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}
	 }
	 public void autorizar() {	
		 try {
			 Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);					
			 preReprograma.setRdsTrxstaau(3);
			 preReprograma.setRdsAuditusr(usuario.getLogin());
			 preReprograma.setRdsAuditfho(new Date());
			 preReprograma.setRdsAuditwst(UtilWeb.getIPRemoto());
			 					
			 prePrestamosBLLocal.diferimiento(preReprograma,3,new Date(),preReprograma.getRdsFecini(),preReprograma.getRdsFecfin(),usuario.getLogin(),UtilWeb.getIPRemoto());
			 //preReprogramaBLLocal.merge(preReprograma,usuario.getLogin());
			 verDiferimientos(preReprograma.getRdsCodcred(),preReprograma.getRdsCodmod());	
			 FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Información","Autorizado el diferimiento correctamente");
			 FacesContext.getCurrentInstance().addMessage(null, message);
			
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}
	 }
	 
	 public void eliminarDiferimientos(Integer id) {
	    	Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
	    	try {    		
				prePrestamosBLLocal.diferimiento(preReprograma,9,new Date(),preReprograma.getRdsFecini(),preReprograma.getRdsFecfin(),usuario.getLogin(),UtilWeb.getIPRemoto());
	    		//preReprogramaBLLocal.delete(id, usuario.getLogin());
				Log.Info("Diferimiento eliminado:"+id);
				//iniciarVerReprogramacion(itemActual.getId().getPreCodcred(), itemActual.getId().getPreCodmod());
				verDiferimientos(preReprograma.getRdsCodcred(),preReprograma.getRdsCodmod());	
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Pago anticipado rechazado","Satisfactorio" );
			    FacesContext.getCurrentInstance().addMessage(null, message);
			} catch (Exception e) {
				Log.Error(e);
				FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			    FacesContext.getCurrentInstance().addMessage(null, message);
				
			}
	    }

	 public void selectCliPersonaFromDialog(CliPersona product) {    
	    	try {
	      //  cliPersona =  product;
	        cliente=cliPersona.getCliNombre();
	        contrato="";
	        this.codigoPrestamo=0;
	        Map<String,Object> valores=new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());
	    	listPrePrestamos=prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
	    	}
	    	
	    	 catch (Exception e) {
	 			Log.Error(e);
	 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
	 		    FacesContext.getCurrentInstance().addMessage(null, message);
	 			
	 		} 
	     	
	    }
	      
	    public void buscarPorNroDeContrato() {
	    	try {
	    		cliente="";
	    		this.codigoPrestamo=0;
	    	Map<String,Object> valores=new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
	    	listPrePrestamos=prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);    
	    	}
	    	
	    	 catch (Exception e) {
	 			Log.Error(e);
	 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
	 		    FacesContext.getCurrentInstance().addMessage(null, message);
	 			
	 		} 
	     	
	    }
	    public void buscarPorNroDePrestamo() {    
	    	try {
	    		cliente="";
	    		contrato="";
			Map<String,Object> valores=new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
		//	valores.put("pre_codmod", igenGenModulo);
	    	listPrePrestamos=prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);  
	    	}
	    	
	    	 catch (Exception e) {
	 			Log.Error(e);
	 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
	 		    FacesContext.getCurrentInstance().addMessage(null, message);
	 			
	 		} 
	     	
	    }       
	    
	    public void buscarClientes() {
	    	try {
	    	products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
	    	}
	    	 catch (Exception e) {
	 			Log.Error(e);
	 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
	 		    FacesContext.getCurrentInstance().addMessage(null, message);
	 			
	 		} 
	     	
	    }
}
