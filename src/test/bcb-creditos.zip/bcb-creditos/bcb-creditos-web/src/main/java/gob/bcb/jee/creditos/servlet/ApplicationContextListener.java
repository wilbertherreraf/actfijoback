package gob.bcb.jee.creditos.servlet;

import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


/**
 * Servlet de inicio y cierre de aplicacion
 * 
 * 
 */
public class ApplicationContextListener implements ServletContextListener
{

  @Override
  public void contextDestroyed(ServletContextEvent sce)
  {
    Log.Trace("Cerrando aplicacion");

    Log.Trace("Aplicacion cerrada");
  }

  @Override
  public void contextInitialized(ServletContextEvent sce)
  {
    Log.Trace("Iniciando aplicacion (listener)");

    Log.Debug("Context:" + sce.getServletContext().getContextPath());

    CttesWeb.init(sce.getServletContext().getContextPath());

    Log.Trace("Aplicacion iniciada");
  }

}
