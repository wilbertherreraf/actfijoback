package gob.bcb.jee.creditos.web.pages.parametros;


import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.LeyBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenDesctablaPK;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.Ley;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;


import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "LeyBean")
@ViewScoped
@Getter
@Setter
public class LeyBean  implements Serializable {

    private static final long serialVersionUID = 1L;
  

    @Inject
    private LeyBLLocal leyBLLocal;

    
    
    private List<Ley> listLey;
    
    private Ley ley= new Ley();
        
    public LeyBean() {
    }

    @PostConstruct
    public void init() {     
    	try {
    		listLey=leyBLLocal.list();
		} 
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}     	
    }
   
    public void iniciarNuevo() {
    	ley= new Ley();    	
    	
    }
    
 
    public void guardar() {
    	try {    			    	
    		 Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
    		 
	    		ley.setTabtrxstaau(30);
	    		ley.setTrxstaau(1);
	    		ley.setAuditusr(usuario.getLogin());
	    		ley.setAuditfho(new Timestamp(new Date().getTime()));
	    		ley.setAuditwst(UtilWeb.getIPRemoto());
	    		if(ley.getId()!=null)
	    			leyBLLocal.merge(ley, "");
	    		else {
	    			ley.setId(leyBLLocal.getIdNuevo());
	    			ley=leyBLLocal.persist(ley, "");
	    		}
	    			
	    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente","");
	    	    FacesContext.getCurrentInstance().addMessage(null, message);	    	   
	    	Log.Info("Registro guardado:"+ley);
				
	    limpiar();
	    init();
		} 
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		} 
    	
    	
    }
    
  
    public void limpiar() {
    	ley= new Ley();      
       			
    }
}
