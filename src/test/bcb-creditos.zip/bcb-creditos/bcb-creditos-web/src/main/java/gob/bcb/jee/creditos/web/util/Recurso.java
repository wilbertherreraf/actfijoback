package gob.bcb.jee.creditos.web.util;

import gob.bcb.jee.creditos.entidades.*;
import gob.bcb.jee.creditos.numeradores.CodRecurso;

/**
 * Enumerador de Recursos *
 */
public enum Recurso implements CodRecurso {

    // Enumeradores para la j'erarquia del menu
  //  PARAM("PARAM", null, new String[]{"parametros"}, "Paramétricas", 0, true),
 //   PARAM_PARAMETROS("PARAM_PARAMETROS", Parametro.class, new String[]{"parametros.jsf"},     "Parámetros", 1, true),
 
    GESTION("GESTION", null, new String[]{"gestion"}, "Gestión de Créditos", 2, true),
    GESTION_REGISTRO("GESTION_REGISTRO", null,  new String[]{"registroCredito.jsf"}, "1. Registro del crédito", 3, true),
    GESTION_DATOS("GESTION_DATOS", null,  new String[]{"datosCredito.jsf","prePrestamos.jsf"}, "2. Búsqueda de créditos", 4, true),
	GESTION_DESEMBOLSO("GESTION_DESEMBOLSO", null,  new String[]{"desembolsoCredito.jsf"}, "3. Desembolso de créditos", 5, true),
	//GESTION_MODIFICACION("GESTION_MODIFICACION", null,  new String[]{"modificacionCredito.jsf"}, "Modificación de créditos", 6, true),
	GESTION_TRANSACCION("GESTION_TRANSACCION", null,  new String[]{"transaccionCredito.jsf"}, "4. Transacciones de créditos", 7, true),
	GESTION_COBROS("GESTION_COBROS", null,  new String[]{"cobrosCredito.jsf"}, "5. Pago de cuota", 8, true),
	GESTION_DEVENGADO("GESTION_DEVENGADO", null,  new String[]{"devengadoCredito.jsf"}, "6. Devengado de créditos", 9, true),
	GESTION_REPROGRAMACION("GESTION_REPROGRAMACION", null,  new String[]{"reprogramarCredito.jsf"}, "7. Reprogramación de créditos", 10, true),
	GESTION_PAGOANTICIPADO("GESTION_PAGOANTICIPADO", null,  new String[]{"pagoAnticipadoCredito.jsf"}, "8. Pagos anticipados de créditos", 11, true),
	GESTION_DIFERIMIENTO("GESTION_DIFERIMIENTO", null,  new String[]{"diferimientoCredito.jsf"}, "9. Diferimiento de créditos", 12, true),
    GESTION_REGISTRO_GARANTIAS("GESTION_REGISTRO_GARANTIAS ", null,  new String[]{"registroGarantias.jsf"}, "10. Registro de garantías", 17, true),
	
	ADMINISTRACION("ADMINISTRACION", null, new String[]{"administracion"}, "Administración", 3, true),
	ADMINISTRACION_CLIENTES("ADMINISTRACION_CLIENTES", null, new String[]{"administracionClientes.jsf"}, "1. Beneficiarios",9, true),
	ADMINISTRACION_CLAVES("ADMINISTRACION_CLAVES", null, new String[]{"administracionClaves.jsf"}, "2. Claves",10, true),
	ADMINISTRACION_MONEDA("ADMINISTRACION_MONEDA", null, new String[]{"administracionMoneda.jsf"}, "3. Monedas",11, true),
	ADMINISTRACION_TIPOPRODUCTO("ADMINISTRACION_TIPOPRODUCTO", null, new String[]{"administracionTipoProducto.jsf"}, "4. Tipo de producto",12, true),
	ADMINISTRACION_LEYES("ADMINISTRACION_LEYES", null, new String[]{"administracionLey.jsf"}, "5. Leyes",13, true),
	ADMINISTRACION_ARTICULOS("ADMINISTRACION_ARTICULOS", null, new String[]{"administracionArticulo.jsf"}, "6. Articulos",14, true),
    ADMINISTRACION_CUENTAS("ADMINISTRACION_CUENTAS", null, new String[]{"administracionArticulo.jsf"}, "7. Cuentas",15, true),
    ADMINISTRACION_PARAMETROS_CONTABLES("ADMINISTRACION_PARAMETROS_CONTABLES", null, new String[]{"administracionParametrosContables.jsf"}, "8. Matriz de parámetros contables",16, true),


	//ADMINISTRACION_CLAVES("ADMINISTRACION_CLAVES", null, new String[]{"administracionClaves.jsf"}, "Administración de Claves", 10, true)
	
    
//    PROYECTOS("PROYECTOS", null, new String[]{"proyectos"}, "Créditos", 6, true),
//    PROYECTOS_GESTION("PROYECTOS_GESTION", Proyecto.class,  new String[]{"listadoProyectos.jsf", "registroProyecto.jsf"}, "Gestión de Créditos", 7, true),
//    PROYECTOS_DESEMBOLSOS("PROYECTOS_DESEMBOLSOS", Desembolso.class,  new String[]{"listadoDesembolsos.jsf",   "registroDesembolso.jsf"}, "Desembolsos", 8, false),
//    PROYECTOS_DEVENGADOS("PROYECTOS_DEVENGADOS", Devengado.class,  new String[]{"listadoDevengados.jsf"}, "Devengados", 9, false),
//    PROYECTOS_PAGOS("PROYECTOS_PAGOS", Pago.class,new String[]{"listadoPagos.jsf", "registroPago.jsf"}, "Pagos", 10, false),
    REPORTES("REPORTES",   null, new String[]{"reportes"}, "Reportes", 1, true),
    REPORTES_CONSOLIDADOPLANDEPAGOS("REPORTES_CONSOLIDADOPLANDEPAGOS", null, new String[]{"reporteConsolidadoPlanPagos.jsf"}, "1. Consolidado de Plan de Pagos",7, true),
    REPORTES_INTERESDEVENGADOSMENSUALES("REPORTES_INTERESDEVENGADOSMENSUALES", null, new String[]{"reporteDeDevengados.jsf"}, "2. Interes devengados mensuales",8, true),
    REPORTES_COBROCAPITALPORVENCIMIENTO("REPORTES_COBROCAPITALPORVENCIMIENTO", null, new String[]{"reporteCobroCapitalEInteres.jsf"}, "3. Servicio de deuda",9, true),
    //REPORTES_INTERESESYCAPITAL("REPORTES_INTERESESYCAPITAL", null, new String[]{"reporteEstadoInteresCapital.jsf"}, "4. Estado de intereses y capital",10, true),
    REPORTES_ESTADODECREDITOS("REPORTES_ESTADODECREDITOS", null, new String[]{"reporteEstadoDeCreditos.jsf"}, "4. Estado de créditos",11, true),
    REPORTES_EJECUTIVODECREDITOS("REPORTES_EJECUTIVODECREDITOS", null, new String[]{"reporteEjecutivoPorCredito.jsf"}, "5. Ejecutivo de créditos",12, true),
    REPORTES_GARANTIAS("REPORTES_GARANTIAS", null, new String[]{"reporteGarantias.jsf"}, "6. Garantias",13, true),

    
;
    private String codRecurso;
    private String[] url;
    private String textMenu;
    private Integer order;
    private Class clazz;
    private boolean visible;

    private Recurso(String codRecurso, Class clazz, String[] url, String textMenu,
                    Integer order, boolean visible) {
        this.codRecurso = codRecurso;
        this.clazz = clazz;
        this.url = url;
        this.textMenu = textMenu;
        this.order = order;
        this.visible = visible;
    }

    /**
     * Metodo que obtiene le recurso actual - implementa de CodRecurso
     */
    @Override
    public String getCodigoRecurso() {
        return codRecurso;
    }

    /**
     * Metodo que obtiene la clase con la que el recurso actual trabaja -
     * implementa de CodRecurso
     */
    @SuppressWarnings("rawtypes")
    @Override
    public Class getClazz() {
        return clazz;
    }

    @Override
    public String[] getUrl() {
        return url;
    }

    @Override
    public String getTextMenu() {
        return textMenu;
    }

    @Override
    public Integer getOrder() {
        return order;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.numeradores.CodRecurso#getVisible()
     */
    @Override
    public boolean getVisible() {
        return visible;
    }

}
