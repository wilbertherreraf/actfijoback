package gob.bcb.jee.creditos.web.reportes;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.primefaces.model.StreamedContent;

import gob.bcb.jee.creditos.BL.AuxPlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.PreDesembBLLocal;
import gob.bcb.jee.creditos.BL.PreGarantiadBLLocal;
import gob.bcb.jee.creditos.BL.PrePagocuotaBLLocal;
import gob.bcb.jee.creditos.BL.PrePlanpagosBLLocal;
import gob.bcb.jee.creditos.BL.PrePrccontaBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.pages.UtilWebBean;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

@ManagedBean(name = "BuscarReportesBean")
@Getter
@Setter
@ViewScoped
public class BuscarReportesBean implements Serializable {

	@Inject
	GeneradorReporte generadorReporte;

	@Inject
	private PrePrestamosBLLocal prePrestamosBLLocal;

	@Inject
	UtilWebBean utilWebBean;

	@Inject
	private PreDesembBLLocal preDesembBLLocal;

	@Inject
	private PrePlanpagosBLLocal prePlanpagosBLLocal;

	@Inject
	private PreGarantiadBLLocal preGarantiadBLLocal;

	@Inject
	private AuxPlanpagosBLLocal auxPlanpagosBLLocal;

	@Inject
	private CliPersonaBLLocal service;
	@Inject
	private PrePrccontaBLLocal prePrccontaBLLocal;	
	// private PrePrestamos itemActual;
	@Inject
	private PrePagocuotaBLLocal  prePagocuotaBLLocal;

	private Date ini, fin;
	private Date fecha_ini, fecha_fin;
	private Date fin2;
	private Date fin3;
	private Date fin5;	
	private Date fin6;
	private Date maxDate;
	private PrePrestamos itemActual = new PrePrestamos();

	String pattern = "dd MMMMM yyyy";
	String pattern2 = "dd-MM-yyyy";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale("es", "ES"));
	SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(pattern2, new Locale("es", "ES"));
	private List<PreDesemb> listPreDesem;
	private Optional<PreDesemb> preDesemb = Optional.of(new PreDesemb());
	private Integer codigoPrestamo;
	private CliPersona cliPersona = new CliPersona();
	private String cliente;
	private String contrato;
	private List<PrePrestamos> listPrePrestamos;
	private List<CliPersona> products;
	private StreamedContent fileDown;

	@PostConstruct
	public void init() {
		try {

			// Calcular el último día del mes anterior
			Calendar calendar = Calendar.getInstance();

			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
			ini = new Date();
			fin = new Date();
			fin2 = new Date();
			fin3 = new Date();
			fin5 = new Date();
			fin6 = new Date();
			fecha_ini = null;
		    fecha_fin = null;


			// Calcular el último día del mes anterior
			calendar.set(Calendar.DAY_OF_MONTH, 1); // Establecer al primer día del mes actual
			calendar.add(Calendar.DAY_OF_MONTH, -1); // Retroceder un día para obtener el último día del mes anterior
			maxDate = calendar.getTime(); // Asignar el valor a maxDate
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			
		}
	}

	public StreamedContent generarReportePlanPagos(String tipoReporte, PrePrestamos item) throws OperationException {
		StreamedContent sc = null;
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		prePlanpagosBLLocal.actualizarConsolidado(item.getId().getPreCodcred(), item.getId().getPreCodmod(), 1);

		String nombreReporte = "";

		if(item.getId().getPreCodcred()==43){
			nombreReporte = "reporteConsolidadoPlanDePagosFNDR";
		}
		else{
			nombreReporte = "reporteConsolidadoPlanDePagos";
		}

		Map<String, Object> parametros = new HashMap<String, Object>();
		// JRBeanCollectionDataSource beanColDesDetDataSource = new
		// JRBeanCollectionDataSource(resumenUsuarios, false);
		parametros.put("interes_anual", item.getPreTasapac());
		parametros.put("pago_interes", utilWebBean.getDescTabla(item.getPreTabunidplaz(), item.getPreUnidplaz()));
		parametros.put("valor_nominal", item.getPreMonto());
		int valor = item.getPreUnidplaz() != null ? prePrestamosBLLocal.getValorPeriodicidad(item.getPreUnidplaz()) : 1;
		double plazo = (double) (item.getPreNroperiodos() != null ? item.getPreNroperiodos() : 0) / (double) (valor);
		double gracia = (double) (item.getPreNrogracia() != null ? item.getPreNrogracia() : 0) / (double) (valor);
		double graciaInteres = (double) (item.getPreNrograciaint() != null ? item.getPreNrograciaint() : 0)
				/ (double) (valor);
		parametros.put("plazo", (int) (plazo) + " años");
		parametros.put("cliente", utilWebBean.getClienteSigla(item.getPreCodcli()) + " - " + item.getPreDescrip());
		parametros.put("periodo_gracia", (int) (gracia) + " años");
		parametros.put("periodo_gracia_interes", (int) (graciaInteres) + " años");
		parametros.put("codcred", item.getId().getPreCodcred());
		parametros.put("codmod", item.getId().getPreCodmod());
		parametros.put("codusuario", usuario.getLogin());
		// parametros.put("DS1", beanColDesDetDataSource);
		// nombreReporte = "usuarioRol";
		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte, nombreReporte + tipoReporte);
		// sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros,
		// "xlsx", nombreReporte);
		return sc;
	}

	public StreamedContent  generarReporteEjecutivoCredito(String tipo, PrePrestamos item) throws OperationException, ParseException {
		StreamedContent sc = null;
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		String nombreReporte = "reporteEjecutivoCredito";
		BigDecimal valorInteres = new BigDecimal("0.0");
		BigDecimal interesAcumulado=new BigDecimal("0.0");
		BigDecimal interesMesAnterior = new BigDecimal("0.0");

		Log.Info(" valore de fecha  ------> "+ini);

		if (maxDate.before(ini)) {
			// Crear un formateador de fecha
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			// Formatear la fecha
			String formattedDate = dateFormat.format(maxDate);

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,"La fecha del reporte no debe ser mayor a "+formattedDate, "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}


		Date fechaInicio=prePrestamosBLLocal.obtenerFechaCancelado(item.getId().getPreCodcred(), item.getId().getPreCodmod());
		Date fechaProximoPago=prePrestamosBLLocal.obtenerFechaProximoPago(item.getId().getPreCodcred(), item.getId().getPreCodmod());

		if (fechaProximoPago == null ) {
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,"No existe fecha de proximo pago para el credito N° "+item.getId().getPreCodcred(), "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}

		// resta un mes a la fecgha actual, para obtener el devengado del mes anterior
		//LocalDate fechaActual = LocalDate.now();
		/*Instant instant = ini.toInstant();
		LocalDate localDateFechaSelect = instant.atZone(ZoneId.systemDefault()).toLocalDate();*/
		/*LocalDate fechaActual = localDateFechaSelect; //recuperamos la fecha seleccionada por el usuario y se asigna a la variable fecha actual;
		LocalDate mesAnterior = fechaActual.minusMonths(1);
		Date fechaMesAnterior = Date.from(mesAnterior.atStartOfDay(ZoneId.systemDefault()).toInstant());*/


		/*Calendar calendario = Calendar.getInstance();
		calendario.setTime(fechaMesAnterior);
		int ultimoDiaDelMes = calendario.getActualMaximum(Calendar.DAY_OF_MONTH);
		calendario.set(Calendar.DAY_OF_MONTH, ultimoDiaDelMes);
		Date ultimoDia = calendario.getTime();*/


		// Fecha inicial y final
		Date startDate = fechaInicio;
		/*SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date endDate = ultimoDia; //format.parse("2024-06-19");

		SimpleDateFormat formateador = new SimpleDateFormat("yyyy-MM-dd");
		String fechaString = formateador.format(endDate);*/


		// obtiene el interes devengado no el del mes anterior 
		PrePlanpagos prePlanpagos = prePrccontaBLLocal.obtenerDevengamientoAFecha(item.getId().getPreCodcred(), item.getId().getPreCodmod(), ini, ini);
		interesMesAnterior = prePlanpagos.getCuoInteres();

		// Formateador de fechas
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		// Iterar sobre cada mes entre las fechas inicial y final
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		while (calendar.getTime().compareTo(ini) <= 0) {
			// Obtener el último día del mes actual
			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));

			// Formatear el último día del mes
			Date lastDayOfMonth = calendar.getTime();
			String formattedLastDayOfMonth = sdf.format(lastDayOfMonth);
			Log.Info(formattedLastDayOfMonth+" -> "+item.getId().getPreCodcred());
			//Date fechaConsulta=format.parse(formattedLastDayOfMonth);

			prePlanpagos = prePrccontaBLLocal.obtenerDevengamientoAFecha(item.getId().getPreCodcred(), item.getId().getPreCodmod(), lastDayOfMonth, lastDayOfMonth);
			valorInteres = prePlanpagos.getCuoInteres(); 
			interesAcumulado=interesAcumulado.add(valorInteres);
			//interesAcumulado = interesAcumulado+ valorInteres;

			// Avanzar al siguiente mes
			calendar.add(Calendar.MONTH, 1);
		}

		// sumamos los intereses acumukuadois mas el actual
		//interesAcumulado=interesAcumulado.add(interesMesAnterior);

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codusuario", usuario.getLogin());
		parametros.put("cliente", utilWebBean.getClienteSigla(item.getPreCodcli()));
		parametros.put("proyecto", item.getPreDescrip());
		parametros.put("modulo_producto", utilWebBean.getTipModulo(item.getId().getPreCodmod()) + " - "
				+ utilWebBean.getTipProducto(item.getId().getPreCodmod(), item.getPreCodprod()));
		parametros.put("ley", utilWebBean.obtenerLeyesArray(item.getPreNumconv()));
		parametros.put("resolucion_directorio", item.getPreNumresol());

		parametros.put("fecha_contrato", item.getPreFecemi());
		parametros.put("contrato_sano", item.getPreNumcontra());
		parametros.put("fecha_limite_desembolso", item.getPreFeclimite());
		parametros.put("monto_contractual", item.getPreMonto());
		parametros.put("monto_desembolsado", item.getPreMonliqent());
		parametros.put("monto_pendiente_desembolso", item.getPreSaldo());
		parametros.put("tasa_interes", item.getPreTasapac());
		parametros.put("forma_pago", utilWebBean.getDescTabla(item.getPreTabunidplaz(), item.getPreUnidplaz()));
		parametros.put("moneda", utilWebBean.getMoneda(item.getPreCodmon()));

		int valor = item.getPreUnidplaz() != null ? prePrestamosBLLocal.getValorPeriodicidad(item.getPreUnidplaz()) : 1;
		double plazo = (double) (item.getPreNroperiodos() != null ? item.getPreNroperiodos() : 0) / (double) (valor);
		double gracia = (double) (item.getPreNrogracia() != null ? item.getPreNrogracia() : 0) / (double) (valor);
		double graciaInteres = (double) (item.getPreNrograciaint() != null ? item.getPreNrograciaint() : 0)
				/ (double) (valor);

		parametros.put("plazo_anual", (int) (plazo) + ((int) (plazo) > 1 ? " AÑOS" : " AÑO"));
		parametros.put("periodo_gracia", (int) (gracia) + ((int) (gracia) > 1 ? " AÑOS" : " AÑO"));
		parametros.put("periodo_gracia_interes",
				(int) (graciaInteres) + ((int) (graciaInteres) > 1 ? " AÑOS" : " AÑO"));
		parametros.put("numero_desembolsos", prePrestamosBLLocal
				.obtenerCantidadDesembolsos(item.getId().getPreCodcred(), item.getId().getPreCodmod()));
		parametros.put("intereses_devengados", prePrestamosBLLocal
				.obtenerInteresesDevengado(item.getId().getPreCodcred(), item.getId().getPreCodmod()));
		parametros.put("intereses_cobrados", prePrestamosBLLocal.obtenerInteresesCobrados(item.getId().getPreCodcred(),
				item.getId().getPreCodmod()));
		parametros.put("vencimiento_credito", prePrestamosBLLocal
				.obtenerUltimaFechaPlanPagos(item.getId().getPreCodcred(), item.getId().getPreCodmod()));

		parametros.put("monto_descomprometido", prePrestamosBLLocal
					.obtenerMontoDescomprometido(item.getId().getPreCodcred(), item.getId().getPreCodmod()));
		parametros.put("capital_amortizado", prePrestamosBLLocal.obtenerCapitalAmortizado(item.getId().getPreCodcred(),
				item.getId().getPreCodmod()));


		parametros.put("fecha_proximo_pago", fechaProximoPago);
		parametros.put("interes_mes_anterior", interesMesAnterior);
		parametros.put("interes_acumulado", interesAcumulado);
		parametros.put("codcred", item.getId().getPreCodcred());
		parametros.put("codmod", item.getId().getPreCodmod());
		parametros.put("fecha_select", ini);

		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipo, nombreReporte + tipo);
		// sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros,
		// "xlsx", nombreReporte);
		return sc;
	}

	public StreamedContent generarReporteCobroInteres(String tipoReporte, String nombreReporte) {
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		StreamedContent sc = null;
		ini = ini == null ? fin : ini ;
		//String nombreReporte = "reporteDeCobroCapitalInteres";
		if (ini != null && fin.before(ini)) {
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"La fecha de inicio debe ser anterior a la fecha fin", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codusuario", usuario.getLogin());
		parametros.put("tipo_producto", cliPersona != null && cliPersona.getCliNombre()!=null? cliPersona.getCliNombre().toUpperCase():"AL SECTOR PÚBLICO");
		parametros.put("fecha", "Al " + simpleDateFormat.format(fin));
		parametros.put("fecha_ini", ini);
		parametros.put("fecha_fin", fin);
		if (cliPersona != null && cliPersona.getCliCodigo() != null && cliPersona.getCliCodigo().compareTo(0) > 0) {
			parametros.put("clicodigo", cliPersona.getCliCodigo());			
		}
		parametros.put("codcred", codigoPrestamo);
		
		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte,
				nombreReporte + tipoReporte);

		// sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros,
		// "xlsx", nombreReporte);
		return sc;

	}

	public StreamedContent generarReporteDevengados(String tipoReporte, PrePrestamos item, Date fecha) throws ParseException {
		StreamedContent sc = null;
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

		String nombreReporte="";
		if(utilWebBean.getClienteSigla(item.getPreCodcli()).equals("YPFB")){
			nombreReporte = "reporteDeDevengadosYPFB";
		}
		else{
			nombreReporte = "reporteDeDevengados";
		}
        Integer tipoproc = 3; // dev periodo mes
        prePagocuotaBLLocal.generarDevengadosCredito(item.getPrePrestamosPK().getPreCodcred(), item.getPrePrestamosPK().getPreCodmod(), fecha, fecha, tipoproc);

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codusuario", usuario.getLogin());
		parametros.put("importe_credito", item.getPreMonto());
		parametros.put("cliente", utilWebBean.getClienteSigla(item.getPreCodcli()) + " - " + item.getPreDescrip());
		parametros.put("enpe", utilWebBean.getClienteSigla(item.getPreCodcli()));
		parametros.put("fecha", "Al " + simpleDateFormat.format(fecha)/* + " al "+simpleDateFormat.format(fin) */);
		parametros.put("ley", utilWebBean.obtenerDatosLeyesDevengado(item));
		parametros.put("fecha_ini", fecha);
		parametros.put("codcred", item.getId().getPreCodcred());
		parametros.put("codmod", item.getId().getPreCodmod());

		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte, nombreReporte + tipoReporte);

		return sc;
	}

	public StreamedContent generarReporteEstadoCreditos(String tipoReporte) {
		StreamedContent sc = null;

		String nombreReporte = "reporteEstadoDeCreditos";
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("fecha", " Al " + simpleDateFormat.format(ini));
		parametros.put("anio", ini.getYear() + 1900);
		parametros.put("mes", ini.getMonth() + 1);
		parametros.put("dia", ini.getDate());
		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte,
				nombreReporte + tipoReporte);

		// sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros,
		// "xlsx", nombreReporte);
		return sc;

	}

	public StreamedContent generarPlanDePagosIndividualAprobado(String tipoReporte, PrePrestamos itemActual,
			PreDesemb itemActualPreD) throws OperationException {
		StreamedContent sc = null;
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

		String nombreReporte = "reportePlanDePagosPreInd";
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codusuario", usuario.getLogin());
		// JRBeanCollectionDataSource beanColDesDetDataSource = new
		// JRBeanCollectionDataSource(resumenUsuarios, false);
		parametros.put("monto_desembolsado", itemActualPreD.getDsbValor());
		parametros.put("moneda", utilWebBean.getMoneda(itemActual.getPreCodmon()));
		parametros.put("coddsb", itemActualPreD.getId());
		parametros.put("cliente",
				utilWebBean.getClienteSigla(itemActual.getPreCodcli()) + " - " + itemActual.getPreDescrip());
		parametros.put("codcred", itemActual.getId().getPreCodcred());
		parametros.put("codmod", itemActual.getId().getPreCodmod());

		////////////////////////
		parametros.put("interes_anual", itemActual.getPreTasapac());
		parametros.put("pago_interes",
				utilWebBean.getDescTabla(itemActual.getPreTabunidplaz(), itemActual.getPreUnidplaz()));
		// parametros.put("valor_nominal", itemActual.getPreMonliqent());

		int valor = itemActual.getPreUnidplaz() != null
				? prePrestamosBLLocal.getValorPeriodicidad(itemActual.getPreUnidplaz())
				: 1;
		double plazo = (double) (itemActual.getPreNroperiodos() != null ? itemActual.getPreNroperiodos() : 0)
				/ (double) (valor);
		double gracia = (double) (itemActual.getPreNrogracia() != null ? itemActual.getPreNrogracia() : 0)
				/ (double) (valor);
		double gracia_interes = (double) (itemActual.getPreNrograciaint() != null ? itemActual.getPreNrograciaint() : 0)
				/ (double) (valor);
		parametros.put("plazo", (int) (plazo) + " años");
		parametros.put("periodo_gracia", (int) (gracia) + " años");
		parametros.put("periodo_gracia_interes", (int) (gracia_interes) + " años");
		parametros.put("fecha_desembolso", itemActualPreD.getDsbFecdsb());

		// parametros.put("DS1", beanColDesDetDataSource);
		// nombreReporte = "usuarioRol";
		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte,
				nombreReporte + tipoReporte);

		return sc;
	}

	public StreamedContent generarPlanDePagosIndividualAuxiliar(String tipoReporte, PrePrestamos itemActual,
			PreDesemb itemActualPreD,Integer codmod) throws OperationException {
		StreamedContent sc = null;
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

		String nombreReporte = "reportePlanDePagosPreIndAux";
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codusuario", usuario.getLogin());
		// JRBeanCollectionDataSource beanColDesDetDataSource = new
		// JRBeanCollectionDataSource(resumenUsuarios, false);
		parametros.put("monto_desembolsado", itemActualPreD.getDsbValor());
		parametros.put("moneda", utilWebBean.getMoneda(itemActual.getPreCodmon()));
		parametros.put("coddsb", itemActualPreD.getId());
		parametros.put("cliente",
				utilWebBean.getClienteSigla(itemActual.getPreCodcli()) + " - " + itemActual.getPreDescrip());
		parametros.put("codcred", itemActual.getId().getPreCodcred());
		parametros.put("codmod", codmod);

		parametros.put("tasa", itemActual.getPreTasapac());
		parametros.put("pago_interes",
				utilWebBean.getDescTabla(itemActual.getPreTabunidplaz(), itemActual.getPreUnidplaz()));
		// parametros.put("valor_nominal", itemActual.getPreMonliqent());
		int valor = itemActual.getPreUnidplaz() != null
				? prePrestamosBLLocal.getValorPeriodicidad(itemActual.getPreUnidplaz())
				: 1;
		double plazo = (double) (itemActual.getPreNroperiodos() != null ? itemActual.getPreNroperiodos() : 0)
				/ (double) (valor);
		double gracia = (double) (itemActual.getPreNrogracia() != null ? itemActual.getPreNrogracia() : 0)
				/ (double) (valor);
		double gracia_interes = (double) (itemActual.getPreNrograciaint() != null ? itemActual.getPreNrograciaint() : 0)
				/ (double) (valor);
		parametros.put("plazo", (int) (plazo) + " años");
		parametros.put("gracia", (int) (gracia) + " años");
		parametros.put("gracia_interes", (int) (gracia_interes) + " años");
		parametros.put("fecha_desembolso", itemActualPreD.getDsbFecdsb());
		// parametros.put("DS1", beanColDesDetDataSource);
		// nombreReporte = "usuarioRol";
		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte,
				nombreReporte + tipoReporte);

		return sc;
	}

	public StreamedContent generarReporteEstadoInteresCapital(String tipoReporte) {
		StreamedContent sc = null;
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		String nombreReporte = "reporteEstadoDeInteresCapital";
		if (fin.before(ini)) {
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"La fecha de inicio debe ser anterior a la fecha fin", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codusuario", usuario.getLogin());
		parametros.put("fecha", "Al " + simpleDateFormat.format(fin));
		parametros.put("fecha_t_fin", simpleDateFormat2.format(fin));
		parametros.put("fecha_t_ini", simpleDateFormat2.format(ini));
		parametros.put("fecha_ini", ini);
		parametros.put("fecha_fin", fin);

		parametros.put("anio1", ini.getYear() + 1900);
		parametros.put("mes1", ini.getMonth() + 1);
		parametros.put("dia1", ini.getDate());

		parametros.put("anio2", fin.getYear() + 1900);
		parametros.put("mes2", fin.getMonth() + 1);
		parametros.put("dia2", fin.getDate());
		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte,
				nombreReporte + tipoReporte);

		// sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros,
		// "xlsx", nombreReporte);
		return sc;

	}

	public StreamedContent reporteEjecutivoCredito(PrePrestamos item, String tipo) {
		try {
			StreamedContent sc = generarReporteEjecutivoCredito(tipo, item);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reportePDFPlanDePagos(PrePrestamos item) {
		try {
			if (item == null) {
				return null;
			}			
			StreamedContent sc = generarReportePlanPagos("pdf", item);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reporteEXCELPlanDePagos(PrePrestamos item) {
		try {
			if (item == null) {
				return null;
			}
			StreamedContent sc = generarReportePlanPagos("xlsx", item);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}

	}

	public StreamedContent reporteDeDevengados(PrePrestamos item, Date fecha, String formato) {
		try {
			StreamedContent sc = generarReporteDevengados(formato, item, fecha);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public void reportePDFCobroInteres(String tipo, String nombreReporte) {
		try {
			Log.Info("Reportes " + (ini == null) + " nombreReporte " + nombreReporte + " tipo: " + tipo);
			if (nombreReporte.equalsIgnoreCase("repSaldoAdeudado")) {
				fin = fin5;
				ini = fin;
			}else if (nombreReporte.equalsIgnoreCase("reporteSeguimiento")) {
				fin = fin6;
				ini = fin;
			}else if (nombreReporte.equalsIgnoreCase("repCreditosLey")) {
				fin = fin3;
				ini = fin;
			}else if (nombreReporte.equalsIgnoreCase("repCreditosOtorgados")) {
				fin = fin2;
				ini = fin;
			}else if (nombreReporte.equalsIgnoreCase("reporteDeCobroCapitalInteres")) {
				ini = ini;
			}
			
			fileDown = generarReporteCobroInteres(tipo, nombreReporte);
			
		} catch (Exception e) {
			Log.Error("Error en reporte: " + e.getMessage());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}
/*
	public StreamedContent reportePDFCobroInteres2() {
		try {
			StreamedContent sc = generarReporteCobroInteres("pdf");
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reporteEXCELCobroInteres() {
		try {
			StreamedContent sc = generarReporteCobroInteres("xlsx");
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}
*/
	public StreamedContent reportePDFEstadoCreditos() {
		try {
			StreamedContent sc = generarReporteEstadoCreditos("pdf");
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reporteEXCELEstadoCreditos() {
		try {
			StreamedContent sc = generarReporteEstadoCreditos("xlsx");
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reportePDFPlanDePagosIndividualAprobado(PrePrestamos itemActual, PreDesemb itemActualPreD) {
		try {
			StreamedContent sc = generarPlanDePagosIndividualAprobado("pdf", itemActual, itemActualPreD);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}
	public StreamedContent repPlanDePagosDsb(PrePrestamos itemActual, Integer coddsb, String formato) {
		try {
			if (itemActual == null  || coddsb == null)
				return null;
			PreDesemb itemActualPreD = preDesembBLLocal.getByCoddsb(coddsb);
			StreamedContent sc = generarPlanDePagosIndividualAprobado(formato, itemActual, itemActualPreD);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reporteEXCELPlanDePagosIndividualAprobado(PrePrestamos itemActual,
			PreDesemb itemActualPreD) {
		try {
			StreamedContent sc = generarPlanDePagosIndividualAprobado("xlsx", itemActual, itemActualPreD);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reportePDFPlanDePagosIndividualAuxiliar(PrePrestamos itemActual, PreDesemb itemActualPreD,
			int codmod) {
		try {
			StreamedContent sc = generarPlanDePagosIndividualAuxiliar("pdf", itemActual, itemActualPreD, codmod);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reporteEXCELPlanDePagosIndividualAuxiliar(PrePrestamos itemActual, PreDesemb itemActualPreD,
			int codmod) {
		try {
			StreamedContent sc = generarPlanDePagosIndividualAuxiliar("xlsx", itemActual, itemActualPreD, codmod);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reportePDFEstadoInteresCapital() {
		try {
			StreamedContent sc = generarReporteEstadoInteresCapital("pdf");
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reporteEXCELEstadoInteresCapital() {
		try {
			StreamedContent sc = generarReporteEstadoInteresCapital("xlsx");
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public void selectCliPersonaFromDialog(CliPersona product) {
		try {
			// cliPersona = product;
			cliente = cliPersona.getCliNombre();
			contrato = "";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", cliPersona.getCliCodigo());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			
		}

	}

	public void selectCliPersonaFromD(CliPersona cliPerson) {
		try {
			Log.Info("Prsona " + cliPersona.getCliCodigo());
			cliente = cliPersona.getCliNombre();
		}
		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			
		}

	}

	public void buscarPorNroDeContrato() {
		try {
			cliente = "";
			this.codigoPrestamo = 0;
			Map<String, Object> valores = new HashMap<>();
			valores.put("valor1", contrato.toUpperCase());
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_NRO_CONTRATO, valores);
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			
		}

	}

	public void buscarPorNroDePrestamo() {
		try {
			cliente = "";
			contrato = "";
			Map<String, Object> valores = new HashMap<>();
			valores.put("pre_codcred", codigoPrestamo);
			// valores.put("pre_codmod", igenGenModulo);
			listPrePrestamos = prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_ID, valores);
		}

		catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			
		}
	}

	public void buscarClientes() {
		try {
			cliPersona = new CliPersona();			
			products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			
		}

	}

	public StreamedContent reporteEXCELGarantias(PrePrestamos itemActual, PreDesemb itemActualPreD) {
		try {
			StreamedContent sc = generarGarantias("xlsx", itemActual, itemActualPreD);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reporteEXCELGarantiasConsolidado(PrePrestamos itemActual) {
		try {
			StreamedContent sc = generarGarantiasConsolidado("xlsx", itemActual);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reportePDFGarantiasConsolidado(PrePrestamos itemActual) {
		try {
			StreamedContent sc = generarGarantiasConsolidado("pdf", itemActual);
			return sc;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reporteEXCELGarantiasConsolidadoEntidad(CliPersona itemActual) {
		try {
			if (itemActual!= null && itemActual.getCliCodigo() != null) {

			StreamedContent sc = generarGarantiasConsolidadoEntidad("xlsx", itemActual);
			return sc;
			}
			return null;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent reportePDFGarantiasConsolidadoEntidad(CliPersona itemActual) {
		try {
			if (itemActual!= null && itemActual.getCliCodigo() != null) {
				StreamedContent sc = generarGarantiasConsolidadoEntidad("pdf", itemActual);
				return sc;
			}
			return null;
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
			return null;
		}
	}

	public StreamedContent generarGarantias(String tipoReporte, PrePrestamos itemActual, PreDesemb itemActualPreD) throws OperationException {
		StreamedContent sc = null;
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		String nombreReporte = "reporteGarantias";

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codusuario", usuario.getLogin());
		parametros.put("coddsb", itemActualPreD.getId());
		parametros.put("codcred", itemActual.getId().getPreCodcred());
		parametros.put("codmod", itemActual.getId().getPreCodmod());
		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte,nombreReporte + tipoReporte);
		return sc;
	}

	public StreamedContent generarGarantiasConsolidado(String tipoReporte, PrePrestamos itemActual) throws OperationException {
		if (!ValidaRangoFechas())	{
			return null;
		}

		String nombreReporte = "reporteGarantiasxCredito";

		if (fecha_ini != null && fecha_fin != null) {
			nombreReporte = "reporteGarantiasxCreditoyRango";
		}

		StreamedContent sc = null;
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codusuario", usuario.getLogin());
		parametros.put("codcred", itemActual.getId().getPreCodcred());
		parametros.put("codmod", itemActual.getId().getPreCodmod());
		parametros.put("fecha_ini", fecha_ini);
		parametros.put("fecha_fin", fecha_fin);

		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte,nombreReporte + tipoReporte);
		return sc;
	}
	public StreamedContent generarGarantiasConsolidadoEntidad(String tipoReporte, CliPersona Cliente) throws OperationException {
		if (!ValidaRangoFechas()) {
			return null;
		}
		StreamedContent sc = null;
		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
		String nombreReporte = "reporteGarantiasConsolidado";
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codusuario", usuario.getLogin());
		parametros.put("codcli", Cliente.getCliCodigo());
		parametros.put("fecha_ini", fecha_ini);
		parametros.put("fecha_fin", fecha_fin);
		sc = generadorReporte.obtenerStreamedContent(nombreReporte, parametros, tipoReporte,nombreReporte + tipoReporte);
		return sc;
	}

	public boolean ValidaRangoFechas() {
		if (fecha_ini == null && fecha_fin == null) {
			return true;
		}
		fecha_ini = fecha_ini == null ? fecha_fin : fecha_ini;
		if (fecha_ini != null && fecha_fin.before(fecha_ini)) {
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"La fecha de inicio debe ser anterior a la fecha fin", "");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return false;
		}
		return true;
	}
	public  void xx(){
		Log.Info(fecha_ini);
		Log.Info(fecha_fin);
	}

	public Date getMaxDate() {
		return maxDate;
	}
}
