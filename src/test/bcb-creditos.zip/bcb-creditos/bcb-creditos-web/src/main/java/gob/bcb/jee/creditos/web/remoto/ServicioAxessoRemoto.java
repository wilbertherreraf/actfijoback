package gob.bcb.jee.creditos.web.remoto;

import gob.bcb.jee.axesso.entidades.*;
import gob.bcb.jee.axesso.entidades.pojo.DatosAuditoria;
import gob.bcb.jee.axesso.excepciones.EntityValidationException;
import gob.bcb.jee.axesso.excepciones.OperationException;

import javax.ejb.Local;
import java.util.List;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.web.remoto
 * 06/07/2016 - 06:01 PM
 * Código base:
 * Creado por aescobar
 */
@Local
public interface ServicioAxessoRemoto {

    /**
     * @param usuarioId
     * @return
     * @throws Exception
     */
    Usuario getUsuario(Integer usuarioId) throws Exception;

    /**
     * @param login
     * @return
     * @throws Exception
     */
    Usuario getUsuarioByLogin(String login) throws Exception;

    /**
     * @param usuarioId
     * @return
     * @throws Exception
     */
    List<Rol> listRolesByUsuario(Integer usuarioId) throws Exception;

    /**
     * @param codRol
     * @return
     * @throws Exception
     */
    List<Recurso> listRecursosByRol(String codRol) throws Exception;

    /**
     * @param codRol
     * @param codRecurso
     * @return
     * @throws Exception
     */
    List<Permiso> listPermisosByRolAndRecurso(String codRol, String codRecurso) throws Exception;

    Participante getParticipanteByLoginUsuario(String loginUsuario) throws Exception;

    Password getPasswordByUsuarioAndPasseord(String loginUsuario, String passwordUsuario) throws Exception;

    void asignarPassword(Integer usuarioId, String password, DatosAuditoria datosAuditoria) throws EntityValidationException, OperationException;

    void registrarUsuario(Usuario entity, List<Rol> roles, boolean generarPassword, boolean email) throws EntityValidationException, OperationException;

    Agencia getAgencias(Integer usuarioId) throws OperationException;

    void modificarUsuario(Usuario entity, boolean email) throws EntityValidationException, OperationException;


    boolean isPasswordVigente(Integer usuarioId) throws OperationException;

    void lisUsuariosLike(String usuario) throws OperationException;
}
