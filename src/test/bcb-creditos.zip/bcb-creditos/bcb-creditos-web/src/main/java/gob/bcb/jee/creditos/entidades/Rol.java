package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * Entidad Recurso
 *
 * @author ysalinas
 * Modificado: aescobar
 */
@Getter
@Setter
public class Rol implements Serializable {

    private static final long serialVersionUID = -2497179242891965525L;

    public static final String ENTITY = "Rol";

    private String codigo;

    private String descripcion;

    private List<Recurso> recursos;


    public Rol() {
    }

    public Rol(String codigo, String descripcion, List<Recurso> recursos) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.recursos = recursos;
    }

    @Override
    public String toString() {
        return "Rol{" +
                "codRecurso='" + codigo + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", recursos=" + recursos +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Rol)) return false;

        Rol rol = (Rol) o;

        if (codigo != null ? !codigo.equals(rol.codigo) : rol.codigo != null) return false;
        if (descripcion != null ? !descripcion.equals(rol.descripcion) : rol.descripcion != null) return false;
        if (recursos != null ? !recursos.equals(rol.recursos) : rol.recursos != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = codigo != null ? codigo.hashCode() : 0;
        result = 31 * result + (descripcion != null ? descripcion.hashCode() : 0);
        result = 31 * result + (recursos != null ? recursos.hashCode() : 0);
        return result;
    }
}
