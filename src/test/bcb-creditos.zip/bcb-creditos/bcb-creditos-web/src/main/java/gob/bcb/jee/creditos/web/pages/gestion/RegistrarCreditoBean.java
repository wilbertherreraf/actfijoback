package gob.bcb.jee.creditos.web.pages.gestion;


import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.inject.Inject;

import org.primefaces.event.SelectEvent;

import gob.bcb.jee.creditos.BL.ArticuloBLLocal;
import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.BL.GenModuloBLLocal;
import gob.bcb.jee.creditos.BL.GenMonedaBLLocal;
import gob.bcb.jee.creditos.BL.GenTipProductoBLLocal;
import gob.bcb.jee.creditos.BL.PrePrestamosBLLocal;
import gob.bcb.jee.creditos.BL.PreTasaspreBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenModulo;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PrePrestamosPK;
import gob.bcb.jee.creditos.model.PreTasaspre;
import gob.bcb.jee.creditos.model.PreTasasprePK;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "RegistrarCreditoBean")
@ViewScoped
@Getter
@Setter
public class RegistrarCreditoBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    
    @Inject
    private GenTipProductoBLLocal genTipProductoBLLocal;
    
    @Inject
    private GenDesctablaBLLocal genDesctablaBLLocal;
    
    @Inject
    private GenMonedaBLLocal genMonedaBLLocal;
    
    @Inject
    private PrePrestamosBLLocal prePrestamosBLLocal;
    
    @Inject
    private GenModuloBLLocal genModuloBLLocal;
    
    @Inject
    private CliPersonaBLLocal service;
    
    @Inject
    private ArticuloBLLocal articuloBLLocal;
    @Inject
    private PreTasaspreBLLocal preTasaspreBLLocal;

    private List<CliPersona> products;
    
    private PrePrestamos prePrestamos=new PrePrestamos();
    private Double plazo;
    private Double gracia=0.0;
    private Double graciaint=0.0;
    
    private boolean habilitadoCampos=true;
    private CliPersona cliPersona= new CliPersona();
    private String cliente;
    private List<GenTipproducto> listGenTipproductos;
    private List<GenMoneda> listGenMoneda;
    private List<GenDesctabla> listGenDesctablaPlazo;     
    private List<GenModulo> listGenModulo;   
    private List<Object[]>  listLeyes =new ArrayList<>();
    private Integer base;
    private List<Object[]> selectedLeyes;
    private List<String> listSeleccionados= new ArrayList<String>();
    private List<SelectItem> listLeyesSelect = new ArrayList<SelectItem>();
//    private List<GenDesctabla> listGenDesctablaRubro;   
//    private List<GenDesctabla> listGenDesctablaDestino;
    private List<GenDesctabla> listGenDesctablaCapitalizacion;

	private List<PrePrestamos> listarCreditos;

    public RegistrarCreditoBean() {
    }

    @PostConstruct
    public void init() throws OperationException {

		listarCreditos=prePrestamosBLLocal.list();
		// Ordenar la lista de manera descendente por preCodcred
		listarCreditos.sort(Comparator.comparing(
				prePrestamo -> prePrestamo.getPrePrestamosPK().getPreCodcred(),
				Comparator.reverseOrder()
		));
    	buscarClientes();
    }
    public void buscarClientes() {
    	try{
    		products = service.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
    	
    	}
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);	
		}
    }
 
    
    public void iniciar()  {
    	try {    		    		
    		prePrestamos=new PrePrestamos();
    		prePrestamos.setPreDiasfijoper(0);
    		prePrestamos.setPrePrestamosPK(new PrePrestamosPK());
    		Map<String,Object> valores=new HashMap<>();
//    		valores.put("valor1", 160);
//    		listGenDesctablaRubro=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
//    		valores.replace("valor1", 1750);
//    		listGenDesctablaDestino =genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores); 
    		valores.replace("valor1", 1704);
    		listGenModulo=genModuloBLLocal.list();
    		listGenMoneda =genMonedaBLLocal.list();
    		valores.put("valor1", 1703);
    		listGenDesctablaPlazo=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
    		listGenDesctablaPlazo=listGenDesctablaPlazo.stream().sorted((x,y)->x.getDesDescrip().compareTo(y.getDesDescrip())).collect(Collectors.toList());
    		
    		valores.put("valor1", 413);
    		listGenDesctablaCapitalizacion=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
    		//adicionamos leyes
    		listSeleccionados.clear();
    		listLeyes= articuloBLLocal.obtenerLeyesRelacionadas(cliPersona.getId());
    		listLeyesSelect.clear();;
    		for (Object[] to : listLeyes)
    	    {
    			listLeyesSelect.add(new SelectItem(to[0], to[1].toString()+" Art."+ to[7]+ ", Saldo:"+new DecimalFormat("#,###.00").format(to[4] )) );
    	    }
    		
    	}
    	catch ( Exception e ) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}    	
    }
    public boolean validarMonto(BigDecimal monto) {
    	BigDecimal big=BigDecimal.ZERO;
    	for( Object []obj: listLeyes) {
    		String []vec=listSeleccionados.stream().collect(Collectors.joining(",")).split(",");
    		for(String v:vec) {
    			if(obj[0].toString().equals(v)) {
    				big=big.add(new  BigDecimal(obj[4].toString()));
        		}
    		}
    	}
    	if(monto.compareTo(big)<=0) {
    		return true;
    	}
    	return false;
    }
    public void generarPrestamo() {
    	try {
    		
    		if(listSeleccionados.size()==0) {
    			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Datos incompleto", "Debe Seleccionar al menos una ley");
    		    FacesContext.getCurrentInstance().addMessage(null, message);
    			return;
    		}
    		if(!validarMonto(prePrestamos.getPreMonto())) {
    			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "No puede superar el monto de la ley");
    		    FacesContext.getCurrentInstance().addMessage(null, message);
    		    return;
    		}
    		
    		
    		Log.Info(listSeleccionados.size());
	    	int id =prePrestamosBLLocal.getIdByModulo(prePrestamos.getId().getPreCodmod());
	    	Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
	    	//PrePrestamosPK prePrestamosPK=new PrePrestamosPK();
	    	//prePrestamosPK.setPreCodcred(id);
	    	//prePrestamos.setPrePrestamosPK(prePrestamosPK);
	    	prePrestamos.getPrePrestamosPK().setPreCodcred(id);
	    	prePrestamos.setPreCodcli(cliPersona.getCliCodigo());
	    	prePrestamos.setPreFecreg(new Date());
	    	prePrestamos.setPreTabtiprubro(160);
	    	prePrestamos.setPreTabdestcred(1750);
	    	prePrestamos.setPreTabstatus(1704);
	    	prePrestamos.setPreNumconv(listSeleccionados.stream().collect(Collectors.joining(",")));
	    	prePrestamos.setPreTabmethodcapi(413);
	    	prePrestamos.setPreTabunidplaz(1703);
	    	prePrestamos.setPreStatus(1);
	    	prePrestamos.setPreStatreg(0);
	    	prePrestamos.setPreTabstatreg(13);
	    	prePrestamos.setPreTabtrxstaau(30);
	    	prePrestamos.setPreTrxstaau(1);
	    	prePrestamos.setPreSaldo(BigDecimal.ZERO);
	    	prePrestamos.setPreMonliqent(BigDecimal.ZERO);
	    	prePrestamos.setPreAuditusr(usuario.getLogin());
	    	prePrestamos.setPreAuditfho(new Timestamp(new Date().getTime()));
	    	prePrestamos.setPreAuditwst(UtilWeb.getIPRemoto());
	    	prePrestamos.setPreEstadoParametros(1);
	    	int valor=prePrestamosBLLocal.getValorPeriodicidad(prePrestamos.getPreUnidplaz());
	    	
	    	prePrestamos.setPreNroperiodos((int)((double)valor*plazo));
	    	prePrestamos.setPreNrogracia((int)((double)valor*gracia));
	    	prePrestamos.setPreNrograciaint((int)((double)valor*graciaint));
	    	
	    	int numeroPagos=(prePrestamos.getPreNroperiodos())-prePrestamos.getPreNrogracia();
	    	prePrestamos.setPreNropagos(numeroPagos);	    	
			prePrestamosBLLocal.persist(prePrestamos, usuario.getLogin());
			
			PreTasaspre preTasaspre=new PreTasaspre();
			preTasaspre.setId(new PreTasasprePK(prePrestamos.getId().getPreCodcred(),prePrestamos.getId().getPreCodmod(),prePrestamos.getPreFecemi()));
			preTasaspre.setMtpTbase(prePrestamos.getPreTasapac());
			preTasaspre.setMtpTspread(0.0);
			preTasaspre.setMtpIntydias(this.base);
			preTasaspre.setMtpTabintmdias(20);
			preTasaspre.setMtpIntmdias(1);			
			preTasaspre.setMtpTabintydias(21);
    		preTasaspre.setMtpTabtrxstaau(30);
    		preTasaspre.setMtpTrxstaau(1);
    		preTasaspre.setMtpAuditusr(usuario.getLogin());
    		preTasaspre.setMtpAuditfho(new Timestamp(new Date().getTime()));
    		preTasaspre.setMtpAuditwst(UtilWeb.getIPRemoto());
    		
			preTasaspreBLLocal.persist(preTasaspre, usuario.getLogin());
			Log.Info("Registro guardado:"+prePrestamos.toString());
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente", "Pendiente de autorizar");
	    FacesContext.getCurrentInstance().addMessage(null, message);
	    limpiar();
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		} 
    	
    }
    
    private boolean mostrarDiasIregular=true;
public void seleccionarPlazoCapital(SelectEvent id_mod) {		
		int id=Integer.parseInt(id_mod.getObject().toString());
		if(id==1)
			this.mostrarDiasIregular=false;
		else 
			this.mostrarDiasIregular=true;
    	 
	}

    public void selectCliPersonaFromDialog(CliPersona product) {    
    	try {
      //  cliPersona =  product;
        cliente=cliPersona.getCliNombre();
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Beneficiario seleccionado", "Nombre:" + cliPersona.getCliNombre());
		FacesContext.getCurrentInstance().addMessage(null, message);
		iniciar();
		habilitadoCampos=false;
    	}
    	 catch (Exception e) {
 			Log.Error(e);
 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
 		    FacesContext.getCurrentInstance().addMessage(null, message);
 			
 		} 
     	
    }
    
  
    
    public void  actualizarTipoProducto(SelectEvent id_mod) {
    	try {
    		int id=Integer.parseInt(id_mod.getObject().toString());
    		//genTipproducto=new GenTipproducto();
    		Map<String,Object> valores=new HashMap<>();
    		valores.put("valor1", id);
    		listGenTipproductos=genTipProductoBLLocal.listByNamedQuery(GenTipproducto.NQ_GET_BY_ID_MOD,valores);    		
        	}
        	 catch (Exception e) {
     			Log.Error(e);
     			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
     		    FacesContext.getCurrentInstance().addMessage(null, message);
     			
     		} 
    }
    
    public void limpiar() {
    	listSeleccionados.clear();
    	cliPersona =  new CliPersona();
        cliente="";
        prePrestamos=new PrePrestamos();
        prePrestamos.setPrePrestamosPK(new PrePrestamosPK());
        habilitadoCampos=true;
        listGenTipproductos=null;	
//		listGenDesctablaRubro=null;		
//		listGenDesctablaDestino =null; 			
		listGenMoneda =null;
    }

    public String obtenerInstitucion(Integer institucion) throws OperationException {

		return service.obtenerInstitucion(institucion);
	}

	public String obtenerValorMatrizParamteros(Integer codcred, Integer parametro) throws OperationException {
		return prePrestamosBLLocal.obtenerValorMatrizParametro(codcred, parametro);
	}


	public void preAutorizarParametros(PrePrestamos itemActual) {
		try {

			Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActual.setPreAuditusr(usuario.getLogin());
			itemActual.setPreAuditfho(new Timestamp(new Date().getTime()));
			itemActual.setPreAuditwst(UtilWeb.getIPRemoto());
			itemActual.setPreEstadoParametros(2);

			prePrestamosBLLocal.merge(itemActual, usuario.getLogin());
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro preautorizado satisfactoriamente","" );
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}

	public void autorizarParametros(PrePrestamos itemActual) {
		try {

			Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
			itemActual.setPreAuditusr(usuario.getLogin());
			itemActual.setPreAuditfho(new Timestamp(new Date().getTime()));
			itemActual.setPreAuditwst(UtilWeb.getIPRemoto());
			itemActual.setPreEstadoParametros(3);

			prePrestamosBLLocal.merge(itemActual, usuario.getLogin());

			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro autorizado satisfactoriamente","" );
			FacesContext.getCurrentInstance().addMessage(null, message);
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error",UtilWeb.getErrorCause(e));
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}


}
