package gob.bcb.jee.creditos.web.util;

import java.util.Enumeration;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpSession;

import gob.bcb.jee.creditos.util.Log;



/**
 * Clase que permite el limpiar el cache de los objeto que fueron cargados a
 * session
 * 
 * @author ysalinas
 * 
 */ 
public class UtilesLocales
{
 
  /**
   * Metodo que realiza la limpieza de ManagedBean que fueron creados del tipo
   * Session que llevan el sufijo Bean
   * 
   * @param session
   */
  public static void limpiarCache(HttpSession session)
  {
    if (session != null)
    {
      Enumeration<String> e = session.getAttributeNames();

      String objeto = "";
      while (e.hasMoreElements())
      {
        objeto = e.nextElement();
        if (objeto != null && objeto.contains("Bean"))
        {
        	Log.Info("Removiendo objeto: " + objeto);
          session.removeAttribute(objeto);
        }

      }
    }
  }

  /**
   * Funcion que Crea un Mensaje del lado del cliente que sera mostrado en un
   * componente Growl o Messages
   * 
   * 
   * @param String
   *          strMsg
   * @param String
   *          srtTitle
   * @param boolean sinErrores
   */
  public static void CrearMsgWARN(String strMsg, String srtTitle,
      boolean sinErrores)
  {
    FacesMessage message = null;
    message = new FacesMessage(FacesMessage.SEVERITY_WARN, srtTitle, strMsg);
    FacesContext.getCurrentInstance().addMessage(null, message);
    CrearVariableJavascript("sinErrores", sinErrores);
  }

  /**
   * Funcion que Crea una Variable javascript para el lado del cliente
   * 
   * @author flinares
   * 
   * @param String
   *          nomVariable
   * @param Object
   *          Valor
   */
  public static void CrearVariableJavascript(String nomVariable, Object Valor)
  {
    //RequestContext context = RequestContext.getCurrentInstance();
   // context.addCallbackParam(nomVariable, Valor);
  }

  /**
   * Metodo que realiza la obtencion de una parametro del archivo
   * resources.properties
   * 
   * @param keyParametro
   * @return
   */
  public static String obtenerParametro(String keyParametro)
  {
    String valorParametro = "";

    try
    {
      FacesContext facesContext = FacesContext.getCurrentInstance();

      // recupernado parametro de resources
      ResourceBundle bundle = facesContext.getApplication().getResourceBundle(facesContext, "msgs");

      // verificadno si el sistema se logeara usando captcha
      if (bundle != null && bundle.getString(keyParametro) != null)
      {
        valorParametro = bundle.getString(keyParametro);
      }
    }
    catch (Exception e)
    {
      Log.Error("Error al obtener el parametro"+ e);
    }

    return valorParametro;
  }

  @SuppressWarnings("unchecked")
  public static <Ejb> Ejb consumirEJBSeguridad(Class<Ejb> ejbRemoto)
  {
    try
    {
      Properties props = new Properties();
      props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
      InitialContext ctx = new InitialContext(props);
      String appName = "bcb-seguridad-ear";
      String moduleName = "bcb-seguridad-ejb-1.0-SNAPSHOT";
      String distinctName = "";
      String beanName = ejbRemoto.getSimpleName().substring(0, ejbRemoto.getSimpleName().length() - 6);
      String remoteBeanName = ejbRemoto.getName();
      String jndi = "ejb:" + appName + "/" + moduleName + "/" + distinctName + "/" + beanName + "!" + remoteBeanName;
      Ejb ejb = (Ejb) ctx.lookup(jndi);
      return ejb;
    }
    catch (Exception e)
    {
      Log.Error("Error consumo de EJB de seguridad"+ e);
    }
    return null;
  }
}
