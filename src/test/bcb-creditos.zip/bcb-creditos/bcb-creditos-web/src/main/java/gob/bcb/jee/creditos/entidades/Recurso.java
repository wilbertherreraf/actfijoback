/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-plantillaWebEE-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.entities.Recurso
 * 06/04/2015 - 08:30:00
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import gob.bcb.jee.creditos.numeradores.CodRecurso;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Entidad Recurso
 *
 * @author ysalinas
 */
@Getter
@Setter
public class Recurso implements Serializable {

    private static final long serialVersionUID = -978526394511936514L;

    public static final String ENTITY = "Recurso";

    private String padre;

    private String codRecurso;

    private List<Recurso> subRecursos = new ArrayList<Recurso>();

    // @Column(name = "ORDER")
    private Integer order;

    // @Column(name = "NOMBRE", length = 30, nullable = false)
    private String nombre;

    // @Column(name = "DESCRIPCION", length = 255)
    private String descripcion;

    // @Column(name = "URL", length = 150)
    private String[] url;

    private boolean visible;

    private List<Permiso> permisos;

    private String estado;

    public Recurso(String padre, CodRecurso codRecurso,
                   String descripcion) {
        super();
        this.padre = padre;
        this.codRecurso = codRecurso.getCodigoRecurso();
        this.nombre = codRecurso.getTextMenu();
        this.descripcion = descripcion;
        this.url = codRecurso.getUrl();
        this.order = codRecurso.getOrder();
        this.visible = codRecurso.getVisible();
    }

    /**
     * @param codRecurso
     * @param descripcion
     */
    public Recurso(CodRecurso codRecurso, String descripcion) {
        this(null, codRecurso, descripcion);
    }

    public Recurso() {
    }

    @Override
    public String toString() {
        return "Recurso{" +
                ", padre=" + padre +
                ", codRecurso='" + codRecurso + '\'' +
                ", subRecursos=" + subRecursos +
                ", order=" + order +
                ", nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", url='" + url + '\'' +
                ", visible=" + visible +
                ", permisos=" + permisos +
                ", estado=" + estado +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Recurso)) return false;

        Recurso recurso = (Recurso) o;

        if (visible != recurso.visible) return false;
        if (estado != recurso.estado) return false;
        if (padre != null ? !padre.equals(recurso.padre) : recurso.padre != null) return false;
        if (codRecurso != null ? !codRecurso.equals(recurso.codRecurso) : recurso.codRecurso != null) return false;
        if (subRecursos != null ? !subRecursos.equals(recurso.subRecursos) : recurso.subRecursos != null) return false;
        if (order != null ? !order.equals(recurso.order) : recurso.order != null) return false;
        if (nombre != null ? !nombre.equals(recurso.nombre) : recurso.nombre != null) return false;
        if (descripcion != null ? !descripcion.equals(recurso.descripcion) : recurso.descripcion != null) return false;
        if (url != null ? !url.equals(recurso.url) : recurso.url != null) return false;
        return !(permisos != null ? !permisos.equals(recurso.permisos) : recurso.permisos != null);

    }

    @Override
    public int hashCode() {
        int result = padre != null ? padre.hashCode() : 0;
        result = 31 * result + (codRecurso != null ? codRecurso.hashCode() : 0);
        result = 31 * result + (subRecursos != null ? subRecursos.hashCode() : 0);
        result = 31 * result + (order != null ? order.hashCode() : 0);
        result = 31 * result + (nombre != null ? nombre.hashCode() : 0);
        result = 31 * result + (descripcion != null ? descripcion.hashCode() : 0);
        result = 31 * result + (url != null ? url.hashCode() : 0);
        result = 31 * result + (visible ? 1 : 0);
        result = 31 * result + (permisos != null ? permisos.hashCode() : 0);
        result = 31 * result + (estado != null ? estado.hashCode() : 0);
        return result;
    }

   /* public boolean isAdministracion() {
        return administracion;
    }*/

    public boolean isEjecucion() {
        return existePermiso(TipoPermiso.AUT);
    }

    public boolean isPreAutroizacion() {
        return existePermiso(TipoPermiso.PAU);
    }

    public boolean isModificacion() {
        return existePermiso(TipoPermiso.MOD);
    }

    public boolean isAlta() {
        return existePermiso(TipoPermiso.ALT);
    }

    public boolean isLectura() {
        return existePermiso(TipoPermiso.LEC);
    }


    private boolean existePermiso(TipoPermiso tipoPermiso){
       // return true;
        for(Permiso permiso : permisos){
            if(permiso.getCodPermiso().equals(String.valueOf(tipoPermiso))){
                return true;
            }
        }
        return false;
    }
}
