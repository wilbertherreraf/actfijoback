/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-plantillaWebEE-web
 * gob.bcb.jee.creditos.plantillaWebEE.comunes.web.ApplicationBean
 * 26/11/2016 - 08:30:00
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.core.comunes.webManage;
import gob.bcb.jee.creditos.entidades.Entidad;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpSession;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Clase utilizada para instanciar las listas de objetos comunes para toda la
 * aplicacion
 *
 * @author ysalianas
 */
@SuppressWarnings("serial")
@ManagedBean
@Getter
@Setter
@ApplicationScoped
public final class ApplicationBean implements Serializable {

   
    private SimpleDateFormat sdfFecha = new SimpleDateFormat(CttesWeb.DATE_FORMAT);

    private Properties titulosProperties;
    private Properties mensajesProperties;

    private String patternDate = Entidad.FORMAT_DATE;

    private String patternTime = Entidad.FORMAT_TIME;

    private String patternDateTime = Entidad.FORMAT_DATE_TIME;

    private Integer sessionTimeOut = 0;

    private String codParticipante = "0";

    private Map<String, String> paramsSistema;


    /**
     * Metodo que se ejecuta despues del constructor inicializando las listas de
     * los objetos comunes (monedas, ciudades, etc.)
     */
    @PostConstruct
    public void iniciar() {
        Log.Info("Iniciando applicationBean");
        // obtiene valor de session timeout del web.xml
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance()
                .getExternalContext().getSession(true);
        sessionTimeOut = session.getMaxInactiveInterval();

        titulosProperties = new UtilWeb().cargarPropiedades("titulos.properties");
        mensajesProperties = new UtilWeb().cargarPropiedades("mensajes.properties");
        if (titulosProperties.isEmpty()) {
            Log.Warn("Titulos es vacio");
        }
        if (mensajesProperties.isEmpty()) {
            Log.Warn("Mensajes esta vacio");
        }

    }

    @PreDestroy
    public void finalizar() {
        Log.Info("Finalizando applicationBean");
    }

    @Setter(AccessLevel.NONE)
    private SelectItem[] filtroEstados = {
            new SelectItem(null, "TODOS"),
            new SelectItem(Estado.A.toString(), Estado.A.toString()),
            new SelectItem(Estado.P.toString(), Estado.P.toString()),
            new SelectItem(Estado.S.toString(), Estado.S.toString()),
            new SelectItem(Estado.C.toString(), Estado.C.toString())
    };



}
