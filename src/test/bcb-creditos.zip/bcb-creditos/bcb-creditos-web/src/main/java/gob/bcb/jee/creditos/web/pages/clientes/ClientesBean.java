package gob.bcb.jee.creditos.web.pages.clientes;


import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.BL.GenDesctablaBLLocal;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenDesctablaPK;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;


import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "ClientesBean")
@ViewScoped
@Getter
@Setter
public class ClientesBean  implements Serializable {

    private static final long serialVersionUID = 1L;
  
    @Inject
    private GenDesctablaBLLocal genDesctablaBLLocal;    
    
    @Inject
    private CliPersonaBLLocal cliPersonaBLLocal;

    private List<CliPersona> listCliPersonas;
    
    private CliPersona cliPersona= new CliPersona();
    
    private List<GenDesctabla> listGenDesctablaTipoIden;
    
    private List<GenDesctabla> listGenDesctablaTipoPer;
    
    private List<GenDesctabla> listGenDesctablaEstado;
    
    public ClientesBean() {
    }

    @PostConstruct
    public void init() {     
    	try {
    		listCliPersonas=cliPersonaBLLocal.list();
		}
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}     	
    }
   
    public void iniciarNuevo() {
    	try {
    	cliPersona= new CliPersona();
    	Map<String,Object> valores=new HashMap<>();
		valores.put("valor1", 104);
		listGenDesctablaTipoIden=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
		valores.put("valor1", 101);
		listGenDesctablaTipoPer=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
		valores.put("valor1", 177);
		listGenDesctablaEstado=genDesctablaBLLocal.listByNamedQuery(GenDesctabla.NQ_LIST_BY_CODTAB, valores);
		
    	}
    	catch(Exception e)
    	{
    		Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
    	}
    	
    }
      
    public String getDescTabla(Integer codtab,Integer cod) {
    	try {
    		if(codtab!=0 && cod!=0) {
    			GenDesctablaPK pk=new GenDesctablaPK();
    	    	pk.setDesCodtab(codtab);
    	    	pk.setDesCodigo(cod); 			    
    				String valor=genDesctablaBLLocal.get(pk).getDesDescrip();
    				return valor;
    		}
    	
		} catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);		
		}
    	return "";
    }
    
   
    public void guardar() {
    	try {
    		cliPersona.setCliTabtipiden(104);	
    		cliPersona.setCliTabtipper(101);
    		cliPersona.setCliTabstatus(177);
    		cliPersona.setCliFeching(new Date());
    		cliPersona.setCliTabtrxstaau(30);
    		cliPersona.setCliTrxstaau(1);
    		Usuario usuario=(Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
	    	if(cliPersona.getCliCodigo()==null) {
	    		int codigo=cliPersonaBLLocal.getIdNewId();
	    		cliPersona.setCliCodigo(codigo);	    		
	    		cliPersonaBLLocal.persist(cliPersona, usuario.getLogin());	    		
	    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro guardado satisfactoriamente","");
	    	    FacesContext.getCurrentInstance().addMessage(null, message);
	    	}
	    	else {
	    		cliPersonaBLLocal.merge(cliPersona, usuario.getLogin());
	    		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro modificado satisfactoriamente","");
	    	    FacesContext.getCurrentInstance().addMessage(null, message);
	    	}
	    	Log.Info("Registro guardado:"+cliPersona.getCliCodigo());
				
	    limpiar();
	    init();
		}  catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		} 
    	
    	
    }
//    public void selectCliPersona(CliPersona product) {    
//    	try {
//        cliPersona =  product;
//        cliente=cliPersona.getCliCodigo()+"-"+cliPersona.getCliNombre();
//       
//        Map<String,Object> valores=new HashMap<>();
//		valores.put("valor1", cliPersona.getCliCodigo());
//    	listPrePrestamos=prePrestamosBLLocal.listByNamedQuery(PrePrestamos.NQ_GET_BY_CLIENTE, valores);
//    	}
//    	 catch (Exception e) {
// 			Log.Error(e);
// 			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage());
// 		    FacesContext.getCurrentInstance().addMessage(null, message);
// 			
// 		} 
//     	
//    }
    
  
    public void limpiar() {
    	cliPersona =  new CliPersona();        
        listGenDesctablaTipoIden=null;	
        listGenDesctablaTipoPer=null;		
        listGenDesctablaEstado =null; 					
    }
}
