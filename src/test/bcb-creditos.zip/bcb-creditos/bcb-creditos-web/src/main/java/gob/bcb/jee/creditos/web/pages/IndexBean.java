package gob.bcb.jee.creditos.web.pages;


import gob.bcb.jee.creditos.core.comunes.webManage.SessionBean;
import gob.bcb.jee.creditos.entidades.Permiso;
import gob.bcb.jee.creditos.entidades.Recurso;
import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.ContextActions;
import gob.bcb.jee.creditos.web.util.CttesWeb;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "indexBean")
@ViewScoped
@Getter
@Setter
public class IndexBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private Date diaActual;


    // Pagina principal
    private String paginaPrincipal;
    /**
     * objeto de primefaces para la creacion de menus jerarquicos
     */
    private MenuModel menuModel;
    /**
     * objeto que controla las sesiones en la aplicacion
     */
    @ManagedProperty(value = "#{sessionBean}")
    protected SessionBean sessionBean;


 
    /**
     * Constructor por defecto
     */
    public IndexBean() {
    }

    /**
     * Procedimiento de inicializacion posterior a la instanciacion del objeto.
     */
    @PostConstruct
    public void init() {
        Log.Trace("Iniciando " + IndexBean.class.getSimpleName() + "... ");
        this.createMenu();
        diaActual = new Date();
        HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        String queryStringError = req.getParameter("e");
        if (queryStringError != null) {
            sessionBean.mensajeExcepcion = "Error al iniciar sesion en Axesso. Contáctese con su Administrador";
            ContextActions.primeContext("PF('dlgAvisoExcepcion').show();");
        }
        //pagoProximoSelected = new PagoProximo();
       // cargarDatos();
        Log.Trace(IndexBean.class.getSimpleName() + " iniciado.");
    }

  

  

    private List<Recurso> unificarRecursos(List<Recurso> recursos) {
        List<Recurso> recursosUnificados = new ArrayList<Recurso>();
        for (Recurso recurso : recursos) {
            int ind = recursoExiste(recursosUnificados, recurso);
            if (ind == -1) {
                recursosUnificados.add(recurso);
            } else {
                recursosUnificados.get(ind).setPermisos(unificarPermisos(recursosUnificados.get(ind).getPermisos(), recurso.getPermisos()));
                recursosUnificados.get(ind).setSubRecursos(unificarSubrecursos(recursosUnificados.get(ind).getSubRecursos(), recurso.getSubRecursos()));
            }
        }
        return recursosUnificados;
    }

    private Integer recursoExiste(List<Recurso> recursos, Recurso recursoBusqueda) {
        for (int i = 0; i < recursos.size(); i++) {
            if (recursos.get(i).getCodRecurso().equals(recursoBusqueda.getCodRecurso()))
                return i;
        }
        return -1;
    }

    private List<Permiso> unificarPermisos(List<Permiso> actual, List<Permiso> nuevo) {
        List<Permiso> permisos = new ArrayList<Permiso>();
        if(actual != null)
            permisos.addAll(actual);
        boolean existePermiso;
        for (Permiso permisoNuevo : nuevo) {
            existePermiso = false;
            for (Permiso permisoActual : actual) {
                if (permisoActual.getCodPermiso().equals(permisoNuevo.getCodPermiso())) {
                    existePermiso = true;
                    break;
                }
            }
            if (!existePermiso) {
                permisos.add(permisoNuevo);
            }
        }
        return permisos;
    }

    private List<Recurso> unificarSubrecursos(List<Recurso> actual, List<Recurso> nuevo) {
        List<Recurso> subRecursos = new ArrayList<Recurso>();
        if (actual != null)
            subRecursos.addAll(actual);
        boolean existeRecurso;
        for (Recurso recursoNuevo : nuevo) {
            existeRecurso = false;
            for (Recurso recursoActual : actual) {
                if (recursoActual.getCodRecurso().equals(recursoNuevo.getCodRecurso())) {
                    existeRecurso = true;
                    break;
                }
            }
            //if (!existeRecurso) {
                subRecursos.add(recursoNuevo);
            //}
        }
        return subRecursos;
    }

    /**
     * Metodo que realiza la creacion dinamica del menu
     */
    public void createMenu() {
        try {
            menuModel = new DefaultMenuModel();
            Usuario usuario = (Usuario) UtilWeb.getVariableSession(CttesWeb.VariablesSesion.USUARIO);
            if (usuario != null) {
                DefaultSubMenu submenu;
                DefaultMenuItem item;

                HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
                String url = req.getRequestURL().toString();
                url = url.subSequence(0, url.length() - req.getRequestURI().length()) + req.getContextPath() + "/";
                String baseUrl = url + "pages/";
                List<Recurso> recursos = usuario.getRecursos();
                recursos = unificarRecursos(recursos);
                recursos=recursos.stream().sorted((x,y)->y.getOrder().compareTo(x.getOrder())).collect(Collectors.toList());
                for (Recurso recurso : recursos) {
                    if (recurso.getEstado().equals(CttesWeb.AXESSO_ESTADO_REGISTRO_VIGENTE)) {
                        if (recurso.getPadre() != null) {
                            item = new DefaultMenuItem();
                            item.setValue(recurso.getNombre());
                            item.setUrl(baseUrl + recurso.getUrl()[0]);
                            item.setId(recurso.getCodRecurso() + "");
                            item.setIcon("");
//                            Log.Info("EL ITEM ES : " + item);
                            menuModel.getElements().add(item);
                        } else {
                            submenu = new DefaultSubMenu();
                            submenu.setLabel(recurso.getNombre());
                            submenu.setId(recurso.getCodRecurso() + "");
                            submenu.setIcon("");
                            List<Recurso> subRecursos = recurso.getSubRecursos();
                            subRecursos=subRecursos.stream().sorted((x,y)->x.getOrder().compareTo(y.getOrder())).collect(Collectors.toList());
                            //Collections.sort(subRecursos);
                            for (final Recurso recursoHijo : subRecursos) {
                                //Log.Info("EL RECURSO HIJO ES : : " + recursoHijo.getUrl());
                                if (recursoHijo.isVisible()) {
                                    item = new DefaultMenuItem();
                                    item.setValue(recursoHijo.getNombre());
                                    item.setUrl(baseUrl + recurso.getUrl()[0] + "/" + recursoHijo.getUrl()[0]);
                                    item.setId(recursoHijo.getCodRecurso() + "");
                                    item.setIcon("");
                                    submenu.getElements().add(item);
                                }

                            }
                            menuModel.getElements().add(submenu);

                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.Error("Ha ocurrido algun error en la generación del menú"+ e);
            ContextActions.sendError("Ha existido algun error en la generación del menú");
        }

    }
}
