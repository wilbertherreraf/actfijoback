package gob.bcb.jee.creditos.web.pages.clientes;


import gob.bcb.jee.creditos.BL.CliPersonaBLLocal;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.web.util.UtilWeb;
import lombok.Getter;
import lombok.Setter;


import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;

import java.io.Serializable;
import java.util.List;

/**
 * Managed Bean de la vista principal (index)
 */
@ManagedBean(name = "ModalClientesBean")
@ViewScoped
@Getter
@Setter
public class ModalClientesBean  implements Serializable {

    private static final long serialVersionUID = 1L;
  
    @Inject
    private CliPersonaBLLocal cliPersonaBLLocal;

    private List<CliPersona> listCliPersonas;
    
    private CliPersona cliPersona= new CliPersona();
    

    @PostConstruct
    public void init() {     
    	try {    		
    		listCliPersonas = cliPersonaBLLocal.listByNamedQuery(CliPersona.NQ_LIST_VIGENTES);
		}
    	
    	catch (Exception e) {
			Log.Error(e);
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", UtilWeb.getErrorCause(e));
		    FacesContext.getCurrentInstance().addMessage(null, message);
			
		}     	
    }
    
    public void view(CliPersona cli) {    
   		
       PrimeFaces.current().dialog().closeDynamic(cli);
     	
    }
//    	
//    	public void handleReturn(SelectEvent event) {
//    		CliPersona cli = (CliPersona) event.getObject();
//    	}
   
  
}
