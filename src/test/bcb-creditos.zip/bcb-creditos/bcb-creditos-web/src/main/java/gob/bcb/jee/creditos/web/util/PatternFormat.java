package gob.bcb.jee.creditos.web.util;

import lombok.Getter;

import javax.faces.bean.ManagedBean;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.web.util
 * 31/08/2016 - 09:50 AM
 * Creado por aescobar
 */
@ManagedBean(name = "patternFormat")
@Getter
public class PatternFormat {

    private final String FORMAT_DECIMAL_UNO = "#,###,##0.0";
    private final String FORMAT_DECIMAL_DOS = "#,###,##0.00";
    private final String FORMAT_ENTERO = "#,##0";

}
