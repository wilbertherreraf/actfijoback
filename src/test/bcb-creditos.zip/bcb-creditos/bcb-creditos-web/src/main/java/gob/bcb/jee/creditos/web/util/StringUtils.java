/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package gob.bcb.jee.creditos.web.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

/**
 * Converts String to and from bytes using the encodings required by the Java
 * specification. These encodings are specified in <a href=
 * "http://download.oracle.com/javase/1.5.0/docs/api/java/nio/charset/Charset.html"
 * >Standard charsets</a>
 *
 * @see <a
 *      href="http://download.oracle.com/javase/1.5.0/docs/api/java/nio/charset/Charset.html">Standard
 *      charsets</a>
 * @author <a href="mailto:ggregory@seagullsw.com">Gary Gregory</a>
 * @version $Id$
 * @since 1.4
 */
public class StringUtils
{
  /**
   * Encodes the given string into a sequence of bytes using the UTF-8 charset,
   * storing the result into a new byte array.
   *
   * @param string
   *          the String to encode, may be <code>null</code>
   * @return encoded bytes, or <code>null</code> if the input string was
   *         <code>null</code>
   * @throws IllegalStateException
   *           Thrown when the charset is missing, which should be never
   *           according the the Java specification.
   * @see <a
   *      href="http://download.oracle.com/javase/1.5.0/docs/api/java/nio/charset/Charset.html">Standard
   *      charsets</a>
   * @see #getBytesUnchecked(String, String)
   */
  public static byte[] getBytesUtf8(String string)
  {
    return StringUtils.getBytesUnchecked(string, "UTF-8");
  }

  /**
   * Encodes the given string into a sequence of bytes using the named charset,
   * storing the result into a new byte array.
   * <p>
   * This method catches {@link java.io.UnsupportedEncodingException} and
   * rethrows it as {@link IllegalStateException}, which should never happen for
   * a required charset name. Use this method when the encoding is required to
   * be in the JRE.
   * </p>
   *
   * @param string
   *          the String to encode, may be <code>null</code>
   * @param charsetName
   *          The name of a required {@link java.nio.charset.Charset}
   * @return encoded bytes, or <code>null</code> if the input string was
   *         <code>null</code>
   * @throws IllegalStateException
   *           Thrown when a {@link java.io.UnsupportedEncodingException} is
   *           caught, which should never happen for a required charset name.
   * @see String#getBytes(String)
   */
  public static byte[] getBytesUnchecked(String string, String charsetName)
  {
    if (string == null)
    {
      return null;
    }
    try
    {
      return string.getBytes(charsetName);
    }
    catch (UnsupportedEncodingException e)
    {
      throw StringUtils.newIllegalStateException(charsetName, e);
    }
  }

  private static IllegalStateException newIllegalStateException(
      String charsetName, UnsupportedEncodingException e)
  {
    return new IllegalStateException(charsetName + ": " + e);
  }

  /**
   * Constructs a new <code>String</code> by decoding the specified array of
   * bytes using the given charset.
   * <p>
   * This method catches {@link java.io.UnsupportedEncodingException} and
   * re-throws it as {@link IllegalStateException}, which should never happen
   * for a required charset name. Use this method when the encoding is required
   * to be in the JRE.
   * </p>
   *
   * @param bytes
   *          The bytes to be decoded into characters, may be <code>null</code>
   * @param charsetName
   *          The name of a required {@link java.nio.charset.Charset}
   * @return A new <code>String</code> decoded from the specified array of bytes
   *         using the given charset, or <code>null</code> if the input byte
   *         arrray was <code>null</code>.
   * @throws IllegalStateException
   *           Thrown when a {@link java.io.UnsupportedEncodingException} is
   *           caught, which should never happen for a required charset name.
   * @see String#String(byte[], String)
   */
  public static String newString(byte[] bytes, String charsetName)
  {
    if (bytes == null)
    {
      return null;
    }
    try
    {
      return new String(bytes, charsetName);
    }
    catch (UnsupportedEncodingException e)
    {
      throw StringUtils.newIllegalStateException(charsetName, e);
    }
  }

  /**
   * Constructs a new <code>String</code> by decoding the specified array of
   * bytes using the UTF-8 charset.
   *
   * @param bytes
   *          The bytes to be decoded into characters
   * @return A new <code>String</code> decoded from the specified array of bytes
   *         using the UTF-8 charset, or <code>null</code> if the input byte
   *         array was <code>null</code>.
   * @throws IllegalStateException
   *           Thrown when a {@link java.io.UnsupportedEncodingException} is
   *           caught, which should never happen since the charset is required.
   */
  public static String newStringUtf8(byte[] bytes)
  {
    return StringUtils.newString(bytes, "UTF-8");
  }

  /**
   * Obtiene el texto de stacktrace de una excepcion
   *
   * @param e
   * @return
   */
  public static String getTextException(Throwable e)
  {
    StringBuilder strBuilder = new StringBuilder();
    do
    {
      strBuilder.append("Error: ");
      strBuilder.append(e.getMessage());
      strBuilder.append("\nStack: ");
      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);
      e.printStackTrace(pw);
      strBuilder.append(sw.toString());
      e = e.getCause();
      if (e != null)
      {
        strBuilder.append("\nGenerado por:\n");
      }
    } while (e != null);
    return strBuilder.toString();
  }

  public static String convertFromUTF8(String s) {
    String out = null;
    try {
      out = new String(s.getBytes("ISO-8859-1"), "UTF-8");
    } catch (java.io.UnsupportedEncodingException e) {
      return null;
    }
    return out;
  }

  // convert from internal Java String format -> UTF-8
  public static String convertToUTF8(String s) {
    String out = null;
    try {
      out = new String(s.getBytes("UTF-8"), "ISO-8859-1");
    } catch (java.io.UnsupportedEncodingException e) {
      return null;
    }
    return out;
  }
}
