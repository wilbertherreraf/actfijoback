package gob.bcb.jee.creditos.core.comunes.webManage;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import gob.bcb.jee.creditos.util.Log;

import java.util.Date;

/**
 * Clase que realiza el seteo de los valores del tiempo de vida de la session
 * 
 * @author eibanez
 * 
 */
//@WebListener
public class HttpSessionCheker implements HttpSessionListener {
	//TODO: Revisar que esto no afecte al funcionamiento de la app
	@Override
	public void sessionCreated(HttpSessionEvent event) {

		Log.Info("Session ID %s created at %s%n"+ event.getSession().getId()+ new Date());
		Log.Info("Tiempo de Vida de la session: " + event.getSession().getMaxInactiveInterval());

		event.getSession().setMaxInactiveInterval(3 * 60); // session asignada
															// de 3 minutos
		Log.Info("2 Tiempo de Vida de la session: "
				+ event.getSession().getMaxInactiveInterval());
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent event) {

		Log.Info("Session ID %s destroyed at %s%n"+ event.getSession()
				.getId()+ new Date());

	}

}
