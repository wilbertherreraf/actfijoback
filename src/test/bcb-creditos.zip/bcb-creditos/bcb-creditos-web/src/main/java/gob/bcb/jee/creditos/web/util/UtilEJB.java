package gob.bcb.jee.creditos.web.util;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import gob.bcb.jee.creditos.util.Log;

import java.util.Hashtable;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.web.util
 * 15/11/2016 - 04:34 PM
 * Creado por aescobar
 */
public class UtilEJB {

    
    public static String urlContext;

    public static void init(String urlContextCadena)
    {
        urlContext = urlContextCadena + "/";
        Log.Debug("urlEJBContext = " + urlContext);
    }

    public static Object lookup(Class clazz, Class interfaze) throws NamingException
    {
        Log.Info("ingresar al lookup");
        final Hashtable jndiProperties = new Hashtable();
        Context context = new InitialContext(jndiProperties);
        return context.lookup(urlContext + clazz.getSimpleName());
    }

    public static String getContextPath() throws NamingException, Exception
    {
        String mname = (String) new InitialContext().lookup("java:module/ModuleName");
        return mname;
    }



}
