package gob.bcb.jee.creditos.web.util;

import gob.bcb.jee.creditos.entidades.Usuario;
import gob.bcb.jee.creditos.util.Log;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Clase de filtro para control de falla en comunicacion con el TCIABCB
 * 
 * 
 * 
 */
public class SeguridadFilterLogin implements Filter
{


  @Override
  public void destroy()
  {
  }

  @Override
  public void doFilter(ServletRequest request, ServletResponse response,
      FilterChain chain) throws IOException, ServletException
  {
    Log.Trace("Iniciando Filtro");
    String urlAcceso = ((HttpServletRequest) request).getRequestURI();
    Usuario usuario = (Usuario) UtilWeb.getVariableSessionOfRequest(CttesWeb.VariablesSesion.USUARIO, request);
    if (usuario == null)
    {
      Log.Debug("No tiene usuario de sesion, anulará la sesión JAAS");
      try
      {
        ((HttpServletRequest) request).getSession().invalidate();
        ((HttpServletRequest) request).logout();
        Log.Debug("No tiene usuario de sesion, anuló la sesión JAAS");
        // UtilWeb.redireccionarURL(CttesWeb.URL_INDEX);
        ((HttpServletResponse) response).sendRedirect(CttesWeb.URL_INDEX);
      }
      catch (Exception e)
      {
        Log.Error("Error al caducar sesion. "+ e);
        // UtilWeb.redireccionarURL(CttesWeb.URL_ERROR_EXCEPCION_FATAL);
        ((HttpServletResponse) response).sendRedirect(CttesWeb.URL_ERROR_EXCEPCION_FATAL);
      }
      return;
    }
    chain.doFilter(request, response);
  }

  @Override
  public void init(FilterConfig arg0) throws ServletException
  {
  }

}
