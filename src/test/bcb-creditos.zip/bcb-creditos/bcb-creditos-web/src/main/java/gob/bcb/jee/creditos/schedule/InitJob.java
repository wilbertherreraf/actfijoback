package gob.bcb.jee.creditos.schedule;

import java.util.Arrays;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import gob.bcb.jee.creditos.BL.SacClavesBLLocal;
import gob.bcb.jee.creditos.BL.SacClavesBLLocalImpl;
import gob.bcb.jee.creditos.model.SacClaves;
import gob.bcb.jee.creditos.util.Log;
import gob.bcb.jee.creditos.util.UtilEJB;
import gob.bcb.jee.creditos.web.util.UtilJobs;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.schedule
 * 14/11/2016 - 04:03 PM
 * Creado por aescobar
 */
public class InitJob implements Job {

	public final static String JOB_NAME = "InitJob";

	SacClavesBLLocal sacClavesBLLocal;

	@Override
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		try {

			// sacClavesBLLocal = (SacClavesBLLocal) UtilEJB.lookup(SacClavesBLLocal.class);
			// sacClavesBLLocal = lookupBeanSacClavesBLLocal();
			Log.Info("Iniciando configuracion de job devengados");
			SacClaves sacClaves = getLook().get("JOB_DEVENGADO");
			String[] hora = sacClaves.getClvValor().split(":");
			Log.Info("Hora de ejecución " + Arrays.toString(hora));

			UtilJobs.programarJobAtHourAndMinuteForDay(jobExecutionContext.getScheduler(),
					sacClaves.getClvCodclv().trim(), DevengadosJob.class, sacClaves.getClvValor());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			Log.Error(e.getMessage());
			
		}

	}

	protected SacClavesBLLocal getLook() throws Exception {
		if (sacClavesBLLocal == null) {
			sacClavesBLLocal = (SacClavesBLLocal) UtilEJB.lookup(SacClavesBLLocalImpl.class);
		}
		return sacClavesBLLocal;
	}
}
