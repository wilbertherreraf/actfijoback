package gob.bcb.jee.creditos.entidades;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.entidades
 * 11/07/2016 - 06:09 PM
 * Código base:
 * Creado por aescobar
 */

public enum TipoPermiso
{
    LEC("LEC"),
    ALT("ALT"),
    MOD("MOD"),
    ELM("ELM"),
    AUT("AUT"),
    PAU("PAU");


    private String valor;

    private TipoPermiso(String valor)
    {
        this.valor = valor;
    }

    @Override
    public String toString()
    {
        return valor;
    }

}