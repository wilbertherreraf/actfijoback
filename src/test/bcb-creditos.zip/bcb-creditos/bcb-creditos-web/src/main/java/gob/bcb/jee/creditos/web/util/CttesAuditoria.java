package gob.bcb.jee.creditos.web.util;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.web.util
 * 28/06/2016 - 09:14 AM
 * Created por aescobar
 */
public class CttesAuditoria {
    public static final String DATOS_CREDITOS = "0001000";
    public static final String REGISTRO_DATOS = "0001001";
    public static final String MODIFICACION_DATOS = "0001002";
    public static final String ELIMINACION_DATOS = "0001003";
    public static final String AUTORIZACION_DATOS = "0001004";
}
