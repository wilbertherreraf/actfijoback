select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Actualiza estado del credito 78 
         -- FECHA: 23-04-2025
         -- SDAPO: 2407563
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;

update d_creditos.pre_prestamos 
set pre_status=2,
cambio_bd ='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2407563'
where pre_codcred= 78; 