select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Ajuste en el plan de pagos.
         -- FECHA: 31-01-2025
         -- SDAPO: 2320476
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;


update aux_planpagos  
set acu_codcred=0,
acu_codmod=0,
acu_codmodorig=0
where acu_codacu=5174;


update aux_planpagosr  
set acu_codcred=0,
acu_codmod=0,
acu_codmodorig=0
where acu_codacu=89889;


update pre_tasaspre  
set mtp_intydias=360
where mtp_codcred =84 and mtp_codmod =19;
