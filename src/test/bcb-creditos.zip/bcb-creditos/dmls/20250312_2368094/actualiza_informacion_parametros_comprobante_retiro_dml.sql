select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: ACTUALIZA PARAMETROS Y GLOSA DE COMPROBANTES PARA RETIRO DE GARANTIAS.
         -- FECHA: 21-03-2025
         -- SDAPO: 2368094
         -- USUARIO: Mabel Ramos
         -- **********************************************************************
from systables limit 1;
 

-- ACTUALIZA DETALLE DE LA GLOSA
update d_creditos.gen_comprobante
set cmp_glosa='RETIRO DE CUSTODIA DEL BT CON LA CLAVE DE SERIE #P1 CUOTA #P2 FECHA DE VCTO #P3 ACTA DE RETIRO #P4, DEL #P5� DESEMB. DEL CRED. #P6 POR BS#P7 EN EL MARCO DE LA RD. #P8, CONT. #P9 Y DOC. ADJ.',
	cmp_tipo='G',
	cambio_bd ='mcramos_' || CURRENT YEAR TO SECOND || '_sdapo 2368094'
where cmp_codcmp=10;


-- RENGLON DEBE Y HABER
INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 10, 1, 1900, 1, 16, 0, 'D', 1900, 3, 29, 0, 1900, 3, 38, null, 't', 'RETIRO DE CUSTODIA DEL BT CON CLAVE DE SERIE {#P1}, CUOTA {#P2}', 't', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),10, 2, 1900, 1, 17, 0, 'H', 1900, 3, 30, 0, 1900, 3, 39, null, 't', 'RETIRO DE CUSTODIA DEL BT CON CLAVE DE SERIE {#P1}, CUOTA {#P2}', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));





  
