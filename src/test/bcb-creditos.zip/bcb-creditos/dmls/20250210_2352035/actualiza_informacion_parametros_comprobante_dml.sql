select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: ACTUALIZA PARAMETROS Y GLOSA DE COMPROBANTES.
         -- FECHA: 17-02-2025
         -- SDAPO: 2352035
         -- USUARIO: Mabel Ramos
         -- **********************************************************************
from systables limit 1;
 

-- ACTUALIZA DETALLE DE LA GLOSA EPNES 2944 
update d_creditos.gen_comprobante
set cmp_glosa='#P1� DESEMBOLSO DE RECURSOS A #P2, NOTAS CITE: #P3 Y #P4 (#P5) SG. #P6, CONT.#P7 E INFORMES BCB #P8 Y #P9.',
	cmp_tipo='G',
	cambio_bd ='mcramos_' || CURRENT YEAR TO SECOND || '_sdapo 2352035'
where cmp_codcmp=1;

-- ACTUALIZA DETALLE DE LA GLOSA MEFP 3660 
update d_creditos.gen_comprobante
set cmp_glosa='#P1� DESEMB. DE RECURSOS DEL  #P2, SG NOTA: #P3 (#P4), EN EL MARCO DE LA RD N #P5 CONT.SANO-DLBCI #P6 LEY #P7 Y DOC. ADJ.',
 	cmp_tipo='G',
	cambio_bd ='mcramos_' || CURRENT YEAR TO SECOND || '_sdapo 2352035'
where cmp_codcmp=2;

-- DESEMBOLSOS - EPNES
INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 1, 1, 1900, 1, 1, 0, 'D', 1900, 3, 29, 0, 1900, 3, 38, null, 't', '{#P1}� DESEMBOLSO DE RECURSOS A FAVOR DE {#P2}', 't', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),1, 2, 1900, 1, 2, 0, 'H', 1900, 3, 30, 0, 1900, 3, 39, null, 't', 'ABONO EN LA CTA {#P1} POR EL {#P2}� DESEMB. DE {#P3}', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- DESEMBOLSOS - MEFP
INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 2, 1, 1900, 1, 1, 0, 'D', 1900, 3, 29, 0, 1900, 3, 38, null, 't', ' {#P1}� DESEMB. A FAVOR DE {#P2}', 't', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),2, 2, 1900, 1, 2, 0, 'H', 1900, 3, 30, 0, 1900, 3, 39, null, 't', 'ABONO EN LA LIBRETA {#P1} - "{#P2} ({#P3})" {#P4}� DESEMB. {#P5}', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

