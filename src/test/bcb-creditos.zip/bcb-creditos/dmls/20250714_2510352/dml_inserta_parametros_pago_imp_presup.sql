select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Inserta parametros para la IMPUTACION PRESUPUESTARIA en la tabla gen_certpres que se utilizara desde el modulo de PAGO DE CUOTA
         -- FECHA: 14-07-2025
         -- SDAPO: 2510352
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;


INSERT INTO d_creditos.gen_certpres (ctp_codctp, ctp_codrln, ctp_nro_renglon, ctp_tabscr_imp, ctp_scr_imp, ctp_partpr_imp, ctp_default_imp, ctp_tabscr_cp, ctp_scr_cp, ctp_partpr_cp, ctp_cp_default, ctp_tabscr_monto_mn, ctp_scr_monto_mn, ctp_partpr_monto_mn, ctp_default_monto_mn, ctp_tabscr_gestion, ctp_scr_gestion, ctp_partpr_gestion, ctp_gestion_default, ctp_tabscr_uor, ctp_scr_uor, ctp_partpr_uor, ctp_uor_default, ctp_tabscr_rfa, ctp_scr_rfa, ctp_partpr_rfa, ctp_rfa_default, ctp_tabscr_top, ctp_scr_top, ctp_partpr_top, ctp_top_default, ctp_tab_estado, ctp_estado, ctp_auditusr, ctp_auditfho, ctp_auditwst)
VALUES(2, 4, 1, 1900, 2, 0, '1', 1900, 1, 25, NULL, 1900, 3, 33, NULL, 1900, 3, 34, NULL, 1900, 2, 35, '1280', 1900, 2, 36, 'N', 1900, 2, 37, 'R', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));
