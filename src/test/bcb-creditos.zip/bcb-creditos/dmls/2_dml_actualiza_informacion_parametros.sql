select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: ACTUALIZA PARAMETROS Y GLOSA DE COMPROBANTES.
         -- FECHA: 10-07-2024
         -- SDAPO: 2085127
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 
 -- 1 QUERY 
-- actualiza el valor de Cuenta BCB interes devengado
update d_creditos.gen_parametro
set par_parametro='0208',
	cambio_bd ='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2085127'
where par_codpar=176;


-- ACTUALIZA DETALLE DE LA GLOSA 
update d_creditos.gen_comprobante
set cmp_glosa='INTERESES DEVENGADOS POR {#P1} D�AS DE {#P2},POR {#P3} DESEMB.DEL CRED.{#P4},TOT. DESEMB. Bs{#P5} SALDO A CAP. Bs{#P6} EN EL MARCO DE LA RD {#P7} Y CONT. SANO-DLBCI N�{#P8} Y DOC ADJ.',
	cambio_bd ='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2085127'
where cmp_codcmp=3;


update d_creditos.pre_prestamos
set pre_numcontra='018/2023', 
	cambio_bd ='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2085127'
where pre_codcred=69;
  
