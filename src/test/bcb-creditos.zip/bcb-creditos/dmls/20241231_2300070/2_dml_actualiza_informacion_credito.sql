select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Actualiza la informacion de plan consolidado de pagos para los creditos EASBA I y EASBA III e ingresa valores  de saldo de interes en pagos anticipados.
         -- FECHA: 31-12-2024
         -- SDAPO: 2300070
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 

update pre_planpagos 
set cuo_fecfincuo='2026-04-04'
where cuo_codcuo in (82003,82004,82005,82006,82007);

update pre_planpagos 
set cuo_fecfincuo='2026-04-04'
where cuo_codcuo in (82087, 82088, 82089, 82090, 82091);

update pre_planpagos 
set cuo_fecfincuo='2026-04-04'
where cuo_codcuo in (82129, 82130, 82131, 82132, 82133);

update pre_planpagos 
set cuo_fecfincuo='2026-04-04'
where cuo_codcuo in (82171,82172,82173);

update pre_planpagos 
set cuo_fecfincuo='2026-04-04'
where cuo_codcuo in (82211,82212,82213);

update pre_planpagos 
set cuo_fecfincuo='2026-04-04'
where cuo_codcuo in (82251,82252);

update pre_planpagos 
set cuo_fecfincuo='2026-04-04'
where cuo_codcuo in (82290,82291);

update pre_planpagos 
set cuo_fecfincuo='2026-04-04'
where cuo_codcuo in (82329);


update pre_reprograma  
set rds_fecini='2025-02-10',
rds_feciniint='2025-02-10'
where rds_codrepro=38;







update d_creditos.aux_planpagos
set acu_saldo_interes_pago_anticipado= 121998.28
where acu_codacu=4022;


update d_creditos.aux_planpagos
set acu_saldo_interes_pago_anticipado= 242513.66
where acu_codacu=3989;


update d_creditos.pre_planpagos
set cuo_saldo_interes_pago_anticipado= 242513.66,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2300070'
where cuo_codcuo=131095;