select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Actualiza cantidad dias para el credito 56.
         -- FECHA: 11-03-2024
         -- SDAPO: 1968609
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 
 -- 1 QUERY 
-- actualiza el valor de Cuenta BCB interes devengado
update d_creditos.pre_accrual
set acr_diasaccr=30,
	cambio_bd ='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 1968609'
where acr_codacr=3904195; 