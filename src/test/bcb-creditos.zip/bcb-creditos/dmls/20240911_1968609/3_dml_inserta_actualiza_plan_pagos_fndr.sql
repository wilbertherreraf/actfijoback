select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Inserta y actualiza el plan de pagos para el credito N� 43 - FNDR.
         -- FECHA: 11-03-2024
         -- SDAPO: 1968609
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 
 
 
--FECHA 02-12-2021	(INSERTAMOS VALORES)
-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2021-12-02', NULL, '2021-12-02', 0.00, 0.00, 0.00, 0.00, 12613230.28, 12613230.28, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2021-12-02', NULL, '2021-12-02', 0.00, 0.00, 0.00, 0.00, 12613230.28, 12613230.28, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2021-12-02', NULL, '2021-12-02', 0.00, 0.00, 0.00, 0.00, 7347021.43, 7347021.43, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2021-12-02', NULL, '2021-12-02', 0.00, 0.00, 0.00, 0.00, 7347021.43, 7347021.43, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 31-01-2022	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='116651742.45',
	cuo_valorpend='116651742.45'
where cuo_codcuo in (108336, 20964);

-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='3460453.47',
	cuo_valorpend='3460453.47'
where cuo_codcuo in (108337, 70964);

-- INTERES CAPITAL
update d_creditos.pre_planpagos
set cuo_capital='2120392988.54'
where cuo_codcuo =70964;


--FECHA 01-02-2022	(INSERTAMOS VALORES)
-- AMORTIZACION

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-02-01', NULL, '2022-02-01', 0.00, 0.00, 0.00, 0.00, 2240769.1, 2240769.1, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-02-01', NULL, '2022-02-01', 0.00, 0.00, 0.00, 0.00, 2240769.1, 2240769.1, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-02-01', NULL, '2022-02-01', 0.00, 0.00, 0.00, 0.00, 55659.48, 55659.48, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-02-01', NULL, '2022-02-01', 0.00, 0.00, 0.00, 0.00, 55659.48, 55659.48, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


--FECHA 02-02-2022	(INSERTAMOS VALORES)
-- AMORTIZACION

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-02-02', NULL, '2022-02-02', 0.00, 0.00, 0.00, 0.00, 474718.15, 474718.15, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-02-02', NULL, '2022-02-02', 0.00, 0.00, 0.00, 0.00, 474718.15, 474718.15, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-02-02', NULL, '2022-02-02', 0.00, 0.00, 0.00, 0.00, 55597.24, 55597.24, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-02-02', NULL, '2022-02-02', 0.00, 0.00, 0.00, 0.00, 55597.24, 55597.24, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 17-02-2022	(INSERTAMOS VALORES)

-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-02-17', NULL, '2022-02-17', 0.00, 0.00, 0.00, 0.00, 16653.6, 16653.6, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-02-17', NULL, '2022-02-17', 0.00, 0.00, 0.00, 0.00, 16653.6, 16653.6, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 16-05-2022	(INSERTAMOS VALORES)

-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-05-16', NULL, '2022-05-16', 0.00, 0.00, 0.00, 0.00, 2546408.48, 2546408.48, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-05-16', NULL, '2022-05-16', 0.00, 0.00, 0.00, 0.00, 2546408.48, 2546408.48, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 24-06-2022	(INSERTAMOS VALORES)
-- AMORTIZACION

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-06-24', NULL, '2022-06-24', 0.00, 0.00, 0.00, 0.00, 9794486.25, 9794486.25, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-06-24', NULL, '2022-06-24', 0.00, 0.00, 0.00, 0.00, 9794486.25, 9794486.25, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-06-24', NULL, '2022-06-24', 0.00, 0.00, 0.00, 0.00, 5329872.85, 5329872.85, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-06-24', NULL, '2022-06-24', 0.00, 0.00, 0.00, 0.00, 5329872.85, 5329872.85, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 31-07-2022	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='112945235.36',
	cuo_valorpend='112945235.36'
where cuo_codcuo in (79338, 20965);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='2046543.25',
	cuo_valorpend='2046543.25'
where cuo_codcuo in (79339, 70965);


--FECHA 18-08-2022	(INSERTAMOS VALORES)
-- AMORTIZACION

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-08-18', NULL, '2022-08-18', 0.00, 0.00, 0.00, 0.00, 17013197.27, 17013197.27, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-08-18', NULL, '2022-08-18', 0.00, 0.00, 0.00, 0.00, 17013197.27, 17013197.27, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-08-18', NULL, '2022-08-18', 0.00, 0.00, 0.00, 0.00, 939143.02, 939143.02, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-08-18', NULL, '2022-08-18', 0.00, 0.00, 0.00, 0.00, 939143.02, 939143.02, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 05-10-2022	(INSERTAMOS VALORES)

-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-10-05', NULL, '2022-10-05', 0.00, 0.00, 0.00, 0.00, 34630.17, 34630.17, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-10-05', NULL, '2022-10-05', 0.00, 0.00, 0.00, 0.00, 34630.17, 34630.17, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));




--FECHA 30-12-2022	(INSERTAMOS VALORES)
-- AMORTIZACION

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-12-30', NULL, '2022-12-30', 0.00, 0.00, 0.00, 0.00, 12899673.97, 12899673.97, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-12-30', NULL, '2022-12-30', 0.00, 0.00, 0.00, 0.00, 12899673.97, 12899673.97, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2022-12-30', NULL, '2022-12-30', 0.00, 0.00, 0.00, 0.00, 6893440.96, 6893440.96, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2022-12-30', NULL, '2022-12-30', 0.00, 0.00, 0.00, 0.00, 6893440.96, 6893440.96, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 31-01-2023	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='74217222.28',
	cuo_valorpend='74217222.28'
where cuo_codcuo in (79340, 20966);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='1642998.38',
	cuo_valorpend='1642998.38'
where cuo_codcuo in (79341,70966);



--FECHA 01-02-2023	(INSERTAMOS VALORES)
-- AMORTIZACION

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-02-01', NULL, '2023-02-01', 0.00, 0.00, 0.00, 0.00, 40167168.72, 40167168.72, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-02-01', NULL, '2023-02-01', 0.00, 0.00, 0.00, 0.00, 40167168.72, 40167168.72, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-02-01', NULL, '2023-02-01', 0.00, 0.00, 0.00, 0.00, 49282.11, 49282.11, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-02-01', NULL, '2023-02-01', 0.00, 0.00, 0.00, 0.00, 49282.11, 49282.11, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 06-02-2023	(INSERTAMOS VALORES)
-- AMORTIZACION

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-02-06', NULL, '2023-02-06', 0.00, 0.00, 0.00, 0.00, 4869784.16, 4869784.16, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-02-06', NULL, '2023-02-06', 0.00, 0.00, 0.00, 0.00, 4869784.16, 4869784.16, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-02-06', NULL, '2023-02-06', 0.00, 0.00, 0.00, 0.00, 240831.77, 240831.77, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-02-06', NULL, '2023-02-06', 0.00, 0.00, 0.00, 0.00, 240831.77, 240831.77, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 09-02-2023	(INSERTAMOS VALORES)
-- AMORTIZACION

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-02-09', NULL, '2023-02-09', 0.00, 0.00, 0.00, 0.00, 404213.87, 404213.87, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-02-09', NULL, '2023-02-09', 0.00, 0.00, 0.00, 0.00, 404213.87, 404213.87, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-02-09', NULL, '2023-02-09', 0.00, 0.00, 0.00, 0.00, 144093.25, 144093.25, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-02-09', NULL, '2023-02-09', 0.00, 0.00, 0.00, 0.00, 144093.25, 144093.25, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 17-02-2023	(INSERTAMOS VALORES)

-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-02-17', NULL, '2023-02-17', 0.00, 0.00, 0.00, 0.00, 86654.82, 86654.82, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-02-17', NULL, '2023-02-17', 0.00, 0.00, 0.00, 0.00, 86654.82, 86654.82, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 14-03-2023	(INSERTAMOS VALORES)
-- AMORTIZACION

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-03-14', NULL, '2023-03-14', 0.00, 0.00, 0.00, 0.00, 12641279.37, 12641279.37, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-03-14', NULL, '2023-03-14', 0.00, 0.00, 0.00, 0.00, 12641279.37, 12641279.37, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-03-14', NULL, '2023-03-14', 0.00, 0.00, 0.00, 0.00, 1498000.39, 1498000.39, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-03-14', NULL, '2023-03-14', 0.00, 0.00, 0.00, 0.00, 1498000.39, 1498000.39, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 21-03-2023	(INSERTAMOS VALORES)

-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-03-21', NULL, '2023-03-21', 0.00, 0.00, 0.00, 0.00, 42071.44, 42071.44, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-03-21', NULL, '2023-03-21', 0.00, 0.00, 0.00, 0.00, 42071.44, 42071.44, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));




--FECHA 01-06-2023	(INSERTAMOS VALORES)

-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-06-01', NULL, '2023-06-01', 0.00, 0.00, 0.00, 0.00, 150372.6, 150372.6, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-06-01', NULL, '2023-06-01', 0.00, 0.00, 0.00, 0.00, 150372.6, 150372.6, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 31-01-2023	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='109650506.39',
	cuo_valorpend='109650506.39'
where cuo_codcuo in (79342,20967);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6433506.42',
	cuo_valorpend='6433506.42'
where cuo_codcuo in (79343,70967);


--FECHA 10-08-2023	(INSERTAMOS VALORES)

-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-08-10', NULL, '2023-08-10', 0.00, 0.00, 0.00, 0.00, 1173683.77, 1173683.77, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-08-10', NULL, '2023-08-10', 0.00, 0.00, 0.00, 0.00, 1173683.77, 1173683.77, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-08-10', NULL, '2023-08-10', 0.00, 0.00, 0.00, 0.00, 446228.61, 446228.61, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-08-10', NULL, '2023-08-10', 0.00, 0.00, 0.00, 0.00, 446228.61, 446228.61, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 01-09-2023	(INSERTAMOS VALORES)

-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-09-01', NULL, '2023-09-01', 0.00, 0.00, 0.00, 0.00, 2542078.52, 2542078.52, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-09-01', NULL, '2023-09-01', 0.00, 0.00, 0.00, 0.00, 2542078.52, 2542078.52, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-09-01', NULL, '2023-09-01', 0.00, 0.00, 0.00, 0.00, 980985.69, 980985.69, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-09-01', NULL, '2023-09-01', 0.00, 0.00, 0.00, 0.00, 980985.69, 980985.69, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 20-11-2023	(INSERTAMOS VALORES)

-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2023-11-20', NULL, '2023-11-20', 0.00, 0.00, 0.00, 0.00, 56488.52, 56488.52, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2023-11-20', NULL, '2023-11-20', 0.00, 0.00, 0.00, 0.00, 56488.52, 56488.52, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));




--FECHA 31-01-2024	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='19057779.26',
	cuo_valorpend='19057779.26'
where cuo_codcuo in (79344, 20968);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6710497.56',
	cuo_valorpend='6710497.56'
where cuo_codcuo in (79345, 70968);



--FECHA 01-02-2024	(INSERTAMOS VALORES)

-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-02-01', NULL, '2024-02-01', 0.00, 0.00, 0.00, 0.00, 94433398.02, 94433398.02, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-02-01', NULL, '2024-02-01', 0.00, 0.00, 0.00, 0.00, 94433398.02, 94433398.02, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-02-01', NULL, '2024-02-01', 0.00, 0.00, 0.00, 0.00, 43990.26, 43990.26, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-02-01', NULL, '2024-02-01', 0.00, 0.00, 0.00, 0.00, 43990.26, 43990.26, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 09-02-2024	(INSERTAMOS VALORES)

-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-02-09', NULL, '2024-02-09', 0.00, 0.00, 0.00, 0.00, 5304392.42, 5304392.42, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-02-09', NULL, '2024-02-09', 0.00, 0.00, 0.00, 0.00, 5304392.42, 5304392.42, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-02-09', NULL, '2024-02-09', 0.00, 0.00, 0.00, 0.00, 330936.9, 330936.9, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-02-09', NULL, '2024-02-09', 0.00, 0.00, 0.00, 0.00, 330936.9, 330936.9, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 29-02-2024	(INSERTAMOS VALORES)

-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-02-29', NULL, '2024-02-29', 0.00, 0.00, 0.00, 0.00, 454433.47, 454433.47, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-02-29', NULL, '2024-02-29', 0.00, 0.00, 0.00, 0.00, 454433.47, 454433.47, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-02-29', NULL, '2024-02-29', 0.00, 0.00, 0.00, 0.00, 824395.37, 824395.37, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-02-29', NULL, '2024-02-29', 0.00, 0.00, 0.00, 0.00, 824395.37, 824395.37, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));




--FECHA 31-05-2024	(INSERTAMOS VALORES)

-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-05-31', NULL, '2024-05-31', 0.00, 0.00, 0.00, 0.00, 56287.15, 56287.15, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-05-31', NULL, '2024-05-31', 0.00, 0.00, 0.00, 0.00, 56287.15, 56287.15, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));




--FECHA 31-01-2024	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='71081684.67',
	cuo_valorpend='71081684.67'
where cuo_codcuo in (79346, 20969);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6248406.06',
	cuo_valorpend='6248406.06'
where cuo_codcuo in (79347,70969);



--FECHA 05-08-2024	(INSERTAMOS VALORES)

-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-08-05', NULL, '2024-08-05', 0.00, 0.00, 0.00, 0.00, 47049415.67, 47049415.67, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-08-05', NULL, '2024-08-05', 0.00, 0.00, 0.00, 0.00, 47049415.67, 47049415.67, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-08-05', NULL, '2024-08-05', 0.00, 0.00, 0.00, 0.00, 196163.25, 196163.25, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-08-05', NULL, '2024-08-05', 0.00, 0.00, 0.00, 0.00, 196163.25, 196163.25, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));




--FECHA 20-08-2024	(INSERTAMOS VALORES)

-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-08-20', NULL, '2024-08-20', 0.00, 0.00, 0.00, 0.00, 5701204.58, 5701204.58, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-08-20', NULL, '2024-08-20', 0.00, 0.00, 0.00, 0.00, 5701204.58, 5701204.58, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-08-20', NULL, '2024-08-20', 0.00, 0.00, 0.00, 0.00, 568885.95, 568885.95, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-08-20', NULL, '2024-08-20', 0.00, 0.00, 0.00, 0.00, 568885.95, 568885.95, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



--FECHA 30-08-2024	(INSERTAMOS VALORES)

-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2024-08-30', NULL, '2024-08-30', 0.00, 0.00, 0.00, 0.00, 135159.94, 135159.94, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2024-08-30', NULL, '2024-08-30', 0.00, 0.00, 0.00, 0.00, 135159.94, 135159.94, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));




--FECHA 31-01-2025	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='0.00',
	cuo_valorpend='0.00'
where cuo_codcuo in (79348, 20970);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6058686.92',
	cuo_valorpend='6058686.92'
where cuo_codcuo in (79349, 70970);



--FECHA 31-07-2025	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='0.00',
	cuo_valorpend='0.00'
where cuo_codcuo in (79350,20971);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6835891.96',
	cuo_valorpend='6835891.96'
where cuo_codcuo in (79351, 70971);



--FECHA 31-01-2026	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='0.00',
	cuo_valorpend='0.00'
where cuo_codcuo in (79352, 20972);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6949194.04',
	cuo_valorpend='6949194.04'
where cuo_codcuo in (79353,70972);




--FECHA 31-07-2026	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='0.00',
	cuo_valorpend='0.00'
where cuo_codcuo in (79354, 20973);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6835891.96',
	cuo_valorpend='6835891.96'
where cuo_codcuo in (79355, 70973);



--FECHA 31-01-2027	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='0.00',
	cuo_valorpend='0.00'
where cuo_codcuo in (79356,20974);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6949194.04',
	cuo_valorpend='6949194.04'
where cuo_codcuo in (79357,70974);



--FECHA 31-07-2027	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='36605372.46',
	cuo_valorpend='36605372.46'
where cuo_codcuo in (79358,20975);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6835891.96',
	cuo_valorpend='6835891.96'
where cuo_codcuo in (79359,70975);



--FECHA 31-01-2028	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='164999223.69',
	cuo_valorpend='164999223.69'
where cuo_codcuo in (79360,20976);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='6762099.91',
	cuo_valorpend='6762099.91'
where cuo_codcuo in (79361,70976);



--FECHA 31-07-2028	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='164999223.69',
	cuo_valorpend='164999223.69'
where cuo_codcuo in (79362,20977);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='5854436.09',
	cuo_valorpend='5854436.09'
where cuo_codcuo in (79363,70977);



--FECHA 31-01-2029	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='164999223.69',
	cuo_valorpend='164999223.69'
where cuo_codcuo in (79364,20978);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='5075441.18',
	cuo_valorpend='5075441.18'
where cuo_codcuo in (79365,70978);




--FECHA 31-07-2029	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='164999223.69',
	cuo_valorpend='164999223.69'
where cuo_codcuo in (79366,20979);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='4163109.99',
	cuo_valorpend='4163109.99'
where cuo_codcuo in (79367,70979);





--FECHA 31-01-2030	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='164999223.69',
	cuo_valorpend='164999223.69'
where cuo_codcuo in (79368,20980);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='3388782.45',
	cuo_valorpend='3388782.45'
where cuo_codcuo in (79369,70980);




--FECHA 31-07-2030	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='164999223.69',
	cuo_valorpend='164999223.69'
where cuo_codcuo in (79370,20981);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='2503951.13',
	cuo_valorpend='2503951.13'
where cuo_codcuo in (79371,70981);




--FECHA 31-01-2031	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='106704341.84',
	cuo_valorpend='106704341.84',
	cuo_diferido=1
where cuo_codcuo in (79372,20982);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='10577768.10',
	cuo_valorpend='10577768.10'
where cuo_codcuo in (79373,70982);




--FECHA 31-07-2031	(ACTUALIZAMOS VALORES) 
-- AMORTIZACION
update d_creditos.pre_planpagos
set cuo_valor='106704341.84',
	cuo_valorpend='106704341.84',
	cuo_diferido=1
where cuo_codcuo in (79374,20983);


-- INTERES
update d_creditos.pre_planpagos
set cuo_valor='12940571.79',
	cuo_valorpend='12940571.79'
where cuo_codcuo in (79375,70983);




--FECHA 31-01-2032	(INSERTAMOS VALORES)

-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2032-01-31', NULL, '2032-01-31', 0.00, 0.00, 0.00, 0.00, 164999223.69, 164999223.69, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2032-01-31', NULL, '2032-01-31', 0.00, 0.00, 0.00, 0.00, 164999223.69, 164999223.69, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2032-01-31', NULL, '2032-01-31', 0.00, 0.00, 0.00, 0.00, 1702123.72, 1702123.72, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2032-01-31', NULL, '2032-01-31', 0.00, 0.00, 0.00, 0.00, 1702123.72, 1702123.72, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));




--FECHA 31-01-2032	(INSERTAMOS VALORES)

-- AMORTIZACION
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2032-07-31', NULL, '2032-07-31', 0.00, 0.00, 0.00, 0.00, 168024982.53, 168024982.53, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2032-07-31', NULL, '2032-07-31', 0.00, 0.00, 0.00, 0.00, 168024982.53, 168024982.53, 15, 1, NULL, 1720, 1, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));


-- INTERES
INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 0, NULL, '2032-07-31', NULL, '2032-07-31', 0.00, 0.00, 0.00, 0.00, 849459.63, 849459.63, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO d_creditos.pre_planpagos
(cuo_codcuo, cuo_codcred, cuo_codmod, cuo_coddsb, cuo_numcuo, cuo_fecvencuo, cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_desemb, cuo_valor, cuo_valorpend, cuo_tabmonpag, cuo_monpag, cuo_numtrx, cuo_tabtipocuo, cuo_tipocuo, cuo_tipoacu, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst)
VALUES((select max(cuo_codcuo)+1 from pre_planpagos), 43, 18, 43001, NULL, '2032-07-31', NULL, '2032-07-31', 0.00, 0.00, 0.00, 0.00, 849459.63, 849459.63, 15, 1, NULL, 1720, 2, NULL, 1705, NULL, 30, 3, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));
 