select 1 -- **********************************************************************
         -- BD: axesso
         -- DESCRIPCION: Inserta recurso ADMINISTRACION_PARAMETROS_CONTABLES para a�adir la opcion 'Matriz de parametros contables' en el menu del sistema.
         -- FECHA: 23-01-2025
         -- SDAPO: 2326078
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
INSERT INTO d_axesso.axs_recurso (rap_codapp, rap_codrecur, rap_codrecur_padre, rap_codreclit, rap_descrip, rap_tabtiprecur, rap_tiprecur, rap_codrecpar, rap_tabstatreg, rap_statreg, rap_permdefault, rap_auditusr, rap_auditfho, rap_auditwst, cambio_bd)
VALUES('CREDITOS', 'ADMINISTRACION_PARAMETROS_CONTABLES', 'ADMINISTRACION', 'AMINISTRACION DE PARAMETROS CONTABLES', 'AMINISTRACION DE PARAMETROS CONTABLES', 1004, 4, '', 1008, 1, '', USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);


INSERT INTO axs_recursopermiso (rpe_codapp, rpe_codrol, rpe_codrecur, rpe_codpermiso, rpe_estado, cambio_bd)
VALUES('CREDITOS', 'OPERADOR', 'ADMINISTRACION', 'LEC', 'V', NULL);

INSERT INTO d_axesso.axs_recursopermiso (rpe_codapp, rpe_codrol, rpe_codrecur, rpe_codpermiso, rpe_estado, cambio_bd)
VALUES('CREDITOS', 'AUTORIZADOR', 'ADMINISTRACION_PARAMETROS_CONTABLES', 'LEC', 'V', NULL);

INSERT INTO d_axesso.axs_recursopermiso (rpe_codapp, rpe_codrol, rpe_codrecur, rpe_codpermiso, rpe_estado, cambio_bd)
VALUES('CREDITOS', 'PREAUTORIZADOR', 'ADMINISTRACION_PARAMETROS_CONTABLES', 'LEC', 'V', NULL);

INSERT INTO d_axesso.axs_recursopermiso (rpe_codapp, rpe_codrol, rpe_codrecur, rpe_codpermiso, rpe_estado, cambio_bd)
VALUES('CREDITOS', 'OPERADOR', 'ADMINISTRACION_PARAMETROS_CONTABLES', 'LEC', 'V', NULL);

INSERT INTO d_axesso.axs_recursopermiso (rpe_codapp, rpe_codrol, rpe_codrecur, rpe_codpermiso, rpe_estado, cambio_bd)
VALUES('CREDITOS', 'ADMINISTRADOR', 'ADMINISTRACION_PARAMETROS_CONTABLES', 'LEC', 'V', NULL);



INSERT INTO axs_profile(rre_codapp, rre_codrecur, rre_codrol, rre_permiso, rre_tabtippermiso, rre_tippermiso, rre_auditusr, rre_auditfho, rre_auditwst, cambio_bd)
VALUES('CREDITOS', 'ADMINISTRACION', 'OPERADOR', '0660', 1006, 1, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);


INSERT INTO d_axesso.axs_profile (rre_codapp, rre_codrecur, rre_codrol, rre_permiso, rre_tabtippermiso, rre_tippermiso, rre_auditusr, rre_auditfho, rre_auditwst, cambio_bd)
VALUES('CREDITOS', 'ADMINISTRACION_PARAMETROS_CONTABLES', 'AUTORIZADOR', '0660', 1006, 1, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);


INSERT INTO d_axesso.axs_profile (rre_codapp, rre_codrecur, rre_codrol, rre_permiso, rre_tabtippermiso, rre_tippermiso, rre_auditusr, rre_auditfho, rre_auditwst, cambio_bd)
VALUES('CREDITOS', 'ADMINISTRACION_PARAMETROS_CONTABLES', 'PREAUTORIZADOR', '0660', 1006, 1, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);


INSERT INTO d_axesso.axs_profile (rre_codapp, rre_codrecur, rre_codrol, rre_permiso, rre_tabtippermiso, rre_tippermiso, rre_auditusr, rre_auditfho, rre_auditwst, cambio_bd)
VALUES('CREDITOS', 'ADMINISTRACION_PARAMETROS_CONTABLES', 'OPERADOR', '0660', 1006, 1, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);

INSERT INTO d_axesso.axs_profile (rre_codapp, rre_codrecur, rre_codrol, rre_permiso, rre_tabtippermiso, rre_tippermiso, rre_auditusr, rre_auditfho, rre_auditwst, cambio_bd)
VALUES('CREDITOS', 'ADMINISTRACION_PARAMETROS_CONTABLES', 'ADMINISTRADOR', '0660', 1006, 1, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);
