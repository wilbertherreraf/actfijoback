select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Adiciona columna estado_parametros en la tabla pre_prestamos que registra el estado de autorizacion de los parametros registrados.
         -- FECHA: 23-01-2025
         -- SDAPO: 2326078
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;

update pre_prestamos 
set pre_estado_parametros=3,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2251266'; 