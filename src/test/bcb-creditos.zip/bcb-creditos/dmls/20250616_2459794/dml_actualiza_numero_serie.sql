select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Actualiza numeros de serie duplicados en la tabla pre_garantiad.
         -- FECHA: 16/06/2025
         -- SDAPO: 2459794
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;

UPDATE d_creditos.pre_garantiad
SET gard_coddsb=50032000,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2459794'
WHERE gard_cod=230;

UPDATE d_creditos.pre_garantiad
SET gard_coddsb=50064000,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2459794'
WHERE gard_cod=2;

UPDATE d_creditos.pre_garantiad
SET gard_coddsb=50065000,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2459794'
WHERE gard_cod=237;

UPDATE d_creditos.pre_garantiad
SET gard_coddsb=50063000,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2459794'
WHERE gard_cod=244;