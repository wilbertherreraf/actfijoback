select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Actualiza plan de pagos del credito 84 
         -- FECHA: 11-02-2025
         -- SDAPO: 2333600
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;

update d_creditos.aux_planpagos set acu_valor= 49432195.31 , acu_valorpend= 49432195.31 where acu_codacu= 5175;
update d_creditos.aux_planpagos set acu_valor= 49703800.78 , acu_valorpend= 49703800.78 where acu_codacu= 5176;
update d_creditos.aux_planpagos set acu_valor= 49432195.31 , acu_valorpend= 49432195.31 where acu_codacu= 5177;
update d_creditos.aux_planpagos set acu_valor= 49703800.78 , acu_valorpend= 49703800.78 where acu_codacu= 5178;
update d_creditos.aux_planpagos set acu_valor= 49432195.31 , acu_valorpend= 49432195.31 where acu_codacu= 5179;
update d_creditos.aux_planpagos set acu_valor= 49703800.78 , acu_valorpend= 49703800.78 where acu_codacu= 5180;
update d_creditos.aux_planpagos set acu_valor= 49703800.78 , acu_valorpend= 49703800.78 where acu_codacu= 5181;
update d_creditos.aux_planpagos set acu_valor= 49703800.78 , acu_valorpend= 49703800.78 where acu_codacu= 5182;
update d_creditos.aux_planpagos set acu_valor= 49432195.31 , acu_valorpend= 49432195.31 where acu_codacu= 5183;
update d_creditos.aux_planpagos set acu_valor= 49703800.78 , acu_valorpend= 49703800.78 where acu_codacu= 5184;
update d_creditos.aux_planpagos set acu_valor= 49432195.31 , acu_valorpend= 49432195.31 where acu_codacu= 5186;
update d_creditos.aux_planpagos set acu_valor= 48993746.48 , acu_valorpend= 48993746.48 where acu_codacu= 5188;
update d_creditos.aux_planpagos set acu_valor= 48019846.88 , acu_valorpend= 48019846.88 where acu_codacu= 5190;
update d_creditos.aux_planpagos set acu_valor= 47573637.89 , acu_valorpend= 47573637.89 where acu_codacu= 5192;
update d_creditos.aux_planpagos set acu_valor= 46863583.59 , acu_valorpend= 46863583.59 where acu_codacu= 5194;
update d_creditos.aux_planpagos set acu_valor= 46153529.3 , acu_valorpend= 46153529.3 where acu_codacu= 5196;
update d_creditos.aux_planpagos set acu_valor= 45195150 , acu_valorpend= 45195150 where acu_codacu= 5198;
update d_creditos.aux_planpagos set acu_valor= 44733420.7 , acu_valorpend= 44733420.7 where acu_codacu= 5200;
update d_creditos.aux_planpagos set acu_valor= 43782801.56 , acu_valorpend= 43782801.56 where acu_codacu= 5202;
update d_creditos.aux_planpagos set acu_valor= 43313312.11 , acu_valorpend= 43313312.11 where acu_codacu= 5204;
update d_creditos.aux_planpagos set acu_valor= 42370453.13 , acu_valorpend= 42370453.13 where acu_codacu= 5206;
update d_creditos.aux_planpagos set acu_valor= 41893203.52 , acu_valorpend= 41893203.52 where acu_codacu= 5208;
update d_creditos.aux_planpagos set acu_valor= 41183149.22 , acu_valorpend= 41183149.22 where acu_codacu= 5210;
update d_creditos.aux_planpagos set acu_valor= 40473094.92 , acu_valorpend= 40473094.92 where acu_codacu= 5212;
update d_creditos.aux_planpagos set acu_valor= 39545756.25 , acu_valorpend= 39545756.25 where acu_codacu= 5214;
update d_creditos.aux_planpagos set acu_valor= 39052986.33 , acu_valorpend= 39052986.33 where acu_codacu= 5216;
update d_creditos.aux_planpagos set acu_valor= 38133407.81 , acu_valorpend= 38133407.81 where acu_codacu= 5218;
update d_creditos.aux_planpagos set acu_valor= 37632877.73 , acu_valorpend= 37632877.73 where acu_codacu= 5220;
update d_creditos.aux_planpagos set acu_valor= 36721059.38 , acu_valorpend= 36721059.38 where acu_codacu= 5222;
update d_creditos.aux_planpagos set acu_valor= 36212769.14 , acu_valorpend= 36212769.14 where acu_codacu= 5224;
update d_creditos.aux_planpagos set acu_valor= 35502714.84 , acu_valorpend= 35502714.84 where acu_codacu= 5226;
update d_creditos.aux_planpagos set acu_valor= 34792660.55 , acu_valorpend= 34792660.55 where acu_codacu= 5228;
update d_creditos.aux_planpagos set acu_valor= 33896362.5 , acu_valorpend= 33896362.5 where acu_codacu= 5230;
update d_creditos.aux_planpagos set acu_valor= 33372551.95 , acu_valorpend= 33372551.95 where acu_codacu= 5232;
update d_creditos.aux_planpagos set acu_valor= 32484014.06 , acu_valorpend= 32484014.06 where acu_codacu= 5234;
update d_creditos.aux_planpagos set acu_valor= 31952443.36 , acu_valorpend= 31952443.36 where acu_codacu= 5236;
update d_creditos.aux_planpagos set acu_valor= 31071665.63 , acu_valorpend= 31071665.63 where acu_codacu= 5238;
update d_creditos.aux_planpagos set acu_valor= 30532334.77 , acu_valorpend= 30532334.77 where acu_codacu= 5240;
update d_creditos.aux_planpagos set acu_valor= 29822280.47 , acu_valorpend= 29822280.47 where acu_codacu= 5242;
update d_creditos.aux_planpagos set acu_valor= 29112226.17 , acu_valorpend= 29112226.17 where acu_codacu= 5244;
update d_creditos.aux_planpagos set acu_valor= 28246968.75 , acu_valorpend= 28246968.75 where acu_codacu= 5246;
update d_creditos.aux_planpagos set acu_valor= 27692117.58 , acu_valorpend= 27692117.58 where acu_codacu= 5248;
update d_creditos.aux_planpagos set acu_valor= 26834620.31 , acu_valorpend= 26834620.31 where acu_codacu= 5250;
update d_creditos.aux_planpagos set acu_valor= 26272008.98 , acu_valorpend= 26272008.98 where acu_codacu= 5252;
update d_creditos.aux_planpagos set acu_valor= 25422271.88 , acu_valorpend= 25422271.88 where acu_codacu= 5254;
update d_creditos.aux_planpagos set acu_valor= 24851900.39 , acu_valorpend= 24851900.39 where acu_codacu= 5256;
update d_creditos.aux_planpagos set acu_valor= 24141846.09 , acu_valorpend= 24141846.09 where acu_codacu= 5258;
update d_creditos.aux_planpagos set acu_valor= 23431791.8 , acu_valorpend= 23431791.8 where acu_codacu= 5260;
update d_creditos.aux_planpagos set acu_valor= 22597575 , acu_valorpend= 22597575 where acu_codacu= 5262;
update d_creditos.aux_planpagos set acu_valor= 22011683.2 , acu_valorpend= 22011683.2 where acu_codacu= 5264;
update d_creditos.aux_planpagos set acu_valor= 21185226.56 , acu_valorpend= 21185226.56 where acu_codacu= 5266;
update d_creditos.aux_planpagos set acu_valor= 20591574.61 , acu_valorpend= 20591574.61 where acu_codacu= 5268;
update d_creditos.aux_planpagos set acu_valor= 19772878.13 , acu_valorpend= 19772878.13 where acu_codacu= 5270;
update d_creditos.aux_planpagos set acu_valor= 19171466.02 , acu_valorpend= 19171466.02 where acu_codacu= 5272;
update d_creditos.aux_planpagos set acu_valor= 18461411.72 , acu_valorpend= 18461411.72 where acu_codacu= 5274;
update d_creditos.aux_planpagos set acu_valor= 17751357.42 , acu_valorpend= 17751357.42 where acu_codacu= 5276;
update d_creditos.aux_planpagos set acu_valor= 16948181.25 , acu_valorpend= 16948181.25 where acu_codacu= 5278;
update d_creditos.aux_planpagos set acu_valor= 16331248.83 , acu_valorpend= 16331248.83 where acu_codacu= 5280;
update d_creditos.aux_planpagos set acu_valor= 15535832.81 , acu_valorpend= 15535832.81 where acu_codacu= 5282;
update d_creditos.aux_planpagos set acu_valor= 14911140.23 , acu_valorpend= 14911140.23 where acu_codacu= 5284;
update d_creditos.aux_planpagos set acu_valor= 14123484.38 , acu_valorpend= 14123484.38 where acu_codacu= 5286;
update d_creditos.aux_planpagos set acu_valor= 13491031.64 , acu_valorpend= 13491031.64 where acu_codacu= 5288;
update d_creditos.aux_planpagos set acu_valor= 12780977.34 , acu_valorpend= 12780977.34 where acu_codacu= 5290;
update d_creditos.aux_planpagos set acu_valor= 12070923.05 , acu_valorpend= 12070923.05 where acu_codacu= 5292;
update d_creditos.aux_planpagos set acu_valor= 11298787.5 , acu_valorpend= 11298787.5 where acu_codacu= 5294;
update d_creditos.aux_planpagos set acu_valor= 10650814.45 , acu_valorpend= 10650814.45 where acu_codacu= 5296;
update d_creditos.aux_planpagos set acu_valor= 9886439.06 , acu_valorpend= 9886439.06 where acu_codacu= 5298;
update d_creditos.aux_planpagos set acu_valor= 9230705.86 , acu_valorpend= 9230705.86 where acu_codacu= 5300;
update d_creditos.aux_planpagos set acu_valor= 8474090.63 , acu_valorpend= 8474090.63 where acu_codacu= 5302;
update d_creditos.aux_planpagos set acu_valor= 7810597.27 , acu_valorpend= 7810597.27 where acu_codacu= 5304;
update d_creditos.aux_planpagos set acu_valor= 7100542.97 , acu_valorpend= 7100542.97 where acu_codacu= 5306;
update d_creditos.aux_planpagos set acu_valor= 6390488.67 , acu_valorpend= 6390488.67 where acu_codacu= 5308;
update d_creditos.aux_planpagos set acu_valor= 5649393.75 , acu_valorpend= 5649393.75 where acu_codacu= 5310;
update d_creditos.aux_planpagos set acu_valor= 4970380.08 , acu_valorpend= 4970380.08 where acu_codacu= 5312;
update d_creditos.aux_planpagos set acu_valor= 4237045.31 , acu_valorpend= 4237045.31 where acu_codacu= 5314;
update d_creditos.aux_planpagos set acu_valor= 3550271.48 , acu_valorpend= 3550271.48 where acu_codacu= 5316;
update d_creditos.aux_planpagos set acu_valor= 2824696.88 , acu_valorpend= 2824696.88 where acu_codacu= 5318;
update d_creditos.aux_planpagos set acu_valor= 2130162.89 , acu_valorpend= 2130162.89 where acu_codacu= 5320;
update d_creditos.aux_planpagos set acu_valor= 1420108.59 , acu_valorpend= 1420108.59 where acu_codacu= 5322;


INSERT INTO aux_planpagos (acu_codacu, acu_codcred, acu_codmod, acu_codmodorig, acu_numcuo, acu_fecvencuo, acu_fecinicuo, acu_fecfincuo, acu_capital, acu_interes, acu_cargos, acu_valor, acu_valorpend, acu_montocuo, acu_coddsb, acu_tasa, acu_tabtipodsb, acu_tipodsb, acu_tabtipocuo, acu_tipocuo, acu_tabmethodcapi, acu_methodcapi, acu_tabunidplaz, acu_unidplaz, acu_tipoacu, acu_tabmonpag, acu_monpag, acu_tabtipotrx, acu_tipotrx, acu_tabtrxstaau, acu_trxstaau, acu_saldo_interes_pago_anticipado, acu_auditfho, acu_auditusr, acu_auditwst)
VALUES((select max(acu_codacu)+1 from aux_planpagos),84, 1541342, 19, NULL, '2065-01-28', '2064-07-28', '2065-01-28', 44986413.28, NULL, NULL, 710054.30, 710054.30, 0.00, 50109, 3.15, 1720, 4502100, 1720, 2, 413, NULL, 1703, NULL, NULL, 15, 1, 1705, NULL, 30, 2, 0.00, current, '2520', (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5185;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5187;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5189;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5191;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5193;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5195;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5197;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5199;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5201;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5203;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5205;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5207;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5209;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5211;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5213;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5215;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5217;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5219;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5221;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5223;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5225;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5227;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5229;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5231;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5233;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5235;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5237;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5239;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5241;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5243;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5245;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5247;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5249;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5251;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5253;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5255;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5257;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5259;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5261;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5263;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5265;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5267;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5269;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5271;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5273;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5275;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5277;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5279;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5281;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5283;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5285;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5287;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5289;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5291;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5293;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5295;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5297;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5299;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5301;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5303;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5305;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5307;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5309;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5311;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5313;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5315;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5317;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5319;
update d_creditos.aux_planpagos set acu_valor= 44343750 , acu_valorpend= 44343750 where acu_codacu= 5321;
 

INSERT INTO aux_planpagos
(acu_codacu, acu_codcred, acu_codmod, acu_codmodorig, acu_numcuo, acu_fecvencuo, acu_fecinicuo, acu_fecfincuo, acu_capital, acu_interes, acu_cargos, acu_valor, acu_valorpend, acu_montocuo, acu_coddsb, acu_tasa, acu_tabtipodsb, acu_tipodsb, acu_tabtipocuo, acu_tipocuo, acu_tabmethodcapi, acu_methodcapi, acu_tabunidplaz, acu_unidplaz, acu_tipoacu, acu_tabmonpag, acu_monpag, acu_tabtipotrx, acu_tipotrx, acu_tabtrxstaau, acu_trxstaau, acu_saldo_interes_pago_anticipado, acu_auditfho, acu_auditusr, acu_auditwst)
VALUES((select max(acu_codacu)+1 from aux_planpagos), 84, 1541342, 19, NULL, '2065-01-28', '2064-07-28', '2065-01-28', 44986413.28, NULL, NULL, 44343750, 44343750, 0.00, 50109, 3.15, 1720, 4502100, 1720, 1, 413, NULL, 1703, NULL, NULL, 15, 1, 1705, NULL, 30, 2, 0.00, current, '2520', (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



UPDATE d_creditos.aux_planpagos
SET acu_fecvencuo = acu_fecvencuo - 1
WHERE acu_codcred=84 and acu_coddsb=50109 and acu_tipocuo=2 AND TO_CHAR(acu_fecvencuo, '%m-%d') = '01-28';

UPDATE d_creditos.aux_planpagos
SET acu_fecinicuo = acu_fecinicuo - 1
WHERE acu_codcred=84 and acu_coddsb=50109 and acu_tipocuo=2 AND TO_CHAR(acu_fecinicuo, '%m-%d') = '01-28';

UPDATE d_creditos.aux_planpagos
SET acu_fecfincuo = acu_fecfincuo - 1
WHERE acu_codcred=84 and acu_coddsb=50109 and acu_tipocuo=2 AND TO_CHAR(acu_fecfincuo, '%m-%d') = '01-28';



UPDATE d_creditos.aux_planpagos
SET acu_fecvencuo = acu_fecvencuo - 1
WHERE acu_codcred=84 and acu_coddsb=50109 and acu_tipocuo=1 AND TO_CHAR(acu_fecvencuo, '%m-%d') = '01-28';

UPDATE d_creditos.aux_planpagos
SET acu_fecinicuo = acu_fecinicuo - 1
WHERE acu_codcred=84 and acu_coddsb=50109 and acu_tipocuo=1 AND TO_CHAR(acu_fecinicuo, '%m-%d') = '01-28';

UPDATE d_creditos.aux_planpagos
SET acu_fecfincuo = acu_fecfincuo - 1
WHERE acu_codcred=84 and acu_coddsb=50109 and acu_tipocuo=1 AND TO_CHAR(acu_fecfincuo, '%m-%d') = '01-28';
