select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Actualiza amortizacion del credito 1.
         -- FECHA: 28-11-2024
         -- SDAPO: 2235171
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 

update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90069;


update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90070;


update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90071;


update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90072;


update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90073;


update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90074;


update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90075;


update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90076;


update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90077;


update  pre_planpagos 
set cuo_valor=8035464.28,
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where cuo_codcuo=90078;


update  d_creditos.pre_reprograma  
set rds_feculttrx='2015-06-23',
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2235171'
where rds_codrepro=37;
