---- DML ---
select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Actualiza e inserta parametros para las glosas del REGISTRO CONTABLE DE PAGO DE CUOTA en las tablas gen_comprobante y gen_renglon 
         -- FECHA: 06-05-2025
         -- SDAPO: 2401886
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;


UPDATE d_creditos.gen_comprobante
SET cmp_desc='AMORTIZACION DE CAPITAL Y PAGO DE INTERESES EPNE Y MEFP',
cmp_glosa='AMORT.DE CAP.Y PAGO DE INT. POR VCTO.(#P1) DEL #P2� DESEMB. DEL CRED. #P3 POR BS#P4 SG.BT. CON CLAVE DE SERIE #P5 CUOTA #P6, EN EL MARCO DE LA RD #P7, CONT. #P8 Y DOC. ADJ.',
cmp_tipo='G',
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2401886'
WHERE cmp_codcmp=4;

UPDATE d_creditos.gen_comprobante
SET cmp_desc='AMORTIZACION DE CAPITAL Y PAGO DE INTERESES YPFB Y FNDR',
cmp_glosa='AMORT.DE CAP.Y PAGO DE INT. POR VCTO.(#P1) DEL #P2� DESEMB. DEL CRED. #P3 POR BS#P4, EN EL MARCO DE LA RD #P5, CONT. #P6 Y DOC. ADJ.',
cmp_tipo='G',
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2401886'
WHERE cmp_codcmp=5;

UPDATE d_creditos.gen_comprobante
SET cmp_desc='PAGO DE INTERESES EPNE Y MEFP',
cmp_glosa='AMORT.DE CAP.Y PAGO DE INT. POR VCTO.(#P1) DEL #P2� DESEMB. DEL CRED. #P3 POR BS#P4 SG.BT. CON CLAVE DE SERIE #P5 CUOTA #P6, EN EL MARCO DE LA RD #P7, CONT. #P8 Y DOC. ADJ.',
cmp_tipo='G',
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2401886'
WHERE cmp_codcmp=6;

UPDATE d_creditos.gen_comprobante
SET cmp_desc='PAGO DE INTERESES YPFB Y FNDR',
cmp_glosa='AMORT.DE CAP.Y PAGO DE INT. POR VCTO.(#P1) DEL #P2� DESEMB. DEL CRED. #P3 POR BS#P4, EN EL MARCO DE LA RD #P5, CONT. #P6 Y DOC. ADJ.',
cmp_tipo='G',
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2401886'
WHERE cmp_codcmp=7;



INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 4, 1, 1900, 1, 5, 0, 'D', 1900, 3, 29, 0, 1900, 3, 38, null, 't', 'AMORTIZACI�N Y PAGO DE INTERES POR VENCIMIENTO EN {#P1}.', 't', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),4, 2, 1900, 1, 6, 0, 'H', 1900, 3, 30, 0, 1900, 3, 39, null, 't', 'AMORTIZACI�N A CAPITAL SEG�N GLOSA DE REFERENCIA.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),4, 3, 1900, 1, 10, 0, 'H', 1900, 3, 30, 0, 1900, 3, 40, null, 't', 'INTERESES ACUMULADOS AL 31 DE DICIEMBRE DE {#P1}.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),4, 4, 1900, 1, 10, 0, 'H', 1900, 3, 30, 0, 1900, 3, 40, null, 't', 'INTERESES CORRESPONDIENTES AL {#P1}.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 5, 1, 1900, 1, 5, 0, 'D', 1900, 3, 29, 0, 1900, 3, 38, null, 't', 'AMORTIZACI�N Y PAGO DE INTERES POR VENCIMIENTO EN {#P1}.', 't', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),5, 2, 1900, 1, 6, 0, 'H', 1900, 3, 30, 0, 1900, 3, 39, null, 't', 'AMORTIZACI�N A CAPITAL SEG�N GLOSA DE REFERENCIA.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),5, 3, 1900, 1, 10, 0, 'H', 1900, 3, 30, 0, 1900, 3, 40, null, 't', 'INTERESES ACUMULADOS AL 31 DE DICIEMBRE DE {#P1}.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),5, 4, 1900, 1, 10, 0, 'H', 1900, 3, 30, 0, 1900, 3, 40, null, 't', 'INTERESES CORRESPONDIENTES AL {#P1}.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 6, 1, 1900, 1, 5, 0, 'D', 1900, 3, 29, 0, 1900, 3, 38, null, 't', 'PAGO DE INTERESES POR VENCIMIENTO AL {#P1}.', 't', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 6, 2, 1900, 1, 6, 0, 'H', 1900, 3, 30, 0, 1900, 3, 39, null, 't', 'INTERESES ACUMULADOS AL 31 DE DICIEMBRE DE {#P1}.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 6, 3, 1900, 1, 10, 0, 'H', 1900, 3, 30, 0, 1900, 3, 40, null, 't', 'INTERESES CORRESPONDIENTES AL {#P1}.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 7, 1, 1900, 1, 5, 0, 'D', 1900, 3, 29, 0, 1900, 3, 38, null, 't', 'PAGO DE INTERESES POR VENCIMIENTO AL {#P1}.', 't', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 7, 2, 1900, 1, 6, 0, 'H', 1900, 3, 30, 0, 1900, 3, 39, null, 't', 'INTERESES ACUMULADOS AL 31 DE DICIEMBRE DE {#P1}.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 7, 3, 1900, 1, 10, 0, 'H', 1900, 3, 30, 0, 1900, 3, 40, null, 't', 'INTERESES CORRESPONDIENTES AL {#P1}.', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));



  
