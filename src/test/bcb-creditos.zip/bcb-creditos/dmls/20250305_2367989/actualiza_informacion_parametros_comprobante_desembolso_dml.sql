select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: ACTUALIZA VALORES DE GLOSA Y RENGLON DE COMPROBANTE DE DESEMBOLSO.
         -- FECHA: 31-03-2025
         -- SDAPO: 2367989
         -- USUARIO: Mabel Ramos
         -- **********************************************************************
from systables limit 1;
 

-- ACTUALIZA DETALLE DE LA GLOSA EPNES 2944 
update d_creditos.gen_comprobante
set cmp_glosa='#P1� DESEMBOLSO DE RECURSOS DEL CREDITO #P2, SG. NOTAS CITE: #P3 Y #P4 (#P5) EN EL MARCO DE LA RD #P6, CONT. #P7 E INFORMES #P8, #P9 Y DOC ADJ.',
	cmp_tipo='G',
	cambio_bd ='mcramos_' || CURRENT YEAR TO SECOND || '_sdapo 2352035'
where cmp_codcmp=1;


-- ACTUALIZA DETALLE DE LA GLOSA MEFP 3660 
update d_creditos.gen_comprobante
set cmp_glosa='#P1� DESEMBOLSO DE RECURSOS DEL CREDITO #P2, SG NOTA #P3 (#P4), EN EL MARCO DE LA RD #P5 CONT. #P6 LEY #P7 Y DOC. ADJ.',
 	cmp_tipo='G',
	cambio_bd ='mcramos_' || CURRENT YEAR TO SECOND || '_sdapo 2352035'
where cmp_codcmp=2;

-- DESEMBOLSOS - EPNES
UPDATE d_creditos.gen_renglon
SET rln_glosa='{#P1}� DESEMBOLSO DE RECURSOS A FAVOR DE {#P2}', rln_auditusr=USER, rln_auditfho=CURRENT YEAR TO SECOND, rln_auditwst=(select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables'))
WHERE rln_codrln=5;

UPDATE d_creditos.gen_renglon
SET rln_glosa='ABONO EN LA CTA {#P1} POR EL {#P2}� DESEMB. DEL CRED. {#P3}', rln_auditusr=USER, rln_auditfho=CURRENT YEAR TO SECOND, rln_auditwst=(select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables'))
WHERE rln_codrln=6;


-- DESEMBOLSOS - MEFP
UPDATE d_creditos.gen_renglon
SET rln_glosa='{#P1}� DESEMB. DEL CREDITO {#P2}', rln_auditusr=USER, rln_auditfho=CURRENT YEAR TO SECOND, rln_auditwst=(select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables'))
WHERE rln_codrln=7;

UPDATE d_creditos.gen_renglon
SET rln_glosa='ABONO EN LA LIBRETA {#P1} - "{#P2} ({#P3})" SG. GLOSA DE REFERENCIA', rln_auditusr=USER, rln_auditfho=CURRENT YEAR TO SECOND, rln_auditwst=(select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables'))
WHERE rln_codrln=8;

