select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: ACTUALIZA PARAMETROS Y GLOSA DE COMPROBANTES.
         -- FECHA: 05-03-2025
         -- SDAPO: 2367989
         -- USUARIO: Mabel Ramos
         -- **********************************************************************
from systables limit 1;
 

-- ACTUALIZA DETALLE DE LA GLOSA
update d_creditos.gen_comprobante
set cmp_glosa='INGRESO A CUSTODIA DE #P1 BTS POR EL #P2� DESEMB. DEL CRED. #P3 POR BS#P4 CLAVE DE SERIE #P5 SG. ACTA DE DEP. #P6 EN EL MARCO DE LA RD #P7, CONT. #P8, MOD. Y DOC. ADJ.',
	cmp_tipo='G',
	cambio_bd ='mcramos_' || CURRENT YEAR TO SECOND || '_sdapo 2367989'
where cmp_codcmp=9;


-- RENGLON DEBE Y HABER
INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 9, 1, 1900, 1, 14, 0, 'D', 1900, 3, 29, 0, 1900, 3, 38, null, 't', 'INGRESO A CUSTODIA DE {#P1} BTS CON CLAVE DE SERIE {#P2}', 't', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),9, 2, 1900, 1, 15, 0, 'H', 1900, 3, 30, 0, 1900, 3, 39, null, 't', 'INGRESO A CUSTODIA DE {#P1} BTS CON CLAVE DE SERIE {#P2}', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));





  
