-- AXESSO 
select 1 -- **********************************************************************
         -- BD: axesso
         -- DESCRIPCION: Inserta recurso GESTION_REGISTRO_GARANTIAS para a�adir la opcion 'Reistro de Garantias' en el menu del sistema.
         -- FECHA: 05-02-2025
         -- SDAPO: 2344735
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;




INSERT INTO axs_recurso (rap_codapp, rap_codrecur, rap_codrecur_padre, rap_codreclit, rap_descrip, rap_tabtiprecur, rap_tiprecur, rap_codrecpar, rap_tabstatreg, rap_statreg, rap_permdefault, rap_auditusr, rap_auditfho, rap_auditwst, cambio_bd)
VALUES('CREDITOS', 'GESTION_REGISTRO_GARANTIAS', 'GESTION', 'REGISTRO DE GARANTIAS', 'REGISTRO DE GARANTIAS', 1004, 4, '', 1008, 1, '', USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);


INSERT INTO d_axesso.axs_recursopermiso (rpe_codapp, rpe_codrol, rpe_codrecur, rpe_codpermiso, rpe_estado, cambio_bd)
VALUES('CREDITOS', 'AUTORIZADOR', 'GESTION_REGISTRO_GARANTIAS', 'LEC', 'V', NULL);

INSERT INTO d_axesso.axs_recursopermiso (rpe_codapp, rpe_codrol, rpe_codrecur, rpe_codpermiso, rpe_estado, cambio_bd)
VALUES('CREDITOS', 'PREAUTORIZADOR', 'GESTION_REGISTRO_GARANTIAS', 'LEC', 'V', NULL);

INSERT INTO d_axesso.axs_recursopermiso (rpe_codapp, rpe_codrol, rpe_codrecur, rpe_codpermiso, rpe_estado, cambio_bd)
VALUES('CREDITOS', 'OPERADOR', 'GESTION_REGISTRO_GARANTIAS', 'LEC', 'V', NULL);

INSERT INTO d_axesso.axs_recursopermiso (rpe_codapp, rpe_codrol, rpe_codrecur, rpe_codpermiso, rpe_estado, cambio_bd)
VALUES('CREDITOS', 'ADMINISTRADOR', 'GESTION_REGISTRO_GARANTIAS', 'LEC', 'V', NULL);


INSERT INTO d_axesso.axs_profile (rre_codapp, rre_codrecur, rre_codrol, rre_permiso, rre_tabtippermiso, rre_tippermiso, rre_auditusr, rre_auditfho, rre_auditwst, cambio_bd)
VALUES('CREDITOS', 'GESTION_REGISTRO_GARANTIAS', 'AUTORIZADOR', '0660', 1006, 1, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);

INSERT INTO d_axesso.axs_profile (rre_codapp, rre_codrecur, rre_codrol, rre_permiso, rre_tabtippermiso, rre_tippermiso, rre_auditusr, rre_auditfho, rre_auditwst, cambio_bd)
VALUES('CREDITOS', 'GESTION_REGISTRO_GARANTIAS', 'PREAUTORIZADOR', '0660', 1006, 1, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);

INSERT INTO d_axesso.axs_profile (rre_codapp, rre_codrecur, rre_codrol, rre_permiso, rre_tabtippermiso, rre_tippermiso, rre_auditusr, rre_auditfho, rre_auditwst, cambio_bd)
VALUES('CREDITOS', 'GESTION_REGISTRO_GARANTIAS', 'OPERADOR', '0660', 1006, 1, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);

INSERT INTO d_axesso.axs_profile (rre_codapp, rre_codrecur, rre_codrol, rre_permiso, rre_tabtippermiso, rre_tippermiso, rre_auditusr, rre_auditfho, rre_auditwst, cambio_bd)
VALUES('CREDITOS', 'GESTION_REGISTRO_GARANTIAS', 'ADMINISTRADOR', '0660', 1006, 1, USER, CURRENT, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')), NULL);

