select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Actualiza los parametros del REGISTRO TRANSITORIO DE BONOS de la tabla gen_comprobante y registra parametros en la tabla gen_renglon 
         -- FECHA: 05-02-2025
         -- SDAPO: 2344735
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- ***********************************************************************
from systables limit 1;

UPDATE d_creditos.gen_comprobante
SET cmp_glosa='REGISTRO TRANSITORIO DE #P1 BTS CON CLAVE DE SERIE #P2 CORRESPONDIENTE AL #P3� DESEMBOLSO DEL CREDITO #P4 SG. NOTA #P5 (#P6) EN EL MARCO DE LA RD #P7, CONT. #P8, MOD. Y DOC.ADJ.',
cmp_tipo='G',
cambio_bd='acanqui_' || CURRENT YEAR TO SECOND || '_sdapo 2344735'
WHERE cmp_codcmp=8;


INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon), 8, 1, 1900, 1, 12, 0, 'D', 1900, 3, 29, 0, 1900, 3, 38, null, 't', '{#P1}� DESEMBOLSO DEL CREDITO {#P2}', 't', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));

INSERT INTO gen_renglon (rln_codrln, rln_codcmp, rln_numero, rln_tabscr_ctamov, rln_scr_ctamov, rln_partpr_ctamov, rln_ctamov_default, rln_dh, rln_tabscr_monto_mo, rln_scr_monto_mo, rln_partpr_monto_mo, rln_monto_mo_default, rln_tabscr_glosa, rln_scr_glosa, rln_partpr_glosa, rln_glosa_default, rln_glosa_con_param, rln_glosa, rln_tiene_cp, rln_tab_estado, rln_estado, rln_auditusr, rln_auditfho, rln_auditwst)
VALUES((select max(rln_codrln)+1 from gen_renglon),8, 2, 1900, 1, 13, 0, 'H', 1900, 3, 30, 0, 1900, 3, 39, null, 't', '{#P1}� DESEMBOLSO DEL CREDITO {#P2}', 'f', 1901, 1, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables')));