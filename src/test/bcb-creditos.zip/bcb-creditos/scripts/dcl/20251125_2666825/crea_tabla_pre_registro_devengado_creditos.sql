select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Revoca accesos publicos de tabla pre_registro_devengado_creditos y asigna permisos a usuario w_creditos 
         -- FECHA: 25-11-2025
         -- SDAPO: 2666825
         -- USUARIO: Alvaro Canqui
         -- ***********************************************************************
from systables limit 1;

revoke all on "d_creditos".pre_registro_devengado_creditos from "public" as "d_creditos";
grant insert on "d_creditos".pre_registro_devengado_creditos to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_registro_devengado_creditos to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_registro_devengado_creditos to "w_creditos" as "d_creditos";

