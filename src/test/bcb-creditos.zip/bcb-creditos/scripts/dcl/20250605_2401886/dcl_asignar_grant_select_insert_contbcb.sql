select 1 -- **********************************************************************
         -- BD: contbcb
         -- DESCRIPCION: Asigna permisos a d_creditos, w_creditos para registro de datos en la tabla imp_sigma de la base de datos contbcb
         -- FECHA: 06-05-2025
         -- SDAPO: 2401886
         -- USUARIO: Alvaro Canqui
         -- **********************************************************************
from systables limit 1;
   
grant connect to "d_creditos";
grant connect to "w_creditos";

grant select on "d_conta".imp_sigma to "d_creditos" as "d_conta";
grant select on "d_conta".imp_sigma to "w_creditos" as "d_conta";


grant insert on "d_conta".imp_sigma to "d_creditos" as "d_conta";
grant insert on "d_conta".imp_sigma to "w_creditos" as "d_conta";
