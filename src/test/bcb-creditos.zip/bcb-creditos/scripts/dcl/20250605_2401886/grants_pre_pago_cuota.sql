select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Revoca accesos publicos de tabla pre_pagocuota y pre_pagocuota_h y asigna permisos a usuario w_creditos 
         -- FECHA: 06-05-2025
         -- SDAPO: 2401886
         -- USUARIO: Alvaro Canqui
         -- ***********************************************************************
from systables limit 1;

revoke all on "d_creditos".pre_pagocuota from "public" as "d_creditos";
grant insert on "d_creditos".pre_pagocuota to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_pagocuota to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_pagocuota to "w_creditos" as "d_creditos";

revoke all on "d_creditos".pre_pagocuota_h from "public" as "d_creditos";
grant insert on "d_creditos".pre_pagocuota_h to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_pagocuota_h to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_pagocuota_h to "w_creditos" as "d_creditos";