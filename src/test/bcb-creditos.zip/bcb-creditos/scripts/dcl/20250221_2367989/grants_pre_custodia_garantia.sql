select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Revoca accesos publicos de tabla pre_custodia_garantia y pre_custodia_garantia_h asigna permisos a usuario w_creditos 
         -- FECHA: 2025-02-21
         -- SDAPO: 2367989
         -- USUARIO: Mabel Ramos
         -- ***********************************************************************
from systables limit 1;

revoke all on "d_creditos".pre_custodia_garantia from "public" as "d_creditos";
grant insert on "d_creditos".pre_custodia_garantia to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_custodia_garantia to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_custodia_garantia to "w_creditos" as "d_creditos";

revoke all on "d_creditos".pre_custodia_garantia_h from "public" as "d_creditos";
grant insert on "d_creditos".pre_custodia_garantia_h to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_custodia_garantia_h to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_custodia_garantia_h to "w_creditos" as "d_creditos";
