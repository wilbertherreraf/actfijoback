select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: quita permisos a public y asigna permisos insert, select y update en las tablas  pre_registrogarantias y pre_registrogarantias_hist
         -- FECHA: 05-02-2025
         -- SDAPO: 2344735
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 

revoke all on "d_creditos".pre_registrogarantias from "public" as "d_creditos";
revoke all on "d_creditos".pre_registrogarantias from "public" as "d_creditos";

revoke all on "d_creditos".pre_registrogarantias_hist from "public" as "d_creditos";
revoke all on "d_creditos".pre_registrogarantias_hist from "public" as "d_creditos";

grant insert on "d_creditos".pre_registrogarantias to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_registrogarantias to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_registrogarantias to "w_creditos" as "d_creditos";

grant insert on "d_creditos".pre_registrogarantias_hist to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_registrogarantias_hist to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_registrogarantias_hist to "w_creditos" as "d_creditos";