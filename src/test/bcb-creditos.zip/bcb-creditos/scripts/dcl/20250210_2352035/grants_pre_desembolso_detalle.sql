select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Revoca accesos publicos de tabla pre_desembolso_detalle y asigna permisos a usuario w_creditos 
         -- FECHA: 2025-02-10
         -- SDAPO: 2352035
         -- USUARIO: Mabel Ramos
         -- ***********************************************************************
from systables limit 1;

revoke all on "d_creditos".pre_desembolso_detalle from "public" as "d_creditos";
grant insert on "d_creditos".pre_desembolso_detalle to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_desembolso_detalle to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_desembolso_detalle to "w_creditos" as "d_creditos";

revoke all on "d_creditos".pre_desembolso_detalle_h from "public" as "d_creditos";
grant insert on "d_creditos".pre_desembolso_detalle_h to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_desembolso_detalle_h to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_desembolso_detalle_h to "w_creditos" as "d_creditos";
