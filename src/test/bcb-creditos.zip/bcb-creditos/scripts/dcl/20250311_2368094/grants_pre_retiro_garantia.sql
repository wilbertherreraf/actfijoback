select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Revoca accesos publicos de tabla pre_retiro_garantia y pre_retiro_garantia_h y asigna permisos a usuario w_creditos 
         -- FECHA: 2025-03-11
         -- SDAPO: 2368094
         -- USUARIO: Mabel Ramos
         -- ***********************************************************************
from systables limit 1;

revoke all on "d_creditos".pre_retiro_garantia from "public" as "d_creditos";
grant insert on "d_creditos".pre_retiro_garantia to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_retiro_garantia to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_retiro_garantia to "w_creditos" as "d_creditos";

revoke all on "d_creditos".pre_retiro_garantia_h from "public" as "d_creditos";
grant insert on "d_creditos".pre_retiro_garantia_h to "w_creditos" as "d_creditos";
grant select on "d_creditos".pre_retiro_garantia_h to "w_creditos" as "d_creditos";
grant update on "d_creditos".pre_retiro_garantia_h to "w_creditos" as "d_creditos";
