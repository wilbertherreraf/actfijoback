select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Cambia el tipo de dato de la llave de la tabla gen_parametro 
         -- FECHA: 2025-01-17
         -- SDAPO: 2326078
         -- USUARIO: Mabel Ramos
         -- ***********************************************************************
from systables limit 1;

ALTER TABLE creditos:d_creditos.gen_parametro DROP CONSTRAINT pk_gen_parametro;

ALTER TABLE creditos:d_creditos.gen_parametro MODIFY (par_codpar serial8);

ALTER TABLE d_creditos.gen_parametro MODIFY par_codpar SERIAL(2035);

ALTER TABLE d_creditos.gen_parametro ADD CONSTRAINT PRIMARY KEY (par_codpar);



revoke all on "d_creditos".gen_parametro from "public" as "d_creditos";
grant insert on "d_creditos".gen_parametro to "w_creditos" as "d_creditos";
grant select on "d_creditos".gen_parametro to "w_creditos" as "d_creditos";
grant update on "d_creditos".gen_parametro to "w_creditos" as "d_creditos";