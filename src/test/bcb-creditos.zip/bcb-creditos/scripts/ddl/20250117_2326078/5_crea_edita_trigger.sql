select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Modifica trigger pu_h_pre_prestamos que registra el estado de autorizacion de los parametros.
		 --              Crea un nuevo trigger para la tabla gen_parametro_hist
         -- FECHA: 23-01-2025
         -- SDAPO: 2326078
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;



DROP TRIGGER IF EXISTS "d_creditos".tu_h_pre_prestamos;

CREATE TRIGGER "d_creditos".tu_h_pre_prestamos
UPDATE ON "d_creditos".pre_prestamos
REFERENCING OLD AS o_upd NEW AS n_upd
FOR EACH ROW
(
    EXECUTE PROCEDURE "d_creditos".pu_h_pre_prestamos(
        o_upd.pre_codcred, o_upd.pre_codmod, o_upd.pre_codprod, o_upd.pre_codcli, o_upd.pre_codmon,
        o_upd.pre_descrip, o_upd.pre_numcontra, o_upd.pre_tasapac, o_upd.pre_monto, o_upd.pre_monliqent,
        o_upd.pre_saldo, o_upd.pre_montsusp, o_upd.pre_tabtiprubro, o_upd.pre_tiprubro, o_upd.pre_tabdestcred,
        o_upd.pre_destcred, o_upd.pre_descrdcr, o_upd.pre_tabstatus, o_upd.pre_status, o_upd.pre_tabmethodcapi,
        o_upd.pre_methodcapi, o_upd.pre_tabunidplaz, o_upd.pre_unidplaz, o_upd.pre_fecreg, o_upd.pre_fecemi,
        o_upd.pre_fecplzven, o_upd.pre_fecprimpag, o_upd.pre_feculttrx, o_upd.pre_feclimite, o_upd.pre_numconv,
        o_upd.pre_numresol, o_upd.pre_nroperiodos, o_upd.pre_nrogracia, o_upd.pre_nropagos, o_upd.pre_diasfijoper,
        o_upd.pre_tabstatreg, o_upd.pre_statreg, o_upd.pre_tabtrxstaau, o_upd.pre_trxstaau, o_upd.pre_auditusr,
        o_upd.pre_auditfho, o_upd.pre_auditwst, o_upd.pre_estado_parametros,
        n_upd.pre_codcred, n_upd.pre_codmod, n_upd.pre_codprod, n_upd.pre_codcli, n_upd.pre_codmon,
        n_upd.pre_descrip, n_upd.pre_numcontra, n_upd.pre_tasapac, n_upd.pre_monto, n_upd.pre_monliqent,
        n_upd.pre_saldo, n_upd.pre_montsusp, n_upd.pre_tabtiprubro, n_upd.pre_tiprubro, n_upd.pre_tabdestcred,
        n_upd.pre_destcred, n_upd.pre_descrdcr, n_upd.pre_tabstatus, n_upd.pre_status, n_upd.pre_tabmethodcapi,
        n_upd.pre_methodcapi, n_upd.pre_tabunidplaz, n_upd.pre_unidplaz, n_upd.pre_fecreg, n_upd.pre_fecemi,
        n_upd.pre_fecplzven, n_upd.pre_fecprimpag, n_upd.pre_feculttrx, n_upd.pre_feclimite, n_upd.pre_numconv,
        n_upd.pre_numresol, n_upd.pre_nroperiodos, n_upd.pre_nrogracia, n_upd.pre_nropagos, n_upd.pre_diasfijoper,
        n_upd.pre_tabstatreg, n_upd.pre_statreg, n_upd.pre_tabtrxstaau, n_upd.pre_trxstaau, n_upd.pre_auditusr,
        n_upd.pre_auditfho, n_upd.pre_auditwst, n_upd.pre_estado_parametros
    )
);

       

DROP TRIGGER IF EXISTS "d_creditos".tu_h_gen_parametro;

CREATE TRIGGER "d_creditos".tu_h_gen_parametro
    UPDATE ON "d_creditos".gen_parametro
    REFERENCING OLD AS o_upd NEW AS n_upd
    FOR EACH ROW
(
    EXECUTE PROCEDURE "d_creditos".pu_h_gen_parametro(
        o_upd.par_codpar, o_upd.par_codcred, o_upd.par_codmod, o_upd.par_parametro,
        o_upd.par_tprcod, o_upd.par_tabestado, o_upd.par_estado, o_upd.par_auditusr,
        o_upd.par_auditfho, o_upd.par_auditwst, o_upd.cambio_bd,
        n_upd.par_codpar, n_upd.par_codcred, n_upd.par_codmod, n_upd.par_parametro,
        n_upd.par_tprcod, n_upd.par_tabestado, n_upd.par_estado, n_upd.par_auditusr,
        n_upd.par_auditfho, n_upd.par_auditwst, n_upd.cambio_bd
    )
);