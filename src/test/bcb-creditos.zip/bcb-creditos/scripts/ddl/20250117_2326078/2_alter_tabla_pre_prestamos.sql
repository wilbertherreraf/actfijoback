select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Adiciona columna estado_parametros en la tabla pre_prestamos que registra el estado de autorizacion de los parametros registrados.
         -- FECHA: 23-01-2025
         -- SDAPO: 2326078
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 

ALTER TABLE d_creditos.pre_prestamos ADD pre_estado_parametros INTEGER DEFAULT 1 BEFORE cambio_bd;

ALTER TABLE d_creditos.pre_prestamos_h ADD pre_estado_parametros INTEGER;
