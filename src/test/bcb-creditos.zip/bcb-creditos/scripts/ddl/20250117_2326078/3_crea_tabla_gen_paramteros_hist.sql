select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea tabla gen_parametro_hist para registrar el historico de la tabla gen_paramteros.
         -- FECHA: 23-01-2025
         -- SDAPO: 2326078
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 
 
 
DROP TABLE IF EXISTS gen_parametro_hist;

CREATE TABLE d_creditos.gen_parametro_hist(
    hist_id serial NOT NULL, 
    par_codpar int NOT NULL, 
    par_codcred int NOT NULL,
    par_codmod int NOT NULL,
    par_parametro varchar(70) NOT NULL,
    par_tprcod int NOT NULL,
    par_tabestado int NOT NULL,
    par_estado int NOT NULL,
    par_auditusr varchar(15),
    par_auditfho datetime year to second,
    par_auditwst varchar(20),
    cambio_bd varchar(250),
    historial_auditusr varchar(15),
    historial_auditfho datetime  year to second,
    historial_auditwst varchar(20),
    accion varchar(10) NOT NULL, 
    PRIMARY KEY (hist_id)  
);

revoke all on "d_creditos".gen_parametro_hist from "public" as "d_creditos";
grant insert on "d_creditos".gen_parametro_hist to "w_creditos" as "d_creditos";
grant select on "d_creditos".gen_parametro_hist to "w_creditos" as "d_creditos";
grant update on "d_creditos".gen_parametro_hist to "w_creditos" as "d_creditos";
