DROP PROCEDURE IF EXISTS "d_creditos".f_periodo_fechafin_365;


create function "d_creditos".f_periodo_fechafin_365(p_fechaini date , p_nroperiodos integer, p_unidplaz integer, NRODIASPERIODO integer, INPUT_PERIOD_BASE integer, p_codcred integer)
-- calcula la ultima fecha segun el nr de periodos
    returning date
	
-- DESCRIPCION: calcula la ultima fecha segun el nr de periodos 
-- PARAMETROS INGRESO: p_codcred integer, p_codmod integer, p_fecha date, p_statrepro integer
--                     


-- PARAMETROS SALIDA:  date, date, date, date, date
-- AUTOR: 
-- CREACION: 

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
-----------------------------------------------------------------------------------------------------------------------------------------------------
--|           |               |          | calcula la ultima fecha segun el nr de periodos 
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  13-10-2025   | 2333600  | Ajustes en el procedimiento para a�adir el calculo de plan de pagos para creditos de 365 dias
-----------------------------------------------------------------------------------------------------------------------------------------------------
    
    define V_YY_OUT, V_MM_OUT, V_DD_OUT integer;
    define fecha_ini, fecha_fin, ST_D_PERIODHABIL, END_D_PERIODHABIL date;
    define C_INPUT_PERIOD_EXACT, MONTHSPERPERIOD integer;
    define v_step, v_iniper, v_finper, i, v_numpers, DR_REPMTS_PER_YEAR_OUT integer;
    define ST_D_PERIOD, END_D_PERIOD date;
   
    
    let C_INPUT_PERIOD_EXACT = 3;
    let v_numpers = 0;
    let fecha_fin = p_fechaini;
    let fecha_ini = null;
    let INPUT_PERIOD_BASE = nvl(INPUT_PERIOD_BASE, C_INPUT_PERIOD_EXACT);
    let v_iniper = 1;
    let v_step = 1;
    let v_finper = p_nroperiodos;
    
    if nvl(p_nroperiodos, 0) = 0 then
        return p_fechaini;
    end if
    
    if nvl(p_nroperiodos, 0) < 0 then
        let v_iniper = abs(p_nroperiodos);
        let v_finper = 1;
        let v_step = -1;
    end if
    
    if p_unidplaz in (1,7) and nvl(abs(p_nroperiodos), 0) > 0 and nvl(NRODIASPERIODO,0) > 0 then
        -- menos un periodo
        if nvl(p_nroperiodos, 0) < 0 then
            let fecha_fin = p_fechaini - (abs(p_nroperiodos)) * NRODIASPERIODO;
        else
            let fecha_fin = p_fechaini + (p_nroperiodos - 1) * NRODIASPERIODO;
        end if
    else

    	-- para creditos de 365 dias
    	if (select mtp_intydias from d_creditos.pre_tasaspre where mtp_codcred=p_codcred)=365 then
        		let p_nroperiodos = p_nroperiodos+1;
        end if
    
        for i = 1 to nvl(abs(p_nroperiodos), 0) 
            
            call f_infoperiodo( fecha_ini, fecha_fin, p_unidplaz, INPUT_PERIOD_BASE) returning MONTHSPERPERIOD, ST_D_PERIOD, END_D_PERIOD;
           
            if nvl(p_nroperiodos, 0) < 0 then
                let fecha_fin = ST_D_PERIOD + 1;
                let fecha_ini = null;            
            else
                let fecha_fin = END_D_PERIOD;
                let fecha_ini = END_D_PERIOD + 1;
            end if
        end for
    end if
    return fecha_fin;
end function;                











