DROP PROCEDURE IF EXISTS d_creditos.p_generar_renglon_bonos;

CREATE PROCEDURE d_creditos.p_generar_renglon_bonos (p_idtabla integer, p_codcmp integer, p_centro integer, p_cmp_tipo varchar(1),
                                               p_cmp_nro varchar(7), p_nro_renglon integer, p_codcred integer, p_codmod integer,
                                               p_gestion integer, p_nro_periodo integer, p_nro_dia integer)    
    returning boolean as resultado; 
    
         -- DESCRIPCION: Procedimiento para registrar los renglones de las cuentas DEBE y HABER en el COIN
         -- PARAMETROS INGRESO:   p_idtabla integer                     ID tabla
         --                       p_codcmp integer                      Codigo de comprobante
         --                       p_centro integer                      Centro COIN
         --                       p_cmp_tipo varchar(1)                 Tipo Comprobante
         --                       p_cmp_nro varchar(7)                  Nro. comprobante
         --                       p_nro_renglon integer                 Nro. renglon
         --                       p_codcred integer                     Codigo de credito        
         --                       p_codmod integer                      Codigo de modulo
         --                       p_gestion integer                     Gestion (anio)
         --                       p_nro_periodo integer                 Periodo
         --                       p_nro_dia integer                     dia        
         -- PARAMETROS SALIDA:
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: CREDITOS (gen_renglon)
         --               CONTBCB (reng_comprob)      
         -- CREACION:  06-02-2025
         -- SDAPO: 2344735
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO     |  Descripcion
---------------------------------------------------------------------------------------------------------------------------------------
--|  mcramos  |  19-03-2025   |  2352035  | Ajuste para actualizar la glosa se debe y haber en registro de desembolso
---------------------------------------------------------------------------------------------------------------------------------------   
--|  mcramos  |  05-03-2025   |  2367989  | Ajuste para generacion de reglon en registro de Custodia de Garantia
---------------------------------------------------------------------------------------------------------------------------------------
--|  mcramos  |  28-03-2025   |  2368094  | Ajuste para generacion de reglon en registro de Retiro de Garantia
---------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  06-05-2025   | 2401886   | Ajuste para generacion de comprobante para registro contable de Pago de Cuota
---------------------------------------------------------------------------------------------------------------------------------------      
--| acanqui   |  10-06-2025   | 2471161   | Ajuste para implementar la imputacion presupuestaria posterior a la generacion de comprobante del registro contable de Pago de Cuota
---------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  11-06-2025   | 2440644   | Ajuste para implementar el registro CRV SIGMA posterior a la generacion del comprobante del registro de desembolso
---------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  14-07-2025   | 2510352   | Ajuste para implementar la imputacion presupuestaria posterior a la generacion de comprobante del registro contable de Pago de Cuota tipo R
---------------------------------------------------------------------------------------------------------------------------------------


   


-- variables

    define W_ESTADO_HABILITADO         integer;
    define MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS integer;
    define YACIMIENTOS_PETROLIFEROS_FISCALES_BOLIVIANOS integer;
    define FONDO_NACIONAL_DESARROLLO_REGIONAL integer;
     
    define w_cta_mov                   char(8);
    define w_prl_codprl                integer;
    define w_cpr_nro_reng_cp           integer;
    define w_ctp_codctp                integer;
    define w_delim_pos                 integer;
    DEFINE w_parametros_glosa          VARCHAR(255);
    DEFINE w_par_glosa                 VARCHAR(255);
    define w_start_index               integer;     
    define w_end_index                 integer; 
    define w_nro_parametro             integer;
        
--Variables renglon
    
    define w_rln_codrln                 like gen_renglon.rln_codrln;
    define w_rln_scr_ctamov             like gen_renglon.rln_scr_ctamov;
    define w_rln_partpr_ctamov          like gen_renglon.rln_partpr_ctamov;
    define w_rln_ctamov_default         like gen_renglon.rln_ctamov_default;
    define w_rln_dh                     like gen_renglon.rln_dh; 
    
    define w_rln_scr_monto_mo           like gen_renglon.rln_scr_monto_mo;
    define w_rln_partpr_monto_mo        like gen_renglon.rln_partpr_monto_mo;
    define w_rln_monto_mo_default       like gen_renglon.rln_monto_mo_default;
    
    define w_rln_scr_glosa              like gen_renglon.rln_scr_glosa;
    define w_rln_partpr_glosa           like gen_renglon.rln_partpr_glosa;
    define w_rln_glosa_default          like gen_renglon.rln_glosa_default;
    
    define w_rln_glosa_con_param        like gen_renglon.rln_glosa_con_param;
    define w_rln_glosa                  like gen_renglon.rln_glosa;
    
    define w_rln_tiene_cp               like gen_renglon.rln_tiene_cp;    
    define w_rln_estado                 like gen_renglon.rln_estado;    

    define w_cta_mov_moneda             varchar(6);
   
--Variables Certificacion Presupuestaria
 
    define w_ctp_scr_imp                like gen_certpres.ctp_scr_imp;   --source nro imputacion (cp)  
    define w_ctp_partpr_imp             like gen_certpres.ctp_partpr_imp;                     
    define w_ctp_default_imp            like gen_certpres.ctp_default_imp;
   
    define w_ctp_scr_cp                 like gen_certpres.ctp_scr_cp;
    define w_ctp_partpr_cp              like gen_certpres.ctp_partpr_cp;
    define w_ctp_cp_default             like gen_certpres.ctp_cp_default;

    define w_ctp_scr_cp_monto_mn        like gen_certpres.ctp_scr_monto_mn; 
    define w_ctp_partpr_cp_monto_mn     like gen_certpres.ctp_partpr_monto_mn;            
    define w_ctp_cp_default_monto_mn    like gen_certpres.ctp_default_monto_mn;
    
    define w_ctp_scr_cp_gestion         like gen_certpres.ctp_scr_gestion;
    define w_ctp_partpr_cp_gestion      like gen_certpres.ctp_partpr_gestion;
    define w_ctp_cp_gestion_default     like gen_certpres.ctp_gestion_default;
    
    define w_ctp_scr_cp_uor             like gen_certpres.ctp_scr_uor;
    define w_ctp_partpr_cp_uor          like gen_certpres.ctp_partpr_uor;
    define w_ctp_cp_uor_default         like gen_certpres.ctp_uor_default;
    
    define w_ctp_scr_cp_rfa             like gen_certpres.ctp_scr_rfa;
    define w_ctp_partpr_cp_rfa          like gen_certpres.ctp_partpr_rfa;
    define w_ctp_cp_rfa_default         like gen_certpres.ctp_rfa_default;
    
    define w_ctp_scr_cp_top             like gen_certpres.ctp_scr_top;
    define w_ctp_partpr_cp_top          like gen_certpres.ctp_partpr_top;
    define w_ctp_cp_top_default         like gen_certpres.ctp_top_default;
    define w_ctp_estado                 like gen_certpres.ctp_estado;    
    
--- variables de para el renglones

     define w_prl_nro_mayor             like contbcb@bcbux02:d_conta.reng_comprob.nro_mayor;   
     define w_prl_nro_afectable         like contbcb@bcbux02:d_conta.reng_comprob.nro_afectable;        
     define w_prl_monto_mo              like contbcb@bcbux02:d_conta.reng_comprob.monto_mo;
     define w_prl_factor_conv_mo_mn     like contbcb@bcbux02:d_conta.reng_comprob.factor_conv_mo_mn;    
     define w_prl_monto_mn              like contbcb@bcbux02:d_conta.reng_comprob.monto_mn;    
     define w_prl_nro_reng_esq          like contbcb@bcbux02:d_conta.reng_comprob.nro_reng_esq;

     define w_monto_mo          like contbcb@bcbux02:d_conta.reng_comprob.monto_mo;
     define w_factor_conv_mo_mn like contbcb@bcbux02:d_conta.reng_comprob.factor_conv_mo_mn; 
     define w_glosa_reng        like contbcb@bcbux02:d_conta.reng_comprob.glosa_reng;
     define w_nro_mayor         like contbcb@bcbux02:d_conta.reng_comprob.nro_mayor;
     define w_nro_afectable     like contbcb@bcbux02:d_conta.reng_comprob.nro_afectable; 
     define w_nro_reng_esq      like contbcb@bcbux02:d_conta.reng_comprob.nro_reng_esq; 
     define w_monto_mn          like contbcb@bcbux02:d_conta.reng_comprob.monto_mn;
     
     define w_char_prl_monto_mo varchar(20);
     

-- Variables para el manejo de los renglones del comprobante
     define w_nro_renglones     integer;
     define w_rln_numero        like gen_renglon.rln_numero;
     define w_glosa             varchar(255);

--Variables Cerificacion Presupuestaria

     define w_cp_imp           VARCHAR(20);
     define w_cp               VARCHAR(20);
     define w_cp_cta           INTEGER;
     define w_cp_monto_mn      VARCHAR(20);
     define w_cp_renglon       INTEGER;      
     define w_cp_gestion       VARCHAR(20);
     define w_cp_uor           VARCHAR(20); 
     define w_cp_rfa           VARCHAR(20);
     define w_cp_top           VARCHAR(20); 
    
     define w_array_glosa      VARCHAR(200);
     define w_codigo_cliente   INTEGER;
     define w_pago_importe_capital DECIMAL (20,2);
     define w_intereses_gestion_anterior DECIMAL (20,2);
     define w_nro_renglon_aux INTEGER;
    
     define x_imp_sigma  	  INTEGER;
     define w_tipo_sigma      VARCHAR(20);
    
     define W_IMP_PRESUP_PAGO_CUOTA	  INTEGER;

    /*define v_pathlog varchar(250); -- log
    let v_pathlog = 'p_generar_renglon_bonos.log'; -- log
    SET DEBUG FILE TO v_pathlog; -- log*/

  
--  inicializacion de variables
    let W_ESTADO_HABILITADO = 1;
    let MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS=7;
    let YACIMIENTOS_PETROLIFEROS_FISCALES_BOLIVIANOS=2;
    let FONDO_NACIONAL_DESARROLLO_REGIONAL=10;
    let w_codigo_cliente=0;
    let w_nro_renglon_aux=0;
    let x_imp_sigma=0;
    let W_IMP_PRESUP_PAGO_CUOTA=4;
       
--  Validar parametros

    if p_codcmp is null or p_codcmp <=0 then
       Raise Exception -746, 0, "[ERR_PGR_001] - El valor proporcionado para el parametro c?digo de comprobante no es valido (p_codcmp).";
    end if   

    if p_centro is null or p_centro <=0 then
       Raise Exception -746, 0, "[ERR_PGR_002] - El valor proporcionado para el parametro centro no es valido (p_centro).";
    end if   

    if p_cmp_tipo is null or length(trim(p_cmp_tipo)) = 0 then
       Raise Exception -746, 0, "[ERR_PGR_003] - El valor proporcionado para el parametro tipo comprobante no es valido (p_cmp_tipo).";
    end if   

    if p_nro_renglon is null or p_nro_renglon <=0 then
       Raise Exception  -746, 0, "[ERR_PGR_004] - El valor proporcionado para el parametro n?mero de renglon no es valido (p_nro_renglon).";
    end if  
 
    if p_cmp_nro is null or length(trim(p_cmp_nro)) = 0 then
       Raise Exception -746, 0, "[ERR_PGR_005] - El valor proporcionado para el parametro n?mero comprobante no es valido (p_cmp_nro).";
    end if   
    
    if p_codcred is null or p_codcred <=0 then
       Raise Exception  -746, 0, "[ERR_PGR_006] - El valor proporcionado para el parametro c?digo de cr?dito no es valido (p_codcred).";
    end if   

    if p_codmod is null or p_codmod <=0 then
       Raise Exception  -746, 0, "[ERR_PGR_007] - El valor proporcionado para el parametro m?dulo del cr?dito no es valido (p_codmod).";
    end if   
    

		 -- obtener parametros del renglon especificado
        call d_creditos.p_get_par_renglon (p_codcmp, p_nro_renglon)    returning w_rln_codrln,
                                                                                 w_rln_scr_ctamov, w_rln_partpr_ctamov, w_rln_ctamov_default, w_rln_dh,         
                                                                                 w_rln_scr_monto_mo, w_rln_partpr_monto_mo, w_rln_monto_mo_default,
                                                                                 w_rln_scr_glosa, w_rln_partpr_glosa, w_rln_glosa_default, 
                                                                                 w_rln_glosa_con_param, w_rln_glosa,
                                                                                 w_rln_tiene_cp, w_rln_estado;

                                                                                
                                                         
        if not w_rln_estado = W_ESTADO_HABILITADO then
           Raise Exception  -746, 0, "[ERR_PGC_008] - El renglon especificado no esta habilitado.";
        end if
        
            -- con esta consulta obtenemos el numero de cuenta dl debe y haber
                select par_parametro
                        into w_cta_mov
                        from gen_parametro 
                        where par_codcred = p_codcred
                          and par_codmod  = p_codmod
                          and par_tprcod=w_rln_partpr_ctamov;
                          
                        if dbinfo ("sqlca.sqlerrd2") = 0 then
                               Raise Exception  -746, 0, "[ERR_PGC_008] - No se enuentra registrado en numero de cuenta para el credito "|| p_codcred; 
                         end if;           
                       
                        
                        let w_cta_mov_moneda = "69"; --moneda por defecto en bolivianos de acuerdo a lo indicado por usuario        
                        let w_delim_pos = INSTR(w_cta_mov, '-');        

                        IF w_delim_pos > 0 THEN   ---viene con la moneda 
                           let w_cta_mov = SUBSTR(w_cta_mov, 1, w_delim_pos - 1);        
                           let w_cta_mov_moneda = "";
                           let w_cta_mov_moneda = SUBSTR(w_cta_mov, w_delim_pos + 1);
                        END IF;
                

                        --obtener el mayor y cuenta afectable a partir de la cuenta de movimiento y p_centro
                        call contbcb@bcbux02:c_conta.nro_afect_mayor (w_cta_mov, w_cta_mov_moneda, p_centro) returning w_prl_nro_afectable, w_prl_nro_mayor;



        --obtener el  tipo de cambio (factor conversion) de la moneda de la cuenta afectable 
        select factor into w_prl_factor_conv_mo_mn from contbcb@bcbux02:d_conta.factor_conv_mn where cod_moneda = w_cta_mov_moneda and fecha_dia = mdy(p_nro_periodo,p_nro_dia,p_gestion);

       
       -- obtenemos el codigo del cliente del credito w_codigo_cliente
       	  select pre_codcli 
       	  into w_codigo_cliente 
          from d_creditos.pre_prestamos 
          where pre_codcred=p_codcred and pre_codmod=p_codmod; 

       -- obtenemos los valores de la glosa para las cuentas del DEBE y HABER  de acuerdo al tipo de operacion
       if p_codcmp=8 then -- registro transitorio de garantias
       
               select valor_total_garantia, (numero_desembolso||'|'||(select par_parametro from d_creditos.gen_parametro where par_codcred=codcred and par_codmod=codmod and par_tprcod=42 )) as parametros
                   into w_char_prl_monto_mo, w_array_glosa
                   from d_creditos.pre_registrogarantias
               where id= p_idtabla;
              
       elif p_codcmp=1 then -- registro de desembolsos EPNES
                        
                        SELECT monto_desembolsar, 
                                       CASE 
                                           WHEN p_nro_renglon = 1 THEN 
                                               
                                                   COALESCE((select count(*) from d_creditos.pre_desemb where dsb_codcred= codcred and dsb_codmod=codmod), 0) || '|' ||  -- total desembolsos
                                               COALESCE((SELECT par_parametro 
                                                         FROM d_creditos.gen_parametro 
                                                         WHERE par_codcred = pdd.codcred 
                                                           AND par_codmod = pdd.codmod 
                                                           AND par_tprcod = 42), 'S/D') -- descripcion corta
                                           WHEN p_nro_renglon = 2 THEN 
                                               COALESCE((SELECT par_parametro 
                                                         FROM d_creditos.gen_parametro 
                                                         WHERE par_codcred = pdd.codcred 
                                                           AND par_codmod = pdd.codmod 
                                                           AND par_tprcod = 2), '0') || '|' || -- cuenta haber
                                               COALESCE((select count(*) from d_creditos.pre_desemb where dsb_codcred= codcred and dsb_codmod=codmod), 0) || '|' || -- total desembolsos
                                               COALESCE((SELECT par_parametro 
                                                         FROM d_creditos.gen_parametro 
                                                         WHERE par_codcred = pdd.codcred 
                                                           AND par_codmod = pdd.codmod 
                                                           AND par_tprcod = 42), 'S/D')  -- descripcion corta
                                       END AS parametros
                                INTO w_char_prl_monto_mo, w_array_glosa
                                FROM d_creditos.pre_desembolso_detalle pdd
                                WHERE id =p_idtabla;
           
       elif p_codcmp=2 then -- registro de desembolsos MEFP
           
                                SELECT monto_desembolsar, 
                                       CASE 
                                           WHEN p_nro_renglon = 1 THEN 
                                                           COALESCE((select count(*) from d_creditos.pre_desemb where dsb_codcred= codcred and dsb_codmod=codmod), 0) || '|' ||  -- total desembolsos
                                               COALESCE((SELECT par_parametro 
                                                         FROM d_creditos.gen_parametro 
                                                         WHERE par_codcred = pdd.codcred 
                                                           AND par_codmod = pdd.codmod 
                                                           AND par_tprcod = 42), 'S/D')  -- descripcion corta
                                           WHEN p_nro_renglon = 2 THEN 
                                               numero_libreta || '|' ||  -- numero libreta
                                               descripcion_libreta || '|' || -- descripcion libreta
                                               
                                               COALESCE((SELECT par_parametro 
                                                         FROM d_creditos.gen_parametro 
                                                         WHERE par_codcred = pdd.codcred 
                                                           AND par_codmod = pdd.codmod 
                                                           AND par_tprcod = 2), '0') || '|' ||  -- cuenta haber
                                               COALESCE((select count(*) from d_creditos.pre_desemb where dsb_codcred= codcred and dsb_codmod=codmod), 0) || '|' ||  -- total desembolsos            
                                               COALESCE((SELECT par_parametro 
                                                         FROM d_creditos.gen_parametro 
                                                         WHERE par_codcred = pdd.codcred 
                                                           AND par_codmod = pdd.codmod 
                                                           AND par_tprcod = 42), 'S/D')   -- descripcion corta
                                       END AS parametros
                                INTO w_char_prl_monto_mo, w_array_glosa
                                FROM d_creditos.pre_desembolso_detalle pdd
                                WHERE id =  p_idtabla;

        elif  p_codcmp=9 then -- registro custodia de garantia
				SELECT valor_total_garantia,
				       CASE
				           WHEN p_nro_renglon = 1 THEN

				          COALESCE((select count(1) from table (f_pp_saldos_pend(pcg.codcred ,pcg.codmod ,pcg.dsb_coddsb ,NULL ,NULL ,2 ))), 0)|| '|' || --total de bonos
				               COALESCE((SELECT gard_claveserie from d_creditos.pre_garantiad where gard_codmod=pcg.codmod and gard_codcred=pcg.codcred and gard_coddsb=pcg.dsb_coddsb), 'S/D') -- Numero de Serie del desembolso
				           WHEN p_nro_renglon = 2 THEN
				               COALESCE((select count(1) from table (f_pp_saldos_pend(pcg.codcred ,pcg.codmod ,pcg.dsb_coddsb ,NULL ,NULL ,2 ))), 0)|| '|' || --total de bonos
				               COALESCE((SELECT gard_claveserie from d_creditos.pre_garantiad where gard_codmod=pcg.codmod and gard_codcred=pcg.codcred and gard_coddsb=pcg.dsb_coddsb), 'S/D') -- Numero de Serie del desembolso
				       END AS parametros
				INTO w_char_prl_monto_mo, w_array_glosa
				FROM d_creditos.pre_custodia_garantia pcg
				WHERE id =p_idtabla;

                                
       elif  p_codcmp=10 then -- registro retiro de garantia
                                SELECT valor_cuota,
                                       CASE
                                           WHEN p_nro_renglon = 1 THEN
											   COALESCE((SELECT gard_claveserie from d_creditos.pre_garantiad where gard_codmod=prg.codmod and gard_codcred=prg.codcred and gard_coddsb=prg.coddsb), 'S/D') || '|' || -- Numero de Serie del desembolso
                                               COALESCE((select cuota from d_creditos.pre_retiro_garantia where id=prg.id), 0) --nro cuota
                                           WHEN p_nro_renglon = 2 THEN
											   COALESCE((SELECT gard_claveserie from d_creditos.pre_garantiad where gard_codmod=prg.codmod and gard_codcred=prg.codcred and gard_coddsb=prg.coddsb), 'S/D') || '|' || -- Numero de Serie del desembolso
                                               COALESCE((select cuota from d_creditos.pre_retiro_garantia where id=prg.id), 0) --nro cuota
                                       END AS parametros
                                INTO w_char_prl_monto_mo, w_array_glosa
                                FROM d_creditos.pre_retiro_garantia prg
                                WHERE id = p_idtabla;
                               
       elif p_codcmp in (4,5,6,7) then -- registro contable pago de deuda


                	-- obtenemos el valor de importe pago capital para verificar cuales son las glosas que se generaran
            	    select pago_importe_capital 
	        		into w_pago_importe_capital 
     		     	from d_creditos.pre_pagocuota  
		            where id=p_idtabla; 
                
		                if w_pago_importe_capital!=0 then -- para este caso se toman en cuenta 4 renglones
		                
		                		SELECT case
	                					   when p_nro_renglon = 1 then pc.total_cuota_vencimiento 
	                					   when p_nro_renglon = 2 then pc.pago_importe_capital
	                					   when p_nro_renglon = 3 then pc.intereses_gestion_anterior
	                					   when p_nro_renglon = 4 then pc.intereses_gestion_actual
                					   end as valor_total_garantia,
                				
                                       CASE -- array de parametros
                                           WHEN p_nro_renglon = 1 THEN
                                                COALESCE(TO_CHAR(pc.fecha_vencimiento, '%d/%m/%Y'), 'NULL') --fecha vencimiento
                                                
                                           WHEN p_nro_renglon = 3 then
                                           		COALESCE(TO_CHAR((YEAR(pc.fecha_vencimiento)-1)), 'NULL')
                                           		
                                           WHEN p_nro_renglon = 4 then
                                           		DAY(pc.fecha_vencimiento) || ' DE ' ||
															    CASE MONTH(pc.fecha_vencimiento)
															        WHEN 1 THEN 'ENERO' WHEN 2 THEN 'FEBRERO' WHEN 3 THEN 'MARZO' WHEN 4 THEN 'ABRIL' WHEN 5 THEN 'MAYO' WHEN 6 THEN 'JUNIO'
															        WHEN 7 THEN 'JULIO' WHEN 8 THEN 'AGOSTO'  WHEN 9 THEN 'SEPTIEMBRE' WHEN 10 THEN 'OCTUBRE' WHEN 11 THEN 'NOVIEMBRE' WHEN 12 THEN 'DICIEMBRE'
															    END || ' DE ' || YEAR(pc.fecha_vencimiento)
															   
										   					    
                                                                   
                                       END AS parametros
                                INTO w_char_prl_monto_mo, w_array_glosa
                                FROM d_creditos.pre_pagocuota  pc
                                WHERE id =p_idtabla;
		                	
		                end if
		                
		                if w_pago_importe_capital=0 then -- para este caso se toman en cuenta 3 renglones

		                		SELECT case
	                					   when p_nro_renglon = 1 then pc.pago_importe_intereses	
	                					   when p_nro_renglon = 2 then pc.intereses_gestion_anterior
	                					   when p_nro_renglon = 3 then pc.intereses_gestion_actual
                					   end as valor_total_garantia,
                					   
                                       CASE -- array de parametros
                                           WHEN p_nro_renglon = 1 THEN
                                               COALESCE(TO_CHAR(pc.fecha_vencimiento, '%d/%m/%Y'), 'NULL') --fecha vencimiento
                                                           
										   WHEN p_nro_renglon = 2 then
                                           		COALESCE(TO_CHAR((YEAR(pc.fecha_vencimiento)-1)), 'NULL')
                                           
                                           WHEN p_nro_renglon = 3 then
                                           		DAY(pc.fecha_vencimiento) || ' DE ' ||
															    CASE MONTH(pc.fecha_vencimiento)
															        WHEN 1 THEN 'ENERO' WHEN 2 THEN 'FEBRERO' WHEN 3 THEN 'MARZO' WHEN 4 THEN 'ABRIL' WHEN 5 THEN 'MAYO' WHEN 6 THEN 'JUNIO'
															        WHEN 7 THEN 'JULIO' WHEN 8 THEN 'AGOSTO'  WHEN 9 THEN 'SEPTIEMBRE' WHEN 10 THEN 'OCTUBRE' WHEN 11 THEN 'NOVIEMBRE' WHEN 12 THEN 'DICIEMBRE'
															    END || ' DE ' || YEAR(pc.fecha_vencimiento)		
                                                                   
                                       END AS parametros
                                INTO w_char_prl_monto_mo, w_array_glosa
                                FROM d_creditos.pre_pagocuota  pc
                                WHERE id =p_idtabla;
		                
		                end if
		                
		                 
		                
		                
                			
       end if
              
        if w_char_prl_monto_mo is null then
           Raise Exception  -746, 0, "[ERR_PGR_010] - Monto para el renglon no es valido o no se parametrizo." || p_idtabla || "," || w_rln_scr_monto_mo || "," || w_rln_partpr_monto_mo;
        end if

         
        let w_prl_monto_mo = cast(w_char_prl_monto_mo as decimal (15,2));
        let w_prl_monto_mn = w_prl_monto_mo * w_prl_factor_conv_mo_mn;
        let w_prl_nro_reng_esq = null;
        
       
       -- aqui obtenemos los paramteros de la glosa para las cuentas del DEBE y HABER  -- {#P1} DESEMBOLSO DEL CR?DITO OTORGADO PARA LA {#P2}
        select rln_glosa
        into w_parametros_glosa
        from d_creditos.gen_renglon
        where  rln_codcmp=p_codcmp
        and rln_numero=p_nro_renglon
        and rln_partpr_ctamov=w_rln_partpr_ctamov;
       

       
        -- (w_parametro_glosa) 
        if w_rln_glosa_con_param then --reemplazar parametros obtenidos en la glosa
           
        	-- obtiene la glosa por cuenta DEBE y HABER  -- w_rln_glosa -> 1 DESEMBOLSO DEL CR?DITO OTORGADO PARA LA 3er CRED. DE LIQUIDEZ - GESTI?N 2024 OTORGADO AL TGN.
        	LET w_rln_glosa = f_reemplazar_parametros_glosa(w_parametros_glosa,w_array_glosa);
        
        end if

        
        -- obtenemos el valor de intereses de la gestion anterior para ajustar el numero de renglon
        select intereses_gestion_anterior 
	    into w_intereses_gestion_anterior 
     	from d_creditos.pre_pagocuota  
		where id=p_idtabla;
		           
        -- codigo paara verificar que el renglon anterior es cero y ajustar el renglon posterior
        if p_codcmp in (4,5,6,7) then -- registro contable pago de deuda

        				-- codigo para obtener la certificacion presupuestaria por renglon  (codigo para la imputacion presupuestaria)
        				  let w_cp="";
		                  if w_pago_importe_capital!=0 then -- para este caso se toman en cuenta 4 renglones

		                		if p_nro_renglon=3 then
		                			select par_parametro into w_cp from gen_parametro where par_codcred =p_codcred and par_codmod =p_codmod and par_tprcod=26;  -- obtenemos el valor de la variable  w_cp para la imputacion presupuestaria
		 		                end if

		 		                if p_nro_renglon=4 then
		 		                	select par_parametro into w_cp from gen_parametro where par_codcred =p_codcred and par_codmod =p_codmod and par_tprcod=25; -- obtenemos el valor de la variable  w_cp para la imputacion presupuestaria
		                		end if

		                  end if

		                  if w_pago_importe_capital=0 then -- para ete caso se toman en cuenta 3 renglones

	 		                  	if p_nro_renglon=2 then
		                			select par_parametro into w_cp from gen_parametro where par_codcred =p_codcred and par_codmod =p_codmod and par_tprcod=26;  -- obtenemos el valor de la variable  w_cp para la imputacion presupuestaria
		 		                end if

		 		                if p_nro_renglon=3 then
		 		                	select par_parametro into w_cp from gen_parametro where par_codcred =p_codcred and par_codmod =p_codmod and par_tprcod=25;  -- obtenemos el valor de la variable  w_cp para la imputacion presupuestaria
		                		end if

		                  end if
		                -- fin codigo para la imputacion presupuestaria


        				-- codigo para ajustar el numero de renglon  en caso de que el interes de la gestion anterior sea igual a cero
		                if w_pago_importe_capital!=0 and p_nro_renglon=4 and w_intereses_gestion_anterior=0 then
		                	let w_nro_renglon_aux=p_nro_renglon;
		                	let p_nro_renglon=3;

		                	-- reasignamos el valor de la certificacion presupuestaria en caso de que el interes de la gestion anterior es igual a cero (codigo para la imputacion presupuestaria)
		                	select par_parametro into w_cp from gen_parametro where par_codcred =p_codcred and par_codmod =p_codmod and par_tprcod=25;  -- obtenemos el valor de la variable  w_cp para la imputacion presupuestaria

		                end if
		                if w_pago_importe_capital=0 and p_nro_renglon=3 and w_intereses_gestion_anterior=0 then
		                	let w_nro_renglon_aux=p_nro_renglon;
		                	let p_nro_renglon=2;

		                	-- reasignamos el valor de la certificacion presupuestaria en caso de que el interes de la gestion anterior es igual a cero (codigo para la imputacion presupuestaria)
		                	select par_parametro into w_cp from gen_parametro where par_codcred =p_codcred and par_codmod =p_codmod and par_tprcod=25;  -- obtenemos el valor de la variable  w_cp para la imputacion presupuestaria


		                end if
        end if


        
        
        if w_char_prl_monto_mo <>0 then
        	-- codigo para insertar los valores del renglon en la tabla 'reng_comprob' de la BD contbcb
        	insert into contbcb@bcbux02:d_conta.reng_comprob values (p_centro, p_cmp_tipo, p_cmp_nro, p_nro_renglon, w_rln_dh, w_prl_monto_mo, w_prl_factor_conv_mo_mn,
                                                 w_rln_glosa, w_prl_nro_mayor, w_prl_nro_afectable, w_prl_nro_reng_esq, w_prl_monto_mn);


			-- verifica que se haya registrado correctamente el renglon
	        if dbinfo ("sqlca.sqlerrd2") = 0 then  -- no hizo el insert
	         	Raise Exception -746, 0, "[ERROR_ESTADO_011] - No se pudo registrar el renglon -> "|| p_nro_renglon ||" del comprobante "|| p_cmp_nro ||" en la tabla reng_comprob. Revisar en COIN y SISCRED";
		    end if
		end if


--	    raise exception -746,0," DETENIDO  w_rln_codrln-> " || w_rln_codrln;


	    -- codigo para generar la imputacion presupuestaria solo para el modulo de PAGO DE CUOTA (codigo reutilizado del procedimiento p_generar_renglon)
	    if p_codcmp in (4,5,6,7) then

---	    		raise exception -746,0," DETENIDO  w_pago_importe_capital-> " || w_pago_importe_capital || " w_char_prl_monto_mo -> "||w_char_prl_monto_mo ||" w_prl_monto_mo -> "|| w_prl_monto_mo || " w_intereses_gestion_anterior -> "||w_intereses_gestion_anterior || " w_cp -> "||w_cp;

			    -- if w_rln_tiene_cp then --el renglon tiene certificacion presupuestaria
		           Foreach select ctp_nro_renglon into w_cpr_nro_reng_cp from d_creditos.gen_certpres where ctp_codrln = 1 and ctp_nro_renglon > 0
		                   call d_creditos.p_get_par_certpres(W_IMP_PRESUP_PAGO_CUOTA, w_cpr_nro_reng_cp) returning w_ctp_scr_imp, w_ctp_partpr_imp, w_ctp_default_imp,
		                                                                                                 w_ctp_scr_cp, w_ctp_partpr_cp, w_ctp_cp_default,
		                                                                                                 w_ctp_scr_cp_monto_mn, w_ctp_partpr_cp_monto_mn, w_ctp_cp_default_monto_mn,
		                                                                                                 w_ctp_scr_cp_gestion, w_ctp_partpr_cp_gestion, w_ctp_cp_gestion_default,
		                                                                                                 w_ctp_scr_cp_uor, w_ctp_partpr_cp_uor, w_ctp_cp_uor_default,
		                                                                                                 w_ctp_scr_cp_rfa, w_ctp_partpr_cp_rfa, w_ctp_cp_rfa_default,
		                                                                                                 w_ctp_scr_cp_top, w_ctp_partpr_cp_top, w_ctp_cp_top_default,
		                                                                                                 w_ctp_estado;

		                 -- Raise Exception  -746, 0, "[ERR_PGR_010] - La certificación presupuestaria  parametrizada no esta habilitada.";

		                   if not w_ctp_estado = W_ESTADO_HABILITADO then
		                       Raise Exception  -746, 0, "[ERR_PGR_010] - La certificación presupuestaria  parametrizada no esta habilitada.";
		                   end if

		                   --call f_get_parametro (p_proceso, w_ctp_scr_imp, w_ctp_partpr_imp, w_ctp_default_imp, p_codcred, p_codmod)  returning w_cp_imp;
		                   let w_cp_imp=w_ctp_default_imp;




		                  -- codigo original
		                   /*let w_delim_pos = INSTR(w_cp, '-');
		                   IF w_delim_pos > 0 THEN
		                      let w_cp_cta = SUBSTR(w_cp, 1, w_delim_pos - 1);
		                      let w_cp_renglon = "";
		                      let w_cp_renglon = SUBSTR(w_cp, w_delim_pos + 1);
		                   else
		                      Raise Exception  -746, 0, "[ERR_PGR_011] - La certificación presupuestaria  no esta parametrizada o formato incorrecto." || w_cp|| "<-";
		                   END IF;

		                   if w_cp_cta is null or w_cp_renglon is null or w_cp_cta = 0 or w_cp_renglon = 0 then
		                       Raise Exception  -746, 0, "[ERR_PGR_012] - El parametro Certificación Presupuestaria no es valido.";
		                   end if */



		                   --monto cp partpr 33
		                  let w_cp_monto_mn=w_prl_monto_mo; -- monto que realizara la imputacion presupuestaria

		                   --GESTION cp partpr 34
		                   let w_cp_gestion=YEAR(CURRENT); -- obtiene la gestion del año actual

		                   --RFA cp partpr 36
		                  let w_cp_rfa=w_ctp_cp_rfa_default;

		                   --TPO cp partpr 37
		                   let w_cp_top=w_ctp_cp_top_default; -- tipo de opoeracion realizada en la tabla imp_presup R= realizado, D= devengado para este caso se utiliza R



		                  if w_pago_importe_capital!=0 then -- para este caso se toman en cuenta 4 renglones

			                		if p_nro_renglon in (3,4) then

			                				if w_cp_monto_mn <>0 then	-- verifica que el monto que se registrara en la imputacion sea distinto de cero


		                   					   -- se realizan ajustes al valor de la certificacion presupuestaria para  w_pago_importe_capital distinto de cero
								                   let w_delim_pos = INSTR(w_cp, '-');
								                   IF w_delim_pos > 0 THEN
								                      let w_cp_cta = SUBSTR(w_cp, 1, w_delim_pos - 1);
								                      let w_cp_renglon = "";
								                      let w_cp_renglon = SUBSTR(w_cp, w_delim_pos + 1);
								                   else
								                      Raise Exception  -746, 0, "[ERR_PGR_011] - La certificación presupuestaria  no esta parametrizada o formato incorrecto." || w_cp|| "<-";
								                   END IF;

								                   if w_cp_cta is null or w_cp_renglon is null or w_cp_cta = 0 or w_cp_renglon = 0 then
								                       Raise Exception  -746, 0, "[ERR_PGR_012] - El parametro Certificación Presupuestaria no es valido.";
								                   end if
		                   					   -- ---------------------------------------------------------------------------------------------------------------------


			                				   -- registro de la imputacion presupuestaria
							                   insert into contbcb@bcbux02:imp_presup values (p_centro, p_cmp_tipo, p_cmp_nro, p_nro_renglon, cast(w_cp_imp as int), cast(w_cp_monto_mn as decimal(15,2)), cast(w_cp_gestion as int), cast(w_cp_cta as int), w_cp_renglon, w_cp_top, w_cp_rfa) ;
							                   -- verifica que se haya registrado correctamente la imputacion presupuestaria
										       if dbinfo ("sqlca.sqlerrd2") = 0 then  -- no hizo el insert
										         	Raise Exception -746, 0, "[ERROR_ESTADO_014] - No se pudo registrar la imputacion presupuestaria en el renglon -> "|| p_nro_renglon ||" del comprobante "|| p_cmp_nro ||" en la tabla reng_comprob. Revisar en COIN y SISCRED";
											   end if

										    end if

			                		end if

		                  end if

		                  if w_pago_importe_capital=0 then -- para ete caso se toman en cuenta 3 renglones

		 		                  	if p_nro_renglon in (2,3) then
											if w_cp_monto_mn <>0 then	 -- verifica que el monto que se registrara en la imputacion sea distinto de cero



	                   						   -- se realizan ajustes al valor de la certificacion presupuestaria para  w_pago_importe_capital igual a cero
								                   let w_delim_pos = INSTR(w_cp, '-');
								                   IF w_delim_pos > 0 THEN
								                      let w_cp_cta = SUBSTR(w_cp, 1, w_delim_pos - 1);
								                      let w_cp_renglon = "";
								                      let w_cp_renglon = SUBSTR(w_cp, w_delim_pos + 1);
								                   else
								                      Raise Exception  -746, 0, "[ERR_PGR_011] - La certificación presupuestaria  no esta parametrizada o formato incorrecto." || w_cp|| "<-";
								                   END IF;

								                   if w_cp_cta is null or w_cp_renglon is null or w_cp_cta = 0 or w_cp_renglon = 0 then
								                       Raise Exception  -746, 0, "[ERR_PGR_012] - El parametro Certificación Presupuestaria no es valido.";
								                   end if
							                   -- ---------------------------------------------------------------------------------------------------------------------


											   -- registro de la imputacion presupuestaria
							                   insert into contbcb@bcbux02:imp_presup values (p_centro, p_cmp_tipo, p_cmp_nro, p_nro_renglon, cast(w_cp_imp as int), cast(w_cp_monto_mn as decimal(15,2)), cast(w_cp_gestion as int), cast(w_cp_cta as int), w_cp_renglon, w_cp_top, w_cp_rfa) ;
							                   -- verifica que se haya registrado correctamente la imputacion presupuestaria
										       if dbinfo ("sqlca.sqlerrd2") = 0 then  -- no hizo el insert
										         	Raise Exception -746, 0, "[ERROR_ESTADO_014] - No se pudo registrar la imputacion presupuestaria en el renglon -> "|| p_nro_renglon ||" del comprobante "|| p_cmp_nro ||" en la tabla reng_comprob. Revisar en COIN y SISCRED";
											   end if

										    end if
			                		end if

		                  end if




		            end foreach

		        -- end if --if w_rln_tiene_cp then
		 end if  --if p_codcmp in (4,5,6,7) then
         -- *************************************************************************************************************************************



		 -- CODIGO PARA GENERAR EL REGISTRO CRV - SIGMA PARA EL REGISTRO CONTABLE DE DESEMBOLSOS SOLO PARA CREDITOS DEL MEFP
		 if p_codcmp=2 then -- registro de desembolsos MEFP

		 		IF p_nro_renglon = 2 then -- numero de renglon 2

		 		   let x_imp_sigma = x_imp_sigma + 1;
				   let w_tipo_sigma = "CRV";

		           insert into contbcb@bcbux02:d_conta.imp_sigma (nro_centro, cve_tipo_comprob, nro_comprob, nro_reng, nro_imp, desc_imp, monto_imp_mo, cve_tipo_sigma, nro_doc_sigma)
		           values(p_centro, p_cmp_tipo, p_cmp_nro, p_nro_renglon, x_imp_sigma, null, w_prl_monto_mo, w_tipo_sigma, p_cmp_nro);

		           -- verifica que se haya registrado correctamente la imputacion presupuestaria
				   if dbinfo ("sqlca.sqlerrd2") = 0 then  -- no hizo el insert
					      	Raise Exception -746, 0, "[ERROR_ESTADO_015] - No se pudo registrar el tipo de operacion CRV-SIGMA en el renglon -> "|| p_nro_renglon ||" del comprobante "|| p_cmp_nro ||" en la tabla reng_comprob. Revisar en COIN y SISCRED";
				   end if

		        END IF;

		 end if
		 -- *********************************************************************************************************************************


                                                

	    -- CODIGO PARA ACTUALIZAR LAS TABLAS DEL SISCRED DESPUES DE INSERTAR CORRECTAMENTE LOS RENGLONES DEL COMPROBANTE EN LA BD CONTBCB
		if p_codcmp=1 or p_codcmp=2 then
        	if p_nro_renglon = 1 then
        		update d_creditos.pre_desembolso_detalle
                set glosa_debe = w_rln_glosa
                where id = p_idtabla;
        	elif p_nro_renglon = 2 then
        		update d_creditos.pre_desembolso_detalle
                set glosa_haber = w_rln_glosa
                where id = p_idtabla;
        	end if
        end if

        if p_codcmp=9 then -- registro custodia de garantia
                if p_nro_renglon = 1 then
                update d_creditos.pre_custodia_garantia
                set glosa_debe = w_rln_glosa
                where id = p_idtabla;
                elif p_nro_renglon = 2 then
                        update d_creditos.pre_custodia_garantia
                set glosa_haber = w_rln_glosa
                where id = p_idtabla;
                end if
        end if
                
        if p_codcmp=10 then -- registro retiro de garantia
                if p_nro_renglon = 1 then
					update d_creditos.pre_retiro_garantia
					set glosa_debe = w_rln_glosa
					where id = p_idtabla;
				elif p_nro_renglon = 2 then
					update d_creditos.pre_retiro_garantia
					set glosa_haber = w_rln_glosa
					where id = p_idtabla;
                end if
        end if
        
        if p_codcmp in (4,5,6,7) then -- registro contable pago de cuota
        		
        		
		        if w_pago_importe_capital!=0 and w_nro_renglon_aux=4 and w_intereses_gestion_anterior=0 then		          
		                	let p_nro_renglon=w_nro_renglon_aux;
		        end if		                
		        if w_pago_importe_capital=0 and w_nro_renglon_aux=3 and w_intereses_gestion_anterior=0 then
		                	let p_nro_renglon=w_nro_renglon_aux;
		        end if
        
        
        		if w_pago_importe_capital!=0 then
        			if p_nro_renglon = 1 then
	        			update d_creditos.pre_pagocuota set glosa_coin_debe_capital = w_rln_glosa where id = p_idtabla;
					elif p_nro_renglon = 2 then
						update d_creditos.pre_pagocuota set glosa_coin_haber_capital = w_rln_glosa where id = p_idtabla;
					elif p_nro_renglon = 3 then
						update d_creditos.pre_pagocuota set glosa_coin_interes_anterior = w_rln_glosa where id = p_idtabla;
					elif p_nro_renglon = 4 then
						update d_creditos.pre_pagocuota set glosa_coin_interes_actual = w_rln_glosa where id = p_idtabla;
                	end if
        		end if
        		
        		if w_pago_importe_capital=0 then
        			if p_nro_renglon = 1 then
	        			update d_creditos.pre_pagocuota set glosa_coin_debe_capital = w_rln_glosa where id = p_idtabla;
					elif p_nro_renglon = 2 then
						update d_creditos.pre_pagocuota set glosa_coin_interes_anterior = w_rln_glosa where id = p_idtabla;
					elif p_nro_renglon = 3 then
						update d_creditos.pre_pagocuota set glosa_coin_interes_actual = w_rln_glosa where id = p_idtabla;
                	end if
        		end if
        		
        end if
          
    return cast("T" as boolean);          
end procedure;
