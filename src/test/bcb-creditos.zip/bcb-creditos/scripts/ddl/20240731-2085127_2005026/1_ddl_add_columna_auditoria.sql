select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: ADICIONA COLUMNA AUDITORIA EN LAS TABLAS gen_comprobante y gen_parametro.
         -- FECHA: 10-07-2024
         -- SDAPO: 2085127
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 
 -- 1 QUERY 
alter table d_creditos.gen_comprobante add cambio_bd varchar(250) default null;	
alter table d_creditos.gen_parametro add cambio_bd varchar(250) default null;
alter table d_creditos.pre_prestamos add cambio_bd varchar(250) default null;
  
