DROP PROCEDURE IF EXISTS d_creditos.pu_h_pre_pagocuota;
 
CREATE PROCEDURE d_creditos.pu_h_pre_pagocuota (
    o_id INTEGER, 
    o_codcred INTEGER, 
    o_codmod INTEGER, 
    o_coddsb INTEGER,
    o_total_cuota_vencimiento DECIMAL(15,2), 
    o_pago_importe_capital DECIMAL(15,2),
    o_pago_importe_intereses DECIMAL(15,2), 
    o_fecha_vencimiento DATE, 
    o_fecha DATE,
    o_intereses_gestion_anterior DECIMAL(15,2), 
    o_intereses_gestion_actual DECIMAL(15,2),
    o_total_saldo DECIMAL(15,2),
    o_numero_cuota INTEGER,
    o_nro_claveserie VARCHAR(100),
    o_estado INTEGER, 
    o_nro_comprobante_coin VARCHAR(250),
    o_glosa_coin LVARCHAR(500), 
    o_glosa_coin_debe_capital LVARCHAR(500),
    o_glosa_coin_haber_capital LVARCHAR(500), 
    o_glosa_coin_interes_anterior LVARCHAR(500),
    o_glosa_coin_interes_actual LVARCHAR(500), 
    o_cambio_bd VARCHAR(250),
    o_audit_usuario VARCHAR(15), 
    o_audit_fechahora DATETIME YEAR TO SECOND, 
    o_audit_host VARCHAR(20),
    o_audit_usuario_genera VARCHAR(15), 
    o_audit_fechahora_genera DATETIME YEAR TO SECOND, 
    o_audit_host_genera VARCHAR(20),
    o_audit_usuario_preautoriza VARCHAR(15), 
    o_audit_fechahora_preautoriza DATETIME YEAR TO SECOND, 
    o_audit_host_preautoriza VARCHAR(20),
    o_audit_usuario_autoriza VARCHAR(15), 
    o_audit_fechahora_autoriza DATETIME YEAR TO SECOND, 
    o_audit_host_autoriza VARCHAR(20)
)

	     -- DESCRIPCI�N: Procedimiento utilizado en trigger para la actualizacion de datos en la tabla PRE_PRESTAMOS_H
         -- PARAMETROS INGRESO: o_id INTEGER, 
         -- o_codcred INTEGER, 
         -- o_codmod INTEGER, 
         -- o_coddsb INTEGER,
         -- o_total_cuota_vencimiento DECIMAL(15,2), 
         -- o_pago_importe_capital DECIMAL(15,2),
         -- o_pago_importe_intereses DECIMAL(15,2), 
         -- o_fecha_vencimiento DATE, 
         -- o_fecha DATE,
         -- o_intereses_gestion_anterior DECIMAL(15,2), 
         -- o_intereses_gestion_actual DECIMAL(15,2),
         -- o_total_saldo DECIMAL(15,2),
		 -- o_numero_cuota INTEGER,
		 -- o_nro_claveserie VARCHAR(100),
         -- o_estado INTEGER, 
         -- o_nro_comprobante_coin VARCHAR(250),
         -- o_glosa_coin LVARCHAR(500), 
         -- o_glosa_coin_debe_capital LVARCHAR(500),
         -- o_glosa_coin_haber_capital LVARCHAR(500), 
         -- o_glosa_coin_interes_anterior LVARCHAR(500),
         -- o_glosa_coin_interes_actual LVARCHAR(500), 
         -- o_cambio_bd VARCHAR(250),
         -- o_audit_usuario VARCHAR(15), 
         -- o_audit_fechahora DATETIME YEAR TO SECOND, 
         -- o_audit_host VARCHAR(20),
         -- o_audit_usuario_genera VARCHAR(15), 
         -- o_audit_fechahora_genera DATETIME YEAR TO SECOND, 
         -- o_audit_host_genera VARCHAR(20),
         -- o_audit_usuario_preautoriza VARCHAR(15), 
         -- o_audit_fechahora_preautoriza DATETIME YEAR TO SECOND, 
         -- o_audit_host_preautoriza VARCHAR(20),
         -- o_audit_usuario_autoriza VARCHAR(15), 
         -- o_audit_fechahora_autoriza DATETIME YEAR TO SECOND, 
         -- o_audit_host_autoriza VARCHAR(20)
		 
         -- PARAMETROS SALIDA: 
		 --
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: CREDITOS (pre_pagocuota_h)
         -- CREACI�N:  06-05-2025
         -- SDAPO: 2401886
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--|           |               |          |  
----------------------------------------------------------------------------

 
    INSERT INTO d_creditos.pre_pagocuota_h (
        id, codcred, codmod, coddsb,
        total_cuota_vencimiento, pago_importe_capital, pago_importe_intereses, fecha_vencimiento, fecha,
        intereses_gestion_anterior, intereses_gestion_actual,
        total_saldo, numero_cuota, nro_claveserie,
        estado, nro_comprobante_coin,
        glosa_coin, glosa_coin_debe_capital, glosa_coin_haber_capital,
        glosa_coin_interes_anterior, glosa_coin_interes_actual, cambio_bd,
        audit_usuario, audit_fechahora, audit_host,
        audit_usuario_genera, audit_fechahora_genera, audit_host_genera,
        audit_usuario_preautoriza, audit_fechahora_preautoriza, audit_host_preautoriza,
        audit_usuario_autoriza, audit_fechahora_autoriza, audit_host_autoriza,
        fecha_modificacion, usuario_modificacion, host_modificacion
    )
    VALUES (
        o_id, o_codcred, o_codmod, o_coddsb,
        o_total_cuota_vencimiento, o_pago_importe_capital, o_pago_importe_intereses, o_fecha_vencimiento, o_fecha,
        o_intereses_gestion_anterior, o_intereses_gestion_actual,
        o_total_saldo, o_numero_cuota, o_nro_claveserie,
        o_estado, o_nro_comprobante_coin,
        o_glosa_coin, o_glosa_coin_debe_capital, o_glosa_coin_haber_capital,
        o_glosa_coin_interes_anterior, o_glosa_coin_interes_actual, o_cambio_bd,
        o_audit_usuario, o_audit_fechahora, o_audit_host,
        o_audit_usuario_genera, o_audit_fechahora_genera, o_audit_host_genera,
        o_audit_usuario_preautoriza, o_audit_fechahora_preautoriza, o_audit_host_preautoriza,
        o_audit_usuario_autoriza, o_audit_fechahora_autoriza, o_audit_host_autoriza,
        CURRENT, USER,
        (SELECT TRIM(hostname)
         FROM sysmaster:syssessions
         WHERE sid = (SELECT DBINFO('sessionid') FROM systables WHERE tabname = 'systables'))
    );
END PROCEDURE; 