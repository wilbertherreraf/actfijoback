DROP PROCEDURE IF EXISTS d_creditos.pu_h_pre_garantiad;

CREATE PROCEDURE d_creditos.pu_h_pre_garantiad (
    o_gard_cod INTEGER,
    o_gard_codcred INTEGER,
    o_gard_codmod INTEGER,
    o_gard_coddsb INTEGER,
    o_gard_habilita boolean,
    o_gard_claveserie VARCHAR(30),
    o_gard_titulo VARCHAR(10),
    o_gard_negociable boolean,
    o_gard_tabtrxstaau INTEGER,
    o_gard_trxstaau INTEGER,
    o_gard_auditusr VARCHAR(15),
    o_gard_auditfho DATETIME YEAR TO SECOND,
    o_gard_auditwst VARCHAR(50)
)

-- DESCRIPCION: Procedimiento utilizado en trigger para la actualizacion de datos en la tabla PRE_GARANTIAD_H
         -- PARAMETROS INGRESO: o_gard_cod INTEGER,
    						 -- o_gard_codcred INTEGER,
    						 -- o_gard_codmod INTEGER,
    						 -- o_gard_coddsb INTEGER,
    						 -- o_gard_habilita boolean,
    						 -- o_gard_claveserie VARCHAR(30),
    						 -- o_gard_titulo VARCHAR(10),
    						 -- o_gard_negociable boolean,
    						 -- o_gard_tabtrxstaau INTEGER,
    						 -- o_gard_trxstaau INTEGER,
    						 -- o_gard_auditusr VARCHAR(15),
    						 -- o_gard_auditfho DATETIME YEAR TO SECOND,
    						 -- o_gard_auditwst VARCHAR(50)
		 
         -- PARAMETROS SALIDA: 
		 --
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: CREDITOS (pre_garantiad_h)
         -- CREACION:  16/06/2025
         -- SDAPO: 2459794
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--|           |               |          |  
----------------------------------------------------------------------------
 
    INSERT INTO d_creditos.pre_garantiad_h (
        gard_cod,
        gard_codcred,
        gard_codmod,
        gard_coddsb,
        gard_habilita,
        gard_claveserie,
        gard_titulo,
        gard_negociable,
        gard_tabtrxstaau,
        gard_trxstaau,
        gard_auditusr,
        gard_auditfho,
        gard_auditwst,
        hist_accion, 
        hist_fecha
    )
    VALUES (
        o_gard_cod,
        o_gard_codcred,
        o_gard_codmod,
        o_gard_coddsb,
        o_gard_habilita,
        o_gard_claveserie,
        o_gard_titulo,
        o_gard_negociable,
        o_gard_tabtrxstaau,
        o_gard_trxstaau,
        o_gard_auditusr,
        o_gard_auditfho,
        o_gard_auditwst,
        'UPDATE',
        CURRENT
    );
END PROCEDURE;
