-- QUERY 4
DROP PROCEDURE IF EXISTS p_rpro_panti_metosaldodsb;   
-- SPL MODIFICADO
create procedure "d_creditos".p_rpro_panti_metosaldodsb(p_codcred integer, p_codmod integer, p_codmodtmp integer, p_fecha date, p_fechaoper date, p_importe decimal(20,2), p_coduser varchar(100), P_ESTACION VARCHAR(100), p_tipo_pago CHAR(10))
{
    wherrera 2021.11.01 divide el saldo captial del pago anticipado entre el numero de cuotas restantes
	prorratea el importe entre los saldos cap de cada dsb 
	agrega C/I por dsb al cronograma
	prorrateo en cada dsb 
	actualiza montos de cronograma 
  
-- DESCRIPCION: Procedimiento para generar pagos anticipados
-- PARAMETROS INGRESO: p_codcred     integer
--                     p_codmod      integer
--                     p_codmodtmp   integer
--                     p_fecha       date
--					   p_fechaoper	 date
--					   p_importe	 decimal(20,2)		
--					   p_coduser	 varchar(100)
--					   P_ESTACION	 VARCHAR(100)
--					   p_tipo_pago	 CHAR(10)


-- PARAMETROS SALIDA:  No devuelve ningun valor como resultado
-- AUTOR: wherrera
-- CREACION: 2021.11.01

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| wherrera  |  2021.11.01   |          | divide el saldo captial del pago anticipado entre el numero de cuotas restantes prorratea el importe entre los saldos cap de cada dsb agrega C/I por dsb al cronograma prorrateo en cada dsb actualiza montos de cronograma
----------------------------------------------------------------------------
--| acanqui   |  06-05-2024   | 1763004  | Adici�n de opcion para realizar pagos con DISTRIBUCION LINEAL DE CUOTAS (DLC) O CONTRA LA SIGUIENTE CUOTA (CSC) SOLAMENTE PARA EL FNDR.
----------------------------------------------------------------------------
--| acanqui   |  31-12-2024   | 2300070  | Ajuste para obtener el saldo del pago anticipado de un pago anterior y sumarlo al interes actual (el ajuste solo se aplica cuando el saldo restante es mayor a cero).
----------------------------------------------------------------------------
}
 


 define v_sum_int, v_cap_resto, v_int_restper,v_int_restper2,v_sum_desembolso, v_siap, v_mnt_capper,v_panti ,v_mnt_cap_prorrateado like pre_planpagos.cuo_valor;
define v_amtacru, v_new_unpaid, v_sum_importe like pre_planpagos.cuo_valor;
define V_MNT_PRG, V_MNT_PRGPEND, v_sumdiff like pre_planpagos.cuo_valor;
define v_fecha_ini_per, v_fecsigper, v_cuo_fecvencuo, v_dsb_fecdsb date;
define C_TIPOTRX_PANTI, C_TIPOCUO_CAP, C_TIPOCUO_INT, C_TIPOCOB_PANTI_CAP, C_TIPOCOB_PANTI_INT INTEGER;
define v_codacu,v_contdesem, v_cuo_coddsb, v_cont , v_dsb_coddsb, v_cuo_codcuo, v_cuo_tipocuo, v_cuo_codcuoint integer; 
DEFINE C_TIPOPRORRA_AMORTIGUAL, C_TIPOPRORRA_SIAP, C_TIPOPRORRA_VALPEND INTEGER;
define v_app_t, v_appint_t, v_appaux_t aux_planpagos_t; 

-- codigo para definir variables para el credito FNDR
define v_dsb_coddsb_int INTEGER;
define CREDITO_FNDR, TIPO_CUOTA_FNDR INTEGER;
define v_saldo_interes_pago_anticipado DECIMAL(20,2);
define v_resto_saldo_interes_pago_anticipado DECIMAL(20,2);

/*define v_pathlog varchar(250); -- log
let v_pathlog = 'p_rpro_panti_metosaldodsb.log'; -- log
SET DEBUG FILE TO v_pathlog; -- log*/

let C_TIPOCUO_CAP = 1;
let C_TIPOCUO_INT = 2;
LET C_TIPOTRX_PANTI = 3;
LET C_TIPOCOB_PANTI_CAP = 12; 
LET C_TIPOCOB_PANTI_INT = 22;
let C_TIPOPRORRA_AMORTIGUAL = 3;
let C_TIPOPRORRA_SIAP = 2;
let C_TIPOPRORRA_VALPEND = 1;
let v_mnt_cap_prorrateado=0; 
let v_fecsigper = f_pp_fec_sigper(p_codcred, p_codmod, null, p_fecha, C_TIPOCUO_INT);
let v_sum_int = 0;
let v_cap_resto = p_importe;
let v_cont = 0;
let CREDITO_FNDR=43;
let TIPO_CUOTA_FNDR=2;
let v_saldo_interes_pago_anticipado=0;
let v_resto_saldo_interes_pago_anticipado=0;


-- en este query obtiene el valor 927671.93
-- se cambio la funcion 'f_getinteres_dsb' por 'f_getinteres_dsb_pago_anticipado'
select sum(f_getinteres_dsb_pago_anticipado(p_codcred, p_codmod, dsb_coddsb, p_fecha)),sum(dsb_valor),count(1)
into v_int_restper2,v_sum_desembolso,v_contdesem 
from pre_desemb
where dsb_codmod = p_codmod
and dsb_codcred = p_codcred
and dsb_undsb > 0;


   -- CODIGO PARA VERIFICAR Y OBTENER SI EXISTE EL SALDO DEL PAGO ANTICIPADO DE UNA FECHA ANTERIOR
   if CREDITO_FNDR = p_codcred then 
   			-- consulta que obtiene el saldo del pago anticipado del resgistro anterior
			SELECT cuo_saldo_interes_pago_anticipado
		   	INTO v_saldo_interes_pago_anticipado
			FROM pre_planpagos
			WHERE cuo_codcred = p_codcred
			  AND cuo_codmod = p_codmod
			  AND cuo_tipocuo = TIPO_CUOTA_FNDR
			  AND cuo_fecvencuo = (
			    SELECT MAX(cuo_fecvencuo)
			    FROM pre_planpagos
			    WHERE cuo_codcred = p_codcred
			      AND cuo_codmod = p_codmod
			      AND cuo_tipocuo = TIPO_CUOTA_FNDR
			      AND cuo_fecvencuo < p_fecha
			      AND cuo_coddsb > 0
			  )
			  AND cuo_coddsb > 0;
			  
   end if;
 
-- verifica que el importe sea menor al interes 
--if p_importe <= v_int_restper2 then -- codigo anterior
if p_importe <= (v_int_restper2+v_saldo_interes_pago_anticipado) then

	let v_resto_saldo_interes_pago_anticipado=(v_int_restper2+v_saldo_interes_pago_anticipado)-p_importe;
	foreach
		select
			dsb_coddsb,
			round(dsb_valor / v_sum_desembolso, 2)* p_importe 
		into
			v_dsb_coddsb,
			v_panti
		from 
			pre_desemb
		where
			dsb_codmod = p_codmod
			and dsb_codcred = p_codcred
			and dsb_undsb > 0
		order by	dsb_coddsb

		let v_cont = v_cont + 1; 
	
		if v_cont=v_contdesem then
			let v_mnt_cap_prorrateado=p_importe-v_mnt_cap_prorrateado;
			let v_panti=v_mnt_cap_prorrateado;
		else
			let v_mnt_cap_prorrateado=v_mnt_cap_prorrateado + v_panti;
		end if

		--insert into auxplanpagos 
		let v_app_t = f_init_app_t(); 
		let v_app_t.acu_codmod = p_codmodtmp;
		let v_app_t.acu_codmodorig = p_codmod;
		let v_app_t.acu_codcred = p_codcred;
		let v_app_t.acu_coddsb = v_dsb_coddsb;
		let v_app_t.acu_trxstaau = 1;
		let v_app_t.acu_monpag = 1;
		let v_app_t.acu_fecvencuo = p_fecha;
		let v_app_t.acu_fecfincuo = p_fecha;
		let v_app_t.acu_auditfho = p_fechaoper;
		let v_app_t.acu_auditusr = p_coduser;
		let v_app_t.acu_auditwst = p_estacion;
		let v_app_t.acu_tipocuo = C_TIPOCUO_INT;
		let v_app_t.acu_valor = v_panti;
		let v_app_t.acu_valorpend = v_panti;
		let v_app_t.acu_capital = 0;
		let v_app_t.acu_tipotrx = C_TIPOTRX_PANTI; 
		let v_app_t.acu_tipoacu = C_TIPOCOB_PANTI_INT; 
		let v_codacu = p_insauxplanpg(v_app_t); -- obtenemos el ID  de la tabla aux_planpagos

		update d_creditos.aux_planpagos 
			set acu_valor=acu_valor-v_panti , acu_valorpend=acu_valorpend-v_panti
		where acu_codcred=p_codcred and acu_codmod=p_codmodtmp and acu_codmodorig=p_codmod and acu_coddsb=v_dsb_coddsb and acu_fecvencuo=v_fecsigper and acu_tipocuo=2;
	
		/*********************************************************/
		-- actualizamos el valor de acu_saldo_interes_pago_anticipado de la tabla aux_planpagos en caso de que el saldo del pago anticip�do con sea mayor que el interes
		if CREDITO_FNDR = p_codcred then 
			if v_resto_saldo_interes_pago_anticipado>0 then 
				update d_creditos.aux_planpagos 
				set acu_saldo_interes_pago_anticipado=v_resto_saldo_interes_pago_anticipado
				where acu_codacu=v_codacu;
			end if;
		end if;
		-- **********************************************************************************************
	
	
	end foreach

else
-- El importe es mayor al interes
-- raise exception -746,0, "dato: "|| p_codmod ||"  "|| p_codcred ;
	foreach
		select dsb_coddsb
		into v_dsb_coddsb
		from pre_desemb
		where dsb_codmod = p_codmod
		  and dsb_codcred = p_codcred
		  and dsb_undsb > 0
		order by dsb_coddsb
		
		-- La  variable 'v_int_restper' obtiene el interes devengado  927671.93 
		let v_int_restper = round(f_getinteres_dsb_pago_anticipado(p_codcred, p_codmod, v_dsb_coddsb, p_fecha),2); -- se cambio la funcion 'f_getinteres_dsb' por 'f_getinteres_dsb_pago_anticipado'
		let v_sum_int = v_sum_int + v_int_restper;
	
		if v_cap_resto >= v_int_restper and v_int_restper > 0 then
		
		-- INSERTA UN VALOR EN LA TABLA aux_planpagos
		-- inserta los valores y fecha del pago anticipado 
			let v_app_t = f_init_app_t();
			let v_siap = f_acr_saldo_fecha(p_codcred, p_codmod, v_dsb_coddsb, p_fecha - 1); 
			let v_app_t.acu_codmod = p_codmodtmp;
			let v_app_t.acu_codmodorig = p_codmod;
			let v_app_t.acu_codcred = p_codcred;
			let v_app_t.acu_coddsb = v_dsb_coddsb;
			let v_app_t.acu_trxstaau = 1;
			let v_app_t.acu_monpag = 1;
			let v_app_t.acu_fecvencuo = p_fecha;
			let v_app_t.acu_fecfincuo = p_fecha;
			let v_app_t.acu_auditfho = current;
			let v_app_t.acu_auditusr = p_coduser;
			let v_app_t.acu_auditwst = p_estacion;
			let v_app_t.acu_tipocuo = C_TIPOCUO_INT;
			let v_app_t.acu_valor = v_int_restper;
			let v_app_t.acu_valorpend = v_int_restper; 
			let v_app_t.acu_capital = v_siap; 
			let v_app_t.acu_tipotrx = C_TIPOTRX_PANTI; 
			let v_app_t.acu_tipoacu = C_TIPOCOB_PANTI_INT; 

		
			if v_int_restper > 0 then
				let v_cont = v_cont + 1;
				let v_codacu = p_insauxplanpg(v_app_t);
			end if
			
			let v_cap_resto = v_cap_resto - v_int_restper;
		end if
		
		if v_cap_resto <= 0 then
			exit foreach;
		end if
		
	end foreach
	 
	if v_sum_int > 0 and v_cont = 0 then
		raise exception -746,0,"Importe " || p_importe || " insuficiente para cubrir intereses " || v_int_restper || " a fecha " || p_fecha ;
	else 
		call p_rpro_adj_crono(p_codcred, p_codmod, p_codmodtmp, v_cap_resto, p_fecha, p_coduser, p_estacion, p_tipo_pago);
	end if
end if

end procedure;