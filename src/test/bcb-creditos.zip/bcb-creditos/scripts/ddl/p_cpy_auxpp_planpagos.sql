DROP PROCEDURE IF EXISTS p_cpy_auxpp_planpagos;

create procedure "d_creditos".p_cpy_auxpp_planpagos(p_codcred integer, p_codmod integer, p_coddsb integer, p_codmodtmp INTEGER, p_coduser varchar(100), p_estacion varchar(100))
{
wherrera 202122 : copia los datos de la tabla auxiliar plande pagos a la tabla transaccional, asume que lo que esta registrado en aux 

-- DESCRIPCION: copia los datos de la tabla auxiliar plande pagos a la tabla transaccional, asume que lo que esta registrado en aux 
-- PARAMETROS INGRESO: p_codcred     integer
--                     p_codmod      integer
--                     p_coddsb		 integer
--					   p_coddsb		 integer
--					   p_coduser	 varchar(100)
--					   p_estacion	 VARCHAR(100)



-- PARAMETROS SALIDA:  No devuelve resultados
-- AUTOR: wherrera
-- CREACION: 202122

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  31-12-2024   | 2300070  | Ajuste para obtener el saldo del pago anticipado de la tabla aux_plan_pagos y registrarlo en la tabla pre_planpagos.
----------------------------------------------------------------------------

}
    define err_num, err_nro integer;
    define err_msg varchar(235); 
    
    define v_cuo_codcuo, v_acu_codacu		like aux_planpagos.acu_codacu		;
    define v_cuo_codcred, v_acu_codcred    like aux_planpagos.acu_codcred      ;
    define v_cuo_codmod, v_acu_codmod     like aux_planpagos.acu_codmod       ;
    define v_acu_numcuo     like aux_planpagos.acu_numcuo       ;
    define v_acu_fecvencuo  like aux_planpagos.acu_fecvencuo    ;
    define v_acu_fecinicuo  like aux_planpagos.acu_fecinicuo    ;
    define v_acu_fecfincuo  like aux_planpagos.acu_fecfincuo    ;
    define v_acu_capital    like aux_planpagos.acu_capital      ;
    define v_acu_interes    like aux_planpagos.acu_interes      ;
    define v_acu_cargos     like aux_planpagos.acu_cargos       ;
    define v_acu_valor      like aux_planpagos.acu_valor        ;
    define v_acu_valorpend  like aux_planpagos.acu_valorpend    ;
    define v_acu_coddsb     like aux_planpagos.acu_coddsb       ;
    define v_acu_tasa       like aux_planpagos.acu_tasa         ;
    define v_acu_tipodsb    like aux_planpagos.acu_tipodsb      ;
    define v_acu_tipocuo    like aux_planpagos.acu_tipocuo      ;
    define v_acu_methodcapi like aux_planpagos.acu_methodcapi   ;
    define v_acu_unidplaz   like aux_planpagos.acu_unidplaz     ;
    define v_acu_tipoacu    like aux_planpagos.acu_tipoacu      ;
    define v_acu_monpag     like aux_planpagos.acu_monpag       ;
    define v_cont, v_flag_ha integer;
    define v_codha integer;
    define v_ult_plz date;
    define C_FLAG_EXETRIGGER_PP_NOEXE integer;
    define C_TIPOCUO_CAP, C_STATTRXAU_AUT, C_COBCODIGO_DSB integer;
    define v_appfound_t, v_app_t aux_planpagos_t;
   
   	define v_saldo_interes_pago_anticipado decimal(20,2);
    define CREDITO_FNDR INTEGER;
   
    
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PV INT DEFAULT -1;
    
    LET C_STATTRXAU_AUT = 3;
    let C_TIPOCUO_CAP = 1;
    let C_COBCODIGO_DSB = 3;
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;
    let G_FLAG_EXETRIGGER_PP = -1;
    let v_flag_ha = 0;
    let v_codha = null;
   
   	let CREDITO_FNDR=43;
	let v_saldo_interes_pago_anticipado=0;
	
    
BEGIN
    ON EXCEPTION  SET err_num, err_nro, err_msg  -- trap all errors
    END EXCEPTION with resume
    
    --call p_srvdeu_initlog(p_coduser, p_estacion);  
    --trace procedure; 
end
BEGIN
    ON EXCEPTION  SET err_num, err_nro, err_msg  -- trap all errors
        call p_log_error(err_num, err_nro, err_msg, null);
        raise exception err_num, err_nro, err_msg ;
    END EXCEPTION        
    
    let v_app_t = f_init_app_t();

    let v_cont = f_pv_contar(p_codcred, p_codmodtmp, p_coddsb);
    
    if v_cont = 0 then
        raise exception -746,0,"No Existen regs. a copiar. Mod: " || p_codmodtmp || " cred: " || p_codcred || " dsb: "|| nvl(p_coddsb, 0);
    end if

-- si existe trx
    SELECT count(*)
    into v_cont
    FROM pre_cobros
    WHERE cob_codcred = p_codcred
    and cob_codmod = p_codmod
    AND cob_codigo != C_COBCODIGO_DSB
    AND cob_statreg = 0
    and exists (select 1
            from pre_planpagos
        where cuo_codmod = p_codmod
        and cuo_codcred = p_codcred
        and cuo_codcuo = cob_numcuo
        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
        and cuo_coddsb > 0
    );

    if v_cont > 0 and p_coddsb is null then
    -- bck si solo ya existen operaciones
        let v_codha = p_pp_cpy_pp_histo(p_codcred, p_codmod, null);
        let v_flag_ha = 1;
    end if
        
    foreach 
        select cuo_codcuo
        into v_cuo_codcuo
        from pre_planpagos
        where cuo_codmod = p_codmod
        and cuo_codcred = p_codcred
        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
        and nvl(cuo_valorpend, 0) != 0
        and cuo_coddsb > 0
        and not exists (select 1
        from aux_planpagos
        where acu_codmod = p_codmodtmp
        and acu_codcred = p_codcred
        and acu_coddsb = cuo_coddsb
        and acu_fecvencuo = cuo_fecvencuo
        and acu_tipocuo = cuo_tipocuo
        and acu_numcuo = cuo_codcuo)
        -- no existe en aux
        --raise exception -746,0,"asd " || v_cuo_codcuo; 
        delete from pre_planpagos
        where cuo_codcuo = v_cuo_codcuo;
    end foreach
            
    foreach 
        select acu_codacu, acu_codcred, acu_codmod, acu_codmodorig, acu_numcuo, acu_fecvencuo,
        acu_fecinicuo, acu_fecfincuo, acu_capital, acu_interes, acu_cargos, acu_valor,
        acu_valorpend, acu_coddsb, acu_tabtipocuo,acu_tipocuo, acu_tipoacu,
        acu_tabmonpag, acu_monpag, acu_tabtipotrx, acu_tipotrx, acu_tabtrxstaau, acu_trxstaau, acu_auditwst, acu_saldo_interes_pago_anticipado
        into v_app_t.acu_codacu, v_app_t.acu_codcred, v_app_t.acu_codmod, v_app_t.acu_codmodorig, v_app_t.acu_numcuo, v_app_t.acu_fecvencuo,
        v_app_t.acu_fecinicuo, v_app_t.acu_fecfincuo, v_app_t.acu_capital, v_app_t.acu_interes, v_app_t.acu_cargos, v_app_t.acu_valor,
        v_app_t.acu_valorpend, v_app_t.acu_coddsb, v_app_t.acu_tabtipocuo,v_app_t.acu_tipocuo, v_app_t.acu_tipoacu,
        v_app_t.acu_tabmonpag, v_app_t.acu_monpag, v_app_t.acu_tabtipotrx, v_app_t.acu_tipotrx, v_app_t.acu_tabtrxstaau, v_app_t.acu_trxstaau, v_app_t.acu_auditwst, v_saldo_interes_pago_anticipado
        from aux_planpagos
        where acu_codmod = p_codmodtmp
        and acu_codcred = p_codcred
        and acu_coddsb = nvl(p_coddsb, acu_coddsb)
        and acu_coddsb > 0
        order by acu_coddsb, acu_fecvencuo, acu_tipocuo
        
            if v_app_t.acu_coddsb is null then
                raise exception -746,0,"Registro " || v_app_t.acu_codacu || " sin codigo de desembolso." ;
            end if

            if v_app_t.acu_fecvencuo is null then
                raise exception -746,0,"Registro " || v_app_t.acu_codacu || " sin fecha de vencimiento." ;
            end if
            
            if v_app_t.acu_tipocuo is null then
                raise exception -746,0,"Registro " || v_app_t.acu_codacu || " sin tipo de cuota." ;
            end if
            
            let v_cuo_codcuo = null;
            
            if v_app_t.acu_numcuo is not null and v_app_t.acu_numcuo > 0 then
                select count(*)
                into v_cont
                from pre_planpagos
                where cuo_codmod = p_codmod
                and cuo_codcred = p_codcred
                and cuo_codcuo = v_app_t.acu_numcuo;
                
                if v_cont > 0 then
                    let v_cuo_codcuo = v_app_t.acu_numcuo;
                end if
            end if
        
            LET v_app_t.acu_trxstaau = C_STATTRXAU_AUT;         
            LET v_app_t.acu_auditusr = p_coduser;
            LET v_app_t.acu_auditwst = p_estacion;
            
            if v_cuo_codcuo is null then
                let v_app_t.acu_codmod = p_codmod;
                let v_app_t.acu_auditfho = current;
                let v_app_t.acu_fecfincuo = nvl(v_app_t.acu_fecfincuo, v_app_t.acu_fecvencuo);
                                
                LET v_cuo_codcuo = f_inspreplanpg(v_app_t);
               
               
               -- Codigo para actualizar el valor de la columna cuo_saldo_interes_pago_anticipado de la tabla pre_planpagos, 
               -- esto en caso de que la cuota no sea mayor al interes
	               	if CREDITO_FNDR = p_codcred then -- verifica que el credito sea del FNDR
	               		if v_saldo_interes_pago_anticipado>0 then  -- verifica que el saldo del pago anticipado que se ingreso en la tabla aux_planpagos sea mayor a cero
	               			-- actualiza el valor de la columna cuo_saldo_interes_pago_anticipado obtenido de la tabla aux_planpagos
	               			update pre_planpagos
	               			set cuo_saldo_interes_pago_anticipado=v_saldo_interes_pago_anticipado
	               			where cuo_codcuo=v_cuo_codcuo;
	               			
	               		end if;
	               	end if;
	               
	            -- ----------------------------------------------------------------------------------------------------------------   
                
                update aux_planpagos
                set acu_tipodsb = null,
                acu_numcuo = v_cuo_codcuo
                where acu_codacu = v_app_t.acu_codacu;                
            else
                if v_flag_ha = 1 then
                    let G_FLAG_EXETRIGGER_PV = 1;
                end if
                
                update pre_planpagos
                set cuo_fecvencuo   = v_app_t.acu_fecvencuo   ,
                cuo_fecinicuo   = v_app_t.acu_fecinicuo   ,
                cuo_fecfincuo   = nvl(cuo_fecfincuo, v_app_t.acu_fecvencuo)   ,
                cuo_capital     = v_app_t.acu_capital     ,
                cuo_interes     = v_app_t.acu_interes     ,
                cuo_cargos      = v_app_t.acu_cargos      ,
                cuo_valor       = v_app_t.acu_valor       ,
                cuo_valorpend   = v_app_t.acu_valorpend   ,
                -- cuo_coddsb      = v_app_t.acu_coddsb      ,
                cuo_tipocuo     = v_app_t.acu_tipocuo   ,
                cuo_tipoacu     = nvl(v_app_t.acu_tipoacu, cuo_tipoacu)     ,
                -- cuo_monpag      = v_app_t.acu_monpag      ,
                cuo_tipotrx     = nvl(v_app_t.acu_tipotrx, cuo_tipotrx)     ,
                cuo_trxstaau    = v_app_t.acu_trxstaau,
                cuo_auditusr = v_app_t.acu_auditusr,
                cuo_auditfho = current,
                cuo_auditwst = v_app_t.acu_auditwst
                where cuo_codcuo = v_cuo_codcuo;
               
                
                let G_FLAG_EXETRIGGER_PV = -1;
                
                update aux_planpagos
                set acu_tipodsb = null
                where acu_numcuo = v_cuo_codcuo;
            end if

            let v_app_t = f_init_app_t();

    end foreach;

    let v_ult_plz = null;
    
    select max(cuo_fecvencuo) 
    into v_ult_plz
    from pre_planpagos
    where cuo_codmod = p_codmod
    and cuo_codcred = p_codcred
    and cuo_coddsb > 0
    and cuo_valor > 0;
        
    call p_pre_act_1erpagovenc(p_codcred, p_codmod, null, v_ult_plz);
    
    call p_pp_dsb_cero_acttodo(p_codcred, p_codmod);
    
    call p_pp_control_dif_dsb(p_codcred, p_codmod, p_coddsb);
    call p_updsumtrans(p_codmod, p_codcred, null, null, null, null, null);    
    
    delete from aux_planpagos
    where acu_codmod = p_codmodtmp
    and acu_codcred = p_codcred
    and acu_coddsb = nvl(p_coddsb, acu_coddsb);
END
    
end procedure;                                                                                                                                                 
