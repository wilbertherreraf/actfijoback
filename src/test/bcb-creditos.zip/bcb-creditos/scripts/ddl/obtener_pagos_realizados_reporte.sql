-- QUERY 1
DROP PROCEDURE IF EXISTS obtener_pagos_realizados_reporte;

-- QUERY 2
CREATE PROCEDURE d_creditos.obtener_pagos_realizados_reporte(p_codcred INTEGER, p_codmod INTEGER, p_fecha VARCHAR(30))
RETURNING 
 			  varchar(50) 	as numeral_pago,
   			  varchar(50) 	as fecha,  			 
   			  varchar(20) 	as interes,
   			  varchar(30) 	as capital, 
   			  varchar(30) 	as pago_total;
{
-- DESCRIPCION: Procedimiento para obtener los pagos realizados por credito para el reporte ejecutivo
-- PARAMETROS INGRESO: 	p_codcred integer 
-- 						p_codmod integer
--						p_fecha  varchar 

-- PARAMETROS SALIDA:   varchar(50) 	as numeral_pago
--						varchar(50) 	as fecha  			 
--						varchar(20) 	as interes
--						varchar(30) 	as capital 
--						varchar(30) 	as pago_total
-- AUTOR: acanqui
-- CREACION: 18.06.2024

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  18-06-2024   | 2005026  | Adici�n de procedimiento el detalle de pagos realizados por credito para el reporte ejecutivo.
----------------------------------------------------------------------------
}

-- variables de salida 	
    			DEFINE v_numeral_pago 		varchar(20);
				DEFINE v_fecha 				varchar(20); 
				DEFINE v_interes 			decimal(20,2); 
				DEFINE v_capital 			decimal(20,2);
				DEFINE v_pago_total 		decimal(20,2);
			    DEFINE v_suma_pago_total 	decimal(20,2);
			
			-- variables de proceso
				DEFINE v_suma_interes 	decimal(20,2);
				DEFINE v_contador 		INTEGER;
				
				let v_numeral_pago='s/d';
				let v_suma_interes=0;	
				let v_contador=0;
				let v_suma_pago_total=0;
	
    foreach
		    select TO_CHAR(fechavencuo, '%d/%m/%Y') fecha, interes, amortizacion, cuota 
		    into v_fecha, v_interes, v_capital, v_pago_total
			from v_planpagos_consol 
			where codmod=p_codmod
			and fechavencuo<=p_fecha
			and codcred=p_codcred and estado_cuota='CANCELADO' order by fechavencuo asc
			
			if v_pago_total=0 then
					let v_suma_interes=v_suma_interes+v_interes;
			else
					let v_interes=v_interes+v_suma_interes;
					let v_suma_interes=0;
					let v_contador=v_contador+1;
					let v_numeral_pago=obtiene_numeral(v_contador);
					let v_suma_pago_total=v_interes+v_capital;
					return v_numeral_pago, v_fecha, v_interes, v_capital, v_suma_pago_total with resume;
			end if

        
    END FOREACH       
        
END PROCEDURE;