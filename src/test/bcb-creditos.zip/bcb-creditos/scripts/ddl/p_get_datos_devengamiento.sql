DROP PROCEDURE IF EXISTS p_get_datos_devengamiento; 

CREATE PROCEDURE d_creditos.p_get_datos_devengamiento(p_codcred integer, p_codmod integer, p_fecha date) RETURNING INTEGER AS nro_desembolsos, integer as  nro_dias, DECIMAL(16,2) AS interes_devengado, DECIMAL(16,2) as desembolsado, DECIMAL(16,2) as saldocapital, DECIMAL(16,2) AS interes_devengado_form;

         -- DESCRIPCI�N: Obtiene los datos del devengamineto de un credito a una fecha especificada de la tablas correspondientes
         -- PARAMETROS INGRESO: p_codcred integer                       Codigo de credito
         --                     p_codmod integer                        Codigo de modulo
         --                     p_fecha date                            Fecha de devengado
         -- PARAMETROS SALIDA: nro_desembolsos INTEGER                  Nro de desembolsos
         --                    nro_dias INTEGER                         Nro de d�as
         --                    interes_devengado DECIMAL(16,2)          Monto Interes devengado
         --                    desembolsado DECIMAL(16,2)               Monto Desembolsado
         --                    saldocapital DECIMAL(16,2)               Saldo Capital
         -- AUTOR: HENRY IVAN PANIQUE MIRANDA
         -- DEPENDENCIAS: CREDITOS (pre_tasaspre,pre_prestamos,pre_accrual,pre_desemb,pre_planpagos)
         -- CREACI�N:  30-11-2023
         -- SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         ----------------------------------------------------------------------------------------------------------------------------------------------------
		 --|   Autor   |     Fecha     | SDAPO    |  Descripcion
		 ---------------------------------------------------------------------------
		 --| acanqui   |  15-11-2024   | 2235171  | Adicion de columna para realizar la sumatoria de los intereses devengados sin verificar si tiene pago mes (dato adicionado para el formulario de credito devengados).
		 ----------------------------------------------------------------------------

    DEFINE w_nro_desembolsos    	INTEGER;
    DEFINE w_nro_dias           	INTEGER;
    DEFINE w_interes_devengado  	DECIMAL(16,2);
    DEFINE w_desembolsado       	DECIMAL(16,2);
    DEFINE w_saldocapital       	DECIMAL(16,2);
    DEFINE w_interes_devengado_form DECIMAL(16,2);

    DEFINE w_total_interes_devengado  		DECIMAL(16,2);
    DEFINE w_total_desembolsado       		DECIMAL(16,2);
    DEFINE w_total_saldocapital       		DECIMAL(16,2);
   	DEFINE w_total_interes_devengado_form  	DECIMAL(16,2);
    
    let w_nro_desembolsos = 0;
    let w_nro_dias = 0;
    let w_total_interes_devengado = 0;
    let w_total_desembolsado = 0;
    let w_total_saldocapital = 0;
    let w_total_interes_devengado_form = 0;
    let w_interes_devengado_form=0;
   

    if p_codcred is null or p_codcred <= 0 then
       Raise Exception -746, 0, "[ERR_SDD_001] - El c�digo de cr�dito del proceso especificado no es valido.";
    end if   

    if p_codmod is null or p_codmod <= 0 then
       Raise Exception -746, 0, "[ERR_SDD_002] - La m�dulo de cr�dito del proceso especificado no es valido.";
    end if   
    
    if p_fecha is null  then
       Raise Exception -746, 0, "[ERR_SDD_003] - La fecha para obtener el devengamiento del cr�dito especificado no es valido.";
    end if   
    
    /*CASE WHEN NOT TienePagoMes AND interes_dias <> dias_mes THEN ROUND(saldo * 1 * ((tasa/100)/dias),2) * dias_mes ELSE interes_devengado END, interes_dias, monto_desembolsado, saldo*/
    
    FOREACH SELECT 
                CASE 
                    WHEN NOT TienePagoMes AND interes_dias <> dias_mes THEN ROUND(saldo * 1 * ((tasa/100)/dias),2) * dias_mes  
                    ELSE interes_devengado 
                END, interes_dias, monto_desembolsado, saldo, interes_devengado 
                INTO w_interes_devengado, w_nro_dias, w_desembolsado, w_saldocapital, w_interes_devengado_form
            FROM (
                    select cod_acr,
                           dsb_fecdsb, 
                           monto_desembolsado, 
                           clave_serie,amortizacion, 
                           saldo,
                           tasa,
                           case when not TienePagoMes and interes_dias <> dias_mes and not TieneDesembolsoEnElMes then dias_mes else interes_dias  end as interes_dias,       
                           case when not TienePagoMes and interes_dias <> dias_mes and not TieneDesembolsoEnElMes then  round(saldo * 1 *  ((tasa/100)/dias),2) * dias_mes  else interes_devengado end as interes_devengado,      
                           acr_fecini,TienePagoMes, interes_dias as interes_dias_plan, interes_devengado as interes_plan, round(saldo * 1 *  ((tasa/100)/dias),2) * dias_mes as interes_reporte, dias_mes, dias   
                      from (
                            select acr_codcred, acr_codmod, acr_fecaccru,
                                   acr_codacr cod_acr,dsb_fecdsb,dsb_valor monto_desembolsado,
                                   nvl(dsb_nrodoc,'') clave_serie,acr_capital amortizacion, acr_saldo saldo,
                                   acr_tasavig tasa,acr_diasaccr interes_dias, acr_interes interes_devengado, acr_fecini, DAY(p_fecha) AS dias_mes, 
                                   nvl((SELECT mtp_intydias
                                      FROM pre_tasaspre
                                     WHERE mtp_codcred = acr_codcred
                                       AND mtp_codmod = acr_codmod
                                       AND mtp_fechavig = (SELECT MAX(mtp_fechavig) 
                                                             FROM  pre_tasaspre
                                                            WHERE mtp_codcred = acr_codcred
                                                              AND mtp_codmod = acr_codmod
                                                              AND   mtp_fechavig <= p_fecha)),0) as dias,
                                   (select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean) 
                                      from sysmaster:sysdual
                                     where exists (select 1
                                      from pre_planpagos
                                     where cuo_tabmonpag = 15 
                                       and cuo_monpag = 2
                                       and cuo_coddsb = acr_coddsb
                                       and cuo_codmod = acr_codmod
                                       and cuo_codcred = acr_codcred                   
                                       and year(cuo_fecvencuo) = year(p_fecha)  
                                       and month(cuo_fecvencuo) = month(p_fecha))) as TienePagoMes,
                                   (select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean) 
                                      from sysmaster:sysdual
                                     where exists (select 1
                                      from pre_desemb
                                     where dsb_tabmonpag = 15 
                                       and dsb_monpag = 1
                                       and dsb_coddsb = acr_coddsb
                                       and dsb_codmod = acr_codmod
                                       and dsb_codcred = acr_codcred                   
                                       and year(dsb_fecdsb) = year(p_fecha)  
                                       and month(dsb_fecdsb) = month(p_fecha))) as TieneDesembolsoEnElMes                                      								
                            from d_creditos.pre_prestamos, d_creditos.pre_accrual, d_creditos.pre_desemb
                            where pre_codcred = dsb_codcred
                            and pre_codmod = dsb_codmod
                            and pre_codcred = acr_codcred
                            and pre_codmod = acr_codmod
                            and acr_coddsb = dsb_coddsb
                            and acr_tipoacr = 3
                            and acr_codcred =  p_codcred 
                            and acr_codmod =  p_codmod 
                            and acr_fecaccru = p_fecha
                            order by dsb_fecdsb) 
                    ) AS t
        LET w_nro_desembolsos = w_nro_desembolsos + 1;
        LET w_total_interes_devengado = w_total_interes_devengado + w_interes_devengado;
        LET w_total_desembolsado = w_total_desembolsado + w_desembolsado;
        LET w_total_saldocapital = w_total_saldocapital + w_saldocapital;
        LET w_total_interes_devengado_form = w_total_interes_devengado_form + w_interes_devengado_form;
        
    END FOREACH;

    if (w_nro_desembolsos <=0 or w_nro_dias <= 0 or w_total_interes_devengado = 0 or w_total_desembolsado = 0) then
       Raise Exception -746, 0, "[ERR_SDD_004] - No existen datos del devengamiento o valores en cero"; --  del cr�dito no son validos o no existen  para la fecha: " || p_fecha;
    end if    
    
    RETURN w_nro_desembolsos, w_nro_dias, w_total_interes_devengado, w_total_desembolsado, w_total_saldocapital, w_total_interes_devengado_form;

END PROCEDURE;