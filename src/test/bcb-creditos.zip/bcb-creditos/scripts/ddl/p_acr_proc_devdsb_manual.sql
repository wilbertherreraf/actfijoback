DROP PROCEDURE IF EXISTS p_acr_proc_devdsb_manual;  -- spl nuevo
 
create procedure d_creditos.p_acr_proc_devdsb_manual(p_fechacierre date)
{
wherrera 2021.11.16     Devenga todos los prestamos desde una fecha procesos automaticos 

-- DESCRIPCION: Genera el devengado de todos los creditos registrados en el sistema 
-- PARAMETROS INGRESO: p_fechacierre date
--                     
-- AUTOR: acanqui
-- CREACION: 2025-11-25

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
-----------------------------------------------------------------------------------------------------------------------------------------------------
--|           |               |          | 
-----------------------------------------------------------------------------------------------------------------------------------------------------
--|           |               |          |
-----------------------------------------------------------------------------------------------------------------------------------------------------
--|           |               |          |
-----------------------------------------------------------------------------------------------------------------------------------------------------


}
define v_dsb_codmod, v_dsb_codcred, v_dsb_coddsb integer;
define v_feculttrx, v_fin_gestionant, v_ult_fec_acr, v_fechafinproc, p_fechaini, p_fechafin , v_pge_feccierre, v_pge_fecultrep date;
define v_min_fecvencuo, v_max_fecvencuo date;
define p_codmod integer ;
    
    let p_fechaini = mdy(month(p_fechacierre),1,year(p_fechacierre));
    let p_fechafin = last_day(p_fechacierre);
    let p_codmod = 17;

    select pge_feccierre, pge_fecultrep
    into v_pge_feccierre, v_pge_fecultrep
    from gen_parmgrales
    where pge_codgral = p_codmod;
    
    let p_fechaini = null;
    let v_fin_gestionant = mdy(12,31,year(current) -1);
    let p_fechacierre = nvl(p_fechacierre, current);
   
    -- raise exception -746,0," [detenido] v_fin_gestionant-> " || v_fin_gestionant;

    Select max(acr_fecaccru)
    into v_max_fecvencuo
    from pre_accrual 
    where acr_fecaccru < p_fechacierre;
    
    Select min(a.acr_fecaccru)
    into v_fechafinproc
    from pre_accrual a
    where a.acr_fecaccru > p_fechacierre;

    if v_max_fecvencuo is not null and p_fechacierre > v_max_fecvencuo + 31 then
        raise exception -746,0,"Fecha de proceso excede a la fecha limite, fecha max para devengar " || v_max_fecvencuo + 31;
    end if
    
    if v_fechafinproc is not null then
        Select max(cob_feccontab)
        into v_feculttrx
        from pre_cobros
        where cob_statreg = 0;
        
        if v_feculttrx is not null then
            if v_feculttrx > v_fin_gestionant and p_fechacierre <= v_fin_gestionant - 31 then
                raise exception -746,0,"Fecha de devengado debe ser mayor a " || (v_fin_gestionant - 31);
            end if
        end if
    else  
        let v_fechafinproc = p_fechacierre -1;
    end if
    
    foreach 
        select distinct dsb_codmod, dsb_codcred
        into v_dsb_codmod, v_dsb_codcred
        from pre_prestamos, pre_desemb
        where pre_codmod = dsb_codmod
        and pre_codcred = dsb_codcred
        order by dsb_codcred
        
        -- codigo para insertar la fecha de devengado en caso de devengado manual
        execute procedure inserta_fecha_devengado(v_dsb_codcred, v_dsb_codmod, p_fechacierre);
        
       
        delete from pre_accrual
        where acr_fecaccru >= p_fechacierre
        and acr_fecaccru > v_fin_gestionant
        and acr_codcred = v_dsb_codcred
        and acr_codmod = v_dsb_codmod;
                
                call p_acr_devenga_cred(-1, v_dsb_codcred, null, p_fechacierre);
                let v_fin_gestionant = mdy(12,31,year(p_fechacierre) -1);
    end foreach

        update gen_parmgrales
        set pge_feccierre = p_fechacierre,
        pge_fecultrep = v_fechafinproc,
        pge_feccieant = v_fin_gestionant,
        pge_auditfho = current
        where pge_codgral = p_codmod;
end procedure;   