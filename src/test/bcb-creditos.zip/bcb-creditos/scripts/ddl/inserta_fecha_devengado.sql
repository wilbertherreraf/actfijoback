DROP PROCEDURE IF EXISTS inserta_fecha_devengado;  -- spl nuevo
 
CREATE PROCEDURE d_creditos.inserta_fecha_devengado(p_codcred integer, p_codmod integer, p_fecha date) 

	-- DESCRIPCI�N: Inserta la fecha de devangado en la tabla pre_registro_devengado_creditos para obtener la cantidad de dias e interes 
         -- PARAMETROS INGRESO: p_codcmp integer                Codigo de Comprobante
         --                     p_codcred integer               Codigo de credito
         --                     p_codmod integer                Codigo de modulo
         --                     P_fecha_devengado               Fecha especificada por el usuario al que se toma los intereses devengados
         -- PARAMETROS SALIDA: 
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: 
         --               
         -- CREACI�N:  27-11-2025
         -- SDAPO: 2666825
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- ----------------------------------------------------------------------------------------------------------------------------------------------------
		--|   Autor   |     Fecha     | SDAPO    |  Descripcion
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|           |               |          |
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|           |               |          |
		-----------------------------------------------------------------------------------------------------------------------------------------------------

	DEFINE RESULTADO INTEGER;
    let RESULTADO= 0;
-- codigo para eliminar las fechas de devengados posterior a la fecha que se esta registrando, este proceso se realiza de acuerdo al proceso de la tabla pre_accrual
	  	--raise exception -746,0," [detenido] 1. v_cuo_fecvencuo-> " || v_cuo_fecvencuo || " p_codcred-> " ||p_codcred;
	delete from pre_registro_devengado_creditos
	where fecha_devengado > p_fecha
	and codcred = p_codcred;
    
    -- CODIGO PARA REGISTRAR LA FECHA DE DEVENGADO DE ACUERDO A LOS DATOS INSERTADOS PREVIAMNTE EN LA TABLA pre_accrual
	if (select count(1) from d_creditos.pre_registro_devengado_creditos where codcred=p_codcred and fecha_devengado=p_fecha )=0 then -- codigo para evitar doble registro
		-- codigo para insertar la fecha de devengado en la tabla pre_registro_devengado_creditos
		INSERT INTO d_creditos.pre_registro_devengado_creditos (codcred, codmod, fecha_devengado, cambio_bd, audit_usuario, audit_fechahora, audit_host) 
		VALUES(p_codcred, p_codmod, p_fecha, null, user, current, (select trim(hostname) from sysmaster:syssessions where sid = (select DBINFO('sessionid') from systables where tabname = 'systables')));
	end if 
	
	if dbinfo ("sqlca.sqlerrd2") = 0 then  -- no hizo el insert
	    	Raise Exception -746, 0, "[ERROR_REGISTRO_CORTE_DEVENGADO_001] - No se pudo registrar la fecha de devengado en el sistema. Fecha: "|| p_fecha ||" N� Credito: "|| p_codcred;
	end if
	

END PROCEDURE;