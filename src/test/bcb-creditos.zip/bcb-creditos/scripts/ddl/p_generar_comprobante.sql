DROP PROCEDURE IF EXISTS p_generar_comprobante; -- SPL MODIFICADO

create procedure d_creditos.p_generar_comprobante (p_codcmp integer, p_codcred integer, p_codmod integer, p_fecha_2 date, p_usuario varchar(15), p_estacion varchar(50))    
    returning integer as codprc; 

         -- DESCRIPCI�N: Obtiene los datos de un parametro de la tabla correspondiente
         -- PARAMETROS INGRESO: p_codcmp integer                Codigo de Comprobante
         --                     p_codcred integer               Codigo de credito
         --                     p_codmod integer                Codigo de modulo
         --                     P_fecha_devengado               Fecha especificada por el usuario al que se toma los intereses devengados
         --                     p_usuario varchar(15)           Codigo de usuario
         --                     p_estacion varchar(50)          Estacion de donde viene la solicitud (IP)
         -- PARAMETROS SALIDA: codprc as integer                Codigo de Proceso
         -- AUTOR: HENRY IVAN PANIQUE MIRANDA
         -- DEPENDENCIAS: CONTBCB (comprobante, dia)
         --              CREDITOS (gen_renglon, pre_prcconta) 
         -- CREACI�N:  30-11-2023
         -- SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- ----------------------------------------------------------------------------------------------------------------------------------------------------
		--|   Autor   |     Fecha     | SDAPO    |  Descripcion
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|  acanqui  |  27-11-2025   | 2666825  | Ajustes en el procedimiento para obtener el valor de los dias e interes de devengado de acuerdo al requerimiento
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|           |               |          |
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|           |               |          |
		-----------------------------------------------------------------------------------------------------------------------------------------------------



      define w_codprc           integer;
      define w_estado_ini_cmp   varchar(1);
      define w_resultado        boolean;
      
      define W_SOURCE_MATRIZ_PARAMETROS   INTEGER;
      define W_SOURCE_DEFAULT             INTEGER;
      define W_SOURCE_MATRIZ_PROCESO      INTEGER;
      define W_TIPO_PARAMETRO             INTEGER;
    
      define w_par_parametro              VARCHAR(255);    
      DEFINE w_parametros_glosa           VARCHAR(255);
  
      DEFINE w_par_glosa VARCHAR(255);
      define w_start_index                  integer;     
      define w_end_index                    integer; 
      define w_nro_parametro                integer;    
      define w_ok                           boolean;    
     
      define w_tienePagoMes                 boolean;
      define w_tieneDesembolsoEnElMes       boolean;

--  definicion de variables del proceso

     define w_prc_fecha         like pre_prcconta.prc_fecha; 
     define w_prc_codcmp        like pre_prcconta.prc_codcmp; 
     define w_prc_codcred       like pre_prcconta.prc_codcred; 
     define w_prc_codmod        like pre_prcconta.prc_codmod; 
     define w_prc_estado        like pre_prcconta.prc_estado;
    
--   Definicion de Variables de la paramerizacion del comprobante
    
     define w_cmp_desc      like gen_comprobante.cmp_desc;
     define w_cmp_esquema   like gen_comprobante.cmp_esquema;
     define w_cmp_centro    like gen_comprobante.cmp_centro;     
     define w_cmp_tipo      like gen_comprobante.cmp_tipo;     
     define w_cmp_glosa     like gen_comprobante.cmp_glosa;
     define w_cmp_dev_real  like gen_comprobante.cmp_dev_real;     
     define w_cmp_tabestado like gen_comprobante.cmp_tabestado;
     define w_cmp_estado    like gen_comprobante.cmp_estado;

-- Definicion de Variables del header del comprobante

     define w_gestion           like contbcb@bcbux02:d_conta.comprobante.gestion;
     define w_nro_periodo       like contbcb@bcbux02:d_conta.comprobante.nro_periodo;
     define w_nro_dia           like contbcb@bcbux02:d_conta.comprobante.nro_dia;     
     define w_factor_conv_us_m  like contbcb@bcbux02:d_conta.comprobante.factor_conv_us_mn;
     define w_cod_unidad        like contbcb@bcbux02:d_conta.comprobante.cod_unidad;
     define w_nro_comprob       like contbcb@bcbux02:d_conta.comprobante.nro_comprob;
     define w_cve_tipo_comprob  like contbcb@bcbux02:d_conta.comprobante.cve_tipo_comprob;
     define w_fecha_dia         like contbcb@bcbux02:d_conta.dia.fecha_dia; 

-- Variables para el manejo de los renglones del comprobante
     define w_nro_renglones     integer;
     define w_rln_numero        like gen_renglon.rln_numero;
     define W_ESTADO_HABILITADO integer;
     define w_fecha_coin        date;
   
     define w_dif_devengado date;	
     define w_cantidad_dias_devengado integer;

--  inicializacion de variables

     let w_estado_ini_cmp = "P";     
     let W_ESTADO_HABILITADO = 1;
     let W_SOURCE_MATRIZ_PARAMETROS = 1;
     let W_SOURCE_DEFAULT = 2;
     let W_SOURCE_MATRIZ_PROCESO = 3;     
     let W_TIPO_PARAMETRO = 27; --glosa 1 del comprobante
     
     let w_dif_devengado = 0;
     let w_cantidad_dias_devengado = 0;


        
--  Validar parametros

    if TRIM(p_usuario) IS NULL OR LENGTH(TRIM(p_usuario)) = 0 then
       Raise Exception  -746, 0, "[ERR_PGC_006] - El valor proporcionado para el parametro usuario no es valido (p_usuario).";
    end if   

--  iniciar proceso
-- inserta registros en la tabla PRE_PRCCONTA
    call p_init_proceso_conta (p_codcmp, p_codcred, p_codmod, p_fecha_2, p_usuario, p_estacion) returning w_codprc;

--  establecer parametros del proceso 

    call p_set_params_proceso_conta (w_codprc)  returning w_resultado;
    if not w_resultado then
      Raise Exception  -746, 0, "[ERR_PGC_007] - No se pudo generar/obtner los prametros pra el proceso.";
    end if    
    
 -- obtener datos del proceso
 
     select prc_fecha, prc_codcmp, prc_codcred, prc_codmod, prc_estado
       into w_prc_fecha, w_prc_codcmp, w_prc_codcred, w_prc_codmod, w_prc_estado
       from d_creditos.pre_prcconta   
      where prc_codprc = w_codprc;

    if w_prc_codcmp is null or w_prc_codcmp <=0 then
       Raise Exception -746, 0, "[ERR_PGC_001] - El valor para el parametro c�digo de comprobante no es valido (codcmp).";
    end if   

    if w_prc_fecha is null then
       Raise Exception -746, 0, "[ERR_PGC_002] - El valor  para el parametro fecha no es valido (fecha).";
    else
       select fecha_dia 
         into w_fecha_coin 
         from contbcb@bcbux02:d_conta.dia   
        where cve_estado_dia = "A";
          
        if w_fecha_coin != w_prc_fecha then   
           Raise Exception  -746, 0, "[ERR_PGC_009] - Fecha habilitada en COIN no coincide con SISCRED (Servidor BD)";
        end if   
    end if   

    if w_prc_codcred is null or w_prc_codcred <=0 then
       Raise Exception  -746, 0, "[ERR_PGC_003] - El valor  para el parametro c�digo de cr�dito no es valido (codcred).";
    end if   

    if w_prc_codmod is null or w_prc_codmod <=0 then
       Raise Exception  -746, 0, "[ERR_PGC_004] - El valor  para el parametro m�dulo del cr�dito no es valido (codmod).";
    end if   
    
    if w_prc_estado is null or w_prc_estado <> 1 then
       Raise Exception  -746, 0, "[ERR_PGC_005] - El estado del proceso no es pendiente (w_prc_estado).";
    end if   
 
 -- obtener parametros del comprobante especificado
  
    call d_creditos.p_get_par_comprobante(w_prc_codcmp) returning w_cmp_desc, w_cmp_esquema, w_cmp_centro, w_cmp_tipo,
                                                                  w_cmp_glosa, w_cmp_dev_real, w_cmp_tabestado, w_cmp_estado;
    
    if not w_cmp_estado = W_ESTADO_HABILITADO then
       Raise Exception  -746, 0, "[ERR_PGC_007] - El comprobante especificado no esta habilitado.";
    end if
    
    select count(1)
      into w_nro_renglones
      from d_creditos.gen_renglon 
     where rln_codcmp = w_prc_codcmp
       and rln_estado = W_ESTADO_HABILITADO;

       
    if dbinfo("sqlca.sqlerrd2") = 0 then   
       Raise Exception  -746, 0, "[ERR_PGC_008] - El comprobante no tiene renglones parametrizados o con estado habilitado.";
    end if


 -- obtener datos del header del comprobante
 
    Call d_creditos.p_get_header_comprobante (w_prc_fecha, w_cmp_centro, p_usuario, w_cmp_tipo) returning w_nro_comprob, w_gestion, w_nro_periodo, w_nro_dia,
                                                                                                          w_fecha_dia, w_cod_unidad, w_factor_conv_us_m;
                                                                                                          
 -- obtener los datos de los parametros de la glosa del comprobant
    call f_get_parametro (w_codprc, W_SOURCE_MATRIZ_PROCESO, W_TIPO_PARAMETRO, null, w_prc_codcred, w_prc_codmod) returning w_parametros_glosa;
    LET w_start_index = 1;
    let w_nro_parametro = 1;
   
							

    WHILE w_start_index > 0 
          LET w_end_index = INSTR(w_parametros_glosa, '|', w_start_index);
          IF w_end_index > 0 THEN
             LET w_par_glosa = SUBSTR(w_parametros_glosa, w_start_index, w_end_index - w_start_index);
             LET w_start_index = w_end_index + 1;
          ELSE
             LET w_par_glosa = SUBSTR(w_parametros_glosa, w_start_index);
             LET w_start_index = 0; -- Establece w_start_index a 0 para terminar el bucle
          END IF;
         
          -- reemplaza el parametro en la glosa
          if w_nro_parametro=1 then -- codigo para ajustar los dias de devengado que se enviara a la glosa -- solo para el primer registro	
          
          	 let w_tienePagoMes	=(select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean) TienePagoMes
                                      from sysmaster:sysdual
                                     where exists (select 1
                                      from pre_planpagos
                                     where cuo_tabmonpag = 15 
                                       and cuo_monpag = 2
                                       and cuo_codmod = p_codmod
                                       and cuo_codcred = p_codcred                   
                                       and year(cuo_fecvencuo) = year(p_fecha_2)  
                                       and month(cuo_fecvencuo) = month(p_fecha_2)) ); -- verificamos que tenga pagos
                                      
              let w_tieneDesembolsoEnElMes	=(select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean)  TieneDesembolsoEnElMes
                                      from sysmaster:sysdual
                                     where exists (select 1
                                      from pre_desemb
                                     where dsb_tabmonpag = 15 
                                       and dsb_monpag = 1
                                       and dsb_codmod = p_codmod
                                       and dsb_codcred = p_codcred                   
                                       and year(dsb_fecdsb) = year(p_fecha_2)  
                                       and month(dsb_fecdsb) = month(p_fecha_2)));  -- verificamos que tenga desembolsos                       
          	 

				if not w_tienePagoMes and not w_tieneDesembolsoEnElMes then    -- verifica que no tenga pagos ni desembolsos                                  
		          	  let w_dif_devengado=(select max(prc_fecha_2) from pre_prcconta where prc_codcred = p_codcred and prc_codmod=p_codmod and prc_estado=3);
			          let w_par_glosa=p_fecha_2-w_dif_devengado;
			    end if     
	         
    	  end if	
    	  
--    	  Raise Exception -746, 0, "[error] - w_par_glosa: "|| w_par_glosa;
         	
          LET w_cmp_glosa = REPLACE(w_cmp_glosa, "{#P" || w_nro_parametro || "}"  , w_par_glosa );
          LET w_nro_parametro = w_nro_parametro + 1;        
     END WHILE;


    

 -- insertar el comprobante   
 
    Insert Into contbcb@bcbux02:d_conta.comprobante (nro_centro, cve_tipo_comprob, nro_comprob, gestion, nro_periodo, nro_dia, fecha_valor, 
                                     factor_conv_us_mn, glosa_comprob, cod_esquema,cve_subesquema, nro_operacion, cve_estado_comprob,
                                     cod_usuario, fecha_hora, estacion, nro_aprobacion, cod_unidad, cve_dev_real) 
                                     
                             Values (w_cmp_centro, w_cmp_tipo, w_nro_comprob, w_gestion, w_nro_periodo, w_nro_dia, null,
                                     w_factor_conv_us_m, w_cmp_glosa, w_cmp_esquema, null, 0, w_estado_ini_cmp,
                                     p_usuario, current, p_estacion, null, w_cod_unidad, w_cmp_dev_real);



 -- Generar Renglones
    
    Foreach select rln_numero into w_rln_numero from d_creditos.gen_renglon where rln_codcmp = w_prc_codcmp and rln_numero > 0 and rln_estado = w_estado_habilitado 
       call p_generar_renglon (w_codprc, w_prc_codcmp, w_cmp_centro , w_cmp_tipo, w_nro_comprob, w_rln_numero, w_prc_codcred, w_prc_codmod, w_gestion, w_nro_periodo, w_nro_dia, p_fecha_2) returning w_ok; 
       if not w_ok then
          Raise Exception  -746, 0, "[ERR_PGC_009] - Error al procesar renglon del comprobante" || w_rln_numero;
       end if   
    End Foreach

-- insertar estado pendiente del comprobante   
--    insert 
--      into contbcb@bcbux02:d_conta.estado_comprob
--    values (w_cmp_centro, w_cmp_tipo, w_nro_comprob, "P", p_usuario, current, p_estacion);

 -- actualizar datos del proceso
     update d_creditos.pre_prcconta
        set prc_nro_centro = w_cmp_centro,  
            prc_cve_tipo_comprob = w_cmp_tipo,
            prc_nro_comprob = w_nro_comprob       
      where prc_codprc = w_codprc;

--     Raise Exception  -746, 0, "DEBUG f:" || p_codcmp || "," || p_codcred || "," || p_codmod || "," || p_usuario || "," || p_estacion;    

  
    return w_codprc;
          
end procedure; 