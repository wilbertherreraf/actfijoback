DROP PROCEDURE IF EXISTS p_generar_comprobante_registro_bonos; 

create procedure d_creditos.p_generar_comprobante_registro_bonos (p_idtabla integer, p_tiporegistro integer, p_codcred integer, p_codmod integer, p_fecha date, p_glosa lvarchar(500), p_usuario varchar(15), p_estacion varchar(50))    
    returning integer as nro_comprob; 

         -- DESCRIPCION: Procedimiento para generar comprobantes en el COIN
         -- PARAMETROS INGRESO: p_idtabla integer				Id de la tabla pre_registrogarantias
   		 --						p_tiporegistro integer          Tipo de rgistro para la consulta Registro transitorio de garantias, 
         --                     p_codcred integer               Codigo de credito
         --                     p_codmod integer                Codigo de modulo
         --                     p_fecha 			            Fecha de registro del proceso
         --                     p_glosa							Descripcion de la glosa que se registrara en el comprobante 
         --                     p_usuario varchar(15)           Codigo de usuario
         --                     p_estacion varchar(50)          Estacion de donde viene la solicitud (IP)
         -- PARAMETROS SALIDA: codprc as integer                Codigo de Proceso
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: CONTBCB (comprobante, dia)
         --               CREDITOS (gen_renglon, pre_prcconta) 
         -- CREACION:  05-02-2025
         -- SDAPO: 2344735
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
     --|   Autor  |     Fecha   |  Sdapo   |  Descripcion
	 ---------------------------------------------------------------------------
	 --| mcramos  |  05-03-2025 | 2367989  | Ajuste para generacion de comprobante para registro de Custodia de Garantia
	 ---------------------------------------------------------------------------
	 --| mcramos  |  12-03-2025 | 2368094  | Ajuste para generacion de comprobante para registro de Retiro de Garantia
	 ---------------------------------------------------------------------------
	 --| mcramos  |  05-03-2025 | 2367989  | Ajuste para generacion de comprobante para registro de Custodia de Garantia
	 ---------------------------------------------------------------------------
	 --| mcramos  |  12-03-2025 | 2368094  | Ajuste para generacion de comprobante para registro de Retiro de Garantia
	 ---------------------------------------------------------------------------
	 --| acanqui  |  06-05-2025 | 2401886  | Ajuste para generacion de comprobante para registro contable de Pago de Cuota
	 ---------------------------------------------------------------------------

      define w_estado_ini_cmp   varchar(1);
      
      define W_SOURCE_MATRIZ_PARAMETROS   INTEGER;
      define W_SOURCE_DEFAULT             INTEGER;
      define W_SOURCE_MATRIZ_PROCESO      INTEGER;
      define W_TIPO_PARAMETRO             INTEGER;
    
      define w_par_parametro              VARCHAR(255);    
      DEFINE w_parametros_glosa           VARCHAR(255);
  
      DEFINE w_par_glosa VARCHAR(255);
      define w_start_index                  integer;     
      define w_end_index                    integer; 
      define w_nro_parametro                integer;    
      define w_ok                           boolean;    
     
     
     
	-- variables para el registro de comprobantes	     
	  define w_fecha 					DATE;
	  define w_estado 					INTEGER;
	  define w_esquema_credito			VARCHAR(30);
	 
	 -- constantes
	  define COMPROBANTE_REG_TRANSITORIO 	INTEGER;
	  define REGISTRO_TRANSITORIO_GARANTIAS INTEGER;
	  define REGISTRO_CONTABLE_DESEMBOLSOS_EPNES  INTEGER;
	  define REGISTRO_CONTABLE_DESEMBOLSOS_MEFP  INTEGER;
	  define CUSTODIA_GARANTIA 				INTEGER;
      define REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA INTEGER;
      define REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA INTEGER;
	  define RETIRO_GARANTIA 				INTEGER;	
	  define COMPROBANTE_REGISTRO			INTEGER;  
	 
	  define ESQUEMA_CREDITO 				INTEGER;
	 
	  define REG_CONT_PAGO_AMORTIZACION_INTERESES_EPNE_MEFP INTEGER;
	  define REG_CONT_PAGO_AMORTIZACION_INTERESES_YPFB_FNDR INTEGER;
	  define REG_CONT_PAGO_INTERESES_EPNE_MEFP INTEGER;
	  define REG_CONT_PAGO_INTERESES_YPFB_FNDR INTEGER;
	   
   
--   Definicion de Variables de la paramerizacion del comprobante
    
     define w_cmp_desc      like gen_comprobante.cmp_desc;
     define w_cmp_esquema   like gen_comprobante.cmp_esquema;
     define w_cmp_centro    like gen_comprobante.cmp_centro;     
     define w_cmp_tipo      like gen_comprobante.cmp_tipo;     
     define w_cmp_glosa     lvarchar(500); -- like gen_comprobante.cmp_glosa;
     define w_cmp_dev_real  like gen_comprobante.cmp_dev_real;     
     define w_cmp_tabestado like gen_comprobante.cmp_tabestado;
     define w_cmp_estado    like gen_comprobante.cmp_estado;

-- Definicion de Variables del header del comprobante

     define w_gestion           like contbcb@bcbux02:d_conta.comprobante.gestion;
     define w_nro_periodo       like contbcb@bcbux02:d_conta.comprobante.nro_periodo;
     define w_nro_dia           like contbcb@bcbux02:d_conta.comprobante.nro_dia;     
     define w_factor_conv_us_m  like contbcb@bcbux02:d_conta.comprobante.factor_conv_us_mn;
     define w_cod_unidad        like contbcb@bcbux02:d_conta.comprobante.cod_unidad;
     define w_nro_comprob       like contbcb@bcbux02:d_conta.comprobante.nro_comprob;
     define w_cve_tipo_comprob  like contbcb@bcbux02:d_conta.comprobante.cve_tipo_comprob;
     define w_fecha_dia         like contbcb@bcbux02:d_conta.dia.fecha_dia; 

-- Variables para el manejo de los renglones del comprobante
     define w_nro_renglones     integer;
     define w_rln_numero        like gen_renglon.rln_numero;
     define W_ESTADO_HABILITADO integer;
     define w_fecha_coin        date;
    
 
    
    /* ***sdefine v_pathlog varchar(250); -- log
    let v_pathlog = 'p_generar_comprobante_registro_bonos.log'; -- log
    SET DEBUG FILE TO v_pathlog; -- log */
    
    -- inicio de variables por tipo de regitro/proceso
    let REGISTRO_TRANSITORIO_GARANTIAS=8;
    let REGISTRO_CONTABLE_DESEMBOLSOS_EPNES=1;
    let REGISTRO_CONTABLE_DESEMBOLSOS_MEFP=2;
    LET REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA=9;
    LET REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA=10; 
   	
    LET REG_CONT_PAGO_AMORTIZACION_INTERESES_EPNE_MEFP=4;
	LET REG_CONT_PAGO_AMORTIZACION_INTERESES_YPFB_FNDR=5;
	LET REG_CONT_PAGO_INTERESES_EPNE_MEFP=6;
	LET REG_CONT_PAGO_INTERESES_YPFB_FNDR=7;
   
--  inicializacion de variables

     let w_estado_ini_cmp = "P";     
     let W_ESTADO_HABILITADO = 1;
     let W_SOURCE_MATRIZ_PARAMETROS = 1;
     let W_SOURCE_DEFAULT = 2;
     let W_SOURCE_MATRIZ_PROCESO = 3;     
     let W_TIPO_PARAMETRO = 27; --glosa 1 del comprobante
     let COMPROBANTE_REGISTRO=0;

     
    let COMPROBANTE_REG_TRANSITORIO=8; -- constante para el registro transitorio de garantia (parametro definido en la tabla 'd_creditos.gen_comprobante')
    
	let CUSTODIA_GARANTIA=2;
	let RETIRO_GARANTIA=3;
     
     
   
--  Validar parametros

    if TRIM(p_usuario) IS NULL OR LENGTH(TRIM(p_usuario)) = 0 then
       Raise Exception  -746, 0, "[ERROR_COMP_001] - El valor proporcionado para el parametro usuario no es valido (p_usuario).";
    end if   

--  establecer parametros del proceso 
    
    if p_idtabla is null or p_idtabla <=0 then
      Raise Exception  -746, 0, "[ERROR_COMP__002] - No se pudo obtener los parametros del proceso, verifique registro de información.";
    end if    
    
    
    /** VERIFICAMOS QUE PROCESO SE REALIZA PARA OBTENER LOS VALORES QUE SE REGISTRARAN EN EL COMPROBANTE**/
    if p_tiporegistro=REGISTRO_TRANSITORIO_GARANTIAS then 
    	
			-- obtenemos los datos de la tabla 'pre_registrogarantias' para el proceso  REGISTRO_TRANSITORIO_GARANTIAS
			     select fecha, estado
			     into w_fecha,w_estado
			     from d_creditos.pre_registrogarantias   
			     where id = p_idtabla;
    end if
    
    if p_tiporegistro=REGISTRO_CONTABLE_DESEMBOLSOS_EPNES or p_tiporegistro=REGISTRO_CONTABLE_DESEMBOLSOS_MEFP then 
    	
			-- obtenemos los datos de la tabla 'creditos:d_creditos.pre_desembolso_detalle' para el proceso  REGISTRO_CONTABLE_DESEMBOLSOS
			     select fecha, estado
			     into w_fecha,w_estado
			     from d_creditos.pre_desembolso_detalle   
			     where id= p_idtabla;
    end if
    
    if p_tiporegistro=REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA then 
        
                        -- obtenemos los datos de la tabla 'creditos:d_creditos.pre_custodia_garantia' para el proceso  REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA
                             select fecha, estado
                             into w_fecha,w_estado
                             from d_creditos.pre_custodia_garantia   
                             where id= p_idtabla;
    end if
    
    if p_tiporegistro=REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA then 
        
                        -- obtenemos los datos de la tabla 'creditos:d_creditos.pre_retiro_garantia' para el proceso  REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA
                             select fecha, estado
                             into w_fecha,w_estado
                             from d_creditos.pre_retiro_garantia   
                             where id= p_idtabla;
    end if
   
   
    -- REGISTRO CONTABLE DE PAGO DE CUOTA
    if p_tiporegistro=REG_CONT_PAGO_AMORTIZACION_INTERESES_EPNE_MEFP or p_tiporegistro=REG_CONT_PAGO_AMORTIZACION_INTERESES_YPFB_FNDR or p_tiporegistro=REG_CONT_PAGO_INTERESES_EPNE_MEFP or p_tiporegistro=REG_CONT_PAGO_INTERESES_YPFB_FNDR then 
   
                        -- obtenemos los datos de la tabla 'creditos:d_creditos.pre_retiro_garantia' para el proceso  REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA
                             select fecha, estado
                             into w_fecha,w_estado
                             from d_creditos.pre_pagocuota   
                             where id= p_idtabla;
    end if
    
     
   

    if w_fecha is null then
       Raise Exception -746, 0, "[ERROR_COMP_003] - El valor  para el parametro fecha no es valido (fecha).";
    else
	        -- obtiene fecha del COIN y compara con la fecha de rrgistro del proceso 
       		select fecha_dia 
	        into w_fecha_coin 
    	    from contbcb@bcbux02:d_conta.dia   
        	where cve_estado_dia = "A";
          
        if w_fecha_coin != w_fecha then   
           Raise Exception  -746, 0, "[ERROR_PGC_004] - Fecha habilitada en COIN no coincide con SISCRED (Servidor BD)";
        end if   
    end if   

    if p_codcred is null or p_codcred <=0 then
       Raise Exception  -746, 0, "[ERROR_COMP_005] - El valor  para el parametro código de crédito no es valido (codcred).";
    end if   

    if p_codmod is null or p_codmod <=0 then
       Raise Exception  -746, 0, "[ERROR_COMP_006] - El valor  para el parametro módulo del crédito no es valido (codmod).";
    end if   
    
    if w_estado is null or w_estado <> 1 then
       Raise Exception  -746, 0, "[ERROR_COMP_007] - El estado del proceso no es pendiente (w_estado).";
    end if   

    
    -- asignamos el valor a la variable COMPROBANTE_REGISTRO de acuerdo al tipo de proceso que se realiza
    if p_tiporegistro=REGISTRO_TRANSITORIO_GARANTIAS then 
    	let COMPROBANTE_REGISTRO=8;
--    	let ESQUEMA_CREDITO=22;
    end if
    
    if p_tiporegistro=REGISTRO_CONTABLE_DESEMBOLSOS_EPNES then 
    	let COMPROBANTE_REGISTRO=1;
    end if
    
    if p_tiporegistro=REGISTRO_CONTABLE_DESEMBOLSOS_MEFP then 
    	let COMPROBANTE_REGISTRO=2;
    end if
    
    if p_tiporegistro=REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA then 
        let COMPROBANTE_REGISTRO=9;
    end if
    
    if p_tiporegistro=REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA then 
        let COMPROBANTE_REGISTRO=10;
    end if
    
    -- codigo para pago de cuota
    if p_tiporegistro=REG_CONT_PAGO_AMORTIZACION_INTERESES_EPNE_MEFP then 
        let COMPROBANTE_REGISTRO=4;
    end if
    
    if p_tiporegistro=REG_CONT_PAGO_AMORTIZACION_INTERESES_YPFB_FNDR then 
        let COMPROBANTE_REGISTRO=5;
    end if
    
    if p_tiporegistro=REG_CONT_PAGO_INTERESES_EPNE_MEFP then 
        let COMPROBANTE_REGISTRO=6;
    end if
    
    if p_tiporegistro=REG_CONT_PAGO_INTERESES_YPFB_FNDR then 
        let COMPROBANTE_REGISTRO=7;
    end if
    
 -- obtener parametros del comprobante especificado
  -- recupera el texto que registro que se utilizara para la glosa, realiza una consulta a la tabla "gen_comprobante"
  -- recupera este texto y otros parametros adicionales "INTERESES DEVENGADOS POR {#P1} DIAS DE {#P2},POR {#P3} DESEMB.DEL CRED.{#P4},TOT. DESEMB. Bs{#P5} SALDO A CAP. Bs{#P6} EN EL MARCO DE LA RD {#P7} Y CONT. SANO-DLBCI N°{#P8} Y DOC ADJ."  
    call d_creditos.p_get_par_comprobante(COMPROBANTE_REGISTRO) returning w_cmp_desc, w_cmp_esquema, w_cmp_centro, w_cmp_tipo,
                                                                  w_cmp_glosa, w_cmp_dev_real, w_cmp_tabestado, w_cmp_estado;

	
                                                                 
    if not w_cmp_estado = W_ESTADO_HABILITADO then
       Raise Exception  -746, 0, "[ERROR_COMP_008] - El comprobante especificado no esta habilitado.";
    end if

    
    /*** obtiene el numero de renglones de la tabla "d_creditos.gen_renglon" para el DEBE 'D' y el HABER 'H' para el registro transitorio de bonos, solo existen dos registros en esta tabla   ***/
    /** en caso derequerir el registro de la tabla imp_presup se deben registrar las dos filas en la tabla "d_creditos.gen_renglon" **/
	    select count(1)
	    into w_nro_renglones
	    from d_creditos.gen_renglon 
	    where rln_codcmp = COMPROBANTE_REGISTRO
	    and rln_estado = W_ESTADO_HABILITADO;
  
    if dbinfo("sqlca.sqlerrd2") = 0 then   
       Raise Exception  -746, 0, "[ERROR_COMP_009] - El comprobante no tiene renglones parametrizados o no estado habilitado.";
    end if
    


	-- obtener datos del header del comprobante
   	/** obtiene el numero de comprobante, gestion ,periodo y factor de conversion (6.96 o 6.86) **/
    Call d_creditos.p_get_header_comprobante (w_fecha, w_cmp_centro, p_usuario, w_cmp_tipo) returning w_nro_comprob, w_gestion, w_nro_periodo, w_nro_dia,
                                                                                                          w_fecha_dia, w_cod_unidad, w_factor_conv_us_m;
                                                                                                         
	let w_cmp_glosa=p_glosa;

                                                                                                         
                                                                                                         
 -- insertar el comprobante   -- CABECERA
 -- inserta comprobante en la tabla d_conta.comprobante con los datos recuperados  con el codigo de mas arriba
    Insert Into contbcb@bcbux02:d_conta.comprobante (nro_centro, cve_tipo_comprob, nro_comprob, gestion, nro_periodo, nro_dia, fecha_valor, 
                                     factor_conv_us_mn, glosa_comprob, cod_esquema,cve_subesquema, nro_operacion, cve_estado_comprob,
                                     cod_usuario, fecha_hora, estacion, nro_aprobacion, cod_unidad, cve_dev_real) 
                                     
                             Values (w_cmp_centro, w_cmp_tipo, w_nro_comprob, w_gestion, w_nro_periodo, w_nro_dia, null,
                                     w_factor_conv_us_m, w_cmp_glosa, w_cmp_esquema, null, 0, w_estado_ini_cmp,
                                     p_usuario, current, p_estacion, null, w_cod_unidad, w_cmp_dev_real);
                                    
	if dbinfo("sqlca.sqlerrd2") = 0 then   
       Raise Exception  -746, 0, "[ERROR_COMP_010] - No se registro comprobante -> "||w_nro_comprob||", comunicarse con el administrador del sistema. Verificar COIN.";
    end if	

 
	-- Generar Renglones
    /*** el foreach obtiene las dos unicas filas de la tabla creditos:d_creditos.gen_renglon para el DEBE 'D' y el HABER 'H' ***/
    FOREACH select rln_numero into w_rln_numero from d_creditos.gen_renglon where rln_codcmp = COMPROBANTE_REGISTRO and rln_numero > 0 and rln_estado = W_ESTADO_HABILITADO 
    
       call p_generar_renglon_bonos (p_idtabla, COMPROBANTE_REGISTRO, w_cmp_centro, w_cmp_tipo, w_nro_comprob, w_rln_numero, p_codcred, p_codmod, w_gestion, w_nro_periodo, w_nro_dia) returning w_ok; 
       if not w_ok then
          Raise Exception  -746, 0, "[ERROR_COMP_011] - Error al procesar renglon del comprobante" || w_rln_numero;
       end if   
       
    END FOREACH
                                    
 

    
	if p_tiporegistro=REGISTRO_TRANSITORIO_GARANTIAS then 
	      -- actualizar datos del proceso en la tabla pre_registrogarantias
		  update d_creditos.pre_registrogarantias
	        set glosa_coin = w_cmp_glosa,
	            nro_comprobante_coin = w_nro_comprob       
	      where id = p_idtabla; 
    end if
    
    if p_tiporegistro=REGISTRO_CONTABLE_DESEMBOLSOS_EPNES or p_tiporegistro=REGISTRO_CONTABLE_DESEMBOLSOS_MEFP then 
    	
			 -- actualizar datos del proceso en la tabla pre_registrogarantias
			  update d_creditos.pre_desembolso_detalle
		        set glosa_coin = w_cmp_glosa,
		            nro_comprobante_coin = w_nro_comprob       
		      where id = p_idtabla; 
    end if

    if p_tiporegistro=REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA then 
        
            -- actualizar datos del proceso en la tabla pre_custodia_garantia
            update d_creditos.pre_custodia_garantia
                set glosa_coin = w_cmp_glosa,
                    nro_comprobante_coin = w_nro_comprob       
                where id = p_idtabla; 
    end if  
    
    if p_tiporegistro=REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA then 
        
            -- actualizar datos del proceso en la tabla pre_retiro_garantia
            update d_creditos.pre_retiro_garantia
                set glosa_coin = w_cmp_glosa,
                    nro_comprobante_coin = w_nro_comprob       
                where id = p_idtabla; 
    end if
    
    -- pago de cuota
    if p_tiporegistro in (REG_CONT_PAGO_AMORTIZACION_INTERESES_EPNE_MEFP, REG_CONT_PAGO_AMORTIZACION_INTERESES_YPFB_FNDR, REG_CONT_PAGO_INTERESES_EPNE_MEFP, REG_CONT_PAGO_INTERESES_YPFB_FNDR) then 
        
	    
            -- actualiza datos del proceso en la tabla pre_pagocuota
            update d_creditos.pre_pagocuota
            set glosa_coin = w_cmp_glosa,
                nro_comprobante_coin = w_nro_comprob       
            where id = p_idtabla; 
    end if
    
    return w_nro_comprob; 
          
end procedure;