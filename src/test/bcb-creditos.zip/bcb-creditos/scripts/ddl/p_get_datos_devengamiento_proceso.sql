-- QUERY 4
DROP PROCEDURE IF EXISTS p_get_datos_devengamiento_proceso;

-- SPL MODIFICADO
CREATE PROCEDURE d_creditos.p_get_datos_devengamiento_proceso(p_codprc integer) RETURNING INTEGER AS nro_desembolsos, integer as  nro_dias, DECIMAL(16,2) AS interes_devengado, DECIMAL(16,2) as desembolsado, DECIMAL(16,2) as saldocapital;

         -- DESCRIPCI�N: Obtiene los datos del devengamineto de un credito a partie de un proceso iniciado de la tablas correspondientes
         -- PARAMETROS INGRESO: p_codprc INTEGER                       Codigo de proceso
         -- PARAMETROS SALIDA: nro_desembolsos INTEGER                 Nro de desembolsos
         --                    nro_dias INTEGER                        Nro de d�as
         --                    interes_devengado DECIMAL(16,2)         Monto Interes devengado
         --                    desembolsado DECIMAL(16,2)              Monto Desembolsado
         --                    saldocapital DECIMAL(16,2)              Saldo Capital
         -- AUTOR: HENRY IVAN PANIQUE MIRANDA
         -- DEPENDENCIAS: CREDITOS (pre_prcconta, pre_tasaspre, pre_prestamos, pre_accrual, pre_desemb, pre_planpagos)
         -- CREACI�N:  30-11-2023
         -- SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  23-01-2025   | 2320476  | Ajuste en la consulta que obtiene los datos del devengamiento, columna 'interes_devengado'. Se agrego una condicion que verifica si existe desembolso el mismo mes del devengado.
----------------------------------------------------------------------------

    DEFINE w_nro_desembolsos    INTEGER;
    DEFINE w_nro_dias           INTEGER;
    DEFINE w_interes_devengado  DECIMAL(16,2);
    DEFINE w_desembolsado       DECIMAL(16,2);
    DEFINE w_saldocapital       DECIMAL(16,2);

    DEFINE w_total_interes_devengado  DECIMAL(16,2);
    DEFINE w_total_desembolsado       DECIMAL(16,2);
    DEFINE w_total_saldocapital       DECIMAL(16,2);
    
    DEFINE w_prc_fecha    DATE;
    DEFINE w_prc_codcred  INTEGER;
    DEFINE w_prc_codmod     INTEGER;
    
    
    let w_nro_desembolsos = 0;
    let w_nro_dias = 0;
    let w_total_interes_devengado = 0;
    let w_total_desembolsado = 0;
    let w_total_saldocapital = 0;

   
    -- OBTIENE LA FECHA DE LA TABLA d_creditos.pre_prcconta PARA QUE LA CONSULTA CALCULE EL DEVENGADO. OBTIENE EL VALOR DE LA COLUMNA prc_fecha_2
    select prc_fecha_2, prc_codcred, prc_codmod
      into w_prc_fecha, w_prc_codcred, w_prc_codmod
      from pre_prcconta
     where prc_codprc = p_codprc;
    
    if p_codprc is null or p_codprc <=0 then
       Raise Exception -746, 0, "[ERR_GDDP_001] - El valor proporcionado para el parametro c�digo de proceso no es valido (p_codprc).";
    end if   

    if w_prc_fecha is null then
       Raise Exception -746, 0, "[ERR_GDDP_002] - La fecha del proceso especificado no es valido.";
    end if   

    if w_prc_codcred is null or w_prc_codcred <= 0 then
       Raise Exception -746, 0, "[ERR_GDDP_003] - El c�digo de cr�dito del proceso especificado no es valido.";
    end if   

    if w_prc_codmod is null or w_prc_codmod <= 0 then
       Raise Exception -746, 0, "[ERR_GDDP_004] - La m�dulo de cr�dito del proceso especificado no es valido.";
    end if   

    FOREACH SELECT 
                CASE 
                    WHEN NOT TienePagoMes AND interes_dias <> dias_mes then
                    	-- ROUND(saldo * 1 * ((tasa/100)/dias),2) * dias_mes -- codigo original
                    	case when TieneDesembolsoEnElMes then -- codigo a�adido para verificar si existe desembolso el mismo mes del devengado
	                    	interes_devengado  
	                    else 
	                    	ROUND(saldo * 1 * ((tasa/100)/dias),2) * dias_mes
	                    end -- fin codigo a�adido
	                    
                    ELSE 
                    	interes_devengado 
                END interesdevengado, interes_dias, monto_desembolsado, saldo 
                INTO w_interes_devengado, w_nro_dias, w_desembolsado, w_saldocapital
            FROM (
                    select cod_acr,
                           dsb_fecdsb, 
                           monto_desembolsado, 
                           clave_serie,amortizacion, 
                           saldo,
                           tasa,
                           case when not TienePagoMes and interes_dias <> dias_mes and not TieneDesembolsoEnElMes then dias_mes else interes_dias  end as interes_dias,       
                           case when not TienePagoMes and interes_dias <> dias_mes and not TieneDesembolsoEnElMes then  round(saldo * 1 *  ((tasa/100)/dias),2) * dias_mes  else interes_devengado end as interes_devengado,      
                           acr_fecini,TienePagoMes, interes_dias as interes_dias_plan, interes_devengado as interes_plan, 
                           round(saldo * 1 *  ((tasa/100)/dias),2) * dias_mes as interes_reporte, 
                           dias_mes, dias, TieneDesembolsoEnElMes   
                      from (
                            select acr_codcred, acr_codmod, acr_fecaccru,
                                   acr_codacr cod_acr,dsb_fecdsb,dsb_valor monto_desembolsado,
                                   nvl(dsb_nrodoc,'') clave_serie,acr_capital amortizacion, acr_saldo saldo,
                                   acr_tasavig tasa,acr_diasaccr interes_dias, acr_interes interes_devengado, acr_fecini, DAY(w_prc_fecha) AS dias_mes, 
                                   nvl((SELECT mtp_intydias
                                      FROM pre_tasaspre
                                     WHERE mtp_codcred = acr_codcred
                                       AND mtp_codmod = acr_codmod
                                       AND mtp_fechavig = (SELECT MAX(mtp_fechavig) 
                                                             FROM  pre_tasaspre
                                                            WHERE mtp_codcred = acr_codcred
                                                              AND mtp_codmod = acr_codmod
                                                              AND   mtp_fechavig <= w_prc_fecha)),0) as dias,
                                   (select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean) 
                                      from sysmaster:sysdual
                                     where exists (select 1
                                      from pre_planpagos
                                     where cuo_tabmonpag = 15 
                                       and cuo_monpag = 2
                                       and cuo_coddsb = acr_coddsb
                                       and cuo_codmod = acr_codmod
                                       and cuo_codcred = acr_codcred                   
                                       and year(cuo_fecvencuo) = year(w_prc_fecha)  
                                       and month(cuo_fecvencuo) = month(w_prc_fecha))) as TienePagoMes,
                                   (select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean) 
                                      from sysmaster:sysdual
                                     where exists (select 1
                                      from pre_desemb
                                     where dsb_tabmonpag = 15 
                                       and dsb_monpag = 1
                                       and dsb_coddsb = acr_coddsb
                                       and dsb_codmod = acr_codmod
                                       and dsb_codcred = acr_codcred                   
                                       and year(dsb_fecdsb) = year(w_prc_fecha)  
                                       and month(dsb_fecdsb) = month(w_prc_fecha))) as TieneDesembolsoEnElMes                                      						
                    from d_creditos.pre_prestamos, d_creditos.pre_accrual, d_creditos.pre_desemb
                            where pre_codcred = dsb_codcred
                            and pre_codmod = dsb_codmod
                            and pre_codcred = acr_codcred
                            and pre_codmod = acr_codmod
                            and acr_coddsb = dsb_coddsb
                            and acr_tipoacr = 3
                            and acr_codcred =  w_prc_codcred 
                            and acr_codmod =  w_prc_codmod 
                            and acr_fecaccru = w_prc_fecha
                            order by dsb_fecdsb) 
                    ) AS t
        LET w_nro_desembolsos = w_nro_desembolsos + 1;
        LET w_total_interes_devengado = w_total_interes_devengado + w_interes_devengado;
        LET w_total_desembolsado = w_total_desembolsado + w_desembolsado;
        LET w_total_saldocapital = w_total_saldocapital + w_saldocapital;
        
    END FOREACH;
    
    if (w_nro_desembolsos <=0 or w_nro_dias <= 0 or w_total_interes_devengado = 0 or w_total_desembolsado = 0) then
       Raise Exception -746, 0, "[ERR_GDDP_005] - No existen datos del devengamiento o valores en cero"; --  del cr�dito no son validos o no existen  para la fecha: " || p_fecha;
    end if    

    RETURN w_nro_desembolsos, w_nro_dias, w_total_interes_devengado, w_total_desembolsado, w_total_saldocapital;

END PROCEDURE;
