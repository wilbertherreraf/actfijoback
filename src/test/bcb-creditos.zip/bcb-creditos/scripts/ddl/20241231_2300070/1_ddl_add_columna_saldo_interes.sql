select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: adiciona columna saldo_interes_pago_anticipado en las tablas pre_planpagos y aux_planpagos para almacenar el saldo de interes.
         -- FECHA: 31-12-2024
         -- SDAPO: 2300070
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 
ALTER TABLE d_creditos.pre_planpagos ADD cuo_saldo_interes_pago_anticipado decimal(20,2) DEFAULT 0  BEFORE cambio_bd;

ALTER TABLE d_creditos.aux_planpagos ADD acu_saldo_interes_pago_anticipado decimal(20,2) DEFAULT 0  BEFORE acu_auditfho;
  
