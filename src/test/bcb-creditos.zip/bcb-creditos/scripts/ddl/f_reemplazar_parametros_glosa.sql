DROP PROCEDURE IF EXISTS f_reemplazar_parametros_glosa;


CREATE FUNCTION d_creditos.f_reemplazar_parametros_glosa(w_rln_glosa LVARCHAR(1024), w_parametros_glosa LVARCHAR(1024))
RETURNING LVARCHAR(1024);

		 -- DESCRIPCI�N: Procedimiento para generar las glosas de las CUENTAS DEBE y HABER
         -- PARAMETROS INGRESO: w_rln_glosa LVARCHAR               Cadena de la glos con los parametros que deben ser modificados
         --						w_parametros_glosa LVARCHAR        parametros que se reemplazaran en la cadena
		 --
		 --
         -- PARAMETROS SALIDA: resultado integer                Resultado con la glosa del comprobante
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: CREDITOS (pre_prcconta)
         --               CONTBCB (estado_comprob, comprobante) 
         -- CREACI�N:  06-02-2025
         -- SDAPO: 2344735
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
 		 ----------------------------------------------------------------------------------------------------------------------------------------------------
		 --|   Autor   |     Fecha     | SDAPO    |  Descripcion
		 ---------------------------------------------------------------------------
		 --|           |               |          |  
		 ----------------------------------------------------------------------------

DEFINE w_start_index INTEGER;
DEFINE w_end_index INTEGER;
DEFINE w_nro_parametro INTEGER;
DEFINE w_par_glosa VARCHAR(255);
DEFINE w_resultado_glosa LVARCHAR(1024);

LET w_start_index = 1;
LET w_nro_parametro = 1;
LET w_resultado_glosa = w_rln_glosa;

WHILE w_start_index > 0 
    LET w_end_index = INSTR(w_parametros_glosa, '|', w_start_index);
    
    IF w_end_index > 0 THEN
        LET w_par_glosa = SUBSTR(w_parametros_glosa, w_start_index, w_end_index - w_start_index);
        LET w_start_index = w_end_index + 1;
    ELSE
        LET w_par_glosa = SUBSTR(w_parametros_glosa, w_start_index);
        LET w_start_index = 0; -- Finaliza el bucle
    END IF;

    -- Reemplazar {#P1}, {#P2}, etc.
    LET w_resultado_glosa = REPLACE(w_resultado_glosa, "{#P" || w_nro_parametro || "}", w_par_glosa);
    LET w_nro_parametro = w_nro_parametro + 1;

END WHILE;

RETURN w_resultado_glosa;
END FUNCTION;
