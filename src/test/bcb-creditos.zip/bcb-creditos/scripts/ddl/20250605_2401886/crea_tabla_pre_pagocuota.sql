select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea tablas pre_pagocuota y pre_pagocuota_h para registrar el pago de cuota y la informacion historica.
         -- FECHA: 06-05-2025
         -- SDAPO: 2401886
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;


DROP TABLE IF EXISTS pre_pagocuota;

CREATE TABLE d_creditos.pre_pagocuota (
    id SERIAL NOT NULL,  
    codcred INT NOT NULL,
    codmod INT NOT NULL,
    coddsb INT NOT NULL,
    
    total_cuota_vencimiento DECIMAL(15,2),
    pago_importe_capital DECIMAL(15,2),
    pago_importe_intereses DECIMAL(15,2),
    fecha_vencimiento DATE NOT NULL,
    fecha DATE NOT NULL,
    intereses_gestion_anterior DECIMAL(15,2),
    intereses_gestion_actual DECIMAL(15,2),
    total_saldo DECIMAL(15,2),
    numero_cuota INTEGER,
    nro_claveserie VARCHAR(100),
    
    estado INT NOT NULL DEFAULT 1,  -- estado Registrado=1/preautorizado=2/Autorizado=3/Rechazado=4/Cancelado=5
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(1000),
    glosa_coin_debe_capital LVARCHAR(500),
    glosa_coin_haber_capital LVARCHAR(500),
    glosa_coin_interes_anterior LVARCHAR(500),
    glosa_coin_interes_actual LVARCHAR(500),
    
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    
    audit_usuario_genera VARCHAR(15),				-- usuario que genera el comprobante
    audit_fechahora_genera DATETIME YEAR TO SECOND,  
    audit_host_genera VARCHAR(20),
    
    audit_usuario_preautoriza VARCHAR(15),			-- usuario que preautoriza el comprobante
    audit_fechahora_preautoriza DATETIME YEAR TO SECOND,  
    audit_host_preautoriza VARCHAR(20),
    
    audit_usuario_autoriza VARCHAR(15),				-- usuario que autoriza el comprobante
    audit_fechahora_autoriza DATETIME YEAR TO SECOND,  
    audit_host_autoriza VARCHAR(20),
    PRIMARY KEY (id),
    FOREIGN KEY (codcred, codmod) REFERENCES pre_prestamos (pre_codcred, pre_codmod) CONSTRAINT d_creditos.fk_codcred_pagocuota, -- CREA LLAVES FOREANEAS
    FOREIGN KEY (coddsb) REFERENCES pre_desemb (dsb_coddsb) CONSTRAINT d_creditos.fk_coddsb_pagocuota -- LLAVE FORANEA
);



DROP TABLE IF EXISTS d_creditos.pre_pagocuota_h;

CREATE TABLE d_creditos.pre_pagocuota_h(
    historico_id SERIAL NOT NULL,
    id INTEGER NOT NULL,  
    codcred INT NOT NULL,
    codmod INT NOT NULL,
    coddsb INT NOT NULL,
    
    total_cuota_vencimiento DECIMAL(15,2),
    pago_importe_capital DECIMAL(15,2),
    pago_importe_intereses DECIMAL(15,2),
    fecha_vencimiento DATE NOT NULL,
    fecha DATE NOT NULL,
    intereses_gestion_anterior DECIMAL(15,2),
    intereses_gestion_actual DECIMAL(15,2),
    total_saldo DECIMAL(15,2),
    numero_cuota INTEGER,
    nro_claveserie VARCHAR(100),
    
    estado INT NOT NULL,   -- estado Registrado=1/preautorizado=2/Autorizado=3/Rechazado=4
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(1000),
    glosa_coin_debe_capital LVARCHAR(500),
    glosa_coin_haber_capital LVARCHAR(500),
    glosa_coin_interes_anterior LVARCHAR(500),
    glosa_coin_interes_actual LVARCHAR(500),
    
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    
    audit_usuario_genera VARCHAR(15),	-- usuario que genera el comprobante
    audit_fechahora_genera DATETIME YEAR TO SECOND,  
    audit_host_genera VARCHAR(20),
    
    audit_usuario_preautoriza VARCHAR(15),		-- usuario que preautoriza el comprobante
    audit_fechahora_preautoriza DATETIME YEAR TO SECOND,  
    audit_host_preautoriza VARCHAR(20),
    
    audit_usuario_autoriza VARCHAR(15),			-- usuario que autoriza el comprobante
    audit_fechahora_autoriza DATETIME YEAR TO SECOND,  
    audit_host_autoriza VARCHAR(20),
    
    fecha_modificacion DATETIME YEAR TO SECOND,
    usuario_modificacion VARCHAR(15),
    host_modificacion VARCHAR(50),

    PRIMARY KEY (historico_id)
);