select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea un trigger que se utilizar� durante la actualizacion de datos en la tabla pre_pagocuota
         -- FECHA: 06-05-2025
         -- SDAPO: 2401886
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;

DROP TRIGGER IF EXISTS d_creditos.tu_h_pre_pagocuota;

CREATE TRIGGER d_creditos.tu_h_pre_pagocuota
    UPDATE ON d_creditos.pre_pagocuota
    REFERENCING OLD AS o NEW AS n
    FOR EACH ROW
    (
        EXECUTE PROCEDURE d_creditos.pu_h_pre_pagocuota(
            o.id, o.codcred, o.codmod, o.coddsb,
            o.total_cuota_vencimiento, o.pago_importe_capital, o.pago_importe_intereses, o.fecha_vencimiento, o.fecha,
            o.intereses_gestion_anterior, o.intereses_gestion_actual,
            o.total_saldo, o.numero_cuota, o.nro_claveserie,
            o.estado, o.nro_comprobante_coin,
            o.glosa_coin, o.glosa_coin_debe_capital, o.glosa_coin_haber_capital,
            o.glosa_coin_interes_anterior, o.glosa_coin_interes_actual, o.cambio_bd,
            o.audit_usuario, o.audit_fechahora, o.audit_host,
            o.audit_usuario_genera, o.audit_fechahora_genera, o.audit_host_genera,
            o.audit_usuario_preautoriza, o.audit_fechahora_preautoriza, o.audit_host_preautoriza,
            o.audit_usuario_autoriza, o.audit_fechahora_autoriza, o.audit_host_autoriza
        )
    );