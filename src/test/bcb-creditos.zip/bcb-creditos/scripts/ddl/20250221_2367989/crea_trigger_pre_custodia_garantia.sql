select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Crea un trigger que se utilizar� durante la actualizacion de datos en la tabla pre_custodia_garantia 
         -- FECHA: 2025-02-21
         -- SDAPO: 2367989
         -- USUARIO: Mabel Ramos
         -- ***********************************************************************
from systables limit 1;

DROP TRIGGER IF EXISTS "d_creditos".tu_h_pre_custodia_garantia;

CREATE TRIGGER "d_creditos".tu_h_pre_custodia_garantia
    UPDATE ON "d_creditos".pre_custodia_garantia
    REFERENCING OLD AS o_upd NEW AS n_upd
    FOR EACH ROW
    ( 
        EXECUTE PROCEDURE "d_creditos".pu_h_pre_custodia_garantia(
			o_upd.id, o_upd.dsb_coddsb, o_upd.codcred, o_upd.codmod, o_upd.fecha, o_upd.valor_total_garantia,
			o_upd.acta_deposito, o_upd.estado, o_upd.nro_comprobante_coin, o_upd.glosa_coin, 
			o_upd.glosa_debe, o_upd.glosa_haber, o_upd.cambio_bd, o_upd.audit_usuario, o_upd.audit_fechahora, 
			o_upd.audit_host, o_upd.audit_usuario_genera, o_upd.audit_fechahora_genera, 
			o_upd.audit_host_genera, o_upd.audit_usuario_preautoriza, o_upd.audit_fechahora_preautoriza, 
			o_upd.audit_host_preautoriza, o_upd.audit_usuario_autoriza, o_upd.audit_fechahora_autoriza, 
			o_upd.audit_host_autoriza,
			n_upd.id, n_upd.dsb_coddsb, n_upd.codcred, n_upd.codmod, n_upd.fecha, n_upd.valor_total_garantia,
			n_upd.acta_deposito, n_upd.estado, n_upd.nro_comprobante_coin, n_upd.glosa_coin, 
			n_upd.glosa_debe, n_upd.glosa_haber, n_upd.cambio_bd, n_upd.audit_usuario, n_upd.audit_fechahora, 
			n_upd.audit_host, n_upd.audit_usuario_genera, n_upd.audit_fechahora_genera, 
			n_upd.audit_host_genera, n_upd.audit_usuario_preautoriza, n_upd.audit_fechahora_preautoriza, 
			n_upd.audit_host_preautoriza, n_upd.audit_usuario_autoriza, n_upd.audit_fechahora_autoriza, 
			n_upd.audit_host_autoriza
        )
    );