select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea tabla pre_custodia_garantia y pre_custodia_garantia_h para el registro de comprobante de custodia 
         -- FECHA: 2025-02-21
         -- SDAPO: 2367989
         -- USUARIO: Mabel Ramos
         -- ***********************************************************************
from systables limit 1;

DROP TABLE IF EXISTS pre_custodia_garantia;

CREATE TABLE d_creditos.pre_custodia_garantia (
	id SERIAL NOT NULL, 
    dsb_coddsb INT NOT NULL,  
	codcred INT NOT NULL,
    codmod INT NOT NULL,
	fecha DATE NOT NULL,
    valor_total_garantia DECIMAL(15,2),
	acta_deposito VARCHAR(70) NOT NULL,
	estado INT NOT NULL,  
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(500),
    glosa_debe LVARCHAR(500),
    glosa_haber LVARCHAR(500),
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    audit_usuario_genera varchar(15),
	audit_fechahora_genera datetime year to second,
	audit_host_genera varchar(20),
	audit_usuario_preautoriza varchar(15),
	audit_fechahora_preautoriza datetime year to second,
	audit_host_preautoriza varchar(20),
	audit_usuario_autoriza varchar(15),
	audit_fechahora_autoriza datetime year to second,
	audit_host_autoriza varchar(20),
	PRIMARY KEY (id),
    FOREIGN KEY (dsb_coddsb) REFERENCES d_creditos.pre_desemb(dsb_coddsb)	
);




DROP TABLE IF EXISTS pre_custodia_garantia_h;

CREATE TABLE d_creditos.pre_custodia_garantia_h (
    historico_id SERIAL NOT NULL,  
    id INT NOT NULL, 
    dsb_coddsb INT NOT NULL, 
	codcred INT NOT NULL,
    codmod INT NOT NULL,
	fecha DATE NOT NULL,
    valor_total_garantia DECIMAL(15,2),
	acta_deposito VARCHAR(70) NOT NULL,
	estado INT NOT NULL,  
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(500),
    glosa_debe LVARCHAR(500),
    glosa_haber LVARCHAR(500),
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    audit_usuario_genera varchar(15),
	audit_fechahora_genera datetime year to second,
	audit_host_genera varchar(20),
	audit_usuario_preautoriza varchar(15),
	audit_fechahora_preautoriza datetime year to second,
	audit_host_preautoriza varchar(20),
	audit_usuario_autoriza varchar(15),
	audit_fechahora_autoriza datetime year to second,
	audit_host_autoriza varchar(20),
     PRIMARY KEY (historico_id) 
);
