-- QUERY 1
DROP PROCEDURE IF EXISTS f_pp_sum_portipo;

create function "d_creditos".f_pp_sum_portipo(p_codcred integer, p_codmod integer, p_coddsb integer, p_fechaini date, p_fechafin date, p_tipocuo integer)
    returning DECIMAL(20,2), DECIMAL(20,2)
    
         -- DESCRIPCI�N: Obtiene los datos de un parametro de la tabla correspondiente
         -- PARAMETROS INGRESO:   	p_codcred 	integer
		 -- 						p_codmod 	integer
		 -- 						p_coddsb 	integer
		 -- 						p_fechaini 	date
		 -- 						p_fechafin 	date
		 -- 						p_tipocuo 	integer
		 
         -- PARAMETROS SALIDA:
		 -- 						DECIMAL
		 -- 						DECIMAL
         -- AUTOR: 
         -- DEPENDENCIAS: CREDITOS (pre_planpagos)
         --                     
         -- CREACI�N:  
         -- SDAPO: 
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  11-09-2024   | 1968609  | Ajuste en SPL para diferencias pagos diferidos caso FNDR.
----------------------------------------------------------------------------
		 
         
-- variables

   DEFINE v_cuo_capital, v_cuo_interes, v_cuo_valor, v_cuo_valorpend like pre_planpagos.cuo_capital;
    
    
    let p_fechaini = nvl(p_fechaini, mdy(1,1,1980));
    let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));
    
    if p_coddsb is null then
        select nvl(sum(cuo_valor), 0), nvl(sum(cuo_valorpend), 0)
        into v_cuo_valor, v_cuo_valorpend
        from pre_planpagos
        where cuo_codmod = p_codmod
        and cuo_codcred = p_codcred
        and cuo_fecvencuo between p_fechaini and p_fechafin
        and cuo_coddsb > 0 
        and cuo_diferido<>1
        and cuo_tipocuo = nvl(p_tipocuo, cuo_tipocuo);
       
    else
    
        select nvl(sum(cuo_valor), 0), nvl(sum(cuo_valorpend), 0)
        into v_cuo_valor, v_cuo_valorpend
        from pre_planpagos
        where cuo_codmod = p_codmod
        and cuo_codcred = p_codcred
        and cuo_fecvencuo between p_fechaini and p_fechafin
        and cuo_coddsb = p_coddsb
        and cuo_coddsb > 0
        and cuo_tipocuo = nvl(p_tipocuo, cuo_tipocuo);
       
    end if


    return  nvl(v_cuo_valor, 0), nvl(v_cuo_valorpend, 0);
    
end function;   