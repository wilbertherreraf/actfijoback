-- QUERY 1
DROP PROCEDURE IF EXISTS p_pp_prorrateo; 

create procedure "d_creditos".p_pp_prorrateo(p_codcred integer, p_codmod integer, p_coddsb integer, p_codcuo integer, p_fecha date, p_importe decimal(20,2), p_tipoprorra integer)
{
wherrera 2021.11.01 prorrateo del monto de la operacion y salva en cronograma

} 
    
         -- DESCRIPCI�N: Prorrateo del monto de la operacion y salva en cronograma
         -- PARAMETROS INGRESO:   p_codcred 		integer, 
		 --						  p_codmod 			integer, 
		 -- 					  p_coddsb 			integer, 
		 --						  p_codcuo 			integer, 
		 --						  p_fecha 			date, 
		 --						  p_importe 		decimal(20,2), 
		 --						  p_tipoprorra 		integer
		 
         -- PARAMETROS SALIDA:
         -- AUTOR: wherrera
         -- DEPENDENCIAS: CREDITOS (f_pp_prorrateo)
         -- CREACI�N:  01-11-2021
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  14-08-2024   | 2156712  | Ajuste en la llamada a la funcion f_pp_prorrateo para el modulo de reversion de pagos.
----------------------------------------------------------------------------
		 
         
DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    define v_cuo_coddsb  like pre_planpagos.cuo_codcuo;
    define v_cuo_fecvencuo like pre_planpagos.cuo_fecvencuo;
    define v_acu_valorpend, v_acu_valor, v_sum_importe, v_cuo_valor, v_cuo_valorpend  like pre_planpagos.cuo_valor;
    define v_numpers, v_cuo_ult, v_cuo_codcuo, v_cuo_tipocuo integer;
    define v_new_unpaid, v_sum_fecvencuo, v_amt_sum_fec, V_MNT_PRG_NEW, V_MNT_PRG_ANT, V_MNT_PRGPEND_ANT like pre_planpagos.cuo_valor;
    define C_FLAG_EXETRIGGER_PP_NOEXE, C_FLAG_EXETRIGGER_PP_EXE integer;
    define C_TIPOCUO_CAP, C_TIPOCUO_INT INTEGER;
    
        let C_TIPOCUO_CAP = 1;
        LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;
        let C_FLAG_EXETRIGGER_PP_EXE = -1;

        foreach 
            execute procedure f_pp_prorrateo(p_codcred, p_codmod, p_coddsb, p_codcuo, p_fecha, p_importe, p_tipoprorra, 'DLC', 0)
                into v_cuo_coddsb, v_cuo_codcuo, v_cuo_fecvencuo, v_cuo_tipocuo, v_new_unpaid, v_sum_importe
                
                    let G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE;
                    call p_pp_upd_mnt_valorpend(v_cuo_codcuo, v_new_unpaid, v_new_unpaid);
                    let G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_EXE;                
        end foreach
end procedure;         