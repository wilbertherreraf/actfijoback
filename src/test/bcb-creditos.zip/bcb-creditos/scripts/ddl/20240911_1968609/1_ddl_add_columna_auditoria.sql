select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: ADICIONA COLUMNA AUDITORIA EN LA TABLA pre_accrual Y COLUMNA PARA PAGOS DIFERIDOS CASO FNDR.
         -- FECHA: 11-03-2024
         -- SDAPO: 1968609
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 
 -- 1 QUERY 
alter table d_creditos.pre_accrual add cambio_bd varchar(250) default null;

ALTER TABLE d_creditos.pre_planpagos ADD cuo_diferido SMALLINT DEFAULT 0;
  
