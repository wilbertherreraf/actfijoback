DROP PROCEDURE IF EXISTS p_generar_renglon; 

CREATE PROCEDURE d_creditos.p_generar_renglon (p_proceso integer, p_codcmp integer, p_centro integer, p_cmp_tipo varchar(1),
                                               p_cmp_nro varchar(7), p_nro_renglon integer, p_codcred integer, p_codmod integer,
                                               p_gestion integer, p_nro_periodo integer, p_nro_dia integer, p_fecha date)    
    returning boolean as resultado; 
    
         -- DESCRIPCI�N: Obtiene los datos de un parametro de la tabla correspondiente
         -- PARAMETROS INGRESO:   p_proceso integer                     Codigo de proceso
         --                       p_codcmp integer                      Codigo de comprobante
         --                       p_centro integer                      Centro COIN
         --                       p_cmp_tipo varchar(1)                 Tipo Comprobante
         --                       p_cmp_nro varchar(7)                  Nro. comprobante
         --                       p_nro_renglon integer                 Nro. renglon
         --                       p_codcred integer                     Codigo de cr�dito        
         --                       p_codmod integer                      C�digo de modulo
         --                       p_gestion integer                     Gestion (a�o)
         --                       p_nro_periodo integer                 Periodo
         --                       p_nro_dia integer                     dia        
         -- PARAMETROS SALIDA:
         -- AUTOR: HENRY IVAN PANIQUE MIRANDA
         -- DEPENDENCIAS: CREDITOS (gen_renglon)
         --               CONTBCB (reng_comprob)      
         -- CREACI�N:  30-11-2023
         -- SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  10-07-2024   | 2085127  | Cambio de tipo de variable para generar el Interes Devengado.
----------------------------------------------------------------------------
		 
         
-- variables

    define W_ESTADO_HABILITADO         integer;
     
    define w_cta_mov                   char(8);
    define w_prl_codprl                integer;
    define w_cpr_nro_reng_cp           integer;
    define w_ctp_codctp                integer;
    define w_delim_pos                 integer;
    DEFINE w_parametros_glosa          VARCHAR(255);
    DEFINE w_par_glosa                 VARCHAR(255);
    define w_start_index               integer;     
    define w_end_index                 integer; 
    define w_nro_parametro             integer;
        
--Variables renglon
    
    define w_rln_codrln                 like gen_renglon.rln_codrln;
    define w_rln_scr_ctamov             like gen_renglon.rln_scr_ctamov;
    define w_rln_partpr_ctamov          like gen_renglon.rln_partpr_ctamov;
    define w_rln_ctamov_default         like gen_renglon.rln_ctamov_default;
    define w_rln_dh                     like gen_renglon.rln_dh; 
    
    define w_rln_scr_monto_mo           like gen_renglon.rln_scr_monto_mo;
    define w_rln_partpr_monto_mo        like gen_renglon.rln_partpr_monto_mo;
    define w_rln_monto_mo_default       like gen_renglon.rln_monto_mo_default;
    
    define w_rln_scr_glosa              like gen_renglon.rln_scr_glosa;
    define w_rln_partpr_glosa           like gen_renglon.rln_partpr_glosa;
    define w_rln_glosa_default          like gen_renglon.rln_glosa_default;
    
    define w_rln_glosa_con_param        like gen_renglon.rln_glosa_con_param;
    define w_rln_glosa                  like gen_renglon.rln_glosa;
    
    define w_rln_tiene_cp               like gen_renglon.rln_tiene_cp;    
    define w_rln_estado                 like gen_renglon.rln_estado;    

    define w_cta_mov_moneda             varchar(6);
   
--Variables Certificacion Presupuestaria
 
    define w_ctp_scr_imp                like gen_certpres.ctp_scr_imp;   --source nro imputacion (cp)  
    define w_ctp_partpr_imp             like gen_certpres.ctp_partpr_imp;                     
    define w_ctp_default_imp            like gen_certpres.ctp_default_imp;
   
    define w_ctp_scr_cp                 like gen_certpres.ctp_scr_cp;
    define w_ctp_partpr_cp              like gen_certpres.ctp_partpr_cp;
    define w_ctp_cp_default             like gen_certpres.ctp_cp_default;

    define w_ctp_scr_cp_monto_mn        like gen_certpres.ctp_scr_monto_mn; 
    define w_ctp_partpr_cp_monto_mn     like gen_certpres.ctp_partpr_monto_mn;            
    define w_ctp_cp_default_monto_mn    like gen_certpres.ctp_default_monto_mn;
    
    define w_ctp_scr_cp_gestion         like gen_certpres.ctp_scr_gestion;
    define w_ctp_partpr_cp_gestion      like gen_certpres.ctp_partpr_gestion;
    define w_ctp_cp_gestion_default     like gen_certpres.ctp_gestion_default;
    
    define w_ctp_scr_cp_uor             like gen_certpres.ctp_scr_uor;
    define w_ctp_partpr_cp_uor          like gen_certpres.ctp_partpr_uor;
    define w_ctp_cp_uor_default         like gen_certpres.ctp_uor_default;
    
    define w_ctp_scr_cp_rfa             like gen_certpres.ctp_scr_rfa;
    define w_ctp_partpr_cp_rfa          like gen_certpres.ctp_partpr_rfa;
    define w_ctp_cp_rfa_default         like gen_certpres.ctp_rfa_default;
    
    define w_ctp_scr_cp_top             like gen_certpres.ctp_scr_top;
    define w_ctp_partpr_cp_top          like gen_certpres.ctp_partpr_top;
    define w_ctp_cp_top_default         like gen_certpres.ctp_top_default;
    define w_ctp_estado                 like gen_certpres.ctp_estado;    
    
--- variables de para el renglones

     define w_prl_nro_mayor             like contbcb@bcbux02:d_conta.reng_comprob.nro_mayor;   
     define w_prl_nro_afectable         like contbcb@bcbux02:d_conta.reng_comprob.nro_afectable;        
     define w_prl_monto_mo              like contbcb@bcbux02:d_conta.reng_comprob.monto_mo;
     define w_prl_factor_conv_mo_mn     like contbcb@bcbux02:d_conta.reng_comprob.factor_conv_mo_mn;    
     define w_prl_monto_mn              like contbcb@bcbux02:d_conta.reng_comprob.monto_mn;    
     define w_prl_nro_reng_esq          like contbcb@bcbux02:d_conta.reng_comprob.nro_reng_esq;

     define w_monto_mo          like contbcb@bcbux02:d_conta.reng_comprob.monto_mo;
     define w_factor_conv_mo_mn like contbcb@bcbux02:d_conta.reng_comprob.factor_conv_mo_mn; 
     define w_glosa_reng        like contbcb@bcbux02:d_conta.reng_comprob.glosa_reng;
     define w_nro_mayor         like contbcb@bcbux02:d_conta.reng_comprob.nro_mayor;
     define w_nro_afectable     like contbcb@bcbux02:d_conta.reng_comprob.nro_afectable; 
     define w_nro_reng_esq      like contbcb@bcbux02:d_conta.reng_comprob.nro_reng_esq; 
     define w_monto_mn          like contbcb@bcbux02:d_conta.reng_comprob.monto_mn;
     
     define w_char_prl_monto_mo varchar(20);
     

-- Variables para el manejo de los renglones del comprobante
     define w_nro_renglones     integer;
     define w_rln_numero        like gen_renglon.rln_numero;
     define w_glosa             varchar(255);

--Variables Cerificacion Presupuestaria

     define w_cp_imp           VARCHAR(20);
     define w_cp               VARCHAR(20);
     define w_cp_cta           INTEGER;
     define w_cp_monto_mn      VARCHAR(20);
     define w_cp_renglon       INTEGER;      
     define w_cp_gestion       VARCHAR(20);
     define w_cp_uor           VARCHAR(20); 
     define w_cp_rfa           VARCHAR(20);
     define w_cp_top           VARCHAR(20); 
    
     define w_fecha_devengado_anterior DATE;
     define w_tienePagoMes                 boolean;
     define w_tieneDesembolsoEnElMes       boolean;
     define w_dif_devengado integer;	
     define w_cantidad_dias_devengado integer;
    
     let w_dif_devengado = 0;
     let w_cantidad_dias_devengado = 0;
    
   
--  inicializacion de variables
     let W_ESTADO_HABILITADO = 1;
       
--  Validar parametros

    if p_codcmp is null or p_codcmp <=0 then
       Raise Exception -746, 0, "[ERR_PGR_001] - El valor proporcionado para el parametro c�digo de comprobante no es valido (p_codcmp).";
    end if   

    if p_centro is null or p_centro <=0 then
       Raise Exception -746, 0, "[ERR_PGR_002] - El valor proporcionado para el parametro centro no es valido (p_centro).";
    end if   

    if p_cmp_tipo is null or length(trim(p_cmp_tipo)) = 0 then
       Raise Exception -746, 0, "[ERR_PGR_003] - El valor proporcionado para el parametro tipo comprobante no es valido (p_cmp_tipo).";
    end if   

    if p_nro_renglon is null or p_nro_renglon <=0 then
       Raise Exception  -746, 0, "[ERR_PGR_004] - El valor proporcionado para el parametro n�mero de renglon no es valido (p_nro_renglon).";
    end if  
 
    if p_cmp_nro is null or length(trim(p_cmp_nro)) = 0 then
       Raise Exception -746, 0, "[ERR_PGR_005] - El valor proporcionado para el parametro n�mero comprobante no es valido (p_cmp_nro).";
    end if   
    
    if p_codcred is null or p_codcred <=0 then
       Raise Exception  -746, 0, "[ERR_PGR_006] - El valor proporcionado para el parametro c�digo de cr�dito no es valido (p_codcred).";
    end if   

    if p_codmod is null or p_codmod <=0 then
       Raise Exception  -746, 0, "[ERR_PGR_007] - El valor proporcionado para el parametro m�dulo del cr�dito no es valido (p_codmod).";
    end if   
    
-- verificams que el credito tenga pagos y deembolsos    
	let w_tienePagoMes	=(select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean) TienePagoMes
		                                      from sysmaster:sysdual
		                                     where exists (select 1
		                                      from pre_planpagos
		                                     where cuo_tabmonpag = 15 
		                                       and cuo_monpag = 2
		                                       and cuo_codmod = p_codmod
		                                       and cuo_codcred = p_codcred                   
		                                       and year(cuo_fecvencuo) = year(p_fecha)  
		                                       and month(cuo_fecvencuo) = month(p_fecha)) ); -- verificamos que tenga pagos
		                                      
	let w_tieneDesembolsoEnElMes	=(select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean)  TieneDesembolsoEnElMes
		                                      from sysmaster:sysdual
		                                     where exists (select 1
		                                      from pre_desemb
		                                     where dsb_tabmonpag = 15 
		                                       and dsb_monpag = 1
		                                       and dsb_codmod = p_codmod
		                                       and dsb_codcred = p_codcred                   
		                                       and year(dsb_fecdsb) = year(p_fecha)  
		                                       and month(dsb_fecdsb) = month(p_fecha)));  -- verificamos que tenga desembolsos               

 -- obtener parametros del renglon especificado
 
        call d_creditos.p_get_par_renglon (p_codcmp, p_nro_renglon)    returning w_rln_codrln,
                                                                                 w_rln_scr_ctamov, w_rln_partpr_ctamov, w_rln_ctamov_default, w_rln_dh,         
                                                                                 w_rln_scr_monto_mo, w_rln_partpr_monto_mo, w_rln_monto_mo_default,
                                                                                 w_rln_scr_glosa, w_rln_partpr_glosa, w_rln_glosa_default, 
                                                                                 w_rln_glosa_con_param, w_rln_glosa,
                                                                                 w_rln_tiene_cp, w_rln_estado;

                                                         
        if not w_rln_estado = W_ESTADO_HABILITADO then
           Raise Exception  -746, 0, "[ERR_PGC_008] - El renglon especificado no esta habilitado.";
        end if
        
     
    	    	call f_get_parametro (p_proceso , w_rln_scr_ctamov, w_rln_partpr_ctamov, w_rln_ctamov_default, p_codcred, p_codmod) returning w_cta_mov;
    	    

		        let w_cta_mov_moneda = "69"; --moneda por defecto en bolivianos de acuerdo a lo indicado por usuario        
		        let w_delim_pos = INSTR(w_cta_mov, '-');        

		        IF w_delim_pos > 0 THEN   ---viene con la moneda 
		           let w_cta_mov = SUBSTR(w_cta_mov, 1, w_delim_pos - 1);        
		           let w_cta_mov_moneda = "";
		           let w_cta_mov_moneda = SUBSTR(w_cta_mov, w_delim_pos + 1);
		        END IF;
		
		        --Raise Exception  -746, 0, "10.3" || nvl(w_cta_mov,"null ctamov") || "-" || nvl(w_cta_mov_moneda,"null moneda") || "-" || nvl(p_centro,"null centro");
		        --obtener el mayor y cuenta afectable a partir de la cuenta de movimiento y p_centro
		        call contbcb@bcbux02:c_conta.nro_afect_mayor (w_cta_mov, w_cta_mov_moneda, p_centro) returning w_prl_nro_afectable, w_prl_nro_mayor;

       

        --obtener el  tipo de cambio (factor conversion) de la moneda de la cuenta afectable 
        select factor into w_prl_factor_conv_mo_mn from contbcb@bcbux02:d_conta.factor_conv_mn where cod_moneda = w_cta_mov_moneda and fecha_dia = mdy(p_nro_periodo,p_nro_dia,p_gestion);
        
       
       
       -- obtenemos le fecha del ultimo devengando con cpomprobante autorizado
       let w_fecha_devengado_anterior=(select max(prc_fecha_2) from d_creditos.pre_prcconta where prc_codcred=p_codcred and prc_codmod=p_codmod and prc_estado=3 and prc_auditfhoaut is not null );									 
       
      
	      if not w_tienePagoMes and not w_tieneDesembolsoEnElMes then
		       -- obtenemo el monto devengado entre la fecha del devengado anterior y la fecha del devengado actual
	    	  let w_char_prl_monto_mo=(select sum(acr_interes) from d_creditos.pre_accrual where acr_codcred=p_codcred and acr_tipoacr=1 and acr_fecaccru>w_fecha_devengado_anterior and acr_fecaccru<= p_fecha);
	      else 
	       --monto original por el factor de convercion partpr 29,30,n.. segun nro renglon
	        call f_get_parametro (p_proceso, w_rln_scr_monto_mo, w_rln_partpr_monto_mo, w_rln_monto_mo_default, p_codcred, p_codmod) returning w_char_prl_monto_mo; -- codigo original para obtener el monto
	      end if 
       
        if w_char_prl_monto_mo is null then
           Raise Exception  -746, 0, "[ERR_PGR_010] - Monto para el renglon no es valido o no se parametrizo." || p_proceso || "," || w_rln_scr_monto_mo || "," || w_rln_partpr_monto_mo;
        end if
--        Raise Exception  -746, 0, "[10.4] - " || nvl(w_char_prl_monto_mo,"null") || "-" || nvl(w_prl_factor_conv_mo_mn,w_cta_mov_moneda)  || p_nro_periodo || p_nro_dia || p_gestion;
        
        let w_prl_monto_mo = cast(w_char_prl_monto_mo as decimal (15,2));
        let w_prl_monto_mn = w_prl_monto_mo * w_prl_factor_conv_mo_mn;
        let w_prl_nro_reng_esq = null;
        
        call f_get_parametro (p_proceso, w_rln_scr_glosa, w_rln_partpr_glosa, w_rln_glosa_default, p_codcred, p_codmod) returning w_parametros_glosa;    --parametros de la glosa
        
        if w_rln_glosa_con_param then --reemplazar parametros obtenidos en la glosa
            LET w_start_index = 1;
            let w_nro_parametro = 1;
            WHILE w_start_index > 0 
                  LET w_end_index = INSTR(w_parametros_glosa, '|', w_start_index);
                  IF w_end_index > 0 THEN
                     LET w_par_glosa = SUBSTR(w_parametros_glosa, w_start_index, w_end_index - w_start_index);
                     LET w_start_index = w_end_index + 1;
                  ELSE
                     LET w_par_glosa = SUBSTR(w_parametros_glosa, w_start_index);
                     LET w_start_index = 0; -- Establece w_start_index a 0 para terminar el bucle
                  END IF;
                  
                  if w_nro_parametro=1 then -- codigo para ajustar los dias de devengado que se enviara a la glosa -- solo para el primer registro	
          
		          	             
		          	 
		
						if not w_tienePagoMes and not w_tieneDesembolsoEnElMes then    -- verifica que no tenga pagos ni desembolsos                                  
				          	  let w_cantidad_dias_devengado	=w_par_glosa;
				              let w_dif_devengado=(select TRUNC(day(max(prc_fecha_2))) from pre_prcconta where prc_codcred = p_codcred and prc_codmod=p_codmod and prc_estado=3);
					          let w_par_glosa=w_cantidad_dias_devengado-w_dif_devengado;
					    end if     
			         
		    	  end if
    	  
    	  
                  -- reemplaza el parametro en la glosa
                  LET w_rln_glosa = REPLACE(w_rln_glosa, "{#P" || w_nro_parametro || "}"  , w_par_glosa );
                  LET w_nro_parametro = w_nro_parametro + 1;        
             END WHILE;
        end if
        
       -- Raise Exception  -746, 0, "[10.5] - " || cast(nvl(w_prl_monto_mo,28) as varchar(20)) || "-" || nvl(w_prl_factor_conv_mo_mn,"null") || p_nro_periodo || p_nro_dia || p_gestion;  
       										
        
        insert into contbcb@bcbux02:d_conta.reng_comprob values (p_centro, p_cmp_tipo, p_cmp_nro, p_nro_renglon, w_rln_dh, w_prl_monto_mo, w_prl_factor_conv_mo_mn,
                                                 w_rln_glosa, w_prl_nro_mayor, w_prl_nro_afectable, w_prl_nro_reng_esq, w_prl_monto_mn);                   
         
--       Raise Exception  -746, 0, "[10.6] - insert ok renglon" || p_nro_renglon;
         
        if w_rln_tiene_cp then --el renglon tiene certificacion presupuestaria           
           Foreach select ctp_nro_renglon into w_cpr_nro_reng_cp from d_creditos.gen_certpres where ctp_codrln = w_rln_codrln and ctp_nro_renglon > 0           
                   call d_creditos.p_get_par_certpres(w_rln_codrln, w_cpr_nro_reng_cp) returning w_ctp_scr_imp, w_ctp_partpr_imp, w_ctp_default_imp,
                                                                                                 w_ctp_scr_cp, w_ctp_partpr_cp, w_ctp_cp_default,
                                                                                                 w_ctp_scr_cp_monto_mn, w_ctp_partpr_cp_monto_mn, w_ctp_cp_default_monto_mn,
                                                                                                 w_ctp_scr_cp_gestion, w_ctp_partpr_cp_gestion, w_ctp_cp_gestion_default,
                                                                                                 w_ctp_scr_cp_uor, w_ctp_partpr_cp_uor, w_ctp_cp_uor_default,
                                                                                                 w_ctp_scr_cp_rfa, w_ctp_partpr_cp_rfa, w_ctp_cp_rfa_default,        
                                                                                                 w_ctp_scr_cp_top, w_ctp_partpr_cp_top, w_ctp_cp_top_default,
                                                                                                 w_ctp_estado;       

                   if not w_ctp_estado = W_ESTADO_HABILITADO then
                       Raise Exception  -746, 0, "[ERR_PGR_010] - La certificaci�n presupuestaria  parametrizada no esta habilitada.";
                   end if
        
                   call f_get_parametro (p_proceso, w_ctp_scr_imp, w_ctp_partpr_imp, w_ctp_default_imp, p_codcred, p_codmod)  returning w_cp_imp;                   
                   call f_get_parametro (p_proceso, w_ctp_scr_cp, w_ctp_partpr_cp, w_ctp_cp_default, p_codcred, p_codmod)  returning w_cp;
                   
                   let w_delim_pos = INSTR(w_cp, '-');        
                   IF w_delim_pos > 0 THEN   
                      let w_cp_cta = SUBSTR(w_cp, 1, w_delim_pos - 1);        
                      let w_cp_renglon = "";
                      let w_cp_renglon = SUBSTR(w_cp, w_delim_pos + 1);
                   else
                      Raise Exception  -746, 0, "[ERR_PGR_011] - La certificaci�n presupuestaria  no esta parametrizada o formato incorrecto.";
                   END IF;

                   if w_cp_cta is null or w_cp_renglon is null or w_cp_cta = 0 or w_cp_renglon = 0 then
                       Raise Exception  -746, 0, "[ERR_PGR_012] - El parametro Certificaci�n Presupuestaria no es valido.";
                   end if    
                   --monto cp partpr 33
                   if not w_tienePagoMes and not w_tieneDesembolsoEnElMes then
	                   let w_cp_monto_mn=w_prl_monto_mo;
	               else
	               	   call f_get_parametro (p_proceso, w_ctp_scr_cp_monto_mn, w_ctp_partpr_cp_monto_mn, w_ctp_cp_default_monto_mn, p_codcred, p_codmod) returning w_cp_monto_mn; -- codigo original
	               end if

	               
                   --GESTION cp partpr 34
                   call f_get_parametro (p_proceso, w_ctp_scr_cp_gestion, w_ctp_partpr_cp_gestion, w_ctp_cp_gestion_default, p_codcred, p_codmod) returning w_cp_gestion;
                   --UNIDAD OPERATIVA cp partpr 35
                   call f_get_parametro (p_proceso, w_ctp_scr_cp_uor, w_ctp_partpr_cp_uor, w_ctp_cp_uor_default, p_codcred, p_codmod) returning w_cp_uor;
                   --RFA cp partpr 36
                   call f_get_parametro (p_proceso, w_ctp_scr_cp_rfa, w_ctp_partpr_cp_rfa, w_ctp_cp_rfa_default, p_codcred, p_codmod) returning w_cp_rfa;
                   --TPO cp partpr 37
                   call f_get_parametro (p_proceso, w_ctp_scr_cp_top, w_ctp_partpr_cp_top, w_ctp_cp_top_default, p_codcred, p_codmod) returning w_cp_top;

                   insert into contbcb@bcbux02:imp_presup                    
                          values (p_centro, p_cmp_tipo, p_cmp_nro, p_nro_renglon, cast(w_cp_imp as int), cast(w_cp_monto_mn as decimal(15,2)), cast(w_cp_gestion as int), cast(w_cp_cta as int), w_cp_renglon, w_cp_top, w_cp_rfa) ;
           end foreach        
       end if
    return cast("T" as boolean);          
end procedure;     
