select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea tablas pre_registro_devengado_creditos para registrar la informacion historica de creditos devengados por fecha.
         -- FECHA: 25-11-2025
         -- SDAPO: 2666825
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;


DROP TABLE IF EXISTS pre_registro_devengado_creditos;

CREATE TABLE d_creditos.pre_registro_devengado_creditos (
    id SERIAL NOT NULL,    
    codcred INT NOT NULL,
    codmod INT NOT NULL,
    -- coddsb INT NOT NULL,
    fecha_devengado DATE NOT NULL,
    
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    
    PRIMARY KEY (id) constraint d_creditos.pk_pre_registro_devengado_creditos,
    FOREIGN KEY (codcred, codmod) REFERENCES pre_prestamos (pre_codcred, pre_codmod) CONSTRAINT d_creditos.fk_codcred_reg_devengado -- CREA LLAVES FOREANEAS
);
