select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Adiciona columna de rds_saldo_interes_pago_anticipado en la tabla pre_reprograma para almacenar el saldo del interes, para pagos anticipados.
         -- FECHA: 27/02/2026
         -- SDAPO: 2666825
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
   
ALTER TABLE d_creditos.pre_reprograma ADD  rds_saldo_interes_pago_anticipado decimal(20,2) DEFAULT 0  BEFORE rds_auditusr;