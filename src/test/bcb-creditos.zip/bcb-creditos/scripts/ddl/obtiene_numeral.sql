-- QUERY 1
DROP PROCEDURE IF EXISTS obtiene_numeral;

-- QUERY 2
CREATE FUNCTION d_creditos.obtiene_numeral(p_numero INTEGER)
    RETURNING VARCHAR(50) as numeral;
{
-- DESCRIPCION: Obtiene en literal el numero de desembolso y pago para el reporte ejecutivo.
-- PARAMETROS INGRESO: 	p_numero integer 

-- PARAMETROS SALIDA:  v_result_numeral VARCHAR
-- AUTOR: acanqui
-- CREACION: 18.06.2024

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  18-06-2024   | 2005026  | Obtiene en literal el numero de desembolso y pago para el reporte ejecutivo.
----------------------------------------------------------------------------
}

DEFINE v_result_numeral VARCHAR(50);

    LET v_result_numeral = 
    CASE 
        WHEN p_numero = 1 THEN 'Primero'
		WHEN p_numero = 2 THEN 'Segundo'
		WHEN p_numero = 3 THEN 'Tercero'
		WHEN p_numero = 4 THEN 'Cuarto'
		WHEN p_numero = 5 THEN 'Quinto'
		WHEN p_numero = 6 THEN 'Sexto'
		WHEN p_numero = 7 THEN 'S�ptimo'
		WHEN p_numero = 8 THEN 'Octavo'
		WHEN p_numero = 9 THEN 'Noveno'
		WHEN p_numero = 10 THEN 'D�cimo'
		WHEN p_numero = 11 THEN 'Und�cimo'
		WHEN p_numero = 12 THEN 'Duod�cimo'
		WHEN p_numero = 13 THEN 'Decimotercero'
		WHEN p_numero = 14 THEN 'Decimocuarto'
		WHEN p_numero = 15 THEN 'Decimoquinto'
		WHEN p_numero = 16 THEN 'Decimosexto'
		WHEN p_numero = 17 THEN 'Decimos�ptimo'
		WHEN p_numero = 18 THEN 'Decimoctavo'
		WHEN p_numero = 19 THEN 'Decimonoveno'
		WHEN p_numero = 20 THEN 'Vig�simo'
		WHEN p_numero = 21 THEN 'Vig�simo primero'
		WHEN p_numero = 22 THEN 'Vig�simo segundo'
		WHEN p_numero = 23 THEN 'Vig�simo tercero'
		WHEN p_numero = 24 THEN 'Vig�simo cuarto'
		WHEN p_numero = 25 THEN 'Vig�simo quinto'
		WHEN p_numero = 26 THEN 'Vig�simo sexto'
		WHEN p_numero = 27 THEN 'Vig�simo s�ptimo'
		WHEN p_numero = 28 THEN 'Vig�simo octavo'
		WHEN p_numero = 29 THEN 'Vig�simo noveno'
		WHEN p_numero = 30 THEN 'Trig�simo'
		WHEN p_numero = 31 THEN 'Trig�simo primero'
		WHEN p_numero = 32 THEN 'Trig�simo segundo'
		WHEN p_numero = 33 THEN 'Trig�simo tercero'
		WHEN p_numero = 34 THEN 'Trig�simo cuarto'
		WHEN p_numero = 35 THEN 'Trig�simo quinto'
		WHEN p_numero = 36 THEN 'Trig�simo sexto'
		WHEN p_numero = 37 THEN 'Trig�simo s�ptimo'
		WHEN p_numero = 38 THEN 'Trig�simo octavo'
		WHEN p_numero = 39 THEN 'Trig�simo noveno'
		WHEN p_numero = 40 THEN 'Cuadrag�simo'
		WHEN p_numero = 41 THEN 'Cuadrag�simo primero'
		WHEN p_numero = 42 THEN 'Cuadrag�simo segundo'
		WHEN p_numero = 43 THEN 'Cuadrag�simo tercero'
		WHEN p_numero = 44 THEN 'Cuadrag�simo cuarto'
		WHEN p_numero = 45 THEN 'Cuadrag�simo quinto'
		WHEN p_numero = 46 THEN 'Cuadrag�simo sexto'
		WHEN p_numero = 47 THEN 'Cuadrag�simo s�ptimo'
		WHEN p_numero = 48 THEN 'Cuadrag�simo octavo'
		WHEN p_numero = 49 THEN 'Cuadrag�simo noveno'
		WHEN p_numero = 50 THEN 'Quincuag�simo'
		WHEN p_numero = 51 THEN 'Quincuag�simo primero'
		WHEN p_numero = 52 THEN 'Quincuag�simo segundo'
		WHEN p_numero = 53 THEN 'Quincuag�simo tercero'
		WHEN p_numero = 54 THEN 'Quincuag�simo cuarto'
		WHEN p_numero = 55 THEN 'Quincuag�simo quinto'
		WHEN p_numero = 56 THEN 'Quincuag�simo sexto'
		WHEN p_numero = 57 THEN 'Quincuag�simo s�ptimo'
		WHEN p_numero = 58 THEN 'Quincuag�simo octavo'
		WHEN p_numero = 59 THEN 'Quincuag�simo noveno'
		WHEN p_numero = 60 THEN 'Sexag�simo'
		WHEN p_numero = 61 THEN 'Sexag�simo primero'
		WHEN p_numero = 62 THEN 'Sexag�simo segundo'
		WHEN p_numero = 63 THEN 'Sexag�simo tercero'
		WHEN p_numero = 64 THEN 'Sexag�simo cuarto'
		WHEN p_numero = 65 THEN 'Sexag�simo quinto'
		WHEN p_numero = 66 THEN 'Sexag�simo sexto'
		WHEN p_numero = 67 THEN 'Sexag�simo s�ptimo'
		WHEN p_numero = 68 THEN 'Sexag�simo octavo'
		WHEN p_numero = 69 THEN 'Sexag�simo noveno'
		WHEN p_numero = 70 THEN 'Septuag�simo'
		WHEN p_numero = 71 THEN 'Septuag�simo primero'
		WHEN p_numero = 72 THEN 'Septuag�simo segundo'
		WHEN p_numero = 73 THEN 'Septuag�simo tercero'
		WHEN p_numero = 74 THEN 'Septuag�simo cuarto'
		WHEN p_numero = 75 THEN 'Septuag�simo quinto'
		WHEN p_numero = 76 THEN 'Septuag�simo sexto'
		WHEN p_numero = 77 THEN 'Septuag�simo s�ptimo'
		WHEN p_numero = 78 THEN 'Septuag�simo octavo'
		WHEN p_numero = 79 THEN 'Septuag�simo noveno'
		WHEN p_numero = 80 THEN 'Octog�simo'
		WHEN p_numero = 81 THEN 'Octog�simo primero'
		WHEN p_numero = 82 THEN 'Octog�simo segundo'
		WHEN p_numero = 83 THEN 'Octog�simo tercero'
		WHEN p_numero = 84 THEN 'Octog�simo cuarto'
		WHEN p_numero = 85 THEN 'Octog�simo quinto'
		WHEN p_numero = 86 THEN 'Octog�simo sexto'
		WHEN p_numero = 87 THEN 'Octog�simo s�ptimo'
		WHEN p_numero = 88 THEN 'Octog�simo octavo'
		WHEN p_numero = 89 THEN 'Octog�simo noveno'
		WHEN p_numero = 90 THEN 'Nonag�simo'
		WHEN p_numero = 91 THEN 'Nonag�simo primero'
		WHEN p_numero = 92 THEN 'Nonag�simo segundo'
		WHEN p_numero = 93 THEN 'Nonag�simo tercero'
		WHEN p_numero = 94 THEN 'Nonag�simo cuarto'
		WHEN p_numero = 95 THEN 'Nonag�simo quinto'
		WHEN p_numero = 96 THEN 'Nonag�simo sexto'
		WHEN p_numero = 97 THEN 'Nonag�simo s�ptimo'
		WHEN p_numero = 98 THEN 'Nonag�simo octavo'
		WHEN p_numero = 99 THEN 'Nonag�simo noveno'
		WHEN p_numero = 100 THEN 'Cent�simo'
        ELSE 'sin dato'
    END;

    RETURN NVL(v_result_numeral, 'S/D');
END FUNCTION;