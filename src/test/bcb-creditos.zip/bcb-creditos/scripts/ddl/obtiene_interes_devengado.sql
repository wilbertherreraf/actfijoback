-- QUERY 1
DROP PROCEDURE IF EXISTS obtiene_interes_devengado;

-- QUERY 2
CREATE FUNCTION d_creditos.obtiene_interes_devengado(p_codcred INTEGER, p_codmod INTEGER, p_fecha_interes VARCHAR(20))
    RETURNING DECIMAL(20,2) as valor_interes;
{
-- DESCRIPCION: Obtiene el interes acumulado por numero de credito de acuerdo al ultimo pago realizado por la EPNE hasta la fecha actual.
-- PARAMETROS INGRESO: 	p_codcred INTEGER 
--						p_codmod INTEGER
--						p_fecha_interes VARCHAR(20)

-- PARAMETROS SALIDA:  valor_interes DECIMAL
-- AUTOR: acanqui
-- CREACION: 18.06.2024

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  18-06-2024   | 2005026  | Obtiene el interes acumulado por numero de credito de acuerdo al ultimo pago realizado por la EPNE hasta la fecha actual.
----------------------------------------------------------------------------
}

DEFINE v_result_numeral VARCHAR(50);
    DEFINE v_interes_mensual 	decimal(20,2);
    let v_interes_mensual=0;
   
   		  select SUM(case when not TienePagoMes and interes_dias <> dias_mes  and not TieneDesembolsoEnElMes then  round(saldo * 1 *  ((tasa/100)/dias),2) * dias_mes  else interes_devengado end) as interes_devengado    
   		  into v_interes_mensual
		  from (
		        select acr_codcred, acr_codmod, acr_fecaccru,
		               acr_saldo saldo,
		               acr_tasavig tasa,acr_diasaccr interes_dias, acr_interes interes_devengado, DAY(p_fecha_interes) AS dias_mes, 
		               nvl((SELECT mtp_intydias
		                  FROM pre_tasaspre
		                 WHERE mtp_codcred = acr_codcred
		                   AND mtp_codmod = acr_codmod
		                   AND mtp_fechavig = (SELECT MAX(mtp_fechavig) 
		                                         FROM  pre_tasaspre
		                                        WHERE mtp_codcred = acr_codcred
		                                          AND mtp_codmod = acr_codmod
		                                          AND   mtp_fechavig <= p_fecha_interes)),0) as dias,
		               (select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean) 
		                  from sysmaster:sysdual
		                 where exists (select 1
		                  from pre_planpagos
		                 where cuo_tabmonpag = 15 
		                   and cuo_monpag = 2
		                   and cuo_coddsb = acr_coddsb
		                   and cuo_codmod = acr_codmod
		                   and cuo_codcred = acr_codcred                   
		                   and year(cuo_fecvencuo) = year(p_fecha_interes)  
		                   and month(cuo_fecvencuo) = month(p_fecha_interes))) as TienePagoMes,
		                (select cast(DECODE(COUNT(*), 0, "F", "T") AS boolean) 
		                  from sysmaster:sysdual
		                 where exists (select 1
		                  from pre_desemb
		                 where dsb_tabmonpag = 15 
		                   and dsb_monpag = 1
		                   and dsb_coddsb = acr_coddsb 
		                   and dsb_codmod = acr_codmod
		                   and dsb_codcred = acr_codcred                   
		                   and year(dsb_fecdsb) = year(p_fecha_interes)  
		                   and month(dsb_fecdsb) = month(p_fecha_interes))) as TieneDesembolsoEnElMes                                      						
		from d_creditos.pre_prestamos, d_creditos.pre_accrual, d_creditos.pre_desemb
		where pre_codcred = dsb_codcred
		and pre_codmod = dsb_codmod
		and pre_codcred = acr_codcred
		and pre_codmod = acr_codmod
		and acr_coddsb = dsb_coddsb
		and acr_tipoacr = 3
		and acr_codcred =  p_codcred 
		and acr_codmod =  p_codmod 
		and acr_fecaccru = p_fecha_interes 
		order by dsb_fecdsb 
		) as t;

   

    RETURN NVL(v_interes_mensual, 'S/D');
END FUNCTION;