select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea tabla pre_desembolso_detalle y pre_desembolso_detalle_h para el registro del comprobante de desembolso 
         -- FECHA: 2025-02-10
         -- SDAPO: 2352035
         -- USUARIO: Mabel Ramos
         -- ***********************************************************************
from systables limit 1;

DROP TABLE IF EXISTS pre_desembolso_detalle;

CREATE TABLE d_creditos.pre_desembolso_detalle (
	id SERIAL NOT NULL, 
    dsb_coddsb INT NOT NULL, 
    codcred INT NOT NULL,
    codmod INT NOT NULL,	
    fecha DATE NOT NULL,
	monto_desembolsar DECIMAL(20,2) DEFAULT 0.0000000000,
	nota_solicitud VARCHAR(70) NOT NULL,
	numero_tramite VARCHAR(70) NOT NULL,
	numero_libreta VARCHAR(70),
	descripcion_libreta VARCHAR(70),
	informe_gom VARCHAR(70),
	informe_gal VARCHAR(70),
	nota_solicitud_mcs VARCHAR(70),
    estado INT NOT NULL DEFAULT 1,  -- estado Registrado=1/preautorizado=2/Autorizado=3/Rechazado=4
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(500),
	glosa_debe LVARCHAR(500),
    glosa_haber LVARCHAR(500),
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    audit_usuario_genera varchar(15),
	audit_fechahora_genera datetime year to second,
	audit_host_genera varchar(20),
	audit_usuario_preautoriza varchar(15),
	audit_fechahora_preautoriza datetime year to second,
	audit_host_preautoriza varchar(20),
	audit_usuario_autoriza varchar(15),
	audit_fechahora_autoriza datetime year to second,
	audit_host_autoriza varchar(20),
	PRIMARY KEY (id),  
    FOREIGN KEY (dsb_coddsb) REFERENCES d_creditos.pre_desemb(dsb_coddsb)
);





DROP TABLE IF EXISTS pre_desembolso_detalle_h;

CREATE TABLE d_creditos.pre_desembolso_detalle_h (
    historico_id SERIAL NOT NULL,  
    id INT NOT NULL, 
    dsb_coddsb INT NOT NULL, 
    codcred INT NOT NULL,
    codmod INT NOT NULL,    
    fecha DATE NOT NULL,
	monto_desembolsar DECIMAL(20,2),
    nota_solicitud VARCHAR(70) NOT NULL,
    numero_tramite VARCHAR(70) NOT NULL,
    numero_libreta VARCHAR(70),
	descripcion_libreta VARCHAR(70),
    informe_gom VARCHAR(70),
    informe_gal VARCHAR(70),
    nota_solicitud_mcs VARCHAR(70),
    estado INT NOT NULL,  
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(500),
    glosa_debe LVARCHAR(500),
    glosa_haber LVARCHAR(500),
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    audit_usuario_genera varchar(15),
	audit_fechahora_genera datetime year to second,
	audit_host_genera varchar(20),
	audit_usuario_preautoriza varchar(15),
	audit_fechahora_preautoriza datetime year to second,
	audit_host_preautoriza varchar(20),
	audit_usuario_autoriza varchar(15),
	audit_fechahora_autoriza datetime year to second,
	audit_host_autoriza varchar(20),
     PRIMARY KEY (historico_id) 
);
