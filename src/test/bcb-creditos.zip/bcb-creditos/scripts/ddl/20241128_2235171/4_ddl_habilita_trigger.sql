select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: HABILITA EL TRIGGER DE LA TABLA EN LA TABLA pre_planpagos.
         -- FECHA: 28-11-2024
         -- SDAPO: 2235171
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 
-- 1 QUERY 
create trigger "d_creditos".tu_pre_planpagos update of cuo_valor,
    cuo_fecvencuo on "d_creditos".pre_planpagos referencing old 
    as o_upd new as n_upd
    for each row
        (
        execute procedure "d_creditos".pu_pre_planpagos(o_upd.cuo_codcuo 
    ,o_upd.cuo_codcred ,o_upd.cuo_codmod ,o_upd.cuo_numcuo ,o_upd.cuo_fecvencuo 
    ,o_upd.cuo_valor ,o_upd.cuo_valorpend ,o_upd.cuo_monpag ,o_upd.cuo_coddsb 
    ,o_upd.cuo_numtrx ,o_upd.cuo_tipocuo ,o_upd.cuo_tipoacu ,o_upd.cuo_tipotrx 
    ,n_upd.cuo_fecvencuo ,n_upd.cuo_valor ,n_upd.cuo_valorpend ,n_upd.cuo_coddsb 
    ,n_upd.cuo_monpag ,n_upd.cuo_numtrx ,n_upd.cuo_tipoacu ));
  
