select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: ADICIONA COLUMNA AUDITORIA EN LA TABLA pre_planpagos  Y DESACTIVA EL TRIGGER DE LA TABLA DE LA MISMA TABLA.
         -- FECHA: 28-11-2024
         -- SDAPO: 2235171
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
 
-- 1 QUERY 
alter table d_creditos.pre_planpagos add cambio_bd varchar(250) default null;

-- 2 QUERY
alter table d_creditos.pre_reprograma add cambio_bd varchar(250) default null;

-- 3 QUERY 
DROP TRIGGER "d_creditos".tu_pre_planpagos;
  
