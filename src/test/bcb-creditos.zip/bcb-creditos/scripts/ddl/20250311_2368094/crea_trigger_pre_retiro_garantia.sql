select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Crea un trigger que se utilizar� durante la actualizacion de datos en la tabla pre_retiro_garantia 
         -- FECHA: 2025-03-11
         -- SDAPO: 2368094
         -- USUARIO: Mabel Ramos
         -- ***********************************************************************
from systables limit 1;

DROP TRIGGER IF EXISTS "d_creditos".tu_h_pre_retiro_garantia;

CREATE TRIGGER "d_creditos".tu_h_pre_retiro_garantia
    UPDATE ON "d_creditos".pre_retiro_garantia
    REFERENCING OLD AS o_upd NEW AS n_upd
    FOR EACH ROW
    ( 
        EXECUTE PROCEDURE "d_creditos".pu_h_pre_retiro_garantia(
			o_upd.id, o_upd.coddsb, o_upd.codcred, o_upd.codmod, o_upd.fecha, o_upd.nro_claveserie, o_upd.acta_retiro, o_upd.cuota,
			o_upd.fecha_vencimiento, o_upd.valor_cuota, o_upd.estado, o_upd.nro_comprobante_coin, o_upd.glosa_coin, 
			o_upd.glosa_debe, o_upd.glosa_haber, o_upd.cambio_bd, o_upd.audit_usuario, o_upd.audit_fechahora, 
			o_upd.audit_host, o_upd.audit_usuario_genera, o_upd.audit_fechahora_genera, 
			o_upd.audit_host_genera, o_upd.audit_usuario_preautoriza, o_upd.audit_fechahora_preautoriza, 
			o_upd.audit_host_preautoriza, o_upd.audit_usuario_autoriza, o_upd.audit_fechahora_autoriza, 
			o_upd.audit_host_autoriza,
			n_upd.id, n_upd.coddsb, n_upd.codcred, n_upd.codmod, n_upd.fecha, n_upd.nro_claveserie, n_upd.acta_retiro, n_upd.cuota,
			n_upd.fecha_vencimiento, n_upd.valor_cuota, n_upd.estado, n_upd.nro_comprobante_coin, n_upd.glosa_coin, 
			n_upd.glosa_debe, n_upd.glosa_haber, n_upd.cambio_bd, n_upd.audit_usuario, n_upd.audit_fechahora, 
			n_upd.audit_host, n_upd.audit_usuario_genera, n_upd.audit_fechahora_genera, 
			n_upd.audit_host_genera, n_upd.audit_usuario_preautoriza, n_upd.audit_fechahora_preautoriza, 
			n_upd.audit_host_preautoriza, n_upd.audit_usuario_autoriza, n_upd.audit_fechahora_autoriza, 
			n_upd.audit_host_autoriza
        )
    );