select 1 -- ***********************************************************************
         -- BD: creditos
         -- DESCRIPCI�N: Crea tabla pre_retiro_garantia y pre_retiro_garantia_h para el registro de comprobante de retiro  
         -- FECHA: 2025-03-11
         -- SDAPO: 2368094
         -- USUARIO: Alvaro Canqui, Mabel Ramos
         -- ***********************************************************************
from systables limit 1;


DROP TABLE IF EXISTS "d_creditos".pre_retiro_garantia;

CREATE TABLE d_creditos.pre_retiro_garantia (
    id SERIAL NOT NULL,  
	coddsb INT NOT NULL,
    codcred INT NOT NULL,
    codmod INT NOT NULL,
    fecha DATE NOT NULL,
	nro_claveserie varchar(30),
    acta_retiro VARCHAR(70) NOT NULL,
	cuota INT NOT NULL,
	fecha_vencimiento date NOT NULL,
	valor_cuota DECIMAL(15,2) NOT NULL,
    estado INT NOT NULL DEFAULT 1,  -- estado Registrado=1/preautorizado=2/Autorizado=3/Rechazado=4
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(500),
	glosa_debe LVARCHAR(500),
    glosa_haber LVARCHAR(500),
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    audit_usuario_genera VARCHAR(15),                      
    audit_fechahora_genera DATETIME YEAR TO SECOND,  
    audit_host_genera VARCHAR(20),
    audit_usuario_preautoriza VARCHAR(15),                
    audit_fechahora_preautoriza DATETIME YEAR TO SECOND,  
    audit_host_preautoriza VARCHAR(20),
    audit_usuario_autoriza VARCHAR(15),                    
    audit_fechahora_autoriza DATETIME YEAR TO SECOND,  
    audit_host_autoriza VARCHAR(20),
    PRIMARY KEY (id),
	FOREIGN KEY (coddsb) REFERENCES d_creditos.pre_desemb(dsb_coddsb)
);


DROP TABLE IF EXISTS "d_creditos".pre_retiro_garantia_h;

CREATE TABLE d_creditos.pre_retiro_garantia_h (
    historico_id SERIAL NOT NULL,  
    id INT NOT NULL, 
	coddsb INT NOT NULL,
    codcred INT NOT NULL,
    codmod INT NOT NULL,
    fecha DATE NOT NULL,
	nro_claveserie varchar(30),
	acta_retiro VARCHAR(70) NOT NULL,
	cuota INT NOT NULL,
	fecha_vencimiento date NOT NULL,
	valor_cuota DECIMAL(15,2) NOT NULL,
    estado INT NOT NULL, 
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(500),
	glosa_debe LVARCHAR(500),
    glosa_haber LVARCHAR(500),
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    audit_usuario_genera VARCHAR(15),                      
    audit_fechahora_genera DATETIME YEAR TO SECOND,  
    audit_host_genera VARCHAR(20),
    audit_usuario_preautoriza VARCHAR(15),                
    audit_fechahora_preautoriza DATETIME YEAR TO SECOND,  
    audit_host_preautoriza VARCHAR(20),
    audit_usuario_autoriza VARCHAR(15),                    
    audit_fechahora_autoriza DATETIME YEAR TO SECOND,  
    audit_host_autoriza VARCHAR(20),
    PRIMARY KEY (historico_id) 	
);
