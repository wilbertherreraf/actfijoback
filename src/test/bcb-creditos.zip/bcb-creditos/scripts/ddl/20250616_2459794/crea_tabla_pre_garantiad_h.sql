select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea tablas pre_garantiad_h para registrar la informacion historica de la tabla pre_garantiad.
         -- FECHA: 16/06/2025
         -- SDAPO: 2459794
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;

DROP TABLE IF EXISTS d_creditos.pre_garantiad_h;

CREATE TABLE d_creditos.pre_garantiad_h (
    gard_cod INTEGER NOT NULL,
    gard_codcred INTEGER NOT NULL,
    gard_codmod INTEGER NOT NULL,
    gard_coddsb INTEGER NOT NULL,
    gard_habilita boolean,  -- Reemplazo de BOOLEAN
    gard_claveserie VARCHAR(30),
    gard_titulo VARCHAR(10),
    gard_negociable boolean,  -- Reemplazo de BOOLEAN
    gard_tabtrxstaau INTEGER DEFAULT 30,
    gard_trxstaau INTEGER DEFAULT 1,
    gard_auditusr VARCHAR(15),
    gard_auditfho DATETIME YEAR TO SECOND,  -- Ajuste DATETIME
    gard_auditwst VARCHAR(50),
    hist_accion VARCHAR(20),  -- 'UPD'
    hist_fecha DATETIME YEAR TO SECOND
);