select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea un trigger que se utilizar durante la actualizacion de datos en la tabla pre_garantiad
         -- FECHA: 16-06-2025
         -- SDAPO: 2459794
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;


DROP TRIGGER IF EXISTS d_creditos.tu_h_pre_garantiad;
 
CREATE TRIGGER d_creditos.tu_h_pre_garantiad
    UPDATE ON d_creditos.pre_garantiad
    REFERENCING OLD AS o NEW AS n
    FOR EACH ROW
    (
       EXECUTE PROCEDURE d_creditos.pu_h_pre_garantiad(
            o.gard_cod,
		    o.gard_codcred,
		    o.gard_codmod,
		    o.gard_coddsb,
		    o.gard_habilita,
		    o.gard_claveserie,
		    o.gard_titulo,
		    o.gard_negociable,
		    o.gard_tabtrxstaau,
		    o.gard_trxstaau,
		    o.gard_auditusr,
		    o.gard_auditfho,
		    o.gard_auditwst
        )
    );