select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Adiciona columna de auditoria en la tabla pre_garantiad.
         -- FECHA: 16/06/2025
         -- SDAPO: 2459794
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;
   
alter table d_creditos.pre_garantiad add cambio_bd varchar(250) default null;