DROP PROCEDURE IF EXISTS "d_creditos".pu_h_pre_registrogarantias;

CREATE PROCEDURE "d_creditos".pu_h_pre_registrogarantias(
    o_id INTEGER, o_codcred INTEGER, o_codmod INTEGER, o_coddsb INTEGER, o_fecha DATE, o_valor_total_garantia DECIMAL(15,2),
    o_nota_solicitud VARCHAR(70), o_numero_tramite VARCHAR(70), o_cantidad_bonos INTEGER, o_numero_desembolso INTEGER,
    o_estado INTEGER, o_nro_comprobante_coin VARCHAR(250), o_glosa_coin LVARCHAR(500), o_cambio_bd VARCHAR(250),
    o_audit_usuario VARCHAR(15), o_audit_fechahora DATETIME YEAR TO SECOND, o_audit_host VARCHAR(20),
    o_audit_usuario_genera VARCHAR(15), o_audit_fechahora_genera DATETIME YEAR TO SECOND, o_audit_host_genera VARCHAR(20),
    o_audit_usuario_preautoriza VARCHAR(15), o_audit_fechahora_preautoriza DATETIME YEAR TO SECOND, o_audit_host_preautoriza VARCHAR(20),
    o_audit_usuario_autoriza VARCHAR(15), o_audit_fechahora_autoriza DATETIME YEAR TO SECOND, o_audit_host_autoriza VARCHAR(20),
    n_id INTEGER, n_codcred INTEGER, n_codmod INTEGER, n_coddsb INTEGER, n_fecha DATE, n_valor_total_garantia DECIMAL(15,2),
    n_nota_solicitud VARCHAR(70), n_numero_tramite VARCHAR(70), n_cantidad_bonos INTEGER, n_numero_desembolso INTEGER,
    n_estado INTEGER, n_nro_comprobante_coin VARCHAR(250), n_glosa_coin LVARCHAR(500), n_cambio_bd VARCHAR(250),
    n_audit_usuario VARCHAR(15), n_audit_fechahora DATETIME YEAR TO SECOND, n_audit_host VARCHAR(20),
    n_audit_usuario_genera VARCHAR(15), n_audit_fechahora_genera DATETIME YEAR TO SECOND, n_audit_host_genera VARCHAR(20),
    n_audit_usuario_preautoriza VARCHAR(15), n_audit_fechahora_preautoriza DATETIME YEAR TO SECOND, n_audit_host_preautoriza VARCHAR(20),
    n_audit_usuario_autoriza VARCHAR(15), n_audit_fechahora_autoriza DATETIME YEAR TO SECOND, n_audit_host_autoriza VARCHAR(20)
)

   
-- DESCRIPCI�N: Procedimiento utilizado en trigger para el registro de datos en la tabla pre_registrogarantias_hist
-- PARAMETROS INGRESO: o_id INTEGER,
--                     o_codcred INTEGER, 
--                     o_codmod INTEGER, 
--                     o_coddsb INTEGER,
--					   o_fecha DATE,	 
--                     o_valor_total_garantia DECIMAL(15,2),
--                     o_nota_solicitud VARCHAR(70), 
--                     o_numero_tramite VARCHAR(70), 
--                     o_cantidad_bonos INTEGER, 
--                     o_numero_desembolso INTEGER,
--                     o_estado INTEGER, 
--                     o_nro_comprobante_coin VARCHAR(250), 
--                     o_glosa_coin LVARCHAR(500), 
--                     o_cambio_bd VARCHAR(250),
--                     o_audit_usuario VARCHAR(15), 
--                     o_audit_fechahora DATETIME YEAR TO SECOND, 
--                     o_audit_host VARCHAR(20),
--                     o_audit_usuario_genera VARCHAR(15), 
--                     o_audit_fechahora_genera DATETIME YEAR TO SECOND, 
--                     o_audit_host_genera VARCHAR(20),
--                     o_audit_usuario_preautoriza VARCHAR(15), 
--                     o_audit_fechahora_preautoriza DATETIME YEAR TO SECOND, 
--                     o_audit_host_preautoriza VARCHAR(20),
--                     o_audit_usuario_autoriza VARCHAR(15), 
--                     o_audit_fechahora_autoriza DATETIME YEAR TO SECOND, 
--                     o_audit_host_autoriza VARCHAR(20),
--                     n_id INTEGER, 
--                     n_codcred INTEGER, 
--                     n_codmod INTEGER, 
--                     n_coddsb INTEGER, 
--                     n_valor_total_garantia DECIMAL(15,2),
--                     n_nota_solicitud VARCHAR(70), 
--                     n_numero_tramite VARCHAR(70), 
--                     n_cantidad_bonos INTEGER, 
--                     n_numero_desembolso INTEGER,
--                     n_estado INTEGER, 
--                     n_nro_comprobante_coin VARCHAR(250), 
--                     n_glosa_coin LVARCHAR(500), 
--                     n_cambio_bd VARCHAR(250),
--                     n_audit_usuario VARCHAR(15), 
--                     n_audit_fechahora DATETIME YEAR TO SECOND, 
--                     n_audit_host VARCHAR(20),
--                     n_audit_usuario_genera VARCHAR(15), 
--                     n_audit_fechahora_genera DATETIME YEAR TO SECOND, 
--                     n_audit_host_genera VARCHAR(20),
--                     n_audit_usuario_preautoriza VARCHAR(15), 
--                     n_audit_fechahora_preautoriza DATETIME YEAR TO SECOND, 
--                     n_audit_host_preautoriza VARCHAR(20),
--                     n_audit_usuario_autoriza VARCHAR(15), 
--                     n_audit_fechahora_autoriza DATETIME YEAR TO SECOND, 
--                     n_audit_host_autoriza VARCHAR(20)
--         
-- PARAMETROS SALIDA: 
--
-- AUTOR: ALVARO CANQUI
-- DEPENDENCIAS: CREDITOS (pre_registrogarantias_hist)
-- CREACI�N:  04-02-2025
-- SDAPO: 2344735
-----------------------------------------------------------------------------------------------------------------------------------------------------------
-- HISTORIAL DE CAMBIOS
-- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--|           |               |          |  
----------------------------------------------------------------------------

    -- Insert the new values into the historical table for UPDATE (n_ refers to new values)
    INSERT INTO "d_creditos".pre_registrogarantias_hist (
        id, codcred, codmod, coddsb, fecha, valor_total_garantia, nota_solicitud, numero_tramite,
        cantidad_bonos, numero_desembolso, estado, nro_comprobante_coin, glosa_coin, cambio_bd,
        audit_usuario, audit_fechahora, audit_host, 
        audit_usuario_genera, audit_fechahora_genera, audit_host_genera,
        audit_usuario_preautoriza, audit_fechahora_preautoriza, audit_host_preautoriza,
        audit_usuario_autoriza, audit_fechahora_autoriza, audit_host_autoriza,
        fecha_modificacion, usuario_modificacion, host_modificacion
    )
    VALUES (
        o_id, o_codcred, o_codmod, o_coddsb, o_fecha, o_valor_total_garantia, o_nota_solicitud, o_numero_tramite,
        o_cantidad_bonos, o_numero_desembolso, o_estado, o_nro_comprobante_coin, o_glosa_coin, o_cambio_bd,
        o_audit_usuario, o_audit_fechahora, o_audit_host, 
        o_audit_usuario_genera, o_audit_fechahora_genera, o_audit_host_genera,
        o_audit_usuario_preautoriza, o_audit_fechahora_preautoriza, o_audit_host_preautoriza,
        o_audit_usuario_autoriza, o_audit_fechahora_autoriza, o_audit_host_autoriza,
        CURRENT, user, (select trim(hostname) from sysmaster:syssessions where sid = (select  DBINFO('sessionid') from systables where tabname = 'systables'))
    );
END PROCEDURE;   