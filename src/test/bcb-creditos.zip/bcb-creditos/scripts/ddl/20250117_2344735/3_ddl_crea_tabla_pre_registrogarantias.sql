select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea tabla pre_registrogarantias y pre_registrogarantias_h para el registro transitorio de garantias y tanla historica.
         -- FECHA: 05-02-2025
         -- SDAPO: 2344735
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;


DROP TABLE IF EXISTS pre_registrogarantias;

CREATE TABLE d_creditos.pre_registrogarantias (
    id SERIAL NOT NULL,  
    codcred INT NOT NULL,
    codmod INT NOT NULL,
    coddsb INT NOT NULL,
    fecha DATE NOT NULL,
    valor_total_garantia DECIMAL(15,2),
    nota_solicitud VARCHAR(70) NOT NULL,
    numero_tramite VARCHAR(70) NOT NULL,
    cantidad_bonos INT NOT NULL,
    numero_desembolso INT NOT NULL,
    estado INT NOT NULL DEFAULT 1,  -- estado Registrado=1/preautorizado=2/Autorizado=3/Rechazado=4
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(500),
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,  
    audit_host VARCHAR(20),
    
    audit_usuario_genera VARCHAR(15),				-- usuario que genera el comprobante
    audit_fechahora_genera DATETIME YEAR TO SECOND,  
    audit_host_genera VARCHAR(20),
    
    audit_usuario_preautoriza VARCHAR(15),			-- usuario que preautoriza el comprobante
    audit_fechahora_preautoriza DATETIME YEAR TO SECOND,  
    audit_host_preautoriza VARCHAR(20),
    
    audit_usuario_autoriza VARCHAR(15),				-- usuario que autoriza el comprobante
    audit_fechahora_autoriza DATETIME YEAR TO SECOND,  
    audit_host_autoriza VARCHAR(20),
    PRIMARY KEY (id),
    FOREIGN KEY (codcred, codmod) REFERENCES pre_prestamos (pre_codcred, pre_codmod) CONSTRAINT fk_codcred, -- CREA LLAVES FOREANEAS
    FOREIGN KEY (coddsb) REFERENCES pre_desemb (dsb_coddsb) CONSTRAINT d_creditos.fk_coddsb -- LLAVE FORANEA
);




DROP TABLE IF EXISTS pre_registrogarantias_hist;

CREATE TABLE d_creditos.pre_registrogarantias_hist(
    historico_id SERIAL NOT NULL,  -- ID único para la tabla histórica
    id INT NOT NULL,               -- ID original de la tabla
    codcred INT NOT NULL,
    codmod INT NOT NULL,
    coddsb INT NOT NULL,
    fecha DATE NOT NULL,
    valor_total_garantia DECIMAL(15,2),
    nota_solicitud VARCHAR(70) NOT NULL,
    numero_tramite VARCHAR(70) NOT NULL,
    cantidad_bonos INT NOT NULL,
    numero_desembolso INT NOT NULL,
    estado INT NOT NULL DEFAULT 1,
    nro_comprobante_coin VARCHAR(250),
    glosa_coin LVARCHAR(500),
    cambio_bd VARCHAR(250),
    audit_usuario VARCHAR(15),
    audit_fechahora DATETIME YEAR TO SECOND,
    audit_host VARCHAR(20),
    
    audit_usuario_genera VARCHAR(15),				-- usuario que genera el comprobante
    audit_fechahora_genera DATETIME YEAR TO SECOND,  
    audit_host_genera VARCHAR(20),
    
    audit_usuario_preautoriza VARCHAR(15),			-- usuario que preautoriza el comprobante	
    audit_fechahora_preautoriza DATETIME YEAR TO SECOND,  
    audit_host_preautoriza VARCHAR(20),
    
    audit_usuario_autoriza VARCHAR(15),				-- usuario que autoriza el comprobante
    audit_fechahora_autoriza DATETIME YEAR TO SECOND,  
    audit_host_autoriza VARCHAR(20),
    
    fecha_modificacion DATETIME YEAR TO SECOND,  -- Fecha de modificación
    usuario_modificacion VARCHAR(15),           -- Usuario que hizo la modificación
    host_modificacion VARCHAR(15),
    PRIMARY KEY (historico_id)                    -- Clave primaria propia para la tabla histórica
);