select 1 -- **********************************************************************
         -- BD: creditos
         -- DESCRIPCION: Crea un trigger que se utilizará durante la actualizacion de datos en la tabla  pre_registrogarantias.
         -- FECHA: 05-02-2025
         -- SDAPO: 2344735
         -- USUARIO: Alvaro Fabian Canqui Callisaya
         -- **********************************************************************
from systables limit 1;


DROP TRIGGER IF EXISTS "d_creditos".tu_h_pre_registrogarantias;

CREATE TRIGGER "d_creditos".tu_h_pre_registrogarantias
    UPDATE ON "d_creditos".pre_registrogarantias
    REFERENCING OLD AS o_upd NEW AS n_upd
    FOR EACH ROW
(
    EXECUTE PROCEDURE "d_creditos".pu_h_pre_registrogarantias(
        o_upd.id, o_upd.codcred, o_upd.codmod, o_upd.coddsb, o_upd.fecha, o_upd.valor_total_garantia,
        o_upd.nota_solicitud, o_upd.numero_tramite, o_upd.cantidad_bonos, o_upd.numero_desembolso,
        o_upd.estado, o_upd.nro_comprobante_coin, o_upd.glosa_coin, o_upd.cambio_bd,
        o_upd.audit_usuario, o_upd.audit_fechahora, o_upd.audit_host,
        o_upd.audit_usuario_genera, o_upd.audit_fechahora_genera, o_upd.audit_host_genera,
        o_upd.audit_usuario_preautoriza, o_upd.audit_fechahora_preautoriza, o_upd.audit_host_preautoriza,
        o_upd.audit_usuario_autoriza, o_upd.audit_fechahora_autoriza, o_upd.audit_host_autoriza,
        n_upd.id, n_upd.codcred, n_upd.codmod, n_upd.coddsb, n_upd.fecha, n_upd.valor_total_garantia,
        n_upd.nota_solicitud, n_upd.numero_tramite, n_upd.cantidad_bonos, n_upd.numero_desembolso,
        n_upd.estado, n_upd.nro_comprobante_coin, n_upd.glosa_coin, n_upd.cambio_bd,
        n_upd.audit_usuario, n_upd.audit_fechahora, n_upd.audit_host,
        n_upd.audit_usuario_genera, n_upd.audit_fechahora_genera, n_upd.audit_host_genera,
        n_upd.audit_usuario_preautoriza, n_upd.audit_fechahora_preautoriza, n_upd.audit_host_preautoriza,
        n_upd.audit_usuario_autoriza, n_upd.audit_fechahora_autoriza, n_upd.audit_host_autoriza
    )
);