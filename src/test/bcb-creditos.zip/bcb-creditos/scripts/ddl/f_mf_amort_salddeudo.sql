DROP PROCEDURE IF EXISTS "d_creditos".f_mf_amort_salddeudo; 



CREATE FUNCTION d_creditos.f_mf_amort_salddeudo( p_app_t aux_planpagos_t, p_feciniint date, p_fecultvenc date,  NPER INTEGER, NGRACIA INTEGER, NGRACIAINT INTEGER, NPAY INTEGER, NRODIASPERIODO INTEGER)
returning aux_planpagos_t
{***** ==> LOG <== *****
wherrera 2021-10-15 tabla de amortizacion de saldos deudores

-- DESCRIPCION: Procedimiento para generar pagos anticipados
-- PARAMETROS INGRESO: p_app_t aux_planpagos_t, 
--                     p_feciniint date, 
--                     p_fecultvenc date,  
--                     NPER INTEGER, 
--                     NGRACIA INTEGER, 
--                     NGRACIAINT INTEGER, 
--                     NPAY INTEGER, 
--                     NRODIASPERIODO INTEGER
--                     


-- PARAMETROS SALIDA:  aux_planpagos_t
-- AUTOR: wherrera
-- CREACION: 2021-10-15

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| wherrera  |  2021-1015   |          | procedimiento para la amortizacion de saldos deudores
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  13-10-2025   | 2333600  | Ajustes en el procedimiento para anadir el calculo de plan de pagos para creditos de 365 dias
-----------------------------------------------------------------------------------------------------------------------------------------------------

}
    define v_amt_resto, v_capamortper, v_siap, v_cap_amort_per, v_amortper, v_sidp decimal(20,2);
    define v_period, C_TASAPERIODO, C_INPUT_PERIOD_EXACT, v_nroper_cap integer;
    define v_first, D_DIFFERENCE_IN_DAYS , MONTHSPERPERIOD, v_TRAINTYDAYS integer;
    define v_nroper_calendar, v_nroper_pp, v_nroper_pp_cal integer;
    define ROI, v_intper float;
    define v_fechaper, v_fechafin, v_fechaini, v_fecmax_cap, v_fecini_cap, v_fechalimit_prg date;
    define v_app_t aux_planpagos_t;
    --define D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY date;
    DEFINE C_TASAPERIODO_ANUAL, C_TIPOCUO_INT, C_TIPOCUO_CAP INTEGER;
    define P_TRAINTYDAYS, P_TRAINTMDAYS integer;
    define C_NROMAXPERS, v_contctrl integer;
   
   
    define FLAG_GESTION_365 INTEGER;
    define result_redondeado  INTEGER;
   
    
    -- determina si existe un pp 
    let C_TIPOCUO_INT = 2;
    let C_TIPOCUO_CAP = 1;
    let v_first = 0;
    let C_TASAPERIODO = 0;
    let C_INPUT_PERIOD_EXACT = 3;
    let C_TASAPERIODO_ANUAL = 1;
    let ngracia = nvl(ngracia, 0);
    let ngraciaint = nvl(ngraciaint, 0);
    let v_cap_amort_per = 0;
    let nper = nvl(nper, 0);
    let NPAY = nvl(NPAY, 0);  --   
    let C_NROMAXPERS = 1000;
    let v_contctrl = 0;
    let NRODIASPERIODO = nvl(NRODIASPERIODO, 0);
    let v_fechalimit_prg = null;
   
    let FLAG_GESTION_365=0;
    let result_redondeado=0;
    
    --SQL Error [IX000]: [OBS_DES-f_mf_amort_salddeudo] P_TRAINTYDAYS-> 360 P_TRAINTMDAYS-> 1
    call f_GET_TRA_INT_YR_MTH_BASE(p_app_t.acu_codmod , p_app_t.acu_codcred ) returning P_TRAINTYDAYS, P_TRAINTMDAYS;
    --call f_INT_MATURITY_AND_GRACE(p_app_t.acu_codmod, p_app_t.acu_codcred, null) returning D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY;
     

    let v_fechalimit_prg = p_fecultvenc; 
    
    
    if v_fechalimit_prg is null and NPER > 0 then
    	-- OBTIENE LA ULTIMA FECHA DE VENCIMIENTO DEL PLAN DE PAGOS
        let v_fechalimit_prg = f_periodo_fechafin(p_app_t.acu_fecvencuo, NPER, p_app_t.acu_unidplaz, NRODIASPERIODO, null);
    end if
    	
   
       
    if NPER >= NPAY and npay > 0 and p_app_t.acu_fecfincuo is not null and v_fechalimit_prg is null then
        let v_fechalimit_prg = f_periodo_fechafin(p_app_t.acu_fecfincuo, NPAY, p_app_t.acu_unidplaz, NRODIASPERIODO, null);
    end if
    
 
    
    -- nro de periodos captial
    if npay = 0 then
        call f_periodos_fechas(p_app_t.acu_fecfincuo, v_fechalimit_prg, p_app_t.acu_unidplaz, NRODIASPERIODO, C_INPUT_PERIOD_EXACT, 0) returning npay, v_nroper_calendar, v_fecmax_cap;    
    end if
    
    
    -- p_app_t.acu_capital (es monto que se desembolsara)
    let p_app_t.acu_capital = nvl(p_app_t.acu_capital, 0); -- EN CASO DE QUE EL IMPORTE DESEMBOLSADO SEA NULO LE ASIGNA CERO 
    
    
    let v_cap_amort_per = p_app_t.acu_capital;

    IF npay > 0 then
        let v_cap_amort_per = p_app_t.acu_capital / npay;

       
    end if

    let v_cap_amort_per = round(v_cap_amort_per, 2);
   
    
    if p_app_t.acu_unidplaz in (1,7) and NRODIASPERIODO <= 0 then
        raise exception -746,0, "Periodicidad irregular debe tener dias periodos mayor a cero.";
    end if
    
    let v_capamortper = 0;
    let v_period = 1; 
    let v_siap = p_app_t.acu_capital; -- monto a desembolsar
    let v_amt_resto = p_app_t.acu_capital; -- monto a desembolsar
    let v_fechaper = p_app_t.acu_fecvencuo; -- primera fecha de vencimiento
      
   
    
    WHILE (v_fechaper < v_fechalimit_prg) or (v_amt_resto > 0 and v_period = 1 and NPER = 1) -- while para generar el plan de pagos
        let v_app_t = f_init_app_t();
        
        /*** ----------------------------------------------------------------------------------------------------------------------------------- ***/
       		 -- codigo nuevo para creditos registrados por 365 dias
       		 if (select mtp_intydias from d_creditos.pre_tasaspre where mtp_codcred=p_app_t.acu_codcred and mtp_codmod=p_app_t.acu_codmod)=365 then	
       		 	/*** ----------------------------------------------------------------------------------------------------------------------------------- ***/
       		 		 -- codigo a�adido para creditos con 365 dias
	       		 		 if v_first = 0 then
					       		
					       		-- obtiene la fecha de inicio y fin de periodo, inicio y fin del periodo de pago. la fecha fin es la fecha de vencimiento de cuota
					       		-- la variable MONTHSPERPERIOD es el tiempo en meses entre la fecha de inicio y fin
					            call f_infoperiodo(null, p_app_t.acu_fecvencuo, p_app_t.acu_unidplaz, C_INPUT_PERIOD_EXACT) returning MONTHSPERPERIOD, v_fechaini, v_fechafin;
					           
					          
					       
					            let v_first = 1;
					            let v_app_t.acu_fecinicuo = p_app_t.acu_fecinicuo;
					            let v_fechaini = p_app_t.acu_fecinicuo;
					           
					            let v_app_t.acu_fecvencuo = v_fechafin; -- CODIGO A�ADIDO
					            -- obtiene la cantidad de dias entre la fecha de desembolso y la fecha del primer vencimiento de cuoa. Es el primer registro del plan de pagos
					            call f_DAYS_BETWEEN_2_DATES(v_fechaini, v_app_t.acu_fecvencuo, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS; -- CODIGO A�ADIDO
					            
					          
					     else
					            IF NRODIASPERIODO > 0 AND p_app_t.acu_unidplaz IN(1,7) then					            
					            	
					                let v_app_t.acu_fecinicuo = v_fechaper + 1;
					                let v_fechafin = v_fechaper + NRODIASPERIODO;
					               
					                let v_app_t.acu_fecvencuo = v_fechafin; -- CODIGO A�ADIDO
					                
				                
					            else
					
					       			call f_infoperiodo(v_fechaper + 1, v_fechaper, p_app_t.acu_unidplaz, C_INPUT_PERIOD_EXACT) returning MONTHSPERPERIOD, v_fechaini, v_fechafin;
					       			
						       		/**************************************************************************************************/
					       			
						       				if FLAG_GESTION_365=0 then
					       						    let result_redondeado=FLOOR(365/2);
								       				let FLAG_GESTION_365=1;	
								       			
								       				if MOD(DAY(v_fechafin), 2) = 0 then -- verificarmos que el dia de la fecha de vencimiento de cuota anterior es par
								       					let v_app_t.acu_fecvencuo = v_fechafin-1;
								       				else
								       					let v_app_t.acu_fecvencuo = v_fechafin+1;	
								       				end if
								       				
								       				--let v_app_t.acu_fecvencuo = v_fechafin-1;								       				
								       				let v_fechaini=v_fechaini-1; 

								       			else
								       				let result_redondeado=CEIL(365/2);
								       				let FLAG_GESTION_365=0;
													let v_app_t.acu_fecvencuo = v_fechafin;

								       		end if	
	
					       			/**************************************************************************************************/
				                
					               
					            end if
					            
					            let v_app_t.acu_fecinicuo = v_fechaini;
					            let v_fechaini = v_fechaper;
					           
					            call f_DAYS_BETWEEN_2_DATES(v_fechaini, v_app_t.acu_fecvencuo, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS; -- CODIGO A�ADIDO
					            /*------------------- CODIGO PARA SUMAR O RESTAR UN DIA DE ACUERDO AL TIPO DE LA PRIMERA FECHA DE VENCIMIENTO DE CUOTA -------------*/
					           		if FLAG_GESTION_365=0 then
					           			if MOD(DAY(v_fechafin), 2) = 0 then -- verificarmos que el dia de la fecha de vencimiento de cuota anterior es par
								       		let D_DIFFERENCE_IN_DAYS=D_DIFFERENCE_IN_DAYS+1;				
								       	else
								       		let D_DIFFERENCE_IN_DAYS=D_DIFFERENCE_IN_DAYS-1;			
								       	end if	
					           			-- let D_DIFFERENCE_IN_DAYS=D_DIFFERENCE_IN_DAYS+1;
						       		end if
								/*---------------------------------------------------------*/
					               
					     end if
				        
				        --- let v_app_t.acu_fecvencuo = v_fechafin;     -- CODIGO ORIGINAL
				       
				       
				        -- p_app_t.acu_fecfincuo almacena la fecha ini de cap
				        if v_app_t.acu_fecvencuo >= p_app_t.acu_fecfincuo then
				            if nvl(v_cap_amort_per, 0) <= 0 then
				                let v_cap_amort_per = v_amt_resto;
				            end if
				            
				            let v_capamortper = v_amt_resto - v_cap_amort_per;
				          
				            if v_capamortper < 0 then
				                let v_capamortper = v_amt_resto;
				            else
				                if v_app_t.acu_fecvencuo < v_fechalimit_prg then
				                
				                	-- codigo a�adido para sumar el ajuste en la ultima cuota del plan de pagos para creditos de 365 dias
				                	if v_capamortper >0 and v_capamortper < 1 then
				                		let v_capamortper = v_cap_amort_per+v_capamortper;
				                	else
				                		let v_capamortper = v_cap_amort_per;
				                	end if
				                
				                    --let v_capamortper = v_cap_amort_per; -- codigo original
				                else 
				                    let v_capamortper = v_amt_resto;
				                end if
				            end if
				            
				            if v_capamortper <= 0 then
				            	-- trace '----- ingreso a exit ------';
				                let v_amt_resto = 0;
				                exit while;
				            end if
				        end if        
				

				
				        let v_app_t.acu_tipoacu = D_DIFFERENCE_IN_DAYS;
				        let v_app_t.acu_codmod = p_app_t.acu_codmod;
				        let v_app_t.acu_codcred = p_app_t.acu_codcred;
				        let v_app_t.acu_coddsb = p_app_t.acu_coddsb;        
				        let v_app_t.acu_numcuo = v_period;
				        let v_app_t.acu_capital = v_siap;    
				        let v_app_t.acu_tasa = p_app_t.acu_tasa;
				        let v_app_t.acu_fecinicuo = v_fechaini;
				        
				        if v_app_t.acu_fecvencuo >= p_feciniint then
				        -- fecha de proceso de interes
				            let v_app_t.acu_fecfincuo = v_app_t.acu_fecvencuo;
				        else        
				            let v_app_t.acu_fecfincuo = p_feciniint;
				        end if
				        
				        
				        if p_app_t.acu_tasa is null or p_app_t.acu_tasa <= 0 then
				            let v_app_t.acu_tasa = f_gettasavigenteprest(p_app_t.acu_codcred, p_app_t.acu_codmod, v_fechaini);
				            --let v_app_t.acu_tasa = f_gettasavigenterepro(p_app_t.acu_codcred, p_app_t.acu_codmod, v_fechaper, null);
				        end if
				        
				        
				         -- obtiene el interes de acuerdo a la cantidad de dias que se encuentra en la variable D_DIFFERENCE_IN_DAYS
				         -- let v_intper = round(v_siap * f_tasaindiceperiodo(p_app_t.acu_unidplaz, v_app_t.acu_tasa, C_TASAPERIODO, P_TRAINTYDAYS, D_DIFFERENCE_IN_DAYS), 2);
				            let v_intper = round(((v_siap * D_DIFFERENCE_IN_DAYS * v_app_t.acu_tasa)/36000), 2); -- calculo enviado por la GOM
				       					   
				        
				        let v_amortper = round(v_intper + v_capamortper, 2);
				        let v_sidp = round(v_siap - v_capamortper, 2);        
				        
				        let v_app_t.acu_valor = v_capamortper;
				        let v_app_t.acu_interes = v_intper;
				       
			        
				        return v_app_t with resume;
				
				        let v_siap = v_sidp;
				        let v_period = v_period + 1;
				        let v_amt_resto = v_amt_resto - v_capamortper;        
				       
				--      LET v_fechaper = v_app_t.acu_fecvencuo; -- codigo original
				        LET v_fechaper = v_fechafin; -- codigo ajustado
				       
				        let v_contctrl = v_contctrl + 1;
				        --v_fechafin
				              
       
       		 
       		 		
       		 	/*** ----------------------------------------------------------------------------------------------------------------------------------- ***/
       		 else 
       		 
       		 	/*** ----------------------------------------------------------------------------------------------------------------------------------- ***/
       		 		 -- codigo original para creditos con 360 dias
       		 			if v_first = 0 then
				            call f_infoperiodo(null, p_app_t.acu_fecvencuo, p_app_t.acu_unidplaz, C_INPUT_PERIOD_EXACT) returning MONTHSPERPERIOD, v_fechaini, v_fechafin;
				            let v_first = 1;
				            let v_app_t.acu_fecinicuo = p_app_t.acu_fecinicuo;
				            let v_fechaini = p_app_t.acu_fecinicuo;
				        else
				            IF NRODIASPERIODO > 0 AND p_app_t.acu_unidplaz IN(1,7) THEN
				                let v_app_t.acu_fecinicuo = v_fechaper + 1;
				                let v_fechafin = v_fechaper + NRODIASPERIODO;
				            else
				                call f_infoperiodo(v_fechaper + 1, v_fechaper, p_app_t.acu_unidplaz, C_INPUT_PERIOD_EXACT) returning MONTHSPERPERIOD, v_fechaini, v_fechafin;
				            end if
				            let v_app_t.acu_fecinicuo = v_fechaini;
				            let v_fechaini = v_fechaper;
				               
				        end if
				        let v_app_t.acu_fecvencuo = v_fechafin;            
				        -- p_app_t.acu_fecfincuo almacena la fecha ini de cap
				        if v_app_t.acu_fecvencuo >= p_app_t.acu_fecfincuo then
				            if nvl(v_cap_amort_per, 0) <= 0 then
				                let v_cap_amort_per = v_amt_resto;
				            end if
				            
				            let v_capamortper = v_amt_resto - v_cap_amort_per;
				            if v_capamortper < 0 then
				                let v_capamortper = v_amt_resto;
				            else
				                if v_app_t.acu_fecvencuo < v_fechalimit_prg then
				                    let v_capamortper = v_cap_amort_per;
				                else 
				                    let v_capamortper = v_amt_resto;
				                end if
				            end if
				            
				            if v_capamortper <= 0 then
				                let v_amt_resto = 0;
				                exit while;
				            end if
				        end if        
				
				        call f_DAYS_BETWEEN_2_DATES(v_fechaini, v_app_t.acu_fecvencuo, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS;        
				
				        let v_app_t.acu_tipoacu = D_DIFFERENCE_IN_DAYS;
				        let v_app_t.acu_codmod = p_app_t.acu_codmod;
				        let v_app_t.acu_codcred = p_app_t.acu_codcred;
				        let v_app_t.acu_coddsb = p_app_t.acu_coddsb;        
				        let v_app_t.acu_numcuo = v_period;
				        let v_app_t.acu_capital = v_siap;    
				        let v_app_t.acu_tasa = p_app_t.acu_tasa;
				        let v_app_t.acu_fecinicuo = v_fechaini;
				        
				        if v_app_t.acu_fecvencuo >= p_feciniint then
				        -- fecha de proceso de interes
				            let v_app_t.acu_fecfincuo = v_app_t.acu_fecvencuo;
				        else        
				            let v_app_t.acu_fecfincuo = p_feciniint;
				        end if
				        
				        if p_app_t.acu_tasa is null or p_app_t.acu_tasa <= 0 then
				            let v_app_t.acu_tasa = f_gettasavigenteprest(p_app_t.acu_codcred, p_app_t.acu_codmod, v_fechaini);
				            --let v_app_t.acu_tasa = f_gettasavigenterepro(p_app_t.acu_codcred, p_app_t.acu_codmod, v_fechaper, null);
				        end if
				        let v_intper = round(v_siap * f_tasaindiceperiodo(p_app_t.acu_unidplaz, v_app_t.acu_tasa, C_TASAPERIODO, P_TRAINTYDAYS, D_DIFFERENCE_IN_DAYS), 2);
				        
				        let v_amortper = round(v_intper + v_capamortper, 2);
				        let v_sidp = round(v_siap - v_capamortper, 2);        
				        
				        let v_app_t.acu_valor = v_capamortper;
				        let v_app_t.acu_interes = v_intper;
				        
				        return v_app_t with resume;
				
				        let v_siap = v_sidp;
				        let v_period = v_period + 1;
				        let v_amt_resto = v_amt_resto - v_capamortper;        
				        LET v_fechaper = v_app_t.acu_fecvencuo;
				        let v_contctrl = v_contctrl + 1;
       		 		   	
       		    /*** ----------------------------------------------------------------------------------------------------------------------------------- ***/
       		 end if
       
        
        
        if v_contctrl > C_NROMAXPERS then
            --exit while;
            raise exception -746,0,"Atencion!! Numero de periodos excede el limite, revise los parametros.";
        end if
    end while
    
    
end function;                