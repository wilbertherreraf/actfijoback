DROP PROCEDURE IF EXISTS p_cambia_estado_comprobante;

CREATE PROCEDURE d_creditos.p_cambia_estado_comprobante(p_idtabla integer, p_codcmp integer, p_codcred integer, p_codmod integer, p_estado varchar(5), p_usuario varchar(15), p_estacion varchar(50)) RETURNING int AS resultado;

         -- DESCRIPCI�N: Procedimiento para cambiar el estado de los comprobantes a PREAUTORIZADO, AUTORIZADO o RECHAZADO
         -- PARAMETROS INGRESO: p_idtabla integer               Id de la tabla donde se actualizara el estado
         --						p_codcmp integer                codigo de comprobante
         --                     p_codcred integer               Codigo de credito
         --                     p_codmod integer                Codigo de modulo
         --                     p_estado varchar(5)             Estado del proceso -- P = pendiente / 1 = preautorizado / A = autorizado / R = rechazado
         --                     p_usuario varchar(15)           codigo de usuario
         --                     p_estacion varchar(50)          Estacion (IP) 
         -- PARAMETROS SALIDA: resultado integer                Resultado de la operacion
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: CREDITOS (pre_prcconta)
         --               CONTBCB (estado_comprob, comprobante) 
         -- CREACI�N:  06-02-2025
         -- SDAPO: 2344735
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
 		 ----------------------------------------------------------------------------------------------------------------------------------------------------
		 --|   Autor   |     Fecha     | SDAPO    |  Descripcion
		 ---------------------------------------------------------------------------
		 --| mcramos   |  07-03-2025   | 2367989  |  Ajuste para actualizar el estado del comprobante para registro de Custodia de Garantia
		 --| mcramos   |  28-03-2025   | 2368094  |  Ajuste para actualizar el estado del comprobante para registro de Retiro de Garantia
		 ----------------------------------------------------------------------------
		 --| mcramos   |  07-03-2025   | 2367989  |  Ajuste para actualizar el estado del comprobante para registro de Custodia de Garantia
		 ---------------------------------------------------------------------------------------------------------------------------------------
		 --| mcramos   |  28-03-2025   | 2368094  |  Ajuste para actualizar el estado del comprobante para registro de Retiro de Garantia
		 ---------------------------------------------------------------------------------------------------------------------------------------
		 --| acanqui   |  06-05-2025   | 2401886   | Ajuste para actualizar el estado del comprobante para registro de Pago de Cuota
		 ---------------------------------------------------------------------------------------------------------------------------------------



  define w_nro_comprobante_coin varchar(30);
  define w_audit_usuario_genera varchar(30);
  define w_nro_centro       	integer;
  define w_tipo_comprobante 	varchar(10);
 
  define w_nro_centro_coin integer; 
  define w_cve_tipo_comprob_coin varchar(10); 
  define w_nro_comprob_coin varchar(20); 
  define w_cve_estado_comprob_coin varchar(10); 
  define w_cod_usuario_coin varchar(20); 
  define w_estacion_coin varchar(10);
	
  define TIPO_COMPROBANTE INTEGER;
  
  DEFINE FALSE   integer;
  DEFINE TRUE    integer;
  
  let FALSE = 0;
  let TRUE = 1;
  let TIPO_COMPROBANTE=0;
 
      
  if p_idtabla is null  then
     Raise Exception -746, 0, "[ERROR_ESTADO_001] - El parametro inicial para cambiar el estado del comprobante no es valido.";
  end if   
  
  if p_codcred is null or p_codcred <= 0 then
     Raise Exception -746, 0, "[ERROR_ESTADO_002] - El c�digo de cr�dito del proceso especificado no es valido.";
  end if   

  if p_codmod is null or p_codmod <= 0 then
     Raise Exception -746, 0, "[ERROR_ESTADO_003] - El m�dulo de cr�dito del proceso especificado no es valido.";
  end if   
 
  if p_estado is null then
     Raise Exception -746, 0, "[ERROR_ESTADO_004] - El estado especificado no es valido.";
  end if   
  
  
  -- REGISTRO TRANSITORIO DE GARANTIAS
  if p_codcmp=8 then -- codigo para obtener los valores del registro transitorio de garantias
  	
  		select nro_comprobante_coin, audit_usuario_genera
  		into w_nro_comprobante_coin, w_audit_usuario_genera
  		from d_creditos.pre_registrogarantias
  		where id=p_idtabla;
  
  end if
  
  -- REGISTRO DE DESEMBOLSOS
  if p_codcmp=1 or p_codcmp=2 then -- codigo para obtener los valores del registro transitorio de garantias
  	
  		select nro_comprobante_coin, audit_usuario_genera
  		into w_nro_comprobante_coin, w_audit_usuario_genera
  		from d_creditos.pre_desembolso_detalle
  		where id=p_idtabla;

  end if

  -- REGISTRO_CONTABLE_CUSTODIA_GARANTIAS
  if p_codcmp=9 then -- codigo para obtener los valores del registro de custodia de garantias

  		select nro_comprobante_coin, audit_usuario_genera
  		into w_nro_comprobante_coin, w_audit_usuario_genera
  		from d_creditos.pre_custodia_garantia
  		where id=p_idtabla;

  end if

  -- REGISTRO_CONTABLE_RETIRO_GARANTIAS
  if p_codcmp=10 then -- codigo para obtener los valores del registro de retiro de garantias

  		select nro_comprobante_coin, audit_usuario_genera
  		into w_nro_comprobante_coin, w_audit_usuario_genera
  		from d_creditos.pre_retiro_garantia
  		where id=p_idtabla;

  end if

  -- REGISTRO_CONTABLE_CUSTODIA_GARANTIAS
  if p_codcmp=9 then -- codigo para obtener los valores del registro de custodia de garantias

  		select nro_comprobante_coin, audit_usuario_genera
  		into w_nro_comprobante_coin, w_audit_usuario_genera
  		from d_creditos.pre_custodia_garantia
  		where id=p_idtabla;

  end if

  -- REGISTRO_CONTABLE_RETIRO_GARANTIAS
  if p_codcmp=10 then -- codigo para obtener los valores del registro de retiro de garantias

  		select nro_comprobante_coin, audit_usuario_genera
  		into w_nro_comprobante_coin, w_audit_usuario_genera
  		from d_creditos.pre_retiro_garantia
  		where id=p_idtabla;

  end if

  -- REGISTRO_CONTABLE PAGO DE CUOTA
  if p_codcmp=4 then -- codigo para obtener los valores del registro de retiro de garantias

  		select nro_comprobante_coin, audit_usuario_genera
  		into w_nro_comprobante_coin, w_audit_usuario_genera
  		from d_creditos.pre_pagocuota
  		where id=p_idtabla;

  end if
  
  
  -- obtenemos los valores del tipo_centro y tipo_comprogbante para obtenr los datos del comprobante
  select cmp_centro, cmp_tipo
  into w_nro_centro, w_tipo_comprobante
  from d_creditos.gen_comprobante
  where cmp_codcmp= p_codcmp;
 
  IF dbinfo ("sqlca.sqlerrd2") = 0 THEN  -- no existe registro
  	   Raise Exception -746, 0, "[ERROR_ESTADO_004] - No existen datos del numero de centro y tipo de comprobante, verifique la informaci�n";	
       return false;       
   END IF
  
   
   -- obtenemos los valores del comprobante del COIN
--   select cve_estado_comprob, cod_usuario    --obtener usuario y estado actual 
   select  nro_centro, cve_tipo_comprob, nro_comprob, cve_estado_comprob, cod_usuario, estacion
   into w_nro_centro_coin, w_cve_tipo_comprob_coin, w_nro_comprob_coin, w_cve_estado_comprob_coin, w_cod_usuario_coin, w_estacion_coin
   from contbcb@bcbux02:d_conta.comprobante
   where nro_centro = w_nro_centro  
   and cve_tipo_comprob = w_tipo_comprobante 
   and nro_comprob = w_nro_comprobante_coin;
  
  
  if w_cod_usuario_coin = p_usuario then
     Raise Exception -746, 0, "[ERROR_ESTADO_005] - El usuario que realiza esta operaci�n no puede ser el mismo que gener� � preautoriz� el comprobante.";
     return false;
  end if

  
-- actualizamos el estado en el comprobante en el COIN
   update contbcb@bcbux02:d_conta.comprobante   --preautorizar comprobante
   set cve_estado_comprob = p_estado,
       cod_usuario = p_usuario,
       fecha_hora = current,
       estacion = p_estacion                                
   where nro_centro = w_nro_centro  
   and cve_tipo_comprob = w_tipo_comprobante 
   and nro_comprob = w_nro_comprobante_coin;
            
   if dbinfo ("sqlca.sqlerrd2") = 0 then  -- no hizo el update
         Raise Exception -746, 0, "[ERROR_ESTADO_006] - No se pudo actualizar el estado del comprobante en COIN. Revisar en COIN";
   end if
    
   
   -- insertamos el estado anterior en la tabla estado_comprob del COIN
   insert into contbcb@bcbux02:d_conta.estado_comprob
   values (w_nro_centro_coin, w_cve_tipo_comprob_coin, w_nro_comprob_coin,w_cve_estado_comprob_coin, w_cod_usuario_coin, current, p_estacion);
        
   if dbinfo ("sqlca.sqlerrd2") != 0 then  -- inserto
      	return true;       
   else       --marcar proceso con estado error 
        Raise Exception -746, 0, "[ERROR_ESTADO_007] - No se pudo insertar el estado del comprobante en COIN. Revisar en COIN";
   end if
  
  return false;
    
END PROCEDURE;

