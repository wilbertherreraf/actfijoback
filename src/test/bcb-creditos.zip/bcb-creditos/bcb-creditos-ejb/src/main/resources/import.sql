-- You can use this file to load seed data into the database using SQL statements
insert into Occupation (id, descripcion) values (1, 'Informatico');
insert into Occupation (id, descripcion) values (2, 'Abogado');
insert into Occupation (id, descripcion) values (3, 'Medico');
insert into Member (id, id_ocupacion, name, email, phone_number) values (0, 2, 'John Smith', 'john.smith@mailinator.com', '2125551212'); 
insert into Member (id, id_ocupacion, name, email, phone_number) values (1, 3, 'Carlos', 'carlos@mailinator.com', '2125551212');
