package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreCustodiaGarantia;

import javax.ejb.Local;

/**
 * PreCustodiaGarantiaBLLocal
 *
 * @author mcramos
 * 21/02/2025
 */
@Local
public interface PreCustodiaGarantiaBLLocal extends
        GenericBLLocal<PreCustodiaGarantia, Integer>{

    PreCustodiaGarantia obtenerPorCodDesembolso(Integer pCodDesembolso);

    Integer getEstadoCustodiaGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;
}
