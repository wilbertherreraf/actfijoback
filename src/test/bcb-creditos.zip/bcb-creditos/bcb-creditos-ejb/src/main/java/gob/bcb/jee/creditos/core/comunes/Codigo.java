package gob.bcb.jee.creditos.core.comunes;


public class Codigo {

	public static final String BCB = "900";

	public static final String SI = "S";
	public static final String NO = "N";

	public static final Integer PASSWORD = 1001;
	public static final Integer ESTADO = 1008;
	public static final Integer TIPO_USUARIO = 1003;
	public static final Integer TIPO_PERMISO = 1006;

	public static final Integer USUARIO_INTERNO = 1;
	public static final Integer USUARIO_EXTERNO = 2;

	public static final Integer PERMISO_DE_SISTEMA = 1;
	public static final String PERMISO_PROFILE = "0660";

	public static final Integer VIGENTE = 1;
	
}
