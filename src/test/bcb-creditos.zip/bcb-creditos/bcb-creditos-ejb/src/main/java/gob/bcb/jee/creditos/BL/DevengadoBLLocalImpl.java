package gob.bcb.jee.creditos.BL;

import java.util.Date;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import gob.bcb.jee.creditos.QL.DevengadoQLLocal;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.remoto
 * 13/09/2016 - 12:28 PM
 * Creado por aescobar
 */
@Stateless
@LocalBean
public class DevengadoBLLocalImpl implements DevengadoBLLocal {
    private static Logger log = Logger.getLogger(DevengadoBLLocalImpl.class);

    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    DevengadoQLLocal devengadoQLLocal;
    
    public void generarDevengadosTodos(Integer tipoproceso, Date fechaGeneracion)  throws Throwable {
    	devengadoQLLocal.generarDevengadosTodos(tipoproceso, fechaGeneracion);
    }

    @Override
    public void generarDevengados(Date fechaIni,Integer tipoproc, String coduser, String estacion) throws OperationException{
    	devengadoQLLocal.generarDevengados(fechaIni, tipoproc, coduser, estacion);
    }
    
    @Override
    public void cierreDevengados(Date fechaCierre, String coduser, String estacion) throws OperationException{
    	devengadoQLLocal.cierreDevengados(fechaCierre,  coduser, estacion);
    }
    
}
