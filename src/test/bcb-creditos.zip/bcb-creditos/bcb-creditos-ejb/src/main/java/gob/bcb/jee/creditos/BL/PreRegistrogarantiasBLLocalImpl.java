package gob.bcb.jee.creditos.BL;

import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PreCustodiaGarantiaQLLocal;
import gob.bcb.jee.creditos.QL.PreDesembolsoDetalleQLLocal;
import gob.bcb.jee.creditos.QL.PrePagocuotaQLLocal;
import gob.bcb.jee.creditos.QL.PrePrccontaQLLocal;
import gob.bcb.jee.creditos.QL.PreRegistrogarantiasQLLocal;
import gob.bcb.jee.creditos.QL.PreRetiroGarantiaQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PreRegistrogarantiasDao;
import gob.bcb.jee.creditos.entidades.PreRegistrogarantias;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreCustodiaGarantia;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;
import gob.bcb.jee.creditos.model.PreRetiroGarantia;
import gob.bcb.jee.creditos.util.Cttes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
@LocalBean
public class PreRegistrogarantiasBLLocalImpl extends
        GenericBLLocalImpl<PreRegistrogarantias, Integer> implements PreRegistrogarantiasBLLocal {
    private static final Logger log = LoggerFactory.getLogger(PrePrccontaBLLocalImpl.class);
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;

    @Inject
    PreRegistrogarantiasDao preRegistrogarantiasDao;
    @Inject
    private PreDesembolsoDetalleQLLocal preDesembolsoDetalleQLLocal;
    @Inject
    private PreRegistrogarantiasQLLocal preRegistrogarantiasQLLocal;
    @Inject
    private PreRetiroGarantiaQLLocal preRetiroGarantiaQLLocal;
    @Inject
    private PreCustodiaGarantiaQLLocal preCustodiaGarantiaQLLocal;
    @Inject
    private PrePrccontaQLLocal prePrccontaQLLocal;
    @Inject
    private PrePagocuotaQLLocal prePagocuotaQLLocal;

    @Override
    public void validar(PreRegistrogarantias entity) throws OperationException, EntityValidationException {

    }

    @Override
    public GenericQLLocal<PreRegistrogarantias, Integer> getQLBean() {
        return preRegistrogarantiasQLLocal;
    }

    @Override
    public GenericDao<PreRegistrogarantias, Integer> getGenericDao() {
        return preRegistrogarantiasDao;
    }

    @Override
    public List<Object[]> getParametrosGlosa(Integer tipoOperacion) throws OperationException {
        return preRegistrogarantiasQLLocal.getParametrosGlosa(tipoOperacion);
    }

    @Override
    public Integer getNumeroTotalDesembolso(Integer codcred, Integer codmod) throws OperationException {
        return preRegistrogarantiasQLLocal.getNumeroTotalDesembolso(codcred, codmod);
    }

    @Override
    public String getNumeroSerieGarantia(Integer codcred, Integer codmod, Integer coddsb) throws OperationException {
        return preRegistrogarantiasQLLocal.getNumeroSerieGarantia(codcred, codmod, coddsb);
    }

    @Override
    public Integer getEstadoGarantia(Integer codcred, Integer codmod, Integer coddsb) throws OperationException {
        return preRegistrogarantiasQLLocal.getEstadoGarantia(codcred, codmod, coddsb);
    }

    public PreDesembolsoDetalle generarCmpbDsbDet(PreDesembolsoDetalle desem, String usuario, String host) {
        PreDesembolsoDetalle dsbDet = preDesembolsoDetalleQLLocal.guardarDsbDetalle(desem);
        log.info("En generar comprobante dsb " , desem.getPdsCodcmp() + " tipo " + dsbDet.getId());        
        prePagocuotaQLLocal.generarOperContCred(dsbDet.getPdsCodcmp(), dsbDet.getId(), dsbDet.getCodcred(),
                dsbDet.getCodmod(), dsbDet.getDsbCoddsb().getDsbCoddsb(), dsbDet.getFecha(), null, usuario,
                host);        
        preRegistrogarantiasQLLocal.generarCmpbBonos(dsbDet.getId(), dsbDet.getPdsCodcmp(), dsbDet.getCodcred(),
                dsbDet.getCodmod(), dsbDet.getFecha(), dsbDet.getGlosaCoin(), usuario, host);
        return dsbDet;
    }

    public PreRegistrogarantias generarCmpbRegGar(PreRegistrogarantias desem, String usuario, String host) {
        PreRegistrogarantias dsbDet = preRegistrogarantiasQLLocal.guardarRegGar(desem);
        log.info("En generar comprobante reg garantia " , desem.getRggCodcmp() + " tipo " + dsbDet.getId());                
        prePagocuotaQLLocal.generarOperContCred(dsbDet.getRggCodcmp(), dsbDet.getId(), dsbDet.getCodcred(),
                dsbDet.getCodmod(), dsbDet.getCoddsb().getDsbCoddsb(), dsbDet.getFecha(), null, usuario,
                host);                
        preRegistrogarantiasQLLocal.generarCmpbBonos(dsbDet.getId(), dsbDet.getRggCodcmp(), dsbDet.getCodcred(),
                dsbDet.getCodmod(), dsbDet.getFecha(), dsbDet.getGlosaCoin(), usuario, host);
        return dsbDet;
    }
    public PreCustodiaGarantia generarCmpbCustGar(PreCustodiaGarantia desem, String usuario, String host) {

        PreCustodiaGarantia dsbDet = preCustodiaGarantiaQLLocal.guardarCustGar(desem);
        log.info("En generar comprobante custorida " , desem.getCugCodcmp() + " tipo " + dsbDet.getId());                        
        prePagocuotaQLLocal.generarOperContCred(dsbDet.getCugCodcmp(), dsbDet.getId(), dsbDet.getCodcred(),
                dsbDet.getCodmod(), dsbDet.getDsbCoddsb().getDsbCoddsb(), dsbDet.getFecha(), null, usuario,
                host);                        
        preRegistrogarantiasQLLocal.generarCmpbBonos(dsbDet.getId(), dsbDet.getCugCodcmp(), dsbDet.getCodcred(),
                dsbDet.getCodmod(), dsbDet.getFecha(), dsbDet.getGlosaCoin(), usuario, host);
        return dsbDet;
    }

    public PreRetiroGarantia generarCmpbRetGar(PreRetiroGarantia desem, String usuario, String host) {

        PreRetiroGarantia dsbDet = preRetiroGarantiaQLLocal.guardarRetGar(desem);
        log.info("En generar comprobante retiro garantia " , desem.getRtgCodcmp() + " tipo " + dsbDet.getId());                                
        prePagocuotaQLLocal.generarOperContCred(dsbDet.getRtgCodcmp(), dsbDet.getId(), dsbDet.getCodcred(),
                dsbDet.getCodmod(), dsbDet.getCoddsb().getDsbCoddsb(), dsbDet.getFecha(), null, usuario,
                host);                                
        preRegistrogarantiasQLLocal.generarCmpbBonos(dsbDet.getId(), dsbDet.getRtgCodcmp(), dsbDet.getCodcred(),
                dsbDet.getCodmod(), dsbDet.getFecha(), dsbDet.getGlosaCoin(), usuario, host);

        return dsbDet;
    }

    public boolean cambiarEstadoOperComprob(Integer idTable, Integer tipocmp, Integer codcred, Integer codmod,
            String estado, String usuario, String host) throws OperationException {
        Integer nvoEstado = Cttes.ESTOPER_PEND;
        if (estado.equals(Cttes.PREAUTORIZAR_COMPROBANTE_COIN)) {
            nvoEstado = Cttes.ESTOPER_PREAUTO;
        } else if (estado.equals(Cttes.AUTORIZAR_COMPROBANTE_COIN)) {
            nvoEstado = Cttes.ESTOPER_AUTO;
        } else if (estado.equals(Cttes.RECHAZAR_COMPROBANTE_COIN)) {
            nvoEstado = Cttes.ESTOPER_RECHAZADO;
        }

        prePrccontaQLLocal.cambiarEstadoOperComprob(tipocmp, idTable, codcred, codmod, null, null, nvoEstado, usuario,
                estado);
        return true;
    }

    @Override
    public Integer verificarRegistroTransitorioGarantias(Integer codcred, Integer codmod, Integer coddsb)
            throws OperationException {
        return preRegistrogarantiasQLLocal.verificarRegistroTransitorioGarantias(codcred, codmod, coddsb);
    }

    @Override
    public PreRegistrogarantias obtenerPorCodDesembolso(Integer pCodDesembolso) {
        return preRegistrogarantiasQLLocal.obtenerPorCodDesembolso(pCodDesembolso);
    }

}
