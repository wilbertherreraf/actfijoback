package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Normativa;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * 
 * Implementacion de los metodos de consulta (QL) para la entidad Normativa
 * 
 * 
 * @author ysalinas
 * 
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class NormativaQLLocalImpl extends
    GenericQLLocalImpl<Normativa, Integer> implements
    NormativaQLLocal
{
  @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
  private EntityManager entityManager;

  /*
   * (non-Javadoc)
   * @see gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager ()
   */
  @Override
  protected EntityManager entityManager()
  {
    return entityManager;
  }

}
