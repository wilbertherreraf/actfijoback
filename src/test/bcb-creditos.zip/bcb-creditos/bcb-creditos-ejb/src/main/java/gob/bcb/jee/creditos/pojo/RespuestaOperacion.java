package gob.bcb.jee.creditos.pojo;

import lombok.Data;

import java.io.Serializable;

/**
 * RespuestaOperacion
 *
 * @author mcramos
 * 15/01/2025
 */
@Data
public class RespuestaOperacion implements Serializable {
    private boolean esValid;
    private String mensaje;
}
