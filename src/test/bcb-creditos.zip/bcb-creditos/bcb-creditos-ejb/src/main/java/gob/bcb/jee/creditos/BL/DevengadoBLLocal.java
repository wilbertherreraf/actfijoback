package gob.bcb.jee.creditos.BL;

import java.util.Date;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;


@Local
public interface DevengadoBLLocal {

    void generarDevengados(Date fechaIni,Integer tipoproc, String coduser, String estacion) throws OperationException;
        
    void cierreDevengados(Date fechaCierre, String coduser, String estacion) throws OperationException;

    void generarDevengadosTodos(Integer tipoproceso, Date fechaGeneracion) throws Throwable;
}