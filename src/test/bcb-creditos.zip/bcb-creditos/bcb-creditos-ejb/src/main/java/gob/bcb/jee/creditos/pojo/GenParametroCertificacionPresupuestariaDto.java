package gob.bcb.jee.creditos.pojo;

import gob.bcb.jee.creditos.entidades.GenParametro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * GenParametroCertificacionPresupuestariaDto
 *
 * @author mcramos
 * 15/01/2025
 */
@Getter
@Setter
@NoArgsConstructor
public class GenParametroCertificacionPresupuestariaDto implements Serializable {
    private GenParametro gestionAnterior = new GenParametro();
    private GenParametro gestionActual = new GenParametro();
    private GenParametro nomCortoCredito = new GenParametro();
}
