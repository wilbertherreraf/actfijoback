/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-web
 * gob.bcb.jee.creditos.jee.mse.web.util.ClockView
 * 17/11/2015 - 15:11:13
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import lombok.Getter;
import lombok.Setter;

/**
 * Clase que controla el reloj a mostrar en pantalla
 * 
 * 
 * @author ysalinas
 * 
 */
@Getter
@Setter
public class ClockView implements Runnable
{
  private static final long serialVersionUID = 1L;

  
  // Variables globales
  String hora, minutos, segundos, ampm;
  Calendar calendario;
  Thread h1;

  public String horaCapturada;

  public ClockView()
  {
    Log.Info("entra al constructor ");
    h1 = null;
    h1 = new Thread(this, "ClockView");
  }

  /**
   * Metodo q inicia el reloj.
   */
  public void clockStart()
  {
    h1.start();
  }

  /**
   * Metodo q finaliza el reloj.
   */
  public void clockStop()
  {
    h1 = null;
  }

  @Override
  public void run()
  {
	  Log.Info("entra a run");
    Thread ct = Thread.currentThread();
    while (ct == h1)
    {
      calculaHora();
      horaCapturada = hora + ":" + minutos + ":" + segundos + " " + ampm;
      Log.Info("LA HORA ES--------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + horaCapturada);
      try
      {
        Thread.sleep(1000);
      }
      catch (InterruptedException e)
      {
      }
    }
  }

  public void calculaHora()
  {

    Calendar calendario = new GregorianCalendar();
    Date fechaHoraActual = new Date();

    calendario.setTime(fechaHoraActual);

    ampm = calendario.get(Calendar.AM_PM) == Calendar.AM ? "AM" : "PM";

    if (ampm.equals("PM"))
    {
      int h = calendario.get(Calendar.HOUR_OF_DAY) - 12;
      hora = h > 9 ? "" + h : "0" + h;
    }
    else
    {
      hora = calendario.get(Calendar.HOUR_OF_DAY) > 9 ? "" + calendario.get(Calendar.HOUR_OF_DAY) : "0" + calendario.get(Calendar.HOUR_OF_DAY);
    }

    minutos = calendario.get(Calendar.MINUTE) > 9 ? "" + calendario.get(Calendar.MINUTE) : "0" + calendario.get(Calendar.MINUTE);
    segundos = calendario.get(Calendar.SECOND) > 9 ? "" + calendario.get(Calendar.SECOND) : "0" + calendario.get(Calendar.SECOND);

  }

}
