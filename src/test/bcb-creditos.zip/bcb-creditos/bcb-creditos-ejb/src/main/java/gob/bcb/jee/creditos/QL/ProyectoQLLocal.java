/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.ProyectoQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Proyecto;
import gob.bcb.jee.creditos.numeradores.Estado;

import javax.ejb.Local;
import java.util.List;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Proyecto
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface ProyectoQLLocal extends
    GenericQLLocal<Proyecto, Long>
{

   // List<Proyecto> searchByParams(Long empresaId, String codProyecto, String proyecto, Estado estado);
}
