package gob.bcb.jee.creditos.pojo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * GenParametroDto
 *
 * @author mcramos
 * 15/01/2025
 */
@Getter
@Setter
@NoArgsConstructor
public class GenParametroDto implements Serializable {
    private GenParametroDesembolsoDto genParametroDesembolsoDto = new GenParametroDesembolsoDto();
    private GenParametroRegTransitorioBonoDto genParametroRegTransitorioBonoDto = new GenParametroRegTransitorioBonoDto();
    private GenParametroDevengadoIntDto genParametroDevengadoIntDto = new GenParametroDevengadoIntDto();
    private GenParametroIngCustodiaBonoTesoreriaDto genParametroIngCustodiaBonoTesoreriaDto = new GenParametroIngCustodiaBonoTesoreriaDto();
    private GenParametroAmortizacionCapitalDto genParametroAmortizacionCapitalDto = new GenParametroAmortizacionCapitalDto();
    private GenParametroRetiroBonoTesoreriaDto genParametroRetiroBonoTesoreriaDto = new GenParametroRetiroBonoTesoreriaDto();
    private GenParametroPagoInteresDto genParametroPagoInteresDto = new GenParametroPagoInteresDto();
    private GenParametroCertificacionPresupuestariaDto genParametroCertificacionPresupuestariaDto = new GenParametroCertificacionPresupuestariaDto();
    private GenParametroUtilEscritorioDto genParametroUtilEscritorioDto = new GenParametroUtilEscritorioDto();
}
