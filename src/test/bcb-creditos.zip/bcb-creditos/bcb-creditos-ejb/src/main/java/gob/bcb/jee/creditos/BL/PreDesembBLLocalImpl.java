/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PreDesembQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PreDesembDao;
import gob.bcb.jee.creditos.entidades.EstadoDesembolsosQuery;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class PreDesembBLLocalImpl extends GenericBLLocalImpl<PreDesemb, Integer> implements PreDesembBLLocal {

	@PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
	EntityManager em;
	/*
	 * Inyeccion de los metodos para consulta (QL)
	 */
	@Inject
	PreDesembQLLocal preDesembQLLocal;

	@Inject
	PreDesembDao parametroDao;

	@Override
	public GenericQLLocal<PreDesemb, Integer> getQLBean() {
		return preDesembQLLocal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
	 */
	@Override
	public GenericDao<PreDesemb, Integer> getGenericDao() {
		return parametroDao;
	}

	@Override
	public void validar(PreDesemb entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub

	}

	@Override
	public Integer getIdNewId() throws OperationException {
		int valorMaximo = preDesembQLLocal.getNewId();
		return valorMaximo;
	}

	@Override
	public BigDecimal getDisponibleDesembolso(Integer codcred, Integer codmod) throws OperationException {
		return preDesembQLLocal.getDisponibleDesembolso(codcred, codmod);
	}

	@Override
	public Integer generarPlanDePagosDsb(Integer p_codcred, Integer p_codmod, Integer p_coddsb, Integer p_codmodtmp,
			String usuario, String ip) throws OperationException {
		return preDesembQLLocal.generarPlanDePagosDsb(p_codcred, p_codmod, p_coddsb, p_codmodtmp, usuario, ip);

	}

	@Override
	public void aprobarPlanDePagos(Integer p_codcred, Integer p_codmod, Integer p_coddsb, Integer p_codmodtmp,
			String cod_user, String ip) throws OperationException {
		preDesembQLLocal.autorizarPlanDePagos(p_codcred, p_codmod, p_coddsb, p_codmodtmp, cod_user, ip);

	}

	@Override
	public void aprobarDesembolso(Integer p_codcred, Integer p_codmod, Integer p_coddsb, Date fecha, Date fechaOpera,
			Integer accion,
			String cod_user, String estacion) throws OperationException {
		preDesembQLLocal.aprobarDesembolso(p_codcred, p_codmod, p_coddsb, fecha, fechaOpera, accion,
				cod_user, estacion);
	}

	@Override
	public void eliminarDesembolso(Integer p_coddsb, String cod_user, String estacion) throws OperationException {
		preDesembQLLocal.eliminarDesembolso(p_coddsb, cod_user, estacion);
	}

	@Override
	public Integer obtenerCodClientePorCodDesembolso(Integer pCodDesembolso) {
		return preDesembQLLocal.obtenerCodClientePorCodDesembolso(pCodDesembolso);
	}

	public List<EstadoDesembolsosQuery> estadoDesembolsosAFecha(Integer codcred, Integer codmod, Integer coddsb,
			Date fechaVencimiento) {
		return preDesembQLLocal.estadoDesembolsosAFecha(codcred, codmod, coddsb, fechaVencimiento);
	}

	public BigDecimal devengadoPorCredAFech(Date fechaVencimiento) {
		return preDesembQLLocal.devengadoPorCredAFech(fechaVencimiento);
	}

	public PreDesemb getByCoddsb(Integer coddsb) {
		return preDesembQLLocal.getByCoddsb(coddsb);
	}

	public List<PreDesemb> dsbByCodCred(Integer codcred, Integer codmod) {
		return preDesembQLLocal.dsbByCodCred(codcred, codmod);
	}

	public static EstadoDesembolsosQuery initEstDsb() {
		EstadoDesembolsosQuery resultado = new EstadoDesembolsosQuery();

		// Inicializar BigDecimal a 0 para evitar NullPointerException
		resultado.setMontoDesemb(BigDecimal.ZERO);
		resultado.setDesembolsado(BigDecimal.ZERO);
		resultado.setIntDevengado(BigDecimal.ZERO);
		resultado.setIntPeriodo(BigDecimal.ZERO);
		resultado.setIntContab(BigDecimal.ZERO);
		resultado.setCapAmortizado(BigDecimal.ZERO);
		resultado.setSaldoCap(BigDecimal.ZERO);
		resultado.setCapitalVenc(BigDecimal.ZERO);
		resultado.setInteresVenc(BigDecimal.ZERO);
		resultado.setMntInt31dic(BigDecimal.ZERO);
		resultado.setCapDifeAntVenc(BigDecimal.ZERO);
		resultado.setCapDifeVenc(BigDecimal.ZERO);
		resultado.setCapDifeCob(BigDecimal.ZERO);
		resultado.setCapPantiAntVcto(BigDecimal.ZERO);
		resultado.setIntPantiAntVcto(BigDecimal.ZERO);
		resultado.setCapPantiVcto(BigDecimal.ZERO);
		resultado.setIntPantiVcto(BigDecimal.ZERO);
		resultado.setIntAl31dic(BigDecimal.ZERO);
		resultado.setIntAlfechavcto(BigDecimal.ZERO);
		resultado.setIntCuota(BigDecimal.ZERO);
		resultado.setCapCuota(BigDecimal.ZERO);
		resultado.setAcrCapitalper(BigDecimal.ZERO);
		resultado.setAcrInteresper(BigDecimal.ZERO);
		resultado.setAcrUndsb(BigDecimal.ZERO);
		resultado.setDiasDeven(0);
		resultado.setCoddsb(0); // cantidad de registros
		return resultado;
	}

	public static EstadoDesembolsosQuery sumarConStreams(List<EstadoDesembolsosQuery> lista) {
		if (lista == null || lista.isEmpty()) {
			return initEstDsb();
		}

		EstadoDesembolsosQuery resultado = initEstDsb();

		// Sumarizar valores BigDecimal usando streams
		resultado.setMontoDesemb(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getMontoDesemb));
		resultado.setDesembolsado(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getDesembolsado));
		resultado.setIntDevengado(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getIntDevengado));
		resultado.setIntPeriodo(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getIntPeriodo));
		resultado.setIntContab(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getIntContab));
		resultado.setCapAmortizado(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getCapAmortizado));
		resultado.setSaldoCap(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getSaldoCap));
		resultado.setCapitalVenc(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getCapitalVenc));
		resultado.setInteresVenc(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getInteresVenc));
		resultado.setMntInt31dic(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getMntInt31dic));
		resultado.setCapDifeAntVenc(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getCapDifeAntVenc));
		resultado.setCapDifeVenc(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getCapDifeVenc));
		resultado.setCapDifeCob(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getCapDifeCob));
		resultado.setCapPantiAntVcto(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getCapPantiAntVcto));
		resultado.setIntPantiAntVcto(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getIntPantiAntVcto));
		resultado.setCapPantiVcto(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getCapPantiVcto));
		resultado.setIntPantiVcto(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getIntPantiVcto));
		resultado.setIntAl31dic(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getIntAl31dic));
		resultado.setIntAlfechavcto(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getIntAlfechavcto));
		resultado.setIntCuota(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getIntCuota));
		resultado.setCapCuota(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getCapCuota));
		resultado.setAcrCapitalper(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getAcrCapitalper));
		resultado.setAcrInteresper(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getAcrInteresper));
		resultado.setAcrUndsb(summarizeBigDecimal(lista, EstadoDesembolsosQuery::getAcrUndsb));

		resultado.setDiasDeven(lista.get(0).getDiasDeven());
		resultado.setCoddsb(lista.size());

		EstadoDesembolsosQuery primerElemento = lista.get(0);
		resultado.setAcrCodacr(primerElemento.getAcrCodacr());
		resultado.setCodcred(primerElemento.getCodcred());
		resultado.setCodmod(primerElemento.getCodmod());
		resultado.setFecha(primerElemento.getFecha());
		resultado.setFecDesemb(primerElemento.getFecDesemb());
		resultado.setNrodoc(primerElemento.getNrodoc());
		resultado.setCodcli(primerElemento.getCodcli());
		resultado.setFec31dicant(primerElemento.getFec31dicant());
		resultado.setFec1roene(primerElemento.getFec1roene());
		resultado.setFecUltvenc(primerElemento.getFecUltvenc());
		resultado.setFecUltdevCont(primerElemento.getFecUltdevCont());
		resultado.setFecUltActiv(primerElemento.getFecUltActiv());
		resultado.setFecIniTramo2(primerElemento.getFecIniTramo2());
		resultado.setTasavig(primerElemento.getTasavig());
		resultado.setAcrFecini(primerElemento.getAcrFecini());
		resultado.setAcrFecfin(primerElemento.getAcrFecfin());

		return resultado;
	}

	public static BigDecimal summarizeBigDecimal(List<EstadoDesembolsosQuery> lista,
			Function<EstadoDesembolsosQuery, BigDecimal> extractor) {
		return lista.stream()
				.map(extractor)
				.filter(Objects::nonNull)
				.reduce(BigDecimal.ZERO, BigDecimal::add);
	}

}
