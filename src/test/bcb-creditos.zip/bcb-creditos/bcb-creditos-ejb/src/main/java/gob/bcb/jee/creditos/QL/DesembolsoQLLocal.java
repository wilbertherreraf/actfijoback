package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Desembolso;

import javax.ejb.Remote;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.negocioQL
 * 01/08/2016 - 12:49 PM
 * Creado por aescobar
 */
@Remote
public interface DesembolsoQLLocal extends
        GenericQLLocal<Desembolso, Long> {

}