/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.CliPersonaQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.dao.CliPersonaDao;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class CliPersonaBLLocalImpl extends
        GenericBLLocalImpl<CliPersona, Integer>
        implements CliPersonaBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    CliPersonaQLLocal parametrosQLLocal;

    @Inject
    CliPersonaDao parametroDao;

    @Override
    public GenericQLLocal<CliPersona, Integer> getQLBean() {
        return parametrosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<CliPersona, Integer> getGenericDao() {
        return parametroDao;
    }

	@Override
	public void validar(CliPersona entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Integer getIdNewId() throws OperationException{
		int valorMaximo=parametrosQLLocal.getIdNewId();
		return valorMaximo;
	}

    @Override
    public String obtenerInstitucion(Integer institucion) throws OperationException {
        return parametrosQLLocal.obtenerInstitucion(institucion);
    }

}

