package gob.bcb.jee.creditos.entidades;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import gob.bcb.jee.creditos.model.PreDesemb;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "pre_registrogarantias")
@Getter
@Setter
@NamedQueries({
        @NamedQuery(name = "PreRegistrogarantias.findAll", query = "SELECT p FROM PreRegistrogarantias p"),
        @NamedQuery(name = "PreRegistrogarantias.findById", query = "SELECT p FROM PreRegistrogarantias p WHERE p.id = :id")})
public class PreRegistrogarantias extends EntidadAutorizable<Integer> implements
        Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    @Column(name = "id")
    private Integer id;

    @Column(name = "codcred")
    private Integer codcred;
    
    @Column(name = "codmod")
    private Integer codmod;

    @Temporal(TemporalType.DATE)
    @Column(name="fecha")
    private Date fecha;

    @Column(name = "valor_total_garantia")
    private BigDecimal valorTotalGarantia;
    
    @Column(name = "nota_solicitud")
    private String notaSolicitud;
    
    @Column(name = "numero_tramite")
    private String numeroTramite;
    
    @Column(name = "cantidad_bonos")
    private Integer cantidadBonos;
    
    @Column(name = "numero_desembolso")
    private Integer numeroDesembolso;
    
    @Column(name = "cve_tipo_comprob")
    private String cveTipoComprob;
        
    @Column(name = "estado")
    private Integer estado;

    @Column(name = "rgg_codcmp")
    private Integer rggCodcmp;

    @Column(name = "nro_comprobante_coin")
    private String nroComprobanteCoin;

    @Column(name = "glosa_coin")
    private String glosaCoin;
    @Column(name = "cambio_bd")
    private String cambioBd;

    @Column(name = "audit_usuario")
    private String auditUsuario;
    @Column(name = "audit_fechahora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahora;
    @Column(name = "audit_host")
    private String auditHost;

    @Column(name = "audit_usuario_genera")
    private String auditUsuarioGenera;
    @Column(name = "audit_fechahora_genera")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraGenera;
    @Column(name = "audit_host_genera")
    private String auditHostGenera;

    @Column(name = "audit_usuario_preautoriza")
    private String auditUsuarioPreautoriza;
    @Column(name = "audit_fechahora_preautoriza")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraPreautoriza;
    @Column(name = "audit_host_preautoriza")
    private String auditHostPreautoriza;

    @Column(name = "audit_usuario_autoriza")
    private String auditUsuarioAutoriza;
    @Column(name = "audit_fechahora_autoriza")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraAutoriza;
    @Column(name = "audit_host_autoriza")
    private String auditHostAutoriza;

    @JoinColumn(name = "coddsb", referencedColumnName = "dsb_coddsb")
    @ManyToOne(optional = false)
    private PreDesemb coddsb;
}
