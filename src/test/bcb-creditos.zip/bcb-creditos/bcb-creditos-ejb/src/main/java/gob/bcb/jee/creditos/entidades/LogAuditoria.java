/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.entidades.LogAuditoria
 * 21/03/2016 - 10:44:24
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Clase para la entidad LogAuditoria
 *
 * @author ysalinas
 * Modificado: aescobar 27/06/2016 - 18:21:30
 */
@Entity
@Table(name = "LOG_AUDITORIA")
@Getter
@Setter
public class LogAuditoria extends Entidad<Integer> implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LOG_AUDITORIA_ID", updatable = false)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "COD_TRANSACCION", nullable = false)
    private TransaccionAuditoria transaccionAuditoria;

    @Column(name = "COD_USUARIO", nullable = true, length = 50)
    private String codUsuario;

    @Column(name = "ESTACION", nullable = true, length = 50)
    private String estacion;

    @Column(name = "FECHA_HORA", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;

    @Column(name = "LOG_ANTERIOR")
    private Integer logAnteriorId;

    public LogAuditoria() {
        super();
    }

    @Override
    public String toString() {
        return "LogAuditoria{" +
                "id=" + id +
                ", transaccionAuditoria=" + transaccionAuditoria +
                ", codUsuario='" + codUsuario + '\'' +
                ", estacion='" + estacion + '\'' +
                ", fechaHora=" + fechaHora +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LogAuditoria that = (LogAuditoria) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (transaccionAuditoria != null ? !transaccionAuditoria.equals(that.transaccionAuditoria) : that.transaccionAuditoria != null)
            return false;
        if (codUsuario != null ? !codUsuario.equals(that.codUsuario) : that.codUsuario != null) return false;
        if (estacion != null ? !estacion.equals(that.estacion) : that.estacion != null) return false;
        return !(fechaHora != null ? !fechaHora.equals(that.fechaHora) : that.fechaHora != null);

    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (transaccionAuditoria != null ? transaccionAuditoria.hashCode() : 0);
        result = 31 * result + (codUsuario != null ? codUsuario.hashCode() : 0);
        result = 31 * result + (estacion != null ? estacion.hashCode() : 0);
        result = 31 * result + (fechaHora != null ? fechaHora.hashCode() : 0);
        return result;
    }
}
