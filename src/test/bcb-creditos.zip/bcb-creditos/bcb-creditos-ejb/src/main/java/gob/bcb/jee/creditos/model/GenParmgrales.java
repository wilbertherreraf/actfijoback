package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the gen_parmgrales database table.
 * 
 */
@Entity
@Table(name="gen_parmgrales")
@NamedQuery(name="GenParmgrales.findAll", query="SELECT g FROM GenParmgrales g")
public class GenParmgrales implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="pge_codmod")
	private Integer pgeCodmod;

	@Column(name="pge_acrdoc")
	private String pgeAcrdoc;

	@Column(name="pge_auditfho")
	private Timestamp pgeAuditfho;

	@Column(name="pge_audittrx")
	private String pgeAudittrx;

	@Column(name="pge_auditusr")
	private String pgeAuditusr;

	@Column(name="pge_auditwst")
	private String pgeAuditwst;

	@Column(name="pge_cargme")
	private Integer pgeCargme;

	@Column(name="pge_cargmn")
	private Integer pgeCargmn;

	@Column(name="pge_cargufv")
	private Integer pgeCargufv;

	@Column(name="pge_codbco")
	private String pgeCodbco;

	@Column(name="pge_codofi")
	private Integer pgeCodofi;

	@Column(name="pge_codsuc")
	private Integer pgeCodsuc;

	@Column(name="pge_ctaacre")
	private String pgeCtaacre;

	@Column(name="pge_ctadeu")
	private String pgeCtadeu;

	@Column(name="pge_ctent")
	private String pgeCtent;

	@Column(name="pge_difcambio")
	private String pgeDifcambio;

	@Column(name="pge_doccomp")
	private String pgeDoccomp;

	@Temporal(TemporalType.DATE)
	@Column(name="pge_feccieant")
	private Date pgeFeccieant;

	@Temporal(TemporalType.DATE)
	@Column(name="pge_feccierre")
	private Date pgeFeccierre;

	@Temporal(TemporalType.DATE)
	@Column(name="pge_feccorte")
	private Date pgeFeccorte;

	@Temporal(TemporalType.DATE)
	@Column(name="pge_fecultrep")
	private Date pgeFecultrep;

	@Column(name="pge_fecvalor")
	private String pgeFecvalor;

	@Column(name="pge_gestion")
	private Integer pgeGestion;

	@Column(name="pge_nroasien")
	private Integer pgeNroasien;

	@Column(name="pge_penaldia")
	private String pgePenaldia;

	@Column(name="pge_repro")
	private String pgeRepro;

	@Column(name="pge_sigla")
	private String pgeSigla;

	public GenParmgrales() {
	}

	public Integer getPgeCodmod() {
		return this.pgeCodmod;
	}

	public void setPgeCodmod(Integer pgeCodmod) {
		this.pgeCodmod = pgeCodmod;
	}

	public String getPgeAcrdoc() {
		return this.pgeAcrdoc;
	}

	public void setPgeAcrdoc(String pgeAcrdoc) {
		this.pgeAcrdoc = pgeAcrdoc;
	}

	public Timestamp getPgeAuditfho() {
		return this.pgeAuditfho;
	}

	public void setPgeAuditfho(Timestamp pgeAuditfho) {
		this.pgeAuditfho = pgeAuditfho;
	}

	public String getPgeAudittrx() {
		return this.pgeAudittrx;
	}

	public void setPgeAudittrx(String pgeAudittrx) {
		this.pgeAudittrx = pgeAudittrx;
	}

	public String getPgeAuditusr() {
		return this.pgeAuditusr;
	}

	public void setPgeAuditusr(String pgeAuditusr) {
		this.pgeAuditusr = pgeAuditusr;
	}

	public String getPgeAuditwst() {
		return this.pgeAuditwst;
	}

	public void setPgeAuditwst(String pgeAuditwst) {
		this.pgeAuditwst = pgeAuditwst;
	}

	public Integer getPgeCargme() {
		return this.pgeCargme;
	}

	public void setPgeCargme(Integer pgeCargme) {
		this.pgeCargme = pgeCargme;
	}

	public Integer getPgeCargmn() {
		return this.pgeCargmn;
	}

	public void setPgeCargmn(Integer pgeCargmn) {
		this.pgeCargmn = pgeCargmn;
	}

	public Integer getPgeCargufv() {
		return this.pgeCargufv;
	}

	public void setPgeCargufv(Integer pgeCargufv) {
		this.pgeCargufv = pgeCargufv;
	}

	public String getPgeCodbco() {
		return this.pgeCodbco;
	}

	public void setPgeCodbco(String pgeCodbco) {
		this.pgeCodbco = pgeCodbco;
	}

	public Integer getPgeCodofi() {
		return this.pgeCodofi;
	}

	public void setPgeCodofi(Integer pgeCodofi) {
		this.pgeCodofi = pgeCodofi;
	}

	public Integer getPgeCodsuc() {
		return this.pgeCodsuc;
	}

	public void setPgeCodsuc(Integer pgeCodsuc) {
		this.pgeCodsuc = pgeCodsuc;
	}

	public String getPgeCtaacre() {
		return this.pgeCtaacre;
	}

	public void setPgeCtaacre(String pgeCtaacre) {
		this.pgeCtaacre = pgeCtaacre;
	}

	public String getPgeCtadeu() {
		return this.pgeCtadeu;
	}

	public void setPgeCtadeu(String pgeCtadeu) {
		this.pgeCtadeu = pgeCtadeu;
	}

	public String getPgeCtent() {
		return this.pgeCtent;
	}

	public void setPgeCtent(String pgeCtent) {
		this.pgeCtent = pgeCtent;
	}

	public String getPgeDifcambio() {
		return this.pgeDifcambio;
	}

	public void setPgeDifcambio(String pgeDifcambio) {
		this.pgeDifcambio = pgeDifcambio;
	}

	public String getPgeDoccomp() {
		return this.pgeDoccomp;
	}

	public void setPgeDoccomp(String pgeDoccomp) {
		this.pgeDoccomp = pgeDoccomp;
	}

	public Date getPgeFeccieant() {
		return this.pgeFeccieant;
	}

	public void setPgeFeccieant(Date pgeFeccieant) {
		this.pgeFeccieant = pgeFeccieant;
	}

	public Date getPgeFeccierre() {
		return this.pgeFeccierre;
	}

	public void setPgeFeccierre(Date pgeFeccierre) {
		this.pgeFeccierre = pgeFeccierre;
	}

	public Date getPgeFeccorte() {
		return this.pgeFeccorte;
	}

	public void setPgeFeccorte(Date pgeFeccorte) {
		this.pgeFeccorte = pgeFeccorte;
	}

	public Date getPgeFecultrep() {
		return this.pgeFecultrep;
	}

	public void setPgeFecultrep(Date pgeFecultrep) {
		this.pgeFecultrep = pgeFecultrep;
	}

	public String getPgeFecvalor() {
		return this.pgeFecvalor;
	}

	public void setPgeFecvalor(String pgeFecvalor) {
		this.pgeFecvalor = pgeFecvalor;
	}

	public Integer getPgeGestion() {
		return this.pgeGestion;
	}

	public void setPgeGestion(Integer pgeGestion) {
		this.pgeGestion = pgeGestion;
	}

	public Integer getPgeNroasien() {
		return this.pgeNroasien;
	}

	public void setPgeNroasien(Integer pgeNroasien) {
		this.pgeNroasien = pgeNroasien;
	}

	public String getPgePenaldia() {
		return this.pgePenaldia;
	}

	public void setPgePenaldia(String pgePenaldia) {
		this.pgePenaldia = pgePenaldia;
	}

	public String getPgeRepro() {
		return this.pgeRepro;
	}

	public void setPgeRepro(String pgeRepro) {
		this.pgeRepro = pgeRepro;
	}

	public String getPgeSigla() {
		return this.pgeSigla;
	}

	public void setPgeSigla(String pgeSigla) {
		this.pgeSigla = pgeSigla;
	}

}
