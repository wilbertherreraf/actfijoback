package gob.bcb.jee.creditos.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity

public class EstadoDesembolsosQuery implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "acr_codacr")
    private Integer acrCodacr;

    @Column(name = "codcred")
    private Integer codcred;;
    @Column(name = "codmod")
    private Integer codmod;
    @Column(name = "coddsb")
    private Integer coddsb;
    @Temporal(TemporalType.DATE)
    @Column(name = "fecha")
    private Date fecha;
    @Temporal(TemporalType.DATE)
    @Column(name = "fec_desemb")
    private Date fecDesemb;
    @Column(name = "monto_desemb")
    private BigDecimal montoDesemb;
    @Column(name = "desembolsado")
    private BigDecimal desembolsado;
    @Column(name = "nrodoc")
    private String nrodoc;
    @Column(name = "codcli")
    private Integer codcli;
    @Temporal(TemporalType.DATE)
    @Column(name = "fec_31dicant")
    private Date fec31dicant;
    @Temporal(TemporalType.DATE)
    @Column(name = "fec_1roene")
    private Date fec1roene;
    @Temporal(TemporalType.DATE)
    @Column(name = "fec_ultvenc")
    private Date fecUltvenc;
    @Temporal(TemporalType.DATE)
    @Column(name = "fec_ultdev_cont")
    private Date fecUltdevCont;
    @Temporal(TemporalType.DATE)
    @Column(name = "fec_ult_activ")
    private Date fecUltActiv;
    @Temporal(TemporalType.DATE)
    @Column(name = "fec_ini_tramo2")
    private Date fecIniTramo2;
    @Column(name = "tasavig")
    private BigDecimal tasavig;
    @Column(name = "dias_deven")
    private Integer diasDeven;
    @Column(name = "int_devengado")
    private BigDecimal intDevengado;
    @Column(name = "int_periodo")
    private BigDecimal intPeriodo;
    @Column(name = "int_contab")
    private BigDecimal intContab;
    @Column(name = "cap_amortizado")
    private BigDecimal capAmortizado;
    @Column(name = "saldo_cap")
    private BigDecimal saldoCap;
    @Column(name = "capital_venc")
    private BigDecimal capitalVenc;
    @Column(name = "interes_venc")
    private BigDecimal interesVenc;
    @Column(name = "mnt_int31dic")
    private BigDecimal mntInt31dic;
    @Column(name = "cap_dife_ant_venc")
    private BigDecimal capDifeAntVenc;
    @Column(name = "cap_dife_venc")
    private BigDecimal capDifeVenc;
    @Column(name = "cap_dife_cob")
    private BigDecimal capDifeCob;
    @Column(name = "cap_panti_ant_vcto")
    private BigDecimal capPantiAntVcto;
    @Column(name = "int_panti_ant_vcto")
    private BigDecimal intPantiAntVcto;
    @Column(name = "cap_panti_vcto")
    private BigDecimal capPantiVcto;
    @Column(name = "int_panti_vcto")
    private BigDecimal intPantiVcto;
    @Column(name = "int_al31dic")
    private BigDecimal intAl31dic;
    @Column(name = "int_alfechavcto")
    private BigDecimal intAlfechavcto;
    @Column(name = "int_cuota")
    private BigDecimal intCuota;
    @Column(name = "cap_cuota")
    private BigDecimal capCuota;
    @Temporal(TemporalType.DATE)
    @Column(name = "acr_fecini")
    private Date acrFecini;
    @Temporal(TemporalType.DATE)
    @Column(name = "acr_fecfin")
    private Date acrFecfin;
    @Column(name = "acr_capitalper")
    private BigDecimal acrCapitalper;
    @Column(name = "acr_interesper")
    private BigDecimal acrInteresper;
    @Column(name = "acr_undsb")
    private BigDecimal acrUndsb;
    @Column(name = "acr_tipoacr")
    private Integer acrTipoacr;

    @Transient
    List<PrePagocuota> cuotasLista = new ArrayList<>();
}
