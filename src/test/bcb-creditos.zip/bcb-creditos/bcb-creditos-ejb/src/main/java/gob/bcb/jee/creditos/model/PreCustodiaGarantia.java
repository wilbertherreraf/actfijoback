package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

/**
 * PreCustodiaGarantia
 *
 * @author mcramos
 * 21/02/2025
 */
@Entity
@Table(name = "pre_custodia_garantia")
@Getter
@Setter
@NamedQueries({
        @NamedQuery(name = "PreCustodiaGarantia.findAll", query = "SELECT p FROM PreCustodiaGarantia p"),
        @NamedQuery(name = "PreCustodiaGarantia.findById", query = "SELECT p FROM PreCustodiaGarantia p WHERE p.id = :id")
})
public class PreCustodiaGarantia extends EntidadAutorizable<Integer> implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    @Column(name = "id")
    private Integer id;

    
    @Column(name = "codcred")
    private Integer codcred;

    
    @Column(name = "codmod")
    private Integer codmod;

    
    @Column(name = "fecha")
    @Temporal(TemporalType.DATE)
    private Date fecha;

    @Column(name = "valor_total_garantia")
    private BigDecimal valorTotalGarantia;

    
    @Column(name = "acta_deposito")
    private String actaDeposito;

    @Column(name = "cug_codcmp")
    private Integer cugCodcmp;

    
    @Column(name = "estado")
    private Integer estado;

    @Column(name = "cve_tipo_comprob")
    private String cveTipoComprob;
        
    @Column(name = "nro_comprobante_coin")
    private String nroComprobanteCoin;

    @Column(name = "glosa_coin")
    private String glosaCoin;

    @Column(name = "glosa_debe")
    private String glosaDebe;

    @Column(name = "glosa_haber")
    private String glosaHaber;

    @Column(name = "cambio_bd")
    private String cambioBd;

    @Column(name = "audit_usuario")
    private String auditUsuario;

    @Column(name = "audit_fechahora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahora;

    @Column(name = "audit_host")
    private String auditHost;

    @Column(name = "audit_usuario_genera")
    private String auditUsuarioGenera;

    @Column(name = "audit_fechahora_genera")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraGenera;

    @Column(name = "audit_host_genera")
    private String auditHostGenera;

    @Column(name = "audit_usuario_preautoriza")
    private String auditUsuarioPreautoriza;

    @Column(name = "audit_fechahora_preautoriza")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraPreautoriza;

    @Column(name = "audit_host_preautoriza")
    private String auditHostPreautoriza;

    @Column(name = "audit_usuario_autoriza")
    private String auditUsuarioAutoriza;

    @Column(name = "audit_fechahora_autoriza")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraAutoriza;

    @Column(name = "audit_host_autoriza")
    private String auditHostAutoriza;

    @JoinColumn(name = "dsb_coddsb", referencedColumnName = "dsb_coddsb")
    @ManyToOne(optional = false)
    private PreDesemb dsbCoddsb;
}
