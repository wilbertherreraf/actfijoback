/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.dao.NormativaDao
 * 01/04/2016 - 17:25:16
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.NormativaEmpresa;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * Banco Central de Bolivia Usuario: Ariel Escobar Fecha: 2/6/2016 Hora: 9:26:21
 */
@Stateless
public class NormativaEmpresaDao extends
        GenericDao<NormativaEmpresa, Integer> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public NormativaEmpresaDao() {
    }

    public NormativaEmpresaDao(Class<NormativaEmpresa> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}
