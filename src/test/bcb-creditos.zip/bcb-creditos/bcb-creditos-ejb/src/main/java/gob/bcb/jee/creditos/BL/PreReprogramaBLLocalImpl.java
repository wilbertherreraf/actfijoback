/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PreReprogramaQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PreReprogramaDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class PreReprogramaBLLocalImpl extends
        GenericBLLocalImpl<PreReprograma, Integer>
        implements PreReprogramaBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    PreReprogramaQLLocal parametrosQLLocal;

    @Inject
    PreReprogramaDao parametroDao;

    @Inject
    private PreReprogramaQLLocal preReprogramaQLLocal;
    @Override
    public GenericQLLocal<PreReprograma, Integer> getQLBean() {
        return parametrosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<PreReprograma, Integer> getGenericDao() {
        return parametroDao;
    }

	@Override
	public void validar(PreReprograma entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Integer nuevoId() throws OperationException {
		return parametrosQLLocal.nuevoId();
	}

	@Override
	public List<Object[]> obtenerContratos(Integer codcred,Integer codmod) throws OperationException {
 
		return parametrosQLLocal.obtenerContratos(codcred, codmod);
	}
    public List<PreReprograma> reprosByCred(Integer codcred, Integer codmod, Integer tiporepro) {
        return parametrosQLLocal.reprosByCred(codcred, codmod,tiporepro);
    }
	
    public PreReprograma guardarRepro(PreReprograma repro) {
        return preReprogramaQLLocal.guardarRepro(repro);
    }

    public PreReprograma findByCodRepro(Integer repro) {
        return preReprogramaQLLocal.findByCodRepro(repro);
    }    
}
