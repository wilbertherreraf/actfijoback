package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreRetiroGarantia;

import javax.ejb.Local;
import java.util.Date;

/**
 * PreRetiroGarantiaBLLocal
 *
 * @author mcramos
 * 11/03/2025
 */
@Local
public interface PreRetiroGarantiaBLLocal extends
        GenericBLLocal<PreRetiroGarantia, Integer> {

    PreRetiroGarantia obtenerPorCodDesembolso(Integer pCodDesembolso);

    Integer getEstadoRetiroGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    Boolean tieneRetiroGarantia(Integer codcred,Integer codmod,Integer coddsb, Date fechaVencimiento) throws OperationException;

    Boolean existeNroClaveSerie(String pNroClaveSerie) throws OperationException;

}
