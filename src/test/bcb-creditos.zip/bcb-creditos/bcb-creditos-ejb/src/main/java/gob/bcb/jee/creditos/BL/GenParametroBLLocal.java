package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.GenParametro;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.pojo.GenParametroDto;
import gob.bcb.jee.creditos.pojo.RespuestaOperacion;

import javax.ejb.Local;

/**
 * GenParametroBLLocal
 *
 * @author mcramos
 * 13/01/2025
 */
@Local
public interface GenParametroBLLocal extends
        GenericBLLocal<GenParametro, Integer> {

    RespuestaOperacion guardarParametros(GenParametroDto pGenParametroDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion);

    GenParametroDto recuperarPorCodCredito(Integer pCodcred);

    RespuestaOperacion modificarParametros(GenParametroDto pGenParametroDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion);

    String getNumeroCuenta(Integer codcred,Integer codmod,Integer tipo) throws OperationException;

}
