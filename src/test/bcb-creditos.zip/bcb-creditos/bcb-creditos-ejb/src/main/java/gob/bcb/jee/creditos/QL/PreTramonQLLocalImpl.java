/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.sql.SQLException;
import java.util.Date;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreTramon;
import gob.bcb.jee.creditos.model.PreTramonPK;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PreTramonQLLocalImpl extends
        GenericQLLocalImpl<PreTramon, PreTramonPK> implements
        PreTramonQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /*
     * (non-Javadoc)
     * @see
     * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
     * ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
    @Override
    public void reversaTransaccion(Integer codcred,Integer codmod,Integer numtrx, Date fechaOper,String usuario, String estacion)throws OperationException,SQLException{
    	String nativeQuery="call d_creditos.p_trx_reversa_cobro(:valor1, :valor2,:valor3,:valor4,:valor5,:valor6)";		
		Query query=entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1",codcred);
		query.setParameter("valor2",codmod);
		query.setParameter("valor3",numtrx);
		query.setParameter("valor4",fechaOper);
		query.setParameter("valor5",usuario);
		query.setParameter("valor6",estacion);
		query.executeUpdate();
    }
    
	@Override
	//@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void reversaTransaccionDif(Integer codcred,Integer codmod,Integer tipotrx, Date fecha, String usuario, String estacion)
			throws OperationException, SQLException {
		String nativeQuery="call d_creditos.p_trx_reversa_tipotrx(:valor1, :valor2,:valor3,:valor4,:valor5,:valor6)";		
		Query query=entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1",codcred);
		query.setParameter("valor2",codmod);
		query.setParameter("valor3",null);
		query.setParameter("valor4",fecha);
		query.setParameter("valor5",usuario);
		query.setParameter("valor6",estacion);
		query.executeUpdate();
		
	}
    
    
	
}
