package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import gob.bcb.jee.creditos.util.Reflection;
import lombok.Getter;
import lombok.Setter;
/**
 *
 * @author hpanique
 */
@Entity
@Getter
@Setter
@Table(name = "pre_prcconta")
@NamedQueries({
        @NamedQuery(name = PrePrcconta.NQ_GET_BY_ID, query = "SELECT p FROM PrePrcconta p where p.prcCodprc = :prcCodprc "),
        @NamedQuery(name = PrePrcconta.NQ_GET_BY_LIST, query = "SELECT p FROM PrePrcconta p where p.id.prcCodcred=:valor1 and p.id.prcCodmod=:valor2 and p.prcEstado in (1,2,3) order by p.prcFecha2 desc"),
        @NamedQuery(name = PrePrcconta.NQ_GET_BY_DATE_MAX, query = "SELECT max(p.id.prcFecha2) FROM PrePrcconta p where p.id.prcCodcred=:valor1 and p.id.prcCodmod=:valor2 "),
})

//@NamedQuery(name = "PrePrcconta.findAll", query = "SELECT p FROM PrePrcconta p"),
//@NamedQuery(name = "PrePrcconta.findByPrcFecha", query = "SELECT p FROM PrePrcconta p WHERE p.prcFecha = :prcFecha"),
//@NamedQuery(name = "PrePrcconta.findByPrcCodcmp", query = "SELECT p FROM PrePrcconta p WHERE p.prcCodcmp = :prcCodcmp"),
//@NamedQuery(name = "PrePrcconta.findByPrcCodcred", query = "SELECT p FROM PrePrcconta p WHERE p.prcCodcred = :prcCodcred"),
//@NamedQuery(name = "PrePrcconta.findByPrcCodmod", query = "SELECT p FROM PrePrcconta p WHERE p.prcCodmod = :prcCodmod"),
//@NamedQuery(name = "PrePrcconta.findByPrcHora", query = "SELECT p FROM PrePrcconta p WHERE p.prcHora = :prcHora"),
//@NamedQuery(name = "PrePrcconta.findByPrcTabestado", query = "SELECT p FROM PrePrcconta p WHERE p.prcTabestado = :prcTabestado"),
//@NamedQuery(name = "PrePrcconta.findByPrcEstado", query = "SELECT p FROM PrePrcconta p WHERE p.prcEstado = :prcEstado"),
//@NamedQuery(name = "PrePrcconta.findByPrcNroCentro", query = "SELECT p FROM PrePrcconta p WHERE p.prcNroCentro = :prcNroCentro"),
//@NamedQuery(name = "PrePrcconta.findByPrcCveTipoComprob", query = "SELECT p FROM PrePrcconta p WHERE p.prcCveTipoComprob = :prcCveTipoComprob"),
//@NamedQuery(name = "PrePrcconta.findByPrcNroComprob", query = "SELECT p FROM PrePrcconta p WHERE p.prcNroComprob = :prcNroComprob"),
//@NamedQuery(name = "PrePrcconta.findByPrcAuditusrgen", query = "SELECT p FROM PrePrcconta p WHERE p.prcAuditusrgen = :prcAuditusrgen"),
//@NamedQuery(name = "PrePrcconta.findByPrcAuditfhogen", query = "SELECT p FROM PrePrcconta p WHERE p.prcAuditfhogen = :prcAuditfhogen"),
//@NamedQuery(name = "PrePrcconta.findByPrcAuditwstgen", query = "SELECT p FROM PrePrcconta p WHERE p.prcAuditwstgen = :prcAuditwstgen"),
//@NamedQuery(name = "PrePrcconta.findByPrcAuditusrpreaut", query = "SELECT p FROM PrePrcconta p WHERE p.prcAuditusrpreaut = :prcAuditusrpreaut"),
//@NamedQuery(name = "PrePrcconta.findByPrcAuditfhopreaut", query = "SELECT p FROM PrePrcconta p WHERE p.prcAuditfhopreaut = :prcAuditfhopreaut"),
//@NamedQuery(name = "PrePrcconta.findByPrcAuditwstpreaut", query = "SELECT p FROM PrePrcconta p WHERE p.prcAuditwstpreaut = :prcAuditwstpreaut"),
//@NamedQuery(name = "PrePrcconta.findByPrcAuditusraut", query = "SELECT p FROM PrePrcconta p WHERE p.prcAuditusraut = :prcAuditusraut"),
//@NamedQuery(name = "PrePrcconta.findByPrcAuditfhoaut", query = "SELECT p FROM PrePrcconta p WHERE p.prcAuditfhoaut = :prcAuditfhoaut"),
//@NamedQuery(name = "PrePrcconta.findByPrcAuditwstaut", query = "SELECT p FROM PrePrcconta p WHERE p.prcAuditwstaut = :prcAuditwstaut")}

public class PrePrcconta extends EntidadAutorizable<Integer> implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String ENTITY ="PrePrcconta";
    public static final String NQ_GET_BY_ID = ENTITY+"GetById";
    public static final String NQ_GET_BY_LIST = ENTITY+"GetByList";
    public static final String NQ_GET_BY_DATE_MAX = ENTITY+"GetByDateMax";

    @Id
    @Column(name = "prc_codprc")
    private Integer prcCodprc;

    
    @Column(name = "prc_fecha")
    @Temporal(TemporalType.DATE)
    private Date prcFecha;

    
    @Column(name = "prc_fecha_2")
    @Temporal(TemporalType.DATE)
    private Date prcFecha2;

    @Column(name = "prc_fecinideven")
    @Temporal(TemporalType.DATE)
    private Date prcFecinideven;

    
    @Column(name = "prc_codcmp")
    private Integer prcCodcmp;

    @Column(name = "prc_montodeven")
    private BigDecimal prcMontodeven;

    
    @Column(name = "prc_codcred")
    private Integer prcCodcred;

    
    @Column(name = "prc_codmod")
    private Integer prcCodmod;


    
    @Column(name = "prc_hora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date prcHora;

    @Column(name = "prc_tabestado")
    private Integer prcTabestado;

    @Column(name = "prc_estado")
    private Integer prcEstado;

    @Column(name = "prc_nro_centro")
    private Integer prcNroCentro;

    @Column(name = "prc_cve_tipo_comprob")
    private Character prcCveTipoComprob;

    @Column(name = "prc_nro_comprob")
    private String prcNroComprob;

    @Column(name = "prc_glosa")
    private String prcGlosa;


    @Column(name = "prc_auditusrgen")
    private String prcAuditusrgen;

    @Column(name = "prc_auditfhogen")
    @Temporal(TemporalType.TIMESTAMP)
    private Date prcAuditfhogen;

    @Column(name = "prc_auditwstgen")
    private String prcAuditwstgen;

    @Column(name = "prc_auditusrpreaut")
    private String prcAuditusrpreaut;

    @Column(name = "prc_auditfhopreaut")
    @Temporal(TemporalType.TIMESTAMP)
    private Date prcAuditfhopreaut;

    @Column(name = "prc_auditwstpreaut")
    private String prcAuditwstpreaut;

    @Column(name = "prc_auditusraut")
    private String prcAuditusraut;

    @Column(name = "prc_auditfhoaut")
    @Temporal(TemporalType.TIMESTAMP)
    private Date prcAuditfhoaut;

    @Column(name = "prc_auditwstaut")
    private String prcAuditwstaut;

    @Column(name = "prc_auditusrrcz")
    private String prcAuditusrrcz;

    @Column(name = "prc_auditfhorcz")
    @Temporal(TemporalType.TIMESTAMP)
    private Date prcAuditfhorcz;

    @Column(name = "prc_auditwstrcz")
    private String prcAuditwstrcz;

    @Column(name = "prc_auditusrcan")
    private String prcAuditusrcan;

    @Column(name = "prc_auditfhocan")
    @Temporal(TemporalType.TIMESTAMP)
    private Date prcAuditfhocan;

    @Column(name = "prc_auditwstcan")
    private String prcAuditwstcan;

    public PrePrcconta() {
    }

    public PrePrcconta(Integer prcCodprc) {
        this.prcCodprc = prcCodprc;
    }

    public PrePrcconta(Integer prcCodprc, Date prcFecha,Integer prcCodcmp,Integer prcCodcred,Integer prcCodmod, Date prcHora) {
        this.prcCodprc = prcCodprc;
        this.prcFecha = prcFecha;
        this.prcCodcmp = prcCodcmp;
        this.prcCodcred = prcCodcred;
        this.prcCodmod = prcCodmod;
        this.prcHora = prcHora;
    }

    @Override
    public String toString() {
        Reflection<PrePrcconta> reflex=new Reflection<PrePrcconta>();
        return reflex.imprimirCampos(this);
    }

    @Override
    public boolean equals(Object o) {
        Reflection<PrePrcconta> reflex=new Reflection<PrePrcconta>();
        return reflex.equals(this,o);
    }

    @Override
    public int hashCode() {
        Reflection<PrePrcconta> reflex=new Reflection<PrePrcconta>();
        return reflex.generarHash(this);
    }
    @Override
    public Integer getId() {
        return this.prcCodprc;
    }
    @Override
    public void setId(Integer id) {
        this.prcCodprc = id;
    }
}
