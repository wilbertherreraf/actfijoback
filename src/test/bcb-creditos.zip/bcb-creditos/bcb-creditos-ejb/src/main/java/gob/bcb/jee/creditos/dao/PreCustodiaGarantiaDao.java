package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.model.PreCustodiaGarantia;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * PreCustodiaGarantiaDao
 *
 * @author mcramos
 * 21/02/2025
 */
@Stateless
public class PreCustodiaGarantiaDao extends GenericDao<PreCustodiaGarantia, Integer> implements
        Serializable {

    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public PreCustodiaGarantiaDao() {
    }

    public PreCustodiaGarantiaDao(Class<PreCustodiaGarantia> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
}
