package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PreRetiroGarantiaQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PreRetiroGarantiaDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreRetiroGarantia;
import gob.bcb.jee.creditos.util.Cttes;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Date;

/**
 * PreRetiroGarantiaBLLocalImpl
 *
 * @author mcramos
 * 11/03/2025
 */
@Stateless
@LocalBean
public class PreRetiroGarantiaBLLocalImpl extends
        GenericBLLocalImpl<PreRetiroGarantia, Integer> implements
        PreRetiroGarantiaBLLocal {

    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;

    @Inject
    PreRetiroGarantiaQLLocal preRetiroGarantiaQLLocal;

    @Inject
    PreRetiroGarantiaDao preRetiroGarantiaDao;

    @Override
    public void validar(PreRetiroGarantia entity) throws OperationException, EntityValidationException {

    }

    @Override
    public GenericQLLocal<PreRetiroGarantia, Integer> getQLBean() {
        return preRetiroGarantiaQLLocal;
    }

    @Override
    public GenericDao<PreRetiroGarantia, Integer> getGenericDao() {
        return preRetiroGarantiaDao;
    }

    @Override
    public PreRetiroGarantia obtenerPorCodDesembolso(Integer pCodDesembolso) {
        return preRetiroGarantiaQLLocal.obtenerPorCodDesembolso(pCodDesembolso);
    }

    @Override
    public Integer getEstadoRetiroGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException {
        return preRetiroGarantiaQLLocal.getEstadoRetiroGarantia(codcred, codmod, coddsb);
    }

    @Override
    public Boolean tieneRetiroGarantia(Integer codcred,Integer codmod,Integer coddsb, Date fechaVencimiento) throws OperationException {
        return preRetiroGarantiaQLLocal.tieneRetiroGarantia(codcred,codmod, coddsb, fechaVencimiento);
    }

    @Override
    public Boolean existeNroClaveSerie(String pNroClaveSerie) throws OperationException {
        return preRetiroGarantiaQLLocal.existeNroClaveSerie(pNroClaveSerie);
    }
}

