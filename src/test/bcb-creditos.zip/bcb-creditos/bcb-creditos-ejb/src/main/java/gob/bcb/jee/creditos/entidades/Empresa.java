/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.entidades.Empresa
 * 29/03/2016 - 10:32:24
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Clase para la entidad Empresa / Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "EMPRESA")
@Getter
@Setter

public class Empresa extends EntidadAutorizable<Integer> implements
    Serializable
{
  public static final String ENTITY = "Empresa";
  public static final String NQ_SEARCH_AUTORIZADOS_BY_TIPO = ENTITY + "SearchByTipo";

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "EMPRESA_ID", updatable = false)
  private Integer id;

  @OneToOne(cascade = {CascadeType.ALL})
  @JoinColumn(name = "LOG_AUDITORIA_ID")
  private LogAuditoria logAuditoria;

  @Column(name = "SIGLA", nullable = false)
  private String sigla;

  @Column(name = "DESCRIPCION", nullable = false)
  private String descripcion;

  @Column(name = "TIPO_EMPRESA", nullable = false)
  private String tipoEmpresa;

  public Empresa()
  {
    super();
  }


  @Override
  public String toString() {
    return "Empresa{" +
            "id=" + id +
            ", logAuditoria=" + logAuditoria +
            ", sigla='" + sigla + '\'' +
            ", descripcion='" + descripcion + '\'' +
            ", tipoEmpresa='" + tipoEmpresa + '\'' +
            '}';
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    Empresa that = (Empresa) o;
    
    if (descripcion != null ? !descripcion.equals(that.descripcion) : that.descripcion != null) return false;
    if (id != null ? !id.equals(that.id) : that.id != null) return false;
    if (logAuditoria != null ? !logAuditoria.equals(that.logAuditoria) : that.logAuditoria != null) return false;
    if (sigla != null ? !sigla.equals(that.sigla) : that.sigla != null) return false;
    if (tipoEmpresa != null ? !tipoEmpresa.equals(that.tipoEmpresa) : that.tipoEmpresa != null)
      return false;

    return true;
  }

  @Override
  public int hashCode() {
    int result = id != null ? id.hashCode() : 0;
    result = 31 * result + (logAuditoria != null ? logAuditoria.hashCode() : 0);
    result = 31 * result + (sigla != null ? sigla.hashCode() : 0);
    result = 31 * result + (descripcion != null ? descripcion.hashCode() : 0);
    result = 31 * result + (tipoEmpresa != null ? tipoEmpresa.hashCode() : 0);
    return result;
  }
}