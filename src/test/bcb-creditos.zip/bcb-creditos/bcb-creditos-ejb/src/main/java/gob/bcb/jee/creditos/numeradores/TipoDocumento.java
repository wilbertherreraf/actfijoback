/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.numeradores.TipoDOcumnento
 * 29/03/2016 - 10:40:48
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.numeradores;

import javax.persistence.Column;

/**
 * Numerador para el tipo de empresaSelected
 * 
 * 
 * @author ysalinas
 * 
 */
public enum TipoDocumento
{
  Documento("Documento"),
  Reglamento("Reglamento");
  private TipoDocumento(String value)
  {
    this.value = value;
  }

  private String value;

  public String getDescripcion()
  {
    return value;
  }

  @Override
  public String toString()
  {
    return value;
  }

  @Column(name = "DESCRIPCION", nullable = false, length = 255)
  private String descripcion;

}
