package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;
import gob.bcb.jee.creditos.util.Cttes;
import org.apache.log4j.Logger;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Arrays;
import java.util.List;

/**
 * PreDesembolsoDetalleQLLocalImpl
 *
 * @author mcramos
 * 11/02/2025
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PreDesembolsoDetalleQLLocalImpl  extends
        GenericQLLocalImpl<PreDesembolsoDetalle, Integer> implements
        PreDesembolsoDetalleQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    protected org.apache.log4j.Logger log = Logger.getLogger(this.getClass());

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
    public PreDesembolsoDetalle buscarPorId(Integer id) {
        String nativeQuery=" select t from PreDesembolsoDetalle t where t.id=:id ";

            Query query=entityManager.createQuery(nativeQuery).setParameter("id", id);
            List result = query.getResultList();
            if (result.size() > 0) {
                return (PreDesembolsoDetalle) result.get(0);
            }

        return null;
    }
    public PreDesembolsoDetalle guardarDsbDetalle(PreDesembolsoDetalle dsbDetalle) {
        try {
            if (dsbDetalle.getId() == null) {
                entityManager.persist(dsbDetalle);
                PreDesembolsoDetalle d = buscarPorId(dsbDetalle.getId());
                return d;
            } else {
                PreDesembolsoDetalle d = entityManager.merge(dsbDetalle);
                return d;
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public PreDesembolsoDetalle obtenerPorCodDesembolso(Integer pCodDesembolso) {
        PreDesembolsoDetalle preDesembolsoDetalle = new PreDesembolsoDetalle();
        String nativeQuery=" select * from d_creditos.pre_desembolso_detalle where dsb_coddsb=:dsb_coddsb and estado IN (1,2,3) ";

        Object detalle = null;
        try {
            Query query=entityManager.createNativeQuery(nativeQuery, PreDesembolsoDetalle.class).setParameter("dsb_coddsb", pCodDesembolso);
            preDesembolsoDetalle = (PreDesembolsoDetalle) query.getSingleResult();

        } catch (NoResultException e) {
            preDesembolsoDetalle = new PreDesembolsoDetalle();
        }
        return preDesembolsoDetalle;
    }

    @Override
    public Integer getEstadoDesembolsoDetalle(Integer codcred,Integer codmod,Integer coddsb) throws OperationException {
        String nativeQuery= " SELECT NVL(r.estado, 0) as estado  " +
                "                 FROM (SELECT 0 as estado FROM systables WHERE tabid = 1) dummy " +
                "                 LEFT JOIN d_creditos.pre_desembolso_detalle r " +
                "                 ON r.codmod=:codmod " +
                "                 and r.codcred=:codcred " +
                "                 and r.dsb_coddsb=:coddsb  " +
                "                 and r.estado in (1,2,3)           ";  // 4 cancelado

        Query query=entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("coddsb", coddsb);

        Object valor= query.getSingleResult();


        if(valor!=null) {
            return (int) valor;
        }
        return 0;
    }

    @Override
    public List<String> getLeyesPrestamo(String leyes) throws OperationException {
        String[] arrayLey = leyes.split(",");

        // Convertir el arreglo a una lista
        List<String> listaLeyes = Arrays.asList(arrayLey);

        // Consulta nativa
        String nativeQuery = "SELECT ley FROM d_creditos.ley WHERE id_ley IN (:leyes)";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("leyes", listaLeyes); // Establecer la lista como parámetro

        // Obtener resultados
        List<String> results = query.getResultList();

        if (results == null || results.isEmpty()) {
            throw new OperationException("No se pudo obtener las leyes del crédito");
        }
        return results;
    }

}
