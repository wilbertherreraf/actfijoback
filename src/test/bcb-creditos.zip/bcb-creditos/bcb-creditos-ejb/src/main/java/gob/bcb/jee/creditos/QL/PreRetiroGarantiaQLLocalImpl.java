package gob.bcb.jee.creditos.QL;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreRetiroGarantia;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;

/**
 * PreRetiroGarantiaQLLocalImpl
 *
 * @author mcramos
 *         11/03/2025
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PreRetiroGarantiaQLLocalImpl extends
        GenericQLLocalImpl<PreRetiroGarantia, Integer> implements
        PreRetiroGarantiaQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

    public PreRetiroGarantia buscarPorId(Integer id) {
        String nativeQuery = " select t from PreRetiroGarantia t where t.id=:id ";

        Query query = entityManager.createQuery(nativeQuery).setParameter("id", id);
        List result = query.getResultList();
        if (result.size() > 0) {
            return (PreRetiroGarantia) result.get(0);
        }

        return null;
    }

    public PreRetiroGarantia guardarRetGar(PreRetiroGarantia entity) {
        try {
            if (entity.getId() == null) {
                entityManager.persist(entity);
                PreRetiroGarantia d = buscarPorId(entity.getId());
                return d;
            } else {
                PreRetiroGarantia d = entityManager.merge(entity);
                return d;
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public PreRetiroGarantia obtenerPorCodDesembolso(Integer pCodDesembolso) {
        PreRetiroGarantia preRetiroGarantia = new PreRetiroGarantia();
        String nativeQuery = " select  FIRST 1 * from d_creditos.pre_retiro_garantia where coddsb=:coddsb and estado IN (1,2,3) order by fecha_vencimiento desc; ";// 4:Anulado,
          // 5:cancelado

        try {
            Query query = entityManager.createNativeQuery(nativeQuery, PreRetiroGarantia.class).setParameter("coddsb",
                    pCodDesembolso);
            preRetiroGarantia = (PreRetiroGarantia) query.getSingleResult();

        } catch (NoResultException e) {
            String error = "No se encontro un retiro de garantia para : " + pCodDesembolso;
            Log.Error(error);
            preRetiroGarantia = new PreRetiroGarantia();
        }
        return preRetiroGarantia;
    }

    @Override
    public Integer getEstadoRetiroGarantia(Integer codcred, Integer codmod, Integer coddsb) throws OperationException {
        String nativeQuery = " SELECT NVL(r.estado, 0) as estado  " +
                " FROM (SELECT 0 as estado FROM systables WHERE tabid = 1) dummy " +
                " LEFT JOIN d_creditos.pre_retiro_garantia r " +
                " ON r.codmod=:codmod " +
                " and r.codcred=:codcred " +
                " and r.coddsb=:coddsb  " +
                " and r.estado IN (1,2,3) ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("coddsb", coddsb);

        Object valor = query.getSingleResult();

        if (valor != null) {
            return (int) valor;
        }
        return 0;
    }

    @Override
    public Boolean tieneRetiroGarantia(Integer codcred, Integer codmod, Integer coddsb, Date fechaVencimiento) {
        int resultado = 0;

        try {
            String nativeQuery = " select NVL(count(*),0) from d_creditos.pre_retiro_garantia where coddsb=:coddsb  and codcred=:codcred and codmod=:codmod and fecha_vencimiento=:fecha_vencimiento and estado IN (1,2,3) ";

            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("codcred", codcred);
            query.setParameter("codmod", codmod);
            query.setParameter("coddsb", coddsb);
            query.setParameter("fecha_vencimiento", fechaVencimiento);

            resultado = (((Number) query.getSingleResult()).intValue());
        } catch (Exception e) {

            return null;
        }

        return resultado > 0;
    }

    @Override
    public Boolean existeNroClaveSerie(String pNroClaveSerie) {
        int resultado = 0;

        try {
            String nativeQuery = " select NVL(count(*),0) from d_creditos.pre_retiro_garantia where nro_claveserie=:pNroClaveSerie and estado IN (1,2,3) ";

            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("pNroClaveSerie", pNroClaveSerie);

            resultado = (((Number) query.getSingleResult()).intValue());
        } catch (Exception e) {

            return null;
        }

        return resultado > 0;
    }
}
