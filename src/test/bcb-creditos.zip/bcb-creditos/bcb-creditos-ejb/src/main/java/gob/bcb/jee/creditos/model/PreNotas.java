package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the pre_notas database table.
 * 
 */
@Entity
@Table(name="pre_notas")
@NamedQuery(name="PreNotas.findAll", query="SELECT p FROM PreNotas p")
public class PreNotas implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PreNotasPK id;

	@Column(name="npr_auditfho")
	private Timestamp nprAuditfho;

	@Column(name="npr_audittrx")
	private String nprAudittrx;

	@Column(name="npr_auditusr")
	private String nprAuditusr;

	@Column(name="npr_auditwst")
	private String nprAuditwst;

	@Column(name="npr_descrip")
	private String nprDescrip;

	@Temporal(TemporalType.DATE)
	@Column(name="npr_fpago")
	private Date nprFpago;

	public PreNotas() {
	}

	public PreNotasPK getId() {
		return this.id;
	}

	public void setId(PreNotasPK id) {
		this.id = id;
	}

	public Timestamp getNprAuditfho() {
		return this.nprAuditfho;
	}

	public void setNprAuditfho(Timestamp nprAuditfho) {
		this.nprAuditfho = nprAuditfho;
	}

	public String getNprAudittrx() {
		return this.nprAudittrx;
	}

	public void setNprAudittrx(String nprAudittrx) {
		this.nprAudittrx = nprAudittrx;
	}

	public String getNprAuditusr() {
		return this.nprAuditusr;
	}

	public void setNprAuditusr(String nprAuditusr) {
		this.nprAuditusr = nprAuditusr;
	}

	public String getNprAuditwst() {
		return this.nprAuditwst;
	}

	public void setNprAuditwst(String nprAuditwst) {
		this.nprAuditwst = nprAuditwst;
	}

	public String getNprDescrip() {
		return this.nprDescrip;
	}

	public void setNprDescrip(String nprDescrip) {
		this.nprDescrip = nprDescrip;
	}

	public Date getNprFpago() {
		return this.nprFpago;
	}

	public void setNprFpago(Date nprFpago) {
		this.nprFpago = nprFpago;
	}

}
