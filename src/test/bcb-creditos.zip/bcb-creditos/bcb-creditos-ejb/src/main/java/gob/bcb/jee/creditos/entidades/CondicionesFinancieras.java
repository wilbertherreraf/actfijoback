package gob.bcb.jee.creditos.entidades;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.entidades
 * 29/11/2016 - 12:31 PM
 * Creado por aescobar
 */
@Getter
@Setter
@Entity
@Table(name = "COND_FINANCIERAS")
@NamedQueries({
        @NamedQuery(name = CondicionesFinancieras.ENTITY + Entidad.NQ_GET_LAZY, query = "select g from CondicionesFinancieras g  where g.id=:id"),
        @NamedQuery(name = CondicionesFinancieras.ENTITY + Entidad.NQ_SEARCH, query = "SELECT g FROM CondicionesFinancieras g "),
        @NamedQuery(name = CondicionesFinancieras.NQ_LIST_BY_PROYECTO_AND_ESTADO, query = "select h from CondicionesFinancieras h where h.proyecto.id = :proyectoId ")
})
public class CondicionesFinancieras extends EntidadAutorizable<Long> implements Serializable {

    public static final String ENTITY = "CondicionesFinancieras";
    public static final String NQ_LIST_BY_PROYECTO_AND_ESTADO = ENTITY + "CondicionesFinancieras";


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", updatable = false)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PROYECTO", referencedColumnName = "ID")
    private Proyecto proyecto;

    @Column(name = "TASA_INTERES", columnDefinition = "DECIMAL(18,2)", precision = 18, scale = 2, nullable = false)
    private BigDecimal tasaInteres;

    @Column(name = "PERIODO_GRACIA_CAPITAL", columnDefinition = "DECIMAL(6,2)",
            precision = 6, scale = 2, nullable = false)
    private BigDecimal periodoGraciaCapital;

    @Column(name = "PERIODO_GRACIA_INTERES", columnDefinition = "DECIMAL(6,2)",
            precision = 6, scale = 2, nullable = false)
    private BigDecimal periodoGraciaInteres;

    @Column(name = "FECHA_VIGENCIA", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaVigencia;

    @Column(name = "FECHA_CAMBIO", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaCambio;

    public CondicionesFinancieras() {
    }

    public CondicionesFinancieras(Proyecto proyecto, BigDecimal tasaInteres, BigDecimal periodoGraciaCapital, BigDecimal periodoGraciaInteres, Date fechaCambio) {
        this.proyecto = proyecto;
        this.tasaInteres = tasaInteres;
        this.periodoGraciaCapital = periodoGraciaCapital;
        this.periodoGraciaInteres = periodoGraciaInteres;
        this.fechaCambio = fechaCambio;
    }

    public String getTasaInteresFormat() {
        return tasaInteres == null ? "" : getDecimalDosFormat(tasaInteres);
    }

    public String getPeriodoGraciaInteresFormat() {
        return getIntegerOrDecimalFormat(periodoGraciaInteres);
    }

    public String getPeriodoGraciaCapitalFormat() {
        return getIntegerOrDecimalFormat(periodoGraciaCapital);
    }
}
