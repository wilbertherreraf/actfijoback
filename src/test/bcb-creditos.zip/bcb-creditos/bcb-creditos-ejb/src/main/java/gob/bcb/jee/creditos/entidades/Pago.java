package gob.bcb.jee.creditos.entidades;

import gob.bcb.jee.creditos.numeradores.Estado;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.entidades
 * 02/08/2016 - 10:57 AM
 * Creado por aescobar
 */

@Entity
@Table(name = "PAGO")
@Getter
@Setter

public class Pago extends EntidadAutorizable<Long> {

    public static final String ENTITY = "Pago";
    public static final String NQ_SEARCH_ALL = ENTITY + "SearchAll";
    public static final String NQ_GET_BY_DESEMBOLSO = ENTITY + "GetByDesembolso";
    public static final String NQ_GET_BY_PROYECTO = ENTITY + "GetByProyecto";
    public static final String NQ_GET_BY_PROYECTO_FECHA = ENTITY + "GetByProyectoFecha";
    public static final String NQ_GET_FECHA_PROX_PAGO = ENTITY + "GetFechaProxPago";
    public static final String NQ_GET_TO_FECHA_BY_DESEMBOLSO = ENTITY + "GetToFechaByDesembolso";
    public static final String NQ_GET_BY_DESEMBOLSO_AUTORIZADOS = ENTITY + "GetByDesembolsoAutorizados";
    public static final String NQ_GET_BY_PROYECTO_FECHA_PENDIENTES_PAGO = ENTITY + "GetByProyectoFechaPendientes";
    public static final String NQ_GET_BY_PROYECTO_AND_ESTADO_PAGO = ENTITY + "GetByProyectoAndEstadoPago";
    public static final String NQ_GET_BY_PROYECTO_EFECTIVOS = ENTITY + "GetByProyectoEfectivos";
    public static final String NQ_GET_BY_PROYECTO_EFECTIVOS_ACTUAL = ENTITY + "GetByProyectoEfectivosActual";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", updatable = false)
    private Long id;

    @Column(name = "NUMERO")
    private Integer numero;

    @Column(name = "FECHA_VENCIMIENTO", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaVencimiento;

    @Column(name = "DIAS")
    private Integer dias;

    @Column(name = "SALDO", columnDefinition = "DECIMAL(15,2)",
            precision = 15, scale = 2, nullable = false)
    private BigDecimal saldo;

    @Column(name = "AMORTIZACION", columnDefinition = "DECIMAL(15,2)",
            precision = 15, scale = 2, nullable = false)
    private BigDecimal amortizacion;

    @Column(name = "INTERES", columnDefinition = "DECIMAL(15,2)",
            precision = 15, scale = 2, nullable = false)
    private BigDecimal interes;

    @Column(name = "CUOTA", columnDefinition = "DECIMAL(15,2)",
            precision = 15, scale = 2, nullable = false)
    private BigDecimal cuota;

    @Column(name = "FECHA_PAGO_EFECTIVO")
    @Temporal(TemporalType.DATE)
    private Date fechaPagoEfectivo;

    @Column(name = "FECHA_REGISTRO")
    @Temporal(TemporalType.DATE)
    private Date fechaRegistro;

    @Column(name = "ESTADO_PAGO", nullable = false)
    @Enumerated(EnumType.STRING)
    private Estado estadoPago;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "DESEMBOLSO", referencedColumnName = "ID")
    private Desembolso desembolso;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "LOG_AUDITORIA_ID")
    private LogAuditoria logAuditoria;

    @OneToOne
    @JoinColumn(name = "COND_FINANCIERAS_ID", nullable = false)
    private CondicionesFinancieras condicionesFinancieras;

    public Pago(Integer numero, Date fechaVencimiento, Integer dias, BigDecimal saldo, BigDecimal amortizacion, BigDecimal interes, BigDecimal cuota, Desembolso desembolso) {
        this.numero = numero;
        this.fechaVencimiento = fechaVencimiento;
        this.dias = dias;
        this.saldo = saldo;
        this.amortizacion = amortizacion;
        this.interes = interes;
        this.cuota = cuota;
        this.desembolso = desembolso;
    }

    public Pago() {
    }

    public String getFechaVencimientoFormat() {
        if (fechaVencimiento != null) {
            return getDateFormat(fechaVencimiento);
        } else {
            return "";
        }
    }

    public String getCuotaFormat() {
        if (cuota != null) {
            return getDecimalDosFormat(cuota);
        } else {
            return "";
        }
    }

    public String getInteresFormat() {
        if (interes != null) {
            return getDecimalDosFormat(interes);
        } else {
            return "";
        }
    }

    public String getAmortizacionFormat() {
        if (amortizacion != null) {
            return getDecimalDosFormat(amortizacion);
        } else {
            return "";
        }
    }

    public String getSaldoFormat() {
        if (saldo != null) {
            return getDecimalDosFormat(saldo);
        } else {
            return "";
        }
    }
}
