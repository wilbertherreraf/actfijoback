package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;

/**
 * The primary key class for the aux_planpagos database table.
 * 
 */
@Getter
@Setter
@Embeddable
public class AuxPlanpagosPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="acu_numcuo")
	private Integer acuNumcuo;

	@Temporal(TemporalType.DATE)
	@Column(name="acu_fecvencuo")
	private java.util.Date acuFecvencuo;
	
	@Column(name="acu_codcred")
	private Integer acuCodcred;

	@Column(name="acu_codmod")
	private Integer acuCodmod;

	public AuxPlanpagosPK() {
	}
	
}
