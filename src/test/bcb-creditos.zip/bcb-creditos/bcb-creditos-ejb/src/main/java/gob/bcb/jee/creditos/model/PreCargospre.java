package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the pre_cargospre database table.
 * 
 */
@Entity
@Table(name="pre_cargospre")
@NamedQuery(name="PreCargospre.findAll", query="SELECT p FROM PreCargospre p")
public class PreCargospre implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PreCargosprePK id;

	@Column(name="ctr_auditfho")
	private Timestamp ctrAuditfho;

	@Column(name="ctr_audittrx")
	private String ctrAudittrx;

	@Column(name="ctr_auditusr")
	private String ctrAuditusr;

	@Column(name="ctr_auditwst")
	private String ctrAuditwst;

	@Temporal(TemporalType.DATE)
	@Column(name="ctr_fecproc")
	private Date ctrFecproc;

	@Temporal(TemporalType.DATE)
	@Column(name="ctr_fecreg")
	private Date ctrFecreg;

	@Column(name="ctr_glosa")
	private String ctrGlosa;

	@Column(name="ctr_marcfin")
	private String ctrMarcfin;

	@Column(name="ctr_monfin")
	private BigDecimal ctrMonfin;

	@Column(name="ctr_numtrx")
	private Integer ctrNumtrx;

	@Column(name="ctr_statreg")
	private Integer ctrStatreg;

	@Column(name="ctr_tabcodtrx")
	private Integer ctrTabcodtrx;

	@Column(name="ctr_tabstatreg")
	private Integer ctrTabstatreg;

	@Column(name="ctr_tabtipregis")
	private Integer ctrTabtipregis;

	@Column(name="ctr_tabtrxstaau")
	private Integer ctrTabtrxstaau;

	@Column(name="ctr_tipregis")
	private Integer ctrTipregis;

	@Column(name="ctr_trxstaau")
	private Integer ctrTrxstaau;

	@Column(name="ctr_valor")
	private BigDecimal ctrValor;

	public PreCargospre() {
	}

	public PreCargosprePK getId() {
		return this.id;
	}

	public void setId(PreCargosprePK id) {
		this.id = id;
	}

	public Timestamp getCtrAuditfho() {
		return this.ctrAuditfho;
	}

	public void setCtrAuditfho(Timestamp ctrAuditfho) {
		this.ctrAuditfho = ctrAuditfho;
	}

	public String getCtrAudittrx() {
		return this.ctrAudittrx;
	}

	public void setCtrAudittrx(String ctrAudittrx) {
		this.ctrAudittrx = ctrAudittrx;
	}

	public String getCtrAuditusr() {
		return this.ctrAuditusr;
	}

	public void setCtrAuditusr(String ctrAuditusr) {
		this.ctrAuditusr = ctrAuditusr;
	}

	public String getCtrAuditwst() {
		return this.ctrAuditwst;
	}

	public void setCtrAuditwst(String ctrAuditwst) {
		this.ctrAuditwst = ctrAuditwst;
	}

	public Date getCtrFecproc() {
		return this.ctrFecproc;
	}

	public void setCtrFecproc(Date ctrFecproc) {
		this.ctrFecproc = ctrFecproc;
	}

	public Date getCtrFecreg() {
		return this.ctrFecreg;
	}

	public void setCtrFecreg(Date ctrFecreg) {
		this.ctrFecreg = ctrFecreg;
	}

	public String getCtrGlosa() {
		return this.ctrGlosa;
	}

	public void setCtrGlosa(String ctrGlosa) {
		this.ctrGlosa = ctrGlosa;
	}

	public String getCtrMarcfin() {
		return this.ctrMarcfin;
	}

	public void setCtrMarcfin(String ctrMarcfin) {
		this.ctrMarcfin = ctrMarcfin;
	}

	public BigDecimal getCtrMonfin() {
		return this.ctrMonfin;
	}

	public void setCtrMonfin(BigDecimal ctrMonfin) {
		this.ctrMonfin = ctrMonfin;
	}

	public Integer getCtrNumtrx() {
		return this.ctrNumtrx;
	}

	public void setCtrNumtrx(Integer ctrNumtrx) {
		this.ctrNumtrx = ctrNumtrx;
	}

	public Integer getCtrStatreg() {
		return this.ctrStatreg;
	}

	public void setCtrStatreg(Integer ctrStatreg) {
		this.ctrStatreg = ctrStatreg;
	}

	public Integer getCtrTabcodtrx() {
		return this.ctrTabcodtrx;
	}

	public void setCtrTabcodtrx(Integer ctrTabcodtrx) {
		this.ctrTabcodtrx = ctrTabcodtrx;
	}

	public Integer getCtrTabstatreg() {
		return this.ctrTabstatreg;
	}

	public void setCtrTabstatreg(Integer ctrTabstatreg) {
		this.ctrTabstatreg = ctrTabstatreg;
	}

	public Integer getCtrTabtipregis() {
		return this.ctrTabtipregis;
	}

	public void setCtrTabtipregis(Integer ctrTabtipregis) {
		this.ctrTabtipregis = ctrTabtipregis;
	}

	public Integer getCtrTabtrxstaau() {
		return this.ctrTabtrxstaau;
	}

	public void setCtrTabtrxstaau(Integer ctrTabtrxstaau) {
		this.ctrTabtrxstaau = ctrTabtrxstaau;
	}

	public Integer getCtrTipregis() {
		return this.ctrTipregis;
	}

	public void setCtrTipregis(Integer ctrTipregis) {
		this.ctrTipregis = ctrTipregis;
	}

	public Integer getCtrTrxstaau() {
		return this.ctrTrxstaau;
	}

	public void setCtrTrxstaau(Integer ctrTrxstaau) {
		this.ctrTrxstaau = ctrTrxstaau;
	}

	public BigDecimal getCtrValor() {
		return this.ctrValor;
	}

	public void setCtrValor(BigDecimal ctrValor) {
		this.ctrValor = ctrValor;
	}

}
