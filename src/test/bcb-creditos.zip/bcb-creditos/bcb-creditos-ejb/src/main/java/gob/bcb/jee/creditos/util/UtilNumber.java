/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.util.UtilNumber
 * 25/02/2016 - 13:19:40
 * Creado por ySalinas
 */
package gob.bcb.jee.creditos.util;

import java.math.BigDecimal;

/**
 * Utilitario para el control de decimales y puntos
 *
 * @author yesenia salinas
 */
public class UtilNumber {
    private static final String THOUSAND_SEPARATOR = ",";
    private static final String DECIMAL_SEPARATOR = ".";

    public static BigDecimal convertToBigDecimal(String number) {
        // quitamos signo de miles
        number = number.replace(THOUSAND_SEPARATOR, "");
        return new BigDecimal(number);
    }

    public static boolean inRange(BigDecimal value, BigDecimal minVal, BigDecimal maxVal){
        return (value.compareTo(minVal) >= 0) && (value.compareTo(maxVal) < 0);
    }

}
