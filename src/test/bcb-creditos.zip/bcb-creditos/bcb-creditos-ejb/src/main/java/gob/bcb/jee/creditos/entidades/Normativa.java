/**
 *
 */
package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Ariel Escobar
 */
@Entity
@Table(name = "NORMATIVA")
@Getter
@Setter

public class Normativa extends EntidadAutorizable<Integer> implements
        Serializable {
    public static final String ENTITY = "Normativa";
    public static final String NQ_SEARCH_ALL = ENTITY + "SearchAll";

    private static final long serialVersionUID = -6660115201439822414L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", updatable = false)
    private Integer id;

    @ManyToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "LOG_AUDITORIA_ID")
    private LogAuditoria logAuditoria;

    @Column(name = "GESTION")
    private Integer gestion;

    @Column(name = "NUMERO_LEY")
    private String numeroLey;

    @Column(name = "NOMBRE", nullable = false)
    private String nombre;

    @Column(name = "CONSIDERACIONES")
    private String consideraciones;


    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "NORMATIVA_ID", nullable = true, insertable = true, updatable = true)
    private List<NormativaEmpresa> empresas = new ArrayList<NormativaEmpresa>();

    public Normativa() {
        super();
    }

    @Override
    public String toString() {
        return "";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((logAuditoria == null) ? 0 : logAuditoria.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((gestion == null) ? 0 : gestion.hashCode());
        result = prime * result + ((numeroLey == null) ? 0 : numeroLey.hashCode());
        result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
        result = prime * result + ((consideraciones == null) ? 0 : consideraciones.hashCode());
        

        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Normativa other = (Normativa) obj;
        //log auditoria
        if (logAuditoria == null && other.logAuditoria != null) {
            return false;
        } else if (logAuditoria != null && !logAuditoria.equals(other.logAuditoria))
            return false;
        //id
        if (id == null && other.id != null) {
            return false;
        } else if (!id.equals(other.id))
            return false;
        //gestion
        if (gestion == null && other.gestion != null) {
            return false;
        } else if (!gestion.equals(other.gestion))
            return false;
        //numeroLey
        if (numeroLey == null && other.numeroLey != null) {
            return false;
        } else if (!numeroLey.equals(other.numeroLey))
            return false;
        //nombre
        if (nombre == null && other.nombre != null) {
            return false;
        } else if (!nombre.equals(other.nombre))
            return false;
        //consideraciones
        if (consideraciones == null && other.consideraciones != null) {
            return false;
        } else if (!consideraciones.equals(other.consideraciones))
            return false;
       

        return true;
    }

}
