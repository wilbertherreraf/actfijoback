/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.numeradores.TipoParametro
 * 21/03/2016 - 10:55:44
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.numeradores;

/**
 * Numerador para el tipo de parametro o tipo de entidad
 * 
 * 
 * @author ysalinas
 * 
 */
public enum TipoParametro
{
  GAR("GARANTIA"),
  LEY("LEY");

  private TipoParametro(String value)
  {
    this.value = value;
  }

  private String value;

  public String getDescripcion()
  {
    return value;
  }

  @Override
  public String toString()
  {
    return value;
  }

}
