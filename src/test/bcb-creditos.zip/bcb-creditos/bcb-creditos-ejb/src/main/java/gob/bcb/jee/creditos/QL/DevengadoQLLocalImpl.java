package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Devengado;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.QL
 * 13/09/2016 - 12:28 PM
 * Creado por aescobar
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class DevengadoQLLocalImpl extends
		GenericQLLocalImpl<Devengado, Long> implements
		DevengadoQLLocal {
	private final static Logger logger = Logger.getLogger(DevengadoQLLocalImpl.class);
	@PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
	private EntityManager entityManager;

	@Override
	protected EntityManager entityManager() {
		return entityManager;
	}

	public void generarDevengados(Date fechaIni, Integer tipoproc, String coduser, String estacion)
			throws OperationException {
		try {
			String nativeQuery = "call d_creditos.p_acr_proc_devengar(:valor1, :valor2, :valor3, :valor4)";
			Query query = entityManager.createNativeQuery(nativeQuery);
			query.setParameter("valor1", fechaIni);
			query.setParameter("valor2", tipoproc);
			query.setParameter("valor3", coduser);
			query.setParameter("valor4", estacion);
			query.executeUpdate();

		} catch (Exception e) {
			Log.Error("Exception: " + e.getMessage());
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			String consent = (count > 0 ? sb.toString().replace(", null ,", "")
					: "Error :" + e.getMessage().replace(", null ,", ""));
			throw new RuntimeException("Error p_acr_proc_devengar: " + consent, e);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void generarDevengadosTodos(Integer tipoproceso, Date fechaIni) throws Throwable {
		try {
			logger.info("Inicio devengado ALLLLLLLLL " + fechaIni + " tipo: " + tipoproceso);
			String nativeQuery = "call d_creditos.p_acr_proc_devdsb_manual(:tipoproceso, :fechaini, :fechafin)";
			Query query = entityManager.createNativeQuery(nativeQuery);
			query.setParameter("tipoproceso", tipoproceso);
			query.setParameter("fechaini", fechaIni, TemporalType.DATE);			
			query.setParameter("fechafin", fechaIni, TemporalType.DATE);
			query.executeUpdate();
		} catch (Exception e) {
			Log.Error("Exception: " + e.getMessage());
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			String consent = (count > 0 ? sb.toString().replace(", null ,", "")
					: "Error :" + e.getMessage().replace(", null ,", ""));
			throw new RuntimeException("Error en p_acr_proc_devdsb_manual: " + consent, e);
		}
	}


	public void cierreDevengados(Date fechaIni, String coduser, String estacion) throws OperationException {
		String nativeQuery = "call d_creditos.p_acr_cerrarinforme(:valor1, :valor2, :valor3)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", fechaIni);
		query.setParameter("valor2", coduser);
		query.setParameter("valor3", estacion);
		query.executeUpdate();
	}

}