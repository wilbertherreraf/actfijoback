package gob.bcb.jee.creditos.BL;

import com.google.common.collect.ImmutableMap;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.NormativaEmpresaQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.NormativaEmpresaDao;
import gob.bcb.jee.creditos.entidades.NormativaEmpresa;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.excepciones.ValidatorViewException;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Cttes;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Banco Central de Bolivia Usuario: Ariel Escobar Fecha: 2/6/2016 Hora: 9:18:15
 */

@Stateless
@LocalBean
public class NormativaEmpresaBLLocalImpl extends
		GenericBLLocalImpl<NormativaEmpresa, Integer> implements NormativaEmpresaBLLocal {
	private static Logger log = Logger.getLogger(NormativaEmpresaBLLocalImpl.class);

	@PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
	EntityManager em;
	/*
	 * Inyeccion de los metodos para consulta (QL)
	 */
	@Inject
	NormativaEmpresaQLLocal normativaEmpresaQLLocal;

	@Inject
	NormativaEmpresaDao normativaEmpresaDao;

	@Override
	public GenericQLLocal<NormativaEmpresa, Integer> getQLBean() {
		return normativaEmpresaQLLocal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
	 */
	@Override
	public GenericDao<NormativaEmpresa, Integer> getGenericDao() {
		return normativaEmpresaDao;
	}

	@Override
	public void validar(NormativaEmpresa entity) throws OperationException {

		log.trace("Validar¡ a el documento requerido: " + entity);
		if (entity == null) {
			throw new ValidatorViewException(
					"No se puede guardar la Normativa", "codRecurso");
		}

	}

	@Override
	public void changeEstate(Integer id, Estado estado)
			throws OperationException {
		super.changeEstate(id, estado);
	}
	
	 @Override
	  public List<NormativaEmpresa> listByEmpresa(Integer empresaId)
	      throws OperationException
	  {
	    List<NormativaEmpresa> lista = new ArrayList<NormativaEmpresa>();
	    log.info("EL ID DE LA EMPRESA ES : " + empresaId);

	    try
	    {

	      lista = normativaEmpresaQLLocal.listByNamedQuery(NormativaEmpresa.NQ_SEARCH_BY_EMPRESA, ImmutableMap.of("empresaId", (Object) empresaId));
	      log.info("LA LISTA DE NORMATIVA INSTIUCION ENCONTRADAS ES : " + lista);
	    }
	    catch (Exception e)
	    {
	      log.error("Error al obtener filtro.", e);
	    }
	    return lista;
	  }
	 
	 @Override
	  public List<NormativaEmpresa> listByNormativa(Integer normativaId)
	      throws OperationException
	  {
	    List<NormativaEmpresa> lista = new ArrayList<NormativaEmpresa>();
	    log.info("EL ID DE LA INSTITUCION ES : " + normativaId);

	    try
	    {

	      lista = normativaEmpresaQLLocal.listByNamedQuery(NormativaEmpresa.NQ_SEARCH_BY_NORMATIVA, ImmutableMap.of("normativaId", (Object) normativaId));
	      log.info("LA LISTA DE NORMATIVA INSTIUCION ENCONTRADAS ES : " + lista);
	    }
	    catch (Exception e)
	    {
	      log.error("Error al obtener filtro.", e);
	    }
	    return lista;
	  }

	@Override
	public BigDecimal getMontoLeyByEmpresa(Integer empresaId) throws OperationException {
		BigDecimal resultado = new BigDecimal("0");
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("empresaId", empresaId);
		try {
			resultado = (BigDecimal) normativaEmpresaQLLocal.getObjectByNamedQuery(NormativaEmpresa.NQ_GET_MONTO_LEY_BY_EMPRESA, params);
		} catch (Exception e) {
			log.error("Error al obtener monto de la empresa " + empresaId, e);
			throw new OperationException("Error al obtener el monto de la empresa " + empresaId);
		}

		return resultado;
	}


}
