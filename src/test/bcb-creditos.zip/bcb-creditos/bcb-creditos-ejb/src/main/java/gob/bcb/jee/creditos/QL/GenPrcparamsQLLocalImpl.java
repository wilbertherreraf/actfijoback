package gob.bcb.jee.creditos.QL;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import gob.bcb.jee.creditos.entidades.GenPrcparams;
import gob.bcb.jee.creditos.util.Cttes;


@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class GenPrcparamsQLLocalImpl implements GenPrcparamsQLLocal{
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    protected EntityManager entityManager;
    
    // Métodos específicos para GenPrcparams
    
    /**
     * Busca parámetros por código de proceso
     */
    public List<GenPrcparams> findByCodPrc(Integer codPrc) {
        TypedQuery<GenPrcparams> query = entityManager.createQuery(
            "SELECT g FROM GenPrcparams g WHERE g.prpCodprc = :codPrc",
            GenPrcparams.class
        );
        query.setParameter("codPrc", codPrc);
        return query.getResultList();
    }
    
    /**
     * Busca parámetros por tipo de proceso
     */
    public List<GenPrcparams> findByTipoProc(Integer tipoProc) {
        TypedQuery<GenPrcparams> query = entityManager.createQuery(
            "SELECT g FROM GenPrcparams g WHERE g.prpTipoproc = :tipoProc",
            GenPrcparams.class
        );
        query.setParameter("tipoProc", tipoProc);
        return query.getResultList();
    }
    public List<GenPrcparams> findByCodPrcAndTipoProc(Integer codPrc, Integer tipoProc) {
        if (codPrc == null || tipoProc == null) {
            return new ArrayList<>();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT g ");
        sb.append("FROM GenPrcparams g ");
        sb.append("WHERE g.prpCodprc = :codPrc ");
        sb.append("AND g.prpTipoproc = :tipoProc ");                        
        sb.append("AND g.prpCtamov is not null ");
        sb.append("AND g.prpMontomn > 0 ");        
        sb.append("order by g.prpNroreng ");

        TypedQuery<GenPrcparams> query = entityManager.createQuery(sb.toString(),
            GenPrcparams.class
        );

        query.setParameter("codPrc", codPrc);
        query.setParameter("tipoProc", tipoProc);
        List<GenPrcparams> results = query.getResultList();
        return results;
    }
    
    public List<GenPrcparams> findByCodPrcYTipoProc(Integer codPrc, Integer tipoProc) {
        if (codPrc == null || tipoProc == null) {
            return new ArrayList<>();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT g ");
        sb.append("FROM GenPrcparams g ");
        sb.append("WHERE g.prpCodprc = :codPrc ");
        sb.append("AND g.prpTipoproc = :tipoProc ");                        
        sb.append("order by g.prpNroreng ");

        TypedQuery<GenPrcparams> query = entityManager.createQuery(sb.toString(),
            GenPrcparams.class
        );

        query.setParameter("codPrc", codPrc);
        query.setParameter("tipoProc", tipoProc);
        List<GenPrcparams> results = query.getResultList();
        return results;
    }    
    public List<GenPrcparams> findByCodLit(String codLit) {
        TypedQuery<GenPrcparams> query = entityManager.createQuery(
            "SELECT g FROM GenPrcparams g WHERE g.prpCodlit = :codLit",
            GenPrcparams.class
        );
        query.setParameter("codLit", codLit);
        return query.getResultList();
    }
    
    public List<GenPrcparams> findByMontomoGreaterThan(BigDecimal monto) {
        TypedQuery<GenPrcparams> query = entityManager.createQuery(
            "SELECT g FROM GenPrcparams g WHERE g.prpMontomo > :monto",
            GenPrcparams.class
        );
        query.setParameter("monto", monto);
        return query.getResultList();
    }
    
    /**
     * Busca parámetros por número de transacción
     */
    public List<GenPrcparams> findByNumTrx(Integer numTrx) {
        TypedQuery<GenPrcparams> query = entityManager.createQuery(
            "SELECT g FROM GenPrcparams g WHERE g.prpNumtrx = :numTrx",
            GenPrcparams.class
        );
        query.setParameter("numTrx", numTrx);
        return query.getResultList();
    }
    
    /**
     * Busca parámetros por código de cobro
     */
    public List<GenPrcparams> findByCodCob(Integer codCob) {
        TypedQuery<GenPrcparams> query = entityManager.createQuery(
            "SELECT g FROM GenPrcparams g WHERE g.prpCodcob = :codCob",
            GenPrcparams.class
        );
        query.setParameter("codCob", codCob);
        return query.getResultList();
    }
    
    /**
     * Busca por código de proceso y tipo de proceso con paginación
     */
    public List<GenPrcparams> findByCodPrcAndTipoProcPaginated(
            Integer codPrc, String tipoProc, int firstResult, int maxResults) {
        TypedQuery<GenPrcparams> query = entityManager.createQuery(
            "SELECT g FROM GenPrcparams g WHERE g.prpCodprc = :codPrc AND g.prpTipoproc = :tipoProc",
            GenPrcparams.class
        );
        query.setParameter("codPrc", codPrc);
        query.setParameter("tipoProc", tipoProc);
        query.setFirstResult(firstResult);
        query.setMaxResults(maxResults);
        return query.getResultList();
    }
    
    /**
     * Cuenta parámetros por código de proceso
     */
    public GenPrcparams findById(Integer codprc, Integer tipoproc, Integer codtpr) {
        TypedQuery<GenPrcparams> query = entityManager.createQuery(
            "SELECT g FROM GenPrcparams g WHERE g.prpCodprc = :codprc AND g.prpTipoproc = :tipoproc and g.prpCodtpr = :codtpr ",
            GenPrcparams.class
        );
        query.setParameter("codprc", codprc);
        query.setParameter("tipoproc", tipoproc);
        query.setParameter("codtpr", codtpr);        
        List<GenPrcparams> results = query.getResultList();
        if (results.size() > 0) {
            return results.get(0);
        }
        return null;
    }
    
    /**
     * Actualiza el valor de un parámetro
     */
    public GenPrcparams saveUpdateGenP(GenPrcparams genPrcparams) {
        entityManager.merge(genPrcparams);
        GenPrcparams gnew = findById(genPrcparams.getPrpCodprc(), genPrcparams.getPrpTipoproc(), genPrcparams.getPrpCodtpr());
        return gnew;
    }
    
    /**
     * Actualiza montos de un parámetro
     */
    public int updateMontos(Integer codPrc, String tipoProc, Integer codTpr, 
                           BigDecimal montoMo, BigDecimal montoMn) {
        return entityManager.createQuery(
            "UPDATE GenPrcparams g SET g.prpMontomo = :montoMo, g.prpMontomn = :montoMn " +
            "WHERE g.prpCodprc = :codPrc AND g.prpTipoproc = :tipoProc AND g.prpCodtpr = :codTpr"
        )
        .setParameter("montoMo", montoMo)
        .setParameter("montoMn", montoMn)
        .setParameter("codPrc", codPrc)
        .setParameter("tipoProc", tipoProc)
        .setParameter("codTpr", codTpr)
        .executeUpdate();
    }
    
    /**
     * Elimina parámetros por código de proceso
     */
    public int deleteByCodPrc(Integer codPrc) {
        return entityManager.createQuery(
            "DELETE FROM GenPrcparams g WHERE g.prpCodprc = :codPrc"
        )
        .setParameter("codPrc", codPrc)
        .executeUpdate();
    }
    

    protected EntityManager entityManager() {
        return entityManager;
    }

    

}
