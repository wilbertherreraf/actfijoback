/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.NormativaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.NormativaQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.NormativaDao;
import gob.bcb.jee.creditos.entidades.Normativa;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.excepciones.ValidatorViewException;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Cttes;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Normativa
 * 
 * 
 * @author ysalinas
 * 
 */
@Stateless
@LocalBean
public class NormativaBLLocalImpl extends
    GenericBLLocalImpl<Normativa, Integer>
    implements NormativaBLLocal
{
  private static Logger log = Logger.getLogger(NormativaBLLocalImpl.class);

  @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
  EntityManager em;
  /*
   * Inyeccion de los metodos para consulta (QL)
   */
  @Inject
  NormativaQLLocal normativaQLLocal;

  @Inject
  NormativaDao normativaDao;

  @Override
  public GenericQLLocal<Normativa, Integer> getQLBean()
  {
    return normativaQLLocal;
  }

  /*
   * (non-Javadoc)
   * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
   */
  @Override
  public GenericDao<Normativa, Integer> getGenericDao()
  {
    return normativaDao;
  }

  @Override
  public void validar(Normativa entity) throws OperationException
  {

    log.trace("Validar¡ a el documento requerido: " + entity);
    if (entity == null)
    {
      throw new ValidatorViewException("No se puede guardar la Normativa", "codRecurso");
    }

    if (Strings.isNullOrEmpty(entity.getNombre()))
    {
      throw new ValidatorViewException("El nombre es requerido", "nombre");
    }

  }

  @Override
  public void changeEstate(Integer id, Estado estado) throws OperationException
  {
    super.changeEstate(id, estado);
  }

  /*
   * (non-Javadoc)
   * @see gob.bcb.jee.creditos.BL.NormativaBLLocal#listarNormativas()
   */
  @Override
  public List<Normativa> listarNormativas() throws OperationException
  {
    List<Normativa> lista = new ArrayList<Normativa>();
    try
    {
      log.info("ENTRA AQUI....");
      lista = new ArrayList<Normativa>();
      lista = normativaQLLocal.listByNamedQuery(Normativa.NQ_SEARCH_ALL, ImmutableMap.of("estado", (Object) (Estado.A)));
    }
    catch (Exception e)
    {
      log.error("Error al obtener filtro.", e);
    }
    return lista;
  }
}
