package gob.bcb.jee.creditos.entidades;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "gen_prcparams")
@IdClass(GenPrcparamsPK.class)
public class GenPrcparams implements Serializable {
    
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "prp_codprc", nullable = false)
    private Integer prpCodprc;

    @Id
    @Column(name = "prp_tipoproc", nullable = false)
    private Integer prpTipoproc;

    @Id
    @Column(name = "prp_codtpr", nullable = false)
    private Integer prpCodtpr;

    @Column(name = "prp_codlit")
    private String prpCodlit;

    @Column(name = "prp_value")
    private String prpValue;

    @Column(name = "prp_numtrx")
    private Integer prpNumtrx;

    @Column(name = "prp_nroreng")
    private Integer prpNroreng;

    @Column(name = "prp_codcob")
    private Integer prpCodcob;

    @Column(name = "prp_montomo")
    private BigDecimal prpMontomo;

    @Column(name = "prp_montomn")
    private BigDecimal prpMontomn;

    @Column(name = "prp_dh")
    private String prpDh;

    @Column(name = "prp_glosa")
    private String prpGlosa;
    
    @Column(name = "prp_mayor")
    private String prpMayor;

    @Column(name = "prp_nroafectable")
    private String prpNroafectable;

    @Column(name = "prp_ctamov")
    private String prpCtamov;

    @Column(name = "prp_nrocp")
    private String prpNrocp;

    // Constructores
    public GenPrcparams() {
    }

    // Getters y Setters
    public Integer getPrpCodprc() {
        return prpCodprc;
    }

    public void setPrpCodprc(Integer prpCodprc) {
        this.prpCodprc = prpCodprc;
    }

    public Integer getPrpTipoproc() {
        return prpTipoproc;
    }

    public void setPrpTipoproc(Integer prpTipoproc) {
        this.prpTipoproc = prpTipoproc;
    }

    public Integer getPrpCodtpr() {
        return prpCodtpr;
    }

    public void setPrpCodtpr(Integer prpCodtpr) {
        this.prpCodtpr = prpCodtpr;
    }

    public String getPrpCodlit() {
        return prpCodlit;
    }

    public void setPrpCodlit(String prpCodlit) {
        this.prpCodlit = prpCodlit;
    }

    public String getPrpValue() {
        return prpValue;
    }

    public void setPrpValue(String prpValue) {
        this.prpValue = prpValue;
    }

    public Integer getPrpNumtrx() {
        return prpNumtrx;
    }

    public void setPrpNumtrx(Integer prpNumtrx) {
        this.prpNumtrx = prpNumtrx;
    }

    public Integer getPrpCodcob() {
        return prpCodcob;
    }

    public void setPrpCodcob(Integer prpCodcob) {
        this.prpCodcob = prpCodcob;
    }

    public BigDecimal getPrpMontomo() {
        return prpMontomo;
    }

    public void setPrpMontomo(BigDecimal prpMontomo) {
        this.prpMontomo = prpMontomo;
    }

    public BigDecimal getPrpMontomn() {
        return prpMontomn;
    }

    public void setPrpMontomn(BigDecimal prpMontomn) {
        this.prpMontomn = prpMontomn;
    }

    public String getPrpDh() {
        return prpDh;
    }

    public void setPrpDh(String prpDh) {
        this.prpDh = prpDh;
    }

    public String getPrpMayor() {
        return prpMayor;
    }

    public void setPrpMayor(String prpMayor) {
        this.prpMayor = prpMayor;
    }

    public String getPrpNroafectable() {
        return prpNroafectable;
    }

    public void setPrpNroafectable(String prpNroafectable) {
        this.prpNroafectable = prpNroafectable;
    }

    public String getPrpCtamov() {
        return prpCtamov;
    }

    public void setPrpCtamov(String prpCtamov) {
        this.prpCtamov = prpCtamov;
    }

    public String getPrpGlosa() {
        return prpGlosa;
    }

    public void setPrpGlosa(String prpGlosa) {
        this.prpGlosa = prpGlosa;
    }

    public Integer getPrpNroreng() {
        return prpNroreng;
    }

    public void setPrpNroreng(Integer prpNroreng) {
        this.prpNroreng = prpNroreng;
    }
    
    public String getPrpNrocp() {
        return prpNrocp;
    }

    public void setPrpNrocp(String prpNrocp) {
        this.prpNrocp = prpNrocp;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        GenPrcparams that = (GenPrcparams) o;

        if (!prpCodprc.equals(that.prpCodprc)) return false;
        if (!prpTipoproc.equals(that.prpTipoproc)) return false;
        return prpCodtpr.equals(that.prpCodtpr);
    }

    @Override
    public int hashCode() {
        int result = prpCodprc.hashCode();
        result = 31 * result + prpTipoproc.hashCode();
        result = 31 * result + prpCodtpr.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "GenPrcparams{" +
                "prpCodprc=" + prpCodprc +
                ", prpTipoproc='" + prpTipoproc + '\'' +
                ", prpCodtpr=" + prpCodtpr +
                ", prpCodlit='" + prpCodlit + '\'' +
                ", prpValue='" + prpValue + '\'' +
                ", prpNumtrx=" + prpNumtrx +
                ", prpCodcob=" + prpCodcob +
                ", prpMontomo=" + prpMontomo +
                ", prpMontomn=" + prpMontomn +
                ", prpDh='" + prpDh + '\'' +
                ", prpMayor='" + prpMayor + '\'' +
                ", prpNroafectable='" + prpNroafectable + '\'' +
                ", prpCtamov='" + prpCtamov + '\'' +
                '}';
    }
}