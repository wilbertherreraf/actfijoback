package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.entidades
 * 13/09/2016 - 12:17 PM
 * Creado por aescobar
 */
@Getter
@Setter
@Entity
@Table(name = "DEVENGADO")
public class Devengado extends Entidad<Long>{

    public static final String ENTITY = "Devengado";
    public static final String NQ_SEARCH_ALL = ENTITY + "SearchAll";
    public static final String NQ_SEARCH_BY_FILTER = ENTITY + "SearchByFilter";
    public static final String NQ_GET_BY_PAGO = ENTITY + "GetByPago";
    public static final String NQ_GET_BY_PAGO_EFECTIVO = ENTITY + "GetByPagoEfectivo";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", updatable = false)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PROYECTO", referencedColumnName = "ID")
    private Proyecto proyecto;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PAGO", referencedColumnName = "ID")
    private Pago pago;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PAGO_EFECTIVO", referencedColumnName = "ID")
    private Pago pagoEfectivo;

    @Column(name = "FECHA_DEVENGADO", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaDevengado;

    @Column(name = "NUMERO")
    private Integer numero;

    @Column(name = "DIAS")
    private Integer dias;

    @Column(name = "MONTO_INTERES", columnDefinition = "DECIMAL(15,8)",
            precision = 15, scale = 8, nullable = false)
    private BigDecimal montoInteres;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "LOG_AUDITORIA_ID")
    private LogAuditoria logAuditoria;

    public Devengado() {
    }

    public Devengado(Proyecto proyecto, Date fechaDevengado, Integer numero, Integer dias, BigDecimal montoInteres, LogAuditoria logAuditoria) {
        this.proyecto = proyecto;
        this.fechaDevengado = fechaDevengado;
        this.numero = numero;
        this.dias = dias;
        this.montoInteres = montoInteres;
        this.logAuditoria = logAuditoria;
    }

    @Override
    public String toString() {
        return "Devengado{" +
                "id=" + id +
                ", proyecto=" + proyecto +
                ", fechaDevengado=" + fechaDevengado +
                ", numero=" + numero +
                ", dias=" + dias +
                ", montoInteres=" + montoInteres +
                ", logAuditoria=" + logAuditoria +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Devengado)) return false;

        Devengado devengado = (Devengado) o;

        if (id != null ? !id.equals(devengado.id) : devengado.id != null) return false;
        if (proyecto != null ? !proyecto.equals(devengado.proyecto) : devengado.proyecto != null) return false;
        if (fechaDevengado != null ? !fechaDevengado.equals(devengado.fechaDevengado) : devengado.fechaDevengado != null)
            return false;
        if (numero != null ? !numero.equals(devengado.numero) : devengado.numero != null) return false;
        if (dias != null ? !dias.equals(devengado.dias) : devengado.dias != null) return false;
        if (montoInteres != null ? !montoInteres.equals(devengado.montoInteres) : devengado.montoInteres != null)
            return false;
        return !(logAuditoria != null ? !logAuditoria.equals(devengado.logAuditoria) : devengado.logAuditoria != null);

    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (proyecto != null ? proyecto.hashCode() : 0);
        result = 31 * result + (fechaDevengado != null ? fechaDevengado.hashCode() : 0);
        result = 31 * result + (numero != null ? numero.hashCode() : 0);
        result = 31 * result + (dias != null ? dias.hashCode() : 0);
        result = 31 * result + (montoInteres != null ? montoInteres.hashCode() : 0);
        result = 31 * result + (logAuditoria != null ? logAuditoria.hashCode() : 0);
        return result;
    }

    public String getMontoInteresFormat(){
        return getDecimalDosFormat(montoInteres);
    }

    public String getFechaDevengadoFormat(){
        return getDateFormat(fechaDevengado);
    }
}
