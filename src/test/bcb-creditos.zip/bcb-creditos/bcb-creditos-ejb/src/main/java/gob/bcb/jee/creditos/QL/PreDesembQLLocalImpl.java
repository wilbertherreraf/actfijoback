/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import gob.bcb.jee.creditos.BL.PrePrccontaBLLocalImpl;
import gob.bcb.jee.creditos.entidades.EstadoDesembolsosQuery;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PreDesembQLLocalImpl extends GenericQLLocalImpl<PreDesemb, Integer> implements PreDesembQLLocal {
	private static final Logger log = LoggerFactory.getLogger(PrePrccontaBLLocalImpl.class);
	@PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
	private EntityManager entityManager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
	 * ()
	 */
	@Override
	protected EntityManager entityManager() {
		return entityManager;
	}

	@Override
	public Integer getNewId() throws OperationException {
		String nativeQuery = "select max(dsb_coddsb) from pre_desemb ";
		Query query = entityManager.createNativeQuery(nativeQuery);
		Object valor = query.getSingleResult();
		int id = 1;
		if (valor != null) {
			id = Integer.parseInt(valor.toString()) + 1;
		}
		return id;
	}

	public List<PreDesemb> dsbByCodCred(Integer codcred, Integer codmod) {
		String nativeQuery = "select t from PreDesemb t where t.dsbCodcred = :codcred " +
		"and t.dsbCodmod = :codmod";
		Query query = entityManager.createQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);	

		List valor = query.getResultList();
		return valor;
	}


	public PreDesemb getByCoddsb(Integer coddsb) {
		String nativeQuery = "select t from PreDesemb t where t.dsbCoddsb = :coddsb ";
		Query query = entityManager.createQuery(nativeQuery).setParameter("coddsb", coddsb);
		List valor = query.getResultList();
		int id = 1;
		if (valor.size() > 0) {
			return (PreDesemb) valor.get(0);
		}
		return null;
	}


	@Override
	public BigDecimal getDisponibleDesembolso(Integer codcred, Integer codmod) throws OperationException {
		String nativeQuery = "call d_creditos.f_getamtundsb(:valor1, :valor2, :valor3)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);
		query.setParameter("valor3", null);
		// query.setParameter("valor4",null);
		Object valor = query.getSingleResult();
		BigDecimal valorD = BigDecimal.ZERO;
		if (valor != null) {
			valorD = new BigDecimal(valor.toString());
		}
		return valorD;
	}

	@Override
	public Integer generarPlanDePagosDsb(Integer codcred, Integer codmod, Integer coddsb, Integer codmodtmp,
			String usuario, String ip) throws OperationException {
		log.info("Creando planp " + coddsb);
		String nativeQuery = "call d_creditos.p_generar_planpagosnue(:codcred, :codmod, :coddsb, :codmodtmp, :usuario, :ip)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);
		query.setParameter("coddsb", coddsb);
		query.setParameter("codmodtmp", codmodtmp);
		query.setParameter("usuario", usuario);
		query.setParameter("ip", ip);
		Object valor = query.getSingleResult();
		int valorD = 0;
		if (valor != null) {
			valorD = Integer.parseInt(valor.toString());
		}
		Log.Info(valorD);
		return valorD;
	}

	@Override
	public void autorizarPlanDePagos(Integer p_codcred, Integer p_codmod, Integer p_coddsb, Integer p_codmodtmp,
			String cod_user, String ip) throws OperationException {
		String nativeQuery = "call d_creditos.p_cpy_auxpp_planpagos(:valor1, :valor2, :valor3, :valor4, :valor5, :valor6)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", p_codcred);
		query.setParameter("valor2", p_codmod);
		query.setParameter("valor3", p_coddsb);
		query.setParameter("valor4", p_codmodtmp);
		query.setParameter("valor5", cod_user);
		query.setParameter("valor6", ip);
		query.executeUpdate();
	}

	@Override
	public void aprobarDesembolso(Integer p_codcred, Integer p_codmod, Integer p_coddsb, Date fecha, Date fechaOpera,
			Integer accion,
			String cod_user, String estacion) throws OperationException {
		String nativeQuery = "call d_creditos.p_generar_operacion(:valor1, :valor2, :valor3, :valor4, :valor5, :valor6, :valor7, :valor8)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", p_codcred);
		query.setParameter("valor2", p_codmod);
		query.setParameter("valor3", p_coddsb);
		query.setParameter("valor4", fecha);
		query.setParameter("valor5", fechaOpera);
		query.setParameter("valor6", accion);
		query.setParameter("valor7", cod_user);
		query.setParameter("valor8", estacion);
		query.executeUpdate();
	}

	public void eliminarDesembolso(Integer p_coddsb, String cod_user, String estacion) throws OperationException {
		String nativeQuery = "call d_creditos.p_dsb_elim_dsb(:valor1, :valor2, :valor3)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", p_coddsb);
		query.setParameter("valor2", cod_user);
		query.setParameter("valor3", estacion);
		query.executeUpdate();
	}

	@Override
	public Integer obtenerCodClientePorCodDesembolso(Integer pCodDesembolso) {
		String nativeQuery = "select p. pre_codcli " +
				"from d_creditos.pre_desemb d, d_creditos.pre_prestamos p " +
				"where d.dsb_codcred=p.pre_codcred  " +
				"and d.dsb_codmod=p.pre_codmod " +
				"and d.dsb_coddsb=:dsb_coddsb ";

		Object codCliente = null;
		try {
			Query query = entityManager.createNativeQuery(nativeQuery).setParameter("dsb_coddsb", pCodDesembolso);
			codCliente = query.getSingleResult();
			;
		} catch (NoResultException e) {
			String error = "Error al recuperar el cod cliente para : " + pCodDesembolso;
			log.error(error);
		}

		return (codCliente != null ? Integer.valueOf(codCliente.toString()) : null);
	}

	public List<EstadoDesembolsosQuery> estadoDesembolsosAFecha(Integer codcred, Integer codmod, Integer coddsb,
			Date fechaVencimiento) {
		if (codcred == null || codmod == null || fechaVencimiento == null) {
			return new ArrayList<>();
		}
		String nativeQuery = "select * ";
		nativeQuery += "from v_planpagos_resu ";
		nativeQuery += "where codcred = :codcred ";
		nativeQuery += "and codmod = :codmod ";
		if (coddsb != null)
			nativeQuery += "and coddsb = :coddsb ";
		nativeQuery += "and fecha = :fechaVencimiento ";
		nativeQuery += "order by fecha,coddsb ";

		Query query = entityManager.createNativeQuery(nativeQuery, EstadoDesembolsosQuery.class);
		query.setParameter("fechaVencimiento", fechaVencimiento, TemporalType.DATE);
		query.setParameter("codcred", codcred);
		if (coddsb != null)
			query.setParameter("coddsb", coddsb);
		query.setParameter("codmod", codmod);

		List list = query.getResultList();
		return list;

	}// en method

	public BigDecimal devengadoPorCredAFech(Date fechaVencimiento) {
		if (fechaVencimiento == null) {
			return BigDecimal.ZERO;
		}
		StringBuilder sb = new StringBuilder();
		sb.append("select sum(int_devengado) ");
		sb.append("from pre_prestamos, v_planpagos_resu v ");
		sb.append("where fecha = :fechaVencimiento ");
		sb.append("and codcred = pre_codcred ");
		sb.append("and codmod = pre_codmod ");
		sb.append("and pre_status = 2 ");

		Query query = entityManager.createNativeQuery(sb.toString());
		query.setParameter("fechaVencimiento", fechaVencimiento, TemporalType.DATE);

		Object valor = query.getSingleResult();
		BigDecimal valorD = BigDecimal.ZERO;
		if (valor != null) {
			valorD = new BigDecimal(valor.toString());
		}
		return valorD;

	}// en method
}
