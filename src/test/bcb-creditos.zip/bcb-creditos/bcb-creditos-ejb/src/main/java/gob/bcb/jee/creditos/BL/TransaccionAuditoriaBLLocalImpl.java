package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.TransaccionAuditoriaQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.TransaccionAuditoriaDao;
import gob.bcb.jee.creditos.entidades.TransaccionAuditoria;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.excepciones.ValidatorViewException;
import gob.bcb.jee.creditos.numeradores.Estado;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.BL
 * 28/06/2016 - 10:56 AM
 * Created por aescobar
 */

@Stateless
@LocalBean
public class TransaccionAuditoriaBLLocalImpl extends
        GenericBLLocalImpl<TransaccionAuditoria, String>
        implements TransaccionAuditoriaBLLocal
{
  
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    TransaccionAuditoriaQLLocal transaccionAuditoriaQLLocal;

    @Inject
    TransaccionAuditoriaDao transaccionAuditoriaDao;

    @Override
    public GenericQLLocal<TransaccionAuditoria, String> getQLBean()
    {
        return transaccionAuditoriaQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<TransaccionAuditoria, String> getGenericDao()
    {
        return transaccionAuditoriaDao;
    }

    @Override
    public void validar(TransaccionAuditoria entity) throws OperationException
    {

        log.trace("Validar¡ a el documento requerido: " + entity);
        if (entity == null)
        {
            throw new ValidatorViewException("No se puede guardar un documento NULL", "id");
        }

    }

    @Override
    public void changeEstate(String id, Estado estado) throws OperationException
    {
        super.changeEstate(id, estado);
    }
}

