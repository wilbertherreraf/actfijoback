package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.NormativaEmpresa;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Banco Central de Bolivia Usuario: Ariel Escobar Fecha: 2/6/2016 Hora: 9:22:30
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class NormativaEmpresaQLLocalImpl extends
    GenericQLLocalImpl<NormativaEmpresa, Integer> implements
        NormativaEmpresaQLLocal
{
  @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
  private EntityManager entityManager;

  /*
   * (non-Javadoc)
   * @see gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager ()
   */
  @Override
  protected EntityManager entityManager()
  {
    return entityManager;
  }

}
