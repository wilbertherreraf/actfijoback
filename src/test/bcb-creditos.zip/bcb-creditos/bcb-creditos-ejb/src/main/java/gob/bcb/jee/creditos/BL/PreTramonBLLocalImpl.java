/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import com.google.common.base.Strings;

import gob.bcb.jee.creditos.QL.CliPersonaQLLocal;
import gob.bcb.jee.creditos.QL.GenDesctablaQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.ParametrosQLLocal;
import gob.bcb.jee.creditos.QL.PreTramonQLLocal;
import gob.bcb.jee.creditos.dao.CliPersonaDao;
import gob.bcb.jee.creditos.dao.GenDesctablaDao;
import gob.bcb.jee.creditos.dao.GenericDao;

import gob.bcb.jee.creditos.dao.PreTramonDao;
import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenDesctablaPK;
import gob.bcb.jee.creditos.model.PreTramon;
import gob.bcb.jee.creditos.model.PreTramonPK;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.UtilFormat;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class PreTramonBLLocalImpl extends
        GenericBLLocalImpl<PreTramon, PreTramonPK>
        implements PreTramonBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    PreTramonQLLocal parametrosQLLocal;

    @Inject
    PreTramonDao parametroDao;

    @Override
    public GenericQLLocal<PreTramon, PreTramonPK> getQLBean() {
        return parametrosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<PreTramon, PreTramonPK> getGenericDao() {
        return parametroDao;
    }

	@Override
	public void validar(PreTramon entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void reversaTransaccion(Integer codcred,Integer codmod,Integer numtrx, Date fechaOper,String usuario, String estacion)throws OperationException,SQLException{
		parametrosQLLocal.reversaTransaccion(codcred, codmod, numtrx, fechaOper, usuario, estacion);
	}

	@Override
	public void reversaTransaccionDif(Integer codcred,Integer codmod,Integer tipotrx, Date fecha, String usuario, String estacion)
			throws OperationException, SQLException {
		parametrosQLLocal.reversaTransaccionDif(codcred, codmod, tipotrx, fecha, usuario, estacion);
		
	}

}
