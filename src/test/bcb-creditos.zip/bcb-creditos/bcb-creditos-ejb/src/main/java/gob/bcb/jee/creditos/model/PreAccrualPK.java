package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the pre_accrual database table.
 * 
 */
@Embeddable
public class PreAccrualPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="acr_codmod", insertable=false, updatable=false)
	private Integer acrCodmod;

	@Column(name="acr_numoper")
	private Integer acrNumoper;

	@Temporal(TemporalType.DATE)
	@Column(name="acr_fecha")
	private java.util.Date acrFecha;

	public PreAccrualPK() {
	}
	public Integer getAcrCodmod() {
		return this.acrCodmod;
	}
	public void setAcrCodmod(Integer acrCodmod) {
		this.acrCodmod = acrCodmod;
	}
	public Integer getAcrNumoper() {
		return this.acrNumoper;
	}
	public void setAcrNumoper(Integer acrNumoper) {
		this.acrNumoper = acrNumoper;
	}
	public java.util.Date getAcrFecha() {
		return this.acrFecha;
	}
	public void setAcrFecha(java.util.Date acrFecha) {
		this.acrFecha = acrFecha;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PreAccrualPK)) {
			return false;
		}
		PreAccrualPK castOther = (PreAccrualPK)other;
		return 
			(this.acrCodmod == castOther.acrCodmod)
			&& (this.acrNumoper == castOther.acrNumoper)
			&& this.acrFecha.equals(castOther.acrFecha);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.acrCodmod;
		hash = hash * prime + this.acrNumoper;
		hash = hash * prime + this.acrFecha.hashCode();
		
		return hash;
	}
}
