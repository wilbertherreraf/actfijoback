package gob.bcb.jee.creditos.QL;
import gob.bcb.jee.creditos.entidades.CondicionesFinancieras;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.QL
 * 29/11/2016 - 13:30 PM
 * Creado por aescobar
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class CondicionesFinancierasQLLocalImpl extends
    GenericQLLocalImpl<CondicionesFinancieras, Long> implements
        CondicionesFinancierasQLLocal
{
  @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
  private EntityManager entityManager;

  @Override
  protected EntityManager entityManager()
  {
    return entityManager;
  }

}