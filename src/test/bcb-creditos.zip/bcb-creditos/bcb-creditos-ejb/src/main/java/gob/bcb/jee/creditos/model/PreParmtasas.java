package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the pre_parmtasas database table.
 * 
 */
@Entity
@Table(name="pre_parmtasas")
@NamedQuery(name="PreParmtasas.findAll", query="SELECT p FROM PreParmtasas p")
public class PreParmtasas implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PreParmtasasPK id;

	@Column(name="pta_acttextpr")
	private String ptaActtextpr;

	@Column(name="pta_auditfho")
	private Timestamp ptaAuditfho;

	@Column(name="pta_audittrx")
	private String ptaAudittrx;

	@Column(name="pta_auditusr")
	private String ptaAuditusr;

	@Column(name="pta_auditwst")
	private String ptaAuditwst;

	@Column(name="pta_tabtrxstaau")
	private Integer ptaTabtrxstaau;

	@Column(name="pta_tasa")
	private Double ptaTasa;

	@Column(name="pta_trxstaau")
	private Integer ptaTrxstaau;

	public PreParmtasas() {
	}

	public PreParmtasasPK getId() {
		return this.id;
	}

	public void setId(PreParmtasasPK id) {
		this.id = id;
	}

	public String getPtaActtextpr() {
		return this.ptaActtextpr;
	}

	public void setPtaActtextpr(String ptaActtextpr) {
		this.ptaActtextpr = ptaActtextpr;
	}

	public Timestamp getPtaAuditfho() {
		return this.ptaAuditfho;
	}

	public void setPtaAuditfho(Timestamp ptaAuditfho) {
		this.ptaAuditfho = ptaAuditfho;
	}

	public String getPtaAudittrx() {
		return this.ptaAudittrx;
	}

	public void setPtaAudittrx(String ptaAudittrx) {
		this.ptaAudittrx = ptaAudittrx;
	}

	public String getPtaAuditusr() {
		return this.ptaAuditusr;
	}

	public void setPtaAuditusr(String ptaAuditusr) {
		this.ptaAuditusr = ptaAuditusr;
	}

	public String getPtaAuditwst() {
		return this.ptaAuditwst;
	}

	public void setPtaAuditwst(String ptaAuditwst) {
		this.ptaAuditwst = ptaAuditwst;
	}

	public Integer getPtaTabtrxstaau() {
		return this.ptaTabtrxstaau;
	}

	public void setPtaTabtrxstaau(Integer ptaTabtrxstaau) {
		this.ptaTabtrxstaau = ptaTabtrxstaau;
	}

	public Double getPtaTasa() {
		return this.ptaTasa;
	}

	public void setPtaTasa(Double ptaTasa) {
		this.ptaTasa = ptaTasa;
	}

	public Integer getPtaTrxstaau() {
		return this.ptaTrxstaau;
	}

	public void setPtaTrxstaau(Integer ptaTrxstaau) {
		this.ptaTrxstaau = ptaTrxstaau;
	}

}
