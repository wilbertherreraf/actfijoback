/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreGarantiad;
import gob.bcb.jee.creditos.util.Cttes;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.text.SimpleDateFormat;
import java.util.HashMap;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 * @author hpanique
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PreGarantiadQLLocalImpl extends
        GenericQLLocalImpl<PreGarantiad, Integer> implements
        PreGarantiadQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

    @Override
    public Integer getNewId()throws OperationException {
        String nativeQuery="select max(gard_cod) from pre_garantiad ";
        Query query=entityManager.createNativeQuery(nativeQuery);
        Object valor=query.getSingleResult();
        int id=1;
        if(valor!=null) {
            id=Integer.parseInt(valor.toString())+1;
        }
        return id;
    }

    @Override
    public PreGarantiad getByDsb(Integer valor1, Integer valor2, Integer valor3)    {
        HashMap<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("valor1", valor1);
        parameters.put("valor2", valor2);
        parameters.put("valor3", valor3);
        return getByNamedQuery(PreGarantiad.NQ_GET_BY_DSB, parameters);
    }
}

