package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the gen_identasex database table.
 * 
 */
@Entity
@Table(name="gen_identasex")
@NamedQuery(name="GenIdentasex.findAll", query="SELECT g FROM GenIdentasex g")
public class GenIdentasex implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private GenIdentasexPK id;

	@Column(name="ite_auditfho")
	private Timestamp iteAuditfho;

	@Column(name="ite_audittrx")
	private String iteAudittrx;

	@Column(name="ite_auditusr")
	private String iteAuditusr;

	@Column(name="ite_auditwst")
	private String iteAuditwst;

	@Column(name="ite_tabtrxstaau")
	private Integer iteTabtrxstaau;

	@Column(name="ite_tabttasaex")
	private Integer iteTabttasaex;

	@Column(name="ite_trxstaau")
	private Integer iteTrxstaau;

	public GenIdentasex() {
	}

	public GenIdentasexPK getId() {
		return this.id;
	}

	public void setId(GenIdentasexPK id) {
		this.id = id;
	}

	public Timestamp getIteAuditfho() {
		return this.iteAuditfho;
	}

	public void setIteAuditfho(Timestamp iteAuditfho) {
		this.iteAuditfho = iteAuditfho;
	}

	public String getIteAudittrx() {
		return this.iteAudittrx;
	}

	public void setIteAudittrx(String iteAudittrx) {
		this.iteAudittrx = iteAudittrx;
	}

	public String getIteAuditusr() {
		return this.iteAuditusr;
	}

	public void setIteAuditusr(String iteAuditusr) {
		this.iteAuditusr = iteAuditusr;
	}

	public String getIteAuditwst() {
		return this.iteAuditwst;
	}

	public void setIteAuditwst(String iteAuditwst) {
		this.iteAuditwst = iteAuditwst;
	}

	public Integer getIteTabtrxstaau() {
		return this.iteTabtrxstaau;
	}

	public void setIteTabtrxstaau(Integer iteTabtrxstaau) {
		this.iteTabtrxstaau = iteTabtrxstaau;
	}

	public Integer getIteTabttasaex() {
		return this.iteTabttasaex;
	}

	public void setIteTabttasaex(Integer iteTabttasaex) {
		this.iteTabttasaex = iteTabttasaex;
	}

	public Integer getIteTrxstaau() {
		return this.iteTrxstaau;
	}

	public void setIteTrxstaau(Integer iteTrxstaau) {
		this.iteTrxstaau = iteTrxstaau;
	}

}
