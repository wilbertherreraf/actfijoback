/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.model.SacClaves;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class SacClavesQLLocalImpl extends
        GenericQLLocalImpl<SacClaves, String> implements
        SacClavesQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /*
     * (non-Javadoc)
     * @see
     * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
     * ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
	

}
