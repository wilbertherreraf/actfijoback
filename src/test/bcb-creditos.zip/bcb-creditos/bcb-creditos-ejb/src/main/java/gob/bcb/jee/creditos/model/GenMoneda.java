package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;


/**
 * The persistent class for the gen_moneda database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="gen_moneda")
@NamedQuery(name="GenMoneda.findAll", query="SELECT g FROM GenMoneda g")
public class GenMoneda  extends EntidadAutorizable<Integer> implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="mon_codmon")
	private Integer monCodmon;

	@Column(name="mon_abrev")
	private String monAbrev;

	@Column(name="mon_codmoncoin")
	private String monCodmoncoin;

	@Column(name="mon_descrip")
	private String monDescrip;

	public GenMoneda() {
	}

	@Override
	public Integer getId() {
		// TODO Auto-generated method stub
		return this.monCodmon;
	}

	@Override
	public void setId(Integer id) {
		this.monCodmon=id;
		
	}

	

}
