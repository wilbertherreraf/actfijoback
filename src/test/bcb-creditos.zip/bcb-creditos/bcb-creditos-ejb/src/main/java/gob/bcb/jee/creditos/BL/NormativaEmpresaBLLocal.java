package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.NormativaEmpresa;
import gob.bcb.jee.creditos.excepciones.OperationException;

import javax.ejb.Local;
import java.math.BigDecimal;
import java.util.List;

/**
 * Banco Central de Bolivia Usuario: Ariel Escobar Fecha: 2/6/2016 Hora: 9:17:50
 */

@Local
public interface NormativaEmpresaBLLocal extends
		GenericBLLocal<NormativaEmpresa, Integer> {

	List<NormativaEmpresa> listByEmpresa(Integer empresaId)
			throws OperationException;
	
	List<NormativaEmpresa> listByNormativa(Integer normativaId)
		      throws OperationException;

	BigDecimal getMontoLeyByEmpresa(Integer empresaId)throws OperationException;
}
