package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.GenParametro;
import gob.bcb.jee.creditos.excepciones.OperationException;

import javax.ejb.Local;
import java.util.List;

/**
 * GenParametroQLLocal
 *
 * @author mcramos
 * 13/01/2025
 */
@Local
public interface GenParametroQLLocal extends
        GenericQLLocal<GenParametro, Integer>  {

    List<GenParametro> obtenerPorCodCredito(Integer pCodCred);

    String getNumeroCuenta(Integer codcred,Integer codmod,Integer tipo) throws OperationException;
}
