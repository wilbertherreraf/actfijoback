package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the pre_accrual database table.
 * 
 */
@Entity
@Table(name="pre_accrual")
@Getter
@Setter
@NamedQuery(name="PreAccrual.findAll", query="SELECT p FROM PreAccrual p")
public class PreAccrual implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @Column(name = "acr_codacr")
    private Integer acrCodacr;

    @Column(name = "acr_codmod")
    private Integer acrCodmod;

    @Column(name = "acr_codcred")
    private Integer acrCodcred;

	@Temporal(TemporalType.DATE)
    @Column(name = "acr_fecaccru")
    private Date acrFecaccru;

    @Column(name = "acr_tabtipoacr")
    private Integer acrTabtipoacr;

    @Column(name = "acr_tipoacr")
    private Integer acrTipoacr;

    @Column(name = "acr_codcli")
    private Integer acrCodcli;

    @Column(name = "acr_diasaccr")
    private Integer acrDiasaccr;

	@Temporal(TemporalType.DATE)
    @Column(name = "acr_fecini")
    private Date acrFecini;

	@Temporal(TemporalType.DATE)
    @Column(name = "acr_fecfin")
    private Date acrFecfin;

	@Temporal(TemporalType.DATE)
    @Column(name = "acr_fecproc")
    private Date acrFecproc;

    @Column(name = "acr_tasavig")
    private BigDecimal acrTasavig;

    @Column(name = "acr_saldo")
    private BigDecimal acrSaldo;

    @Column(name = "acr_interes")
    private BigDecimal acrInteres;

    @Column(name = "acr_capital")
    private BigDecimal acrCapital;

    @Column(name = "acr_valor")
    private BigDecimal acrValor;

    @Column(name = "acr_valorpend")
    private BigDecimal acrValorpend;

    @Column(name = "acr_undsb")
    private BigDecimal acrUndsb;

    @Column(name = "acr_capitalper")
    private BigDecimal acrCapitalper;

    @Column(name = "acr_interesper")
    private BigDecimal acrInteresper;

    @Column(name = "acr_coddsb")
    private Integer acrCoddsb;

    @Column(name = "acr_tabtipocuo")
    private Integer acrTabtipocuo;

    @Column(name = "acr_tipocuo")
    private Integer acrTipocuo;

    @Column(name = "acr_tabstatacru")
    private Integer acrTabstatacru;

    @Column(name = "acr_statacru")
    private Integer acrStatacru;

	 @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "acr_auditfho")
    private Date acrAuditfho;

    @Column(name = "cambio_bd")
    private String cambioBd;

	public PreAccrual() {
	}

}
