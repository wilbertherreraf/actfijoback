package gob.bcb.jee.creditos.entidades;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;


@Getter
@Setter
@EqualsAndHashCode
public class VPlanPagosConsolQueryId implements Serializable {

    private Integer codmod;
    private Integer codcred;
    private Date fechavencuo;
    private Integer tipotrx;    
}
