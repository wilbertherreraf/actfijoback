/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.plantillaWebEE.negocio.GenericNegocioLocalImpl
 * 23/10/2015 - 11:06:40
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import com.google.common.io.Resources;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.entidades.Entidad;
import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Log;

import org.apache.log4j.Logger;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.persistence.LockModeType;
import javax.persistence.NoResultException;
import javax.persistence.OptimisticLockException;
import javax.persistence.Query;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

/**
 * Implementacion de los metodos de logica de negocios genericos
 *
 * @author ysalinas
 */
@SuppressWarnings("rawtypes")
public abstract class GenericBLLocalImpl<T extends Entidad, ID extends Serializable>
        implements GenericBLLocal<T, ID> {

    protected final Logger log = Logger.getLogger(this.getClass());

    @Resource
    SessionContext sessionContext;

    private static final String VALIDATOR_MESSAGE_PROPERTIES = "ValidatorMessage.properties";

    public ResourceBundle actionError;

    public Properties propertiesValidator;


    private Properties getPropertiesValidator() {

        try {
            if (propertiesValidator == null) {
                propertiesValidator = new Properties();
                propertiesValidator.load(Resources.getResource(VALIDATOR_MESSAGE_PROPERTIES).openStream());
            }
        } catch (IOException e) {
            log.error("No se puede leer el archivo de propiedades: " + VALIDATOR_MESSAGE_PROPERTIES);
        }
        return propertiesValidator;
    }

    /**
     * Metodo que obtiene un objeto a traves de un ID
     */
    @Override
    public T get(ID id) throws OperationException {
        try {
            return getQLBean().get(id);
        } catch (Exception e) {
            sessionContext.setRollbackOnly();
            log.error("Error al obtener item con id: " + id, e);
            throw new OperationException("Error al obtener item con id: " + id,
                    e);
        }
    }

    /**
     * Metodo que obtiene todas las relaciones tipo Lazy
     */
    @Override
    public T getRelacionesTipoLazy(ID id) throws OperationException {
        try {
            return getQLBean().getLazy(id);
        } catch (Exception e) {
            sessionContext.setRollbackOnly();
            log.error("Error al obtener item con id: " + id, e);
            throw new OperationException("Error al obtener item con id: " + id,
                    e);
        }
    }

    /**
     * Metodo que obtiene una lista de objetos
     */
    @Override
    public List<T> list() throws OperationException {
        try {
            return getQLBean().list();
        } catch (Exception e) {
            sessionContext.setRollbackOnly();
            log.error("Error al obtener lista de entidad", e);
            throw new OperationException("Error al obtener lista de entidad", e);
        }
    }
   
    @Override
    public  List<T> listByNamedQuery(String namedQuery)
    {

      try
      {
        return getQLBean().listByNamedQuery(namedQuery);
      }
      catch (NoResultException e)
      {
        return null;
      }
    }
    
    @Override
    public  List<T> listByNamedQuery(String namedQuery, Map<String, Object> parameters)
    {

      try
      {
        return getQLBean().listByNamedQuery(namedQuery,parameters);
      }
      catch (NoResultException e)
      {
        return null;
      }
    }
    /**
     * Metodo que obtiene una lista de objetos a traves de un filtro, llamando a
     * los metodos QL
     */
    @Override
    public List<T> list(String filtro) throws OperationException {
        try {
            log.info("Llamara a lista con filtro: " + filtro);
            return getQLBean().list(filtro);
        } catch (Exception e) {
            sessionContext.setRollbackOnly();
            log.error(
                    "Error al obtener lista de entidad con filtro: " + filtro,
                    e);
            throw new OperationException(
                    "Error al obtener lista de entidadcon filtro: " + filtro, e);
        }
    }

    /**
     * Metodo que realiza la persistencia de un objeto (adicion, modificacion),
     * llamando a los metodos
     */
    @Override
    public T persist(T entity, String usuarioRegistro) throws OperationException, EntityValidationException {
        validar(entity);
        try {
            //TODO: ELiminar comentarios despues de verificar que no son necesarios
            // entity.setFechaModificacion(new Date());
            if (entity.getId() == null) {
                // entity.setFechaAlta(new Date());
//
//                if (entity instanceof EntidadAutorizable) {
//                    entity.setEstado(Estado.P);
//                } else {
//                    entity.setEstado(Estado.A);
//                }
            }
            log.debug("Guardará: " + entity);

            return getGenericDao().persist(entity);
        } catch (Exception e) {
            sessionContext.setRollbackOnly();
            log.error("Error al persistir: " + entity, e);
            if (e.getCause() != null && e.getCause() instanceof OptimisticLockException) {
                throw new OperationException("El registro que está intentando editar fue modificado por otro usuario, por favor actualice su pantalla.", e);
            }
            throw new OperationException("Error al persistir: " + entity, e);
        }
    }

    /**
     * Metodo que realiza la persistencia de un objeto
     */
    @Override
    public T merge(T entity, String usuarioModificacion)
            throws OperationException, EntityValidationException {
        validar(entity);
        try {
            //TODO: Revisar por que se coloco este codigo
//            if (entity instanceof EntidadAutorizable) {
//                entity.setEstado(Estado.P);
//            } else {
//                entity.setEstado(Estado.A);
//            }
            return getGenericDao().merge(entity);
        } catch (Exception e) {
            sessionContext.setRollbackOnly();
            log.error("Error en el merge: " + entity, e);
            if (e.getCause() != null && e.getCause() instanceof OptimisticLockException) {
                throw new OperationException("El registro que está intentando editar fue modificado por otro usuario, por favor actualice su pantalla.", e);
            }
            throw new OperationException("Error en  el merge: " + entity, e);
        }
    }

    /**
     * Persistencia de una lista de objetos
     *
     * @param entities
     * @throws OperationException
     */
    @Override
    public void persist(List<T> entities) throws OperationException, EntityValidationException {
        for (T entity : entities) {
            validar(entity);
        }
        for (T entity : entities) {
            try {
                log.debug("Guardará: " + entity);
                getGenericDao().persist(entity);
            } catch (Exception e) {
                sessionContext.setRollbackOnly();
                log.error("Error al persistir: " + entity, e);
                throw new OperationException("Error al persistir: " + entity, e);
            }
        }

    }

    /**
     * Metodo para ser implementando en cada entidad para la validacion de negocio
     *
     * @param entity
     * @throws OperationException
     */
    // public void validar(T entity) throws OperationException
    // {
    // initMessages();
    // if (entity == null)
    // {
    // log.info("Error, el objeto es nulo no se pudo regisrar los datos ingresados");
    // throw new OperationException(getActionError("entity.nulo"));
    // }
    // }
    public abstract void validar(T entity) throws OperationException, EntityValidationException;

    public abstract GenericQLLocal<T, ID> getQLBean();

    public abstract GenericDao<T, ID> getGenericDao();

    // public void initMessages()
    // {
    // Locale locale = new Locale("es", "ES");
    // actionError = ResourceBundle.getBundle(VALIDATOR_MESSAGE_PROPERTIES,
    // locale);
    // }
    //
    // public String getActionError(String name)
    // {
    // name = "error." + name;
    // try
    // {
    // return actionError.getString(name);
    // }
    // catch (Exception e)
    // {
    // log.error("No se encontro el mensaje :" + name);
    // return "No se encontro el mensaje :" + name;
    // }
    //
    // }

    /**
     * Metodo que obtiene un obejto con sus dependencias, llamando a los metodos
     * QL
     */
    @Override
    public T getLazy(ID id) throws OperationException {
        try {
            return getQLBean().getLazy(id);
        } catch (Exception e) {
            sessionContext.setRollbackOnly();
            log.error("Error al obtener item con id: " + id, e);
            throw new OperationException("Error al obtener item con id: " + id,
                    e);
        }
    }

    @Override
    public void changeEstate(ID id, Estado estado) throws OperationException {
        try {
      /* Obtenemos el objeto */
            T obj = this.get(id);
           // obj.setEstado(estado);
            // obj.setFechaModificacion(new Date());
            getGenericDao().persist(obj);
        } catch (Exception e) {
            log.error("Ocurrio un Error al cambiar el estado con id: " + id + ", usuario: ", e);
            throw new OperationException("Error al cambiar de estado el registro" + id, e);
        }
    }

    @Override
    public void delete(ID id, String usuarioEliminacion)
            throws OperationException {
        try {
            // Obtener el objeto
            T obj = this.get(id);

//            if (!(obj.getEstado().equals(Estado.P) || obj.getEstado().equals(Estado.C))) {
//                throw new OperationException("El item no se encuentra en estado Registrado o Rechazado.");
//            }
//            obj.setEstado(Estado.E);
            // obj.setFechaModificacion(new Date());
            // obj.setUsuarioModificacion(usuarioEliminacion);
            getGenericDao().remove(obj);
            Log.Info("Borrando:"+obj.toString()+ " id:"+id);
        } catch (OperationException e) {
            log.error("Error eliminar registro con id: " + id + ", usuario: " + usuarioEliminacion, e);
            throw e;
        } catch (Exception e) {
            log.error("Error desconocido al eliminar registro con id: " + id + ", usuario: " + usuarioEliminacion, e);
            throw new OperationException("Error al eliminar item " + id, e);
        }
    }

    @Override
    public void authorize(T obj, String usuarioAutorizacion, boolean autorizado)
            throws OperationException {
        try {
            // Obtener el objeto
            //T obj = this.get(id);
            // if (!(obj.getClass().isAssignableFrom(EntidadAutorizable.class))){
            if (!(obj instanceof EntidadAutorizable)) {
                throw new OperationException("La entidad no es autorizable.");
            }
//            EntidadAutorizable objAutorizable = (EntidadAutorizable) obj;
//            if (!objAutorizable.getEstado().equals(Estado.P)) {
//                throw new OperationException("La entidad no se encuentra en estado pendiente de autorización.");
//            }
//            if (objAutorizable.getEstado().equals(Estado.S)) {
//                throw new OperationException("La entidad se encuentra suspendida.");
//            }

//            objAutorizable.setEstado(autorizado ? Estado.A : Estado.C);
            // objAutorizable.setFechaModificacion(new Date());
//            obj = (T) objAutorizable;
           // getGenericDao().persist(obj);
        } catch (Exception e) {
            log.error("Error desconocido al autorizar el registro con id: " + obj.getId() + ", usuario: " + usuarioAutorizacion, e);
            throw new OperationException("Error al " + (autorizado ? "autorizar" : "rechazar") + " el registro " + obj.getId(), e);
        }
    }

    protected String getMessageValorRequerido(String nombreCampoRequerido){
        String message = getPropertiesValidator().getProperty("error.entity.valor.requerido");
        return String.format(message, nombreCampoRequerido);
    }

    protected String getMessageErrorCaracteresEspecialesEspacios(String nombreCampoRequerido){
        String message = getPropertiesValidator().getProperty("error.entity.espacios.caracteres.especiales");
        return String.format(message, nombreCampoRequerido);
    }

    protected String getMessageErrorCaracteresEspeciales(String nombreCampoRequerido){
        String message = getPropertiesValidator().getProperty("error.entity.caracteres.especiales");
        return String.format(message, nombreCampoRequerido);
    }

    protected String getMessageEntidadNula(){
        String message = getPropertiesValidator().getProperty("error.entity.nulo");
        return message;
    }



}
