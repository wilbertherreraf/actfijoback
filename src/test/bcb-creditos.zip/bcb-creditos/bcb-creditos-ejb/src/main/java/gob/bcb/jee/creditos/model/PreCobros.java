package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the pre_cobros database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="pre_cobros")
@NamedQueries({
    @NamedQuery(name = PreCobros.NQ_LIST_ALL, query = "SELECT a FROM PreCobros a"),
    @NamedQuery(name = PreCobros.NQ_GET_BY_TRX, query = "SELECT p FROM PreCobros p where p.cobNumtrx =:valor1  and  p.cobStatreg=0 ")
    
})
public class PreCobros extends EntidadAutorizable<Integer> implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="PreCobros";
	  public static final String NQ_GET_BY_TRX =ENTITY+"GetById";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";	  


	@Id
	@Column(name="cob_codcob")
	private Integer cobCodcob;
	
	@Column(name="cob_codcred")
	private Integer cobCodcred;
	
	@Column(name="cob_codmod")
	private Integer cobCodmod;
	
	@Column(name="cob_numtrx")
	private Integer cobNumtrx;
	
	@Column(name="cob_sectran")
	private Integer cobSectran;
	
	@Temporal(TemporalType.DATE)
	@Column(name="cob_feccontab")
	private Date cobFeccontab;

	@Temporal(TemporalType.DATE)
	@Column(name="cob_fechproc")
	private Date cobFechproc;
	
	@Column(name="cob_codtab")
	private Integer cobCodtab;
	
	@Column(name="cob_codigo")
	private Integer cobCodigo;
	
	@Column(name="cob_descrip")
	private String cobDescrip;
	
	@Column(name="cob_valor")
	private BigDecimal cobValor;
	
	@Column(name="cob_codmon")
	private Integer cobCodmon;
	
	@Column(name="cob_tabtipotrx")
	private Integer cobTabtipotrx;
	
	@Column(name="cob_tipotrx")
	private Integer cobTipotrx;
	
	@Column(name="cob_numcuo")
	private Integer cobNumcuo;
	
	@Column(name="cob_tabstatreg")
	private Integer cobTabstatreg;
	
	@Column(name="cob_statreg")
	private Integer cobStatreg;
	
	@Column(name="cob_tabtrxstaau")
	private Integer cobTabtrxstaau;
	
	@Column(name="cob_trxstaau")
	private Integer cobTrxstaau;
	
	@Column(name="cob_auditusr")
	private String cobAuditusr;	

	@Column(name="cob_auditfho")
	private Timestamp cobAuditfho;

	@Column(name="cob_auditwst")
	private String cobAuditwst;

	public PreCobros() {
	}

	@Override
	public void setId(Integer id) {
		this.cobCodcob=id;
	}

	@Override
	public Integer getId() {
		return this.cobCodcob;
	}

}
