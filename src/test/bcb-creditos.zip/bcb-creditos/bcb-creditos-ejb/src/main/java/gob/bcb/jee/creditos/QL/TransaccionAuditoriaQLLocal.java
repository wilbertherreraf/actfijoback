package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.TransaccionAuditoria;

import javax.ejb.Local;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.QL
 * 28/06/2016 - 10:51 AM
 * Created por aescobar
 */

@Local
public interface TransaccionAuditoriaQLLocal extends GenericQLLocal<TransaccionAuditoria, String> {
}
