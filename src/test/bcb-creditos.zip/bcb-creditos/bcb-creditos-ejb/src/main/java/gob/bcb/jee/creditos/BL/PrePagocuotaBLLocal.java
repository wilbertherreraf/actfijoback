package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.EstadoDesembolsosQuery;
import gob.bcb.jee.creditos.entidades.PrePagocuota;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreAccrual;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

@Local
public interface PrePagocuotaBLLocal extends
        GenericBLLocal<PrePagocuota, Integer> {


    public PreAccrual getParametrosCobroDesembolso(Date fechaVencimiento, Integer codcred,Integer codmod, Integer coddsb);

    public List<Object[]> getParametrosGlosa(Integer tipoOperacion)throws OperationException;

    public Integer getNumeroDesembolso(Integer codcred, Integer codmod, Integer coddsb) throws OperationException;

    public Integer getNumeroCuota(Integer codcred, Integer codmod, Date fechaVencimiento) throws OperationException;

    public Integer getEstadoPagoCuota(Integer codcred,Integer codmod,Integer coddsb, Date fechaVencimiento) throws OperationException;

    public Integer getVerificarExistePagoCuota(Integer codcred,Integer codmod,Integer coddsb, Date fechaVencimiento) throws OperationException;

    PrePagocuota obtenerPorCodDesembolso(Integer pCodDesembolso);

    PrePagocuota guardarPagocuota(PrePagocuota prePagocuota);

    PrePagocuota findCuotaById(Integer id);

    PrePagocuota generarOperacionYContaBL(Integer tipoRegistro, PrePagocuota prePagocuota, String resultadoGlosa);

    void generarDevengadosCredito(Integer codcred, Integer codmod, Date fechaIni, Date fechaFin, Integer tipoproc);

    List<PrePagocuota> findByCredDsbVcto(Integer codcred, Integer codmod, Integer coddsb, Date fechaVencimiento);

    List<PrePagocuota> cuotasPendientesSinCmp(Integer codcred, Integer codmod, Date fechaVencimiento);

    void actualizarRengs(Integer tipoproc,Integer codcred, Integer codmod, Date fecha, Integer tipotrx, String usuario, String estacion);

    void devengarCredito(Integer codcred, Integer codmod, Date fechaIni, Date fechaFin, Integer tipoproc);

    void generarOperContCred(Integer codcmp, Integer codprc, Integer codcred, Integer codmod, Integer coddsb,
            Date fecvcto, Integer numtrx, String usuario, String estacion);

    List<PrePagocuota> cuotasConCmpb(Integer codcred, Integer codmod, Date fechaVencimiento);


}
