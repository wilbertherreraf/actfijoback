package gob.bcb.jee.creditos.model;
import gob.bcb.jee.creditos.entidades.*;
import gob.bcb.jee.creditos.util.Reflection;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.entidades
 * 24/07/2023 - 16:08 PM
 * Código base:
 * Creado por hpanique
 */

@Entity
@Table(name = "pre_garantiad")
@Getter
@Setter
@NamedQueries({
        @NamedQuery(name = PreGarantiad.NQ_GET_BY_DSB, query = "SELECT e FROM PreGarantiad e where e.gardCodcred = :valor1 and e.gardCodmod = :valor2 and e.gardCoddsb = :valor3"),
})

public class PreGarantiad extends EntidadAutorizable<Integer> {

    public static final String ENTITY = "PreGarantiad";
    public static final String NQ_GET_BY_DSB =ENTITY+"GetByDsb";

    @Id
    @Column(name="gard_cod")
    private Integer gardCod;

    @Column(name="gard_codcred")
    private Integer gardCodcred;

    @Column(name="gard_codmod")
    private Integer gardCodmod;

    @Column(name="gard_coddsb")
    private Integer gardCoddsb;

    @Column(name="gard_habilita")
    private boolean gardHabilita;

    @Column(name="gard_claveserie")
    private String gardClaveSerie;

    @Column(name="gard_titulo")
    private String gardTitulo;

    @Column(name="gard_negociable")
    private Boolean gardNegociable;

    @Column(name="gard_tabtrxstaau")
    private Integer gardTabtrxstaau;

    @Column(name="gard_trxstaau")
    private Integer gardTrxstaau;

    @Column(name="gard_auditusr")
    private String gardAuditusr;

    @Column(name="gard_auditfho")
    private Timestamp gardAuditfho;

    @Column(name="gard_auditwst")
    private String gardAuditwst;

    public PreGarantiad() {
        super();
    }
    @Override
    public String toString() {
        Reflection<PreGarantiad> reflex=new Reflection<PreGarantiad>();
        return reflex.imprimirCampos(this);
    }

    @Override
    public boolean equals(Object o) {
        Reflection<PreGarantiad> reflex=new Reflection<PreGarantiad>();
        return reflex.equals(this,o);
    }

    @Override
    public int hashCode() {
        Reflection<PreGarantiad> reflex=new Reflection<PreGarantiad>();
        return reflex.generarHash(this);
    }
    @Override
    public Integer getId() {
        return gardCod;
    }
    @Override
    public void setId(Integer id) {
        this.gardCod=id;
    }
}
