package gob.bcb.jee.creditos.excepciones;

import gob.bcb.jee.creditos.numeradores.CodigosError;

public class ConsultasSQLException extends PlantillaEEException {

	private static final long serialVersionUID = 1L;

	public ConsultasSQLException(CodigosError codigo) {
		super(codigo.getCodError());
	}

	public ConsultasSQLException(CodigosError codigo, Exception causa) {
		super(codigo.getCodError(), causa);
	}

	public ConsultasSQLException(CodigosError codigo, String query,
			Exception causa) {
		super(codigo.getCodError(), causa, query);
	}

}
