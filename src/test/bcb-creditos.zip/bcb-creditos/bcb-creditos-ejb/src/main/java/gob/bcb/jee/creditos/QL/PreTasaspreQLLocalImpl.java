/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreTasaspre;
import gob.bcb.jee.creditos.model.PreTasasprePK;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PreTasaspreQLLocalImpl extends
        GenericQLLocalImpl<PreTasaspre, PreTasasprePK> implements
        PreTasaspreQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /*
     * (non-Javadoc)
     * @see
     * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
     * ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
	
    @Override
	public double obtenerTasaVigente(Integer codcred,Integer codmod, Date fecha) throws OperationException{		
		String nativeQuery="call d_creditos.f_gettasavigenteprest(:valor1,:valor2 ,:valor3 )";		
		Query query=entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1",codcred);
		query.setParameter("valor2",codmod);
		query.setParameter("valor3",fecha);		
		Object valor1=query.getSingleResult();
		double id=0;
		if(valor1!=null) {
			id=Double.parseDouble(valor1.toString());
		}
		return id;
		
	}
    
    public PreTasaspre obtenerUltimaTasa(Integer codcred,Integer codmod) throws OperationException{
    	String nativeQuery="SELECT p FROM PreTasaspre p where p.id.mtpCodcred=:valor1 and p.id.mtpCodmod=:valor2 order by p.id.mtpFechavig desc ";		
		Query query=entityManager.createQuery(nativeQuery);
		query.setParameter("valor1",codcred);
		query.setParameter("valor2",codmod);
		List<PreTasaspre> valor1= query.getResultList();		
		if(valor1.size()>0) {
			return valor1.get(0);
		}
		return new PreTasaspre();
    }
    public void update(Integer codcred,Integer codmod, Date fecha, Date newFecha, double tasa,Integer base ) throws OperationException{
    	String nativeQuery="update PreTasaspre "
    			+ " set mtp_fechavig=:valor1 ,"
    			+ " mtp_tbase=:valor2 ,"
    			+ " mtp_intydias=:valor3 "
    			+ " where mtp_codmod=:valor4 and mtp_codcred=:valor5 and mtp_fechavig=:valor6 ";		
		Query query=entityManager.createQuery(nativeQuery);
		query.setParameter("valor1",newFecha);
		query.setParameter("valor2",tasa);
		query.setParameter("valor3",base);
		query.setParameter("valor4",codmod);
		query.setParameter("valor5",codcred);
		query.setParameter("valor6",fecha);
		query.executeUpdate();			
    }

}
