package gob.bcb.jee.creditos.numeradores;

public enum CodigosError {
	
	ERROR_100("100"),
	ERROR_101("101");
	
	private String codError;

	private CodigosError(String codError) {
		this.codError = codError;
	}
	
	public String getCodError() {
		return codError;
	}
	
}
