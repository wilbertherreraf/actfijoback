/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.sql.SQLException;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import gob.bcb.jee.creditos.entidades.PrePagocuota;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.util.Cttes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PreReprogramaQLLocalImpl extends
        GenericQLLocalImpl<PreReprograma, Integer> implements
        PreReprogramaQLLocal {
    private static final Logger log = LoggerFactory.getLogger(PreReprogramaQLLocalImpl.class);
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /*
     * (non-Javadoc)
     * 
     * @see
     * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
     * ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

    public PreReprograma findByCodRepro(Integer codrepro) {

        String nativeQuery = "select t " +
                " from PreReprograma t " +
                " where t.rdsCodrepro = :codrepro "; 

        Query query = entityManager.createQuery(nativeQuery);
        query.setParameter("codrepro", codrepro);

        List result = query.getResultList();
        if (result.size() > 0) {
            return (PreReprograma) result.get(0);
        }
        return null;
    }

    public PreReprograma guardarRepro(PreReprograma repro) {
        try {
            if (repro.getRdsCodrepro() == null) {
                repro.setRdsCodrepro(nuevoId());
                entityManager.persist(repro);
                PreReprograma r = findByCodRepro(repro.getRdsCodrepro());
                log.info("Repro creado " + r.getRdsCodrepro());
                return r;
            } else {
                PreReprograma r = entityManager.merge(repro);
                r = findByCodRepro(r.getRdsCodrepro());
                log.info("Repro actuaizado " + r.getRdsCodrepro());
                return r;
            }

        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
                if (cause instanceof SQLException) {
                    count++;
                    sb.append(cause.getMessage());
                    sb.append(" , ");
                }
            }
            String consent = (count > 0 ? sb.toString().replace(", null ,", "")
                    : "Error :" + e.getMessage().replace(", null ,", ""));
            throw new RuntimeException("Error p_mf_amort_genplan: " + consent, e);
        }
    }

    @Override
    public Integer nuevoId() {
        String nativeQuery = "call f_rpro_getnextid()";
        Query query = entityManager.createNativeQuery(nativeQuery);
        Object valor = query.getSingleResult();
        int id = 0;
        if (valor != null) {
            id = Integer.parseInt(valor.toString());
        }
        return id;
    }

    public List<Object[]> obtenerContratos(Integer codcred, Integer codmod) {
        String nativeQuery = " select nvl(rds_nrodoc,'') contrato, rds_fecini fecha, des_descrip razon " +
                "from pre_reprograma  join gen_desctabla on rds_tabtiporepro=des_codtab and rds_tiporepro =des_codigo "
                +
                "where rds_codcred= :valor1  " +
                "and rds_codmod= :valor2  " +
                "and rds_trxstaau=3 and rds_tiporepro in(1,3) " +
                "order by 2 ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("valor1", codcred);
        query.setParameter("valor2", codmod);
        List<Object[]> valor = query.getResultList();
        return valor;

    }

    public List<PreReprograma> reprosByCred(Integer codcred, Integer codmod, Integer tiporepro) {

        String nativeQuery = "select t " +
                " from PreReprograma t " +
                " where t.rdsCodcred=:codcred  " +
                " and t.rdsCodmod=:codmod  " +
                " and t.rdsTiporepro=:tiporepro  " +
                " and t.rdsStatreg=0  " +
                " order by t.rdsCodrepro desc ";
        Query query = entityManager.createQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("tiporepro", tiporepro);

        List result = query.getResultList();
        return result;
    }

}
