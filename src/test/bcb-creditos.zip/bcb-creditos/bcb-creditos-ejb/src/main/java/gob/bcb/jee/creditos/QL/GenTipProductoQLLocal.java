/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.GenTipproductoPK;


@Local
public interface GenTipProductoQLLocal extends
        GenericQLLocal<GenTipproducto,GenTipproductoPK>
{
	public Integer getIdNewId(Integer codmod)throws OperationException;
}
