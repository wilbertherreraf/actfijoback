/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.GenMoneda;

/**
 * Interface para el negocio del a entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface GenMonedaBLLocal extends
    GenericBLLocal<GenMoneda, Integer>
{
	public Integer getIdNewId()throws OperationException;
}
