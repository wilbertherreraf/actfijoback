package gob.bcb.jee.creditos.BL;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.model.PrePrcconta;

/**
 * Interface para el negocio del a entidad PrePrcconta
 * 
 * @author hpanique
 */

@Local
public interface PrePrccontaBLLocal extends
        GenericBLLocal<PrePrcconta, Integer> {

    public Integer getNextId() throws OperationException;

    PrePrcconta guardarPrcconta(PrePrcconta prePrcconta);

    PrePrcconta buscarPorFechaDeven(Integer prcCodcred, Integer prcCodmod, Date prcFecha2);

    PrePrcconta generarComprobanteDevengado(PrePrcconta prePrcconta);

    PrePlanpagos obtenerDevengamientoAFecha(Integer codcred, Integer codmod, Date fechaini, Date fecha);

    List<PrePrcconta> devengadosContByCred(Integer prcCodcred, Integer prcCodmod);

    List<PrePrcconta> devsGenerados(Integer prcCodcred, Integer prcCodmod, Integer estado, Date fechaCont);

    void cambiarEstadoOperComprob(Integer tipocmp, Integer idtabla, Integer codcred, Integer codmod, Integer coddsb,
            Date fecha, Integer estado, String usuario, String estacion);

    PrePrcconta buscarPorId(Integer prcCodprc);

    PrePrcconta procesarDevengadoManual(PrePrcconta prePrccontaIn, String usuario, String estacion);

    void rechazarDevengadoManual(PrePrcconta prePrccontaIn, String usuario, String estacion);

    void actDeCoinDevengadoManual(PrePrcconta prePrccontaIn, String usuario, String estacion);

}
