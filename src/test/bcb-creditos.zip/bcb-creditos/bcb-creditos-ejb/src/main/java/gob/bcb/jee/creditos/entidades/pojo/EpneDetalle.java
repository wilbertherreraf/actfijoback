package gob.bcb.jee.creditos.entidades.pojo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by eborda on 01/12/2016.
 */
@Getter
@Setter
public class EpneDetalle implements Serializable {
    public Integer idEmpresa;
    public Long idProyecto;
    public String sigla;
    public String descripcion;
    public String nomEmpresa;
    public String nroContrato;
    public Date fechaDesembolso;
    public BigDecimal montoLeyes;
    public BigDecimal montoAprobado;
    public BigDecimal desembolso;
    public BigDecimal porcentaje;
    public BigDecimal saldoDesembolsar;
    public BigDecimal importeUtilizar;

    public EpneDetalle(Integer idEmpresa,Long idProyecto, String sigla, String descripcion, String nroContrato, Date fechaDesembolso, BigDecimal montoAprobado) {
        this.idEmpresa = idEmpresa;
        this.idProyecto = idProyecto;
        this.sigla = sigla;
        this.descripcion = descripcion;
        this.montoLeyes = new BigDecimal("0");
        this.nomEmpresa = sigla + " " + descripcion;
        this.nroContrato = nroContrato;
        this.fechaDesembolso = fechaDesembolso;
        this.montoAprobado = montoAprobado;
        this.desembolso = new BigDecimal("0");
        this.porcentaje = new BigDecimal("0");

        this.saldoDesembolsar = montoAprobado.subtract(desembolso);
        this.importeUtilizar = desembolso;
    }

    @Override
    public String toString() {
        return "EpneDetalle{" +
                "idEmpresa=" + idEmpresa +
                ", idProyecto=" + idProyecto +
                ", sigla='" + sigla + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", nomEmpresa='" + nomEmpresa + '\'' +
                ", nroContrato='" + nroContrato + '\'' +
                ", fechaDesembolso=" + fechaDesembolso +
                ", montoLeyes=" + montoLeyes +
                ", montoAprobado=" + montoAprobado +
                ", desembolso=" + desembolso +
                ", porcentaje=" + porcentaje +
                ", saldoDesembolsar=" + saldoDesembolsar +
                ", importeUtilizar=" + importeUtilizar +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EpneDetalle that = (EpneDetalle) o;

        if (idEmpresa != that.idEmpresa) return false;
        if (descripcion != null ? !descripcion.equals(that.descripcion) : that.descripcion != null) return false;
        if (desembolso != null ? !desembolso.equals(that.desembolso) : that.desembolso != null) return false;
        if (fechaDesembolso != null ? !fechaDesembolso.equals(that.fechaDesembolso) : that.fechaDesembolso != null)
            return false;
        if (idProyecto != null ? !idProyecto.equals(that.idProyecto) : that.idProyecto != null) return false;
        if (importeUtilizar != null ? !importeUtilizar.equals(that.importeUtilizar) : that.importeUtilizar != null)
            return false;
        if (montoAprobado != null ? !montoAprobado.equals(that.montoAprobado) : that.montoAprobado != null)
            return false;
        if (montoLeyes != null ? !montoLeyes.equals(that.montoLeyes) : that.montoLeyes != null) return false;
        if (nomEmpresa != null ? !nomEmpresa.equals(that.nomEmpresa) : that.nomEmpresa != null) return false;
        if (nroContrato != null ? !nroContrato.equals(that.nroContrato) : that.nroContrato != null) return false;
        if (porcentaje != null ? !porcentaje.equals(that.porcentaje) : that.porcentaje != null) return false;
        if (saldoDesembolsar != null ? !saldoDesembolsar.equals(that.saldoDesembolsar) : that.saldoDesembolsar != null)
            return false;
        if (sigla != null ? !sigla.equals(that.sigla) : that.sigla != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idEmpresa;
        result = 31 * result + (idProyecto != null ? idProyecto.hashCode() : 0);
        result = 31 * result + (sigla != null ? sigla.hashCode() : 0);
        result = 31 * result + (descripcion != null ? descripcion.hashCode() : 0);
        result = 31 * result + (nomEmpresa != null ? nomEmpresa.hashCode() : 0);
        result = 31 * result + (nroContrato != null ? nroContrato.hashCode() : 0);
        result = 31 * result + (fechaDesembolso != null ? fechaDesembolso.hashCode() : 0);
        result = 31 * result + (montoLeyes != null ? montoLeyes.hashCode() : 0);
        result = 31 * result + (montoAprobado != null ? montoAprobado.hashCode() : 0);
        result = 31 * result + (desembolso != null ? desembolso.hashCode() : 0);
        result = 31 * result + (porcentaje != null ? porcentaje.hashCode() : 0);
        result = 31 * result + (saldoDesembolsar != null ? saldoDesembolsar.hashCode() : 0);
        result = 31 * result + (importeUtilizar != null ? importeUtilizar.hashCode() : 0);
        return result;
    }
}
