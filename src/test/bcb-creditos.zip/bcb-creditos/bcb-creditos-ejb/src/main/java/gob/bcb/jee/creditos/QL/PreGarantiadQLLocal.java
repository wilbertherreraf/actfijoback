package gob.bcb.jee.creditos.QL;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreGarantiad;

import javax.ejb.Local;


/**
 * Interfaz para los metodos de consulta (QL) para la entidad Pre_Garantiad
 * @author hpanique
 */
@Local
public interface PreGarantiadQLLocal extends
        GenericQLLocal<PreGarantiad,Integer>
{
    public Integer getNewId()throws OperationException;
    public PreGarantiad getByDsb(Integer valor1, Integer valor2, Integer valor3 );
}
