package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the pre_cobros database table.
 * 
 */
@Embeddable
public class PreCobrosPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cob_codcred", insertable=false, updatable=false)
	private Integer cobCodcred;

	@Column(name="cob_codmod", insertable=false, updatable=false)
	private Integer cobCodmod;

	@Column(name="cob_numtrx", insertable=false, updatable=false)
	private Integer cobNumtrx;

	@Column(name="cob_sectran")
	private Integer cobSectran;

	public PreCobrosPK() {
	}
	public Integer getCobCodcred() {
		return this.cobCodcred;
	}
	public void setCobCodcred(Integer cobCodcred) {
		this.cobCodcred = cobCodcred;
	}
	public Integer getCobCodmod() {
		return this.cobCodmod;
	}
	public void setCobCodmod(Integer cobCodmod) {
		this.cobCodmod = cobCodmod;
	}
	public Integer getCobNumtrx() {
		return this.cobNumtrx;
	}
	public void setCobNumtrx(Integer cobNumtrx) {
		this.cobNumtrx = cobNumtrx;
	}
	public Integer getCobSectran() {
		return this.cobSectran;
	}
	public void setCobSectran(Integer cobSectran) {
		this.cobSectran = cobSectran;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PreCobrosPK)) {
			return false;
		}
		PreCobrosPK castOther = (PreCobrosPK)other;
		return 
			(this.cobCodcred == castOther.cobCodcred)
			&& (this.cobCodmod == castOther.cobCodmod)
			&& (this.cobNumtrx == castOther.cobNumtrx)
			&& (this.cobSectran == castOther.cobSectran);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.cobCodcred;
		hash = hash * prime + this.cobCodmod;
		hash = hash * prime + this.cobNumtrx;
		hash = hash * prime + this.cobSectran;
		
		return hash;
	}
}
