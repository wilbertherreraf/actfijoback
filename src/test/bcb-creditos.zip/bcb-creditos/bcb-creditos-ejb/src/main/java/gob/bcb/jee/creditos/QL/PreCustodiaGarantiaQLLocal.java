package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreCustodiaGarantia;

import javax.ejb.Local;

/**
 * PreCustodiaGarantiaQLLocal
 *
 * @author mcramos
 * 21/02/2025
 */
@Local
public interface PreCustodiaGarantiaQLLocal extends GenericQLLocal<PreCustodiaGarantia,Integer> {

    PreCustodiaGarantia obtenerPorCodDesembolso(Integer pCodDesembolso);

    Integer getEstadoCustodiaGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    PreCustodiaGarantia buscarPorId(Integer id);

    PreCustodiaGarantia guardarCustGar(PreCustodiaGarantia entity);
}
