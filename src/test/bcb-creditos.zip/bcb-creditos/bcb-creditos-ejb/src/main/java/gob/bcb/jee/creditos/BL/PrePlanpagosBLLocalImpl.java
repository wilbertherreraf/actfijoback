/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.AuxPlanpagosQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PrePlanpagosQLLocal;
import gob.bcb.jee.creditos.QL.PreReprogramaQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PrePlanpagosDao;
import gob.bcb.jee.creditos.entidades.VPlanPagosConsolQuery;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.AuxPlanpagos;
import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.pojo.PlanPagoDto;
import gob.bcb.jee.creditos.util.Cttes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class PrePlanpagosBLLocalImpl extends GenericBLLocalImpl<PrePlanpagos, Integer> implements PrePlanpagosBLLocal {
	private static final Logger log = LoggerFactory.getLogger(PrePlanpagosBLLocalImpl.class);
	@PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
	EntityManager em;
	/*
	 * Inyeccion de los metodos para consulta (QL)
	 */
	@Inject
	PrePlanpagosQLLocal prePlanpagosQLLocal;
	@Inject
	private AuxPlanpagosQLLocal auxPlanpagosQLLocal;
	@Inject
	PrePlanpagosDao parametroDao;
	@Inject
	private PreReprogramaQLLocal preReprogramaQLLocal;

	public GenericQLLocal<PrePlanpagos, Integer> getQLBean() {
		return prePlanpagosQLLocal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
	 */

	public GenericDao<PrePlanpagos, Integer> getGenericDao() {
		return parametroDao;
	}

	public void validar(PrePlanpagos entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub

	}

	public Integer getCantidad(Integer coddsb) throws OperationException {
		return prePlanpagosQLLocal.getCantidad(coddsb);
	}

	public Integer getCantidadPreAutorizado(Integer coddsb) throws OperationException {
		return prePlanpagosQLLocal.getCantidadPreAutorizado(coddsb);
	}

	public List<Object[]> mostrarPlanDePagos(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {
		return prePlanpagosQLLocal.mostrarPlanDePagos(codcred, codmod, coddsb);
	}

	public List<Object[]> mostrarPlanDePagosGeneral(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {
		return prePlanpagosQLLocal.mostrarPlanDePagosGeneral(codcred, codmod, coddsb);
	}

	public void actualizarPlanDePagos0(Integer codcred, Integer codmod) throws OperationException {
		prePlanpagosQLLocal.actualizarPlanDePagos0(codcred, codmod);
	}

	public void realizarCobro(Integer codcred, Integer codmod, Date fechaVen, Date fechaAct, Integer accion,
			String usuario, String estacion) throws OperationException, SQLException {
		prePlanpagosQLLocal.realizarCobro(codcred, codmod, fechaVen, fechaAct, accion, usuario, estacion);
	}

	public void quitarCuota(Integer codcred, Integer codmod, Integer coddsb, Date fechaCuo, String usuario,
			String estacion) throws OperationException {
		prePlanpagosQLLocal.quitarCuota(codcred, codmod, coddsb, fechaCuo, usuario, estacion);
	}

	public List<Object[]> mostrarPlanDePagosDetalleEstados(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {
		return prePlanpagosQLLocal.mostrarPlanDePagosDetalleEstados(codcred, codmod, coddsb);
	}

	public void actualizarConsolidado(Integer codcred, Integer codmod, Integer codmodtmp) throws OperationException {
		prePlanpagosQLLocal.actualizarConsolidado(codcred, codmod, codmodtmp);
	}

	public void actualizarDesembolso(Integer codcred, Integer codmod, Integer codmodtmp, Integer coddsb)
			throws OperationException {
		prePlanpagosQLLocal.actualizarDesembolso(codcred, codmod, codmodtmp, coddsb);

	}

	public List<Object[]> getTotalBonoValorGarantia(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {
		return prePlanpagosQLLocal.getTotalBonoValorGarantia(codcred, codmod, coddsb);
	}

	public List<PlanPagoDto> mostrarPlanDePagosPorGestionSinCancelar(Integer codcred, Integer codmod, Integer coddsb,
			Integer pGestion) throws OperationException {
		return prePlanpagosQLLocal.recuperarPlanDePagosPorGestionSinCancelar(codcred, codmod, coddsb, pGestion);
	}

	public PlanPagoDto recuperarPlanDePagoPorParametros(Integer codcred, Integer codmod, Integer coddsb,
			Date cuoFecvencuo) throws OperationException {
		return prePlanpagosQLLocal.recuperarPlanDePagoPorParametros(codcred, codmod, coddsb, cuoFecvencuo);
	}

	public List<VPlanPagosConsolQuery> planConsolPorCodmodYCodcred(Integer codcred, Integer codmod) {
		return prePlanpagosQLLocal.planConsolPorCodmodYCodcred(codcred, codmod);
	}

	public List<VPlanPagosConsolQuery> generarPlanPagos(PreReprograma pre) {
		// 1. Validaciones básicas
		boolean conCapital = true;
		if (pre.getRdsNroperiodos() == null || pre.getRdsNroperiodos() <= 0)
			throw new IllegalArgumentException("Número de periodos debe ser mayor que cero.");
		if (pre.getRdsSaldo() == null || pre.getRdsSaldo().compareTo(BigDecimal.ZERO) <= 0)
			throw new IllegalArgumentException("Monto capital debe ser mayor que cero.");
		if (pre.getRdsFeculttrx() == null || pre.getRdsFeciniint() == null || pre.getRdsFecini() == null)
			throw new IllegalArgumentException("Fechas incompletas.");

		// 2. Generar lista de fechas de vencimiento (periodos)
		List<Date> fechasVencimiento = generarFechasVencimiento(pre.getRdsCodcred(), pre.getRdsCodmod());

		conCapital = fechasVencimiento.contains(pre.getRdsFecini());
		// 3. Verificar que rdsFecini esté en la lista
		if (!conCapital) {
			// throw new IllegalArgumentException("La fecha de inicio de capital no coincide
			// con ninguna fecha de vencimiento generada.");

		}

		// 4. Índice donde comienza la amortización de capital
		int indiceCapital = fechasVencimiento.indexOf(pre.getRdsFecini());
		int totalPeriodos = fechasVencimiento.size();
		int numPeriodosCapital = totalPeriodos - indiceCapital;

		// 5. Cuota de capital constante (ajustar última)
		BigDecimal capitalTotal = pre.getRdsSaldo();
		BigDecimal cuotaCapital = capitalTotal.divide(BigDecimal.valueOf(numPeriodosCapital), 2, RoundingMode.HALF_UP);

		// 6. Determinar base de días según unidad
		int baseDias = obtenerBaseDias(pre.getRdsUnidplaz());

		// 7. Construir el plan
		List<VPlanPagosConsolQuery> plan = new ArrayList<>();
		Date fechaAnterior = pre.getRdsFeculttrx();
		BigDecimal saldoPendiente = capitalTotal;
		log.info("EN GEN PP " + saldoPendiente.toPlainString() + " totalPeriodos " + totalPeriodos);
		for (int i = 0; i < totalPeriodos; i++) {
			Date fechaVto = fechasVencimiento.get(i);
			VPlanPagosConsolQuery p = new VPlanPagosConsolQuery();
			p.setFechaant(fechaAnterior);
			p.setFechavencuo(fechaVto);

			// Días entre fecha anterior y vencimiento
			long diff = fechaVto.getTime() - fechaAnterior.getTime();
			int dias = (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			p.setDias(dias);

			// Interés: saldo * tasa * días / (base * 100)
			double tasaDiaria = pre.getRdsTasa() / (100.0 * baseDias);
			BigDecimal interes = saldoPendiente.multiply(BigDecimal.valueOf(tasaDiaria))
					.multiply(BigDecimal.valueOf(dias))
					.setScale(2, RoundingMode.HALF_UP);
			p.setInteres(interes);

			// Amortización: solo si i >= indiceCapital
			BigDecimal amortizacion = BigDecimal.ZERO;
			if (i >= indiceCapital && conCapital) {
				int pos = i - indiceCapital;
				if (pos == numPeriodosCapital - 1) {
					// Última cuota de capital: ajuste para que saldo quede 0
					amortizacion = saldoPendiente;
				} else {
					amortizacion = cuotaCapital;
				}
			}
			p.setAmortizacion(amortizacion);

			// Cuota total
			BigDecimal cuota = interes.add(amortizacion);
			p.setCuota(cuota);
			p.setSaldoInicio(saldoPendiente);
			p.setTasa(BigDecimal.valueOf(pre.getRdsTasa()));
			p.setEstadoCuota("1"); // pendiente

			plan.add(p);

			// Actualizar saldo
			saldoPendiente = saldoPendiente.subtract(amortizacion);
			fechaAnterior = fechaVto;
		}
		log.info("Saliendo ... " + plan.size());
		// También almacenamos el número de periodos de capital en el propio plan o lo
		// devolvemos aparte
		// Lo haremos a través del bean, pero podemos pasar el valor en un atributo
		// extra.
		return plan;
	}

	private int obtenerBaseDias(Integer unidad) {
		// Códigos 1-7 base 360, 12-16 base 365
		if (unidad == null)
			return 360;
		if (unidad >= 1 && unidad <= 7)
			return 360;
		if (unidad >= 12 && unidad <= 16)
			return 365;
		return 360; // default
	}

	public void guardarPlanPagos(PreReprograma pre) {
		// Lógica de persistencia
		System.out.println("Guardando plan para reprograma: " + pre.getRdsCodrepro());
	}

	public PreReprograma genCalendarioGetVencimientos(PreReprograma rpro, Integer tipotrx, String usuario, String estacion) {
		PreReprograma preReprograma = null;
		log.info("En recup fechas vento : " + rpro.getRdsCodcred() + " tipotrx: " + tipotrx);
		if (tipotrx.equals(1)) {
			rpro.setRdsTiporepro(tipotrx);
			preReprograma = preReprogramaQLLocal.guardarRepro(rpro);
		} else {
			preReprograma = rpro;
		}
		
		prePlanpagosQLLocal.generarCalendario(preReprograma.getRdsCodcred(), preReprograma.getRdsCodmod(), tipotrx,
			preReprograma.getRdsCodrepro(), preReprograma.getRdsFecfindif(), 
			preReprograma.getRdsFecini(), preReprograma.getRdsFeciniint(), 
			BigDecimal.valueOf(preReprograma.getRdsTasa()), preReprograma.getRdsUnidplaz(), preReprograma.getRdsNroperiodos(),
				usuario, estacion);

		log.info("Fechas vctos : " + preReprograma.getRdsCodrepro() + " cred " + preReprograma.getRdsCodcred());

		return preReprograma;
	}

	public void generarCalendario(Integer codcred, Integer codmod, Integer tipotrx, Integer codrepro,
			Date fCorterepro, Date fechaPrimAmort, Date fechaPrimAmortint, BigDecimal tasa, Integer unidplaz,
			Integer nroamortInt, String usuario, String estacion) {
		prePlanpagosQLLocal.generarCalendario(codcred, codmod, tipotrx, codrepro, fCorterepro,
				fechaPrimAmort, fechaPrimAmortint, tasa, unidplaz, nroamortInt,
				usuario, estacion);
	}

	/**
	 * Genera la lista de fechas de vencimiento a partir de una fecha inicial,
	 * número de periodos y unidad de plazo.
	 */
	public List<Date> generarFechasVencimiento(Integer codcred, Integer codmod) {

		List<AuxPlanpagos> lista = auxPlanpagosQLLocal.obtCalendarioPP(codcred, codmod);
		List<Date> a = new ArrayList<>();
		
		a = lista.stream().map(l -> {
			Calendar cal = Calendar.getInstance();
			cal.setTime(l.getAcuFecvencuo());
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			return l.getAcuFecvencuo();
		}).collect(Collectors.toList());
		return a;
	}

}
