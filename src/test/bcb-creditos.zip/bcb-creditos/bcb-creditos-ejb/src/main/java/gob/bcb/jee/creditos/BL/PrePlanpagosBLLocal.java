/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.VPlanPagosConsolQuery;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.AuxPlanpagos;
import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.pojo.PlanPagoDto;

import javax.ejb.Local;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 * Interface para el negocio del a entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface PrePlanpagosBLLocal extends GenericBLLocal<PrePlanpagos, Integer>{
	public Integer getCantidad(Integer coddsb)throws OperationException;
	public Integer getCantidadPreAutorizado(Integer coddsb)throws OperationException;

	//public List<Object[]> mostrarPlanDePagos(Integer codcred,Integer coddsb)throws OperationException;
	public List<Object[]> mostrarPlanDePagos(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;
	public List<Object[]> mostrarPlanDePagosGeneral(Integer codcred,Integer codmod,Integer coddsb)throws OperationException;
	public void actualizarPlanDePagos0(Integer codcred,Integer codmod)throws OperationException;
	public void realizarCobro(Integer codcred,Integer codmod,Date fechaVen, Date fechaAct,Integer accion, String usuario, String estacion)throws OperationException,SQLException;
	public void quitarCuota(Integer codcred,Integer codmod,Integer coddsb, Date fechaCuo, String usuario, String estacion)throws OperationException;
	public List<Object[]> mostrarPlanDePagosDetalleEstados(Integer codcred,Integer codmod,Integer coddsb)throws OperationException;
	public void actualizarConsolidado(Integer codcred,Integer codmod,Integer codmodtmp)throws OperationException;	
	public void actualizarDesembolso(Integer codcred,Integer codmod,Integer codmodtmp,Integer coddsb)throws OperationException;

	public List<Object[]> getTotalBonoValorGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

	/**
	 * Metodo que recupera el plan de pagos por gestion sin cancelar
	 * @param codcred
	 * @param codmod
	 * @param coddsb
	 * @param pGestion
	 * @return
	 * @throws OperationException
	 */
	public List<PlanPagoDto> mostrarPlanDePagosPorGestionSinCancelar(Integer codcred,Integer codmod,Integer coddsb,Integer pGestion) throws OperationException;

	public PlanPagoDto recuperarPlanDePagoPorParametros(Integer codcred,Integer codmod,Integer coddsb, Date cuoFecvencuo)throws OperationException;
    List<VPlanPagosConsolQuery> planConsolPorCodmodYCodcred(Integer codcred, Integer codmod);
    List<VPlanPagosConsolQuery> generarPlanPagos(PreReprograma pre);
    /**
     * Genera la lista de fechas de vencimiento a partir de una fecha inicial,
     * número de periodos y unidad de plazo.
     */
    List<Date> generarFechasVencimiento(Integer codcred, Integer codmod);
    void generarCalendario(Integer codcred, Integer codmod, Integer tipotrx, Integer codrepro, Date fCorterepro,
            Date fechaPrimAmort, Date fechaPrimAmortint, BigDecimal tasa, Integer unidplaz, Integer nroamortInt,
            String usuario, String estacion);
    PreReprograma genCalendarioGetVencimientos(PreReprograma preReprograma, Integer tipotrx, String usuario, String estacion) ;
}
