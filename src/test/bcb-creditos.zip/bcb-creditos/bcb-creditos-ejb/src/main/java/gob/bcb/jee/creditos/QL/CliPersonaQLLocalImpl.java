/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.util.Cttes;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class CliPersonaQLLocalImpl extends
        GenericQLLocalImpl<CliPersona, Integer> implements
        CliPersonaQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /*
     * (non-Javadoc)
     * @see
     * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
     * ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

	@Override
	public Integer getIdNewId() throws OperationException{
		String nativeQuery="select max(cli_codigo) from cli_persona";
		Query query=entityManager.createNativeQuery(nativeQuery);
		Object valor=query.getSingleResult();
		int id=1;
		if(valor!=null) {
			id=Integer.parseInt(valor.toString())+1;
		}
		return id;
	}

	@Override
	public String obtenerInstitucion(Integer institucion) throws OperationException {
		if (institucion == null) {
			return null;
		}
		String nativeQuery="select * from cli_persona where cli_codigo= :codCliente";
		Query query=entityManager.createNativeQuery(nativeQuery, CliPersona.class).setParameter("codCliente", institucion);
		List<CliPersona> valor= query.getResultList();

		if(valor.size() > 0) {
			return valor.get(0).getCliIdentifica();
		}
		return null;
	}

}
