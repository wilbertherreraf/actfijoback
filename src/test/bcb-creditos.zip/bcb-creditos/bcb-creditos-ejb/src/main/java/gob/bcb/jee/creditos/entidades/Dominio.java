/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.entidades.Dominio
 * 30/03/2016 - 10:28:10
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 * clase para la entidad Dominio
 *
 * @author ysalinas
 */
@Getter
@Setter
@Entity
@Table(name = "DOMINIO")

public class Dominio extends Entidad<String> implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final String ENTITY = "Dominio";
    @Id
    @NotNull
    @Column(name = "cod_dominio")
    private String id;
    
    @NotNull
    
    @Column(name = "desc_dominio")
    private String descDominio;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "dominio", fetch = FetchType.LAZY)
    private List<ValorDominio> valorDominioList;

}