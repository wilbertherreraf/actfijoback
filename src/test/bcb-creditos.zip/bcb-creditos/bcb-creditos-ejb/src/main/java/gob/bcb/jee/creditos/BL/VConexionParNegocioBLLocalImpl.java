/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mvdb-ejb
 * gob.bcb.jee.mvdb.negocioBL.VOperacionParNegocioBLLocalImpl
 * 18/04/2016 - 10:05:31
 * Creado por vluque
 */
package gob.bcb.jee.creditos.BL;

import java.sql.Connection;
import java.sql.SQLException;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.engine.jdbc.spi.JdbcServices;
import org.hibernate.engine.spi.SessionFactoryImplementor;

import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad
 * VOperacionParNegocioBLLocalImpl
 * 
 * 
 * @author vluque
 * 
 */
@Stateless
@LocalBean
public class VConexionParNegocioBLLocalImpl implements VConexionParNegocioBLLocal
{
 

  @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
  EntityManager em;

  @Override
  public Connection obtenerConnectionCreditos() {
  	
  		Connection cnn = null;
  		Session session = (Session) em.getDelegate();
		//SessionFactoryImplementor sfi = (SessionFactoryImplementor) session.getSessionFactory();
		//ConnectionProvider cp = sfi.getConnectionProvider();

		SessionFactoryImplementor sessionFactory = (SessionFactoryImplementor) session.getSessionFactory();
		JdbcServices jdbcServices = sessionFactory.getServiceRegistry().getService(JdbcServices.class);
		try {
			//ConnectionProvider provider = jdbcServices.getBootstrapJdbcConnectionAccess().obtainConnection();
			cnn = jdbcServices.getBootstrapJdbcConnectionAccess().obtainConnection();
		} catch (SQLException e) {
			
			Log.Error("======> " + e.getMessage());
		}
  	return cnn;
  }

}
