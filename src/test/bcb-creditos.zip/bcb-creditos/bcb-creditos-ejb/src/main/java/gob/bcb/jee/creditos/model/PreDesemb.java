package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.enterprise.inject.Default;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import gob.bcb.jee.creditos.util.Reflection;
import lombok.Getter;
import lombok.Setter;


@Entity
@Getter
@Setter
@Table(name="pre_desemb")
@NamedQueries({
    @NamedQuery(name = PreDesemb.NQ_GET_BY_ID, query = "SELECT e FROM PreDesemb e where e.dsbCoddsb = :valor1 "),    
    @NamedQuery(name = PreDesemb.NQ_GET_NEW_ID, query = "SELECT e FROM PreDesemb e where e.dsbCoddsb = :valor1 "),
    @NamedQuery(name = PreDesemb.NQ_LIST_BY_CREDITO, query = "SELECT e FROM PreDesemb e where e.dsbCodcred = :valor1 and e.dsbCodmod=:valor2 "),  
    @NamedQuery(name = PreDesemb.NQ_LIST_ALL, query = "SELECT p FROM PreDesemb p")
    
})
public class PreDesemb  extends EntidadAutorizable<Integer> implements Serializable{
	  private static final long serialVersionUID = 1L;
	  public static final String ENTITY ="PreDesemb";
	  public static final String NQ_GET_BY_ID =ENTITY+"GetById";
	  public static final String NQ_GET_NEW_ID =ENTITY+"GetNewId";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	  public static final String NQ_LIST_BY_CREDITO = ENTITY + "ListByCred";
	@Id		
	@Column(name="dsb_coddsb")
	private Integer dsbCoddsb;

	@Column(name="dsb_codcred")
	private Integer dsbCodcred;
	
	@Column(name="dsb_codmod")
	private Integer dsbCodmod;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_fecdsb")
	private Date dsbFecdsb;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_fecini")	
	private Date dsbFecini;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_feciniint")
	private Date dsbFeciniint;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_fecfin")
	private Date dsbFecfin;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_feculttrx")
	private Date dsbFeculttrx;
			
	@Column(name="dsb_tasa")
	private Double dsbTasa;
	
	@Column(name="dsb_valor")
	private BigDecimal dsbValor;
	
	@Column(name="dsb_valorcuo")
	private BigDecimal dsbValorcuo;
	
	
	@Column(name="dsb_valordeven")
	private BigDecimal dsbValordeven;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_fecprimpag")
	private Date dsbFecprimpag;

	@Column(name="dsb_undsb")
	private BigDecimal dsbUndsb;
	
	@Column(name="dsb_saldo")
	private BigDecimal dsbSaldo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_fecinidif")
	private Date dsbFecinidif;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_fecfindif")
	private Date dsbFecfindif;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_fecplzven")
	private Date dsbFecplzven;
	
	@Column(name="dsb_tabmethodcapi")
	private Integer dsbTabmethodcapi;
	
	@Column(name="dsb_methodcapi")
	private Integer dsbMethodcapi;
	
	@Column(name="dsb_tabtipodsb")
	private Integer dsbTabtipodsb;
	
	@Column(name="dsb_tipodsb")
	private Integer dsbTipodsb;
	
	@Column(name="dsb_tabunidplaz")
	private Integer dsbTabunidplaz;
	
	@Column(name="dsb_unidplaz")
	private Integer dsbUnidplaz;
	
	@Column(name="dsb_tabunidplazint")
	private Integer dsbTabunidplazint;
	
	@Column(name="dsb_unidplazint")
	private Integer dsbUnidplazint;
	
	@Column(name="dsb_tabmonpag")
	private Integer dsbTabmonpag;
	
	@Column(name="dsb_monpag")
	private Integer dsbMonpag;
	
	@Column(name="dsb_numtrx")
	private Integer dsbNumtrx;
	
	@Column(name="dsb_nrodoc")
	private String dsbNrodoc; 
	
	@Column(name="dsb_tabtrxstaau")
	private Integer dsbTabtrxstaau;
	
	@Column(name="dsb_trxstaau")
	private Integer dsbTrxstaau;
		
	@Column(name="dsb_auditusr")
	private String dsbAuditusr;
	
	@Column(name="dsb_auditfho")
	private Timestamp dsbAuditfho;
	
	@Column(name="dsb_auditwst")
	private String dsbAuditwst;
							
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_fecinidifint")
	private Date dsbFecinidifint;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dsb_fecfindifint")
	private Date dsbFecfindifint;
	
	
	
	public PreDesemb() {
		super();
	}
	@Override
	public String toString() {
		Reflection<PreDesemb> reflex=new Reflection<PreDesemb>();
		return reflex.imprimirCampos(this);
	}

    @Override
    public boolean equals(Object o) {
    	Reflection<PreDesemb> reflex=new Reflection<PreDesemb>();
		return reflex.equals(this,o);      
    }

    @Override
    public int hashCode() {
    	Reflection<PreDesemb> reflex=new Reflection<PreDesemb>();
		return reflex.generarHash(this);
    }
	@Override
	public Integer getId() {		
		return dsbCoddsb;
	}
	@Override
	public void setId(Integer id) {
		this.dsbCoddsb=id;
		
	}	
}
