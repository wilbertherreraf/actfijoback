package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;


/**
 * The persistent class for the gen_tipproducto database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="gen_tipproducto")
@NamedQueries({
    @NamedQuery(name = GenTipproducto.NQ_LIST_ALL, query = "SELECT p FROM GenTipproducto p"),
    @NamedQuery(name = GenTipproducto.NQ_GET_BY_ID_MOD, query = "SELECT p FROM GenTipproducto p where p.id.tpdCodmod=:valor1 "),
    @NamedQuery(name = GenTipproducto.NQ_GET_BY_ID, query = "SELECT p FROM GenTipproducto p where p.id.tpdCodmod=:valor1 and p.id.tpdCodprod=:valor2 ")
    
})
public class GenTipproducto extends EntidadAutorizable<GenTipproductoPK>  implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="GenTipproducto";
	  public static final String NQ_GET_BY_ID_MOD =ENTITY+"GetByIdMod";
	  public static final String NQ_GET_BY_ID =ENTITY+"GetById";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";	  
	@EmbeddedId
	private GenTipproductoPK id;

	@Column(name="tpd_auditfho")
	private Timestamp tpdAuditfho;
	

	@Column(name="tpd_auditusr")
	private String tpdAuditusr;

	@Column(name="tpd_auditwst")
	private String tpdAuditwst;

	@Column(name="tpd_descrip")
	private String tpdDescrip;

	@Column(name="tpd_diasbase")
	private Integer tpdDiasbase;

	@Column(name="tpd_diascast")
	private Integer tpdDiascast;

	@Column(name="tpd_diaseje")
	private Integer tpdDiaseje;

	@Column(name="tpd_diaslarplz")
	private Integer tpdDiaslarplz;

//	@Column(name="tpd_diastol1ven")
//	private Integer tpdDiastol1ven;
//
//	@Column(name="tpd_diastol2ven")
//	private Integer tpdDiastol2ven;

	@Column(name="tpd_diasvenc")
	private Integer tpdDiasvenc;

	@Column(name="tpd_fpago")
	private Integer tpdFpago;

//	@Column(name="tpd_peja")
//	private String tpdPeja;

	@Column(name="tpd_tabfpago")
	private Integer tpdTabfpago;

//	@Column(name="tpd_tabtipprest")
//	private Integer tpdTabtipprest;

//	@Column(name="tpd_tabtramo")
//	private Integer tpdTabtramo;

//	@Column(name="tpd_tabtrxstaau")
//	private Integer tpdTabtrxstaau;

//	@Column(name="tpd_tipprest")
//	private Integer tpdTipprest;

//	@Column(name="tpd_tramo")
//	private Integer tpdTramo;

//	@Column(name="tpd_trxstaau")
//	private Integer tpdTrxstaau;

	@Column(name="tpd_vencuo")
	private String tpdVencuo;

	public GenTipproducto() {
	}

	
}
