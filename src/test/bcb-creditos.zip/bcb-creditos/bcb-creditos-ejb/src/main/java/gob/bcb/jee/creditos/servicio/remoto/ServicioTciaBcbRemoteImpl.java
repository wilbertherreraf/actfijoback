package gob.bcb.jee.creditos.servicio.remoto;
//package gob.bcb.jee.creditos.plantillaWebEE.servicio.remoto;
//
//import gob.bcb.jee.creditos.plantillaWebEE.excepciones.OperationException;
//import gob.bcb.tciabcb.entidades.Agencia;
//import gob.bcb.tciabcb.entidades.Aplicacion;
//import gob.bcb.tciabcb.entidades.ValorDominio;
//import gob.bcb.tciabcb.entidades.Contrasenia;
//import gob.bcb.tciabcb.entidades.Participante;
//import gob.bcb.tciabcb.entidades.Persona;
//import gob.bcb.tciabcb.entidades.PersonaPK;
//import gob.bcb.tciabcb.entidades.Recurso;
//import gob.bcb.tciabcb.entidades.Rol;
//import gob.bcb.tciabcb.entidades.Sesion;
//import gob.bcb.tciabcb.entidades.Usuario;
//import gob.bcb.tciabcb.remoto.EjbAgenciaRemoto;
//import gob.bcb.tciabcb.remoto.EjbComunRemoto;
//import gob.bcb.tciabcb.remoto.EjbContraseniaRemoto;
//import gob.bcb.tciabcb.remoto.EjbParticipanteRemoto;
//import gob.bcb.tciabcb.remoto.EjbPersonaRemoto;
//import gob.bcb.tciabcb.remoto.EjbRecursoRemoto;
//import gob.bcb.tciabcb.remoto.EjbRolRemoto;
//import gob.bcb.tciabcb.remoto.EjbSesionRemoto;
//import gob.bcb.tciabcb.remoto.EjbUsuarioRemoto;
//import gob.bcb.tciabcb.remoto.EjbUsuarioRolRemoto;
//import gob.bcb.tciabcb.remoto.ServiciosWebLIPRemoto;
//import gob.bcb.tciabcb.util.BeanUsuario;
//import gob.bcb.tciabcb.util.ESTADO_REGISTRO;
//import gob.bcb.tciabcb.util.UtilRemoto;
//
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//import javax.ejb.Stateless;
//
//import org.apache.log4j.Logger;
//
///**
// * Implementacion de los EJB Remotos del TCIABCB
// * 
// * @author fmamani
// * 
// */
//@Stateless
//public class ServicioTciaBcbRemoteImpl implements ServicioTciaBcbRemote
//{
//  // private static final Logger log =
//  // LoggerFactory.getLogger(ServicioTciaBcbRemoteImpl.class);
//  private static final Logger log = Logger
//      .getLogger(ServicioTciaBcbRemoteImpl.class);
//
//  private ServiciosWebLIPRemoto serviciosWebLIPRemoto = UtilRemoto
//      .consumirEJBTCIABCB(ServiciosWebLIPRemoto.class);
//  private EjbUsuarioRemoto ejbUsuarioRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbUsuarioRemoto.class);
//  private EjbRolRemoto ejbRolRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbRolRemoto.class);
//  private EjbUsuarioRolRemoto ejbUsuarioRolRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbUsuarioRolRemoto.class);
//  private EjbAgenciaRemoto ejbAgenciaRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbAgenciaRemoto.class);
//  private EjbComunRemoto ejbComunRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbComunRemoto.class);
//  private EjbContraseniaRemoto ejbContraseniaRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbContraseniaRemoto.class);
//  private EjbSesionRemoto ejbSesionRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbSesionRemoto.class);
//  private EjbPersonaRemoto ejbPersonaRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbPersonaRemoto.class);
//  private EjbParticipanteRemoto ejbParticipanteRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbParticipanteRemoto.class);
//  private EjbRecursoRemoto ejbRecursoRemoto = UtilRemoto
//      .consumirEJBTCIABCB(EjbRecursoRemoto.class);
//
//  public String buscarNombreParticipante(String codParticipante)
//      throws Exception
//  {
//    try
//    {
//      String nomParticipante = "";
//
//      Participante participante = serviciosWebLIPRemoto
//          .obtenerDatosParticipante(codParticipante.trim());
//      if (participante != null)
//      {
//        if (participante.getNomParticipante().equals("")
//            || participante.getNomParticipante() == null)
//        {
//          nomParticipante = "DATO NO DEFINIDO EN SEGURIDAD TCIABCB";
//        }
//        else
//        {
//          nomParticipante = participante.getNomParticipante();
//        }
//      }
//      else
//      {
//        nomParticipante = "DATO NO DEFINIDO EN SEGURIDAD TCIABCB";
//      }
//      log.info("Participante encontrado de servicio remoto:"
//          + nomParticipante + "<");
//
//      return nomParticipante;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  public boolean esUsuarioBCB(String codUsuario) throws Exception
//  {
//    try
//    {
//      boolean salida = false;
//
//      salida = serviciosWebLIPRemoto.isUsuarioBCB(codUsuario);
//
//      log.info("Verificacion de servicio remoto si es usuario BCB: "
//          + salida);
//
//      return salida;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//
//  }
//
//  @Override
//  public List<Usuario> listarUsuarios(String codAplicacion,
//      String codParticipante) throws Exception
//  {
//    try
//    {
//      List<Usuario> respuesta = null;
//
//      respuesta = ejbUsuarioRemoto.listarUsuarios(codAplicacion,
//          codParticipante);
//
//      log.info("Total usuarios obtenidos de servicio remoto: "
//          + (respuesta != null ? respuesta.size() : null));
//
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public Usuario agregarUsuario(Usuario usuario,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception
//  {
//    try
//    {
//      Usuario usr = ejbUsuarioRemoto.agregar(usuario, beanUsuarioTciaBcb);
//
//      log.info("Usuario " + usuario.getNombreCompleto() + " agregado.");
//
//      return usr;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public Usuario modificarUsuario(Usuario usuario,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception
//  {
//    try
//    {
//      Usuario usr = ejbUsuarioRemoto.modificar(usuario,
//          beanUsuarioTciaBcb);
//
//      log.info("Usuario " + usuario.getNombreCompleto() + "modificado.");
//
//      return usr;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public void cambiarEstadoRegistroUsuario(String codUsuario,
//      ESTADO_REGISTRO estadoRegistro, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception
//  {
//    try
//    {
//      ejbUsuarioRemoto.cambiarEstadoRegistro(codUsuario, estadoRegistro,
//          beanUsuarioTciaBcb);
//      log.info("Estado de registro cambiado para usuario a "
//          + estadoRegistro);
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public List<Rol> listarRolesTodosVigentes(String codAplicacion)
//      throws Exception
//  {
//    try
//    {
//      List<Rol> respuesta = ejbRolRemoto
//          .listarTodosVigentes(codAplicacion);
//      log.info("Total roles vigentes obtenidos: "
//          + (respuesta != null ? respuesta.size() : null));
//
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public List<Rol> listarRolesDelUsuario(String codAplicacion, String usrLogin)
//      throws Exception
//  {
//    try
//    {
//      List<Rol> respuesta = ejbRolRemoto.listarRolesDelUsuario(
//          codAplicacion, usrLogin);
//      log.info("Total roles de usuario obtenidos: "
//          + (respuesta != null ? respuesta.size() : null));
//
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public List<Rol> listarRolesVisiblesPorTipoParticipante(
//      String codAplicacion, Participante participante) throws Exception
//  {
//    try
//    {
//      List<Rol> respuesta = new ArrayList<Rol>();
//      respuesta = ejbRolRemoto.listarRolesVisiblesPorTipoParticipante(
//          codAplicacion, participante);
//
//      log.info("Total roles vigentes para el nivel visible "
//          + participante.getTipoParticipante()
//              .getCodTipoParticipante() + " obtenidos: "
//          + (respuesta != null ? respuesta.size() : null));
//
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public void cambiarRol(String codUsuario, List<Rol> listaRoles,
//      String codAplicacion, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception
//  {
//    try
//    {
//      ejbUsuarioRolRemoto.cambiarRol(codUsuario, listaRoles,
//          codAplicacion, beanUsuarioTciaBcb);
//
//      log.info("Rol cambiado para " + codUsuario);
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public List<Agencia> listarAgenciasTodosVigentes(String codParticipante)
//      throws Exception
//  {
//    try
//    {
//      List<Agencia> respuesta = ejbAgenciaRemoto
//          .listarTodosVigentes(codParticipante);
//      log.info("Total agencias obtenidas: "
//          + (respuesta != null ? respuesta.size() : null));
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public List<ValorDominio> obtenerClaves(String dominioSelected) throws Exception
//  {
//    try
//    {
//      List<ValorDominio> respuesta = ejbComunRemoto.obtenerClaves(dominioSelected);
//      log.info("Total claves obtenidas: "
//          + (respuesta != null ? respuesta.size() : null));
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public Contrasenia verificarContrasenia(String cd, String passCodif)
//      throws Exception
//  {
//    try
//    {
//      Contrasenia respuesta = ejbContraseniaRemoto.verificar(cd,
//          passCodif);
//      log.info("Contrasenia verificada");
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public boolean existeContraseniaEnLos8Ultimos(String codUsuario, String pass)
//      throws Exception
//  {
//    try
//    {
//      boolean respuesta = false;
//      respuesta = ejbContraseniaRemoto.existeContraseniaEnLos8Ultimos(
//          codUsuario, pass);
//      log.info("Contrasenia en 8 ult." + respuesta);
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//
//  }
//
//  @Override
//  public boolean vericarValidoContrasenia(String pass) throws Exception
//  {
//    try
//    {
//      boolean respuesta = ejbContraseniaRemoto
//          .vericarValidoContrasenia(pass);
//
//      log.info("Varifica Contrasenia valida" + respuesta);
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public void cambiarEstadoRegistroContrasenia(Object contraseniaId,
//      char estado, String codTransaccion, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception
//  {
//    try
//    {
//      ejbContraseniaRemoto.cambiarEstadoRegistro(contraseniaId, estado,
//          codTransaccion, beanUsuarioTciaBcb);
//      log.info("Estado de registro de contrasenia cambiado a " + estado);
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public void agregarContrasenia(Contrasenia contrasenia, String pass,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception
//  {
//    try
//    {
//      ejbContraseniaRemoto.agregar(contrasenia, pass, beanUsuarioTciaBcb);
//      log.info("Contrasenia agregada.");
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public String agregarContrasenaAutomatica(String usuarioLogin,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception
//  {
//    try
//    {
//      return ejbContraseniaRemoto.agregarContrasenaAutomatica(
//          usuarioLogin, beanUsuarioTciaBcb);
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public List<Agencia> listarAgenciasTodos(String codParticipante)
//      throws Exception
//  {
//    try
//    {
//      List<Agencia> respuesta = ejbAgenciaRemoto
//          .listarTodos(codParticipante);
//
//      log.info("Total agencias totales obtenidas: "
//          + (respuesta != null ? respuesta.size() : null));
//
//      return respuesta;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public void modificarAgencia(Agencia agencia, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception
//  {
//    try
//    {
//      ejbAgenciaRemoto.modificar(agencia, beanUsuarioTciaBcb);
//      log.info("Agencia modificada" + agencia.getAgenciaid());
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public void agregarAgencia(Agencia agencia, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception
//  {
//    try
//    {
//      ejbAgenciaRemoto.agregar(agencia, beanUsuarioTciaBcb);
//      log.info("Agencia agregada " + agencia.getAgenciaid());
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public void cambiarEstadoRegistroAgencia(Object idAgencia,
//      ESTADO_REGISTRO estadoRegistro, BeanUsuario beanUsuario)
//      throws Exception
//  {
//    try
//    {
//      ejbAgenciaRemoto.cambiarEstadoRegistro(idAgencia, estadoRegistro,
//          beanUsuario);
//      log.info("Estado de registro de agencia modificado a "
//          + estadoRegistro);
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public void limpiarSessionAbierta(String codUsuario, String codAplicacion)
//      throws Exception
//  {
//    try
//    {
//      log.info("Registrando session cerrada para usuario " + codUsuario);
//      Boolean respuesta = ejbSesionRemoto.limpiarSessionAbierta(
//          codUsuario, codAplicacion);
//      if (!respuesta)
//      {
//        throw new Exception("Limpieza incorrecta en TCIABCB");
//      }
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public void registrarSesionAbierta(String codApp, String codUsuario)
//      throws Exception
//  {
//    try
//    {
//      try
//      {
//        this.limpiarSessionAbierta(codUsuario, codApp);
//      }
//      catch (Exception ignore)
//      {
//      }
//
//      Sesion sesion = new Sesion();
//      sesion.setAplicacion(new Aplicacion(codApp));
//      sesion.setUsuario(new Usuario(codUsuario));
//      sesion.setFechaHoraInicio(new Date());
//      sesion.setFechaHoraFin(null);
//      sesion.setCveEstadoSesion('A');
//      ejbSesionRemoto.agregar(sesion);
//      log.info("Registrando session abierta para usuario " + codUsuario);
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public Persona agregarPersona(Persona persona,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception
//  {
//    try
//    {
//      Persona per = ejbPersonaRemoto.agregar(persona, beanUsuarioTciaBcb);
//
//      log.info("Persona " + persona.getNombreCompleto() + " agregado.");
//
//      return per;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public Persona modificarPersona(Persona persona,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception
//  {
//    try
//    {
//      Persona per = ejbPersonaRemoto.modificar(persona,
//          beanUsuarioTciaBcb);
//
//      log.info("Persona " + persona.getNombreCompleto() + "modificado.");
//
//      return per;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public Persona buscarPersona(PersonaPK personaPK) throws Exception
//  {
//    try
//    {
//      Persona per = ejbPersonaRemoto.buscar(personaPK);
//
//      return per;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public Usuario buscarUsuario(String usuarioLogin) throws Exception
//  {
//    try
//    {
//      Usuario usr = ejbUsuarioRemoto.buscarUsuario(usuarioLogin);
//
//      return usr;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public List<Object[]> obtenerParticipantesVigentes() throws Exception
//  {
//    try
//    {
//      List<Object[]> participantes = new ArrayList<Object[]>();
//
//      List<Participante> respuesta = ejbParticipanteRemoto
//          .listarTodosVigentes();
//      if (!respuesta.isEmpty())
//      {
//        Object[] obj;
//        for (Participante par : respuesta)
//        {
//          obj = new Object[2];
//          obj[0] = par.getCodParticipante();
//          obj[1] = par.getNomParticipante();
//          participantes.add(obj);
//        }
//      }
//
//      log.info("Total particiapntes obtenidas de servicio remoto: "
//          + (participantes != null ? participantes.size() : null));
//
//      return participantes;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//
//  }
//
//  /*
//   * (non-Javadoc)
//   * @see bo.gob.bcb.jee.creditos.lip.web.remotos.ServicioTciaBcbRemote#
//   * obtenerParticipanteCorresponsal()
//   */
//  @Override
//  public String obtenerParticipanteCorresponsal() throws Exception
//  {
//    String codPart = null;
//    try
//    {
//      Participante participante = null;
//      List<Participante> respuesta = ejbParticipanteRemoto
//          .listarTodosVigentes();
//      for (Participante part : respuesta)
//      {
//        if (part.getTipoParticipante().getCodTipoParticipante()
//            .equals("B_PUB"))
//        {
//          participante = part;
//          break;
//        }
//      }
//      if (participante == null)
//      {
//        throw new Exception(
//            "No existe definido un participante corresponsal.");
//      }
//      codPart = participante.getCodParticipante();
//      log.info("Particiapntes obtenidas de servicio remoto: "
//          + participante);
//
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//
//    return codPart;
//  }
//
//  @Override
//  public List<Recurso> obtenerListaRecursosAplicacion(String codApp)
//      throws Exception
//  {
//    try
//    {
//      List<Recurso> listaRecurso = ejbRecursoRemoto
//          .listarRecursosVigentesPorAplicacion(codApp);
//      return listaRecurso;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public List<Recurso> obtenerListaRecursosPorRol(String codRol)
//      throws Exception
//  {
//    try
//    {
//      List<Recurso> listaRecurso = ejbRecursoRemoto
//          .listarRecursosVigentesPorRol(codRol);
//      return listaRecurso;
//    }
//    catch (Exception e)
//    {
//      String msjError = "Error en los servicios remotos de TCIABCB.";
//      log.error(msjError, e);
//      throw new OperationException(msjError, e);
//    }
//  }
//
//  @Override
//  public boolean testConection()
//  {
//    return ejbComunRemoto.testConexion();
//  }
//
// }
