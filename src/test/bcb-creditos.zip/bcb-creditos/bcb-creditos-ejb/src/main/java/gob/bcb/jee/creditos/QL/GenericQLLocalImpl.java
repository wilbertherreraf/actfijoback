/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.QL.GenericNegocioQLImpl
 * 05/11/2015 - 11:29:46
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Entidad;
import gob.bcb.jee.creditos.model.AuxPlanpagos;
import gob.bcb.jee.creditos.util.Log;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.NoResultException;
import javax.persistence.Query;


/**
 * Implementacion de los metodos de consulta (QL) genericos
 * 
 * 
 * @author ysalinas
 * 
 */
@SuppressWarnings("rawtypes")
@Stateless
public abstract class GenericQLLocalImpl<T extends Entidad, ID extends Serializable>
    implements GenericQLLocal<T, ID>
{
 
  // @PersistenceContext(unitName = Cttes.UP_SAAPFBCB)
  // protected EntityManager entityManager;
  protected abstract EntityManager entityManager();

  // protected EntityManager entityManager;

  @Override
  public T get(ID id)
  {
    T entitie = entityManager().find(getEntityClass(), id);
    entityManager().lock(entitie, LockModeType.NONE);
    return entitie;
  }

  @SuppressWarnings("unchecked")
  @Override
  public T getByNamedQuery(String namedQuery, Map<String, Object> parameters)
  {
    Query query = entityManager().createNamedQuery(namedQuery);
    for (String parameter : parameters.keySet())
    {
      query.setParameter(parameter, parameters.get(parameter));
    }
    try
    {
      T entidad = (T) query.getSingleResult();
      entityManager().lock(entidad, LockModeType.NONE);
      return entidad;
    }
    catch (NoResultException e)
    {
      return null;
    }
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<T> list()
  {
    Query query = entityManager().createQuery("SELECT e FROM "
        + getEntityClass().getName() + " e");
    //query.setHint("hibernate.cache.use_query_cache", true);
    return query.getResultList();
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<T> list(String filtro)
  {
    try
    {
      Query query = entityManager().createNamedQuery(getEntityClass()
          .getSimpleName() + Entidad.NQ_SEARCH);
      query.setParameter("filtro", "%" + filtro.toUpperCase() + "%");
      //query.setHint("hibernate.cache.use_query_cache", true);
      List<T> lista = query.getResultList();
      return lista;
    }
    catch (Exception e)
    {
      Log.Error(e.getMessage());
      throw new RuntimeException(e);
    }
  }

  /**
   * Metodo que obtiene una lista de objetos a traves de un NamedQuery sin
   * parametros
   */
  @Override
  public List<T> listByNamedQuery(String namedQuery)
  {
    return listByNamedQuery(namedQuery, new HashMap<String, Object>());
  }

  /**
   * Metodo que obtiene una lista de objetos a traves de un NamedQuery con
   * parametros
   */
  @SuppressWarnings("unchecked")
  @Override
  public List<T> listByNamedQuery(String namedQuery,
      Map<String, Object> parameters)
  {
    return listByNamedQuery(namedQuery, parameters, null);
  }

  /**
   * Metodo que obtiene una lista de objectos de un NamedQuery con parametros y
   * un maximo de registros
   */
  @SuppressWarnings("unchecked")
  @Override
  public List<T> listByNamedQuery(String namedQuery,
      Map<String, Object> parameters, Integer maxResult)
  {
    Query query = entityManager().createNamedQuery(namedQuery);
    for (String parameter : parameters.keySet())
    {
      query.setParameter(parameter, parameters.get(parameter));
    }
    if (maxResult != null)
    {
      query.setMaxResults(maxResult);
    }
    query.setLockMode(LockModeType.NONE);
    //query.setHint("hibernate.cache.use_query_cache", true);
    // log.trace("current query lock mode: " + query.getLockMode());
    return (List<T>) query.getResultList();
  }

  /**
   * Metodo para obtener una lista de objetos con las dependencias de las clases
   */
  @SuppressWarnings("unchecked")
  @Override
  public T getLazy(ID id)
  {
    Query query = entityManager().createNamedQuery(getEntityClass()
        .getSimpleName() + Entidad.NQ_GET_LAZY);
    query.setParameter("id", id);
    //query.setHint("hibernate.cache.use_query_cache", true);
    try
    {
      // return (T) query.getSingleResult();
      T entidad = (T) query.getSingleResult();
      entityManager().lock(entidad, LockModeType.NONE);
      return entidad;
    }
    catch (NoResultException e)
    {
      return null;
    }
  }

  /**
   * Metodo que obtiene la entidad sobre la que se trabaja actualmente
   */
  @SuppressWarnings("unchecked")
  private Class<T> getEntityClass()
  {
    return (Class<T>) ((ParameterizedType) getClass()
        .getGenericSuperclass()).getActualTypeArguments()[0];
  }

  @Override
  public Object getObjectByNamedQuery(String namedQuery) {
    return getObjectByNamedQuery(namedQuery, new HashMap<String, Object>());
  }

  @Override
  public Object getObjectByNamedQuery(String namedQuery,
                                      Map<String, Object> parameters) {
    Query query = entityManager().createNamedQuery(namedQuery);
    for (String parameter : parameters.keySet()) {
      query.setParameter(parameter, parameters.get(parameter));
    }
    query.setMaxResults(1);
    //query.setHint("hibernate.cache.use_query_cache", true);
    try {
      Object objeto = (Object) query.getSingleResult();
      return objeto;
    } catch (NoResultException e) {
      return null;
    }
  }

  @Override
  public Object getListObjectByNamedQuery(String namedQuery) {
    return getListObjectByNamedQuery(namedQuery, new HashMap<String, Object>());
  }

  @Override
  public Object getListObjectByNamedQuery(String namedQuery,
                                           Map<String, Object> parameters) {
    Query query = entityManager().createNamedQuery(namedQuery);
    for (String parameter : parameters.keySet()) {
      query.setParameter(parameter, parameters.get(parameter));
    }
//    query.setMaxResults(1);
    //query.setHint("hibernate.cache.use_query_cache", true);
    try {

      return query.getResultList();
    } catch (NoResultException e) {
      return null;
    }
  }

  public List<AuxPlanpagos> obtCalendarioPP(Integer codcred, Integer codmod) {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'obtCalendarioPP'");
  }

  public List<AuxPlanpagos> obtCalendarioaPP(Integer codcred, Integer codmod) {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'obtCalendarioaPP'");
  }


}
