/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.VPVPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.VPVPlanPagosDsbQuery;
import gob.bcb.jee.creditos.entidades.VPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.VPlanPagosDsbQuery;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.pojo.PlanPagoDto;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;


@Local
public interface PrePlanpagosQLLocal extends
        GenericQLLocal<PrePlanpagos,Integer>
{
	public Integer getCantidad(Integer coddsb) throws OperationException;
//	public Integer getCantidadAutorizado(Integer coddsb,Integer codgenerado,Integer codAut) ;
	public Integer getCantidadPreAutorizado(Integer coddsb) throws OperationException;
	
	//public List<Object[]> mostrarPlanDePagos(Integer codcred,Integer coddsb)throws OperationException;
	public List<Object[]> mostrarPlanDePagos(Integer codcred,Integer codmod,Integer coddsb)throws OperationException;
	
	public List<Object[]> mostrarPlanDePagosGeneral(Integer codcred,Integer codmod,Integer coddsb)throws OperationException;
	public void actualizarPlanDePagos0(Integer codcred,Integer codmod)throws OperationException;
	
	public void realizarCobro(Integer codcred,Integer codmod,Date fechaVen, Date fechaAct,Integer accion, String usuario, String estacion)throws OperationException,SQLException;
	public void quitarCuota(Integer codcred,Integer codmod,Integer coddsb, Date fechaCuo, String usuario, String estacion)throws OperationException;
	
	public List<Object[]> mostrarPlanDePagosDetalleEstados(Integer codcred,Integer codmod,Integer coddsb)throws OperationException;
	
	public void actualizarConsolidado(Integer codcred,Integer codmod,Integer codmodtmp)throws OperationException;
	
	public void actualizarDesembolso(Integer codcred,Integer codmod,Integer codmodtmp,Integer coddsb)throws OperationException;

	public List<Object[]> getTotalBonoValorGarantia(Integer codcred,Integer codmod,Integer coddsb)throws OperationException;

	public List<PlanPagoDto> recuperarPlanDePagosPorGestionSinCancelar(Integer codcred,Integer codmod,Integer coddsb,Integer pGestion)throws OperationException;

	public PlanPagoDto recuperarPlanDePagoPorParametros(Integer codcred,Integer codmod,Integer coddsb, Date cuoFecvencuo)throws OperationException;
    List<VPlanPagosConsolQuery> planConsolPorCodmodYCodcred(Integer codcred, Integer codmod);
    List<VPlanPagosConsolQuery> cuotasVencPendOSgtes(Integer codcred, Integer codmod, Date fechaActual);
    List<VPlanPagosDsbQuery> planDsbPorCodmodYCodcred(Integer codcred, Integer codmod, Integer coddsb);
    List<VPlanPagosDsbQuery> planDsbPorCodmodYCodcredPV(Integer codcred, Integer codmod, Integer coddsb);	
    List<VPlanPagosDsbQuery> cuotasVencPendOSgtesDsb(Integer codcred, Integer codmod, Integer coddsb, Date fechaActual);
    List<VPlanPagosConsolQuery> cuotasVencPendOSgtes(Date fechaIni, Date fechaActual);
    List<VPVPlanPagosConsolQuery> planVPConsolPorCodmodYCodcred(Integer codcred, Integer codmod);
    List<VPVPlanPagosDsbQuery> planVPDsbPorCodmodYCodcred(Integer codcred, Integer codmod, Integer coddsb);
    List<VPlanPagosConsolQuery> planpagosPPOPV(Integer codcred, Integer codmod);
    List<VPVPlanPagosDsbQuery> planpagosPPOPVAFecha(Integer codcred, Integer codmod, Date fecha, Integer tipotrx);
    void generarCalendario(Integer codcred, Integer codmod, Integer tipotrx, Integer codrepro, Date fCorterepro,
            Date fechaPrimAmort, Date fechaPrimAmortint, BigDecimal tasa, Integer unidplaz, Integer nroamortInt,
            String usuario, String estacion);

}
