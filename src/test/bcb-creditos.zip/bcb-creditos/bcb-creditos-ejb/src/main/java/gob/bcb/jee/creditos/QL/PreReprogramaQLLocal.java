/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.util.List;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreReprograma;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface PreReprogramaQLLocal extends
        GenericQLLocal<PreReprograma,Integer>
{
	public Integer nuevoId() throws OperationException;
	public List<Object[]> obtenerContratos(Integer codcred,Integer codmod)throws OperationException;
    List<PreReprograma> reprosByCred(Integer codcred, Integer codmod,Integer tiporepro);
    PreReprograma guardarRepro(PreReprograma repro);
    PreReprograma findByCodRepro(Integer codrepro);
}
