/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.ArticuloQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.dao.ArticuloDao;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.Articulo;
import gob.bcb.jee.creditos.util.Cttes;


@Stateless
@LocalBean
public class ArticuloBLLocalImpl extends
        GenericBLLocalImpl<Articulo, Integer>
        implements ArticuloBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    ArticuloQLLocal parametrosQLLocal;

    @Inject
    ArticuloDao parametroDao;

    @Override
    public GenericQLLocal<Articulo, Integer> getQLBean() {
        return parametrosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<Articulo, Integer> getGenericDao() {
        return parametroDao;
    }

	@Override
	public void validar(Articulo entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Integer getIdNuevo() throws OperationException {

		return parametrosQLLocal.getIdNuevo();
	}

	@Override
	public List<Object[]> obtenerLeyesRelacionadas(Integer id_cli_persona) throws OperationException {
		// TODO Auto-generated method stub
		return parametrosQLLocal.obtenerLeyesRelacionadas(id_cli_persona);
	}

}
