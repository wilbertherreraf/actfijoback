/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.NormativaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.NormativaEmpresa;

import javax.ejb.Local;

/**
 * Banco Central de Bolivia Usuario: Ariel Escobar Fecha: 2/6/2016 Hora: 9:22:15
 */

@Local
public interface NormativaEmpresaQLLocal extends
    GenericQLLocal<NormativaEmpresa, Integer>
{

}
