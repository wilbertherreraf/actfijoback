/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PrePrestamosQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PrePrestamosDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PrePrestamosPK;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class PrePrestamosBLLocalImpl extends
		GenericBLLocalImpl<PrePrestamos, PrePrestamosPK>
		implements PrePrestamosBLLocal {

	@PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
	EntityManager em;
	/*
	 * Inyeccion de los metodos para consulta (QL)
	 */
	@Inject
	PrePrestamosQLLocal prePrestamosQLLocal;

	@Inject
	PrePrestamosDao parametroDao;

	@Inject
	private PreReprogramaBLLocal preReprogramaBLLocal;

	@Override
	public GenericQLLocal<PrePrestamos, PrePrestamosPK> getQLBean() {
		return prePrestamosQLLocal;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
	 */
	@Override
	public GenericDao<PrePrestamos, PrePrestamosPK> getGenericDao() {
		return parametroDao;
	}

	@Override
	public void validar(PrePrestamos entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub

	}

	@Override
	public Integer getIdByModulo(Integer codmod) throws OperationException {
		int valorMaximo = prePrestamosQLLocal.getIdByModulo(codmod);
		return valorMaximo;
	}

	@Override
	public Integer getValorPeriodicidad(Integer valor) throws OperationException {
		int valor1 = prePrestamosQLLocal.getValorPeriodicidad(valor);
		return valor1;
	}

	public void procesarReprogramacion(Integer tipotrx, Integer codrepo, Date fecha, String user,	String ip) {
		
		prePrestamosQLLocal.procesarReprogramacion(tipotrx, codrepo, fecha, user,	ip);
	}

	@Override
	public void p_rpro_aprob_planpagos(Integer codcred, Integer codmod, Integer codtmp, Integer codrep, String user,
			String ip) throws OperationException {
		prePrestamosQLLocal.p_rpro_aprob_planpagos(codcred, codmod, codtmp, codrep, user, ip);
	}

	@Override
	public void pagoAnticipadoNuevo(PreReprograma preReprograma, Integer codmod, Integer codrepro, Date fechaoper,
			String user, String estacion) throws OperationException {
		try {
			PreReprograma preReprogramaNew = preReprogramaBLLocal.persist(preReprograma, user);
			Log.Info("Reprograma creado " + preReprogramaNew.getRdsCodrepro());
			prePrestamosQLLocal.pagoAnticipadoNuevo(codmod, preReprogramaNew.getRdsCodrepro(), fechaoper, user,
					estacion);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public void preAutoPagAnticip(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion)
			throws OperationException {
		prePrestamosQLLocal.preAutoPagAnticip(codmod, codrepro, fechaoper, user, estacion);
	}

	public void autorizarPagAnticip(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion) {
		prePrestamosQLLocal.autorizarPagAnticip(codmod, codrepro, fechaoper, user, estacion);
	}

	public void eliminarAutoPagAnticip(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion)
			throws OperationException {
		prePrestamosQLLocal.eliminarAutoPagAnticip(codmod, codrepro, fechaoper, user, estacion);
	}

	public void diferimiento(PreReprograma preReprograma, Integer tipotrx, Date fechaoper, Date fechaInicio,
			Date fechaFin, String user,
			String estacion) throws OperationException {
		PreReprograma preReprogramaNew = null;
		try {
			if (tipotrx.equals(1)) {
				preReprograma = preReprogramaBLLocal.persist(preReprograma, user);
				Log.Info("diferimiento creado " + preReprograma.getRdsCodrepro());
			}
			Log.Info("diferimiento antes proceso " + preReprograma.getRdsCodrepro() + " tipotrx " + tipotrx);
			prePrestamosQLLocal.diferimiento(tipotrx, preReprograma.getRdsCodrepro(), fechaoper, fechaInicio, fechaFin,
					user, estacion);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Integer obtenerCantidadDesembolsos(Integer codcred, Integer codmod) throws OperationException {
		return prePrestamosQLLocal.obtenerCantidadDesembolsos(codcred, codmod);
	}

	@Override
	public BigDecimal obtenerInteresesDevengado(Integer codcred, Integer codmod) throws OperationException {
		return prePrestamosQLLocal.obtenerInteresesDevengado(codcred, codmod);
	}

	@Override
	public BigDecimal obtenerInteresesCobrados(Integer codcred, Integer codmod) throws OperationException {
		return prePrestamosQLLocal.obtenerInteresesCobrados(codcred, codmod);
	}

	@Override
	public Date obtenerUltimaFechaPlanPagos(Integer codcred, Integer codmod) throws OperationException {
		return prePrestamosQLLocal.obtenerUltimaFechaPlanPagos(codcred, codmod);
	}

	@Override
	public BigDecimal obtenerMontoDescomprometido(Integer codcred, Integer codmod) throws OperationException {
		return prePrestamosQLLocal.obtenerMontoDescomprometido(codcred, codmod);
	}

	@Override
	public BigDecimal obtenerCapitalAmortizado(Integer codcred, Integer codmod) throws OperationException {
		return prePrestamosQLLocal.obtenerCapitalAmortizado(codcred, codmod);
	}

	@Override
	public List<Object[]> ObtenerParamsComprobante(Integer codcred, Integer codmod) throws OperationException {
		return prePrestamosQLLocal.ObtenerParamsComprobante(codcred, codmod);
	}


	public Integer ObtenerIdProcesoComprobante(Integer codcmp, Integer codcred, Integer codmod, Date fecha,
			Integer estado) throws OperationException {
		return prePrestamosQLLocal.ObtenerIdProcesoComprobante(codcmp, codcred, codmod, fecha, estado);
	}

	@Override
	public Date obtenerFechaCancelado(Integer codcred, Integer codmod) {
		return prePrestamosQLLocal.obtenerFechaCancelado(codcred, codmod);
	}

	@Override
	public Date obtenerFechaSinCancelar(Integer codcred, Integer codmod) {
		return prePrestamosQLLocal.obtenerFechaSinCancelar(codcred, codmod);
	}

	@Override
	public Date obtenerFechaProximoPago(Integer codcred, Integer codmod) {
		return prePrestamosQLLocal.obtenerFechaProximoPago(codcred, codmod);
	}

	@Override
	public String obtenerValorMatrizParametro(Integer codcred, Integer parametro) throws OperationException {
		return prePrestamosQLLocal.obtenerValorMatrizParametro(codcred, parametro);
	}

	@Override
	public Date obtenerFechaUltimoDevengado(Integer codcred, Integer codmod, Date fechaDevengado)
			throws OperationException {
		return prePrestamosQLLocal.obtenerFechaUltimoDevengado(codcred, codmod, fechaDevengado);
	}

	@Override
	public BigDecimal obtenerTotalInteresDevengado(Integer codcred, Integer codmod, Date fechaDevengado,
			Date fechaUltimodevengado) throws OperationException {
		return prePrestamosQLLocal.obtenerTotalInteresDevengado(codcred, codmod, fechaDevengado, fechaUltimodevengado);
	}

	@Override
	public List<Object[]> ObtenerDatosFechaDevengado(Integer codcred, Integer codmod) throws OperationException {
		return prePrestamosQLLocal.ObtenerDatosFechaDevengado(codcred, codmod);
	}

	@Override
	public Date obtenerFechaUltimoDevengadoPorCredito(Integer codcred, Integer codmod) throws OperationException {
		return prePrestamosQLLocal.obtenerFechaUltimoDevengadoPorCredito(codcred, codmod);
	}

	@Override
	public Date obtenerFechaUltimoDevengadoGeneral() {
		return prePrestamosQLLocal.obtenerFechaUltimoDevengadoGeneral();
	}

	@Override
	public Date obtenerFechaUltimoDevengadoPorCreditoComprobante(Integer codcred, Integer codmod, Date fecha)
			throws OperationException {
		return prePrestamosQLLocal.obtenerFechaUltimoDevengadoPorCreditoComprobante(codcred, codmod, fecha);
	}

	public PrePrestamos prestamoById(Integer codcred, Integer codmod) {
		return prePrestamosQLLocal.prestamoById(codcred, codmod);
	}
	public List<PrePrestamos> prestamosVig(Integer tipoproc) {
		return prePrestamosQLLocal.prestamosVig(tipoproc) ;
	}
}
