/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.entidades.ValorDominio
 * 30/03/2016 - 15:30:01
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 *
 * @author ysalinas
 */
@Getter
@Setter
@Entity
@Table(name = "VALOR_DOMINIO")

public class ValorDominio extends Entidad<ValorDominioPK> implements Serializable {
    public static final String ENTITY = "ValorDominio";

    public static final String NQ_SEARCH_BY_DOMINIO = ENTITY + "SearchByDominio";
    public static final String NQ_SEARCH_BY_DOMINIO_AUTORIZADO = ENTITY + "SearchByDominioAutorizado";

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ValorDominioPK id;

    
    @NotNull
    
    @Column(name = "valor_dato")
    private String valorDato;

    
    @NotNull
    @Column(name = "desc_valor_dato")
    private String descValorDato;

    @JoinColumn(name = "cod_dominio", referencedColumnName = "cod_dominio", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Dominio dominio;

    @Transient
    private String descripcion;

    public ValorDominio() {
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ValorDominio [id=" + id + ", valorDato=" + valorDato + ", descValorDato=" + descValorDato + ", dominio=" + dominio + ", descripcion=" + descripcion + "]";
    }

}