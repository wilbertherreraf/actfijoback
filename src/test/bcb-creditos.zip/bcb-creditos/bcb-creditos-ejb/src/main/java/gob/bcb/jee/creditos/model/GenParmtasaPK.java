package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the gen_parmtasa database table.
 * 
 */
@Embeddable
public class GenParmtasaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="tas_codmod", insertable=false, updatable=false)
	private Integer tasCodmod;

	@Column(name="tas_codprod", insertable=false, updatable=false)
	private Integer tasCodprod;

	@Column(name="tas_codmon")
	private Integer tasCodmon;

	public GenParmtasaPK() {
	}
	public Integer getTasCodmod() {
		return this.tasCodmod;
	}
	public void setTasCodmod(Integer tasCodmod) {
		this.tasCodmod = tasCodmod;
	}
	public Integer getTasCodprod() {
		return this.tasCodprod;
	}
	public void setTasCodprod(Integer tasCodprod) {
		this.tasCodprod = tasCodprod;
	}
	public Integer getTasCodmon() {
		return this.tasCodmon;
	}
	public void setTasCodmon(Integer tasCodmon) {
		this.tasCodmon = tasCodmon;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof GenParmtasaPK)) {
			return false;
		}
		GenParmtasaPK castOther = (GenParmtasaPK)other;
		return 
			(this.tasCodmod == castOther.tasCodmod)
			&& (this.tasCodprod == castOther.tasCodprod)
			&& (this.tasCodmon == castOther.tasCodmon);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.tasCodmod;
		hash = hash * prime + this.tasCodprod;
		hash = hash * prime + this.tasCodmon;
		
		return hash;
	}
}
