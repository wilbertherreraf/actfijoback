package gob.bcb.jee.creditos.pojo;

import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * PreDesembolsoDto
 *
 * @author mcramos
 * 17/02/2025
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PreDesembolsoDto implements Serializable {
    PreDesemb desembolso;
    PreDesembolsoDetalle desembolsoDetalle;
}
