package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the aux_precobro database table.
 * 
 */
@Embeddable
public class AuxPrecobroPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="apc_codmod", insertable=false, updatable=false)
	private Integer apcCodmod;

	@Column(name="apc_codcred")
	private Integer apcCodcred;

	@Column(name="apc_sectran")
	private Integer apcSectran;

	public AuxPrecobroPK() {
	}
	public Integer getApcCodmod() {
		return this.apcCodmod;
	}
	public void setApcCodmod(Integer apcCodmod) {
		this.apcCodmod = apcCodmod;
	}
	public Integer getApcCodcred() {
		return this.apcCodcred;
	}
	public void setApcCodcred(Integer apcCodcred) {
		this.apcCodcred = apcCodcred;
	}
	public Integer getApcSectran() {
		return this.apcSectran;
	}
	public void setApcSectran(Integer apcSectran) {
		this.apcSectran = apcSectran;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AuxPrecobroPK)) {
			return false;
		}
		AuxPrecobroPK castOther = (AuxPrecobroPK)other;
		return 
			(this.apcCodmod == castOther.apcCodmod)
			&& (this.apcCodcred == castOther.apcCodcred)
			&& (this.apcSectran == castOther.apcSectran);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.apcCodmod;
		hash = hash * prime + this.apcCodcred;
		hash = hash * prime + this.apcSectran;
		
		return hash;
	}
}
