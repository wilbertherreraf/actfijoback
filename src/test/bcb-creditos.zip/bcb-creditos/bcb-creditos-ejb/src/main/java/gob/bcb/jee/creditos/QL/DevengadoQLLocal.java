package gob.bcb.jee.creditos.QL;
import gob.bcb.jee.creditos.entidades.Devengado;
import gob.bcb.jee.creditos.excepciones.OperationException;

import java.util.Date;

import javax.ejb.Local;
/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.QL
 * 13/09/2016 - 12:28 PM
 * Creado por aescobar
 */
@Local
public interface DevengadoQLLocal extends
    GenericQLLocal<Devengado, Long>
{
	public void generarDevengados(Date fechaIni,Integer tipoproc, String coduser, String estacion) throws OperationException;
	public void cierreDevengados(Date fechaCierre, String coduser, String estacion) throws OperationException;
    void generarDevengadosTodos(Integer tipoproceso, Date fechaIni) throws Throwable;
}