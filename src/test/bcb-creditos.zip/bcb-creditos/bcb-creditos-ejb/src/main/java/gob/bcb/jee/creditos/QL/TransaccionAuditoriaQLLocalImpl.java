package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.TransaccionAuditoria;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.QL
 * 28/06/2016 - 10:51 AM
 * Created por aescobar
 */

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class TransaccionAuditoriaQLLocalImpl extends
        GenericQLLocalImpl<TransaccionAuditoria, String> implements
        TransaccionAuditoriaQLLocal
{
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    @Override
    protected EntityManager entityManager()
    {
        return entityManager;
    }

}