/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.NormativaBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.Normativa;
import gob.bcb.jee.creditos.excepciones.OperationException;

import java.util.List;

import javax.ejb.Local;

/**
 * Interface para el negocio del a entidad Normativa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface NormativaBLLocal extends
    GenericBLLocal<Normativa, Integer>
{

  /**
   * 
   * Lista las normarivas vigentes
   * 
   * 
   * @return
   * @throws OperationException
   */
  List<Normativa> listarNormativas()
      throws OperationException;

}
