package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the gen_identasex database table.
 * 
 */
@Embeddable
public class GenIdentasexPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ite_codmon", insertable=false, updatable=false)
	private Integer iteCodmon;

	@Column(name="ite_ttasaex", insertable=false, updatable=false)
	private Integer iteTtasaex;

	public GenIdentasexPK() {
	}
	public Integer getIteCodmon() {
		return this.iteCodmon;
	}
	public void setIteCodmon(Integer iteCodmon) {
		this.iteCodmon = iteCodmon;
	}
	public Integer getIteTtasaex() {
		return this.iteTtasaex;
	}
	public void setIteTtasaex(Integer iteTtasaex) {
		this.iteTtasaex = iteTtasaex;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof GenIdentasexPK)) {
			return false;
		}
		GenIdentasexPK castOther = (GenIdentasexPK)other;
		return 
			(this.iteCodmon == castOther.iteCodmon)
			&& (this.iteTtasaex == castOther.iteTtasaex);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.iteCodmon;
		hash = hash * prime + this.iteTtasaex;
		
		return hash;
	}
}
