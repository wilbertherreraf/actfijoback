package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * DOITJMMC
 * 
 */
@Embeddable
public class GenDesctablaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="des_codtab", insertable=false, updatable=false)
	private Integer desCodtab;

	@Column(name="des_codigo")
	private Integer desCodigo;

	public GenDesctablaPK() {
	}
	public GenDesctablaPK(Integer codtabla, Integer descodigo) {
		super();
		this.desCodtab = codtabla;
		this.desCodigo = descodigo;		
	}
	public Integer getDesCodtab() {
		return this.desCodtab;
	}
	public void setDesCodtab(Integer desCodtab) {
		this.desCodtab = desCodtab;
	}
	public Integer getDesCodigo() {
		return this.desCodigo;
	}
	public void setDesCodigo(Integer desCodigo) {
		this.desCodigo = desCodigo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof GenDesctablaPK)) {
			return false;
		}
		GenDesctablaPK castOther = (GenDesctablaPK)other;
		return 
			(this.desCodtab == castOther.desCodtab)
			&& (this.desCodigo == castOther.desCodigo);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.desCodtab;
		hash = hash * prime + this.desCodigo;
		
		return hash;
	}
}
