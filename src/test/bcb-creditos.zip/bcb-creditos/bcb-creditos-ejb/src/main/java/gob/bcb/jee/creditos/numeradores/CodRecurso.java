/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-plantillaWebEE-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.numeradores.CodRecurso
 * 12/03/2015 - 18:32:00
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.numeradores;

/**
 * Intefaz para el control y manejo de los Recursos
 * 
 * @author ysalinas
 * 
 */
public interface CodRecurso
{
  String getCodigoRecurso();

  String[] getUrl();

  String getTextMenu();

  Integer getOrder();

  boolean getVisible();

  @SuppressWarnings("rawtypes")
  Class getClazz();
}
