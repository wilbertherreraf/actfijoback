/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import java.util.List;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreReprograma;


@Local

public interface PreReprogramaBLLocal extends
    GenericBLLocal<PreReprograma, Integer>
{
	public Integer nuevoId()throws OperationException;
	public List<Object[]> obtenerContratos(Integer codcred,Integer codmod)throws OperationException;
    List<PreReprograma> reprosByCred(Integer codcred, Integer codmod, Integer tiporepro);
    PreReprograma guardarRepro(PreReprograma repro);
    PreReprograma findByCodRepro(Integer repro);
}
