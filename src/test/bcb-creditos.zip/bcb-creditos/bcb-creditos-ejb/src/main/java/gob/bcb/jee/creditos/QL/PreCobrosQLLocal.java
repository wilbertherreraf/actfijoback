/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.model.PreCobros;
import gob.bcb.jee.creditos.model.PreTramon;
import gob.bcb.jee.creditos.model.PreTramonPK;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;

import javax.ejb.Local;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface PreCobrosQLLocal extends
        GenericQLLocal<PreCobros,Integer>
{

	
}
