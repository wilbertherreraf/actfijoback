package gob.bcb.jee.creditos.entidades;

import java.io.Serializable;
import java.util.Objects;

public class GenPrcparamsPK implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Integer prpCodprc;
    private Integer prpTipoproc;
    private Integer prpCodtpr;

    public GenPrcparamsPK() {
    }

    public GenPrcparamsPK(Integer prpCodprc, Integer prpTipoproc, Integer prpCodtpr) {
        this.prpCodprc = prpCodprc;
        this.prpTipoproc = prpTipoproc;
        this.prpCodtpr = prpCodtpr;
    }

    // Getters y Setters
    public Integer getPrpCodprc() {
        return prpCodprc;
    }

    public void setPrpCodprc(Integer prpCodprc) {
        this.prpCodprc = prpCodprc;
    }

    public Integer getPrpTipoproc() {
        return prpTipoproc;
    }

    public void setPrpTipoproc(Integer prpTipoproc) {
        this.prpTipoproc = prpTipoproc;
    }

    public Integer getPrpCodtpr() {
        return prpCodtpr;
    }

    public void setPrpCodtpr(Integer prpCodtpr) {
        this.prpCodtpr = prpCodtpr;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GenPrcparamsPK that = (GenPrcparamsPK) o;
        return Objects.equals(prpCodprc, that.prpCodprc) &&
                Objects.equals(prpTipoproc, that.prpTipoproc) &&
                Objects.equals(prpCodtpr, that.prpCodtpr);
    }

    @Override
    public int hashCode() {
        return Objects.hash(prpCodprc, prpTipoproc, prpCodtpr);
    }
}