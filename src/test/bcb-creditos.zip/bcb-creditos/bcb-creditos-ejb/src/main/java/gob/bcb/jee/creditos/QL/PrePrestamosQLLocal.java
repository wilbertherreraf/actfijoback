/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PrePrestamosPK;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface PrePrestamosQLLocal extends
        GenericQLLocal<PrePrestamos,PrePrestamosPK>
{
	public Integer getIdByModulo(Integer codmod)throws OperationException;
	
	public Integer getValorPeriodicidad(Integer valor)throws OperationException;
	
	public void p_rpro_aprob_planpagos(Integer codcred,Integer codmod ,Integer codtmp,Integer codrep, String user, String ip) throws OperationException;
		
	public void diferimiento(Integer codcred,Integer codmod, Date fechaoper, Date fechaInicio, Date fechaFin, String user,String estacion) throws OperationException;
	public void pagoAnticipadoNuevo(Integer codmodtmp,Integer codrepro , Date fechaoper, String user, String estacion) throws OperationException;
	
	public Integer obtenerCantidadDesembolsos(Integer codcred,Integer codmod)throws OperationException;
	public BigDecimal obtenerInteresesDevengado(Integer codcred,Integer codmod)throws OperationException;
	public BigDecimal obtenerInteresesCobrados(Integer codcred,Integer codmod)throws OperationException;
	public Date obtenerUltimaFechaPlanPagos(Integer codcred,Integer codmod)throws OperationException;
	public BigDecimal obtenerMontoDescomprometido(Integer codcred,Integer codmod)throws OperationException;
	public BigDecimal obtenerCapitalAmortizado(Integer codcred,Integer codmod)throws OperationException;
	public List<Object[]> ObtenerParamsComprobante(Integer codcred,Integer codmod) throws OperationException;

	public Integer ObtenerIdProcesoComprobante(Integer codcmp,Integer codcred,Integer codmod, Date fecha,Integer estado) throws OperationException;

	public Date obtenerFechaSinCancelar(Integer codcred, Integer codmod);
	public Date obtenerFechaCancelado(Integer codcred, Integer codmod);
	public Date obtenerFechaProximoPago(Integer codcred, Integer codmod);

	public String obtenerValorMatrizParametro(Integer codcred, Integer parametro)throws OperationException;

	public Date obtenerFechaUltimoDevengado(Integer codcred,Integer codmod, Date fechaDevengado) throws OperationException;
	public BigDecimal obtenerTotalInteresDevengado(Integer codcred,Integer codmod, Date fechaDevengado, Date fechaUltimodevengado) throws OperationException;

	public List<Object[]> ObtenerDatosFechaDevengado(Integer codcred,Integer codmod) throws OperationException;

	public Date obtenerFechaUltimoDevengadoPorCredito(Integer codcred,Integer codmod) throws OperationException;

	public Date obtenerFechaUltimoDevengadoGeneral() ;

	public Date obtenerFechaUltimoDevengadoPorCreditoComprobante(Integer codcred,Integer codmod, Date fecha) throws OperationException;

    void preAutoPagAnticip(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion)
            throws OperationException;

    void eliminarAutoPagAnticip(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion)
            throws OperationException;

    PrePrestamos prestamoById(Integer codcred, Integer codmod);

	Integer presVigentes();

    BigDecimal mntOtorgado();

    BigDecimal mntPorRecuperar();

    void autorizarPagAnticip(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion);

    List<PrePrestamos> prestamosVig(Integer tipoproc);

    void procesarReprogramacion(Integer tipotrx, Integer codrepo, Date fecha, String user, String ip);


}
