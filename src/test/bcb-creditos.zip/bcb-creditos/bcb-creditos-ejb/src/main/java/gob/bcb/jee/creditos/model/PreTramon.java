package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the pre_tramon database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="pre_tramon")
@NamedQueries({
    @NamedQuery(name = PreTramon.NQ_LIST_ALL, query = "SELECT a FROM PreTramon a"),
    @NamedQuery(name = PreTramon.NQ_GET_BY_ID, query = "SELECT p FROM PreTramon p where p.id.tmoCodcred=:valor1 and p.id.tmoCodmod=:valor2 and p.tmoStatreg=0 "),
    @NamedQuery(name = PreTramon.NQ_LIST_TRAM, query = "SELECT p FROM PreTramon p where p.id.tmoCodcred=:valor1 and p.id.tmoCodmod=:valor2 and p.tmoTabtipotra=:valor3 and p.tmoTipotra=:valor4 and p.tmoStatreg=:valor5 "),
    @NamedQuery(name = PreTramon.NQ_LIST_TRAMDSB, query = "SELECT p FROM PreTramon p where p.id.tmoCodcred=:valor1 and p.id.tmoCodmod=:valor2 and p.tmoTabtipotra=:valor3 and p.tmoTipotra=:valor4 and p.tmoStatreg=:valor5  and p.tmoCoddsb=:valor6")
    
})
public class PreTramon extends EntidadAutorizable<PreTramonPK> implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="PreTramon";
	  public static final String NQ_GET_BY_ID =ENTITY+"GetById";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	  public static final String NQ_LIST_TRAM = ENTITY + "ListTram";
	  public static final String NQ_LIST_TRAMDSB = ENTITY + "ListTramDsb";

	@Id
	private PreTramonPK id;

	@Column(name="tmo_codmon")
	private Integer tmoCodmon;
	
	@Column(name="tmo_tabtipotra")
	private Integer tmoTabtipotra;
	
	@Column(name="tmo_tipotra")
	private Integer tmoTipotra;
	
	@Column(name="tmo_tabtipocob")
	private Integer tmoTabtipocob;

	@Column(name="tmo_tipocob")
	private Integer tmoTipocob;
	
	@Column(name="tmo_valor")
	private BigDecimal tmoValor;
	
	@Column(name="tmo_importe")
	private BigDecimal tmoImporte;

	@Column(name="tmo_numcta")
	private String tmoNumcta;
	
	@Column(name="tmo_glosa")
	private String tmoGlosa;
	
	@Column(name="tmo_cotiza")
	private Double tmoCotiza;
	
	@Temporal(TemporalType.DATE)
	@Column(name="tmo_fechproc")
	private Date tmoFechproc;

	@Temporal(TemporalType.DATE)
	@Column(name="tmo_fechcon")
	private Date tmoFechcon;
	
	@Temporal(TemporalType.DATE)
	@Column(name="tmo_fechreg")
	private Date tmoFechreg;
	
	@Temporal(TemporalType.DATE)
	@Column(name="tmo_fecvencuo")
	private Date tmoFecvencuo;
	
	@Column(name="tmo_coddsb")
	private Integer tmoCoddsb;
	
	@Column(name="tmo_tabstatreg")
	private Integer tmoTabstatreg;
	
	@Column(name="tmo_statreg")
	private Integer tmoStatreg;
	
	@Temporal(TemporalType.DATE)
	@Column(name="tmo_fechauto")
	private Date tmoFechauto;
	
	@Column(name="tmo_usrpreau")
	private String tmoUsrpreau;

	@Column(name="tmo_usrauto")
	private String tmoUsrauto;
	
	@Column(name="tmo_usrcob")
	private String tmoUsrcob;
	
	@Column(name="tmo_tabtrxstaau")
	private Integer tmoTabtrxstaau;

	@Column(name="tmo_trxstaau")
	private Integer tmoTrxstaau;
	
	@Column(name="tmo_auditusr")
	private String tmoAuditusr;
	
	@Column(name="tmo_auditfho")
	private Timestamp tmoAuditfho;

	@Column(name="tmo_auditwst")
	private String tmoAuditwst;

	public PreTramon() {
	}

	

}
