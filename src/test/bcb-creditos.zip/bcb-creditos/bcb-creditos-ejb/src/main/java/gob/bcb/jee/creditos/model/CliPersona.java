package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;


/**
 * The persistent class for the cli_persona database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="cli_persona")
@NamedQuery(name="CliPersona.findAll", query="SELECT c FROM CliPersona c")
@NamedQueries({
    @NamedQuery(name = CliPersona.NQ_LIST_ALL, query = "SELECT p FROM CliPersona p"),
    @NamedQuery(name = CliPersona.NQ_LIST_VIGENTES, query = "SELECT p FROM CliPersona p where p.cliStatus=1")
    
})
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY,isGetterVisibility = JsonAutoDetect.Visibility.ANY,getterVisibility = JsonAutoDetect.Visibility.ANY)
public class CliPersona extends EntidadAutorizable<Integer>  implements Serializable {
	private static final long serialVersionUID = 1L;

	public static final String ENTITY ="CliPersona";
	  public static final String NQ_GET_BY_ID ="GetById";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	  public static final String NQ_LIST_VIGENTES = ENTITY + "ListAllVigentes";
	  
	@Id
	@Column(name="cli_codigo")
	private Integer cliCodigo;

	@Column(name="cli_nombre")
	private String cliNombre;

	@Column(name="cli_tabtipiden")
	private Integer cliTabtipiden;

	@Column(name="cli_tipiden")
	private Integer cliTipiden;
	
	@Column(name="cli_identifica")
	private String cliIdentifica;
	
	@Column(name="cli_numruc")
	private String cliNumruc;
	
	@Column(name="cli_tabtipper")
	private Integer cliTabtipper;
	
	@Column(name="cli_tipper")
	private Integer cliTipper;
	
	@Column(name="cli_telcel")
	private String cliTelcel;
	
	@Column(name="cli_casilla")
	private String cliCasilla;

	@Column(name="cli_descact")
	private String cliDescact;
	
	@Column(name="cli_calif")
	private String cliCalif;	
	
	@Temporal(TemporalType.DATE)
	@Column(name="cli_feching")
	private Date cliFeching;

	@Column(name="cli_tabstatus")
	private Integer cliTabstatus;
	
	@Column(name="cli_status")
	private Integer cliStatus;
	
	@Temporal(TemporalType.DATE)
	@Column(name="cli_fstatus")
	private Date cliFstatus;
	
	@Column(name="cli_email")
	private String cliEmail;
	
	@Column(name="cli_direccion")
	private String cliDireccion;
	
	@Column(name="cli_tabtrxstaau")
	private Integer cliTabtrxstaau;

	@Column(name="cli_trxstaau")
	private Integer cliTrxstaau;

	@Column(name="cli_auditusr")
	private String cliAuditusr;

	@Column(name="cli_auditfho")
	private Timestamp cliAuditfho;

	@Column(name="cli_auditwst")
	private String cliAuditwst;

	public CliPersona() {
	}


	@Override
	public Integer getId() {
		return cliCodigo;
	}

	@Override
	public void setId(Integer id) {
		this.cliCodigo=id;
	}

}
