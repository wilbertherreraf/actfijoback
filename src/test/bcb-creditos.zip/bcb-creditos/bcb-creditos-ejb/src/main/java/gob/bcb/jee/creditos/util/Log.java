package gob.bcb.jee.creditos.util;

import org.apache.log4j.Logger;

public final class Log
{
  private final static Logger logger = Logger.getLogger("");

  Log()
  {
  }

  public static void Trace(Object message)
  {
    String metod = "", clase = "";
    if (Thread.currentThread().getStackTrace().length > 2)
    {
      metod = Thread.currentThread().getStackTrace()[2].getMethodName();
      clase = Thread.currentThread().getStackTrace()[2].getClassName();
    }
    logger.trace("[" + clase + "." + metod + "] " + message.toString());
  }

  public static void Debug(Object message)
  {
    String metod = "", clase = "";
    if (Thread.currentThread().getStackTrace().length > 2)
    {
      metod = Thread.currentThread().getStackTrace()[2].getMethodName();
      clase = Thread.currentThread().getStackTrace()[2].getClassName();
    }
    logger.debug("[" + clase + "." + metod + "] " + message.toString());
  }

  public static void Info(Object message)
  {
    String metod = "", clase = "";
    if (Thread.currentThread().getStackTrace().length > 2)
    {
      metod = Thread.currentThread().getStackTrace()[2].getMethodName();
      clase = Thread.currentThread().getStackTrace()[2].getClassName();
    }
    logger.info("[" + clase + "." + metod + "] " + message.toString());
  }

  public static void Warn(Object message)
  {
    String metod = "", clase = "";
    if (Thread.currentThread().getStackTrace().length > 2)
    {
      metod = Thread.currentThread().getStackTrace()[2].getMethodName();
      clase = Thread.currentThread().getStackTrace()[2].getClassName();
    }

    logger.warn("[" + clase + "." + metod + "] " + message.toString());
  }

  public static void Error(Object message)
  {
    String metod = "", clase = "";
    if (Thread.currentThread().getStackTrace().length > 2)
    {
      metod = Thread.currentThread().getStackTrace()[2].getMethodName();
      clase = Thread.currentThread().getStackTrace()[2].getClassName();
    }

    logger.error("[" + clase + "." + metod + "] " + message.toString());
  }

  public static void Fatal(Object message)
  {
    String metod = "", clase = "";
    if (Thread.currentThread().getStackTrace().length > 2)
    {
      metod = Thread.currentThread().getStackTrace()[2].getMethodName();
      clase = Thread.currentThread().getStackTrace()[2].getClassName();
    }

    logger.fatal("[" + clase + "." + metod + "] " + message.toString());
  }
}
