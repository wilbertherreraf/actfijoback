/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.entidades.EntidadAutorizable
 * 28/03/2016 - 12:05:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.Setter;

/**
 * Entidad generica (super clase)
 * 
 * 
 * @author ysalinas
 * 
 */
@Getter
@Setter
@MappedSuperclass
public abstract class EntidadAutorizable<ID extends Serializable> extends
    Entidad<ID>
{

  private static final long serialVersionUID = 4461500801819463012L;

  // @Column(name = "USUARIO_AUTORIZACION", length = 50)
  // private String usuarioAutorizacion;
  //
  // @Column(name = "FECHA_AUTORIZACION")
  // @Temporal(TemporalType.TIMESTAMP)
  // private Date fechaAutorizacion;

}
