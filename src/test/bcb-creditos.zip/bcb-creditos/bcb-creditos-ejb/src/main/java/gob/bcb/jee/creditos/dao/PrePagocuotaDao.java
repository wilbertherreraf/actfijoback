package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.PrePagocuota;
import gob.bcb.jee.creditos.util.Cttes;


import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

@Stateless
public class PrePagocuotaDao extends GenericDao<PrePagocuota, Integer> implements Serializable {


    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public PrePagocuotaDao() {
    }

    public PrePagocuotaDao(Class<PrePagocuota> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
}
