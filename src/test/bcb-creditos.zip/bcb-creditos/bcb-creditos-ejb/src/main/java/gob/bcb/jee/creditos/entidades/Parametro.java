/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.entidades.Empresa
 * 29/03/2016 - 10:32:24
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * Clase para la entidad Empresa / Empresa
 *
 *
 * @author ysalinas
 *
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "PARAMETRO")
@Getter
@Setter

public class Parametro extends EntidadAutorizable<String> implements
        Serializable
{
    public static final String ENTITY = "Parametro";
    public static final String NQ_SEARCH_BY_TIPO = ENTITY + "SearchByTipo";

    @Id
    @NotNull
    
    @Column(name = "COD_PARAMETRO", updatable = false)
    private String id;

    
    @Column(name = "VALOR_PARAMETRO")
    private String valorParametro;

    
    @Column(name = "DESCRIPCION_CORTA", nullable = false)
    private String descripcionCorta;

    @Column(name = "DESCRIPCION_LARGA", nullable = false)
    private String descripcionLarga;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "LOG_AUDITORIA_ID")
    private LogAuditoria logAuditoria;

    public Parametro()
    {
        super();
    }


    @Override
    public String toString() {
        return "Parametro{" +
                   "id=" + id +
                ", logAuditoria=" + logAuditoria +
                ", valorParametro =" + valorParametro +
                ", descripcionCorta ='" + descripcionCorta + '\'' +
                ", descripcionLarga ='" + descripcionLarga + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Parametro that = (Parametro) o;

        if (descripcionLarga != null ? !descripcionLarga.equals(that.descripcionLarga) : that.descripcionLarga != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
//        if (valorParametro != null ? !valorParametro.equals(that.logAuditoria) : that.logAuditoria != null) return false;
        if (descripcionCorta != null ? !descripcionCorta.equals(that.descripcionCorta) : that.descripcionCorta != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (valorParametro != null ? valorParametro.hashCode() : 0);
        result = 31 * result + (descripcionCorta != null ? descripcionCorta.hashCode() : 0);
        result = 31 * result + (descripcionLarga != null ? descripcionLarga.hashCode() : 0);
        return result;
    }
}