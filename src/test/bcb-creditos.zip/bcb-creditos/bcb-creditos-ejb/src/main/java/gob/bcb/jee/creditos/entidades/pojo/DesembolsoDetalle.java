package gob.bcb.jee.creditos.entidades.pojo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by eborda on 25/10/2016.
 */
public class DesembolsoDetalle implements Serializable {
    private Long idDesembolso;

    private Date fechaDesembolso;

    private Integer numero;

    private BigDecimal monto;

    private Long idProyecto;

    private BigDecimal montoDesembolsar;

    public DesembolsoDetalle(){

    }

    public DesembolsoDetalle(Long idDesembolso, Date fechaDesembolso, Integer numero, BigDecimal monto, Long idProyecto) {
        this.idDesembolso = idDesembolso;
        this.fechaDesembolso = fechaDesembolso;
        this.numero = numero;
        this.monto = monto;
        this.idProyecto = idProyecto;
    }

    public Long getIdDesembolso() {
        return idDesembolso;
    }

    public void setIdDesembolso(Long idDesembolso) {
        this.idDesembolso = idDesembolso;
    }

    public Date getFechaDesembolso() {
        return fechaDesembolso;
    }

    public void setFechaDesembolso(Date fechaDesembolso) {
        this.fechaDesembolso = fechaDesembolso;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public BigDecimal getMonto() {
        return monto;
    }

    public void setMonto(BigDecimal monto) {
        this.monto = monto;
    }

    public Long getIdProyecto() {
        return idProyecto;
    }

    public void setIdProyecto(Long idProyecto) {
        this.idProyecto = idProyecto;
    }

    public BigDecimal getMontoDesembolsar() {
        return montoDesembolsar;
    }

    public void setMontoDesembolsar(BigDecimal montoDesembolsar) {
        this.montoDesembolsar = montoDesembolsar;
    }

    @Override
    public String toString() {
        return "DesembolsoDetalle{" +
                "idDesembolso=" + idDesembolso +
                ", fechaDesembolso=" + fechaDesembolso +
                ", numero=" + numero +
                ", monto=" + monto +
                ", idProyecto=" + idProyecto +
                ", montoDesembolsar=" + montoDesembolsar +
                '}';
    }
}
