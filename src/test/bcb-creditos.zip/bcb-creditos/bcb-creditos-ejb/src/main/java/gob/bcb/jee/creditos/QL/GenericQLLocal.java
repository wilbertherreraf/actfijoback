/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.QL.GenericNegocioQL
 * 05/11/2015 - 11:24:43
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Entidad;

import javax.ejb.Local;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Interfaz para los metodos de consulta (QL) genericos
 * 
 * 
 * @author ysalinas
 * 
 */
@SuppressWarnings("rawtypes")
@Local
public interface GenericQLLocal<T extends Entidad, ID extends Serializable>
{
  /**
   * Metodo de obtener el objeto por ID
   */
  T get(ID id);

  /**
   * Metodo para obtener un objeto a traves de un NamedQuery
   */
  T getByNamedQuery(String namedQuery, Map<String, Object> parameters);
 
  /**
   * Metodo para obtener una lista de objetos
   */
  List<T> list();

  /**
   * Metodo para obtener una lista de objetos a traves de un filtro
   */
  List<T> list(String filtro);

  /**
   * Metodo para obtener una lista de objetos a traves de un NamedQuery
   */
  List<T> listByNamedQuery(String namedQuery);

  /**
   * Metodo para obtener una lista de objetos a traves de un NamedQuery
   */
  List<T> listByNamedQuery(String namedQuery, Map<String, Object> parameters);

  /**
   * Listado de objetos a partir de un NamedQuery, sus parametros y un maximo de
   * objetos en la lista
   * 
   * @param namedQuery
   * @param parameters
   * @param maxResult
   * @return
   */
  List<T> listByNamedQuery(String namedQuery, Map<String, Object> parameters,
      Integer maxResult);

  /**
   * Metodo para obtener un objeto con todas sus relaciones
   */
  T getLazy(ID id);

  /**
   * Ejecuta query OBTENIENDO UN objeto especifico
   * @param namedQuery nombre del query
   * @return un obejeto
   */
  Object getObjectByNamedQuery(String namedQuery);

  /**
   * Ejecuta query OBTENIENDO UN objeto especifico
   * @param namedQuery nombre del query
   * @param parameters parametros del query
   * @return un obejeto
   */
  Object getObjectByNamedQuery(String namedQuery,
                               Map<String, Object> parameters);


  /**
   * Ejecuta un query y obtiene una lista de objetos
   * @param namedQuery nombre del query
   * @return una colección de obejetos
   */
  Object getListObjectByNamedQuery(String namedQuery);

  /**
   * Ejecuta un query y obtiene una lista de objetos
   * @param namedQuery nombre del query
   * @param parameters parametros del query
   * @return una colección de obejetos
   */
  Object getListObjectByNamedQuery(String namedQuery, Map<String, Object> parameters);

}
