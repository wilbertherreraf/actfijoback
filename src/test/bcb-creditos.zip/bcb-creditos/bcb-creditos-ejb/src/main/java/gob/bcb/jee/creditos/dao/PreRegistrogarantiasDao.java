package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.PreRegistrogarantias;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

@Stateless
public class PreRegistrogarantiasDao extends GenericDao<PreRegistrogarantias, Integer> implements Serializable {

    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;



    public PreRegistrogarantiasDao() {
    }

    public PreRegistrogarantiasDao(Class<PreRegistrogarantias> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
}
