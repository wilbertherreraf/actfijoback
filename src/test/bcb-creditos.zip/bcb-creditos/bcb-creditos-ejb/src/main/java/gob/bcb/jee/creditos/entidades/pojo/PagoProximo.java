package gob.bcb.jee.creditos.entidades.pojo;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.entidades.pojo
 * 05/12/2016 - 03:01 PM
 * Creado por aescobar
 */
@Getter
@Setter
public class PagoProximo {
    private Long proyectoId;
    private String nombreProyecto;
    private String siglaEmpresa;
    private Long numDesembolsos;
    private Date fechaPago;
    private BigDecimal monto;

    public PagoProximo() {
    }

    public PagoProximo(Long proyectoId, String nombreProyecto, String siglaEmpresa, Long numDesembolsos, Date fechaPago, BigDecimal monto) {
        this.proyectoId = proyectoId;
        this.nombreProyecto = nombreProyecto;
        this.siglaEmpresa = siglaEmpresa;
        this.numDesembolsos = numDesembolsos;
        this.fechaPago = fechaPago;
        this.monto = monto;
    }
}
