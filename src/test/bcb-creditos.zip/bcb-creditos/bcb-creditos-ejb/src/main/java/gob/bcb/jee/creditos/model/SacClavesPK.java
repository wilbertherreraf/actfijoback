package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the sac_claves database table.
 * 
 */
@Embeddable
public class SacClavesPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="clv_codmod", insertable=false, updatable=false)
	private Integer clvCodmod;

	@Column(name="clv_codclv")
	private String clvCodclv;

	public SacClavesPK() {
	}
	public Integer getClvCodmod() {
		return this.clvCodmod;
	}
	public void setClvCodmod(Integer clvCodmod) {
		this.clvCodmod = clvCodmod;
	}
	public String getClvCodclv() {
		return this.clvCodclv;
	}
	public void setClvCodclv(String clvCodclv) {
		this.clvCodclv = clvCodclv;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SacClavesPK)) {
			return false;
		}
		SacClavesPK castOther = (SacClavesPK)other;
		return 
			(this.clvCodmod == castOther.clvCodmod)
			&& this.clvCodclv.equals(castOther.clvCodclv);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.clvCodmod;
		hash = hash * prime + this.clvCodclv.hashCode();
		
		return hash;
	}
}
