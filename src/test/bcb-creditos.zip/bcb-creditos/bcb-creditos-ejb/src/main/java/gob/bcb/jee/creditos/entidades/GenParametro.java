package gob.bcb.jee.creditos.entidades;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "gen_parametro")
@Getter
@Setter
@NamedQueries({

        @NamedQuery(name = GenParametro.NQ_GET_LIST_BY_CREDITO, query = "SELECT g FROM GenParametro g where g.parCodcred= :pCodcred"),
})


public class GenParametro extends EntidadAutorizable<Integer> implements
        Serializable {

    private static final long serialVersionUID = 1L;
    public static final String ENTITY ="GenParametro";
    public static final String NQ_GET_LIST_BY_CREDITO ="GetByCredito";
    @Id
    
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "par_codpar")
    private Integer id;
    @Column(name = "par_codcred")
    private Integer parCodcred;
    @Column(name = "par_codmod")
    private Integer parCodmod;
    
    @Column(name = "par_parametro")
    private String parParametro;
    @Column(name = "par_tprcod")
    private Integer parTprcod;
    @Column(name = "par_tabestado")
    private Integer parTabestado;
    @Column(name = "par_estado")
    private Integer parEstado;
    @Column(name = "par_auditusr")
    private String parAuditusr;
    @Column(name = "par_auditfho")
    @Temporal(TemporalType.TIMESTAMP)
    private Date parAuditfho;
    @Column(name = "par_auditwst")
    private String parAuditwst;
    @Column(name = "cambio_bd")
    private String cambioBd;
    /*
    @JoinColumns({
            @JoinColumn(name = "par_tabestado", referencedColumnName = "des_codtab"),
            @JoinColumn(name = "par_estado", referencedColumnName = "des_codigo")})
    @ManyToOne(optional = false)
    private GenDesctabla genDesctabla;
    @JoinColumn(name = "par_tprcod", referencedColumnName = "tpr_codtpr")
    @ManyToOne(optional = false)
    private GenTipoparametro parTprcod;
    @JoinColumns({
            @JoinColumn(name = "par_codcred", referencedColumnName = "pre_codcred"),
            @JoinColumn(name = "par_codmod", referencedColumnName = "pre_codmod")})
    @ManyToOne(optional = false)
    private PrePrestamos prePrestamos;*/
}

