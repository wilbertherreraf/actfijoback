package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.CondicionesFinancieras;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.dao
 * 29/11/2016 - 13:30 PM
 * Creado por aescobar
 */
@Stateless
public class CondicionesFinancierasDao extends GenericDao<CondicionesFinancieras, Long> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /**
     *
     */
    public CondicionesFinancierasDao() {
    }

    public CondicionesFinancierasDao(Class<CondicionesFinancieras> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}