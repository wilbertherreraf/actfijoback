package gob.bcb.jee.creditos.QL;
import gob.bcb.jee.creditos.entidades.Pago;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.QL
 * 02/08/2016 - 11:54 AM
 * Creado por aescobar
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PagoQLLocalImpl extends
    GenericQLLocalImpl<Pago, Long> implements
    PagoQLLocal
{
  @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
  private EntityManager entityManager;

  @Override
  protected EntityManager entityManager()
  {
    return entityManager;
  }

}