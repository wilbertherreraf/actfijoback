/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenDesctabla;
import gob.bcb.jee.creditos.model.GenDesctablaPK;
import gob.bcb.jee.creditos.model.PreTramon;
import gob.bcb.jee.creditos.model.PreTramonPK;

import java.sql.SQLException;
import java.util.Date;

import javax.ejb.Local;

/**
 * Interface para el negocio del a entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface PreTramonBLLocal extends
    GenericBLLocal<PreTramon, PreTramonPK>
{
	public void reversaTransaccion(Integer codcred,Integer codmod,Integer numtrx, Date fechaOper,String usuario, String estacion)throws OperationException,SQLException;
	
	public void reversaTransaccionDif(Integer codcred,Integer codmod,Integer tipotrx, Date fecha,String usuario, String estacion)throws OperationException,SQLException;
}
