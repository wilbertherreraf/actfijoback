package gob.bcb.jee.creditos.entidades;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

import gob.bcb.jee.creditos.model.PrePrestamos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "v_pv_planpagos_consol")
@IdClass(VVPPlanPagosConsolQueryId.class)
public class VPVPlanPagosConsolQuery implements Serializable {

    @Id
    @Column(name = "codmod")
    private Integer codmod;

    @Id
    @Column(name = "codcred")
    private Integer codcred;

    @Id
    @Temporal(TemporalType.DATE)    
    @Column(name = "fechavencuo")
    private Date fechavencuo;

    @Temporal(TemporalType.DATE)
    @Column(name = "fechaant")
    private Date fechaant;
    @Id
    @Column(name = "tipotrx")
    private Integer tipotrx;

    @Column(name = "tipotrx_desc")
    private String tipotrxDesc;

    @Column(name = "interes_ini")
    private BigDecimal interesIni;

    @Column(name = "saldo_dev")
    private BigDecimal saldoDev;

    @Column(name = "interes_dev")
    private BigDecimal interesDev;

    @Column(name = "saldo_inicio")
    private BigDecimal saldoInicio;

    @Column(name = "amortizacion")
    private BigDecimal amortizacion;

    @Column(name = "amortizacion_saldo")
    private BigDecimal amortizacionSaldo;

    @Column(name = "interes")
    private BigDecimal interes;

    @Column(name = "interes_saldo")
    private BigDecimal interesSaldo;

    @Column(name = "dias")
    private Integer dias;

    @Column(name = "tasa")
    private BigDecimal tasa;

    @Column(name = "cuota")
    private BigDecimal cuota;

    @Column(name = "estado_cuota")
    private String estadoCuota;

    @Transient
    private String preDescrip;

    @Transient
    private PrePrestamos prestamos;
}
