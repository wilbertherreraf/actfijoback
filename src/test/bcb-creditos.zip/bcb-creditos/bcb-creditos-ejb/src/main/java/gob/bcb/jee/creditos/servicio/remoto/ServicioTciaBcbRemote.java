package gob.bcb.jee.creditos.servicio.remoto;
//package gob.bcb.jee.creditos.plantillaWebEE.servicio.remoto;
//
//import gob.bcb.tciabcb.entidades.Agencia;
//import gob.bcb.tciabcb.entidades.ValorDominio;
//import gob.bcb.tciabcb.entidades.Contrasenia;
//import gob.bcb.tciabcb.entidades.Participante;
//import gob.bcb.tciabcb.entidades.Persona;
//import gob.bcb.tciabcb.entidades.PersonaPK;
//import gob.bcb.tciabcb.entidades.Recurso;
//import gob.bcb.tciabcb.entidades.Rol;
//import gob.bcb.tciabcb.entidades.Usuario;
//import gob.bcb.tciabcb.util.BeanUsuario;
//import gob.bcb.tciabcb.util.ESTADO_REGISTRO;
//
//import java.util.List;
//
//import javax.ejb.Local;
//
///**
// * Interface de consumo de EJB Remotos de los servicios de seguridad de TCIABCB
// * 
// * @author fmamani
// * 
// */
//@Local
//public interface ServicioTciaBcbRemote
//{
//
//  /**
//   * Busca una partipante en base a un codRecurso.
//   * 
//   * @param codParticipante
//   * @return
//   * @throws Exception
//   */
//  public String buscarNombreParticipante(String codParticipante)
//      throws Exception;
//
//  /**
//   * Verifica si un usuario determinado es operador BCB.
//   * 
//   * @param codUsuario
//   * @return True si es operador BCB. False en caso contrario.
//   * @throws ExcepcionEjb
//   */
//  public boolean esUsuarioBCB(String codUsuario) throws Exception;
//
//  /**
//   * Obtiene la lista de usuarios segun la aplicacion y el participante
//   * 
//   * @param codAplicacion
//   * @param codParticipante
//   * @return
//   * @throws Exception
//   */
//  public List<Usuario> listarUsuarios(String codAplicacion,
//      String codParticipante) throws Exception;
//
//  /**
//   * Adiciona un nuevo usuario
//   * 
//   * @param usuario
//   * @param beanUsuarioTciaBcb
//   * @return
//   * @throws Exception
//   */
//  public Usuario agregarUsuario(Usuario usuario,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception;
//
//  /**
//   * Modifica un usuario
//   * 
//   * @param usuario
//   * @param beanUsuarioTciaBcb
//   * @return
//   * @throws Exception
//   */
//  public Usuario modificarUsuario(Usuario usuario,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception;
//
//  /**
//   * Cambia el estado de registro del usuario
//   * 
//   * @param codUsuario
//   * @param estadoRegistro
//   * @param beanUsuarioTciaBcb
//   * @throws Exception
//   */
//  public void cambiarEstadoRegistroUsuario(String codUsuario,
//      ESTADO_REGISTRO estadoRegistro, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception;
//
//  /**
//   * Obtiene la lista de todos los roles vigentes por aplicacion
//   * 
//   * @param codAplicacion
//   * @return
//   * @throws Exception
//   */
//  public List<Rol> listarRolesTodosVigentes(String codAplicacion)
//      throws Exception;
//
//  /**
//   * Obtiene la lista de todos los roles del usuario y la aplicacion
//   * 
//   * @param codAplicacion
//   * @param usrLogin
//   * @return
//   * @throws Exception
//   */
//  public List<Rol> listarRolesDelUsuario(String codAplicacion, String usrLogin)
//      throws Exception;
//
//  /**
//   * Obtiene la lista de los roles visibles por tipo de participante y
//   * aplicacion
//   * 
//   * @param codAplicacion
//   * @param participante
//   * @return
//   * @throws Exception
//   */
//  public List<Rol> listarRolesVisiblesPorTipoParticipante(
//      String codAplicacion, Participante participante) throws Exception;
//
//  /**
//   * Actualiza los roles de un usuario y la aplicacion
//   * 
//   * @param codUsuario
//   * @param listaRoles
//   * @param codAplicacion
//   * @param beanUsuarioTciaBcb
//   * @throws Exception
//   */
//  public void cambiarRol(String codUsuario, List<Rol> listaRoles,
//      String codAplicacion, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception;
//
//  /**
//   * Lista las agencias de un participante
//   * 
//   * @param codParticipante
//   * @return
//   * @throws Exception
//   */
//  public List<Agencia> listarAgenciasTodosVigentes(String codParticipante)
//      throws Exception;
//
//  /**
//   * Obtiene las claves
//   * 
//   * @param dominioSelected
//   * @return
//   * @throws Exception
//   */
//  public List<ValorDominio> obtenerClaves(String dominioSelected) throws Exception;
//
//  /**
//   * Realiza la verificacion de la contraseña de un usuario
//   * 
//   * @param cd
//   * @param passCodif
//   * @return
//   * @throws Exception
//   */
//  public Contrasenia verificarContrasenia(String cd, String passCodif)
//      throws Exception;
//
//  /**
//   * Verificacion de contraseña
//   * 
//   * @param codUsuario
//   * @param pass
//   * @return
//   * @throws Exception
//   */
//  public boolean existeContraseniaEnLos8Ultimos(String codUsuario, String pass)
//      throws Exception;
//
//  /**
//   * Verifica si es una contraseña valida
//   * 
//   * @param pass
//   * @return
//   * @throws Exception
//   */
//  public boolean vericarValidoContrasenia(String pass) throws Exception;
//
//  /**
//   * Actualiza el estado de la contraseña
//   * 
//   * @param contraseniaId
//   * @param estado
//   * @param codTransaccion
//   * @param beanUsuarioTciaBcb
//   * @throws Exception
//   */
//  public void cambiarEstadoRegistroContrasenia(Object contraseniaId,
//      char estado, String codTransaccion, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception;
//
//  /**
//   * Adiciona una nueva contraseña
//   * 
//   * @param contrasenia
//   * @param pass
//   * @param beanUsuarioTciaBcb
//   * @throws Exception
//   */
//  public void agregarContrasenia(Contrasenia contrasenia, String pass,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception;
//
//  /**
//   * Generacion de la contraseña automatica
//   * 
//   * @param usuarioLogin
//   * @param beanUsuarioTciaBcb
//   * @return
//   * @throws Exception
//   */
//  public String agregarContrasenaAutomatica(String usuarioLogin,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception;
//
//  /**
//   * Obtiene la lista de todas las agencias del participante
//   * 
//   * @param codParticipante
//   * @return
//   * @throws Exception
//   */
//  public List<Agencia> listarAgenciasTodos(String codParticipante)
//      throws Exception;
//
//  /**
//   * Modifica el registro de la agencia
//   * 
//   * @param agencia
//   * @param beanUsuarioTciaBcb
//   * @throws Exception
//   */
//  public void modificarAgencia(Agencia agencia, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception;
//
//  /**
//   * Adiciona una nueva agencia
//   * 
//   * @param agencia
//   * @param beanUsuarioTciaBcb
//   * @throws Exception
//   */
//  public void agregarAgencia(Agencia agencia, BeanUsuario beanUsuarioTciaBcb)
//      throws Exception;
//
//  /**
//   * Cambia el estado de la agencia
//   * 
//   * @param idAgencia
//   * @param estadoRegistro
//   * @param beanUsuario
//   * @throws Exception
//   */
//  public void cambiarEstadoRegistroAgencia(Object idAgencia,
//      ESTADO_REGISTRO estadoRegistro, BeanUsuario beanUsuario)
//      throws Exception;
//
//  /**
//   * Limpia una sesion abierta
//   * 
//   * @param codUsuario
//   * @param codAplicacion
//   * @throws Exception
//   */
//  public void limpiarSessionAbierta(String codUsuario, String codAplicacion)
//      throws Exception;
//
//  /**
//   * Registra una sesion nueva
//   * 
//   * @param codApp
//   * @param codUsuario
//   * @throws Exception
//   */
//  public void registrarSesionAbierta(String codApp, String codUsuario)
//      throws Exception;
//
//  /**
//   * Adiciona la informacion de persona
//   * 
//   * @param persona
//   * @param beanUsuarioTciaBcb
//   * @return
//   * @throws Exception
//   */
//  public Persona agregarPersona(Persona persona,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception;
//
//  /**
//   * Modifica la informacion de persona
//   * 
//   * @param persona
//   * @param beanUsuarioTciaBcb
//   * @return
//   * @throws Exception
//   */
//  public Persona modificarPersona(Persona persona,
//      BeanUsuario beanUsuarioTciaBcb) throws Exception;
//
//  /**
//   * Realiza la busqueda de la informacion de una persona
//   * 
//   * @param personaPK
//   * @return
//   * @throws Exception
//   */
//  public Persona buscarPersona(PersonaPK personaPK) throws Exception;
//
//  /**
//   * Realiza la busqueda de un usuario
//   * 
//   * @param usuarioLogin
//   * @return
//   * @throws Exception
//   */
//  public Usuario buscarUsuario(String usuarioLogin) throws Exception;
//
//  /**
//   * Obtiene la lista de participantes vigentes
//   * 
//   * @return
//   * @throws Exception
//   */
//  public List<Object[]> obtenerParticipantesVigentes() throws Exception;
//
//  /**
//   * Obtiene el corresponsal de un participante
//   * 
//   * @return
//   * @throws Exception
//   */
//  public String obtenerParticipanteCorresponsal() throws Exception;
//
//  /**
//   * Obtiene la lista de recursos de una aplicacion
//   * 
//   * @param codApp
//   * @return
//   * @throws Exception
//   */
//  public List<Recurso> obtenerListaRecursosAplicacion(String codApp)
//      throws Exception;
//
//  /**
//   * Obtiene la lista de recursos por rol de una aplicacion
//   * 
//   * @param codRol
//   * @return
//   * @throws Exception
//   */
//  public List<Recurso> obtenerListaRecursosPorRol(String codRol)
//      throws Exception;
//
//  /**
//   * Metodo de prueba de conexion
//   * 
//   * @return
//   */
//  public boolean testConection();
// }
