package gob.bcb.jee.creditos.entidades.pojo;

import java.math.BigDecimal;
import java.util.Date;

import gob.bcb.jee.creditos.entidades.GenPrcparams;

public class ComprobanteDet implements java.io.Serializable {

	private String cpbCodigo;
	private Date cpbFecha;
	private Integer renCodigo;
	private String cpbGlosa;
	private String ctaMovimiento;	
	private String movi;
	private String claDebehaber;
	private BigDecimal renTipocambio;
	private Integer codMoneda;
	private BigDecimal renMontomo;
	private BigDecimal renMontomn;
	private BigDecimal debe;
	private BigDecimal haber;
	private String renAfectable;
	private String renGlosa;
	private String nroCP;	
	private Integer codMonedadest;
	private String tipoTransfer;
	private String cveEstado;
	private String cpbNrocpbte;
	private BigDecimal cpbTipocambio;
	private String cveDettipocomp;
	private Integer codTransac;
	private Integer esqCodigo;
	private String codUsuario;
	private GenPrcparams genPrcparams;

	public ComprobanteDet() {
	}

	public String getCpbCodigo() {
		return cpbCodigo;
	}

	public void setCpbCodigo(String cpbCodigo) {
		this.cpbCodigo = cpbCodigo;
	}

	public Integer getRenCodigo() {
		return renCodigo;
	}

	public void setRenCodigo(Integer renCodigo) {
		this.renCodigo = renCodigo;
	}

	public String getMovi() {
		return movi;
	}

	public void setMovi(String movi) {
		this.movi = movi;
	}

	public String getClaDebehaber() {
		return claDebehaber;
	}

	public void setClaDebehaber(String claDebehaber) {
		this.claDebehaber = claDebehaber;
	}

	public BigDecimal getRenTipocambio() {
		return renTipocambio;
	}

	public void setRenTipocambio(BigDecimal renTipocambio) {
		this.renTipocambio = renTipocambio;
	}

	public BigDecimal getRenMontomo() {
		return renMontomo;
	}

	public void setRenMontomo(BigDecimal renMontomo) {
		this.renMontomo = renMontomo;
	}

	public BigDecimal getRenMontomn() {
		return renMontomn;
	}

	public void setRenMontomn(BigDecimal renMontomn) {
		this.renMontomn = renMontomn;
	}

	public void setDebe(BigDecimal debe) {
		this.debe = debe;
	}

	public void setHaber(BigDecimal haber) {
		this.haber = haber;
	}

	public BigDecimal getHaber() {
		return haber;
	}

	public BigDecimal getDebe() {
		return debe;
	}

	public String getRenAfectable() {
		return renAfectable;
	}

	public void setRenAfectable(String renAfectable) {
		this.renAfectable = renAfectable;
	}

	public String getRenGlosa() {
		return renGlosa;
	}

	public void setRenGlosa(String renGlosa) {
		this.renGlosa = renGlosa;
	}
	public String getNroCP() {
		return nroCP;
	}

	public void setNroCP(String nroCP) {
		this.nroCP = nroCP;
	}

	public void setCpbGlosa(String cpbGlosa) {
		this.cpbGlosa = cpbGlosa;
	}

	public String getCpbGlosa() {
		return cpbGlosa;
	}

	public Integer getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	
	public String toString() {
		return "Comprobante [cpbCodigo=" + cpbCodigo + ", renCodigo=" + renCodigo + ", cpbGlosa=" + cpbGlosa + ", movi=" + movi + ", claDebehaber="
				+ claDebehaber + ", renTipocambio=" + renTipocambio + ", codMoneda=" + codMoneda + ", renMontomo=" + renMontomo + ", renMontomn="
				+ renMontomn + ", debe=" + debe + ", haber=" + haber + ", renAfectable=" + renAfectable + ", renGlosa=" + renGlosa + "]";
	}

	public Integer getCodMonedadest() {
		return codMonedadest;
	}

	public void setCodMonedadest(Integer codMonedadest) {
		this.codMonedadest = codMonedadest;
	}

	public String getTipoTransfer() {
		return tipoTransfer;
	}

	public void setTipoTransfer(String tipoTransfer) {
		this.tipoTransfer = tipoTransfer;
	}

	public String getCveEstado() {
		return cveEstado;
	}

	public void setCveEstado(String cveEstado) {
		this.cveEstado = cveEstado;
	}

	public String getCpbNrocpbte() {
		return cpbNrocpbte;
	}

	public void setCpbNrocpbte(String cpbNrocpbte) {
		this.cpbNrocpbte = cpbNrocpbte;
	}

	public BigDecimal getCpbTipocambio() {
		return cpbTipocambio;
	}

	public void setCpbTipocambio(BigDecimal cpbTipocambio) {
		this.cpbTipocambio = cpbTipocambio;
	}

	public String getCveDettipocomp() {
		return cveDettipocomp;
	}

	public void setCveDettipocomp(String cveDettipocomp) {
		this.cveDettipocomp = cveDettipocomp;
	}

	public Integer getCodTransac() {
		return codTransac;
	}

	public void setCodTransac(Integer codTransac) {
		this.codTransac = codTransac;
	}

	public Integer getEsqCodigo() {
		return esqCodigo;
	}

	public void setEsqCodigo(Integer esqCodigo) {
		this.esqCodigo = esqCodigo;
	}

	public String getCtaMovimiento() {
		return ctaMovimiento;
	}

	public void setCtaMovimiento(String ctaMovimiento) {
		this.ctaMovimiento = ctaMovimiento;
	}

	public Date getCpbFecha() {
		return cpbFecha;
	}

	public void setCpbFecha(Date cpbFecha) {
		this.cpbFecha = cpbFecha;
	}

	public String getCodUsuario() {
		return codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
    public GenPrcparams getGenPrcparams() {
		return genPrcparams;
	}

	public void setGenPrcparams(GenPrcparams genPrcparams) {
		this.genPrcparams = genPrcparams;
	}

}
