package gob.bcb.jee.creditos.pojo;

import gob.bcb.jee.creditos.entidades.GenParametro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * GenParametroDevengadoIntDto
 *
 * @author mcramos
 * 15/01/2025
 */
@Getter
@Setter
@NoArgsConstructor
public class GenParametroDevengadoIntDto implements Serializable {
    private GenParametro debito = new GenParametro();
    private GenParametro abono = new GenParametro();
    private GenParametro esquema = new GenParametro();
}
