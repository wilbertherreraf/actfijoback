package gob.bcb.jee.creditos.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * PrePlanPagoDto
 *
 * @author mcramos
 * 27/03/2025
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PlanPagoDto implements Serializable {
    private String fechaVencimientoCuota;
    private BigDecimal saldoInicio;
    private BigDecimal amortizacion;
    private BigDecimal amortizacionSaldo;
    private BigDecimal interes;
    private BigDecimal interesSaldo;
    private Integer dias;
    private BigDecimal tasa;
    private BigDecimal cuota;
    private String estadoCuota;
}
