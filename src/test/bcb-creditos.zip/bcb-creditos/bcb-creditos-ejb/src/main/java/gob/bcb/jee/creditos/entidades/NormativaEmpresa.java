package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "NORMATIVA_EMPRESA")
@Getter
@Setter
@NamedQueries({
    @NamedQuery(name = NormativaEmpresa.NQ_SEARCH_BY_EMPRESA, query = "select n from NormativaEmpresa n where n.empresa.id = :empresaId"),
    @NamedQuery(name = NormativaEmpresa.NQ_SEARCH_BY_NORMATIVA, query = "select n from NormativaEmpresa n where n.normativa.id = :normativaId")
})
public class NormativaEmpresa extends Entidad<Integer> implements Serializable {

	public static final String ENTITY = "NormativaEmpresa";
	public static final String NQ_SEARCH_BY_EMPRESA = ENTITY + "SearchByEmpresa";
	public static final String NQ_SEARCH_BY_NORMATIVA = ENTITY + "SearchByNormativa";
	public static final String NQ_GET_MONTO_LEY_BY_EMPRESA = ENTITY + "GetMontoLeyByEmpresa";


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", updatable = false)
	private Integer id;

	@ManyToOne
	@JoinColumn(name = "EMPRESA_ID", nullable = false)
	private Empresa empresa;
	
	@Column(name = "MONEDA")
	private String moneda;

	@Column(name = "MONTO", columnDefinition = "DECIMAL(15,2)", precision = 15, scale = 2)
	private BigDecimal monto;
	
	@ManyToOne
	@JoinColumn(name = "NORMATIVA_ID")
	private Normativa normativa;

	public NormativaEmpresa() {
		super();
	}

	@Override
	public String toString() {
		return "NormativaEmpresa [id=" + id + ", empresa=" + empresa
				+ ", monto=" + monto + ", moneda=" + moneda + "]";
	}


	public String getMontoFormat() {
		if (monto != null) {
			return getDecimalDosFormat(monto);
		} else {
			return "";
		}
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NormativaEmpresa other = (NormativaEmpresa) obj;
		// id
		if (id == null && other.id != null) {
			return false;
		} else if (!id.equals(other.id))
			return false;
		// empresa
		if (empresa == null && other.empresa != null) {
			return false;
		} else if (!empresa.equals(other.empresa))
			return false;
		// empresa
		if (monto == null && other.monto != null) {
			return false;
		} else if (!monto.equals(other.monto))
			return false;
		// estado
		
		return true;
	}

}
