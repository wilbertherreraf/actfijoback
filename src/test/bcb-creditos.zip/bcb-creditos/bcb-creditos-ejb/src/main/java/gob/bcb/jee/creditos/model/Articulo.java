package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;


/**
 * The persistent class for the aux_bcbprice database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="articulo")
@NamedQueries({
    @NamedQuery(name = Articulo.NQ_LIST_ALL, query = "SELECT a FROM Articulo a"),
    @NamedQuery(name = Articulo.NQ_GET_BY_ID, query = "SELECT p FROM Articulo p where p.id=:valor1  "),
    @NamedQuery(name = Articulo.NQ_GET_BY_CLI_LEY, query = "SELECT p FROM Articulo p where p.idLey=:valor1 and p.idCliPersona=:valor2 order by id  "),
    @NamedQuery(name = Articulo.NQ_GET_BY_CLI, query = "SELECT p FROM Articulo p where p.idCliPersona=:valor1")
    
})
public class Articulo extends EntidadAutorizable<Integer> implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="Articulo";
	  public static final String NQ_GET_BY_ID =ENTITY+"GetById";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	  public static final String NQ_GET_BY_CLI =ENTITY+"GetByCli";
	  public static final String NQ_GET_BY_CLI_LEY =ENTITY+"GetByCliLey";
	@Id  
	@Column(name="id_articulo")
	private Integer id;
	
	@Column(name="id_ley")
	private Integer idLey;
	
	@Column(name="numero_articulo", length = 49)
	private String numeroArticulo;
	
	@Column(name="id_cli_persona")
	private Integer idCliPersona;
		
	@Column(name="monto_registrado")
	private BigDecimal montoRegistrado;

	@Column(name="monto_otorgado")
	private BigDecimal montoOtorgado;
	
	@Column(name="saldo")
	private BigDecimal saldo;

	
	@Column(name="tabtrxstaau")
	private Integer tabtrxstaau;
	
	@Column(name="trxstaau")
	private Integer trxstaau;
	
	
	@Column(name="auditusr")
	private String auditusr;

	@Column(name="auditfho")
	private Timestamp auditfho;

	@Column(name="auditwst")
	private String auditwst;
	


}
