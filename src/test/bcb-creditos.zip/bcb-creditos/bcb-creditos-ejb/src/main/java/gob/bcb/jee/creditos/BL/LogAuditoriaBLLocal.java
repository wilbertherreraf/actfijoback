/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.BL.FeriadoBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.LogAuditoria;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.numeradores.TipoTransaccion;
import gob.bcb.jee.creditos.numeradores.TipoParametro;

import javax.ejb.Local;

/**
 * Interface para el negocio del a entidad LogAuditoria
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface LogAuditoriaBLLocal extends
    GenericBLLocal<LogAuditoria, Long>
{
    public void registrarLog(TipoParametro tipoParametro, TipoTransaccion tipoAccion)throws OperationException;

}
