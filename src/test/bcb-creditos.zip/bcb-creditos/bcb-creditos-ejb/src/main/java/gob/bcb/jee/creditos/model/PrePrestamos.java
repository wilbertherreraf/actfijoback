package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.enterprise.inject.Default;
import javax.persistence.*;

import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import gob.bcb.jee.creditos.util.Reflection;
import lombok.Getter;
import lombok.Setter;


@Entity
@Getter
@Setter
@Table(name="pre_prestamos")
@NamedQueries({
    @NamedQuery(name = PrePrestamos.NQ_GET_BY_ID, query = "SELECT e FROM PrePrestamos e where e.prePrestamosPK.preCodcred = :pre_codcred and e.preTrxstaau=3 "),
    @NamedQuery(name = PrePrestamos.NQ_GET_BY_NRO_CONTRATO, query = "SELECT e FROM PrePrestamos e where e.preTrxstaau=3 and UPPER(e.preNumcontra) like CONCAT('%',:valor1,'%') "),
    @NamedQuery(name = PrePrestamos.NQ_GET_BY_CLIENTE, query = "SELECT e FROM PrePrestamos e where e.preCodcli=:valor1 and e.preTrxstaau=3"),
    
    @NamedQuery(name = PrePrestamos.NQ_GET_BY_ID_R, query = "SELECT e FROM PrePrestamos e where e.prePrestamosPK.preCodcred = :pre_codcred  "),
    @NamedQuery(name = PrePrestamos.NQ_GET_BY_NRO_CONTRATO_R, query = "SELECT e FROM PrePrestamos e where UPPER(e.preNumcontra) like CONCAT('%',:valor1,'%')"),
    @NamedQuery(name = PrePrestamos.NQ_GET_BY_CLIENTE_R, query = "SELECT e FROM PrePrestamos e where e.preCodcli=:valor1 ORDER BY e.prePrestamosPK.preCodcred DESC "),
    
    @NamedQuery(name = PrePrestamos.NQ_LIST_ALL, query = "SELECT p FROM PrePrestamos p")
    
})
public class PrePrestamos  extends EntidadAutorizable<PrePrestamosPK> implements Serializable{
	  private static final long serialVersionUID = 1L;
	  public static final String ENTITY ="PrePrestamos";
	  public static final String NQ_GET_BY_ID ="GetById";
	  public static final String NQ_GET_BY_NRO_CONTRATO ="GetByNroContrato";
	  public static final String NQ_GET_BY_CLIENTE ="GetByCliente";
	  
	  public static final String NQ_GET_BY_ID_R ="GetByIdR";
	  public static final String NQ_GET_BY_NRO_CONTRATO_R ="GetByNroContratoR";
	  public static final String NQ_GET_BY_CLIENTE_R ="GetByClienteR";
	  
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	@Id	
	@EmbeddedId
	private PrePrestamosPK prePrestamosPK;

	@Column(name="pre_codprod")
	private Integer preCodprod;
	
	@Column(name="pre_codcli")
	private Integer preCodcli;
	
	@Column(name="pre_codmon")
	private Integer preCodmon;
	
	@Column(name="pre_numcontra")
	private String preNumcontra;
	
	@Temporal(TemporalType.DATE)
	@Column(name="pre_fecreg")
	private Date preFecreg;
	
	@Temporal(TemporalType.DATE)
	@Column(name="pre_fecemi")
	private Date preFecemi;
	
	@Column(name="pre_tasapac")
	private Double preTasapac;
	
	@Column(name="pre_monto")
	private BigDecimal preMonto;
	
	@Column(name="pre_monliqent")
	private BigDecimal preMonliqent;
	
	@Column(name="pre_saldo")
	private BigDecimal preSaldo;
	
	@Column(name="pre_montsusp")
	private BigDecimal preMontsusp;
	
	@Column(name="pre_tabtiprubro")
	private Integer preTabtiprubro;

	@Column(name="pre_tiprubro")
	private Integer preTiprubro;
	
	@Column(name="pre_tabdestcred")
	private Integer preTabdestcred;
	
	@Column(name="pre_destcred")
	private Integer preDestcred;
	
	@Column(name="pre_descrdcr")
	private String preDescrdcr;
	
	@Column(name="pre_tabstatus")
	private Integer preTabstatus;
	
	@Column(name="pre_status")
	private Integer preStatus;
	
	@Temporal(TemporalType.DATE)
	@Column(name="pre_fecplzven")
	private Date preFecplzven;
		
	@Temporal(TemporalType.DATE)
	@Column(name="pre_fecprimpag")
	private Date preFecprimpag;
	
	@Temporal(TemporalType.DATE)
	@Column(name="pre_feculttrx")
	private Date preFeculttrx;
	
	@Column(name="pre_numconv")
	private String preNumconv;
	
	@Column(name="pre_numresol")
	private String preNumresol;
	
	@Column(name="pre_tabstatreg")
	private Integer preTabstatreg;
	
	@Column(name="pre_statreg")
	private Integer preStatreg;
	
	@Column(name="pre_tabtrxstaau")
	private Integer preTabtrxstaau;
	
	@Column(name="pre_trxstaau")
	private Integer preTrxstaau;

	@Column(name="pre_auditusr")
	private String preAuditusr;
	
	@Column(name="pre_auditfho")
	private Timestamp preAuditfho;
	
	@Column(name="pre_auditwst")
	private String preAuditwst;
				
	@Column(name="pre_nroperiodos")
	private Integer preNroperiodos; 
	
	@Column(name="pre_nrogracia")
	private Integer preNrogracia; 
	
	@Column(name="pre_nrograciaint")
	private Integer preNrograciaint; 
	
	@Column(name="pre_nropagos")
	private Integer preNropagos; 
	
	@Column(name="pre_diasfijoper")
	private Integer preDiasfijoper; 
	
	@Temporal(TemporalType.DATE)
	@Column(name="pre_feclimite")
	private Date preFeclimite;
	
	@Temporal(TemporalType.DATE)
	@Column(name="pre_fecfirmconv")
	private Date preFecfirmconv;
	
	@Column(name="pre_descrip")
	private String preDescrip;
	
	@Column(name="pre_unidplaz")
	private Integer preUnidplaz; 
	
	@Column(name="pre_tabunidplaz")
	private Integer preTabunidplaz;
	
	@Column(name="pre_tabmethodcapi")
	private Integer preTabmethodcapi;
	
	@Column(name="pre_methodcapi")
	private Integer preMethodcapi;

	@Column(name="pre_estado_parametros")
	private Integer preEstadoParametros;

	@Transient
	private PrePrcconta prcconta;	
/////////////////////////

	public PrePrestamos() {
	}
	@Override
	public String toString() {
		Reflection<PrePrestamos> reflex=new Reflection<PrePrestamos>();
		return reflex.imprimirCampos(this);
	}

    @Override
    public boolean equals(Object o) {
    	Reflection<PrePrestamos> reflex=new Reflection<PrePrestamos>();
		return reflex.equals(this,o);      
    }

    @Override
    public int hashCode() {
    	Reflection<PrePrestamos> reflex=new Reflection<PrePrestamos>();
		return reflex.generarHash(this);
    }
	@Override
	public PrePrestamosPK getId() {
		// TODO Auto-generated method stub
		return this.prePrestamosPK;
	}
	@Override
	public void setId(PrePrestamosPK id) {
		this.prePrestamosPK=id;
	}  
}
