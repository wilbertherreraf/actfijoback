/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import gob.bcb.jee.creditos.BL.PrePrccontaBLLocalImpl;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PrePrestamosPK;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PrePrestamosQLLocalImpl extends
		GenericQLLocalImpl<PrePrestamos, PrePrestamosPK> implements
		PrePrestamosQLLocal {
private static final Logger log = LoggerFactory.getLogger(PrePrccontaBLLocalImpl.class);			
	@PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
	private EntityManager entityManager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
	 * ()
	 */
	@Override
	protected EntityManager entityManager() {
		return entityManager;
	}

	@Override
	public Integer getIdByModulo(Integer codmod) throws OperationException {
		String nativeQuery = "select max(pre_codcred) from pre_prestamos ";
		Query query = entityManager.createNativeQuery(nativeQuery);
		Object valor = query.getSingleResult();
		int id = 1;
		if (valor != null) {
			id = Integer.parseInt(valor.toString()) + 1;
		}
		return id;
	}

	@Override
	public Integer getValorPeriodicidad(Integer valor) throws OperationException {
		String nativeQuery = "call d_creditos.f_ISREPMTSPERYEAR(:valor1)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", valor);
		Object valor1 = query.getSingleResult();
		int id = 0;
		if (valor1 != null) {
			id = Integer.parseInt(valor1.toString());
		}
		return id;
	}

	public PrePrestamos prestamoById(Integer codcred, Integer codmod) {
		String nativeQuery = "select t from PrePrestamos t where t.prePrestamosPK.preCodcred = :codcred and t.prePrestamosPK.preCodmod = :codmod";
		Query query = entityManager.createQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);
		List valor1 = query.getResultList();

		if (valor1.size() > 0) {
			return (PrePrestamos) valor1.get(0);
		}
		return null;
	}

	public List<PrePrestamos> prestamosVig(Integer tipoproc) {
		StringBuilder sb = new StringBuilder();
		sb.append("select t from PrePrestamos t ");
		sb.append("where t.preStatus != 9 ");
		Query query = entityManager.createQuery(sb.toString());
		List list = query.getResultList();

		return list;
	}

		public void procesarReprogramacion(Integer tipotrx, Integer codrepo, Date fecha, String user,	String ip) {

		String nativeQuery = "call d_creditos.p_rpro_calc_plan(:tipotrx,:codrepo, :fecha,:user,:ip)";
		try {
			log.info("En p_rpro_calc_plan codrepo " + codrepo + " tipotrx " + tipotrx);
			Query query = entityManager.createNativeQuery(nativeQuery);
			query.setParameter("tipotrx", tipotrx);
			query.setParameter("codrepo", codrepo);
			query.setParameter("fecha", fecha);
			query.setParameter("user", user);
			query.setParameter("ip", ip);
			query.executeUpdate();
		} catch (Exception e) {
			log.error("Exception: " + e.getMessage());
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			String consent = (count > 0 ? sb.toString().replace(", null ,", "")
					: "Error :" + e.getMessage().replace(", null ,", ""));
			throw new RuntimeException("Error p_rpro_calc_plan: " + consent, e);
		}
	}

	@Override
	public void p_rpro_aprob_planpagos(Integer codcred, Integer codmod, Integer codtmp, Integer codrep, String user,
			String ip) throws OperationException {
		String nativeQuery = "call d_creditos.p_rpro_aprob_planpagos(:valor1,:valor2, :valor3, :valor4,  :valor5, :valor6)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);
		query.setParameter("valor3", codtmp);
		query.setParameter("valor4", codrep);
		query.setParameter("valor5", user);
		query.setParameter("valor6", ip);
		query.executeUpdate();
	}

	public void pagoAnticipadoCrearAct(Integer tipotrx, Integer codmod, Integer codrepro, Date fechaoper, String user,
			String estacion) {
		try {
			Log.Info("En crear-actualizar pago anticipo p_generar_oper_panti_dsb codrepro: tipotrx:" + tipotrx
					+ " codrepro: " + codrepro + ", fecha: "
					+ fechaoper
					+ ", usr: " + user + ", est: " + estacion);
			String nativeQuery = "call d_creditos.p_generar_oper_panti_dsb(:trxstaau, :codrepro, :fechaoper, :user, :estacion)";
			Query query = entityManager.createNativeQuery(nativeQuery);
			query.setParameter("codrepro", codrepro);
			query.setParameter("trxstaau", tipotrx);
			query.setParameter("fechaoper", fechaoper);
			query.setParameter("user", user);
			query.setParameter("estacion", estacion);
			query.executeUpdate();
		} catch (Exception e) {
			Log.Error("Exception: " + e.getMessage());
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			String consent = (count > 0 ? sb.toString().replace(", null ,", "")
					: "Error :" + e.getMessage().replace(", null ,", ""));
			throw new RuntimeException("Error p_generar_operacion: " + consent, e);
		}
	}

	@Override
	public void pagoAnticipadoNuevo(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion)
			throws OperationException {
		Integer tipotrx = 1;// C_TRXSTAAU_VIGENTE = 1;
		pagoAnticipadoCrearAct(tipotrx, codmod, codrepro, fechaoper, user, estacion);
	}

	public void preAutoPagAnticip(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion)
			throws OperationException {
		Log.Info("PREAUTORIZAR anticipo p_generar_oper_panti_dsb codrepro: " + codrepro + ", fecha: " + fechaoper
				+ ", usr: " + user + ", est: " + estacion);
		Integer tipotrx = 2;// C_TRXSTAAU_PREAUTO = 2;
		pagoAnticipadoCrearAct(tipotrx, codmod, codrepro, fechaoper, user, estacion);
	}

	public void autorizarPagAnticip(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion) {
		Log.Info("AUTORIZAR p anticipo p_generar_oper_panti_dsb codrepro: " + codrepro + ", fecha: " + fechaoper
				+ ", usr: " + user + ", est: " + estacion);
		Integer tipotrx = 3;// C_TRXSTAAU_PREAUTO = 2;
		pagoAnticipadoCrearAct(tipotrx, codmod, codrepro, fechaoper, user, estacion);
	}

	public void eliminarAutoPagAnticip(Integer codmod, Integer codrepro, Date fechaoper, String user, String estacion)
			throws OperationException {
		Log.Info("ELIMAR eliminarAutoPagAnticip codrepro: " + codrepro + ", fecha: " + fechaoper + ", usr: " + user
				+ ", est: " + estacion);
		Integer C_TRXSTAAU_ELIMINAR = 9;
		Integer tipotrx = 9;// C_TRXSTAAU_PREAUTO = 2;
		pagoAnticipadoCrearAct(tipotrx, codmod, codrepro, fechaoper, user, estacion);
	}

	@Override
	public void diferimiento(Integer tipotrx, Integer codrepro, Date fechaoper, Date fechaInicio, Date fechaFin,
			String user, String estacion) throws OperationException {
		String nativeQuery = "call d_creditos.p_rpro_calc_plan_difer(:tipotrx,:codrepro, :fechaoper, :fechaInicio, :fechaFin, :valor6, :valor7)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("tipotrx", tipotrx);
		query.setParameter("codrepro", codrepro);
		query.setParameter("fechaoper", fechaoper);
		query.setParameter("fechaInicio", fechaInicio);
		query.setParameter("fechaFin", fechaFin);
		query.setParameter("valor6", user);
		query.setParameter("valor7", estacion);
		query.executeUpdate();
	}

	@Override
	public BigDecimal obtenerInteresesDevengado(Integer codcred, Integer codmod) {
		String nativeQuery = "select nvl(sum(b.acr_interes), 0) "
				+ "from pre_accrual b "
				+ "where b.acr_fecaccru = date(current) "
				+ "and acr_codmod = :valor2 "
				+ "and acr_codcred = :valor1 "
				+ "and acr_tipoacr = 3 ";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);

		Object valor1 = query.getSingleResult();
		BigDecimal suma = BigDecimal.ZERO;
		if (valor1 != null) {
			suma = new BigDecimal(valor1.toString());
		}

		return suma;
	}

	@Override
	public Integer obtenerCantidadDesembolsos(Integer codcred, Integer codmod) {
		String nativeQuery = "select count(1) "
				+ "from d_creditos.pre_desemb "
				+ "where dsb_undsb>0 "
				+ "and dsb_codcred=:valor1 and dsb_codmod=:valor2 ";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);

		Object valor1 = query.getSingleResult();
		int id = 0;
		if (valor1 != null) {
			id = Integer.parseInt(valor1.toString());
		}

		return id;
	}

	@Override
	public BigDecimal obtenerInteresesCobrados(Integer codcred, Integer codmod) {
		String nativeQuery = "call f_getamtcobroscap(:valor1, :valor2, null, null,null, 2);";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);

		Object valor1 = query.getSingleResult();
		BigDecimal suma = BigDecimal.ZERO;
		if (valor1 != null) {
			suma = new BigDecimal(valor1.toString());
		}

		return suma;
	}

	@Override
	public Date obtenerUltimaFechaPlanPagos(Integer codcred, Integer codmod) {
		String nativeQuery = "select max(cuo_fecvencuo) "
				+ "        from pre_planpagos "
				+ "        where cuo_codmod = :valor2 "
				+ "        and cuo_codcred = :valor1 "
				+ "        and cuo_tipocuo = 1 "
				+ "        and cuo_valor > 0 "
				+ "        and cuo_coddsb > 0;";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);

		Object valor1 = query.getSingleResult();
		Date date = null;
		if (valor1 != null) {
			date = (Date) valor1;
		}

		return date;
	}

	@Override
	public BigDecimal obtenerMontoDescomprometido(Integer codcred, Integer codmod) {
		String nativeQuery = "call f_getamtundsb(:valor1, :valor2, current) ";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);

		Object valor1 = query.getSingleResult();
		BigDecimal suma = BigDecimal.ZERO;
		if (valor1 != null) {
			suma = new BigDecimal(valor1.toString());
		}
		return suma;
	}

	@Override
	public BigDecimal obtenerCapitalAmortizado(Integer codcred, Integer codmod) {
		String nativeQuery = "call f_getamtcobroscap(:valor1, :valor2, null, null, current, 2)  ";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);

		Object valor1 = query.getSingleResult();
		BigDecimal suma = BigDecimal.ZERO;
		if (valor1 != null) {
			suma = new BigDecimal(valor1.toString());
		}
		return suma;
	}

	@Override
	public List<Object[]> ObtenerParamsComprobante(Integer codcred, Integer codmod) throws OperationException {
		String nativeQuery = "SELECT " +
				"MAX(CASE WHEN par_tprcod = 3 THEN par_parametro END) AS cta_debe, " +
				"MAX(CASE WHEN par_tprcod = 4 THEN par_parametro END) AS cta_haber, " +
				"MAX(CASE WHEN par_tprcod = 25 THEN par_parametro END) AS cp_actual " +
				"FROM gen_parametro " +
				"WHERE par_codcred = :valor1 AND par_codmod = :valor2 AND par_tprcod IN (3, 4, 25) " +
				"GROUP BY par_codcred, par_codmod";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);

		List<Object[]> results = query.getResultList();

		if (results == null || results.isEmpty()) {
			throw new OperationException("No se pudo obtener los parametros del crédito");
		}
		return results;
	}

	public Integer ObtenerIdProcesoComprobante(Integer codcmp, Integer codcred, Integer codmod, Date fecha,
			Integer estado) throws OperationException {
		String nativeQuery = "call d_creditos.p_get_id_proceso_conta(:valor1, :valor2, :valor3, :valor4, :valor5 )";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcmp);
		query.setParameter("valor2", codcred);
		query.setParameter("valor3", codmod);
		query.setParameter("valor4", fecha);
		query.setParameter("valor5", estado);
		Object prc_codprc = query.getSingleResult();
		if (prc_codprc == null) {
			throw new OperationException("No se pudo obtener el ID del proceso comprobante");
		}
		try {
			return Integer.parseInt(prc_codprc.toString());
		} catch (NumberFormatException e) {
			throw new OperationException("El código de proceso obtenido no es un número válido");
		}
	}

	@Override
	public Date obtenerFechaCancelado(Integer codcred, Integer codmod) {

		String nativeQuery = "select FIRST 1 fechavencuo fecha " +
				" from v_planpagos_consol " +
				" where codmod=:codmod " +
				" and codcred=:codcred and estado_cuota='CANCELADO' and tipotrx = 2 order by fecha desc ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);

		Object valor1 = query.getSingleResult();
		Date date = null;
		if (valor1 != null) {
			date = (Date) valor1;
		}

		return date;
	}

	@Override
	public Date obtenerFechaSinCancelar(Integer codcred, Integer codmod) {

		String nativeQuery = " select FIRST 1 fechavencuo fecha " +
				" from v_planpagos_consol " +
				" where codmod=:codmod " +
				" and codcred=:codcred and tipotrx = 2 and estado_cuota='SIN CANCELAR' order by fecha asc ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);

		Object valor1 = query.getSingleResult();
		Date date = null;
		if (valor1 != null) {
			date = (Date) valor1;
		}

		return date;

	}

	@Override
	public Date obtenerFechaProximoPago(Integer codcred, Integer codmod) {
		String nativeQuery = " select FIRST 1 fechavencuo fecha " +
				" from v_planpagos_consol " +
				" where codmod=:codmod and tipotrx = 2 " +
				" and codcred=:codcred and fechavencuo >= CURRENT order by fecha asc ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);

		List<Object> resultados = query.getResultList();
		Date date = null;

		if (!resultados.isEmpty()) {
			date = (Date) resultados.get(0);
		} else {
			// Manejar el caso donde no se encontró ningún resultado
			System.out.println("No se encontraron resultados para la consulta.");
		}

		return date;
	}

	@Override
	public String obtenerValorMatrizParametro(Integer codcred, Integer parametro) throws OperationException {

		String nativeQuery = " SELECT NVL( " +
				"    (SELECT par_parametro " +
				"     FROM gen_parametro " +
				"     WHERE par_codcred = :parCodcred AND par_tprcod = :parTprcod), " +
				"    'S/D' " +
				" ) AS par_parametro " +
				" FROM systables " +
				" WHERE tabid = 1; ";
		Query query = entityManager.createNativeQuery(nativeQuery).setParameter("parCodcred", codcred)
				.setParameter("parTprcod", parametro);
		Object valor = query.getSingleResult();

		if (valor != null) {
			return valor.toString();
		}
		return null;
	}

	@Override
	public Date obtenerFechaUltimoDevengado(Integer codcred, Integer codmod, Date fechaDevengado)
			throws OperationException {

		String nativeQuery = " select pre_fecplzven  " +
				" from pre_prestamos " +
				" where pre_codcred=:codcred and pre_codmod=:codmod ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);
		query.setParameter("fechaDevengado", fechaDevengado);

		Object valor1 = query.getSingleResult();
		Date date = null;
		if (valor1 != null) {
			date = (Date) valor1;
		}

		return date;
	}

	@Override
	public BigDecimal obtenerTotalInteresDevengado(Integer codcred, Integer codmod, Date fechaDevengado,
			Date fechaUltimodevengado) throws OperationException {
		String nativeQuery = "select sum(acr_interes) total_interes " +
				" from d_creditos.pre_accrual " +
				" where acr_codcred=:codcred and acr_tipoacr=1 " +
				" and acr_fecaccru>:fechaUltimodevengado and acr_fecaccru<= :fechaDevengado ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("fechaUltimodevengado", fechaUltimodevengado);
		query.setParameter("fechaDevengado", fechaDevengado);

		Object valor1 = query.getSingleResult();
		BigDecimal suma = BigDecimal.ZERO;
		if (valor1 != null) {
			suma = new BigDecimal(valor1.toString());
		}
		return suma;
	}

	@Override
	public List<Object[]> ObtenerDatosFechaDevengado(Integer codcred, Integer codmod) throws OperationException {
		String nativeQuery = "SELECT " +
				"    MAX(CASE WHEN rn = 1 THEN fecha_devengado END) AS fechaUltimoDevengado, " +
				"    MAX(CASE WHEN rn = 2 THEN fecha_devengado END) AS fechaDevengadoAnterior " +
				" FROM ( " +
				"    SELECT FIRST 2 fecha_devengado, " +
				"           ROW_NUMBER() OVER(ORDER BY id DESC) AS rn " +
				"    FROM d_creditos.pre_registro_devengado_creditos " +
				"    WHERE codcred = :codcred " +
				"    ORDER BY fecha_devengado DESC " +
				" ) AS t";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		List<Object[]> results = query.getResultList();

		if (results == null || results.isEmpty()) {
			throw new OperationException("No se pudo obtener los datos de fecha de devengados");
		}

		return results;
	}

	@Override
	public Date obtenerFechaUltimoDevengadoPorCredito(Integer codcred, Integer codmod) throws OperationException {
		String nativeQuery = " select pre_fecplzven " +
				" from pre_prestamos " +
				" where pre_codcred=:codcred " +
				" and pre_codmod=:codmod ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);

		Object valor1 = query.getSingleResult();
		Date date = null;
		if (valor1 != null) {
			date = (Date) valor1;
		}

		return date;
	}

	@Override
	public Date obtenerFechaUltimoDevengadoGeneral() {
		String nativeQuery = " select max(prc_fecha_2) "
				+
				" from pre_prcconta " +
				" where prc_estado=3 " +
				" and prc_auditfhoaut is not null ";

		Query query = entityManager.createNativeQuery(nativeQuery);

		Object valor1 = query.getSingleResult();
		Date date = null;
		if (valor1 != null) {
			date = (Date) valor1;
		}

		return date;
	}

	@Override
	public Date obtenerFechaUltimoDevengadoPorCreditoComprobante(Integer codcred, Integer codmod, Date fecha)
			throws OperationException {
		String nativeQuery = " select pre_fecplzven " +
				" from pre_prestamos " +
				" where pre_codcred=:codcred " +
				" and pre_codmod=:codmod ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);
		query.setParameter("fecha", fecha);

		Object valor1 = query.getSingleResult();
		Date date = null;
		if (valor1 != null) {
			date = (Date) valor1;
		}

		return date;
	}

	public Integer presVigentes() {
		StringBuilder nativeQuery = new StringBuilder("select count(1) ");
		nativeQuery.append("from pre_prestamos   ");
		nativeQuery.append("where pre_saldo > 0 ");
		nativeQuery.append("and pre_monto > 0 ");
		nativeQuery.append("and pre_status = 2  ");
		Query query = entityManager.createNativeQuery(nativeQuery.toString());

		Object valor1 = query.getSingleResult();
		int id = 0;
		if (valor1 != null) {
			id = Integer.parseInt(valor1.toString());
		}

		return id;
	}

	public BigDecimal mntOtorgado() {
		StringBuilder nativeQuery = new StringBuilder("select sum(pre_monliqent) ");
		nativeQuery.append("from pre_prestamos   ");
		nativeQuery.append("where pre_saldo > 0 ");
		nativeQuery.append("and pre_monto > 0 ");
		nativeQuery.append("and pre_status = 2  ");
		Query query = entityManager.createNativeQuery(nativeQuery.toString());

		Object valor1 = query.getSingleResult();
		BigDecimal suma = BigDecimal.ZERO;
		if (valor1 != null) {
			suma = new BigDecimal(valor1.toString());
		}
		return suma;
	}

	public BigDecimal mntPorRecuperar() {
		StringBuilder nativeQuery = new StringBuilder("select sum(pre_saldo) ");
		nativeQuery.append("from pre_prestamos   ");
		nativeQuery.append("where pre_saldo > 0 ");
		nativeQuery.append("and pre_monto > 0 ");
		nativeQuery.append("and pre_status = 2  ");
		Query query = entityManager.createNativeQuery(nativeQuery.toString());

		List list = query.getResultList();

		if (list.size() == 0) {
			return BigDecimal.ZERO;
		}
		BigDecimal suma = BigDecimal.ZERO;
		Object o = list.get(0);
		if (o != null) {
			suma = new BigDecimal(o.toString());
		}
		return suma;
	}
}
