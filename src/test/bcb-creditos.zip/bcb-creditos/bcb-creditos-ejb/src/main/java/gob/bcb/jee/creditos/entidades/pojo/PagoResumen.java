package gob.bcb.jee.creditos.entidades.pojo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by eborda on 11/10/2016.
 */
public class PagoResumen {
    public Long proyectoId;
    public Long desembolsoId;
    public Long pagoId;
    public Date fechaVencimiento;
    public Integer nroCuota;
    public Integer periodoGracia;
    public BigDecimal desembolsoCapital;
    public BigDecimal acumulado;
    public BigDecimal saldoCapital;
    public BigDecimal amotizacionCapital;
    public BigDecimal pagoInteres;
    public BigDecimal montoPagar;
    public BigDecimal valorDeuda;

    public PagoResumen(Long proyectoId, Long desembolsoId, Long pagoId, Date fechaVencimiento,Integer nroCuota,Integer periodoGracia, BigDecimal desembolsoCapital, BigDecimal acumulado, BigDecimal saldoCapital, BigDecimal amotizacionCapital, BigDecimal pagoInteres, BigDecimal montoPagar, BigDecimal valorDeuda) {
        this.proyectoId = proyectoId;
        this.desembolsoId = desembolsoId;
        this.pagoId = pagoId;
        this.fechaVencimiento = fechaVencimiento;
        this.nroCuota = nroCuota;
        this.periodoGracia = periodoGracia;
        this.desembolsoCapital = desembolsoCapital;
        this.acumulado = acumulado;
        this.saldoCapital = saldoCapital;
        this.amotizacionCapital = amotizacionCapital;
        this.pagoInteres = pagoInteres;
        this.montoPagar = montoPagar;
        this.valorDeuda = valorDeuda;
    }

    public PagoResumen() {

    }

    public Long getProyectoId() {
        return proyectoId;
    }

    public void setProyectoId(Long proyectoId) {
        this.proyectoId = proyectoId;
    }

    public Long getDesembolsoId() {
        return desembolsoId;
    }

    public void setDesembolsoId(Long desembolsoId) {
        this.desembolsoId = desembolsoId;
    }

    public Long getPagoId() {
        return pagoId;
    }

    public void setPagoId(Long pagoId) {
        this.pagoId = pagoId;
    }

    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(Date fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public Integer getNroCuota() {
        return nroCuota;
    }

    public void setNroCuota(Integer nroCuota) {
        this.nroCuota = nroCuota;
    }

    public Integer getPeriodoGracia() {
        return periodoGracia;
    }

    public void setPeriodoGracia(Integer periodoGracia) {
        this.periodoGracia = periodoGracia;
    }

    public BigDecimal getDesembolsoCapital() {
        return desembolsoCapital;
    }

    public void setDesembolsoCapital(BigDecimal desembolsoCapital) {
        this.desembolsoCapital = desembolsoCapital;
    }

    public BigDecimal getAcumulado() {
        return acumulado;
    }

    public void setAcumulado(BigDecimal acumulado) {
        this.acumulado = acumulado;
    }

    public BigDecimal getSaldoCapital() {
        return saldoCapital;
    }

    public void setSaldoCapital(BigDecimal saldoCapital) {
        this.saldoCapital = saldoCapital;
    }

    public BigDecimal getAmotizacionCapital() {
        return amotizacionCapital;
    }

    public void setAmotizacionCapital(BigDecimal amotizacionCapital) {
        this.amotizacionCapital = amotizacionCapital;
    }

    public BigDecimal getPagoInteres() {
        return pagoInteres;
    }

    public void setPagoInteres(BigDecimal pagoInteres) {
        this.pagoInteres = pagoInteres;
    }

    public BigDecimal getMontoPagar() {
        return montoPagar;
    }

    public void setMontoPagar(BigDecimal montoPagar) {
        this.montoPagar = montoPagar;
    }

    public BigDecimal getValorDeuda() {
        return valorDeuda;
    }

    public void setValorDeuda(BigDecimal valorDeuda) {
        this.valorDeuda = valorDeuda;
    }

    @Override
    public String toString() {
        return "PagoResumen{" +
                "proyectoId=" + proyectoId +
                ", desembolsoId=" + desembolsoId +
                ", pagoId=" + pagoId +
                ", fechaVencimiento=" + fechaVencimiento +
                ", nroCuota=" + nroCuota +
                ", periodoGracia=" + periodoGracia +
                ", desembolsoCapital=" + desembolsoCapital +
                ", acumulado=" + acumulado +
                ", saldoCapital=" + saldoCapital +
                ", amotizacionCapital=" + amotizacionCapital +
                ", pagoInteres=" + pagoInteres +
                ", montoPagar=" + montoPagar +
                ", valorDeuda=" + valorDeuda +
                '}';
    }
}
