package gob.bcb.jee.creditos.QL;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.model.PrePrcconta;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author hpanique
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)

public class PrePrccontaQLLocalImpl extends GenericQLLocalImpl<PrePrcconta, Integer> implements PrePrccontaQLLocal {
    private static final Logger log = LoggerFactory.getLogger(PrePrccontaQLLocalImpl.class);
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /*
     * (non-Javadoc)
     * 
     * @see
     * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
     * ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

    @Override
    public Integer getNextId() {
        String nativeQuery = " select max (prc_codprc)  from pre_prcconta ";

        Query query = entityManager.createNativeQuery(nativeQuery);

        List lista = query.getResultList();
        if (lista.size() > 0) {
            Integer maximo = lista.get(0) != null ? (Integer) lista.get(0) : 0;
            return (maximo == null ? Integer.valueOf(1) : ++maximo);
        }

        return Integer.valueOf(1);

    }

    public PrePrcconta guardarPrcconta(PrePrcconta prePrcconta) {
        try {
            Integer entero = null;

            if (prePrcconta.getPrcCodprc() == null) {
                PrePrcconta prePrccontaOld = buscarPorFechaDeven(prePrcconta.getPrcCodcred(),
                        prePrcconta.getPrcCodmod(),
                        prePrcconta.getPrcFecha2());
                if (prePrccontaOld != null) {
                    throw new RuntimeException(
                            "Registro contable existente para fecha devengado " + prePrcconta.getPrcFecha2());
                }
                entero = getNextId();
                prePrcconta.setPrcCodprc(entero);
                entityManager.persist(prePrcconta);
                log.info("prePrccontaNew creado " + entero);
            } else {
                entero = prePrcconta.getPrcCodprc();
                entityManager.merge(prePrcconta);
                log.info("prePrccontaNew modificado " + prePrcconta.getPrcCodprc());
            }
            PrePrcconta prePrccontaNew = this.get(entero);
            return prePrccontaNew;
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
                if (cause instanceof SQLException) {
                    count++;
                    sb.append(cause.getMessage());
                    sb.append(" , ");
                }
            }
            String consent = (count > 0 ? sb.toString().replace(", null ,", "")
                    : "Error :" + e.getMessage().replace(", null ,", ""));
            throw new RuntimeException("Error guardarPrcconta: " + consent, e);
        }
    }
    public PrePrcconta buscarPorId(Integer prcCodprc) {
        if (prcCodprc == null) {
            return null;
        }

        String jpql = "SELECT t FROM PrePrcconta t WHERE t.prcCodprc = :prcCodprc " ;

        Query query = entityManager.createQuery(jpql);
        query.setParameter("prcCodprc", prcCodprc);

        List lista = query.getResultList();
        if (lista.size() > 0) {
            return (PrePrcconta) lista.get(0);
        }

        return null;
    }

    public void initProcesoConta(Integer tipocmp,Integer idtabla ,Integer tipotrx ,Integer codcred,Integer codmod,Integer coddsb, Date fecha2, String usuario, String estacion) {
        try {
            log.info("En  p_init_proceso_conta para tipotrx " + tipotrx + " tipocmp " + tipocmp
                    + " codcred " + codcred + " codmod " + codmod + " fecha " + fecha2);
            String nativeQuery = "call d_creditos.p_init_proceso_conta(:tipocmp,:idtabla ,:tipotrx ,:codcred,:codmod,:coddsb, :fecha2, :usuario, :estacion)";
            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("tipocmp", tipocmp);            
            query.setParameter("idtabla", idtabla);                        
            query.setParameter("tipotrx", tipotrx);
            query.setParameter("codcred", codcred);
            query.setParameter("codmod", codmod);
            query.setParameter("coddsb", coddsb);            
            query.setParameter("fecha2", fecha2);
            query.setParameter("usuario", usuario);
            query.setParameter("estacion", estacion);

            query.executeUpdate();

        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
                if (cause instanceof SQLException) {
                    count++;
                    sb.append(cause.getMessage());
                    sb.append(" , ");
                }
            }
            String consent = (count > 0 ? sb.toString().replace(", null ,", "")
                    : "Error :" + e.getMessage().replace(", null ,", ""));
            throw new RuntimeException("Error p_init_proceso_conta: " + consent, e);
        }
    }

    public PrePlanpagos obtenerDevengamientoAFecha(Integer codcred, Integer codmod, Date fechafin, Date fecha) {
        String nativeQuery = "call d_creditos.p_get_datos_devengamiento(:valor1, :valor2, :fechafin, :valor3)";
        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("valor1", codcred);
        query.setParameter("valor2", codmod);
        query.setParameter("fechafin", fechafin);
        query.setParameter("valor3", fecha);

        List<Object[]> results = query.getResultList();

        PrePlanpagos auxPlanpagos = new PrePlanpagos();
        auxPlanpagos.setCuoFecvencuo(results.get(0)[0] != null ? (Date) results.get(0)[0] : null);
        auxPlanpagos.setCuoNumcuo(results.get(0)[1] != null ? Integer.parseInt(results.get(0)[1].toString()) : null);
        auxPlanpagos.setCuoNumtrx(results.get(0)[2] != null ? Integer.parseInt(results.get(0)[2].toString()) : null);
        auxPlanpagos.setCuoInteres(
                results.get(0)[3] != null ? new BigDecimal(results.get(0)[3].toString()) : BigDecimal.ZERO);
        auxPlanpagos.setCuoDesemb(
                results.get(0)[4] != null ? new BigDecimal(results.get(0)[4].toString()) : BigDecimal.ZERO);
        auxPlanpagos.setCuoCapital(
                results.get(0)[5] != null ? new BigDecimal(results.get(0)[5].toString()) : BigDecimal.ZERO);
        auxPlanpagos.setCuoValor(
                results.get(0)[6] != null ? new BigDecimal(results.get(0)[6].toString()) : BigDecimal.ZERO);
        return auxPlanpagos;
    }

    public PrePrcconta buscarPorFechaDeven(Integer prcCodcred, Integer prcCodmod, Date prcFecha2) {
        if (prcFecha2 == null || prcCodcred == null) {
            return null;
        }

        String jpql = "SELECT t FROM PrePrcconta t WHERE t.prcCodcred = :prcCodcred "
                + "and t.prcCodmod = :prcCodmod " +
                "and t.prcFecha2 = :prcFecha2 " +
                "and t.prcCodcmp = 3 " +
                "AND t.prcEstado in (1,2,3) ";

        Query query = entityManager.createQuery(jpql);
        query.setParameter("prcCodcred", prcCodcred);
        query.setParameter("prcCodmod", prcCodmod);
        query.setParameter("prcFecha2", prcFecha2);

        List lista = query.getResultList();
        if (lista.size() > 0) {
            return (PrePrcconta) lista.get(0);
        }

        return null;
    }

    public List<PrePrcconta> devengadosContByCred(Integer prcCodcred, Integer prcCodmod) {
        StringBuilder jpql = new StringBuilder();
        jpql.append("SELECT t FROM PrePrcconta t WHERE t.prcCodcred = :prcCodcred ");
        jpql.append("and t.prcCodmod = :prcCodmod  ");
        jpql.append("and t.prcCodcmp = 3  ");
        jpql.append("AND t.prcEstado in (1,2,3)  ");
        jpql.append("order by t.prcFecha2 desc ");        

        Query query = entityManager.createQuery(jpql.toString());
        query.setParameter("prcCodcred", prcCodcred);
        query.setParameter("prcCodmod", prcCodmod);

        List lista = query.getResultList();
        return lista;
    }

    public List<PrePrcconta> devsGenerados(Integer prcCodcred, Integer prcCodmod, Integer estado, Date fechaDev) {

        StringBuilder jpql = new StringBuilder();
        jpql.append("SELECT t FROM PrePrcconta t ");
        jpql.append("WHERE t.prcCodcred = :prcCodcred ");        
        jpql.append("and t.prcCodmod = :prcCodmod  ");
        jpql.append("and t.prcCodcmp = 3  ");
        jpql.append("AND t.prcNroComprob is not null ");        
        jpql.append("AND t.prcCveTipoComprob is not null ");                
        jpql.append("AND t.prcNroCentro > 0 ");
        jpql.append("AND t.prcFecha is not null ");

        // consulta por fecha de devengamiento
        if (estado == 1 && fechaDev != null) {
            jpql.append("AND t.prcFecha2 = :fechaDev ");
            jpql.append("AND t.prcEstado in (1,2,3)  ");
        } else {
            jpql.append("AND t.prcEstado in (1,2,3)  ");
        }
        // pendientes para contabilizar        
        if (estado == 2 && fechaDev != null) {
            jpql.append("AND t.prcFecha = :fechaCont ");
        }

        jpql.append("order by t.prcFecha2  ");        

        Query query = entityManager.createQuery(jpql.toString());
        query.setParameter("prcCodcred", prcCodcred);
        query.setParameter("prcCodmod", prcCodmod);

        if (estado == 1 && fechaDev != null) {
            query.setParameter("fechaDev", fechaDev);
        }
        if (estado == 2 && fechaDev != null) {
            query.setParameter("fechaCont", fechaDev);
        }

        List<PrePrcconta> lista = query.getResultList();
        List<PrePrcconta> listResult = lista.stream().filter(p -> {
            if (p.getPrcNroComprob() == null || p.getPrcNroComprob().trim().length() == 0) {
                return false;
            }
            
            return true;
        }).collect(Collectors.toList());

        return listResult;
    }

    public void cambiarEstadoOperComprob(Integer tipocmp, Integer idtabla, Integer codcred, Integer codmod, Integer coddsb, Date fecha,
            Integer estado, String usuario, String estacion){

        String nativeQuery = "call d_creditos.p_set_estado_proceso_conta(:tipocmp, :idtabla, :codcred, :codmod, :coddsb, :fecha, :estado, :usuario, :estacion)";
        try {
            log.info("En cambiarEstadoOperComprob cambio de estado p_set_estado_proceso_conta nvoestado: " + estado+ " idtabla: {} tipooper: {}", idtabla, tipocmp);

            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("tipocmp", tipocmp);            
            query.setParameter("idtabla", idtabla);
            query.setParameter("codcred", codcred);
            query.setParameter("codmod", codmod);
            query.setParameter("coddsb", coddsb);            
            query.setParameter("fecha", fecha);
            query.setParameter("estado", estado);
            query.setParameter("usuario", usuario);
            query.setParameter("estacion", estacion);
            query.executeUpdate();

            log.info("Cambio de estado hecho... cred: {} nuevo estado {}", idtabla, tipocmp);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
                if (cause instanceof SQLException) {
                    count++;
                    sb.append(cause.getMessage());
                    sb.append(" , ");
                }
            }
            String consent = (count > 0 ? sb.toString().replace(", null ,", "")
                    : "Error :" + e.getMessage().replace(", null ,", ""));
            throw new RuntimeException("Error p_set_estado_proceso_conta: " + consent, e);
        }
    }

}
