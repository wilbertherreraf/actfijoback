/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.NormativaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Normativa;

import javax.ejb.Local;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Normativa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface NormativaQLLocal extends
    GenericQLLocal<Normativa, Integer>
{

}
