package gob.bcb.jee.creditos.entidades.pojo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by eborda on 01/12/2016.
 */
public class GrupoEpne implements Serializable {
    private String nombreEpne;
    private Integer idEmpresa;

    private List<EpneDetalle> epnes;

    public GrupoEpne() {
        this.epnes = new ArrayList<EpneDetalle>();
    }

    public GrupoEpne(String nombreEpne, Integer idEmpresa) {
        this.nombreEpne = nombreEpne;
        this.idEmpresa = idEmpresa;
        epnes = new ArrayList<EpneDetalle>();
    }

    public String getNombreEpne() {
        return nombreEpne;
    }

    public void setNombreEpne(String nombreEpne) {
        this.nombreEpne = nombreEpne;
    }

    public Integer getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Integer idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public List<EpneDetalle> getEpnes() {
        return epnes;
    }

    public void setEpnes(List<EpneDetalle> epnes) {
        this.epnes = epnes;
    }

}
