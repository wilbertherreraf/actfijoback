package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the pre_cargospre database table.
 * 
 */
@Embeddable
public class PreCargosprePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ctr_codcred", insertable=false, updatable=false)
	private Integer ctrCodcred;

	@Column(name="ctr_codmod", insertable=false, updatable=false)
	private Integer ctrCodmod;

	@Column(name="ctr_codcarg")
	private Integer ctrCodcarg;

	@Column(name="ctr_codtrx", insertable=false, updatable=false)
	private Integer ctrCodtrx;

	public PreCargosprePK() {
	}
	public Integer getCtrCodcred() {
		return this.ctrCodcred;
	}
	public void setCtrCodcred(Integer ctrCodcred) {
		this.ctrCodcred = ctrCodcred;
	}
	public Integer getCtrCodmod() {
		return this.ctrCodmod;
	}
	public void setCtrCodmod(Integer ctrCodmod) {
		this.ctrCodmod = ctrCodmod;
	}
	public Integer getCtrCodcarg() {
		return this.ctrCodcarg;
	}
	public void setCtrCodcarg(Integer ctrCodcarg) {
		this.ctrCodcarg = ctrCodcarg;
	}
	public Integer getCtrCodtrx() {
		return this.ctrCodtrx;
	}
	public void setCtrCodtrx(Integer ctrCodtrx) {
		this.ctrCodtrx = ctrCodtrx;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PreCargosprePK)) {
			return false;
		}
		PreCargosprePK castOther = (PreCargosprePK)other;
		return 
			(this.ctrCodcred == castOther.ctrCodcred)
			&& (this.ctrCodmod == castOther.ctrCodmod)
			&& (this.ctrCodcarg == castOther.ctrCodcarg)
			&& (this.ctrCodtrx == castOther.ctrCodtrx);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.ctrCodcred;
		hash = hash * prime + this.ctrCodmod;
		hash = hash * prime + this.ctrCodcarg;
		hash = hash * prime + this.ctrCodtrx;
		
		return hash;
	}
}
