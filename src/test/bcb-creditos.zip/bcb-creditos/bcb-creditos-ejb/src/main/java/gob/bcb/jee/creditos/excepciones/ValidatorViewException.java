package gob.bcb.jee.creditos.excepciones;

/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.mse.excepciones.ValidatorViewException
 * 19/01/2016 - 18:18:02
 * Creado por vluque
 */

/**
 * Clase para el manejo de las excepciones de la vista
 * 
 * 
 * @author vluque
 * 
 */
public class ValidatorViewException extends OperationException
{

  private static final long serialVersionUID = 1L;

  private String clientObjectId;

  /**
   * @return the clientObjectId
   */
  public String getClientObjectId()
  {
    return clientObjectId;
  }

  public ValidatorViewException(String mensaje)
  {
    super(mensaje);
    this.clientObjectId = "";
  }

  public ValidatorViewException(String mensaje, String clientObjectId)
  {
    super(mensaje);
    this.clientObjectId = clientObjectId;
  }

  public ValidatorViewException(String mensaje, Throwable e,
      String clientObjectId)
  {
    super(mensaje, e);
    this.clientObjectId = clientObjectId;
  }

}
