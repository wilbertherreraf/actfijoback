package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the gen_parmtasa database table.
 * 
 */
@Entity
@Table(name="gen_parmtasa")
@NamedQuery(name="GenParmtasa.findAll", query="SELECT g FROM GenParmtasa g")
public class GenParmtasa implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private GenParmtasaPK id;

	@Column(name="tas_auditfho")
	private Timestamp tasAuditfho;

	@Column(name="tas_audittrx")
	private String tasAudittrx;

	@Column(name="tas_auditusr")
	private String tasAuditusr;

	@Column(name="tas_auditwst")
	private String tasAuditwst;

	@Column(name="tas_caat")
	private String tasCaat;

	@Column(name="tas_caej")
	private String tasCaej;

	@Column(name="tas_cave")
	private String tasCave;

	@Column(name="tas_cavi")
	private String tasCavi;

	@Column(name="tas_cicg")
	private String tasCicg;

	@Column(name="tas_ciej")
	private String tasCiej;

	@Column(name="tas_civ2")
	private String tasCiv2;

	@Column(name="tas_civg")
	private String tasCivg;

	@Column(name="tas_civn")
	private String tasCivn;

	@Column(name="tas_ckaa")
	private String tasCkaa;

	@Column(name="tas_ckad")
	private String tasCkad;

	@Column(name="tas_ckca")
	private String tasCkca;

	@Column(name="tas_ckej")
	private String tasCkej;

	@Column(name="tas_ckm1")
	private String tasCkm1;

	@Column(name="tas_ckm2")
	private String tasCkm2;

	@Column(name="tas_ckvc")
	private String tasCkvc;

	@Column(name="tas_ckvl")
	private String tasCkvl;

	@Column(name="tas_codcargi")
	private Integer tasCodcargi;

	@Column(name="tas_codcargk")
	private Integer tasCodcargk;

	@Column(name="tas_cpas")
	private String tasCpas;

	@Column(name="tas_cpcg")
	private String tasCpcg;

	@Column(name="tas_cpej")
	private String tasCpej;

	@Column(name="tas_cpv2")
	private String tasCpv2;

	@Column(name="tas_cpvg")
	private String tasCpvg;

	@Column(name="tas_cpvn")
	private String tasCpvn;

	@Column(name="tas_krec")
	private String tasKrec;

	@Column(name="tas_orec")
	private String tasOrec;

	@Column(name="tas_saej")
	private String tasSaej;

	@Column(name="tas_sav2")
	private String tasSav2;

	@Column(name="tas_savg")
	private String tasSavg;

	@Column(name="tas_savn")
	private String tasSavn;

	@Column(name="tas_sdej")
	private String tasSdej;

	@Column(name="tas_sdv2")
	private String tasSdv2;

	@Column(name="tas_sdvg")
	private String tasSdvg;

	@Column(name="tas_sdvn")
	private String tasSdvn;

	@Column(name="tas_tabtrxstaau")
	private Integer tasTabtrxstaau;

	@Column(name="tas_tbas")
	private Double tasTbas;

	@Column(name="tas_trxstaau")
	private Integer tasTrxstaau;

	@Column(name="tas_tvto")
	private Double tasTvto;

	public GenParmtasa() {
	}

	public GenParmtasaPK getId() {
		return this.id;
	}

	public void setId(GenParmtasaPK id) {
		this.id = id;
	}

	public Timestamp getTasAuditfho() {
		return this.tasAuditfho;
	}

	public void setTasAuditfho(Timestamp tasAuditfho) {
		this.tasAuditfho = tasAuditfho;
	}

	public String getTasAudittrx() {
		return this.tasAudittrx;
	}

	public void setTasAudittrx(String tasAudittrx) {
		this.tasAudittrx = tasAudittrx;
	}

	public String getTasAuditusr() {
		return this.tasAuditusr;
	}

	public void setTasAuditusr(String tasAuditusr) {
		this.tasAuditusr = tasAuditusr;
	}

	public String getTasAuditwst() {
		return this.tasAuditwst;
	}

	public void setTasAuditwst(String tasAuditwst) {
		this.tasAuditwst = tasAuditwst;
	}

	public String getTasCaat() {
		return this.tasCaat;
	}

	public void setTasCaat(String tasCaat) {
		this.tasCaat = tasCaat;
	}

	public String getTasCaej() {
		return this.tasCaej;
	}

	public void setTasCaej(String tasCaej) {
		this.tasCaej = tasCaej;
	}

	public String getTasCave() {
		return this.tasCave;
	}

	public void setTasCave(String tasCave) {
		this.tasCave = tasCave;
	}

	public String getTasCavi() {
		return this.tasCavi;
	}

	public void setTasCavi(String tasCavi) {
		this.tasCavi = tasCavi;
	}

	public String getTasCicg() {
		return this.tasCicg;
	}

	public void setTasCicg(String tasCicg) {
		this.tasCicg = tasCicg;
	}

	public String getTasCiej() {
		return this.tasCiej;
	}

	public void setTasCiej(String tasCiej) {
		this.tasCiej = tasCiej;
	}

	public String getTasCiv2() {
		return this.tasCiv2;
	}

	public void setTasCiv2(String tasCiv2) {
		this.tasCiv2 = tasCiv2;
	}

	public String getTasCivg() {
		return this.tasCivg;
	}

	public void setTasCivg(String tasCivg) {
		this.tasCivg = tasCivg;
	}

	public String getTasCivn() {
		return this.tasCivn;
	}

	public void setTasCivn(String tasCivn) {
		this.tasCivn = tasCivn;
	}

	public String getTasCkaa() {
		return this.tasCkaa;
	}

	public void setTasCkaa(String tasCkaa) {
		this.tasCkaa = tasCkaa;
	}

	public String getTasCkad() {
		return this.tasCkad;
	}

	public void setTasCkad(String tasCkad) {
		this.tasCkad = tasCkad;
	}

	public String getTasCkca() {
		return this.tasCkca;
	}

	public void setTasCkca(String tasCkca) {
		this.tasCkca = tasCkca;
	}

	public String getTasCkej() {
		return this.tasCkej;
	}

	public void setTasCkej(String tasCkej) {
		this.tasCkej = tasCkej;
	}

	public String getTasCkm1() {
		return this.tasCkm1;
	}

	public void setTasCkm1(String tasCkm1) {
		this.tasCkm1 = tasCkm1;
	}

	public String getTasCkm2() {
		return this.tasCkm2;
	}

	public void setTasCkm2(String tasCkm2) {
		this.tasCkm2 = tasCkm2;
	}

	public String getTasCkvc() {
		return this.tasCkvc;
	}

	public void setTasCkvc(String tasCkvc) {
		this.tasCkvc = tasCkvc;
	}

	public String getTasCkvl() {
		return this.tasCkvl;
	}

	public void setTasCkvl(String tasCkvl) {
		this.tasCkvl = tasCkvl;
	}

	public Integer getTasCodcargi() {
		return this.tasCodcargi;
	}

	public void setTasCodcargi(Integer tasCodcargi) {
		this.tasCodcargi = tasCodcargi;
	}

	public Integer getTasCodcargk() {
		return this.tasCodcargk;
	}

	public void setTasCodcargk(Integer tasCodcargk) {
		this.tasCodcargk = tasCodcargk;
	}

	public String getTasCpas() {
		return this.tasCpas;
	}

	public void setTasCpas(String tasCpas) {
		this.tasCpas = tasCpas;
	}

	public String getTasCpcg() {
		return this.tasCpcg;
	}

	public void setTasCpcg(String tasCpcg) {
		this.tasCpcg = tasCpcg;
	}

	public String getTasCpej() {
		return this.tasCpej;
	}

	public void setTasCpej(String tasCpej) {
		this.tasCpej = tasCpej;
	}

	public String getTasCpv2() {
		return this.tasCpv2;
	}

	public void setTasCpv2(String tasCpv2) {
		this.tasCpv2 = tasCpv2;
	}

	public String getTasCpvg() {
		return this.tasCpvg;
	}

	public void setTasCpvg(String tasCpvg) {
		this.tasCpvg = tasCpvg;
	}

	public String getTasCpvn() {
		return this.tasCpvn;
	}

	public void setTasCpvn(String tasCpvn) {
		this.tasCpvn = tasCpvn;
	}

	public String getTasKrec() {
		return this.tasKrec;
	}

	public void setTasKrec(String tasKrec) {
		this.tasKrec = tasKrec;
	}

	public String getTasOrec() {
		return this.tasOrec;
	}

	public void setTasOrec(String tasOrec) {
		this.tasOrec = tasOrec;
	}

	public String getTasSaej() {
		return this.tasSaej;
	}

	public void setTasSaej(String tasSaej) {
		this.tasSaej = tasSaej;
	}

	public String getTasSav2() {
		return this.tasSav2;
	}

	public void setTasSav2(String tasSav2) {
		this.tasSav2 = tasSav2;
	}

	public String getTasSavg() {
		return this.tasSavg;
	}

	public void setTasSavg(String tasSavg) {
		this.tasSavg = tasSavg;
	}

	public String getTasSavn() {
		return this.tasSavn;
	}

	public void setTasSavn(String tasSavn) {
		this.tasSavn = tasSavn;
	}

	public String getTasSdej() {
		return this.tasSdej;
	}

	public void setTasSdej(String tasSdej) {
		this.tasSdej = tasSdej;
	}

	public String getTasSdv2() {
		return this.tasSdv2;
	}

	public void setTasSdv2(String tasSdv2) {
		this.tasSdv2 = tasSdv2;
	}

	public String getTasSdvg() {
		return this.tasSdvg;
	}

	public void setTasSdvg(String tasSdvg) {
		this.tasSdvg = tasSdvg;
	}

	public String getTasSdvn() {
		return this.tasSdvn;
	}

	public void setTasSdvn(String tasSdvn) {
		this.tasSdvn = tasSdvn;
	}

	public Integer getTasTabtrxstaau() {
		return this.tasTabtrxstaau;
	}

	public void setTasTabtrxstaau(Integer tasTabtrxstaau) {
		this.tasTabtrxstaau = tasTabtrxstaau;
	}

	public Double getTasTbas() {
		return this.tasTbas;
	}

	public void setTasTbas(Double tasTbas) {
		this.tasTbas = tasTbas;
	}

	public Integer getTasTrxstaau() {
		return this.tasTrxstaau;
	}

	public void setTasTrxstaau(Integer tasTrxstaau) {
		this.tasTrxstaau = tasTrxstaau;
	}

	public Double getTasTvto() {
		return this.tasTvto;
	}

	public void setTasTvto(Double tasTvto) {
		this.tasTvto = tasTvto;
	}

}
