/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import gob.bcb.jee.creditos.entidades.EstadoDesembolsosQuery;
import gob.bcb.jee.creditos.entidades.VPVPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.VPVPlanPagosDsbQuery;
import gob.bcb.jee.creditos.entidades.VPlanPagosConsolQuery;
import gob.bcb.jee.creditos.entidades.VPlanPagosDsbQuery;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.pojo.PlanPagoDto;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PrePlanpagosQLLocalImpl extends
		GenericQLLocalImpl<PrePlanpagos, Integer> implements
		PrePlanpagosQLLocal {

	private static final Logger log = LoggerFactory.getLogger(PrePlanpagosQLLocalImpl.class);
	@PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
	private EntityManager entityManager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
	 * ()
	 */
	@Override
	protected EntityManager entityManager() {
		return entityManager;
	}

	public List<VPlanPagosConsolQuery> planConsolPorCodmodYCodcred(Integer codcred, Integer codmod) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT v ");
		sb.append("FROM VPlanPagosConsolQuery v ");
		sb.append("WHERE v.codmod = :codmod ");
		sb.append("AND v.codcred = :codcred ");
		sb.append("order by v.fechavencuo ");

		TypedQuery<VPlanPagosConsolQuery> query = entityManager.createQuery(sb.toString(), VPlanPagosConsolQuery.class);
		query.setParameter("codmod", codmod);
		query.setParameter("codcred", codcred);
		return query.getResultList();
	}

	public List<VPVPlanPagosConsolQuery> planVPConsolPorCodmodYCodcred(Integer codcred, Integer codmod) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT v ");
		sb.append("FROM VPVPlanPagosConsolQuery v ");
		sb.append("WHERE v.codmod = :codmod ");
		sb.append("AND v.codcred = :codcred ");
		sb.append("order by v.fechavencuo ");
		TypedQuery<VPVPlanPagosConsolQuery> query = entityManager.createQuery(sb.toString(),
				VPVPlanPagosConsolQuery.class);
		query.setParameter("codmod", codmod);
		query.setParameter("codcred", codcred);
		return query.getResultList();
	}

	public List<VPlanPagosConsolQuery> cuotasVencPendOSgtes(Integer codcred, Integer codmod, Date fechaActual) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT v FROM VPlanPagosConsolQuery v ");
		sb.append("WHERE v.codmod = :codmod ");
		sb.append("AND v.codcred = :codcred ");
		sb.append("and v.fechavencuo <= :fecha ");

		TypedQuery<VPlanPagosConsolQuery> query = entityManager.createQuery(sb.toString(), VPlanPagosConsolQuery.class);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);
		query.setParameter("fecha", fechaActual, TemporalType.DATE);

		return query.getResultList();
	}

	public List<VPlanPagosConsolQuery> cuotasVencPendOSgtes(Date fechaIni, Date fechaActual) {

		StringBuilder sb = new StringBuilder();
		sb.append("SELECT v FROM VPlanPagosConsolQuery v ");
		sb.append("WHERE v.fechavencuo >= :fechaIni ");
		sb.append("and v.fechavencuo <= :fecha ");
		sb.append("order by fechavencuo ");

		TypedQuery<VPlanPagosConsolQuery> query = entityManager.createQuery(sb.toString(), VPlanPagosConsolQuery.class);
		query.setParameter("fechaIni", fechaIni, TemporalType.DATE);
		query.setParameter("fecha", fechaActual, TemporalType.DATE);

		return query.getResultList();
	}

	public List<VPlanPagosDsbQuery> planDsbPorCodmodYCodcred(Integer codcred, Integer codmod, Integer coddsb) {
		TypedQuery<VPlanPagosDsbQuery> query = entityManager.createQuery(
				"SELECT v FROM VPlanPagosDsbQuery v WHERE v.codmod = :codmod AND v.codcred = :codcred and v.coddsb = :coddsb order by v.fechavencuo",
				VPlanPagosDsbQuery.class);
		query.setParameter("codmod", codmod);
		query.setParameter("codcred", codcred);
		query.setParameter("coddsb", coddsb);
		return query.getResultList();
	}

	public List<VPlanPagosDsbQuery> planDsbPorCodmodYCodcredPV(Integer codcred, Integer codmod, Integer coddsb) {
		if (codcred == null || codmod == null) {
			return new ArrayList<>();
		}
		String nativeQuery = "select * ";
		nativeQuery += "from v_pv_planpagos_dsb ";
		nativeQuery += "where codcred = :codcred ";
		nativeQuery += "and codmod = :codmod ";
		nativeQuery += "and coddsb = :coddsb ";
		nativeQuery += "order by fechavencuo  ";

		Query query = entityManager.createNativeQuery(nativeQuery, VPlanPagosDsbQuery.class);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);
		query.setParameter("coddsb", coddsb);
		// query.setParameter("tipotrx", tipotrx);

		List list = query.getResultList();
		return list;

	}

	public List<VPVPlanPagosDsbQuery> planVPDsbPorCodmodYCodcred(Integer codcred, Integer codmod, Integer coddsb) {
		TypedQuery<VPVPlanPagosDsbQuery> query = entityManager.createQuery(
				"SELECT v FROM VPVPlanPagosDsbQuery v WHERE v.codmod = :codmod AND v.codcred = :codcred and v.coddsb = :coddsb order by v.fechavencuo",
				VPVPlanPagosDsbQuery.class);
		query.setParameter("codmod", codmod);
		query.setParameter("codcred", codcred);
		query.setParameter("coddsb", coddsb);
		return query.getResultList();
	}

	public List<VPlanPagosDsbQuery> cuotasVencPendOSgtesDsb(Integer codcred, Integer codmod, Integer coddsb,
			Date fechaActual) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT v FROM VPlanPagosDsbQuery v ");
		sb.append("WHERE v.codmod = :codmod ");
		sb.append("AND v.codcred = :codcred ");
		sb.append("AND v.coddsb = :coddsb ");
		sb.append("and v.fechavencuo <= :fecha ");

		TypedQuery<VPlanPagosDsbQuery> query = entityManager.createQuery(sb.toString(), VPlanPagosDsbQuery.class);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);
		query.setParameter("fecha", fechaActual, TemporalType.DATE);

		return query.getResultList();
	}

	public List<VPlanPagosConsolQuery> planpagosPPOPV(Integer codcred, Integer codmod) {
		if (codcred == null || codmod == null) {
			return new ArrayList<>();
		}
		String nativeQuery = "select * ";
		nativeQuery += "from v_pv_planpagos_consol ";
		nativeQuery += "where codcred = :codcred ";
		nativeQuery += "and codmod = :codmod ";
		nativeQuery += "order by fechavencuo ";

		Query query = entityManager.createNativeQuery(nativeQuery, VPlanPagosConsolQuery.class);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);

		List list = query.getResultList();
		return list;

	}

	public List<VPVPlanPagosDsbQuery> planpagosPPOPVAFecha(Integer codcred, Integer codmod, Date fecha,
			Integer tipotrx) {
		if (codcred == null || codmod == null) {
			return new ArrayList<>();
		}
		String nativeQuery = "select * ";
		nativeQuery += "from v_pv_planpagos_dsb ";
		nativeQuery += "where codcred = :codcred ";
		nativeQuery += "and codmod = :codmod ";
		nativeQuery += "and fechavencuo = :fechavencuo ";
		nativeQuery += "and tipotrx = :tipotrx ";
		nativeQuery += "order by fechavencuo,coddsb  ";

		Query query = entityManager.createNativeQuery(nativeQuery, VPVPlanPagosDsbQuery.class);
		query.setParameter("codcred", codcred);
		query.setParameter("codmod", codmod);
		query.setParameter("fechavencuo", fecha, TemporalType.DATE);
		query.setParameter("tipotrx", tipotrx);

		List list = query.getResultList();
		return list;

	}

	@Override
	public Integer getCantidad(Integer coddsb) throws OperationException {
		String nativeQuery = "select count(1) from pre_planpagos where  cuo_coddsb=:valor1";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", coddsb);
		Object valor = query.getSingleResult();
		int id = 0;
		if (valor != null) {
			id = Integer.parseInt(valor.toString());
		}
		return id;
	}

	@Override
	public Integer getCantidadPreAutorizado(Integer coddsb) throws OperationException {
		String nativeQuery = "select count(1) from pre_planpagos where  cuo_coddsb=:valor1  ";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", coddsb);
		Object valor = query.getSingleResult();
		int id = 0;
		if (valor != null) {
			id = Integer.parseInt(valor.toString());
		}
		return id;
	}

	@Override
	public void actualizarPlanDePagos0(Integer codcred, Integer codmod) throws OperationException {
		String nativeQuery = "call d_creditos.p_pp_dsb_cero_acttodo(:valor1, :valor2)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);
		query.executeUpdate();
	}

	@Override
	public void realizarCobro(Integer codcred, Integer codmod, Date fechaVen, Date fechaAct, Integer accion,
			String usuario, String estacion) throws OperationException, SQLException {
		Log.Info("GEnerar operacion p_generar_operacion " + codcred + " accion " + accion);
		String nativeQuery = "call p_generar_operacion(:codcred, :codmod,:valor3,:fechaVen,:fechaAct,:accion,:usuario,:estacion)";
		try {
			Query query = entityManager.createNativeQuery(nativeQuery);
			query.setParameter("codcred", codcred);
			query.setParameter("codmod", codmod);
			query.setParameter("valor3", null);
			query.setParameter("fechaVen", fechaVen);
			query.setParameter("fechaAct", fechaAct);
			query.setParameter("accion", accion);
			query.setParameter("usuario", usuario);
			query.setParameter("estacion", estacion);
			query.executeUpdate();
		} catch (Exception e) {
			Log.Error("Exception: " + e.getMessage());
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			String consent = (count > 0 ? sb.toString().replace(", null ,", "")
					: "Error :" + e.getMessage().replace(", null ,", ""));
			throw new RuntimeException("Error p_generar_operacion: " + consent, e);
		}
	}

	@Override
	public void quitarCuota(Integer codcred, Integer codmod, Integer coddsb, Date fechaCuo, String usuario,
			String estacion) throws OperationException {
		String nativeQuery = "call d_creditos.p_pp_elim_cuota(:valor1, :valor2,:valor3,:valor4,:valor5,:valor6)";
		Log.Info("p_pp_elim_cuota " + codcred + " coddsb " + coddsb);
		try {
			Query query = entityManager.createNativeQuery(nativeQuery);
			query.setParameter("valor1", codcred);
			query.setParameter("valor2", codmod);
			query.setParameter("valor3", coddsb);
			query.setParameter("valor4", fechaCuo);
			query.setParameter("valor5", usuario);
			query.setParameter("valor6", estacion);
			query.executeUpdate();
		} catch (Exception e) {
			Log.Error("Exception: " + e.getMessage());
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			String consent = (count > 0 ? sb.toString().replace(", null ,", "")
					: "Error :" + e.getMessage().replace(", null ,", ""));
			throw new RuntimeException("Error p_pp_elim_cuota: " + consent, e);
		}
	}

	@Override
	public List<Object[]> mostrarPlanDePagos(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {
		String nativeQuery = "select fechavencuo fecha, saldo_inicio, amortizacion, amortizacion_saldo ,interes , interes_saldo,dias,tasa,cuota, estado_cuota estado "
				+ "from v_planpagos_dsb "
				+ "where codmod=:valor3 "
				+ "and codcred=:valor1 "
				+ "and coddsb=:valor2 ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", coddsb);
		query.setParameter("valor3", codmod);
		List<Object[]> valor = query.getResultList();
		if (valor == null) {
			return new ArrayList<>();
		}
		return valor;

	}

	@Override
	public List<Object[]> mostrarPlanDePagosGeneral(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {
		String nativeQuery = "select fechavencuo fecha, saldo_inicio, amortizacion, amortizacion_saldo ,interes , interes_saldo,dias,tasa,cuota, estado_cuota estado,tipotrx "
				+ "from v_planpagos_consol "
				+ "where codmod=:valor2 "
				+ "and codcred=:valor1 ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);
		// query.setParameter("valor3", coddsb);
		List<Object[]> valor = query.getResultList();
		if (valor == null) {
			return new ArrayList<>();
		}

		return valor;
	}

	@Override
	public List<Object[]> mostrarPlanDePagosDetalleEstados(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {
		String nativeQuery = "select fecvencuo f, tabtipotrx ,tipotrx ,tipotran , tabestado ,estd ,estadodesc ,monto "
				+ "from v_detalle_servdeuda "
				+ "where codmod=:valor2 "
				+ "and codcred=:valor1 "
				+ "and coddsb=:valor3 ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);
		query.setParameter("valor3", coddsb);
		List<Object[]> valor = query.getResultList();
		if (valor == null) {
			return new ArrayList<>();
		}
		return valor;
	}

	@Override
	public void actualizarConsolidado(Integer codcred, Integer codmod, Integer codmodtmp) throws OperationException {
		String nativeQuery = "call d_creditos.f_rpo_planpagos_consol(:valor1, :valor2,:valor3)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);
		query.setParameter("valor3", codmodtmp);
		query.getResultList();
	}

	@Override
	public void actualizarDesembolso(Integer codcred, Integer codmod, Integer codmodtmp, Integer coddsb)
			throws OperationException {
		String nativeQuery = "call d_creditos.f_rpo_planpagos_dsb(:valor1, :valor2,:valor3,:valor4)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);
		query.setParameter("valor3", codmodtmp);
		query.setParameter("valor4", coddsb);
		query.getResultList();
	}

	@Override
	public List<Object[]> getTotalBonoValorGarantia(Integer codcred, Integer codmod, Integer coddsb)
			throws OperationException {
		String nativeQuery = "select count(1) total_bonos,  sum(cuota) valor_garantia "
				+ "from v_planpagos_dsb "
				+ "where codmod=:valor3 "
				+ "and codcred=:valor1 "
				+ "and coddsb=:valor2 ";

		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", coddsb);
		query.setParameter("valor3", codmod);
		List<Object[]> valor = query.getResultList();
		if (valor == null) {
			return new ArrayList<>();
		}
		return valor;

	}

	@Override
	public List<PlanPagoDto> recuperarPlanDePagosPorGestionSinCancelar(Integer codcred, Integer codmod, Integer coddsb,
			Integer pGestion) throws OperationException {
		List<PlanPagoDto> resultado = new ArrayList<>();
		PlanPagoDto planPagoDto = new PlanPagoDto();
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

		String nativeQuery = "select fechavencuo fecha, saldo_inicio, amortizacion, amortizacion_saldo ,interes , interes_saldo,dias,tasa,cuota, estado_cuota estado "
				+ "from v_planpagos_dsb "
				+ "where codmod=:valor3 "
				+ "and codcred=:valor1 "
				+ "and coddsb=:valor2 "
				+ "and year (fechavencuo) = :pGestion " +
				"and estado_cuota = 'SIN CANCELAR'";
		List resultList = null;

		resultList = entityManager.createNativeQuery(nativeQuery)
				.setParameter("valor1", codcred)
				.setParameter("valor2", coddsb)
				.setParameter("valor3", codmod)
				.setParameter("pGestion", pGestion)
				.getResultList();
		for (Integer i = 0; i < resultList.size(); i++) {
			Object[] object = (Object[]) resultList.get(i);
			planPagoDto = new PlanPagoDto();
			planPagoDto.setFechaVencimientoCuota(object[0] != null ? sdf.format(object[0]) : null);
			planPagoDto.setSaldoInicio(object[1] != null ? new BigDecimal(object[1].toString()) : null);
			planPagoDto.setAmortizacion(object[2] != null ? new BigDecimal(object[2].toString()) : null);
			planPagoDto.setAmortizacionSaldo(object[3] != null ? new BigDecimal(object[3].toString()) : null);
			planPagoDto.setInteres(object[4] != null ? new BigDecimal(object[4].toString()) : null);
			planPagoDto.setInteresSaldo(object[5] != null ? new BigDecimal(object[5].toString()) : null);
			planPagoDto.setDias(object[6] != null ? Integer.valueOf(object[6].toString()) : null);
			planPagoDto.setTasa(object[7] != null ? new BigDecimal(object[7].toString()) : null);
			planPagoDto.setCuota(object[8] != null ? new BigDecimal(object[8].toString()) : null);
			planPagoDto.setEstadoCuota(object[9] != null ? object[9].toString() : null);

			resultado.add(planPagoDto);
		}

		return resultado;
	}

	@Override
	public PlanPagoDto recuperarPlanDePagoPorParametros(Integer codcred, Integer codmod, Integer coddsb,
			Date cuoFecvencuo) throws OperationException {
		PlanPagoDto planPagoDto = new PlanPagoDto();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		try {
			String nativeQuery = "select fechavencuo fecha, saldo_inicio, amortizacion, amortizacion_saldo ,interes , interes_saldo,dias,tasa,cuota, estado_cuota estado "
					+
					"from v_planpagos_dsb " +
					"where codmod=:codmod " +
					"and codcred=:codcred " +
					"and coddsb=:coddsb " +
					"and fechavencuo = :fechavencuo ";
			Object result = entityManager.createNativeQuery(nativeQuery)
					.setParameter("codcred", codcred)
					.setParameter("coddsb", coddsb)
					.setParameter("codmod", codmod)
					.setParameter("fechavencuo", cuoFecvencuo)
					.getSingleResult();

			if (result != null) {
				Object[] object = (Object[]) result;
				planPagoDto = new PlanPagoDto();
				planPagoDto.setFechaVencimientoCuota(object[0] != null ? sdf.format(object[0]) : null);
				planPagoDto.setSaldoInicio(object[1] != null ? new BigDecimal(object[1].toString()) : null);
				planPagoDto.setAmortizacion(object[2] != null ? new BigDecimal(object[2].toString()) : null);
				planPagoDto.setAmortizacionSaldo(object[3] != null ? new BigDecimal(object[3].toString()) : null);
				planPagoDto.setInteres(object[4] != null ? new BigDecimal(object[4].toString()) : null);
				planPagoDto.setInteresSaldo(object[5] != null ? new BigDecimal(object[5].toString()) : null);
				planPagoDto.setDias(object[6] != null ? Integer.valueOf(object[6].toString()) : null);
				planPagoDto.setTasa(object[7] != null ? new BigDecimal(object[7].toString()) : null);
				planPagoDto.setCuota(object[8] != null ? new BigDecimal(object[8].toString()) : null);
				planPagoDto.setEstadoCuota(object[9] != null ? object[9].toString() : null);
			}

		} catch (Exception e) {
			String error = "NO se pudo recuperar el plan de pagos para los parametros ingresado.";
			throw new OperationException(error);
		}

		return planPagoDto;
	}

	public static VPlanPagosDsbQuery sumarConStreams(List<VPlanPagosDsbQuery> lista) {
		if (lista == null || lista.isEmpty()) {
			return initVPPDsb();
		}

		VPlanPagosDsbQuery resultado = new VPlanPagosDsbQuery();

		// Sumarizar valores BigDecimal usando streams
		resultado.setAmortizacion(summarizeBigDecimal(lista, VPlanPagosDsbQuery::getAmortizacion));
		resultado.setAmortizacionSaldo(summarizeBigDecimal(lista, VPlanPagosDsbQuery::getAmortizacionSaldo));
		resultado.setInteres(summarizeBigDecimal(lista, VPlanPagosDsbQuery::getInteres));
		resultado.setInteresSaldo(summarizeBigDecimal(lista, VPlanPagosDsbQuery::getInteresSaldo));
		resultado.setInteresDev(summarizeBigDecimal(lista, VPlanPagosDsbQuery::getInteresDev));
		resultado.setCuota(summarizeBigDecimal(lista, VPlanPagosDsbQuery::getCuota));
		resultado.setInteresIni(summarizeBigDecimal(lista, VPlanPagosDsbQuery::getInteresIni));

		return resultado;
	}

	public static VPlanPagosDsbQuery initVPPDsb() {
		VPlanPagosDsbQuery resultado = new VPlanPagosDsbQuery();

		// Inicializar BigDecimal a 0 para evitar NullPointerException
		resultado.setAmortizacion(BigDecimal.ZERO);
		resultado.setAmortizacionSaldo(BigDecimal.ZERO);
		resultado.setInteres(BigDecimal.ZERO);
		resultado.setInteresSaldo(BigDecimal.ZERO);
		resultado.setInteresDev(BigDecimal.ZERO);
		resultado.setInteresIni(BigDecimal.ZERO);
		resultado.setSaldoInicio(BigDecimal.ZERO);
		resultado.setCuota(BigDecimal.ZERO);
		resultado.setTasa(BigDecimal.ZERO);

		return resultado;
	}

	public static BigDecimal summarizeBigDecimal(List<VPlanPagosDsbQuery> lista,
			Function<VPlanPagosDsbQuery, BigDecimal> extractor) {
		return lista.stream()
				.map(extractor)
				.filter(Objects::nonNull)
				.reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	public static VPVPlanPagosDsbQuery sumarConStreamsPvDsb(List<VPVPlanPagosDsbQuery> lista) {
		if (lista == null || lista.isEmpty()) {
			return initVPPPDsb();
		}

		VPVPlanPagosDsbQuery resultado = initVPPPDsb();

		// Sumarizar valores BigDecimal usando streams
		resultado.setAmortizacion(summarizeBigDecimalPvDsb(lista, VPVPlanPagosDsbQuery::getAmortizacion));
		resultado.setAmortizacionSaldo(summarizeBigDecimalPvDsb(lista, VPVPlanPagosDsbQuery::getAmortizacionSaldo));
		resultado.setInteres(summarizeBigDecimalPvDsb(lista, VPVPlanPagosDsbQuery::getInteres));
		resultado.setInteresSaldo(summarizeBigDecimalPvDsb(lista, VPVPlanPagosDsbQuery::getInteresSaldo));
		resultado.setInteresDev(summarizeBigDecimalPvDsb(lista, VPVPlanPagosDsbQuery::getInteresDev));
		resultado.setCuota(summarizeBigDecimalPvDsb(lista, VPVPlanPagosDsbQuery::getCuota));
		resultado.setInteresIni(summarizeBigDecimalPvDsb(lista, VPVPlanPagosDsbQuery::getInteresIni));

		return resultado;
	}

	public static VPVPlanPagosDsbQuery initVPPPDsb() {
		VPVPlanPagosDsbQuery resultado = new VPVPlanPagosDsbQuery();

		// Inicializar BigDecimal a 0 para evitar NullPointerException
		resultado.setAmortizacion(BigDecimal.ZERO);
		resultado.setAmortizacionSaldo(BigDecimal.ZERO);
		resultado.setInteres(BigDecimal.ZERO);
		resultado.setInteresSaldo(BigDecimal.ZERO);
		resultado.setInteresDev(BigDecimal.ZERO);
		resultado.setInteresIni(BigDecimal.ZERO);
		resultado.setSaldoInicio(BigDecimal.ZERO);
		resultado.setCuota(BigDecimal.ZERO);
		resultado.setTasa(BigDecimal.ZERO);

		return resultado;
	}

	public static BigDecimal summarizeBigDecimalPvDsb(List<VPVPlanPagosDsbQuery> lista,
			Function<VPVPlanPagosDsbQuery, BigDecimal> extractor) {
		return lista.stream()
				.map(extractor)
				.filter(Objects::nonNull)
				.reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	public static VPlanPagosConsolQuery sumarConStreamsPpConsol(List<VPlanPagosConsolQuery> lista) {
		if (lista == null || lista.isEmpty()) {
			return initPPConsol();
		}

		VPlanPagosConsolQuery resultado = initPPConsol();

		resultado.setAmortizacion(summarizeBigDecimalPp(lista, VPlanPagosConsolQuery::getAmortizacion));
		resultado.setAmortizacionSaldo(summarizeBigDecimalPp(lista, VPlanPagosConsolQuery::getAmortizacionSaldo));
		resultado.setInteres(summarizeBigDecimalPp(lista, VPlanPagosConsolQuery::getInteres));
		resultado.setInteresSaldo(summarizeBigDecimalPp(lista, VPlanPagosConsolQuery::getInteresSaldo));
		resultado.setInteresDev(summarizeBigDecimalPp(lista, VPlanPagosConsolQuery::getInteresDev));
		resultado.setCuota(summarizeBigDecimalPp(lista, VPlanPagosConsolQuery::getCuota));
		resultado.setInteresIni(summarizeBigDecimalPp(lista, VPlanPagosConsolQuery::getInteresIni));

		return resultado;
	}

	public static VPlanPagosConsolQuery initPPConsol() {
		VPlanPagosConsolQuery resultado = new VPlanPagosConsolQuery();

		// Inicializar BigDecimal a 0 para evitar NullPointerException
		resultado.setAmortizacion(BigDecimal.ZERO);
		resultado.setAmortizacionSaldo(BigDecimal.ZERO);
		resultado.setInteres(BigDecimal.ZERO);
		resultado.setInteresSaldo(BigDecimal.ZERO);
		resultado.setInteresDev(BigDecimal.ZERO);
		resultado.setInteresIni(BigDecimal.ZERO);
		resultado.setSaldoInicio(BigDecimal.ZERO);
		resultado.setCuota(BigDecimal.ZERO);
		resultado.setTasa(BigDecimal.ZERO);

		return resultado;
	}

	public static BigDecimal summarizeBigDecimalPp(List<VPlanPagosConsolQuery> lista,
			Function<VPlanPagosConsolQuery, BigDecimal> extractor) {
		return lista.stream()
				.map(extractor)
				.filter(Objects::nonNull)
				.reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	/*
	 * call p_mf_amort_genplan(55, 17, null,12, null,
	 * "2024-06-10", "2028-09-06", "2026-09-06", 4.26, 13,
	 * 20, 0, "usr", "sta")
	 */
	public void generarCalendario(Integer codcred, Integer codmod, Integer tipotrx, Integer codrepro,
			Date fCorterepro, Date fechaPrimAmort, Date fechaPrimAmortint, BigDecimal tasa, Integer unidplaz,
			Integer nroamortInt, String usuario, String estacion) {
		String nativeQuery = "call d_creditos.p_mf_amort_genplan(:codcred, :codmod,:tipotrx, :codrepro, :fCorterepro, :fechaPrimAmort, :fechaPrimAmortint, :tasa, :unidplaz, :nroamortInt, :usuario, :estacion)";
		try {
			log.info("En p_mf_amort_genplan " + ", " +codcred + ", " +codmod + ", " +tipotrx + ", " +codrepro + ", " +fCorterepro + ", " +fechaPrimAmort + ", " +fechaPrimAmortint + ", " +tasa + ", " +unidplaz + ", " +nroamortInt + ", " +usuario  + ", " + estacion);
			Query query = entityManager.createNativeQuery(nativeQuery);
			query.setParameter("codcred", codcred);
			query.setParameter("codmod", codmod);
			query.setParameter("tipotrx", tipotrx);
			query.setParameter("codrepro", codrepro);
			query.setParameter("fCorterepro", fCorterepro);
			query.setParameter("fechaPrimAmort", fechaPrimAmort);
			query.setParameter("fechaPrimAmortint", fechaPrimAmortint);
			query.setParameter("tasa", tasa);
			query.setParameter("unidplaz", unidplaz);
			query.setParameter("nroamortInt", nroamortInt);
			query.setParameter("usuario", usuario);
			query.setParameter("estacion", estacion);
			query.executeUpdate();

		} catch (Exception e) {
			Log.Error("Exception: " + e.getMessage());
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			String consent = (count > 0 ? sb.toString().replace(", null ,", "")
					: "Error :" + e.getMessage().replace(", null ,", ""));
			throw new RuntimeException("Error p_mf_amort_genplan: " + consent, e);
		}
	}

}
