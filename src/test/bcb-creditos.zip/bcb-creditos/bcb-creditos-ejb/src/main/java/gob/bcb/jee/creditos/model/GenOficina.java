package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the gen_oficina database table.
 * 
 */
@Entity
@Table(name="gen_oficina")
@NamedQuery(name="GenOficina.findAll", query="SELECT g FROM GenOficina g")
public class GenOficina implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private GenOficinaPK id;

	@Column(name="ofi_direccion1")
	private String ofiDireccion1;

	@Column(name="ofi_nombre")
	private String ofiNombre;

	public GenOficina() {
	}

	public GenOficinaPK getId() {
		return this.id;
	}

	public void setId(GenOficinaPK id) {
		this.id = id;
	}

	public String getOfiDireccion1() {
		return this.ofiDireccion1;
	}

	public void setOfiDireccion1(String ofiDireccion1) {
		this.ofiDireccion1 = ofiDireccion1;
	}

	public String getOfiNombre() {
		return this.ofiNombre;
	}

	public void setOfiNombre(String ofiNombre) {
		this.ofiNombre = ofiNombre;
	}

}
