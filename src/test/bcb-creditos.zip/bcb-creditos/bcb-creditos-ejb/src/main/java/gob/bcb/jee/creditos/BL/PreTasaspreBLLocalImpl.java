/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import com.google.common.base.Strings;

import gob.bcb.jee.creditos.QL.CliPersonaQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.ParametrosQLLocal;
import gob.bcb.jee.creditos.QL.PreReprogramaQLLocal;
import gob.bcb.jee.creditos.QL.PreTasaspreQLLocal;
import gob.bcb.jee.creditos.QL.SacClavesQLLocal;
import gob.bcb.jee.creditos.dao.CliPersonaDao;
import gob.bcb.jee.creditos.dao.GenericDao;

import gob.bcb.jee.creditos.dao.PreReprogramaDao;
import gob.bcb.jee.creditos.dao.PreTasaspreDao;
import gob.bcb.jee.creditos.dao.SacClavesDao;
import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.model.PreTasaspre;
import gob.bcb.jee.creditos.model.PreTasasprePK;
import gob.bcb.jee.creditos.model.SacClaves;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.UtilFormat;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class PreTasaspreBLLocalImpl extends
        GenericBLLocalImpl<PreTasaspre, PreTasasprePK>
        implements PreTasaspreBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    PreTasaspreQLLocal parametrosQLLocal;

    @Inject
    PreTasaspreDao parametroDao;

    @Override
    public GenericQLLocal<PreTasaspre, PreTasasprePK> getQLBean() {
        return parametrosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<PreTasaspre, PreTasasprePK> getGenericDao() {
        return parametroDao;
    }

	@Override
	public void validar(PreTasaspre entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public double obtenerTasaVigente(Integer codcred,Integer codmod, Date fecha) throws OperationException{
		return parametrosQLLocal.obtenerTasaVigente(codcred, codmod, fecha);
	}
	@Override
	public PreTasaspre obtenerUltimaTasa(Integer codcred,Integer codmod) throws OperationException{
		return parametrosQLLocal.obtenerUltimaTasa(codcred, codmod);
	}
	
	@Override
	public void update(Integer codcred,Integer codmod, Date fecha, Date newFecha, double tasa,Integer base ) throws OperationException{
		parametrosQLLocal.update( codcred, codmod,  fecha,  newFecha,  tasa,  base );
	}
}
