package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreGarantiad;

import javax.ejb.Local;

/**
 * Interface para el negocio del a entidad PreGarantiad
 * @author hpanique
 */
@Local
public interface PreGarantiadBLLocal extends
        GenericBLLocal<PreGarantiad, Integer>
{
    public Integer getIdNewId()throws OperationException;
    public PreGarantiad GetByDsb(Integer Valor1, Integer Valor2, Integer Valor3);
}


