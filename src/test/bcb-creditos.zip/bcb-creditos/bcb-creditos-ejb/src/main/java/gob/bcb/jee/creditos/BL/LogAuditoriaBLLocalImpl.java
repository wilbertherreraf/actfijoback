/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.BL.FeriadoBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.LogAuditoriaQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.LogAuditoriaDao;
import gob.bcb.jee.creditos.entidades.LogAuditoria;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.numeradores.TipoParametro;
import gob.bcb.jee.creditos.numeradores.TipoTransaccion;
import gob.bcb.jee.creditos.util.Cttes;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Date;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad
 * LogAuditoriaBLLocalImpl
 * 
 * 
 * @author ysalinas
 * 
 */
@Stateless
@LocalBean
public class LogAuditoriaBLLocalImpl extends
    GenericBLLocalImpl<LogAuditoria, Long>
    implements LogAuditoriaBLLocal
{
  private static Logger log = Logger.getLogger(LogAuditoriaBLLocalImpl.class);

  @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
  EntityManager em;
  /*
   * Inyeccion de los metodos para consulta (QL)
   */
  @Inject
  LogAuditoriaQLLocal logAuditoriaQLLocal;

  @Inject
  LogAuditoriaDao logAuditoriaDao;

  @Override
  public GenericQLLocal<LogAuditoria, Long> getQLBean()
  {
    return logAuditoriaQLLocal;
  }

  /*
   * (non-Javadoc)
   * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
   */
  @Override
  public GenericDao<LogAuditoria, Long> getGenericDao()
  {
    return logAuditoriaDao;
  }

  /*
   * (non-Javadoc)
   * @see
   * gob.bcb.jee.creditos.BL.LogAuditoriaBLLocal#registrarLog(gob.bcb.jee.creditos
   * .numeradores.TipoParametro, gob.bcb.jee.creditos.numeradores.TipoAccion)
   */
  @Override
  public void registrarLog(TipoParametro tipoParametro,
      TipoTransaccion tipoAccion)
      throws OperationException
  {
    LogAuditoria logAuditoria = new LogAuditoria();

    logAuditoria.setFechaHora(new Date());

  }

  /*
   * (non-Javadoc)
   * @see
   * gob.bcb.jee.creditos.BL.GenericBLLocalImpl#validar(gob.bcb.jee.creditos
   * .entidades.Entidad)
   */
  @Override
  public void validar(LogAuditoria entity) throws OperationException
  {
    // TODO: Agregar l³gica de validaci³n

  }

}
