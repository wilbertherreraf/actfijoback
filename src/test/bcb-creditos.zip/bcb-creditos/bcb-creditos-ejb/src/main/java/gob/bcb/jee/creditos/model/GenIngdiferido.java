package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the gen_ingdiferido database table.
 * 
 */
@Entity
@Table(name="gen_ingdiferido")
@NamedQuery(name="GenIngdiferido.findAll", query="SELECT g FROM GenIngdiferido g")
public class GenIngdiferido implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private GenIngdiferidoPK id;

	@Column(name="idf_auditfho")
	private Timestamp idfAuditfho;

	@Column(name="idf_audittrx")
	private String idfAudittrx;

	@Column(name="idf_auditusr")
	private String idfAuditusr;

	@Column(name="idf_auditwst")
	private String idfAuditwst;

	@Column(name="idf_cantdias")
	private Integer idfCantdias;

	@Column(name="idf_ctaingdifing")
	private String idfCtaingdifing;

	@Column(name="idf_ctaingdifpas")
	private String idfCtaingdifpas;

	@Column(name="idf_tabtrxstaau")
	private Integer idfTabtrxstaau;

	@Column(name="idf_trxstaau")
	private Integer idfTrxstaau;

	@Column(name="idf_viacob")
	private Integer idfViacob;

	public GenIngdiferido() {
	}

	public GenIngdiferidoPK getId() {
		return this.id;
	}

	public void setId(GenIngdiferidoPK id) {
		this.id = id;
	}

	public Timestamp getIdfAuditfho() {
		return this.idfAuditfho;
	}

	public void setIdfAuditfho(Timestamp idfAuditfho) {
		this.idfAuditfho = idfAuditfho;
	}

	public String getIdfAudittrx() {
		return this.idfAudittrx;
	}

	public void setIdfAudittrx(String idfAudittrx) {
		this.idfAudittrx = idfAudittrx;
	}

	public String getIdfAuditusr() {
		return this.idfAuditusr;
	}

	public void setIdfAuditusr(String idfAuditusr) {
		this.idfAuditusr = idfAuditusr;
	}

	public String getIdfAuditwst() {
		return this.idfAuditwst;
	}

	public void setIdfAuditwst(String idfAuditwst) {
		this.idfAuditwst = idfAuditwst;
	}

	public Integer getIdfCantdias() {
		return this.idfCantdias;
	}

	public void setIdfCantdias(Integer idfCantdias) {
		this.idfCantdias = idfCantdias;
	}

	public String getIdfCtaingdifing() {
		return this.idfCtaingdifing;
	}

	public void setIdfCtaingdifing(String idfCtaingdifing) {
		this.idfCtaingdifing = idfCtaingdifing;
	}

	public String getIdfCtaingdifpas() {
		return this.idfCtaingdifpas;
	}

	public void setIdfCtaingdifpas(String idfCtaingdifpas) {
		this.idfCtaingdifpas = idfCtaingdifpas;
	}

	public Integer getIdfTabtrxstaau() {
		return this.idfTabtrxstaau;
	}

	public void setIdfTabtrxstaau(Integer idfTabtrxstaau) {
		this.idfTabtrxstaau = idfTabtrxstaau;
	}

	public Integer getIdfTrxstaau() {
		return this.idfTrxstaau;
	}

	public void setIdfTrxstaau(Integer idfTrxstaau) {
		this.idfTrxstaau = idfTrxstaau;
	}

	public Integer getIdfViacob() {
		return this.idfViacob;
	}

	public void setIdfViacob(Integer idfViacob) {
		this.idfViacob = idfViacob;
	}

}
