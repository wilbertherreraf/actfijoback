/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.GenMonedaQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.dao.GenMonedaDao;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class GenMonedaBLLocalImpl extends
        GenericBLLocalImpl<GenMoneda, Integer>
        implements GenMonedaBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    GenMonedaQLLocal parametrosQLLocal;

    @Inject
    GenMonedaDao parametroDao;

    @Override
    public GenericQLLocal<GenMoneda, Integer> getQLBean() {
        return parametrosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<GenMoneda, Integer> getGenericDao() {
        return parametroDao;
    }

    public Integer getIdNewId() throws OperationException{
    	return parametrosQLLocal.getIdNewId();
    }
    
	@Override
	public void validar(GenMoneda entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}

}
