/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.QL.OfertaNegocioQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.LogAuditoria;

import javax.ejb.Local;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Oferta
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface LogAuditoriaQLLocal extends
        GenericQLLocal<LogAuditoria, Long>
{

}
