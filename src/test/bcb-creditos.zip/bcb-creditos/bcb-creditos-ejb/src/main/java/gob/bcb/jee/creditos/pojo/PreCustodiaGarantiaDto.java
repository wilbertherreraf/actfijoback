package gob.bcb.jee.creditos.pojo;

import gob.bcb.jee.creditos.model.PreCustodiaGarantia;
import gob.bcb.jee.creditos.model.PreDesemb;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * PreCustodiaGarantiaDto
 *
 * @author mcramos
 * 26/02/2025
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PreCustodiaGarantiaDto implements Serializable {
    PreDesemb desembolso;
    PreCustodiaGarantia custodiaGarantia;
}
