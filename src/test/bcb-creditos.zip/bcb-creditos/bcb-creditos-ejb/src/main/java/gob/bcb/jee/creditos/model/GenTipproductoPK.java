package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class GenTipproductoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="tpd_codmod", insertable=false, updatable=false)
	private Integer tpdCodmod;

	@Column(name="tpd_codprod")
	private Integer tpdCodprod;

	public GenTipproductoPK() {
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof GenTipproductoPK)) {
			return false;
		}
		GenTipproductoPK castOther = (GenTipproductoPK)other;
		return 
			(this.tpdCodmod == castOther.tpdCodmod)
			&& (this.tpdCodprod == castOther.tpdCodprod);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.tpdCodmod;
		hash = hash * prime + this.tpdCodprod;
		
		return hash;
	}
}
