/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.numeradores.Estado
 * 21/01/2016 - 16:42:26
 * Creado por vluque
 */
package gob.bcb.jee.creditos.numeradores;

/**
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 * 
 * 
 * @author vluque
 * 
 */
public enum Estado
{
  P("Pendiente"),
  M("Modificado"),
  A("Autorizado"),
  S("Suspendido"),
  C("Rechazado"),
  E("Eliminado");

  private String valor;

  private Estado(String valor)
  {
    this.valor = valor;
  }

  @Override
  public String toString()
  {
    return valor;
  }

}
