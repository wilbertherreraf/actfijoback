package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the pre_notas database table.
 * 
 */
@Embeddable
public class PreNotasPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="npr_codcred", insertable=false, updatable=false)
	private Integer nprCodcred;

	@Column(name="npr_codmod", insertable=false, updatable=false)
	private Integer nprCodmod;

	@Temporal(TemporalType.DATE)
	@Column(name="npr_fecnota")
	private java.util.Date nprFecnota;

	@Column(name="npr_sec")
	private Integer nprSec;

	public PreNotasPK() {
	}
	public Integer getNprCodcred() {
		return this.nprCodcred;
	}
	public void setNprCodcred(Integer nprCodcred) {
		this.nprCodcred = nprCodcred;
	}
	public Integer getNprCodmod() {
		return this.nprCodmod;
	}
	public void setNprCodmod(Integer nprCodmod) {
		this.nprCodmod = nprCodmod;
	}
	public java.util.Date getNprFecnota() {
		return this.nprFecnota;
	}
	public void setNprFecnota(java.util.Date nprFecnota) {
		this.nprFecnota = nprFecnota;
	}
	public Integer getNprSec() {
		return this.nprSec;
	}
	public void setNprSec(Integer nprSec) {
		this.nprSec = nprSec;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PreNotasPK)) {
			return false;
		}
		PreNotasPK castOther = (PreNotasPK)other;
		return 
			(this.nprCodcred == castOther.nprCodcred)
			&& (this.nprCodmod == castOther.nprCodmod)
			&& this.nprFecnota.equals(castOther.nprFecnota)
			&& (this.nprSec == castOther.nprSec);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.nprCodcred;
		hash = hash * prime + this.nprCodmod;
		hash = hash * prime + this.nprFecnota.hashCode();
		hash = hash * prime + this.nprSec;
		
		return hash;
	}
}
