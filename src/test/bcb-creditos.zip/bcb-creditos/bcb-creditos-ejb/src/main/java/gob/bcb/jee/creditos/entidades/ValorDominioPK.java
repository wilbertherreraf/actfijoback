/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.entidades.ValorDominioPK
 * 30/03/2016 - 10:35:22
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

/**
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 * 
 * 
 * @author ysalinas
 * 
 */
@Getter
@Setter
@Embeddable
public class ValorDominioPK implements Serializable
{
  
  @NotNull
  @Column(name = "cod_dominio")
  private String codDominio;
  
  @NotNull
  @Column(name = "cod_dato")
  private String codDato;

  public ValorDominioPK()
  {
    super();
  }

  @Override
  public String toString()
  {
    return "ValorDominioPK [codClave=" + codDominio + ", codDato=" + codDato + "]";
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = prime * result
        + ((codDominio == null) ? 0 : codDominio.hashCode());
    result = prime * result + ((codDato == null) ? 0 : codDato.hashCode());
    return result;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ValorDominioPK other = (ValorDominioPK) obj;
    if (codDominio == null)
    {
      if (other.codDominio != null)
        return false;
    }
    else if (!codDominio.equals(other.codDominio))
      return false;
    if (codDato == null)
    {
      if (other.codDato != null)
        return false;
    }
    else if (!codDato.equals(other.codDato))
      return false;
    return true;
  }

  /**
   * @param codDominio
   * @param codDato
   */
  public ValorDominioPK(String codDominio)
  {
    super();
    this.codDominio = codDominio;
  }

}
