package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the pre_planpagos database table.
 * 
 */
@Embeddable
public class PrePlanpagosPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cuo_codcred", insertable=false, updatable=false)
	private Integer cuoCodcred;

	@Column(name="cuo_codmod", insertable=false, updatable=false)
	private Integer cuoCodmod;

	@Column(name="cuo_numcuo")
	private Integer cuoNumcuo;

	@Temporal(TemporalType.DATE)
	@Column(name="cuo_fecvencuo")
	private java.util.Date cuoFecvencuo;

	public PrePlanpagosPK() {
	}
	public Integer getCuoCodcred() {
		return this.cuoCodcred;
	}
	public void setCuoCodcred(Integer cuoCodcred) {
		this.cuoCodcred = cuoCodcred;
	}
	public Integer getCuoCodmod() {
		return this.cuoCodmod;
	}
	public void setCuoCodmod(Integer cuoCodmod) {
		this.cuoCodmod = cuoCodmod;
	}
	public Integer getCuoNumcuo() {
		return this.cuoNumcuo;
	}
	public void setCuoNumcuo(Integer cuoNumcuo) {
		this.cuoNumcuo = cuoNumcuo;
	}
	public java.util.Date getCuoFecvencuo() {
		return this.cuoFecvencuo;
	}
	public void setCuoFecvencuo(java.util.Date cuoFecvencuo) {
		this.cuoFecvencuo = cuoFecvencuo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PrePlanpagosPK)) {
			return false;
		}
		PrePlanpagosPK castOther = (PrePlanpagosPK)other;
		return 
			(this.cuoCodcred == castOther.cuoCodcred)
			&& (this.cuoCodmod == castOther.cuoCodmod)
			&& (this.cuoNumcuo == castOther.cuoNumcuo)
			&& this.cuoFecvencuo.equals(castOther.cuoFecvencuo);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.cuoCodcred;
		hash = hash * prime + this.cuoCodmod;
		hash = hash * prime + this.cuoNumcuo;
		hash = hash * prime + this.cuoFecvencuo.hashCode();
		
		return hash;
	}
}
