package gob.bcb.jee.creditos.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Months;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.util
 * 29/08/2016 - 07:11 PM
 * Creado por aescobar
 */
public class UtilDate {

    public final static Integer LANG_ESP = 0;
    public final static Integer LANG_ENG = 1;

    public static Date dateAddMonth(Date fecha, Integer numMeses) {
        if (fecha == null)
            return null;
        DateTime resFecha = new DateTime(fecha.getTime()).plusMonths(numMeses);
        return new Date(resFecha.getMillis());

    }

    public static int getNumeroDias(Date fechaInicial, Date fechaFinal) {
        if (fechaFinal == null && fechaInicial == null)
            return -1;
        if (fechaFinal == null || fechaInicial == null)
            return 0;
        DateTime dtInicial = new DateTime(fechaInicial.getTime());
        DateTime dtFinal = new DateTime(fechaFinal.getTime());
        return Days.daysBetween(dtInicial, dtFinal).getDays();
    }

    public static int getNumeroMeses(Date fechaInicial, Date fechaFinal) {
        if (fechaFinal == null && fechaInicial == null)
            return -1;
        if (fechaFinal == null || fechaInicial == null)
            return 0;
        DateTime dtInicial = new DateTime(fechaInicial.getTime());
        DateTime dtFinal = new DateTime(fechaFinal.getTime());
        return Months.monthsBetween(dtInicial, dtFinal).getMonths();
    }


    /**
     * Método que retorna el nombre del mes actual del sistema
     *
     * @param p_idioma Entero que determina el idioma en que se retornara la respuesta (0 -> español, 1-> ingles)
     * @return Nombre del mes actual en el idioma determinado en el parametro
     */
    public static String getNombreMes(Integer p_idioma, Date pFecha) throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.setTime(pFecha);
        int month = cal.get(Calendar.MONTH);
        String[][] mesNombre = {{"Enero", "January"}, {"Febrero", "Febrary"}, {"Marzo", "March"}, {"Abril", "April"}, {"Mayo", "May"}, {"Junio", "June"}, {"Julio", "July"}, {"Agosto", "August"}, {"Septiembre", "September"}, {"Octubre", "October"}, {"Noviembre", "November"}, {"Diciembre", "December"},};          /** se verifica que el parametro idioma sea valido **/
        if (p_idioma > 1)
            throw new Exception("Error al intentar obtener el nombre del mes con el código de idioma " + p_idioma);
        /** se calcula el mes del sistema */
        String mes = mesNombre[month][p_idioma];          /** se retorna el nombre del mes **/
        return mes;
    }

    /**
     * Método que retorna el nombre abreviado del mes
     *
     * @param p_idioma Entero que determina el idioma en que se retornara la respuesta (0 -> español, 1-> ingles)
     * @return Nombre del mes actual en el idioma determinado en el parametro
     */
    public static String getNombreMesAbreviado(Integer p_idioma, Date pFecha) throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.setTime(pFecha);
        int month = cal.get(Calendar.MONTH);
        String[][] mesNombre = {{"Ene", "Jan"}, {"Feb", "Feb"}, {"Mar", "Mar"}, {"Abr", "Apr"}, {"May", "May"}, {"Jun", "Jun"}, {"Jul", "Jul"}, {"Ago", "Aug"}, {"Sep", "Sep"}, {"Oct", "Oct"}, {"Nov", "Nov"}, {"Dic", "Dec"},};          /** se verifica que el parametro idioma sea valido **/
        if (p_idioma > 1)
            throw new Exception("Error al intentar obtener el nombre del mes con el código de idioma " + p_idioma);
        /** se calcula el mes del sistema */
        String mes = mesNombre[month][p_idioma];          /** se retorna el nombre del mes **/
        return mes;
    }

    /**
     * Método que retorna el nombre del dia actual del sistema
     *
     * @param p_idioma Entero que determina el idioma en que se retornara la respuesta (0 -> español, 1-> ingles)
     * @return Nombre del dia actual en el idioma determinado en el parametro
     */
    public static String getNombreDia(Integer p_idioma, Date pFecha) throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.setTime(pFecha);
        int diaSemana = cal.get(Calendar.DAY_OF_WEEK);
        String[][] diaNombre = {{"Lunes", "Monday"}, {"Martes", "Tuesday"}, {"Miercoles", "Wednesday"}, {"Jueves", "Thursday"}, {"Viernes", "Friday"}, {"Sabado", "Saturday"}, {"Domingo", "Sunday"},};          /** se verifica que el parametro idioma sea valido **/
        if (p_idioma > 1)
            throw new Exception("Error al intentar obtener el nombre del mes con el código de idioma " + p_idioma);
        /** se calcula el mes del sistema */
        String mes = diaNombre[diaSemana][p_idioma];          /** se retorna el nombre del mes **/
        return mes;
    }


    /**
     * Metodo que permite obtener una fecha en formato literal para el idioma espanol
     *
     * @param fecha
     * @return
     */
    public static String dateToLiteralSpanishString(Date fecha) {
        try {
            DateTime fechaSeleccionada = new DateTime(fecha.getTime());
            String mes = getNombreMes(0, fecha);
            return fechaSeleccionada.getDayOfMonth() + " de " + mes + " de " + fechaSeleccionada.getYear();
        } catch (Exception e) {
            SimpleDateFormat formateador = new SimpleDateFormat(
                    "dd 'de' MMMM 'de' yyyy", new Locale("es_ES"));
            String fechaLiteral = formateador.format(fecha);
            return fechaLiteral;
        }
    }

    public static Integer getDayOfMonth(Date fecha) {
        if(fecha == null)
            return  null;
        else
            return new DateTime(fecha.getTime()).getDayOfMonth();
    }

    public static Integer getYear(Date fecha) {
        if(fecha == null)
            return  null;
        else
            return new DateTime(fecha.getTime()).getYear();
    }

    public static Integer getMonthOfYear(Date fecha) {
        if(fecha == null)
            return  null;
        else
            return new DateTime(fecha.getTime()).getMonthOfYear();
    }
/**
	 * Agrega o resta dias, meses ... a una fecha determinada
	 * 
	 * @param fecha
	 *            fecha base a calcular
	 * @param cantidadTiempo
	 *            cantidad de tiempo
	 * @param tipoTiempo
	 *            unidad de tiempo, 5 Dias, 2 meses, 1 AÃƒÂ±o, 11 hora, 12
	 *            minuto, 13 segundo
	 * @return
	 */
	public static Date addTime(Date fecha, int cantidadTiempo, int unidTiempo) {
		if (fecha == null) {
			return null;
		}
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(fecha);

		if (unidTiempo == Calendar.YEAR || unidTiempo == Calendar.MONTH || unidTiempo == Calendar.DAY_OF_MONTH) {
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
		}
		calendar.add(unidTiempo, cantidadTiempo);

		return calendar.getTime();
	}

}
