package gob.bcb.jee.creditos.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class ArticuloPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name="id_numero_articulo")
	private String idNumeroArticulo;

	@Column(name="id_numero_ley")
	private Integer idNumeroLey;
	
}
