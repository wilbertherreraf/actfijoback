package gob.bcb.jee.creditos.QL;
import gob.bcb.jee.creditos.entidades.Pago;

import javax.ejb.Remote;
/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.QL
 * 02/08/2016 - 11:54 AM
 * Creado por aescobar
 */
@Remote
public interface PagoQLLocal extends
    GenericQLLocal<Pago, Long>
{

}