package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;

import javax.ejb.Local;
import java.util.List;

/**
 * PreDesembolsoDetalleBLLocal
 *
 * @author mcramos
 * 11/02/2025
 */
@Local
public interface PreDesembolsoDetalleBLLocal extends
        GenericBLLocal<PreDesembolsoDetalle, Integer>{
    PreDesembolsoDetalle obtenerPorCodDesembolso(Integer pCodDesembolso);

    public Integer getEstadoDesembolsoDetalle(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    public List<String> getLeyesPrestamo(String leyes) throws OperationException;

}
