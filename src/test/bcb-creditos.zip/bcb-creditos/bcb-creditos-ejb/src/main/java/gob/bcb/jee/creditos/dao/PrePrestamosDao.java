/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.dao.EmpresaDao
 * 29/03/2016 - 11:02:08
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.dao;

import java.io.Serializable;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.model.PrePrestamos;
import gob.bcb.jee.creditos.model.PrePrestamosPK;
import gob.bcb.jee.creditos.util.Cttes;


@Stateless
public class PrePrestamosDao extends GenericDao<PrePrestamos, PrePrestamosPK> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

   

    public PrePrestamosDao() {
    }

    public PrePrestamosDao(Class<PrePrestamos> entityClass) {
        super(entityClass);
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}