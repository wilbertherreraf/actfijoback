package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.TransaccionAuditoria;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.dao
 * 28/06/2016 - 10:44 AM
 * Created por aescobar
 */

@Stateless
public class TransaccionAuditoriaDao extends
        GenericDao<TransaccionAuditoria, String> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public TransaccionAuditoriaDao() {
    }

    public TransaccionAuditoriaDao(Class<TransaccionAuditoria> entityClass) {
        super(entityClass);
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
}