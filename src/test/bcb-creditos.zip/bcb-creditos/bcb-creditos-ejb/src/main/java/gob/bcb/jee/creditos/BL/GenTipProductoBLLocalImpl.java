/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.GenTipProductoQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.dao.GenTipProductoDao;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.GenTipproductoPK;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class GenTipProductoBLLocalImpl extends
        GenericBLLocalImpl<GenTipproducto, GenTipproductoPK>
        implements GenTipProductoBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    GenTipProductoQLLocal parametrosQLLocal;

    @Inject
    GenTipProductoDao parametroDao;

    @Override
    public GenericQLLocal<GenTipproducto, GenTipproductoPK> getQLBean() {
        return parametrosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<GenTipproducto, GenTipproductoPK> getGenericDao() {
        return parametroDao;
    }

	@Override
	public void validar(GenTipproducto entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Integer getIdNewId(Integer codmod) throws OperationException{
		return parametrosQLLocal.getIdNewId(codmod);
	}
}
