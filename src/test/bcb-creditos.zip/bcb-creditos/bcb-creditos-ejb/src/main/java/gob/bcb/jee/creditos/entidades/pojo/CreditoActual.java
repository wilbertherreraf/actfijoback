package gob.bcb.jee.creditos.entidades.pojo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by eborda on 25/10/2016.
 */
public class CreditoActual implements Serializable {
    private Date fechaVencimiento;
    private BigDecimal pagoCapital;
    private BigDecimal pagoInteres;
    private BigDecimal saldo;

    public CreditoActual(Date fechaVencimiento, BigDecimal pagoCapital, BigDecimal pagoInteres) {
        this.fechaVencimiento = fechaVencimiento;
        this.pagoCapital = pagoCapital;
        this.pagoInteres = pagoInteres;
    }

    public Date getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(Date fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public BigDecimal getPagoCapital() {
        return pagoCapital;
    }

    public void setPagoCapital(BigDecimal pagoCapital) {
        this.pagoCapital = pagoCapital;
    }

    public BigDecimal getPagoInteres() {
        return pagoInteres;
    }

    public void setPagoInteres(BigDecimal pagoInteres) {
        this.pagoInteres = pagoInteres;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }
}
