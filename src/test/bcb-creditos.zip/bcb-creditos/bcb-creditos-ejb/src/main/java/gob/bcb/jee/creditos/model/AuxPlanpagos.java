package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the aux_planpagos database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="aux_planpagos")
@NamedQueries({
    @NamedQuery(name = AuxPlanpagos.NQ_LIST_ALL, query = "SELECT a FROM AuxPlanpagos a"),
    @NamedQuery(name = AuxPlanpagos.NQ_GET_BY_ID, query = "SELECT p FROM AuxPlanpagos p where p.acuCodacu=:valor1"),
    @NamedQuery(name = AuxPlanpagos.NQ_GET_BY_DESEM, query = "SELECT p FROM AuxPlanpagos p where p.acuCoddsb=:valor1")
    
})
public class AuxPlanpagos extends EntidadAutorizable<Integer> implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="AuxPlanpagos";
	  public static final String NQ_GET_BY_ID =ENTITY+"GetById";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	  public static final String NQ_GET_BY_DESEM =ENTITY+"GetByDesem";

	@Id
	@Column(name="acu_codacu")
	private Integer acuCodacu;

	@Column(name="acu_codcred")
	private Integer acuCodcred;

	@Column(name="acu_codmod")
	private Integer acuCodmod;
	
	@Column(name="acu_numcuo")
	private Integer acuNumcuo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="acu_fecvencuo")
	private java.util.Date acuFecvencuo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="acu_fecinicuo")
	private java.util.Date acuFecinicuo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="acu_fecfincuo")
	private java.util.Date acuFecfincuo;
	
	@Column(name="acu_capital")
	private BigDecimal acuCapital;
	
	@Column(name="acu_interes")
	private BigDecimal acuInteres;

	@Column(name="acu_cargos")
	private BigDecimal acuCargos;

	@Column(name="acu_valor")
	private BigDecimal acuValor;
	
	@Column(name="acu_valorpend")
	private BigDecimal acuValorpend;

	@Column(name="acu_coddsb")
	private Integer acuCoddsb;
	
	@Column(name="acu_tasa")
	private Double acuTasa;
	
	@Column(name="acu_tabtipocuo")
	private Integer acuTabtipocuo;
	
	@Column(name="acu_tipocuo")
	private Integer acuTipocuo;

	@Column(name="acu_tipoacu")
	private Integer acuTipoacu;

	@Column(name="acu_tabtipodsb")
	private Integer acuTabtipodsb;
	
	@Column(name="acu_tipodsb")
	private Integer acuTipodsb;
	
	@Column(name="acu_auditusr")
	private String preAuditusr;
	
	@Column(name="acu_auditfho")
	private Timestamp preAuditfho;
	


	public AuxPlanpagos() {
	}

	@Override
	public Integer getId() {		
		return acuCodacu;
	}

	@Override
	public void setId(Integer id) {
		this.acuCodacu=id;
		
	}	
}
