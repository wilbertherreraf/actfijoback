package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the pre_planpagos database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="pre_planpagos")
@NamedQueries({
    @NamedQuery(name = PrePlanpagos.NQ_LIST_ALL, query = "SELECT a FROM PrePlanpagos a"),
    @NamedQuery(name = PrePlanpagos.NQ_GET_BY_ID, query = "SELECT p FROM PrePlanpagos p where p.cuoCodcuo=:valor1"),
    @NamedQuery(name = PrePlanpagos.NQ_GET_BY_DESEM, query = "SELECT p FROM PrePlanpagos p where p.cuoCoddsb=:valor1")
    
})
public class PrePlanpagos  extends EntidadAutorizable<Integer>  implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="PrePlanpagos";
	  public static final String NQ_GET_BY_ID =ENTITY+"GetById";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	  public static final String NQ_GET_BY_DESEM =ENTITY+"GetByDesem";
	@Id
	@Column(name="cuo_codcuo")
	private Integer cuoCodcuo;
		
	@Column(name="cuo_codcred" )
	private Integer cuoCodcred;

	@Column(name="cuo_codmod")
	private Integer cuoCodmod;

	@Column(name="cuo_numcuo")
	private Integer cuoNumcuo;

	@Temporal(TemporalType.DATE)
	@Column(name="cuo_fecvencuo")
	private java.util.Date cuoFecvencuo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="cuo_fecinicuo")
	private java.util.Date cuoFecinicuo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="cuo_fecfincuo")
	private java.util.Date cuoFecfincuo;
	
	@Column(name="cuo_capital")
	private BigDecimal cuoCapital;
	
	@Column(name="cuo_interes")
	private BigDecimal cuoInteres;
	
	@Column(name="cuo_cargos")
	private BigDecimal cuoCargos;
	
	@Column(name="cuo_desemb")
	private BigDecimal cuoDesemb;
	
	@Column(name="cuo_valor")
	private BigDecimal cuoValor;
	
	@Column(name="cuo_valorpend")
	private BigDecimal cuoValorpend;
	
	@Column(name="cuo_tabmonpag")
	private Integer cuoTabmonpag;
	
	@Column(name="cuo_monpag")
	private Integer cuoMonpag;
	
	@Column(name="cuo_coddsb")
	private Integer cuoCoddsb;
	
	@Column(name="cuo_numtrx")
	private Integer cuoNumtrx;
	
	@Column(name="cuo_tabtipocuo")
	private Integer cuoTabtipocuo;
	
	@Column(name="cuo_tipocuo")
	private Integer cuoTipocuo;
	
	@Column(name="cuo_tipotrx")
	private Integer cuoTipotrx;

	@Column(name="cuo_tipoacu")
	private Integer cuoTipoacu;


	public PrePlanpagos() {
	}
	
	@Override
	public void setId(Integer id) {
		this.cuoCodcuo=id;
		
	}

	@Override
	public Integer getId() {		
		return this.cuoCodcuo;
	}

}
