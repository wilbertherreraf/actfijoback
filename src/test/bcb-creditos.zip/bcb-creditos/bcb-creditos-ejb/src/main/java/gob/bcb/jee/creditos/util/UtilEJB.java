/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.util.UtilEJB
 * 21/03/2016 - 10:44:24
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import java.io.File;
import java.util.Properties;

/**
 * Created by ysalinas on 21/03/2016. .idea
 */
public class UtilEJB {

    
    public static String urlContext;

    public static void init(String urlContextCadena) {
        urlContext = urlContextCadena + "/";
        Log.Debug("urlEJBContext = " + urlContext);
    }

    public static Object lookup(Class clazz) throws Exception
    {
        try {
        	String variable=getContextPath(clazz) + clazz.getSimpleName()+"!gob.bcb.jee.creditos.BL."+clazz.getSimpleName().replace("Impl", "");
            return new InitialContext().lookup(variable);
        } catch (Exception e) {
            throw new Exception("Error al intentar obtener el path de ejecucion del EJB", e);
        }
    }
    //                            java:global/bcb-creditos/bcb-creditos-ejb-0.0.1/SacClavesBLLocalImpl
    //return (SacClavesBLLocal) c.lookup("ejb:bcb-creditos/bcb-creditos-ejb-0.0.1/SacClavesBLLocalImpl!gob.bcb.jee.creditos.BL.SacClavesBLLocal");
    public static String getContextPath(Class clazz)
    {
        File ejbJar = new File(clazz.getProtectionDomain().getCodeSource().getLocation().getPath());
        String appName = ejbJar.getParentFile().getName().replace(".ear","");
        String moduleName = ejbJar.getName().replace(".jar","");
        String variable="java:global/" + appName + "/" + moduleName + "/";
        Log.Info(variable);
        return variable;
        		
    }
    
//    public static Object lookup(Class clazz, Class interfaze) throws NamingException {
//        log.info("ingresar al lookup");
//        final Hashtable jndiProperties = new Hashtable();
//        Context context = new InitialContext(jndiProperties);
//        return context.lookup(urlContext + clazz.getSimpleName());
//    }
//
//    public static <Ejb> Ejb lookup(Class<Ejb> ejbRemoto) {
//        try {
//            Properties e = new Properties();
//            e.put("jboss.naming.client.ejb.context", Boolean.valueOf(true));
//            e.put("java.naming.factory.url.pkgs", "org.jboss.ejb.client.naming");
//            InitialContext ctx = new InitialContext(e);
//            String appName = "bcb-creditos-ear";
//            String moduleName = "bcb-creditos-ejb-0.0.1";
//            String distinctName = "";
//            String beanName = ejbRemoto.getSimpleName() + "Impl";
//            String remoteBeanName = ejbRemoto.getName();
//            String jndi = "ejb:" + appName + "/" + moduleName  + "/" + beanName + "!" + remoteBeanName;
//            Log.Debug("Ejb Remoto para consumir: " + jndi);
//            Object ejb = ctx.lookup(jndi);
//            return (Ejb) ejb;
//        } catch (Exception var10) {
//        	Log.Error("Error al establecer conexión con los EJB\'s, verifique que la aplicación bcb-axesso-ear esté publicada correctamente" + var10);
//            return null;
//        }
//    }

    public static String getContextPath() throws NamingException, Exception {
        String mname = (String) new InitialContext().lookup("java:module/ModuleName");
        return mname;
    }

}
