/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import gob.bcb.jee.creditos.entidades.EstadoDesembolsosQuery;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreDesemb;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface PreDesembQLLocal extends
        GenericQLLocal<PreDesemb,Integer>
{
	public Integer getNewId()throws OperationException;
	
	public BigDecimal getDisponibleDesembolso(Integer codcred,Integer codmod)throws OperationException;
	public Integer generarPlanDePagosDsb(Integer p_codcred,Integer p_codmod,Integer p_coddsb,Integer p_codmodtmp, String usuario, String ip)throws OperationException ;
	public void autorizarPlanDePagos(Integer p_codcred,Integer p_codmod,Integer p_coddsb,Integer p_codmodtmp, String cod_user, String ip) throws OperationException;
	
	public void aprobarDesembolso(Integer p_codcred,Integer p_codmod,Integer p_coddsb, Date fecha, Date fechaOpera,Integer accion,String cod_user, String estacion)throws OperationException;
	public void eliminarDesembolso(Integer p_coddsb ,String cod_user,String estacion)throws OperationException;

	public Integer obtenerCodClientePorCodDesembolso(Integer pCodDesembolso);

    List<EstadoDesembolsosQuery> estadoDesembolsosAFecha(Integer codcred, Integer codmod, Integer coddsb,
            Date fechaVencimiento);

    PreDesemb getByCoddsb(Integer coddsb);

    BigDecimal devengadoPorCredAFech(Date fechaVencimiento);

    List<PreDesemb> dsbByCodCred(Integer codcred, Integer codmod);
}
