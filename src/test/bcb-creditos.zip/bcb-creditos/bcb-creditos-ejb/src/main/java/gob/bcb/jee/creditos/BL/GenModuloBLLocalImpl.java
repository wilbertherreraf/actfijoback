/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import com.google.common.base.Strings;

import gob.bcb.jee.creditos.QL.CliPersonaQLLocal;
import gob.bcb.jee.creditos.QL.GenModuloQLLocal;
import gob.bcb.jee.creditos.QL.GenMonedaQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.ParametrosQLLocal;
import gob.bcb.jee.creditos.dao.CliPersonaDao;
import gob.bcb.jee.creditos.dao.GenModuloDao;
import gob.bcb.jee.creditos.dao.GenMonedaDao;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenModulo;
import gob.bcb.jee.creditos.model.GenMoneda;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.UtilFormat;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class GenModuloBLLocalImpl extends
        GenericBLLocalImpl<GenModulo, Integer>
        implements GenModuloBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    GenModuloQLLocal parametrosQLLocal;

    @Inject
    GenModuloDao parametroDao;

    @Override
    public GenericQLLocal<GenModulo, Integer> getQLBean() {
        return parametrosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<GenModulo, Integer> getGenericDao() {
        return parametroDao;
    }

	@Override
	public void validar(GenModulo entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}

}
