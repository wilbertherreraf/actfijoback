/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.ValorDominioQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.ValorDominio;
import gob.bcb.jee.creditos.entidades.ValorDominioPK;

import javax.ejb.Local;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad ValorDominio
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface ValorDominioQLLocal extends
        GenericQLLocal<ValorDominio, ValorDominioPK>
{

}
