/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import com.google.common.base.Strings;

import gob.bcb.jee.creditos.QL.AuxPlanpagosQLLocal;
import gob.bcb.jee.creditos.QL.CliPersonaQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.ParametrosQLLocal;
import gob.bcb.jee.creditos.dao.AuxPlanpagosDao;
import gob.bcb.jee.creditos.dao.CliPersonaDao;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.AuxPlanpagos;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.numeradores.Estado;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.UtilFormat;
import org.apache.log4j.Logger;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@LocalBean
public class AuxPlanpagosBLLocalImpl extends
        GenericBLLocalImpl<AuxPlanpagos, Integer>
        implements AuxPlanpagosBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    AuxPlanpagosQLLocal auxPlanpagosQLLocal;

    @Inject
    AuxPlanpagosDao parametroDao;

    @Override
    public GenericQLLocal<AuxPlanpagos, Integer> getQLBean() {
        return auxPlanpagosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<AuxPlanpagos, Integer> getGenericDao() {
        return parametroDao;
    }

	@Override
	public void validar(AuxPlanpagos entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Integer getCantidad(Integer coddsb) throws OperationException{
		return auxPlanpagosQLLocal.getCantidad(coddsb);
	}
	
	@Override
	public Integer getCantidadPreAutorizado(Integer coddsb) throws OperationException{
		return auxPlanpagosQLLocal.getCantidadPreAutorizado(coddsb);
	}
	
	@Override
	public Integer getCantidadNoPreAutorizado(Integer coddsb,Integer codgenerado) throws OperationException{
		return auxPlanpagosQLLocal.getCantidadNoPreAutorizado(coddsb,codgenerado);
	}
	
	@Override
	public void preautorizar(Integer coddsb, String usuario, Timestamp fecha,Integer estado,Integer codseleccionado) throws OperationException{
		auxPlanpagosQLLocal.preautorizar(coddsb,usuario,fecha,estado,codseleccionado);
	}
	
	@Override
	public List<Object[]> mostrarPlanDePagosAux(Integer codcred,Integer coddsb,Integer codMod) throws OperationException{
		return auxPlanpagosQLLocal.mostrarPlanDePagosAux(codcred,coddsb,codMod);
	}
	
	@Override
	public Integer getCantidadAutorizado(Integer coddsb,Integer codgenerado,Integer codaut) throws OperationException{
		return auxPlanpagosQLLocal.getCantidadAutorizado(coddsb,codgenerado,codaut);
	}
	
	@Override
	public List<Object[]> mostrarPlanDePagosDisponibles(Integer codcred,Integer coddsb)throws OperationException {
		return auxPlanpagosQLLocal.mostrarPlanDePagosDisponibles(codcred,coddsb);
	}
	
	public List<Object[]> mostrarPlanDePagosConsolAux(Integer codcred,Integer codMod)throws OperationException{
		return auxPlanpagosQLLocal.mostrarPlanDePagosConsolAux(codcred, codMod);
	}

	@Override
	public void actualizarConsolidadoAux(Integer codcred,Integer codmod,Integer codmodtmp) throws OperationException {
		auxPlanpagosQLLocal.actualizarConsolidadoAux(codcred, codmod, codmodtmp);
	}

	@Override
	public void actualizarDesembolsoAux(Integer codcred,Integer codmod,Integer codmodtmp,Integer coddsb) throws OperationException {
		auxPlanpagosQLLocal.actualizarDesembolsoAux(codcred, codmod, codmodtmp, coddsb);
		
	}

}
