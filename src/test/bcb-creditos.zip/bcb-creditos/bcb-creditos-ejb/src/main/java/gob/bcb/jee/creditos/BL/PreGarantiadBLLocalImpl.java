package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PreGarantiadQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PreGarantiadDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreGarantiad;
import gob.bcb.jee.creditos.util.Cttes;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;



/**
 * Implementacion para los metodos de consulta (BL) para la entidad PreGarantiad
 *
 * @author hpanique
 */
@Stateless
@LocalBean
public class PreGarantiadBLLocalImpl extends
        GenericBLLocalImpl<PreGarantiad, Integer>
        implements PreGarantiadBLLocal {

    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    PreGarantiadQLLocal parametrosQLLocal;

    @Inject
    PreGarantiadDao parametroDao;

    @Override
    public GenericQLLocal<PreGarantiad, Integer> getQLBean() {
        return parametrosQLLocal;
    }

    @Override
    public GenericDao<PreGarantiad, Integer> getGenericDao() {
        return parametroDao;
    }

    @Override
    public void validar(PreGarantiad entity) throws OperationException, EntityValidationException {
        // TODO Auto-generated method stub

    }

    @Override
    public Integer getIdNewId() throws OperationException{
        int valorMaximo=parametrosQLLocal.getNewId();
        return valorMaximo;
    }

    @Override
    public PreGarantiad GetByDsb(Integer Valor1, Integer Valor2, Integer Valor3) {
        PreGarantiad garantiad = parametrosQLLocal.getByDsb(Valor1, Valor2, Valor3);
        return garantiad;
    }

}
