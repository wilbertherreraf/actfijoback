package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the gen_oficina database table.
 * 
 */
@Embeddable
public class GenOficinaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ofi_codsuc", insertable=false, updatable=false)
	private Integer ofiCodsuc;

	@Column(name="ofi_codofi")
	private Integer ofiCodofi;

	public GenOficinaPK() {
	}
	public Integer getOfiCodsuc() {
		return this.ofiCodsuc;
	}
	public void setOfiCodsuc(Integer ofiCodsuc) {
		this.ofiCodsuc = ofiCodsuc;
	}
	public Integer getOfiCodofi() {
		return this.ofiCodofi;
	}
	public void setOfiCodofi(Integer ofiCodofi) {
		this.ofiCodofi = ofiCodofi;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof GenOficinaPK)) {
			return false;
		}
		GenOficinaPK castOther = (GenOficinaPK)other;
		return 
			(this.ofiCodsuc == castOther.ofiCodsuc)
			&& (this.ofiCodofi == castOther.ofiCodofi);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.ofiCodsuc;
		hash = hash * prime + this.ofiCodofi;
		
		return hash;
	}
}
