/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.entidades.Proyecto
 * 01/04/2016 - 09:12:34
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Clase para la entidad Solicitud credito
 *
 * @author ysalinas
 */
@Entity
@Table(name = "PROYECTO")
@Getter
@Setter

public class Proyecto extends EntidadAutorizable<Long> implements
        Serializable {
    private static final long serialVersionUID = -6761668984124916032L;

    public static final String ENTITY = "Proyecto";
    public static final String NQ_SEARCH_ALL = ENTITY + "SearchAll";
    public static final String NQ_SEARCH_BY_FILTER = ENTITY + "SearchByFilter";
    //TODO: Revisar la parte de la vigencia
    public static final String NQ_GET_AUTORIZADOS_VIGENTES = ENTITY + "GetAutorizadosVigente";
    public static final String NQ_GET_AUTORIZADOS_VIGENTES_EMPRESA_DETALLE = ENTITY + "GetAutorizadosVigenteEmpresaDetalle";
	public static final String NQ_GET_PAGOS_PROXIMOS = ENTITY + "GetPagosProximos";
    public static final String NQ_GET_PAGOS_PENDIENTES_RESUMEN = ENTITY + "GetPagosPendientesResumen";
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", updatable = false)
    private Long id;


    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "LOG_AUDITORIA_ID")
    private LogAuditoria logAuditoria;

    @ManyToOne
    @JoinColumn(name = "EMPRESA_ID")
    private Empresa empresa;

    @Column(name = "DESCRIPCION", nullable = false)
    private String descripcion;

    @Column(name = "TIPO_EMPRESA", nullable = false)
    private String tipoEmpresa;

    @Column(name = "CODIGO", nullable = false)
    private String codigo;

    @Column(name = "MONTO_APROBADO", columnDefinition = "DECIMAL(18,2)",
            precision = 18, scale = 2, nullable = false)
    private BigDecimal montoAprobado;

    @Column(name = "PLAZO", columnDefinition = "DECIMAL(6,2)",
            precision = 6, scale = 2, nullable = false)
    private BigDecimal plazo;

//    @Column(name = "TASA_INTERES", columnDefinition = "DECIMAL(18,2)", precision = 18, scale = 2, nullable = false)
//    private BigDecimal tasaInteres;
//
//    @Column(name = "PERIODO_GRACIA_CAPITAL", columnDefinition = "DECIMAL(6,2)",
//            precision = 6, scale = 2, nullable = false)
//    private BigDecimal periodoGraciaCapital;
//
//    @Column(name = "PERIODO_GRACIA_INTERES", columnDefinition = "DECIMAL(6,2)",
//            precision = 6, scale = 2, nullable = false)
//    private BigDecimal periodoGraciaInteres;

    @Column(name = "FORMA_PAGO", nullable = false)
    private String formaPago;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "COND_FINANCIERAS_ID", nullable = false)
    private CondicionesFinancieras condicionesFinancieras;

    //TODO: Consultar si este atributo no será necesario
//    @Column(name = "TIPO_AMORTIZACION")
//    private String tipoAmortizacion;

    @Column(name = "FECHA_LIMITE_DESEMBOLSO", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaLimiteDesembolso;

    @Column(name = "FECHA_CONTRATO", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaContrato;

    @Column(name = "FECHA_VENCIMIENTO")
    @Temporal(TemporalType.DATE)
    private Date fechaVencimiento;

    @Column(name = "NUMERO_CONTRATO", nullable = false)
    private String numeroContrato;

    @Column(name = "PROTOCOLIZACION", nullable = false)
    private String protocolizacion;

    @Column(name = "TIPO_GARANTIA")
    private String tipoGarantia;

    @Column(name = "SERIE_BASE")
    private String serieBase;

    @OneToMany(mappedBy = "proyecto", fetch = FetchType.EAGER)
    private List<Desembolso> desembolsos;

    public Proyecto() {
        condicionesFinancieras = new CondicionesFinancieras();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Proyecto)) return false;

        Proyecto proyecto = (Proyecto) o;

        if (id != null ? !id.equals(proyecto.id) : proyecto.id != null) return false;
        if (logAuditoria != null ? !logAuditoria.equals(proyecto.logAuditoria) : proyecto.logAuditoria != null)
            return false;
        if (empresa != null ? !empresa.equals(proyecto.empresa) : proyecto.empresa != null) return false;
        if (descripcion != null ? !descripcion.equals(proyecto.descripcion) : proyecto.descripcion != null)
            return false;
        if (tipoEmpresa != null ? !tipoEmpresa.equals(proyecto.tipoEmpresa) : proyecto.tipoEmpresa != null)
            return false;
        if (codigo != null ? !codigo.equals(proyecto.codigo) : proyecto.codigo != null) return false;
        if (montoAprobado != null ? !montoAprobado.equals(proyecto.montoAprobado) : proyecto.montoAprobado != null)
            return false;
        if (plazo != null ? !plazo.equals(proyecto.plazo) : proyecto.plazo != null) return false;
        if (formaPago != null ? !formaPago.equals(proyecto.formaPago) : proyecto.formaPago != null) return false;
        if (fechaLimiteDesembolso != null ? !fechaLimiteDesembolso.equals(proyecto.fechaLimiteDesembolso) : proyecto.fechaLimiteDesembolso != null)
            return false;
        if (fechaContrato != null ? !fechaContrato.equals(proyecto.fechaContrato) : proyecto.fechaContrato != null)
            return false;
        if (numeroContrato != null ? !numeroContrato.equals(proyecto.numeroContrato) : proyecto.numeroContrato != null)
            return false;
        if (protocolizacion != null ? !protocolizacion.equals(proyecto.protocolizacion) : proyecto.protocolizacion != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (logAuditoria != null ? logAuditoria.hashCode() : 0);
        result = 31 * result + (empresa != null ? empresa.hashCode() : 0);
        result = 31 * result + (descripcion != null ? descripcion.hashCode() : 0);
        result = 31 * result + (tipoEmpresa != null ? tipoEmpresa.hashCode() : 0);
        result = 31 * result + (codigo != null ? codigo.hashCode() : 0);
        result = 31 * result + (montoAprobado != null ? montoAprobado.hashCode() : 0);
        result = 31 * result + (plazo != null ? plazo.hashCode() : 0);
        result = 31 * result + (formaPago != null ? formaPago.hashCode() : 0);
        result = 31 * result + (fechaLimiteDesembolso != null ? fechaLimiteDesembolso.hashCode() : 0);
        result = 31 * result + (fechaContrato != null ? fechaContrato.hashCode() : 0);
        result = 31 * result + (numeroContrato != null ? numeroContrato.hashCode() : 0);
        result = 31 * result + (protocolizacion != null ? protocolizacion.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Proyecto{" +
                "id=" + id +
                ", logAuditoria=" + logAuditoria +
                ", empresa=" + empresa +
                ", descripcion='" + descripcion + '\'' +
                ", tipoEmpresa='" + tipoEmpresa + '\'' +
                ", codigo='" + codigo + '\'' +
                ", montoAprobado=" + montoAprobado +
                ", plazo=" + plazo +
                ", formaPago='" + formaPago + '\'' +
                ", fechaLimiteDesembolso=" + fechaLimiteDesembolso +
                ", fechaContrato=" + fechaContrato +
                ", numeroContrato='" + numeroContrato + '\'' +
                ", protocolizacion='" + protocolizacion + '\'' +
                '}';
    }

    public String getMontoAprobadoFormat() {
        return montoAprobado == null ? "" : getDecimalDosFormat(montoAprobado);
    }

    public String getPlazoFormat() {
        return getIntegerOrDecimalFormat(plazo);
    }

    public String getFechaContratoFormat() {
        return getDateFormat(fechaContrato);
    }

    public String getFechaLimiteDesembolsoFormat() {
        return getDateFormat(fechaLimiteDesembolso);
    }

    public String getFechaVencimientoFormat() {
        return getDateFormat(fechaVencimiento);
    }

}