/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-subasta-ejb
 * gob.bcb.jee.creditos.jee.subasta.util.Cttes
 * 20/10/2015 - 12:04:43
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.util;

import jdk.nashorn.api.scripting.ScriptUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 
 * 
 * @author ysalinas
 * 
 */
public class Cttes
{
  // unidades de persistencia

  public static final String UP_CREDITOSBCB = "CreditosDS";

  // VALORES TABLA CLAVES

  public static final String DOM_TIPO_EMPRESA = "dom_tipo_empresa";
  public static final String DOM_FORMA_PAGO = "dom_forma_pago";
  public static final String DOM_TIPO_NORMATIVA = "dom_tipo_normativa";
  public static final String DOM_TIPO_GARANTIA = "dom_tipo_garantia";
  public static final String DOM_TIPO_MONEDA = "dom_moneda";
  public static final String DOM_TIPO_PAGO_INTERES_GRACIA = "dom_tipo_pago_interes_gracia";
  public static final String DOM_TIPO_CALCULO = "dom_tipo_calculo";

  public static final String PARAM_NUM_DECIMALES_CALC = "PARAM_DECIMALES_CALCULO";
  public static final String PARAM_REGISTRO_MANUAL = "PARAM_REGISTRO_MANUAL";

  public static final char DOM_TIPO_EMP_EPNE = '1';
  public static final char DOM_ESTADO_EMP_SP = '0';

  public static final String OPCION_SI = "S";
  public static final String OPCION_NO = "N";

  public static final String FORMA_PAGO_ANUAL = "A";
  public static final String FORMA_PAGO_SEMESTRAL = "S";

  public static final String CONTRA_SIGUIENTE_CUOTA = "CSC";
  public static final String DESCRIPCION_CONTRA_SIGUIENTE_CUOTA = "CONTRA LA SIGUIENTE CUOTA";
  public static final String DISTRIBUCION_LINEAL_CUOTA = "DLC";
  public static final String DESCRIPCION_DISTRIBUCION_LINEAL_CUOTA = "DISTRIBUCION LINEAL DE LAS CUOTAS";
  public static final Integer NUMERO_CREDITO_FNDR = 43;


  public static final Integer DESCRIPCION_CORTA_CREDITO = 42;

  public static final Integer REGISTRO_TRANSITORIO_DE_BONOS = 8;

  public static final Integer REGISTRO_TRANSITORIO_DE_BONOS_CUENTA_DEBE = 12;
  public static final Integer REGISTRO_TRANSITORIO_DE_BONOS_CUENTA_HABER = 13;

  public static final Integer REGISTRO_DESEMBOLSOS_CUENTA_DEBE = 1;
  public static final Integer REGISTRO_DESEMBOLSOS_CUENTA_HABER = 2;

  public static final Integer REGISTRO_PAGO_CUOTA_CUENTA_DEBE = 5;
  public static final Integer REGISTRO_PAGO_CUOTA_CUENTA_HABER = 6;
  public static final Integer REGISTRO_PAGO_CUOTA_CUENTA_HABER_INTERES = 10;

  public static final Integer CP_GESTION_ANTERIOR = 25;
  public static final Integer CP_GESTION_ACTUAL = 26;


  public static final Integer CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_DEBE   = 14;
  public static final Integer CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_HABER = 15;

  public static final Integer CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_DEBE    = 16;
  public static final Integer CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_HABER = 17;

  /** constantes para diferencia el tipo de operacion**/
  public static final Integer REGISTRO_TRANSITORIO_DE_GARANTIAS = 8;
  public static final Integer REGISTRO_CONTABLE_DESEMBOLSOS_EPNES = 1;
  public static final Integer REGISTRO_CONTABLE_DESEMBOLSOS_MEFP = 2;
  public static final Integer REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA = 9;
  public static final Integer REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA = 10;
  public static final Integer REGISTRO_CONTABLE_PAGO_CUOTA = 4;

  /**constantes para  diferenciar por tipo de operacion ***/
  public static final Integer PAGO_AMORTIZACION_INTERESES_EPNE_MEFP = 4;
  public static final Integer PAGO_AMORTIZACION_INTERESES_YPFB_FNDR = 5;
  public static final Integer PAGO_INTERESES_EPNE_MEFP = 6;
  public static final Integer PAGO_INTERESES_YPFB_FNDR = 7;


  //CODIGO CLIENTE
  public static final Integer MINISTERIO_DE_ECONOMIA_FINANZAS_PUBLICAS = 7;
  public static final Integer YACIMIENTOS_PETROLIFEROS_FISCALES_BOLIVIANOS = 2;
  public static final Integer FONDO_NACIONAL_DE_DESARROLLO_REGIONAL = 10;
  public static final Integer FONDO_NACIONAL_DESARROLLO_REGIONAL = 10;

  /** Estados comprobantes COIN **/
  public static final String PREAUTORIZAR_COMPROBANTE_COIN = "1";
  public static final String AUTORIZAR_COMPROBANTE_COIN = "A";
  public static final String RECHAZAR_COMPROBANTE_COIN = "R";

  /** Estados SISCRED **/
  public static final Integer ESTOPER_PEND = 1;
  public static final Integer ESTOPER_PREAUTO = 2;
  public static final Integer ESTOPER_AUTO = 3;
  public static final Integer ESTOPER_RECHAZADO = 4;
  public static final Integer ESTOPER_CANC = 5;
  public static final Integer ESTOPER_ENREV = 8;

  /** FECHA PUESTA EN PRODUCCION REGISTRO TRANSITORIO DE GARANTIAS - SDAPO 2344735**/
  public static String FECHA_REGISTRO_TRANSITORIO_GARANTIAS = "2025-03-11";

}
