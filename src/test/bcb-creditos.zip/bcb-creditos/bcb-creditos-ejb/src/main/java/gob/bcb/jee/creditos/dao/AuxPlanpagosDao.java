/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.dao.EmpresaDao
 * 29/03/2016 - 11:02:08
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.model.AuxPlanpagos;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;


@Stateless
public class AuxPlanpagosDao extends GenericDao<AuxPlanpagos, Integer> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;


    public AuxPlanpagosDao() {
    }

    public AuxPlanpagosDao(Class<AuxPlanpagos> entityClass) {
        super(entityClass);
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}