/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.Articulo;
import gob.bcb.jee.creditos.model.ArticuloPK;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.Ley;
import gob.bcb.jee.creditos.model.SacClaves;
import gob.bcb.jee.creditos.util.Cttes;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class ArticuloQLLocalImpl extends
        GenericQLLocalImpl<Articulo, Integer> implements
        ArticuloQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /*
     * (non-Javadoc)
     * @see
     * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
     * ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
	
    @Override
	public Integer getIdNuevo() throws OperationException {
		String nativeQuery="select max(id_articulo) from articulo ";
		Query query=entityManager.createNativeQuery(nativeQuery);
		Object valor=query.getSingleResult();
		int id=1;
		if(valor!=null) {
			id=Integer.parseInt(valor.toString())+1;
		}
		return id;
	}

	@Override
	public List<Object[]> obtenerLeyesRelacionadas(Integer id_cli_persona) throws OperationException {
		String nativeQuery="select l.id_ley,l.ley, a.monto_registrado,a.monto_otorgado,a.saldo, l.fecha, id_articulo,numero_articulo  "
				+ "from d_creditos.ley l join d_creditos.articulo a on l.id_ley= a.id_ley "
				+ "where a.id_cli_persona= :valor1  "
				+ "order by l.fecha ";
		Query query=entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", id_cli_persona);
		List<Object[]> valor=query.getResultList();		
		if(valor==null) {
			return valor=new ArrayList<>();
		}
		return valor;
	}
}
