/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.util.EmailUtil
 * 04/01/2016 - 13:23:11
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.util;

import gob.bcb.jee.creditos.excepciones.PlantillaEEException;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.ejb.EJBException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

/**
 * Utilitario que realiza el proceso de armado de envio de email
 * 
 * yesenia salinas
 * 
 */
public class EmailUtil
{
  private String asunto;
  private String mensajeHtml;

  public void enviarNotificacion(StringBuffer sb, String mailDestino,
      String asunto) throws PlantillaEEException
  {

	  Log.Info("Preparando e-mail de notificación");
    this.asunto = asunto;
    this.armarMensaje(sb);
    Log.Info("Se enviará e-mail a: ");
    try
    {

      Locale locale = new Locale("es", "ES");

      ResourceBundle resource = ResourceBundle.getBundle("Email", locale);

      JavaMailSenderImpl sender = new JavaMailSenderImpl();
      sender.setHost(resource.getString("MAIL_SERVER"));
      sender.setPort(Integer.valueOf(resource.getString("MAIL_PORT")));
      MimeMessage message = sender.createMimeMessage();
      MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
      if ("SI".equals(resource.getString("HABILITAR_ENVIO_A_USUARIOS")))
      {
        helper.setTo(mailDestino.split(";"));
        helper.setBcc(resource.getString("MAIL_ADMIN").split(";"));
      }
      else
      {
        helper.setTo(resource.getString("MAIL_ADMIN").split(";"));
      }
      helper.setSubject(this.asunto);
      helper.setFrom(resource.getString("MAIL_SENDER"),
          resource.getString("MAIL_SENDER_NAME"));
      helper.setText(this.mensajeHtml, true);

      sender.send(message);
      Log.Info("E-mail de notificación enviado satisfactoriamente");

    }
    catch (EJBException e)
    {
      Log.Error("Error al enviar la notificación" + e);
      throw new PlantillaEEException("Error al enviar la notificación", e);
    }
    catch (Exception e)
    {
    	Log.Error("Error al enviar la notificación"+ e);
      throw new PlantillaEEException("Error al enviar la notificación", e);
    }
  }

  private void armarMensaje(StringBuffer sb)
  {

    this.mensajeHtml = sb.toString();
    sb.append("<br/><br/><br/>Atentamente,<br/><br/>Gerencia de Operaciones Monetarias<br/>BANCO CENTRAL DE BOLIVIA");
    this.mensajeHtml = this.darFormato(sb.toString());
  }

  private String darFormato(String contenido)
  {
    StringBuffer sb = new StringBuffer(
        "<html><head><meta http-equiv=Content-Type content=\"text/html; charset=utf-8\"><style type='text/css'>");
    sb.append("html,body{margin:10px;font-style:normal;font-size:14px;font-family:Arial,Verdana,Tahoma;color:#555555;}");
    sb.append("h2{color:#204D84;font-size:14px;font-weight:bold;margin: 0px 0px 0px 0px;padding: 0px 0px 0px 0px;}");
    sb.append("table{vertical-align:middle;}");
    sb.append("tr.a td{background-color:#D5E0F3;}tr.b td {background-color:#EAF0FB;}");
    sb.append("td.a{background-color:#D5E0F3;font-weight:bold;border: 1px solid #D5D5D5;}td.b{background-color:#EAF0FB;border: 1px solid #D5D5D5;}");
    sb.append("th{color:#FFFFFF;font-size:14px;background-color:#204D84;padding: 1px 10px 1px 10px;}");
    sb.append("td{color:#204D84;font-size:14px;padding: 0px 10px 0px 10px;}");
    sb.append("</style></head><body>");
    sb.append(contenido);
    sb.append("</body></html>");
    return sb.toString();
  }

}
