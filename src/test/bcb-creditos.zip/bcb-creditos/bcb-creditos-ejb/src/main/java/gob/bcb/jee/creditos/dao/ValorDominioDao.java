/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.dao.FeriadoDao
 * 22/01/2016 - 10:51:59
 * Creado por ySalinas
 */
package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.ValorDominio;
import gob.bcb.jee.creditos.entidades.ValorDominioPK;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * Clase Dao para el control de las Garantias
 *
 * @author ySalinas
 */
@Stateless
public class ValorDominioDao extends GenericDao<ValorDominio, ValorDominioPK> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /**
     *
     */
    public ValorDominioDao() {
    }

    public ValorDominioDao(Class<ValorDominio> entityClass) {
        super(entityClass);
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}