package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.QL.GenericQLLocalImpl;
import gob.bcb.jee.creditos.entidades.Entidad;
import gob.bcb.jee.creditos.excepciones.ConsultasSQLException;
import gob.bcb.jee.creditos.numeradores.CodigosError;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;



/**
 * Clase generica para realizacion de ABM
 * 
 * @author yesenia salinas
 * 
 * @param <T>
 */
@SuppressWarnings("rawtypes")
public abstract class GenericDao<T extends Entidad, ID extends Serializable>
    extends GenericQLLocalImpl<T, ID>
{


  private Class<T> entityClass;

  public GenericDao(Class<T> entityClass)
  {
    this.entityClass = entityClass;
  }

  public GenericDao()
  {

  }

  // Protected abstract EntityManager getEntityManager();

  /**
   * Metodo que realiza la persistencia de una objeto (adicion, modificacion)
   */
  public T persist(T entity)
  {
    // this.entityManager().persist(entity);

    if (entity.getId() == null)
    {
      entityManager().persist(entity);
    }
    else
    {
      entity = entityManager().merge(entity);
    }

    this.entityManager().flush();
    return entity;
  }

  /**
   * Metodo que realiza el update de una objeto (adicion, modificacion)
   */
  public T merge(T entity)
  {
    entity = this.entityManager().merge(entity);
    this.entityManager().flush();
    return entity;
  }

  /**
   * Metodo que ejecuta un NamedQuery
   */
  public Integer executeNamedQuery(String namedQuery,
      Map<String, Object> parameters)
  {
    Query query = this.entityManager().createNamedQuery(namedQuery);
    for (String parameter : parameters.keySet())
    {
      query.setParameter(parameter, parameters.get(parameter));
    }
    return query.executeUpdate();
  }

  @TransactionAttribute(TransactionAttributeType.MANDATORY)
  public void create(T entity)
  {
    this.entityManager().persist(entity);
  }

  @TransactionAttribute(TransactionAttributeType.MANDATORY)
  public void remove(T entity)
  {
    this.entityManager().remove(entity);
  }

  public T find(Object id)
  {
    return this.entityManager().find(entityClass, id);
  }

  @SuppressWarnings("unchecked")
  public List<T> findAll()
  {
    return this.entityManager().createQuery(
        "select object(o) from " + entityClass.getSimpleName()
            + " as o").getResultList();
  }

  @SuppressWarnings("unchecked")
  public List<T> findRange(int[] range)
  {
    javax.persistence.Query q = this.entityManager().createQuery(
        "select object(o) from " + entityClass.getSimpleName()
            + " as o");
    q.setMaxResults(range[1] - range[0]);
    q.setFirstResult(range[0]);
    return q.getResultList();
  }

  public Integer count()
  {
    return ((Long) this.entityManager()
        .createQuery(
            "select count(o) from " + entityClass.getSimpleName()
                + " as o").getSingleResult()).intValue();
  }

  @SuppressWarnings("unchecked")
  protected T simpleNamedQuery(String namedQuery,
      HashMap<String, Object> parametros) throws ConsultasSQLException
  {
    Query query;
    try
    {
      query = this.entityManager().createNamedQuery(namedQuery);

      if (parametros != null)
      {
        for (Entry<String, Object> entry : parametros.entrySet())
          query.setParameter(entry.getKey(), entry.getValue());
      }

      return (T) query.getSingleResult();
    }
    catch (NoResultException e)
    {
      throw new ConsultasSQLException(CodigosError.ERROR_100, namedQuery,
          e);
    }
    catch (NonUniqueResultException e)
    {
      throw new ConsultasSQLException(CodigosError.ERROR_101, namedQuery,
          e);
    }
  }

  @SuppressWarnings("unchecked")
  protected T simpleQuery(String consulta, HashMap<String, Object> parametros)
      throws ConsultasSQLException
  {
    Query query;

    try
    {
      query = this.entityManager().createQuery(consulta);

      if (parametros != null && !parametros.isEmpty())
      {
        for (Entry<String, Object> entry : parametros.entrySet())
          query.setParameter(entry.getKey(), entry.getValue());
      }

      return (T) query.getSingleResult();
    }
    catch (NoResultException e)
    {
      throw new ConsultasSQLException(CodigosError.ERROR_100, consulta, e);
    }
    catch (NonUniqueResultException e)
    {
      throw new ConsultasSQLException(CodigosError.ERROR_101, consulta, e);
    }
  }

  @SuppressWarnings("unchecked")
  protected List<T> listNamedQuery(String namedQuery,
      HashMap<String, Object> parametros)
  {
    Query query;

    query = this.entityManager().createNamedQuery(namedQuery);

    if (parametros != null)
    {
      for (Entry<String, Object> entry : parametros.entrySet())
        query.setParameter(entry.getKey(), entry.getValue());
    }

    return (List<T>) query.getResultList();

  }

  @SuppressWarnings("unchecked")
  protected List<T> listQuery(String consulta,
      HashMap<String, Object> parametros) throws ConsultasSQLException
  {
    Query query;

    try
    {
      query = this.entityManager().createQuery(consulta);

      if (parametros != null && !parametros.isEmpty())
      {
        for (Entry<String, Object> entry : parametros.entrySet())
          query.setParameter(entry.getKey(), entry.getValue());
      }

      return (List<T>) query.getResultList();
    }
    catch (NoResultException e)
    {
      throw new ConsultasSQLException(CodigosError.ERROR_100, consulta, e);
    }
  }

  @SuppressWarnings("unchecked")
  protected <U> U singleResultNamedQuery(String namedQuery,
      HashMap<String, Object> parametros, Class<U> clazz)
      throws ConsultasSQLException
  {
    Query query;
    try
    {
      query = this.entityManager().createNamedQuery(namedQuery);

      if (parametros != null)
      {
        for (Entry<String, Object> entry : parametros.entrySet())
          query.setParameter(entry.getKey(), entry.getValue());
      }

      return (U) query.getSingleResult();
    }
    catch (NoResultException e)
    {
      throw new ConsultasSQLException(
          CodigosError.ERROR_100, namedQuery, e);
    }
    catch (NonUniqueResultException e)
    {
      throw new ConsultasSQLException(
          CodigosError.ERROR_101, namedQuery, e);
    }
  }

}
