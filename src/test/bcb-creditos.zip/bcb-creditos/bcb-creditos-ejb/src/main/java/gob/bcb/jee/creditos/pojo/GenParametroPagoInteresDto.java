package gob.bcb.jee.creditos.pojo;

import gob.bcb.jee.creditos.entidades.GenParametro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * GenParametroPagoInteresDto
 *
 * @author mcramos
 * 15/01/2025
 */
@Getter
@Setter
@NoArgsConstructor
public class GenParametroPagoInteresDto implements Serializable {
    private GenParametro debitoInteres = new GenParametro();
    private GenParametro abonoIntGestAnt = new GenParametro();
    private GenParametro abonoIntGestActual = new GenParametro();
    private GenParametro esquema = new GenParametro();
}
