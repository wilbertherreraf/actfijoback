/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.util.UtilFormat
 * 07/06/2016 - 17:20:25
 * Creado por vluque
 */
package gob.bcb.jee.creditos.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utilitario para el gestion de formatos de fechas y numeros
 *
 * @author vluque
 */
public class UtilFormat {
    public static final String FORMAT_DATE_TIME = "dd-MM-yyyy HH:mm:ss";
    public static final String FORMAT_DATE = "dd-MM-yyyy";
    public static final String FORMAT_TIME = "HH:mm";
    public static final String FORMAT_DECIMAL = "###,###.##";
    public static final String FORMAT_ENTERO = "###,###";

    public static final char THOUSAND_SEPARATOR = ',';
    public static final char DECIMAL_SEPARATOR = '.';

    private static String dateFormat(Date field, String formato) {
        if (field == null) {
            return "";
        }
        SimpleDateFormat dt = new SimpleDateFormat(formato);
        String date = dt.format(field);
        return date;
    }

    public static String numberFormat(BigDecimal valor, String formato) {
        if (valor == null) {
            return "0";
        }
        DecimalFormatSymbols simbolo = new DecimalFormatSymbols();
        simbolo.setDecimalSeparator(DECIMAL_SEPARATOR);
        simbolo.setGroupingSeparator(THOUSAND_SEPARATOR);
        DecimalFormat formateador = new DecimalFormat(formato, simbolo);
        return formateador.format(valor);
    }

    public static boolean tieneCarcteresEspeciales(String cadena) {
        Pattern pats = Pattern.compile("^(?=.*[A-Z].*[A-Z])(?=.*[!@#$&*])(?=.*[0-9].*[0-9])(?=.*[a-z].*[a-z].*[a-z]).{8}$");
        Pattern pat = Pattern.compile("^[\\w-]+");
        Matcher mat = pat.matcher(cadena);
        if (mat.matches()) {
            return false;
        } else {
            return true;
        }

    }
}
