/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.dao.DocumentoRequeridoDao
 * 31/03/2016 - 15:06:31
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.Proyecto;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * Clase Dao para el control de los Solicitudes de crédito
 *
 * @author ysalinas
 */
@Stateless
public class ProyectoDao extends
        GenericDao<Proyecto, Long> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public ProyectoDao() {
    }

    public ProyectoDao(Class<Proyecto> entityClass) {
        super(entityClass);
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}