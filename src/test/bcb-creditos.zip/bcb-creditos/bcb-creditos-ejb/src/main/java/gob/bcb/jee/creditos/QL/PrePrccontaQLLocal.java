package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.model.PrePrcconta;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad PrePrcconta
 * @author hpanique
 */

@Local
public interface PrePrccontaQLLocal extends
        GenericQLLocal<PrePrcconta, Integer> {

    public Integer getNextId()throws OperationException;

    PrePrcconta guardarPrcconta(PrePrcconta prePrcconta);

    PrePrcconta buscarPorFechaDeven(Integer prcCodcred, Integer prcCodmod, Date prcFecha2);

    PrePlanpagos obtenerDevengamientoAFecha(Integer codcred, Integer codmod, Date fechafin, Date fecha);

    List<PrePrcconta> devengadosContByCred(Integer prcCodcred, Integer prcCodmod);

    List<PrePrcconta> devsGenerados(Integer prcCodcred, Integer prcCodmod, Integer estado, Date fechaCont);

    void cambiarEstadoOperComprob(Integer tipocmp, Integer idtabla, Integer codcred, Integer codmod, Integer coddsb,
            Date fecha, Integer estado, String usuario, String estacion);

    PrePrcconta buscarPorId(Integer prcCodprc);

    void initProcesoConta(Integer tipocmp, Integer idtabla, Integer tipotrx, Integer codcred, Integer codmod,
            Integer coddsb, Date fecha2, String usuario, String estacion);
}


