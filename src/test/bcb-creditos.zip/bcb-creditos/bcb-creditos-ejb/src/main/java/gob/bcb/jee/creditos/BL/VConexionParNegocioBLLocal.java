/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mvdb-ejb
 * gob.bcb.jee.mvdb.negocioBL.VOperacionParNegocioBLLocal
 * 18/04/2016 - 10:05:31
 * Creado por vluque
 */
package gob.bcb.jee.creditos.BL;

import javax.ejb.Local;
import java.sql.Connection;

/**
 * Interface para el negocio del a entidad VOperacionPar
 * 
 * 
 * @author vluque
 * 
 */
@Local
public interface VConexionParNegocioBLLocal
{

	Connection obtenerConnectionCreditos();

}
