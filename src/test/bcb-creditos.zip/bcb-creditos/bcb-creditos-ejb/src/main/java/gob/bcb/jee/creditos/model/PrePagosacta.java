package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the pre_pagosacta database table.
 * 
 */
@Entity
@Table(name="pre_pagosacta")
@NamedQuery(name="PrePagosacta.findAll", query="SELECT p FROM PrePagosacta p")
public class PrePagosacta implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PrePagosactaPK id;

	@Column(name="pac_auditfho")
	private Timestamp pacAuditfho;

	@Column(name="pac_audittrx")
	private String pacAudittrx;

	@Column(name="pac_auditusr")
	private String pacAuditusr;

	@Column(name="pac_auditwst")
	private String pacAuditwst;

	@Column(name="pac_codcarg")
	private Integer pacCodcarg;

	@Column(name="pac_codcred")
	private Integer pacCodcred;

	@Column(name="pac_codmon")
	private Integer pacCodmon;

	@Column(name="pac_codmoncon")
	private Integer pacCodmoncon;

	@Column(name="pac_despcta")
	private String pacDespcta;

	@Temporal(TemporalType.DATE)
	@Column(name="pac_feccon")
	private Date pacFeccon;

	@Temporal(TemporalType.DATE)
	@Column(name="pac_fechaope")
	private Date pacFechaope;

	@Temporal(TemporalType.DATE)
	@Column(name="pac_fecreg")
	private Date pacFecreg;

	@Column(name="pac_glosa")
	private String pacGlosa;

	@Column(name="pac_montocon")
	private BigDecimal pacMontocon;

	@Column(name="pac_numtrx")
	private Integer pacNumtrx;

	@Column(name="pac_statpcta")
	private Integer pacStatpcta;

	@Column(name="pac_statreg")
	private Integer pacStatreg;

	@Column(name="pac_tabstatpcta")
	private Integer pacTabstatpcta;

	@Column(name="pac_tabstatreg")
	private Integer pacTabstatreg;

	@Column(name="pac_tabtipopcta")
	private Integer pacTabtipopcta;

	@Column(name="pac_tabtrxstaau")
	private Integer pacTabtrxstaau;

	@Column(name="pac_tipopcta")
	private Integer pacTipopcta;

	@Column(name="pac_trxstaau")
	private Integer pacTrxstaau;

	@Column(name="pac_valor")
	private BigDecimal pacValor;

	public PrePagosacta() {
	}

	public PrePagosactaPK getId() {
		return this.id;
	}

	public void setId(PrePagosactaPK id) {
		this.id = id;
	}

	public Timestamp getPacAuditfho() {
		return this.pacAuditfho;
	}

	public void setPacAuditfho(Timestamp pacAuditfho) {
		this.pacAuditfho = pacAuditfho;
	}

	public String getPacAudittrx() {
		return this.pacAudittrx;
	}

	public void setPacAudittrx(String pacAudittrx) {
		this.pacAudittrx = pacAudittrx;
	}

	public String getPacAuditusr() {
		return this.pacAuditusr;
	}

	public void setPacAuditusr(String pacAuditusr) {
		this.pacAuditusr = pacAuditusr;
	}

	public String getPacAuditwst() {
		return this.pacAuditwst;
	}

	public void setPacAuditwst(String pacAuditwst) {
		this.pacAuditwst = pacAuditwst;
	}

	public Integer getPacCodcarg() {
		return this.pacCodcarg;
	}

	public void setPacCodcarg(Integer pacCodcarg) {
		this.pacCodcarg = pacCodcarg;
	}

	public Integer getPacCodcred() {
		return this.pacCodcred;
	}

	public void setPacCodcred(Integer pacCodcred) {
		this.pacCodcred = pacCodcred;
	}

	public Integer getPacCodmon() {
		return this.pacCodmon;
	}

	public void setPacCodmon(Integer pacCodmon) {
		this.pacCodmon = pacCodmon;
	}

	public Integer getPacCodmoncon() {
		return this.pacCodmoncon;
	}

	public void setPacCodmoncon(Integer pacCodmoncon) {
		this.pacCodmoncon = pacCodmoncon;
	}

	public String getPacDespcta() {
		return this.pacDespcta;
	}

	public void setPacDespcta(String pacDespcta) {
		this.pacDespcta = pacDespcta;
	}

	public Date getPacFeccon() {
		return this.pacFeccon;
	}

	public void setPacFeccon(Date pacFeccon) {
		this.pacFeccon = pacFeccon;
	}

	public Date getPacFechaope() {
		return this.pacFechaope;
	}

	public void setPacFechaope(Date pacFechaope) {
		this.pacFechaope = pacFechaope;
	}

	public Date getPacFecreg() {
		return this.pacFecreg;
	}

	public void setPacFecreg(Date pacFecreg) {
		this.pacFecreg = pacFecreg;
	}

	public String getPacGlosa() {
		return this.pacGlosa;
	}

	public void setPacGlosa(String pacGlosa) {
		this.pacGlosa = pacGlosa;
	}

	public BigDecimal getPacMontocon() {
		return this.pacMontocon;
	}

	public void setPacMontocon(BigDecimal pacMontocon) {
		this.pacMontocon = pacMontocon;
	}

	public Integer getPacNumtrx() {
		return this.pacNumtrx;
	}

	public void setPacNumtrx(Integer pacNumtrx) {
		this.pacNumtrx = pacNumtrx;
	}

	public Integer getPacStatpcta() {
		return this.pacStatpcta;
	}

	public void setPacStatpcta(Integer pacStatpcta) {
		this.pacStatpcta = pacStatpcta;
	}

	public Integer getPacStatreg() {
		return this.pacStatreg;
	}

	public void setPacStatreg(Integer pacStatreg) {
		this.pacStatreg = pacStatreg;
	}

	public Integer getPacTabstatpcta() {
		return this.pacTabstatpcta;
	}

	public void setPacTabstatpcta(Integer pacTabstatpcta) {
		this.pacTabstatpcta = pacTabstatpcta;
	}

	public Integer getPacTabstatreg() {
		return this.pacTabstatreg;
	}

	public void setPacTabstatreg(Integer pacTabstatreg) {
		this.pacTabstatreg = pacTabstatreg;
	}

	public Integer getPacTabtipopcta() {
		return this.pacTabtipopcta;
	}

	public void setPacTabtipopcta(Integer pacTabtipopcta) {
		this.pacTabtipopcta = pacTabtipopcta;
	}

	public Integer getPacTabtrxstaau() {
		return this.pacTabtrxstaau;
	}

	public void setPacTabtrxstaau(Integer pacTabtrxstaau) {
		this.pacTabtrxstaau = pacTabtrxstaau;
	}

	public Integer getPacTipopcta() {
		return this.pacTipopcta;
	}

	public void setPacTipopcta(Integer pacTipopcta) {
		this.pacTipopcta = pacTipopcta;
	}

	public Integer getPacTrxstaau() {
		return this.pacTrxstaau;
	}

	public void setPacTrxstaau(Integer pacTrxstaau) {
		this.pacTrxstaau = pacTrxstaau;
	}

	public BigDecimal getPacValor() {
		return this.pacValor;
	}

	public void setPacValor(BigDecimal pacValor) {
		this.pacValor = pacValor;
	}

}
