package gob.bcb.jee.creditos.dao;
import gob.bcb.jee.creditos.model.PreGarantiad;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * Clase Dao para el control de las Empresa
 *
 * @author ysalinas
 */
@Stateless
public class PreGarantiadDao extends GenericDao<PreGarantiad, Integer> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public PreGarantiadDao() {
    }

    public PreGarantiadDao(Class<PreGarantiad> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
}

