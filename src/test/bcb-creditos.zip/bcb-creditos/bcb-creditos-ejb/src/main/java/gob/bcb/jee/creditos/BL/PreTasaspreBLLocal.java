/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.PreReprograma;
import gob.bcb.jee.creditos.model.PreTasaspre;
import gob.bcb.jee.creditos.model.PreTasasprePK;
import gob.bcb.jee.creditos.model.SacClaves;

import java.util.Date;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;


@Local

public interface PreTasaspreBLLocal extends
    GenericBLLocal<PreTasaspre, PreTasasprePK>
{
	public double obtenerTasaVigente(Integer codcred,Integer codmod, Date fecha) throws OperationException;
	public PreTasaspre obtenerUltimaTasa(Integer codcred,Integer codmod) throws OperationException;
	public void update(Integer codcred,Integer codmod, Date fecha, Date newFecha, double tasa,Integer base ) throws OperationException;
}
