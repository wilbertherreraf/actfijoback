package gob.bcb.jee.creditos.BL;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import gob.bcb.jee.creditos.entidades.PreRegistrogarantias;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreCustodiaGarantia;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;
import gob.bcb.jee.creditos.model.PreRetiroGarantia;

@Local
public interface PreRegistrogarantiasBLLocal extends
        GenericBLLocal<PreRegistrogarantias, Integer> {

    public List<Object[]> getParametrosGlosa(Integer tipoOperacion)throws OperationException;

    public Integer getNumeroTotalDesembolso(Integer codcred,Integer codmod) throws OperationException;

    public String getNumeroSerieGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    public Integer getEstadoGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    public boolean cambiarEstadoOperComprob(Integer idTable,Integer tipocmp,Integer codcred,Integer codmod, String estado, String usuario, String host) throws OperationException;

    public Integer verificarRegistroTransitorioGarantias(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    PreRegistrogarantias obtenerPorCodDesembolso(Integer pCodDesembolso);

    PreDesembolsoDetalle generarCmpbDsbDet(PreDesembolsoDetalle desem, String usuario, String host);

    PreRegistrogarantias generarCmpbRegGar(PreRegistrogarantias desem, String usuario, String host);

    PreCustodiaGarantia generarCmpbCustGar(PreCustodiaGarantia desem, String usuario, String host);

    PreRetiroGarantia generarCmpbRetGar(PreRetiroGarantia desem, String usuario, String host);

}
