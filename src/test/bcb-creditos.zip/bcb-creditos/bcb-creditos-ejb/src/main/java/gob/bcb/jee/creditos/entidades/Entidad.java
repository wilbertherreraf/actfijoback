/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-seoma-ejb
 * gob.bcb.jee.creditos.jee.mse.entidades.Entidad
 * 22/10/2015 - 09:20:53
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * Entidad generica para las entidades
 *
 * @author ysalinas
 */
@SuppressWarnings("rawtypes")
@Getter
@Setter
@MappedSuperclass
public abstract class Entidad<ID extends Serializable> implements Serializable,
        Comparable<Entidad> {

    private static final long serialVersionUID = -1L;

    public Entidad() {
    }

    @Transient
    public static final String NQ_SEARCH = "Search";

    @Transient
    public static final String NQ_GET_LAZY = "GetLazy";

    @Transient
    public static final String FORMAT_DATE_TIME = "dd-MM-yyyy HH:mm:ss";

    @Transient
    public static final String FORMAT_DATE = "dd-MM-yyyy";

    @Transient
    public static final String FORMAT_DATE_MONTH_YEAR = "MM/yyyy";

    @Transient
    public static final String FORMAT_TIME = "HH:mm:ss";

    @Transient
    public static final String FORMAT_MONTO = "###,##0.00";

    @Transient
    public static final String FORMAT_DECIMAL_UNO = "###,##0.0";

    @Transient
    public static final String FORMAT_DECIMAL_CERO = "###,##0";

    @Transient
    public static final String FORMAT_TASA = "##0.0000";

//    @Column(name = "ESTADO", length = 2)
//    @Enumerated(EnumType.STRING)
//    protected gob.bcb.jee.creditos.numeradores.Estado estado;
/*
  @Column(name = "FECHA_ALTA", length = 50, nullable = false, updatable = false)
  @Temporal(TemporalType.TIMESTAMP)
  private Date fechaAlta;

  @Column(name = "USUARIO_ALTA", length = 50, nullable = false, updatable = false)
  private String usuarioAlta;*/

    @Transient
    public Map<String, Object> validateFields;

    public abstract ID getId();

    public abstract void setId(ID id);

    public String getTimeFormat(Date field) {
        return dateFormat(field, Entidad.FORMAT_TIME);
    }

    public String getDateFormat(Date field) {
        return dateFormat(field, Entidad.FORMAT_DATE);
    }

    public String getDateMonthYearFormat(Date field) {
        return dateFormat(field, Entidad.FORMAT_DATE_MONTH_YEAR);
    }

    public String getDateTimeFormat(Date field) {
        return dateFormat(field, Entidad.FORMAT_DATE_TIME);
    }

    public String getDecimalDosFormat(BigDecimal decimal) {
        return numberFormat(decimal, FORMAT_MONTO);
    }

    public String getDecimalUnoFormat(BigDecimal decimal) {
        return numberFormat(decimal, FORMAT_DECIMAL_UNO);
    }

    public String getDecimalCeroFormat(BigDecimal decimal) {
        return numberFormat(decimal, FORMAT_DECIMAL_CERO);
    }

    public String getTasaFormat(BigDecimal decimal) {
        return numberFormat(decimal, FORMAT_TASA);
    }

    public String getIntegerOrDecimalFormat(BigDecimal decimal){
        if(decimal != null) {
            if (decimal.multiply(new BigDecimal("100")).remainder(new BigDecimal("100")).compareTo(BigDecimal.ZERO) > 0)
                return getDecimalUnoFormat(decimal);
            else
                return getDecimalCeroFormat(decimal);
        }else
            return "";

    }

    public String numberFormat(BigDecimal valor, String formato) {
        if (valor == null) {
            return "0";
        }
        DecimalFormatSymbols simbolo = new DecimalFormatSymbols();
        simbolo.setDecimalSeparator(',');
        simbolo.setGroupingSeparator('.');
        DecimalFormat formateador = new DecimalFormat(formato, simbolo);
        return formateador.format(valor);
    }

    private String dateFormat(Date field, String formato) {
        if (field == null) {
            return "";
        }
        SimpleDateFormat dt = new SimpleDateFormat(formato);
        String date = dt.format(field);
        return date;
    }

    public Object getValidateFieldByName(String name) {
        Object field = null;
        if (validateFields != null && name != null) {
            if (validateFields.containsKey(name)) {
                field = validateFields.get(name);
            }
        }
        return field;
    }

    public Boolean existValidateField(String name) {
        if (validateFields != null && name != null) {
            if (validateFields.containsKey(name)) {
                return true;
            }
        }
        return false;
    }

    public boolean isValidateFieldEmpty() {
        return (validateFields == null ? false : true);
    }

    @Override
    public int compareTo(Entidad other) {
        return 0;
    }

    @Transient   
    public boolean isLazyLoading() {
        Field[] fields = this.getClass().getDeclaredFields();
        for (Field field : fields) {
            Type tipo = field.getType();
            if ("java.util.List".equals(((Class) tipo).getName())) {
                return true;
            }
            if ("java.util.Set".equals(((Class) tipo).getName())) {
                return true;
            }
        }
        return false;
    }
}
