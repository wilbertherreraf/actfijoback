package gob.bcb.jee.creditos.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;


public class Reflection<T> {

	public String imprimirCampos(T t) {
		Class<? extends T> objeto = (Class<? extends T>) t.getClass();
		Field[] variables = objeto.getDeclaredFields();
		String valor="["+objeto.getName()+"{";
		for(Field variable: variables) {			
			try {				
				String mod=Modifier.toString(variable.getModifiers());
				if(!mod.contains("static")) {
					Field o= objeto.getDeclaredField(variable.getName());		
					o.setAccessible(true);
					String valorObtenido=String.valueOf(o.get(t));				
					valor=valor+(variable.getName()+":"+valorObtenido+";");
				}				
			} 
			catch (IllegalArgumentException e) {					
				
			} catch (NoSuchFieldException e) {
					// TODO Auto-generated catch block
					
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					
				}
		}		
		return valor=valor+"}]";
	}
	public Integer generarHash(T t) {
		Class<? extends T> objeto = (Class<? extends T>) t.getClass();
		Field[] variables = objeto.getDeclaredFields();
		String valor="["+objeto.getName()+"{";
		int hash=0;
		for(Field variable: variables) {			
			try {
				
				Field o= objeto.getDeclaredField(variable.getName());		
				o.setAccessible(true);
					String valorObtenido=String.valueOf(o.get(t));				
					valor=valor+(variable.getName()+":"+valorObtenido+";");
					hash=valor.hashCode();
			} 
			catch (IllegalArgumentException e) {					
				
			} catch (NoSuchFieldException e) {
					// TODO Auto-generated catch block
					
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					
				}
		}		
		return hash;
	}
	public  String obtenerNombreClase(T t) {
		return t.getClass().getName();
	}
	public boolean equals(T t1,Object o) {
		 if (t1 == o) 
			 return true;	       
	     return false;  
	}
}
