package gob.bcb.jee.creditos.entidades;


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "pre_pagocuota")
@Getter
@Setter

public class PrePagocuota extends EntidadAutorizable<Integer> implements
        Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    @Column(name = "id")
    private Integer id;

    @Column(name = "codcred")
    private Integer codcred;

    @Column(name = "codmod")
    private Integer codmod;

    @Column(name = "coddsb")
    private Integer coddsb;

    @Column(name = "pcu_tipocmp")
    private Integer pcuTipocmp;

    @Column(name = "pcu_numtrx")
    private Integer pcuNumtrx;

    @Column(name = "total_cuota_vencimiento")
    private BigDecimal totalCuotaVencimiento;

    @Column(name = "pago_importe_capital")
    private BigDecimal pagoImporteCapital;

    @Column(name = "pago_importe_intereses")
    private BigDecimal pagoImporteIntereses;

    //
    @Column(name = "fecha_vencimiento")
    @Temporal(TemporalType.DATE)
    private Date fechaVencimiento;

    @Column(name = "fecha")
    @Temporal(TemporalType.DATE)
    private Date fecha;

    @Column(name = "intereses_gestion_anterior")
    private BigDecimal interesesGestionAnterior;

    @Column(name = "intereses_gestion_actual")
    private BigDecimal interesesGestionActual;

    @Column(name = "total_saldo")
    private BigDecimal totalSaldo;

    
    @Column(name = "numero_cuota")
    private Integer numeroCuota;

    @Column(name = "nro_claveserie")
    private String nroClaveSerie;

    
    @Column(name = "estado")
    private Integer estado;

    
    @Column(name = "cve_tipo_comprob")
    private String cveTipoComprob;

    @Column(name = "nro_comprobante_coin")
    private String nroComprobanteCoin;

    @Column(name = "glosa_coin")
    private String glosaCoin;

    @Column(name = "glosa_coin_debe_capital")
    private String glosaCoinDebeCapital;

    @Column(name = "glosa_coin_haber_capital")
    private String glosaCoinHaberCapital;

    @Column(name = "glosa_coin_interes_anterior")
    private String glosaCoinInteresAnterior;

    @Column(name = "glosa_coin_interes_actual")
    private String glosaCoinInteresActual;

    @Column(name = "cambio_bd")
    private String cambioBd;

    @Column(name = "audit_usuario")
    private String auditUsuario;

    @Column(name = "audit_fechahora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahora;

    @Column(name = "audit_host")
    private String auditHost;

    @Column(name = "audit_usuario_genera")
    private String auditUsuarioGenera;

    @Column(name = "audit_fechahora_genera")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraGenera;

    @Column(name = "audit_host_genera")
    private String auditHostGenera;

    @Column(name = "audit_usuario_preautoriza")
    private String auditUsuarioPreautoriza;

    @Column(name = "audit_fechahora_preautoriza")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraPreautoriza;

    @Column(name = "audit_host_preautoriza")
    private String auditHostPreautoriza;

    @Column(name = "audit_usuario_autoriza")
    private String auditUsuarioAutoriza;

    @Column(name = "audit_fechahora_autoriza")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraAutoriza;

    @Column(name = "audit_host_autoriza")
    private String auditHostAutoriza;



//     @JoinColumn(name = "coddsb", referencedColumnName = "dsb_coddsb")
//     @ManyToOne(optional = false)
//     private PreDesemb coddsb;

//     @JoinColumns({
//             @JoinColumn(name = "codcred", referencedColumnName = "pre_codcred"),
//             @JoinColumn(name = "codmod", referencedColumnName = "pre_codmod")})
//     @ManyToOne(optional = false)
//     private PrePrestamos prePrestamos;
}
