/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.AuxPlanpagos;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class AuxPlanpagosQLLocalImpl extends
		GenericQLLocalImpl<AuxPlanpagos, Integer> implements
		AuxPlanpagosQLLocal {
	@PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
	private EntityManager entityManager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
	 * ()
	 */
	@Override
	protected EntityManager entityManager() {
		return entityManager;
	}

	@Override
	public Integer getCantidad(Integer coddsb) throws OperationException {
		String nativeQuery = "select count(1) from aux_planpagos where  acu_coddsb=:valor1";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", coddsb);
		Object valor = query.getSingleResult();
		int id = 0;
		if (valor != null) {
			id = Integer.parseInt(valor.toString());
		}
		return id;
	}

	@Override
	public Integer getCantidadPreAutorizado(Integer coddsb) throws OperationException {
		String nativeQuery = "select count(1) from aux_planpagos where  acu_coddsb=:valor1 and acu_trxstaau=2";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", coddsb);
		Object valor = query.getSingleResult();
		int id = 0;
		if (valor != null) {
			id = Integer.parseInt(valor.toString());
		}
		return id;
	}

	@Override
	public Integer getCantidadNoPreAutorizado(Integer coddsb, Integer codgenerado) throws OperationException {
		String nativeQuery = "select count(1) from aux_planpagos where  acu_coddsb=:valor1 and acu_trxstaau=1 and acu_codmod=:valor2";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", coddsb);
		query.setParameter("valor2", codgenerado);
		Object valor = query.getSingleResult();
		int id = 0;
		if (valor != null) {
			id = Integer.parseInt(valor.toString());
		}
		return id;
	}

	@Override
	public List<Object[]> mostrarPlanDePagosAux(Integer codcred, Integer coddsb, Integer codMod)
			throws OperationException {
		String nativeQuery = "select codmod,codcred,coddsb, fechavencuo, amortizacion, amortizacion_saldo, interes,interes_saldo , dias,tasa,cuota,estado_cuota,estado_auto, tipotrx_desc "
				+ "from v_pv_planpagos_dsb "
				+ "where coddsb=:valor2 and codcred=:valor1 and codmod=:valor3 ";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", coddsb);
		query.setParameter("valor3", codMod);
		List<Object[]> valor = query.getResultList();
		if (valor == null) {
			return valor = new ArrayList<>();
		}
		return valor;
	}

	@Override
	public List<Object[]> mostrarPlanDePagosConsolAux(Integer codcred, Integer codMod) throws OperationException {
		Log.Info("mostrarPlanDePagosConsolAux codcred: " + codcred + " codMod: " + codMod);
		String nativeQuery = "select codmod,codcred, fechavencuo, amortizacion, amortizacion_saldo, interes,interes_saldo , dias,tasa,cuota,estado_cuota,tipotrx_desc "
				+ "from v_pv_planpagos_consol "
				+ "where codcred=:valor1 and codmod=:valor2 " ;
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred); 
		query.setParameter("valor2", codMod);
		List<Object[]> valor = query.getResultList();
		if (valor == null) {
			return valor = new ArrayList<>();
		}
		return valor;
	}

	@Override
	public List<Object[]> mostrarPlanDePagosDisponibles(Integer codcred, Integer coddsb) throws OperationException {
		String nativeQuery = "select distinct acu_codcred,acu_codmod ,acu_coddsb, acu_auditusr "
				+ "from aux_planpagos "
				+ "where acu_codcred=:valor1 and "
				+ "	  acu_coddsb=:valor2";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", coddsb);
		List<Object[]> valor = query.getResultList();
		if (valor == null) {
			return null;
		}
		return valor;
	}

	@Override
	public void preautorizar(Integer coddsb, String usuario, Timestamp fecha, Integer estado, Integer codseleccionado)
			throws OperationException {
		String nativeQuery = "update aux_planpagos set acu_trxstaau=:valor4, acu_auditfho=:valor1, acu_auditusr=:valor2 where acu_coddsb=:valor3 and acu_codmod=:valor5";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", fecha);
		query.setParameter("valor2", usuario);
		query.setParameter("valor3", coddsb);
		query.setParameter("valor4", estado);
		query.setParameter("valor5", codseleccionado);
		query.executeUpdate();

	}

	@Override
	public Integer getCantidadAutorizado(Integer coddsb, Integer codgenerado, Integer codaut)
			throws OperationException {
		String nativeQuery = "select count(1) from aux_planpagos where  acu_coddsb=:valor1 and acu_trxstaau=:valor3 and acu_codmod=:valor2";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", coddsb);
		query.setParameter("valor2", codgenerado);
		query.setParameter("valor3", codaut);
		Object valor = query.getSingleResult();
		int id = 0;
		if (valor != null) {
			id = Integer.parseInt(valor.toString());
		}
		return id;
	}

	@Override
	public void actualizarConsolidadoAux(Integer codcred, Integer codmod, Integer codmodtmp) throws OperationException {
		String nativeQuery = "call d_creditos.f_pv_rpo_planpagos_consol(:valor1, :valor2,:valor3)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", codmod);
		query.setParameter("valor3", codmodtmp);
		query.getResultList();
	}

	@Override
	public void actualizarDesembolsoAux(Integer codcred, Integer codmod, Integer codmodtmp, Integer coddsb)
			throws OperationException {
		String nativeQuery = "call d_creditos.f_pv_rpo_planpagos_dsb(:valor1, :valor2,:valor3,:valor4)";
		Query query = entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codcred);
		query.setParameter("valor2", null);
		query.setParameter("valor3", codmodtmp);
		query.setParameter("valor4", coddsb);
		query.getResultList();
	}

    public List<AuxPlanpagos> obtCalendarioPP( Integer codcred,  Integer codmod) {
		Integer tabtipodsb = 999;
		StringBuilder sb = new StringBuilder();
        sb.append("SELECT g ");
        sb.append("FROM AuxPlanpagos g ");
        sb.append("WHERE g.acuCodcred = :codcred ");
        sb.append("AND g.acuCodmod = :codmod ");                        
        sb.append("AND g.acuTabtipodsb = :tabtipodsb ");                        
        sb.append("AND g.acuTipodsb = g.acuCodcred ");
        sb.append("order by g.acuFecvencuo ");

        TypedQuery<AuxPlanpagos> query = entityManager.createQuery(sb.toString(),
            AuxPlanpagos.class
        );
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("tabtipodsb", tabtipodsb);
        List<AuxPlanpagos> results = query.getResultList();
        return results;
    }    

}
