/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.numeradores.EstadoDocumento
 * 01/04/2016 - 10:35:36
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.numeradores;

/**
 * Numerador para los estados del documento
 * 
 * 
 * @author ysalinas
 * 
 */
public enum EstadoDocumento
{
  C("Copia"),
  O("Original"),
  CL("Copia Legalizada");

  private String valor;

  private EstadoDocumento(String valor)
  {
    this.valor = valor;
  }

  @Override
  public String toString()
  {
    return valor;
  }

}
