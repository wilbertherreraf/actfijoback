package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the gen_ingdiferido database table.
 * 
 */
@Embeddable
public class GenIngdiferidoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="idf_codmod", insertable=false, updatable=false)
	private Integer idfCodmod;

	@Column(name="idf_codprod", insertable=false, updatable=false)
	private Integer idfCodprod;

	@Column(name="idf_codmon")
	private Integer idfCodmon;

	public GenIngdiferidoPK() {
	}
	public Integer getIdfCodmod() {
		return this.idfCodmod;
	}
	public void setIdfCodmod(Integer idfCodmod) {
		this.idfCodmod = idfCodmod;
	}
	public Integer getIdfCodprod() {
		return this.idfCodprod;
	}
	public void setIdfCodprod(Integer idfCodprod) {
		this.idfCodprod = idfCodprod;
	}
	public Integer getIdfCodmon() {
		return this.idfCodmon;
	}
	public void setIdfCodmon(Integer idfCodmon) {
		this.idfCodmon = idfCodmon;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof GenIngdiferidoPK)) {
			return false;
		}
		GenIngdiferidoPK castOther = (GenIngdiferidoPK)other;
		return 
			(this.idfCodmod == castOther.idfCodmod)
			&& (this.idfCodprod == castOther.idfCodprod)
			&& (this.idfCodmon == castOther.idfCodmon);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.idfCodmod;
		hash = hash * prime + this.idfCodprod;
		hash = hash * prime + this.idfCodmon;
		
		return hash;
	}
}
