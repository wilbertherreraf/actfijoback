/**
 * Banco Central De Bolivia 
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.plantillaWebEE.negocio.EntidadNegocioLocal
 * 23/10/2015 - 10:57:21
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.Entidad;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.numeradores.Estado;

import javax.ejb.Local;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Interface de los metodos de logica de negocios genericos
 * 
 * 
 * @author ysalinas
 * 
 */
@SuppressWarnings("rawtypes")
@Local
public interface GenericBLLocal<T extends Entidad, ID extends Serializable>
{
  /**
   * Obtiene un objeto
   * 
   * @param id
   * 
   * @return
   * @throws OperationException
   */
  T get(ID id) throws OperationException;

  /**
   * Obtiene un objeto con dependencias a partir del ID
   * 
   * @param id
   * @return
   * @throws OperationException
   */
  T getRelacionesTipoLazy(ID id) throws OperationException;

  /**
   * Obtiene una list de objetos
   * 
   * @return
   * @throws OperationException
   */
  List<T> list() throws OperationException;

  /**
   * Obtiene una lista de objetos a partir de un filtro
   * 
   * @param filtro
   * @return
   * @throws OperationException
   */
  List<T> list(String filtro) throws OperationException;
  
  List<T> listByNamedQuery(String namedQuery)throws OperationException;
  
  List<T> listByNamedQuery(String namedQuery, Map<String, Object> parameters)throws OperationException;;

  /**
   * Persistencia del objeto
   * 
   * @param entity
   * @return
   * @throws OperationException
   */
  T persist(T entity, String usuarioRegistro) throws OperationException, EntityValidationException;

  /**
   * 
   * 
   * 
   * 
   * @param entity
   * @return
   * @throws OperationException
   */
  T merge(T entity, String usuarioModificacion) throws OperationException, EntityValidationException;

  /**
   * Persistencia de una lista de objetos
   * 
   * @param entities
   * @throws OperationException
   */
  void persist(List<T> entities) throws OperationException, EntityValidationException;

  /**
   * Obtiene un objeto con dependencias a partir del ID
   * 
   * @param id
   * @return
   * @throws OperationException
   */
  T getLazy(ID id) throws OperationException;

  /**
   * Cambio del estado de un objeto
   * 
   * @param id
   * @param estado
   * @throws OperationException
   */
  void changeEstate(ID id, Estado estado) throws OperationException;

  /**
   * Eliminacion de un objeto
   * 
   * @param id
   * @param usuarioEliminacion
   * @throws OperationException
   */
  void delete(ID id, String usuarioEliminacion) throws OperationException;

  /**
   * Autorizacion de un objeto
   * 
   * @param obj
   * @param usuarioAutorizacion
   * @param autorizado
   * @throws OperationException
   */
  void authorize(T obj, String usuarioAutorizacion, boolean autorizado)
      throws OperationException;

}
