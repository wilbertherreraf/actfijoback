package gob.bcb.jee.creditos.excepciones;

import javax.ejb.ApplicationException;

/**
 * Exception del tipo aplicacion, que la misma propagada marca para realizar un
 * rollback de la misma
 * 
 * @author eibanez
 * 
 */
@ApplicationException(rollback = true)
public class PlantillaEEException extends Exception {

	private String codigoMensaje;

	private String descMensaje;

	private String[] parametros;

	private static final long serialVersionUID = 1L;

	public PlantillaEEException(String codigoMensaje, Exception e) {
		super(codigoMensaje, e);

		this.codigoMensaje = codigoMensaje;
	}

	public PlantillaEEException(String codigoMensaje, String mensaje) {
		super(mensaje);

		this.codigoMensaje = codigoMensaje;
		this.descMensaje = mensaje;
	}

	public PlantillaEEException(String codigoMensaje) {
		super(codigoMensaje);

		this.codigoMensaje = codigoMensaje;
	}

	public PlantillaEEException(String codigoMensaje, Exception e,
			String... parametros) {
		super(codigoMensaje, e);

		this.codigoMensaje = codigoMensaje;
		this.parametros = parametros;
	}

	public PlantillaEEException(String codigoMensaje, String... parametros) {
		super(codigoMensaje);

		this.codigoMensaje = codigoMensaje;
		this.parametros = parametros;
	}

	public String getCodigoMensaje() {
		return codigoMensaje;
	}

	protected static String reemplazarParametrosMensaje(String mensaje,
			String... parametros) {
		String mensajeModificado = mensaje;

		for (int i = 0; i < parametros.length; i++) {
			mensajeModificado = mensajeModificado.replaceAll(
					Integer.toString(i + 1), parametros[i]);
		}

		return mensajeModificado;
	}

	private static String recuperarMensaje(String codigoMensaje,
			String[] parametros) {
		/*
		 * CatalogoMensaje catalogoMensaje;
		 * 
		 * try { catalogoMensaje = getCatalogoMensajeQL().find(codigoMensaje);
		 * 
		 * if (parametros != null && parametros.length > 0) return
		 * reemplazarParametrosMensaje( catalogoMensaje.getDescMensaje(),
		 * parametros); else return catalogoMensaje.getDescMensaje(); } catch
		 * (Exception e) { return "No existe el codRecurso de mensaje definido"; }
		 */

		return "No existe la descripción para el codRecurso de mensaje definido";
	}

	/*
	 * @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW) private
	 * static CatalogoMensajeQL getCatalogoMensajeQL() throws NamingException {
	 * InitialContext initialContext;
	 * 
	 * if (qlCatalogoMensajes == null) { initialContext = new InitialContext();
	 * qlCatalogoMensajes = (CatalogoMensajeQL) initialContext
	 * .lookup("java:module/CatalogoMensajeQL"); }
	 * 
	 * return qlCatalogoMensajes; }
	 */

	@Override
	public String getMessage() {
		if (this.descMensaje == null || this.descMensaje.isEmpty())
			this.descMensaje = recuperarMensaje(this.codigoMensaje,
					this.parametros);

		return this.descMensaje;
	}

	@Override
	public String toString() {
		return this.codigoMensaje + " - " + this.getMessage();
	}

}
