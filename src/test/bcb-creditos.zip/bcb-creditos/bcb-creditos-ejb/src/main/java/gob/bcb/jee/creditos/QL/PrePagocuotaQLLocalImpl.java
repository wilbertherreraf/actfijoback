package gob.bcb.jee.creditos.QL;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.jee.creditos.entidades.PrePagocuota;
import gob.bcb.jee.creditos.entidades.pojo.ComprobanteDet;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreAccrual;
import gob.bcb.jee.creditos.util.Cttes;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PrePagocuotaQLLocalImpl extends
        GenericQLLocalImpl<PrePagocuota, Integer> implements PrePagocuotaQLLocal {
	private static final Logger log = LoggerFactory.getLogger(PrePagocuotaQLLocalImpl.class);

    @Resource
    private SessionContext sessionContext;

    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

    public PrePagocuota guardarPagocuota(PrePagocuota prePagocuota) {
        PrePagocuota prePagocuotaNew = null;
        if (prePagocuota.getId() == null) {
            entityManager.persist(prePagocuota);
            prePagocuotaNew = findCuotaById(prePagocuota.getId());            
            log.info("prePagocuota creado : " + prePagocuotaNew.getId() + " cred: " + prePagocuotaNew.getCodcred() + " dsb: "
                    + prePagocuotaNew.getCoddsb());
        } else {
            entityManager.merge(prePagocuota);
            prePagocuotaNew = findCuotaById(prePagocuota.getId());
            log.info("prePagocuota modificado : " + prePagocuotaNew.getId() + " cred: " + prePagocuotaNew.getCodcred()
                    + " dsb: " + prePagocuotaNew.getCoddsb());
        }

        return prePagocuotaNew;
    }

    public PrePagocuota findCuotaById(Integer id) {
        String nativeQuery = "select t " +
                "from PrePagocuota t  " +
                "where t.id=:id  ";

        Query query = entityManager.createQuery(nativeQuery);
        query.setParameter("id", id);

        List result = query.getResultList();
        if (result.size() > 0) {
            return (PrePagocuota) result.get(0);
        }
        return null;
    }

    public List<PrePagocuota> findByCredDsbVcto(Integer codcred, Integer codmod, Integer coddsb, Date fechaVencimiento) {

        String nativeQuery = "select t " +
                " from PrePagocuota t " +
                " where t.codcred=:codcred  " +
                " and t.codmod=:codmod  " +
                " and t.coddsb=:coddsb  " +
                " and t.estado in (1,2,3) " +
                " and t.fechaVencimiento = :fechaVencimiento  " ; 

        Query query = entityManager.createQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("coddsb", coddsb);
        query.setParameter("fechaVencimiento", fechaVencimiento, TemporalType.DATE);

        List result = query.getResultList();
        return result;
    }

    public List<PrePagocuota> cuotasPendientesSinCmp(Integer codcred, Integer codmod, Date fechaVencimiento) {

        String nativeQuery = "select t " +
                "from PrePagocuota t " +
                "where t.codcred=:codcred  " +
                "and t.codmod=:codmod  " +
                "and t.estado in (1,2) " +
                "and fechaVencimiento = (  " +
                "select max(p.cuoFecvencuo) " +
                "from PrePlanpagos p " +
                "where p.cuoCodcred = t.codcred " +
                "and p.cuoCodmod = t.codmod " +
                "and p.cuoCoddsb = t.coddsb " +
                "and p.cuoCoddsb > 0 " +
                "and p.cuoValorpend = 0 " +
                ") " ;

        Query query = entityManager.createQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        //query.setParameter("fechaVencimiento", fechaVencimiento, TemporalType.DATE);

        List result = query.getResultList();
        return result;
    }    

    public List<PrePagocuota> cuotasConCmpb(Integer codcred, Integer codmod, Date fechaVencimiento) {

        String nativeQuery = "select t " +
                "from PrePagocuota t " +
                "where t.codcred=:codcred  " +
                "and t.codmod=:codmod  " +
                "and t.estado in (1,2,3) " +
                "and fechaVencimiento = :fechaVencimiento " +
                "and t.nroComprobanteCoin is not null "  ;

        Query query = entityManager.createQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("fechaVencimiento", fechaVencimiento, TemporalType.DATE);

        List result = query.getResultList();
        return result;
    }        
    public PreAccrual getParametrosCobroDesembolso(Date fechaVencimiento, Integer codcred, Integer codmod,
            Integer coddsb) {

        String nativeQuery = "select saldo_cap, int_al31dic, int_alfechavcto, int_cuota,cap_cuota, " +
                "(int_cuota + cap_cuota) total_cuota     " +
                "from v_planpagos_resu                   " +
                "where codcred = :codcred                      " +
                "and codmod = :codmod                " +
                "and coddsb = :coddsb                " +
                "and fecha = :fechaVencimiento           " +
                "order by fecha,coddsb                   ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("fechaVencimiento", fechaVencimiento, TemporalType.DATE);
        query.setParameter("codcred", codcred);
        query.setParameter("coddsb", coddsb);
        query.setParameter("codmod", codmod);

        PreAccrual preAccrual = new PreAccrual();
        preAccrual.setAcrSaldo(BigDecimal.ZERO);
        preAccrual.setAcrValorpend(BigDecimal.ZERO);
        preAccrual.setAcrInteresper(BigDecimal.ZERO);
        preAccrual.setAcrInteres(BigDecimal.ZERO);
        preAccrual.setAcrCapital(BigDecimal.ZERO);
        preAccrual.setAcrValor(BigDecimal.ZERO);

        try {
            
            //generarDevengadosCredito(codcred, codmod, null, fechaVencimiento);

            List<Object[]> results = query.getResultList();
            if (results != null && results.size() > 0) {
                Object[] result = results.get(0);
                preAccrual.setAcrSaldo(result[0] != null ? (BigDecimal) result[0] : BigDecimal.ZERO);
                preAccrual.setAcrValorpend(result[1] != null ? (BigDecimal) result[1] : BigDecimal.ZERO);
                preAccrual.setAcrInteresper(result[2] != null ? (BigDecimal) result[2] : BigDecimal.ZERO);
                preAccrual.setAcrInteres(result[3] != null ? (BigDecimal) result[3] : BigDecimal.ZERO);
                preAccrual.setAcrCapital(result[4] != null ? (BigDecimal) result[4] : BigDecimal.ZERO);
                preAccrual.setAcrValor(result[5] != null ? (BigDecimal) result[5] : BigDecimal.ZERO);
            }

            return preAccrual;

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }

    }// en method
    @Override
    public List<Object[]> getParametrosGlosa(Integer tipoOperacion) throws OperationException {
        String nativeQuery = "execute procedure p_get_par_comprobante(:tipoOperacion)";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("tipoOperacion", tipoOperacion);

        List<Object[]> results = query.getResultList();

        if (results == null || results.isEmpty()) {
            throw new OperationException("No se pudo obtener los parametros del crédito");
        }
        return results;
    }

    @Override
    public Integer getNumeroDesembolso(Integer codcred, Integer codmod, Integer coddsb) throws OperationException {

        String nativeQuery = " SELECT sub.fila FROM ( " +
                "    SELECT ROW_NUMBER() OVER () AS fila, *  " +
                "    FROM d_creditos.pre_desemb " +
                "    WHERE dsb_codcred = :codcred AND dsb_codmod = :codmod " +
                "       ) AS sub " +
                " WHERE dsb_coddsb = :coddsb  ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("coddsb", coddsb);

        Object valor = query.getSingleResult();

        if (valor != null) {
            return ((BigInteger) valor).intValue();
        }
        return 0;

    } 

    @Override
    public Integer getNumeroCuota(Integer codcred, Integer codmod, Date fechaVencimiento) throws OperationException {
        String nativeQuery = " SELECT sub.numero_cuota FROM ( " +
                "                   select ROW_NUMBER() OVER () AS numero_cuota, fechavencuo fecha, saldo_inicio, amortizacion, amortizacion_saldo ,interes , interes_saldo,dias,tasa,cuota, estado_cuota estado "
                +
                "                   from v_planpagos_consol " +
                "                   where codmod=:codmod and codcred=:codcred " +
                "                   ) AS sub " +
                " WHERE fecha=:fechaVencimiento ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("fechaVencimiento", fechaVencimiento);

        Object valor = query.getSingleResult();

        if (valor != null) {
            return ((BigInteger) valor).intValue();
        }
        return 0;
    } 

    public void generarOperContCred(Integer codcmp, Integer codprc,Integer codcred,Integer codmod,Integer coddsb,Date fecvcto, Integer numtrx,String usuario,String estacion) {

        String nativeQuery = "execute procedure p_set_params_proceso_conta(:codcmp, :codprc,:codcred,:codmod, :coddsb, :fecvcto, :numtrx,:usuario, :estacion)";
        log.info("En generarOperContCred p_set_params_proceso_conta codcmp: "+codcmp+", codprc : {}, codcred: {}, coddsb: {"+coddsb+"}, usuario: {"+usuario+"},estacion: {"+estacion+"}",codprc, codcred);
        try {
            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("codcmp", codcmp);
            query.setParameter("codprc", codprc);
            query.setParameter("codcred", codcred);
            query.setParameter("codmod", codmod);
            query.setParameter("coddsb", coddsb);
            query.setParameter("fecvcto", fecvcto, TemporalType.DATE);
            query.setParameter("numtrx", numtrx);
            query.setParameter("usuario", usuario);
            query.setParameter("estacion", estacion);

            query.executeUpdate();
            log.info("==> FIN generarOperContCred p_set_params_proceso_conta tipoproc: "+codcmp+", codprc : {}, codcred: {}, coddsb: {"+coddsb+"}, usuario: {"+usuario+"},estacion: {"+estacion+"}",codprc, codcred);
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
                if (cause instanceof SQLException) {
                    count++;
                    sb.append(cause.getMessage());
                    sb.append(" , ");
                }
            }
            String consent = (count > 0 ? sb.toString().replace(", null ,", "")
                    : "Error :" + e.getMessage().replace(", null ,", ""));
            throw new RuntimeException("Error p_set_params_proceso_conta : " + consent, e);
        }
    }

    @Override
    public Integer getEstadoPagoCuota(Integer codcred, Integer codmod, Integer coddsb, Date fechaVencimiento)
            throws OperationException {
        String nativeQuery = " SELECT NVL(r.estado, 0) as estado  " +
                " FROM (SELECT 0 as estado FROM systables WHERE tabid = 1) dummy " +
                " LEFT JOIN d_creditos.pre_pagocuota r " +
                " ON r.codmod=:codmod " +
                " and codcred=:codcred " +
                " and coddsb=:coddsb  " +
                " and fecha_vencimiento=:fechaVencimiento  " +
                " and r.estado in (1,2,3)  ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("coddsb", coddsb);
        query.setParameter("fechaVencimiento", fechaVencimiento);

        Object valor = query.getSingleResult();

        if (valor != null) {
            return (int) valor;
        }
        return 0;
    }

    @Override
    public Integer getVerificarExistePagoCuota(Integer codcred, Integer codmod, Integer coddsb, Date fechaVencimiento)
            throws OperationException {
        String nativeQuery = " select count(*) as total " +
                " from d_creditos.pre_pagocuota  " +
                " where codcred=:codcred  " +
                " and codmod=:codmod  " +
                " and coddsb=:coddsb  " +
                " and fecha_vencimiento=:fechaVencimiento  " +
                " and estado in (1,2,3) ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("coddsb", coddsb);
        query.setParameter("fechaVencimiento", fechaVencimiento);

        Object valor = query.getSingleResult();

        if (valor != null) {
            return ((BigDecimal) valor).intValue(); // Conversión segura
        }
        return 0;
    }

    @Override
    public PrePagocuota obtenerPorCodDesembolso(Integer pCodDesembolso) {
        PrePagocuota prePagocuota = new PrePagocuota();

        String nativeQuery = " SELECT * FROM d_creditos.pre_pagocuota WHERE coddsb = :coddsb and fecha=:pfecha and estado  in (1,2,3) ";// 4:anulado,
                                                                                                                                           // 5:cancelado

        try {
            Query query = entityManager.createNativeQuery(nativeQuery, PrePagocuota.class)
                    .setParameter("coddsb", pCodDesembolso).setParameter("pfecha", new Date());
            prePagocuota = (PrePagocuota) query.getSingleResult();

        } catch (NoResultException e) {
            prePagocuota = new PrePagocuota();
        }
        return prePagocuota;
    }

    public void generarDevengadosCredito(Integer codcred, Integer codmod, Date fechaIni, Date fechaFin, Integer tipoproc) {
        try {
            log.info("Inicio p_acr_devenga_cred de fecha de devengado Credito: " + codcred + " Fecha: " + fechaIni
                    + " -> "
                    + fechaFin + " tipoproc " + tipoproc);
            String nativeQuery = "call p_acr_devenga_cred(:codmod, :codcred, :fechaIni, :fechaFin, :tipoproc)";
            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("codmod", codmod);
            query.setParameter("codcred", codcred);
            query.setParameter("fechaIni", fechaIni, TemporalType.DATE);
            query.setParameter("fechaFin", fechaFin, TemporalType.DATE);
            query.setParameter("tipoproc", tipoproc);            
            query.executeUpdate();

        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
                if (cause instanceof SQLException) {
                    count++;
                    sb.append(cause.getMessage());
                    sb.append(" , ");
                }
            }
            String consent = (count > 0 ? sb.toString().replace(", null ,", "")
                    : "Error :" + e.getMessage().replace(", null ,", ""));
            throw new RuntimeException("Error p_acr_devenga_cred: " + consent, e);
        }
    }

    @Transactional(Transactional.TxType.REQUIRES_NEW)
    public void devengarCredito(Integer codcred, Integer codmod, Date fechaIni, Date fechaFin, Integer tipoproc) {
        try {
            log.info("Inicio diario devengado Credito: " + codcred + " Fecha: " + fechaIni
                    + " -> "
                    + fechaFin + " tipoproc " + tipoproc);
            String nativeQuery = "call p_acr_devenga_cred(:codmod, :codcred, :fechaIni, :fechaFin, :tipoproc)";
            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("codmod", codmod);
            query.setParameter("codcred", codcred);
            query.setParameter("fechaIni", fechaIni, TemporalType.DATE);
            query.setParameter("fechaFin", fechaFin, TemporalType.DATE);
            query.setParameter("tipoproc", tipoproc);            
            query.executeUpdate();

        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
                if (cause instanceof SQLException) {
                    count++;
                    sb.append(cause.getMessage());
                    sb.append(" , ");
                }
            }
            String consent = (count > 0 ? sb.toString().replace(", null ,", "")
                    : "Error :" + e.getMessage().replace(", null ,", ""));
            throw new RuntimeException("Error p_acr_devenga_cred: " + consent, e);
        }
    }

	public List<ComprobanteDet> recuperarComprobReng(String cpbCodigo) {
		List<ComprobanteDet> comprobanteList = new ArrayList<ComprobanteDet>();
		String query = "select c.cpb_codigo,c.cpb_fecha,r.ren_codigo,r.cta_movimiento,r.cla_debehaber,r.ren_tipocambio,r.ren_montomo,r.ren_montomn,r.ren_afectable,r.ren_glosa,r.moneda,r.cla_debehaber,c.cpb_glosa, ";
		query = query.concat("(select s.cta_nommovimiento from soc_cuentassol s where s.cta_afectable = r.ren_afectable and s.moneda = r.moneda "
				+ "and s.cta_codigo = (select min(s0.cta_codigo) from soc_cuentassol s0 where s0.cta_movimiento = s.cta_movimiento AND s0.moneda = s.moneda)) cta_nommovimiento ");
		query = query.concat("from soc_rengscomp r, soc_comprobante c ");
		query = query.concat("where c.cpb_codigo = r.cpb_codigo ");
		query = query.concat("and c.cpb_codigo = :cpbCodigo ");
		query = query.concat("order by r.ren_codigo ");

		try {
			Query consulta = entityManager.createNativeQuery(query);
			consulta.setParameter("cpbCodigo", cpbCodigo);

			List lista = consulta.getResultList();
			List<Map<String, Object>> resultado = new ArrayList<>();

			for (Map<String, Object> res : resultado) {
				ComprobanteDet comprobante = new ComprobanteDet();

				comprobante.setCpbCodigo((String) res.get("cpb_codigo"));
				comprobante.setCpbFecha((Date) res.get("cpb_fecha"));
				comprobante.setRenCodigo((Integer) res.get("ren_codigo"));
				comprobante.setCtaMovimiento((String) res.get("cta_movimiento"));
				comprobante.setMovi((String) res.get("cta_nommovimiento"));
				comprobante.setClaDebehaber(String.valueOf(((Character) res.get("cla_debehaber"))));
				comprobante.setRenTipocambio((BigDecimal) res.get("ren_tipocambio"));
				comprobante.setRenMontomo((BigDecimal) res.get("ren_montomo"));
				comprobante.setRenMontomn((BigDecimal) res.get("ren_montomn"));
				comprobante.setRenAfectable((String) res.get("ren_afectable"));
				//comprobante.setRenGlosa((String) res.get("ren_glosa"));

				String glosa = (String) res.get("ren_glosa");
				if (glosa != null) {
					glosa = glosa.replaceAll("\\|+$", "").trim(); // quita solo los pipes al final
				}
				comprobante.setRenGlosa(glosa);

				comprobante.setCodMoneda((Integer) res.get("moneda"));
				comprobante.setDebe(BigDecimal.ZERO);
				comprobante.setHaber(BigDecimal.ZERO);

				if (comprobante.getClaDebehaber().equals("D")) {
					comprobante.setDebe(comprobante.getRenMontomn());
				} else {
					comprobante.setHaber(comprobante.getRenMontomn());
				}
				comprobanteList.add(comprobante);
			}
		} catch (Exception e) {
			log.error("Error al recuperar comprobante: " + e.getMessage());
			throw new RuntimeException("Error al recuperar comprobante: " + e.getMessage(), e);
		}
		return comprobanteList;
	}

    public void actualizarRengs(Integer tipoproc, Integer codcred, Integer codmod, Date fecha, Integer tipotrx, String usuario, String estacion) {
        String codproceso = "PAGO";
        if (tipoproc == 8) {
            codproceso = "PAGADO";
        }
        String nativeQuery = "execute procedure p_upd_status_pre(:codcred, :codmod, :coddsb, :fecha, :idtabla, :tipotrx, :codproceso, :usuario, :estacion)";
        log.info("En p_upd_status_pre idTable: " 
                +  " codcred: " + codcred + " codmod: " + codmod + " fecha: "
                + fecha);
        try {
            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("codcred", codcred);
            query.setParameter("codmod", codmod);            
            query.setParameter("coddsb", null);
            query.setParameter("fecha", fecha, TemporalType.DATE);
            query.setParameter("idtabla", null);
            query.setParameter("tipotrx", tipotrx);
            query.setParameter("codproceso", codproceso);            
            query.setParameter("usuario", usuario);
            query.setParameter("estacion", estacion);

            query.executeUpdate();
        } catch (Exception e) {
            log.error("Exception: " + e.getMessage());
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
                if (cause instanceof SQLException) {
                    count++;
                    sb.append(cause.getMessage());
                    sb.append(" , ");
                }
            }
            String consent = (count > 0 ? sb.toString().replace(", null ,", "")
                    : "Error :" + e.getMessage().replace(", null ,", ""));
            throw new RuntimeException("Error p_upd_status_pre: " + consent, e);
        }
    } 

    public static PrePagocuota nuevoCuota(){
        PrePagocuota prePagocuota = new PrePagocuota();
        prePagocuota.setTotalCuotaVencimiento(BigDecimal.ZERO);
        prePagocuota.setTotalSaldo(BigDecimal.ZERO);
        prePagocuota.setPagoImporteIntereses(BigDecimal.ZERO);
        prePagocuota.setPagoImporteCapital(BigDecimal.ZERO);
        prePagocuota.setInteresesGestionAnterior(BigDecimal.ZERO);
        prePagocuota.setInteresesGestionActual(BigDecimal.ZERO);
        return prePagocuota;
    }
} // end class
