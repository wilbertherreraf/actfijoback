package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the aux_precobro database table.
 * 
 */
@Entity
@Table(name="aux_precobro")
@NamedQuery(name="AuxPrecobro.findAll", query="SELECT a FROM AuxPrecobro a")
public class AuxPrecobro implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AuxPrecobroPK id;

	@Column(name="apc_codigo")
	private Integer apcCodigo;

	@Column(name="apc_codmon")
	private Integer apcCodmon;

	@Column(name="apc_codtab")
	private Integer apcCodtab;

	@Column(name="apc_cuenta")
	private String apcCuenta;

	@Column(name="apc_descrip")
	private String apcDescrip;

	@Temporal(TemporalType.DATE)
	@Column(name="apc_feccontab")
	private Date apcFeccontab;

	@Column(name="apc_numtrx")
	private Integer apcNumtrx;

	@Column(name="apc_operador")
	private String apcOperador;

	@Column(name="apc_tabtipotrx")
	private Integer apcTabtipotrx;

	@Column(name="apc_tipotrx")
	private Integer apcTipotrx;

	@Column(name="apc_valor")
	private BigDecimal apcValor;

	public AuxPrecobro() {
	}

	public AuxPrecobroPK getId() {
		return this.id;
	}

	public void setId(AuxPrecobroPK id) {
		this.id = id;
	}

	public Integer getApcCodigo() {
		return this.apcCodigo;
	}

	public void setApcCodigo(Integer apcCodigo) {
		this.apcCodigo = apcCodigo;
	}

	public Integer getApcCodmon() {
		return this.apcCodmon;
	}

	public void setApcCodmon(Integer apcCodmon) {
		this.apcCodmon = apcCodmon;
	}

	public Integer getApcCodtab() {
		return this.apcCodtab;
	}

	public void setApcCodtab(Integer apcCodtab) {
		this.apcCodtab = apcCodtab;
	}

	public String getApcCuenta() {
		return this.apcCuenta;
	}

	public void setApcCuenta(String apcCuenta) {
		this.apcCuenta = apcCuenta;
	}

	public String getApcDescrip() {
		return this.apcDescrip;
	}

	public void setApcDescrip(String apcDescrip) {
		this.apcDescrip = apcDescrip;
	}

	public Date getApcFeccontab() {
		return this.apcFeccontab;
	}

	public void setApcFeccontab(Date apcFeccontab) {
		this.apcFeccontab = apcFeccontab;
	}

	public Integer getApcNumtrx() {
		return this.apcNumtrx;
	}

	public void setApcNumtrx(Integer apcNumtrx) {
		this.apcNumtrx = apcNumtrx;
	}

	public String getApcOperador() {
		return this.apcOperador;
	}

	public void setApcOperador(String apcOperador) {
		this.apcOperador = apcOperador;
	}

	public Integer getApcTabtipotrx() {
		return this.apcTabtipotrx;
	}

	public void setApcTabtipotrx(Integer apcTabtipotrx) {
		this.apcTabtipotrx = apcTabtipotrx;
	}

	public Integer getApcTipotrx() {
		return this.apcTipotrx;
	}

	public void setApcTipotrx(Integer apcTipotrx) {
		this.apcTipotrx = apcTipotrx;
	}

	public BigDecimal getApcValor() {
		return this.apcValor;
	}

	public void setApcValor(BigDecimal apcValor) {
		this.apcValor = apcValor;
	}

}
