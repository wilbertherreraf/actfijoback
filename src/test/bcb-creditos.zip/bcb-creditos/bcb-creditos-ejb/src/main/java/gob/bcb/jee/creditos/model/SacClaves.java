package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the sac_claves database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="sac_claves")
@NamedQuery(name=SacClaves.NQ_LIST_ALL, query="SELECT s FROM SacClaves s")
public class SacClaves extends EntidadAutorizable<String>  implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="SacClaves";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	@Id
	@Column(name="clv_codclv",length = 15)
	private String clvCodclv;
	
	@Column(name="clv_descrip")
	private String clvDescrip;

	@Column(name="clv_valor")
	private String clvValor;
	
	@Column(name="clv_abrev",length = 35)
	private String clvAbrev;

	@Column(name="clv_auditusr")
	private String clvAuditusr;

	@Column(name="clv_auditfho")
	private Timestamp clvAuditfho;

	@Column(name="clv_auditwst")
	private String clvAuditwst;

	public SacClaves() {
	}

	@Override
	public String getId() {
		return this.clvCodclv;
	}

	@Override
	public void setId(String id) {
		this.clvCodclv=id;
	}
}
