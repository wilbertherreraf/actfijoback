package gob.bcb.jee.creditos.BL;

import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PrePagocuotaQLLocal;
import gob.bcb.jee.creditos.QL.PreRegistrogarantiasQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PrePagocuotaDao;
import gob.bcb.jee.creditos.entidades.PrePagocuota;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreAccrual;
import gob.bcb.jee.creditos.util.Cttes;

@Stateless
@LocalBean
public class PrePagocuotaBLLocalImpl extends
        GenericBLLocalImpl<PrePagocuota, Integer> implements PrePagocuotaBLLocal {
    private static final Logger logger = LoggerFactory.getLogger(PrePagocuotaBLLocalImpl.class);
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;

    @Inject
    PrePagocuotaQLLocal prePagocuotaQLLocal;
    @Inject
    private PreRegistrogarantiasQLLocal preRegistrogarantiasQLLocal;
    @Inject
    PrePagocuotaDao prePagocuotaDao;

    @Override
    public void validar(PrePagocuota entity) throws OperationException, EntityValidationException {

    }

    @Override
    public GenericQLLocal<PrePagocuota, Integer> getQLBean() {
        return prePagocuotaQLLocal;
    }

    @Override
    public GenericDao<PrePagocuota, Integer> getGenericDao() {
        return prePagocuotaDao;
    }

    @Override
    public PreAccrual getParametrosCobroDesembolso(Date fechaVencimiento, Integer codcred, Integer codmod,
            Integer coddsb) {
        return prePagocuotaQLLocal.getParametrosCobroDesembolso(fechaVencimiento, codcred, codmod, coddsb);
    }

    @Override
    public List<Object[]> getParametrosGlosa(Integer tipoOperacion) throws OperationException {
        return prePagocuotaQLLocal.getParametrosGlosa(tipoOperacion);
    }

    @Override
    public Integer getNumeroDesembolso(Integer codcred, Integer codmod, Integer coddsb) throws OperationException {
        return prePagocuotaQLLocal.getNumeroDesembolso(codcred, codmod, coddsb);
    }

    @Override
    public Integer getNumeroCuota(Integer codcred, Integer codmod, Date fechaVencimiento) throws OperationException {
        return prePagocuotaQLLocal.getNumeroCuota(codcred, codmod, fechaVencimiento);
    }

    @Override
    public Integer getEstadoPagoCuota(Integer codcred, Integer codmod, Integer coddsb, Date fechaVencimiento)
            throws OperationException {
        return prePagocuotaQLLocal.getEstadoPagoCuota(codcred, codmod, coddsb, fechaVencimiento);
    }

    @Override
    public Integer getVerificarExistePagoCuota(Integer codcred, Integer codmod, Integer coddsb, Date fechaVencimiento)
            throws OperationException {
        return prePagocuotaQLLocal.getVerificarExistePagoCuota(codcred, codmod, coddsb, fechaVencimiento);
    }

    @Override
    public PrePagocuota obtenerPorCodDesembolso(Integer pCodDesembolso) {
        return prePagocuotaQLLocal.obtenerPorCodDesembolso(pCodDesembolso);
    }

    public PrePagocuota guardarPagocuota(PrePagocuota prePagocuota) {
        return prePagocuotaQLLocal.guardarPagocuota(prePagocuota);
    }

    public PrePagocuota findCuotaById(Integer id) {
        return prePagocuotaQLLocal.findCuotaById(id);
    }

    public List<PrePagocuota> findByCredDsbVcto(Integer codcred, Integer codmod, Integer coddsb,
            Date fechaVencimiento) {
        return prePagocuotaQLLocal.findByCredDsbVcto(codcred, codmod, coddsb, fechaVencimiento);
    }

    public PrePagocuota generarOperacionYContaBL(Integer tipoRegistro, PrePagocuota prePagocuota, String resultadoGlosa) {
        log.info("Inicio generando operacion cuota " + prePagocuota.getId() + " tipoRegistro: " + tipoRegistro);
        PrePagocuota  pcuota = prePagocuotaQLLocal.guardarPagocuota(prePagocuota);
        
        String nroCmp = preRegistrogarantiasQLLocal.generarCmpbBonos(pcuota.getId(), pcuota.getPcuTipocmp(),
                pcuota.getCodcred(), pcuota.getCodmod(), pcuota.getFechaVencimiento(), pcuota.getGlosaCoin(),
                prePagocuota.getAuditUsuarioGenera(), prePagocuota.getAuditHostGenera());

         PrePagocuota  pcuot = prePagocuotaQLLocal.findCuotaById(pcuota.getId());
        return pcuot;
    }

    public void generarDevengadosCredito(Integer codcred, Integer codmod, Date fechaIni, Date fechaFin,
            Integer tipoproc) {
        prePagocuotaQLLocal.generarDevengadosCredito(codcred, codmod, fechaIni, fechaFin, tipoproc);
    }

    public List<PrePagocuota> cuotasPendientesSinCmp(Integer codcred, Integer codmod, Date fechaVencimiento) {
        return prePagocuotaQLLocal.cuotasPendientesSinCmp(codcred, codmod, fechaVencimiento);
    }

    public List<PrePagocuota> cuotasConCmpb(Integer codcred, Integer codmod, Date fechaVencimiento) {
        return prePagocuotaQLLocal.cuotasConCmpb( codcred,codmod, fechaVencimiento);
    }
    public void actualizarRengs(Integer tipoproc,Integer codcred, Integer codmod, Date fecha, Integer tipotrx, String usuario,
            String estacion) {
        prePagocuotaQLLocal.actualizarRengs(tipoproc,codcred, codmod, fecha, tipotrx, usuario, estacion);
    }

    public void devengarCredito(Integer codcred, Integer codmod, Date fechaIni, Date fechaFin, Integer tipoproc) {
        try {
            prePagocuotaQLLocal.devengarCredito(codcred, codmod, fechaIni, fechaFin, tipoproc);
            logger.info("Credito " + codcred + " mod: " + codmod + " fe: " + fechaFin + " devengado hecho...");
        } catch (Exception e) {
            logger.error("Error al devengar cred " + codcred + ":" + e.getMessage());
        }
    }

    public void generarOperContCred(Integer codcmp, Integer codprc, Integer codcred, Integer codmod, Integer coddsb,
            Date fecvcto, Integer numtrx, String usuario, String estacion) {
        prePagocuotaQLLocal.generarOperContCred(codcmp, codprc, codcred, codmod, coddsb, fecvcto, numtrx, usuario,
                estacion);
    }
}
