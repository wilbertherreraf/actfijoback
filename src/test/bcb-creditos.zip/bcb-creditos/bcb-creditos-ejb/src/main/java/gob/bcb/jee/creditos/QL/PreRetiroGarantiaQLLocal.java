package gob.bcb.jee.creditos.QL;

import java.util.Date;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreRetiroGarantia;

/**
 * PreRetiroGarantiaQLLocal
 *
 * @author mcramos
 * 11/03/2025
 */
@Local
public interface PreRetiroGarantiaQLLocal extends
        GenericQLLocal<PreRetiroGarantia, Integer>{

    PreRetiroGarantia obtenerPorCodDesembolso(Integer pCodDesembolso);

    Integer getEstadoRetiroGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    Boolean tieneRetiroGarantia(Integer codcred,Integer codmod,Integer coddsb, Date fechaVencimiento);

    Boolean existeNroClaveSerie(String pNroClaveSerie);

    PreRetiroGarantia buscarPorId(Integer id);

    PreRetiroGarantia guardarRetGar(PreRetiroGarantia entity);
}
