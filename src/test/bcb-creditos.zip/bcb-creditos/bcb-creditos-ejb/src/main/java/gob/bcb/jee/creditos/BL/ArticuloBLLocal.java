/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import java.util.List;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.Articulo;


@Local

public interface ArticuloBLLocal extends
    GenericBLLocal<Articulo,Integer>
{
	public Integer getIdNuevo() throws OperationException;
	
	public List<Object[]> obtenerLeyesRelacionadas(Integer id_cli_persona) throws OperationException;
}
