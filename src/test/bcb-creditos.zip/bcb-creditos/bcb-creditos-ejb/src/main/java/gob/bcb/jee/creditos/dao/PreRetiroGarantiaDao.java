package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.model.PreRetiroGarantia;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * PreRetiroGarantiaDao
 *
 * @author mcramos
 * 11/03/2025
 */
@Stateless
public class PreRetiroGarantiaDao extends GenericDao<PreRetiroGarantia, Integer> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public PreRetiroGarantiaDao() {
    }

    public PreRetiroGarantiaDao(Class<PreRetiroGarantia> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
}
