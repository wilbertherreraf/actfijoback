package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the sac_claves database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="ley")
@NamedQuery(name=Ley.NQ_LIST_ALL, query="SELECT s FROM Ley s")
public class Ley extends EntidadAutorizable<Integer>  implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="Ley";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	@Id	
	@Column(name="id_ley")
	private Integer idLey;
	
	@Column(name="numero_ley")
	private Integer numeroLey;
	
	@Column(name="ley")
	private String ley;

	@Temporal(TemporalType.DATE)
	@Column(name="fecha")
	private Date fecha;
	
	@Column(name="aclaracion")
	private String aclaracion;
		
	@Column(name="tabtrxstaau")
	private Integer tabtrxstaau;
	
	@Column(name="trxstaau")
	private Integer trxstaau;
	
	
	@Column(name="auditusr")
	private String auditusr;

	@Column(name="auditfho")
	private Timestamp auditfho;

	@Column(name="auditwst")
	private String auditwst;

	public Ley() {
	}

	@Override
	public Integer getId() {
		return this.idLey;
	}

	@Override
	public void setId(Integer id) {
		this.idLey=id;
		
	}

}
