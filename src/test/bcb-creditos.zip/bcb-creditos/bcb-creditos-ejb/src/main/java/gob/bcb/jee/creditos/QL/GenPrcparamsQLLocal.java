package gob.bcb.jee.creditos.QL;

import java.util.List;

import gob.bcb.jee.creditos.entidades.GenPrcparams;

public interface GenPrcparamsQLLocal {

    /**
     * Busca parámetros por tipo de proceso
     */
    List<GenPrcparams> findByTipoProc(Integer tipoProc);

    List<GenPrcparams> findByCodPrcAndTipoProc(Integer codPrc, Integer tipoProc);

    /**
     * Busca parámetros por código de proceso
     */
    List<GenPrcparams> findByCodPrc(Integer codPrc);

    /**
     * Busca parámetros por número de transacción
     */
    List<GenPrcparams> findByNumTrx(Integer numTrx);

    /**
     * Actualiza el valor de un parámetro
     */
    GenPrcparams saveUpdateGenP(GenPrcparams genPrcparams);

    /**
     * Cuenta parámetros por código de proceso
     */
    GenPrcparams findById(Integer codprc, Integer tipoproc, Integer codtpr);

    List<GenPrcparams> findByCodPrcYTipoProc(Integer codPrc, Integer tipoProc);

}
