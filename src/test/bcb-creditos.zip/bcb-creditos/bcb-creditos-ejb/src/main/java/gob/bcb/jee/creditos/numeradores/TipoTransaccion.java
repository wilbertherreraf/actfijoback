/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.numeradores.TipoParametro
 * 21/03/2016 - 10:55:44
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.numeradores;

/**
 * Numerador para el tipo de parametro o tipo de entidad
 * 
 * 
 * @author ysalinas
 * 
 */
public enum TipoTransaccion
{
  CRE("CREACIÓN "),
  MOD("MODIFICACIÓN"),
  SUS("SUSPENSIÓN"),
  HAB("HABILITACIÓN"),
  ELI("ELIMINACIÓN"),
  SESION("INICIO SESION");

  private TipoTransaccion(String value)
  {
    this.value = value;
  }

  private String value;

  public String getDescripcion()
  {
    return value;
  }

  @Override
  public String toString()
  {
    return value;
  }

}
