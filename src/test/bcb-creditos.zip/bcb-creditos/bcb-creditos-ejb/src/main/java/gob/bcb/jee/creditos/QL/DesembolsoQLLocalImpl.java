package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Desembolso;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.negocioQL
 * 01/08/2016 - 12:49 PM
 * Creado por aescobar
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class DesembolsoQLLocalImpl extends
        GenericQLLocalImpl<Desembolso, Long> implements
        DesembolsoQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}