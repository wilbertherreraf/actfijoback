/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.dao.EmpresaDao
 * 29/03/2016 - 11:02:08
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.dao;

import java.io.Serializable;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.util.Cttes;


@Stateless
public class PrePlanpagosDao extends GenericDao<PrePlanpagos, Integer> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;


    public PrePlanpagosDao() {
    }

    public PrePlanpagosDao(Class<PrePlanpagos> entityClass) {
        super(entityClass);
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}