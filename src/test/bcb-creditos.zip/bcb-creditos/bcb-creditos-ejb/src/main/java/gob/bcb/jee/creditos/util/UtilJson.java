/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.util.UtilJson
 * 21/03/2016 - 18:38:07
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.util;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Utilitario para la serialización y deserealización de objetos
 * 
 * 
 * @author ysalinas
 * 
 */
public class UtilJson<T>
{
  @SuppressWarnings("rawtypes")
  Class clazz;

  public UtilJson(@SuppressWarnings("rawtypes") Class clazz)
  {
    this.clazz = clazz;
  }

  public String toJson(T obj) throws IOException
  {
    ObjectMapper mapper = new ObjectMapper();
    return mapper.writeValueAsString(obj);
  }

  @SuppressWarnings("unchecked")
  public T toObject(String json) throws IOException
  {
    ObjectMapper mapper = new ObjectMapper();
    return (T) mapper.readValue(json, this.clazz);
  }

}
