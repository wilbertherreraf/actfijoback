package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.entidades
 * 01/08/2016 - 09:50 AM
 * Código base:
 * Creado por aescobar
 */

@Entity
@Table(name = "DESEMBOLSO")
@Getter
@Setter
@NamedQueries({
        @NamedQuery(name = Desembolso.ENTITY + Entidad.NQ_GET_LAZY, query = "select n from Desembolso n  where n.id=:id"),
        @NamedQuery(name = Desembolso.ENTITY + Entidad.NQ_SEARCH, query = "SELECT n FROM Desembolso n where n.proyecto.descripcion like :filtro "),
        @NamedQuery(name = Desembolso.NQ_SEARCH_ALL, query = "select n from Desembolso n  "),
        @NamedQuery(name = Desembolso.NQ_GET_DESEMBOLSOS_AUT_BY_PROYECTO, query = "select n from Desembolso n " +
                "where  n.proyecto.id = :proyectoId"),
        @NamedQuery(name = Desembolso.NQ_GET_DESEMBOLSOS_BY_PROYECTO, query = "select n from Desembolso n " +
                "where  n.proyecto.id = :proyectoId"),
        @NamedQuery(name = Desembolso.NQ_GET_DESEMBOLSOS_AUT_BY_PROYECTO_FECHA, query = "select n from Desembolso n " +
                "where  n.proyecto.id = :proyectoId AND n.fechaDesembolso <= :fecha"),
        @NamedQuery(name = Desembolso.NQ_GET_PRIMER_DESEMBOLSO, query = "select n from Desembolso n " +
                "where  n.numero = 1 and n.proyecto.id = :proyectoId"),
        @NamedQuery(name = Desembolso.NQ_GET_DESEMBOLSOS_AUT_BY_PROYECTO_DETALLE, query = "select new gob.bcb.jee.creditos.entidades.pojo.DesembolsoDetalle(n.id, n.fechaDesembolso,n.numero,n.monto,n.proyecto.id) from Desembolso n " +
                "where  n.proyecto.id = :proyectoId AND n.fechaDesembolso <= :fecha")
        })
public class Desembolso extends EntidadAutorizable<Long> {

    public static final String ENTITY = "Desembolso";
    public static final String NQ_SEARCH_ALL = ENTITY + "SearchAll";
    public static final String NQ_GET_PRIMER_DESEMBOLSO = ENTITY + "GetPrimerDesembolso";
    public static final String NQ_GET_DESEMBOLSOS_AUT_BY_PROYECTO = ENTITY + "GetDesembolsosAutByProyecto";
    public static final String NQ_GET_DESEMBOLSOS_AUT_BY_PROYECTO_FECHA = ENTITY + "GetDesembolsosAutByProyectofECHA";
    public static final String NQ_GET_DESEMBOLSOS_AUT_BY_PROYECTO_DETALLE = ENTITY + "GetDesembolsosAutByProyectoDetalle";
    public static final String NQ_GET_DESEMBOLSOS_BY_PROYECTO = ENTITY + "GetDesembolsosByProyecto";


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", updatable = false)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PROYECTO", referencedColumnName = "ID")
    private Proyecto proyecto;

    @Column(name = "FECHA_DESEMBOLSO", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fechaDesembolso;

    @Column(name = "FECHA_VENCIMIENTO")
    @Temporal(TemporalType.DATE)
    private Date fechaVencimiento;

    @Column(name = "NUMERO")
    private Integer numero;

    @Column(name = "MONTO", columnDefinition = "DECIMAL(15,2)",
            precision = 15, scale = 2, nullable = false)
    private BigDecimal monto;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "LOG_AUDITORIA_ID")
    private LogAuditoria logAuditoria;

    @Column(name = "SERIE_BONOS")
    private String serieBonos;

    @Column(name = "PAGO_INTERES")
    private String pagoInteres;

    @Column(name = "TIPO_CALCULO")
    private String tipoCalculo;

    @Column(name = "CUOTAS")
    private Integer cuotas;

    @OneToMany(mappedBy = "desembolso", cascade = {CascadeType.ALL})
    private List<Pago> pagos;

    @Override
    public String toString() {
        return "Desembolso{" +
                "id=" + id +
                ", proyecto=" + proyecto +
                ", fechaReporte=" + fechaDesembolso +
                ", fechaVencimiento=" + fechaVencimiento +
                ", numero=" + numero +
                ", monto=" + monto +
                ", logAuditoria=" + logAuditoria +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Desembolso)) return false;

        Desembolso that = (Desembolso) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (proyecto != null ? !proyecto.equals(that.proyecto) : that.proyecto != null) return false;
        if (fechaDesembolso != null ? !fechaDesembolso.equals(that.fechaDesembolso) : that.fechaDesembolso != null)
            return false;
        if (fechaVencimiento != null ? !fechaVencimiento.equals(that.fechaVencimiento) : that.fechaVencimiento != null)
            return false;
        if (numero != null ? !numero.equals(that.numero) : that.numero != null) return false;
        if (monto != null ? !monto.equals(that.monto) : that.monto != null) return false;
        return !(logAuditoria != null ? !logAuditoria.equals(that.logAuditoria) : that.logAuditoria != null);

    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (proyecto != null ? proyecto.hashCode() : 0);
        result = 31 * result + (fechaDesembolso != null ? fechaDesembolso.hashCode() : 0);
        result = 31 * result + (fechaVencimiento != null ? fechaVencimiento.hashCode() : 0);
        result = 31 * result + (numero != null ? numero.hashCode() : 0);
        result = 31 * result + (monto != null ? monto.hashCode() : 0);
        result = 31 * result + (logAuditoria != null ? logAuditoria.hashCode() : 0);
        return result;
    }

    public String getFechaDesembolsoFormat() {
        return getDateFormat(fechaDesembolso);
    }

    public String getFechaVencimientoFormat() {

        return getDateFormat(fechaVencimiento);
    }

    public String getMontoFormat(){
        return getDecimalDosFormat(monto);
    }
}
