package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;


import com.fasterxml.jackson.annotation.JsonIgnore;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;


/**
 * The persistent class for the gen_desctabla database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="gen_desctabla")
@NamedQuery(name="GenDesctabla.findAll", query="SELECT g FROM GenDesctabla g")
@NamedQueries({
    @NamedQuery(name = GenDesctabla.NQ_LIST_ALL, query = "SELECT p FROM GenDesctabla p "),
    @NamedQuery(name = GenDesctabla.NQ_LIST_BY_CODTAB, query = "SELECT p FROM GenDesctabla p where p.genDesctablaPK.desCodtab=:valor1 "),
    @NamedQuery(name = GenDesctabla.NQ_LIST_BY_CODTABCOD, query = "SELECT p FROM GenDesctabla p where p.genDesctablaPK.desCodtab=:valor1 and p.genDesctablaPK.desCodigo=:valor2 ")
    
})
public class GenDesctabla extends EntidadAutorizable<GenDesctablaPK> {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="GenDesctabla";
	  public static final String NQ_GET_BY_ID ="GetById";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";
	  public static final String NQ_LIST_BY_CODTAB = ENTITY + "ListByCodigo";
	  public static final String NQ_LIST_BY_CODTABCOD = ENTITY + "ListByTabCodigo";
	@EmbeddedId
	private GenDesctablaPK genDesctablaPK;

	@JsonIgnore
	@Column(name="des_auditfho")
	private Timestamp desAuditfho;

	@JsonIgnore
	@Column(name="des_auditusr")
	private String desAuditusr;

	@JsonIgnore
	@Column(name="des_auditwst")
	private String desAuditwst;

	@JsonIgnore
	@Column(name="des_codeiso")
	private String desCodeiso;

	@Column(name="des_descrip")
	private String desDescrip;

	@JsonIgnore
	@Column(name="des_status")
	private String desStatus;

	public GenDesctabla() {
	}


	@Override
	public GenDesctablaPK getId() { 
		return genDesctablaPK;
	}

	@Override
	public void setId(GenDesctablaPK id) {
		this.genDesctablaPK=id;
		
	}

}
