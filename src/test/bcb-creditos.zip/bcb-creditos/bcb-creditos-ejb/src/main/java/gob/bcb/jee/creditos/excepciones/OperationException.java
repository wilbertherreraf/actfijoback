/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.plantillaWebEE.excepciones.OperationException
 * 22/10/2015 - 09:38:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.excepciones;

/**
 * Clase para el manejo de las excepciones
 * 
 * 
 * @author ysalinas
 * 
 */
public class OperationException extends Exception
{

  private static final long serialVersionUID = 1L;

  private String codigoError;

  public String getCodigoError()
  {
    return codigoError;
  }

  public OperationException(String mensaje)
  {
    super(mensaje);
  }

  public OperationException(String mensaje, String codigoError)
  {
    super(mensaje);
    this.codigoError = codigoError;
  }

  public OperationException(String mensaje, Throwable e)
  {
    super(mensaje, e);
  }

  public OperationException(String mensaje, Throwable e, String codigoError)
  {
    super(mensaje, e);
    this.codigoError = codigoError;
  }

}
