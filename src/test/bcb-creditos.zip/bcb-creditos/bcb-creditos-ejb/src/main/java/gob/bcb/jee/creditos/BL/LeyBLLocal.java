/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.Ley;
import gob.bcb.jee.creditos.model.SacClaves;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;


@Local

public interface LeyBLLocal extends
    GenericBLLocal<Ley,Integer>
{
	public Integer getIdNuevo()throws OperationException ;
}
