package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PreCustodiaGarantiaQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PreCustodiaGarantiaDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreCustodiaGarantia;
import gob.bcb.jee.creditos.util.Cttes;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * PreCustodiaGarantiaBLLocalImpl
 *
 * @author mcramos
 * 21/02/2025
 */
@Stateless
@LocalBean
public class PreCustodiaGarantiaBLLocalImpl extends
        GenericBLLocalImpl<PreCustodiaGarantia, Integer> implements
        PreCustodiaGarantiaBLLocal {

    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;

    @Inject
    PreCustodiaGarantiaQLLocal preCustodiaGarantiaQLLocal;

    @Inject
    PreCustodiaGarantiaDao preCustodiaGarantiaDao;

    @Override
    public void validar(PreCustodiaGarantia entity) throws OperationException, EntityValidationException {

    }

    @Override
    public GenericQLLocal<PreCustodiaGarantia, Integer> getQLBean() {
        return preCustodiaGarantiaQLLocal;
    }

    @Override
    public GenericDao<PreCustodiaGarantia, Integer> getGenericDao() {
        return preCustodiaGarantiaDao;
    }

    @Override
    public PreCustodiaGarantia obtenerPorCodDesembolso(Integer pCodDesembolso) {
        return preCustodiaGarantiaQLLocal.obtenerPorCodDesembolso(pCodDesembolso);
    }

    @Override
    public Integer getEstadoCustodiaGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException {
        return preCustodiaGarantiaQLLocal.getEstadoCustodiaGarantia(codcred, codmod,coddsb);
    }
}

