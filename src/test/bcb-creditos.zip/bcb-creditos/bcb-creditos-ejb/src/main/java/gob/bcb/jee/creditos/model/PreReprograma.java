package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the pre_reprograma database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="pre_reprograma")
@NamedQuery(name="PreReprograma.findAll", query="SELECT p FROM PreReprograma p")
@NamedQueries({
    @NamedQuery(name = PreReprograma.NQ_GET_BY_ID, query = "SELECT e FROM PreReprograma e where e.rdsCodrepro = :rds_codrepro")  ,
    @NamedQuery(name = PreReprograma.NQ_GET_BY_CRED, query = "SELECT e FROM PreReprograma e where e.rdsCodcred=:valor1 and e.rdsCodmod=:valor2 and e.rdsTiporepro=:valor3 ") , 
    @NamedQuery(name = PreReprograma.NQ_GET_BY_CRED_PEND, query = "SELECT e FROM PreReprograma e where e.rdsCodcred=:valor1 and e.rdsCodmod=:valor2 and e.rdsTiporepro=:valor3  and e.rdsTrxstaau in (1,2) ")
})
public class PreReprograma extends EntidadAutorizable<Integer> implements Serializable {
	private static final long serialVersionUID = 1L;
	  public static final String ENTITY ="PreReprograma";
	  public static final String NQ_GET_BY_ID =ENTITY+"GetById";
	  public static final String NQ_GET_BY_CRED =ENTITY+"GetByCred";
	  public static final String NQ_GET_BY_CRED_PEND =ENTITY+"GetByCredPend";

	@Id
	@Column(name="rds_codrepro")
	private Integer rdsCodrepro;
	
	@Column(name="rds_codcred")
	private Integer rdsCodcred;
	
	@Column(name="rds_codmod")
	private Integer rdsCodmod;
	
	@Temporal(TemporalType.DATE)
	@Column(name="rds_fecini")
	private Date rdsFecini;
	
	@Temporal(TemporalType.DATE)
	@Column(name="rds_feciniint")
	private Date rdsFeciniint;
	
	@Temporal(TemporalType.DATE)
	@Column(name="rds_fecfin")
	private Date rdsFecfin;
	
	@Temporal(TemporalType.DATE)
	@Column(name="rds_feculttrx")
	private Date rdsFeculttrx;
		
	@Column(name="rds_valor")
	private BigDecimal rdsValor;
	
	@Column(name="rds_valorcuo")
	private BigDecimal rdsValorcuo;
	
	@Column(name="rds_undsb")
	private BigDecimal rdsUndsb;
	
	@Column(name="rds_saldo")
	private BigDecimal rdsSaldo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="rds_fecinidif")
	private Date rdsFecinidif;
	
	@Temporal(TemporalType.DATE)
	@Column(name="rds_fecfindif")
	private Date rdsFecfindif;
	
	@Column(name="rds_tabunidplaz")
	private Integer rdsTabunidplaz;/////////////////////
	
	@Column(name="rds_tasa")
	private Double rdsTasa;
	
	@Column(name="rds_unidplaz")
	private Integer rdsUnidplaz;
	
	@Column(name="rds_tabunidplazint")
	private Integer rdsTabunidplazint;
	
	@Column(name="rds_unidplazint")
	private Integer rdsUnidplazint;
	
	@Column(name="rds_nroperiodos")
	private Integer rdsNroperiodos;
	
	@Column(name="rds_nrogracia")
	private Integer rdsNrogracia;
	
	@Column(name="rds_nropagos")
	private Integer rdsNropagos;
	
	@Column(name="rds_diasfijoper")
	private Integer rdsDiasfijoper;
	
	@Column(name="rds_tabtrxstaau")
	private Integer rdsTabtrxstaau;
	
	@Column(name="rds_trxstaau")
	private Integer rdsTrxstaau;
	
	@Column(name="rds_tabstatreg")
	private Integer rdsTabstatreg;
	
	@Column(name="rds_statreg")
	private Integer rdsStatreg;
	
	@Column(name="rds_nrodoc")
	private String rdsNrodoc;
	
	@Column(name="rds_auditusr")
	private String rdsAuditusr;
	
	@Column(name="rds_auditwst")
	private String rdsAuditwst;

	@Temporal(TemporalType.DATE)
	@Column(name="rds_auditfho")
	private Date rdsAuditfho;
	
	@Column(name="rds_tabtiporepro")
	private Integer rdsTabtiporepro;
	
	@Column(name="rds_tiporepro")
	private Integer rdsTiporepro;

	@Column(name="rds_tipo_pago")
	private String rdsTipoPago;

	@Column(name="rds_saldo_interes_pago_anticipado")
	private BigDecimal rdsSaldointerespagoanticipado;


	public PreReprograma() {
	}

	@Override
	public Integer getId() {
		return rdsCodrepro;
	}

	@Override
	public void setId(Integer id) {
		this.rdsCodrepro=id;		
	}

}
