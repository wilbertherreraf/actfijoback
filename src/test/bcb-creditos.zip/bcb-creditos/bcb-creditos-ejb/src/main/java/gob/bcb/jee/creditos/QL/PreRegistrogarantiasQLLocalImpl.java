package gob.bcb.jee.creditos.QL;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import gob.bcb.jee.creditos.entidades.PreRegistrogarantias;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;
import gob.bcb.jee.creditos.util.Cttes;
import gob.bcb.jee.creditos.util.Log;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PreRegistrogarantiasQLLocalImpl extends
        GenericQLLocalImpl<PreRegistrogarantias, Integer> implements PreRegistrogarantiasQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

    public PreRegistrogarantias buscarPorId(Integer id) {
        String nativeQuery = " select t from PreRegistrogarantias t where t.id=:id ";

        Query query = entityManager.createQuery(nativeQuery).setParameter("id", id);
        List result = query.getResultList();
        if (result.size() > 0) {
            return (PreRegistrogarantias) result.get(0);
        }

        return null;
    }

    public PreRegistrogarantias guardarRegGar(PreRegistrogarantias entity) {
        try {
            if (entity.getId() == null) {
                entityManager.persist(entity);
                PreRegistrogarantias d = buscarPorId(entity.getId());
                return d;
            } else {
                PreRegistrogarantias d = entityManager.merge(entity);
                return d;
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public List<Object[]> getParametrosGlosa(Integer tipoOperacion) throws OperationException {
        String nativeQuery = "execute procedure p_get_par_comprobante(:tipoOperacion)";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("tipoOperacion", tipoOperacion);

        List<Object[]> results = query.getResultList();

        if (results == null || results.isEmpty()) {
            throw new OperationException("No se pudo obtener los parametros del crédito");
        }
        return results;
    }

    @Override
    public Integer getNumeroTotalDesembolso(Integer codcred, Integer codmod) throws OperationException {
        String nativeQuery = " SELECT count(1) total  " +
                " from d_creditos.pre_desemb " +
                " where dsb_codmod=:codmod " +
                " and dsb_codcred=:codcred " +
                " and dsb_trxstaau= 3 ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);

        Object valor1 = query.getSingleResult();
        Integer total = 0;

        return (valor1 != null) ? ((Number) valor1).intValue() : 0;
    }

    @Override
    public String getNumeroSerieGarantia(Integer codcred, Integer codmod, Integer coddsb) throws OperationException {
        Object valor = null;
        try {

            String nativeQuery = "SELECT gard_claveserie  " +
                    " from d_creditos.pre_garantiad " +
                    " where gard_codmod=:codmod " +
                    " and gard_codcred=:codcred " +
                    " and gard_coddsb=:coddsb  ";

            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("codcred", codcred);
            query.setParameter("codmod", codmod);
            query.setParameter("coddsb", coddsb);

            valor = query.getSingleResult();

            if (valor != null) {
                return valor.toString();
            }

        } catch (Exception e) {
            // se encontro mas de un nro de serie
            String error = "El desembolso cuenta con mas de un Número de serie. Revisar datos del desembolso. ";
            throw new OperationException(error);
        }

        return (valor != null ? valor.toString() : "");
    }

    @Override
    public Integer getEstadoGarantia(Integer codcred, Integer codmod, Integer coddsb) throws OperationException {
        String nativeQuery = " SELECT NVL(r.estado, 0) as estado  " +
                " FROM (SELECT 0 as estado FROM systables WHERE tabid = 1) dummy " +
                " LEFT JOIN d_creditos.pre_registrogarantias r " +
                " ON r.codmod=:codmod " +
                " and codcred=:codcred " +
                " and coddsb=:coddsb  " +
                " and r.estado IN (1,2,3)  ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("coddsb", coddsb);

        Object valor = query.getSingleResult();

        if (valor != null) {
            return (int) valor;
        }
        return 0;
    }

    public String generarCmpbBonos(Integer idTable, Integer tipoOperacion, Integer codcred, Integer codmod,
            Date fecha, String glosa, String usuario, String host) {

        String nativeQuery = " execute procedure p_generar_comprobante_registro_bonos(:idTable,  :tipoOperacion,  :codcred,  :codmod,  :fecha,  :glosa,  :usuario, :host)  ";
        Log.Info("En generarCmpbBonos p_generar_comprobante_registro_bonos idTable: " + idTable + " tipoOperacion: "
                + tipoOperacion + " codcred: " + codcred + " codmod: " + codmod);
        try {
            Query query = entityManager.createNativeQuery(nativeQuery);
            query.setParameter("idTable", idTable);
            query.setParameter("tipoOperacion", tipoOperacion);
            query.setParameter("codcred", codcred);
            query.setParameter("codmod", codmod);
            query.setParameter("fecha", fecha);
            query.setParameter("glosa", glosa);
            query.setParameter("usuario", usuario);
            query.setParameter("host", host);

            Object valor = query.getSingleResult();
            Log.Info("==> FIN generarCmpbBonos p_generar_comprobante_registro_bonos idTable: " + idTable
                    + " tipoOperacion: "
                    + tipoOperacion + " codcred: " + codcred + " NROCOMPROB: " + valor);
            if (valor != null) {
                return valor.toString();
            }
            return null;
        } catch (Exception e) {
            Log.Error("Exception: " + e.getMessage());
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
                if (cause instanceof SQLException) {
                    count++;
                    sb.append(cause.getMessage());
                    sb.append(" , ");
                }
            }
            String consent = (count > 0 ? sb.toString().replace(", null ,", "")
                    : "Error :" + e.getMessage().replace(", null ,", ""));
            throw new RuntimeException("Error p_generar_comprobante_registro_bonos: " + consent, e);
        }
    }

    @Override
    public Integer verificarRegistroTransitorioGarantias(Integer codcred, Integer codmod, Integer coddsb)
            throws OperationException {
        String nativeQuery = " SELECT COUNT(*) " +
                " FROM d_creditos.pre_registrogarantias r " +
                " WHERE r.codmod=:codmod " +
                " and codcred=:codcred " +
                " and coddsb=:coddsb  " +
                " and r.estado=3  ";

        Query query = entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("coddsb", coddsb);

        Object valor = query.getSingleResult();

        if (valor != null) {

            if (valor instanceof BigDecimal) {
                return ((BigDecimal) valor).intValue(); // Convertir BigDecimal a int
            } else if (valor instanceof Integer) {
                return (Integer) valor; // Si ya es un Integer, simplemente lo devolvemos
            } else {
                throw new IllegalArgumentException("El valor no es de un tipo compatible.");
            }
        }
        return 0;
    }

    @Override
    public PreRegistrogarantias obtenerPorCodDesembolso(Integer pCodDesembolso) {

        PreRegistrogarantias preRegistrogarantias = new PreRegistrogarantias();
        String nativeQuery = " SELECT * FROM d_creditos.pre_registrogarantias WHERE coddsb = :coddsb and estado  IN (1,2,3) ";// 4:anulado,
                                                                                                                              // 5:cancelado

        try {
            Query query = entityManager.createNativeQuery(nativeQuery, PreRegistrogarantias.class)
                    .setParameter("coddsb", pCodDesembolso);
            preRegistrogarantias = (PreRegistrogarantias) query.getSingleResult();

        } catch (NoResultException e) {
            preRegistrogarantias = new PreRegistrogarantias();
        }
        return preRegistrogarantias;
    }
}
