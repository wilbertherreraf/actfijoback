/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Parametro;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.CliPersona;
import gob.bcb.jee.creditos.model.GenTipproducto;
import gob.bcb.jee.creditos.model.GenTipproductoPK;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 * Implementacion de los metodos de consulta (QL) para la entidad Empresa
 *
 * @author ysalinas
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class GenTipProductoQLLocalImpl extends
        GenericQLLocalImpl<GenTipproducto, GenTipproductoPK> implements
        GenTipProductoQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /*
     * (non-Javadoc)
     * @see
     * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
     * ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
    @Override
    public Integer getIdNewId(Integer codmod) throws OperationException{
    	String nativeQuery="select max(tpd_codprod) from gen_tipproducto where tpd_codmod=:valor1";
		Query query=entityManager.createNativeQuery(nativeQuery);
		query.setParameter("valor1", codmod);
		Object valor=query.getSingleResult();
		int id=1;
		if(valor!=null) {
			id=Integer.parseInt(valor.toString())+1;
		}
		return id;
    }
}
