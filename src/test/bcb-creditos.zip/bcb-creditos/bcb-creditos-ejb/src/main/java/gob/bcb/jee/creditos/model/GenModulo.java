package gob.bcb.jee.creditos.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;


/**
 * The persistent class for the gen_modulo database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = "gen_modulo")
@NamedQuery(name = "GenModulo.findAll", query = "SELECT g FROM GenModulo g")
public class GenModulo extends EntidadAutorizable<Integer> implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "mod_codmod")
	private Integer modCodmod;

	@Column(name = "mod_abrevia")
	private String modAbrevia;

	@Column(name = "mod_nombre")
	private String modNombre;

	@Override
	public Integer getId() {
		
		return this.modCodmod;
	}

	@Override
	public void setId(Integer id) {
		this.modCodmod=id;
		
	}

}
