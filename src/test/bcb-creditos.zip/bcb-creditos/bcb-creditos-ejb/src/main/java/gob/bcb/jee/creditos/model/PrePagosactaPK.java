package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the pre_pagosacta database table.
 * 
 */
@Embeddable
public class PrePagosactaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="pac_codmod", insertable=false, updatable=false)
	private Integer pacCodmod;

	@Column(name="pac_sec")
	private Integer pacSec;

	public PrePagosactaPK() {
	}
	public Integer getPacCodmod() {
		return this.pacCodmod;
	}
	public void setPacCodmod(Integer pacCodmod) {
		this.pacCodmod = pacCodmod;
	}
	public Integer getPacSec() {
		return this.pacSec;
	}
	public void setPacSec(Integer pacSec) {
		this.pacSec = pacSec;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PrePagosactaPK)) {
			return false;
		}
		PrePagosactaPK castOther = (PrePagosactaPK)other;
		return 
			(this.pacCodmod == castOther.pacCodmod)
			&& (this.pacSec == castOther.pacSec);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.pacCodmod;
		hash = hash * prime + this.pacSec;
		
		return hash;
	}
}
