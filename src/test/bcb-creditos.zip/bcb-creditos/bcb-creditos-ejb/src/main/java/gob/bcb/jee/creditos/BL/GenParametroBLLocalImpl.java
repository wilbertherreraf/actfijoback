package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.QL.GenParametroQLLocal;
import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.dao.GenParametroDao;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.entidades.GenParametro;
import gob.bcb.jee.creditos.enums.EnumGenTipoParametro;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.pojo.*;
import gob.bcb.jee.creditos.util.Cttes;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * GenParametroBLLocalImpl
 *
 * @author mcramos
 * 13/01/2025
 */
@Stateless
@LocalBean
public class GenParametroBLLocalImpl extends
        GenericBLLocalImpl<GenParametro, Integer> implements GenParametroBLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;

    @Inject
    GenParametroQLLocal genParametroQLLocal;

    @Inject
    GenParametroDao genParametroDao;

    @Override
    public void validar(GenParametro entity) throws OperationException, EntityValidationException {

    }

    @Override
    public GenericQLLocal<GenParametro, Integer> getQLBean() {
        return genParametroQLLocal;
    }

    @Override
    public GenericDao<GenParametro, Integer> getGenericDao() {
        return genParametroDao;
    }

    @Override
    public RespuestaOperacion guardarParametros(GenParametroDto pGenParametroDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion) {
        log.info("guardarParametros|| Ingresa");
        RespuestaOperacion respuestaOperacion = new RespuestaOperacion();

        try {
            guardaDesembolso(pGenParametroDto.getGenParametroDesembolsoDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            guardaRegistroTransitorioBonos(pGenParametroDto.getGenParametroRegTransitorioBonoDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            guardaDevengadoInteres(pGenParametroDto.getGenParametroDevengadoIntDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            guardaIngresoCustodiaBonosTesoreria(pGenParametroDto.getGenParametroIngCustodiaBonoTesoreriaDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            guardaAmortizacionCapital(pGenParametroDto.getGenParametroAmortizacionCapitalDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            guardarRetiroBonosTesoreria(pGenParametroDto.getGenParametroRetiroBonoTesoreriaDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            guardarPagoInteses(pGenParametroDto.getGenParametroPagoInteresDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            guardarCertificacionPresupuestaria(pGenParametroDto.getGenParametroCertificacionPresupuestariaDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            guardarUtilesEscritorio(pGenParametroDto.getGenParametroUtilEscritorioDto(), pCodcred, pCodmod, pUsuario, pEstacion);

            respuestaOperacion.setEsValid(Boolean.TRUE);
        }catch (Exception e){
            log.error("Excepcion al guardarParametros: "+e.getMessage());
            respuestaOperacion.setMensaje("Ocurri³ un problema al guardar los parametros.");
            respuestaOperacion.setEsValid(Boolean.FALSE);
        }

        log.info("guardarParametros|| Sale");
        return respuestaOperacion;
    }

    public void guardaDesembolso(GenParametroDesembolsoDto pGenParametroDesembolsoDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("guardaDesembolso|| Registro de desembolso DEBITO");
            pGenParametroDesembolsoDto.getDebito().setParCodcred(pCodcred);
            pGenParametroDesembolsoDto.getDebito().setParCodmod(pCodmod);
            pGenParametroDesembolsoDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_DESEMBOLSO_CREDITO_DEBE.getValor());
            pGenParametroDesembolsoDto.getDebito().setParTabestado(1901);
            pGenParametroDesembolsoDto.getDebito().setParEstado(1);
            pGenParametroDesembolsoDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroDesembolsoDto.getDebito().setParAuditfho(new Date());
            pGenParametroDesembolsoDto.getDebito().setParAuditwst(pEstacion);
            persist(pGenParametroDesembolsoDto.getDebito(), pUsuario);

            log.info("guardaDesembolso|| Registro de desembolso ABONO");
            pGenParametroDesembolsoDto.getAbono().setParCodcred(pCodcred);
            pGenParametroDesembolsoDto.getAbono().setParCodmod(pCodmod);
            pGenParametroDesembolsoDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_DESEMBOLSO_CREDITO_HABER.getValor());
            pGenParametroDesembolsoDto.getAbono().setParTabestado(1901);
            pGenParametroDesembolsoDto.getAbono().setParEstado(1);
            pGenParametroDesembolsoDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroDesembolsoDto.getAbono().setParAuditfho(new Date());
            pGenParametroDesembolsoDto.getAbono().setParAuditwst(pEstacion);
            persist(pGenParametroDesembolsoDto.getAbono(), pUsuario);

            log.info("guardaDesembolso|| Registro de desembolso ESQUEMA");
            pGenParametroDesembolsoDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroDesembolsoDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroDesembolsoDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_DESEMBOLSO_CREDITO.getValor());
            pGenParametroDesembolsoDto.getEsquema().setParTabestado(1901);
            pGenParametroDesembolsoDto.getEsquema().setParEstado(1);
            pGenParametroDesembolsoDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroDesembolsoDto.getEsquema().setParAuditfho(new Date());
            pGenParametroDesembolsoDto.getEsquema().setParAuditwst(pEstacion);
            persist(pGenParametroDesembolsoDto.getEsquema(), pUsuario);
        }catch (Exception e){
            log.error("guardaDesembolso|| Excepcion: "+e.getMessage());
        }
    }

    public void guardaRegistroTransitorioBonos(GenParametroRegTransitorioBonoDto pGenParametroRegTransitorioBonoDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("guardaRegistroTransitorioBonos|| Registro DEBITO");
            pGenParametroRegTransitorioBonoDto.getDebito().setParCodcred(pCodcred);
            pGenParametroRegTransitorioBonoDto.getDebito().setParCodmod(pCodmod);
            pGenParametroRegTransitorioBonoDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_REGISTRO_TRANSITORIO_BONOS_DEBE.getValor());
            pGenParametroRegTransitorioBonoDto.getDebito().setParTabestado(1901);
            pGenParametroRegTransitorioBonoDto.getDebito().setParEstado(1);
            pGenParametroRegTransitorioBonoDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroRegTransitorioBonoDto.getDebito().setParAuditfho(new Date());
            pGenParametroRegTransitorioBonoDto.getDebito().setParAuditwst(pEstacion);
            persist(pGenParametroRegTransitorioBonoDto.getDebito(), pUsuario);

            log.info("guardaRegistroTransitorioBonos|| Registro ABONO");
            pGenParametroRegTransitorioBonoDto.getAbono().setParCodcred(pCodcred);
            pGenParametroRegTransitorioBonoDto.getAbono().setParCodmod(pCodmod);
            pGenParametroRegTransitorioBonoDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_REGISTRO_TRANSITORIO_BONOS_HABER.getValor());
            pGenParametroRegTransitorioBonoDto.getAbono().setParTabestado(1901);
            pGenParametroRegTransitorioBonoDto.getAbono().setParEstado(1);
            pGenParametroRegTransitorioBonoDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroRegTransitorioBonoDto.getAbono().setParAuditfho(new Date());
            pGenParametroRegTransitorioBonoDto.getAbono().setParAuditwst(pEstacion);
            persist(pGenParametroRegTransitorioBonoDto.getAbono(), pUsuario);

            log.info("guardaRegistroTransitorioBonos|| Registro ESQUEMA");
            pGenParametroRegTransitorioBonoDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_REGISTRO_TRANSITORIO_BONOS.getValor());
            pGenParametroRegTransitorioBonoDto.getEsquema().setParTabestado(1901);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParEstado(1);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParAuditfho(new Date());
            pGenParametroRegTransitorioBonoDto.getEsquema().setParAuditwst(pEstacion);
            persist(pGenParametroRegTransitorioBonoDto.getEsquema(), pUsuario);
        }catch (Exception e){
            log.error("guardaRegistroTransitorioBonos|| Excepcion: "+e.getMessage());
        }
    }

    public void guardaDevengadoInteres(GenParametroDevengadoIntDto pGenParametroDevengadoIntDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("guardaDevengadoInteres|| Registro DEBITO");
            pGenParametroDevengadoIntDto.getDebito().setParCodcred(pCodcred);
            pGenParametroDevengadoIntDto.getDebito().setParCodmod(pCodmod);
            pGenParametroDevengadoIntDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_DEVENGADO_INTERESES_DEBE.getValor());
            pGenParametroDevengadoIntDto.getDebito().setParTabestado(1901);
            pGenParametroDevengadoIntDto.getDebito().setParEstado(1);
            pGenParametroDevengadoIntDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroDevengadoIntDto.getDebito().setParAuditfho(new Date());
            pGenParametroDevengadoIntDto.getDebito().setParAuditwst(pEstacion);
            persist(pGenParametroDevengadoIntDto.getDebito(), pUsuario);

            log.info("guardaDevengadoInteres|| Registro ABONO");
            pGenParametroDevengadoIntDto.getAbono().setParCodcred(pCodcred);
            pGenParametroDevengadoIntDto.getAbono().setParCodmod(pCodmod);
            pGenParametroDevengadoIntDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_DEVENGADO_INTERESES_HABER.getValor());
            pGenParametroDevengadoIntDto.getAbono().setParTabestado(1901);
            pGenParametroDevengadoIntDto.getAbono().setParEstado(1);
            pGenParametroDevengadoIntDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroDevengadoIntDto.getAbono().setParAuditfho(new Date());
            pGenParametroDevengadoIntDto.getAbono().setParAuditwst(pEstacion);
            persist(pGenParametroDevengadoIntDto.getAbono(), pUsuario);

            log.info("guardaDevengadoInteres|| Registro ESQUEMA");
            pGenParametroDevengadoIntDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroDevengadoIntDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroDevengadoIntDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_DEVENGADO_INTERESES.getValor());
            pGenParametroDevengadoIntDto.getEsquema().setParTabestado(1901);
            pGenParametroDevengadoIntDto.getEsquema().setParEstado(1);
            pGenParametroDevengadoIntDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroDevengadoIntDto.getEsquema().setParAuditfho(new Date());
            pGenParametroDevengadoIntDto.getEsquema().setParAuditwst(pEstacion);
            persist(pGenParametroDevengadoIntDto.getEsquema(), pUsuario);
        }catch (Exception e){
            log.error("guardaDevengadoInteres|| Excepcion: "+e.getMessage());
        }
    }

    public void guardaIngresoCustodiaBonosTesoreria(GenParametroIngCustodiaBonoTesoreriaDto pGenParametroIngCustodiaBonoTesoreriaDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("guardaIngresoCustodiaBonosTesoreria|| Registro DEBITO");
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParCodcred(pCodcred);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParCodmod(pCodmod);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_DEBE.getValor());
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParTabestado(1901);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParEstado(1);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParAuditfho(new Date());
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParAuditwst(pEstacion);
            persist(pGenParametroIngCustodiaBonoTesoreriaDto.getDebito(), pUsuario);

            log.info("guardaIngresoCustodiaBonosTesoreria|| Registro ABONO");
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParCodcred(pCodcred);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParCodmod(pCodmod);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_HABER.getValor());
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParTabestado(1901);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParEstado(1);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParAuditfho(new Date());
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParAuditwst(pEstacion);
            persist(pGenParametroIngCustodiaBonoTesoreriaDto.getAbono(), pUsuario);

            log.info("guardaIngresoCustodiaBonosTesoreria|| Registro ESQUEMA");
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_INGRESO_CUSTODIA_BONOS_TESORERIA.getValor());
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParTabestado(1901);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParEstado(1);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParAuditfho(new Date());
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParAuditwst(pEstacion);
            persist(pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema(), pUsuario);
        }catch (Exception e){
            log.error("guardaIngresoCustodiaBonosTesoreria|| Excepcion: "+e.getMessage());
        }
    }

    public void guardaAmortizacionCapital(GenParametroAmortizacionCapitalDto pGenParametroAmortizacionCapitalDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("guardaAmortizacionCapital|| Registro DEBITO Cap. Int");
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParTprcod(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_CAP_INT_DEBE.getValor());
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParAuditwst(pEstacion);
            persist(pGenParametroAmortizacionCapitalDto.getDebitoCapInt(), pUsuario);


            log.info("guardaAmortizacionCapital|| Registro HABER Cap. Int");
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParTprcod(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_CAP_HABER.getValor());
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParAuditwst(pEstacion);
            persist(pGenParametroAmortizacionCapitalDto.getAbonoCapital(), pUsuario);


            log.info("guardarPagoInteses|| Registro ABONO int. gest. ant.");
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParTprcod(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_INT_GESTION_ANT_HABER.getValor());
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParAuditwst(pEstacion);
            persist(pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt(), pUsuario);

            log.info("guardaAmortizacionCapital|| Registro ABONO int. gest. Actual");
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParTprcod(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_INT_GESTION_ACTUAL_HABER.getValor());
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParAuditwst(pEstacion);
            persist(pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual(), pUsuario);

            log.info("guardaAmortizacionCapital|| Registro ESQUEMA");
            pGenParametroAmortizacionCapitalDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_AMORTIZACION_CAPITAL_PAGO_INTERESES.getValor());
            pGenParametroAmortizacionCapitalDto.getEsquema().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getEsquema().setParAuditwst(pEstacion);
            persist(pGenParametroAmortizacionCapitalDto.getEsquema(), pUsuario);
        }catch (Exception e){
            log.error("guardaAmortizacionCapital|| Excepcion: "+e.getMessage());
        }
    }

    public void guardarRetiroBonosTesoreria(GenParametroRetiroBonoTesoreriaDto pGenParametroRetiroBonoTesoreriaDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("guardarRetiroBonosTesoreria|| Registro de desembolso DEBITO");
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParCodcred(pCodcred);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParCodmod(pCodmod);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_DEBE.getValor());
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParTabestado(1901);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParEstado(1);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParAuditfho(new Date());
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParAuditwst(pEstacion);
            persist(pGenParametroRetiroBonoTesoreriaDto.getDebito(), pUsuario);

            log.info("guardarRetiroBonosTesoreria|| Registro de desembolso ABONO");
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParCodcred(pCodcred);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParCodmod(pCodmod);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_HABER.getValor());
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParTabestado(1901);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParEstado(1);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParAuditfho(new Date());
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParAuditwst(pEstacion);
            persist(pGenParametroRetiroBonoTesoreriaDto.getAbono(), pUsuario);

            log.info("guardarRetiroBonosTesoreria|| Registro de desembolso ESQUEMA");
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_RETIRO_CUSTODIA_BONOS_TESORERIA.getValor());
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParTabestado(1901);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParEstado(1);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParAuditfho(new Date());
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParAuditwst(pEstacion);
            persist(pGenParametroRetiroBonoTesoreriaDto.getEsquema(), pUsuario);
        }catch (Exception e){
            log.error("guardarRetiroBonosTesoreria|| Excepcion: "+e.getMessage());
        }
    }

    public void guardarPagoInteses(GenParametroPagoInteresDto pGenParametroPagoInteresDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("guardarPagoInteses|| Registro DEBITO Int");
            pGenParametroPagoInteresDto.getDebitoInteres().setParCodcred(pCodcred);
            pGenParametroPagoInteresDto.getDebitoInteres().setParCodmod(pCodmod);
            pGenParametroPagoInteresDto.getDebitoInteres().setParTprcod(EnumGenTipoParametro.CUENTA_PAGO_INTERESES_INTERESES_DEBE.getValor());
            pGenParametroPagoInteresDto.getDebitoInteres().setParTabestado(1901);
            pGenParametroPagoInteresDto.getDebitoInteres().setParEstado(1);
            pGenParametroPagoInteresDto.getDebitoInteres().setParAuditusr(pUsuario);
            pGenParametroPagoInteresDto.getDebitoInteres().setParAuditfho(new Date());
            pGenParametroPagoInteresDto.getDebitoInteres().setParAuditwst(pEstacion);
            persist(pGenParametroPagoInteresDto.getDebitoInteres(), pUsuario);

            log.info("guardarPagoInteses|| Registro ABONO int. gest. ant.");
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParCodcred(pCodcred);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParCodmod(pCodmod);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParTprcod(EnumGenTipoParametro.CUENTA_PAGO_INTERESES_INT_GESTION_ANT_HABER.getValor());
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParTabestado(1901);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParEstado(1);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParAuditusr(pUsuario);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParAuditfho(new Date());
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParAuditwst(pEstacion);
            persist(pGenParametroPagoInteresDto.getAbonoIntGestAnt(), pUsuario);

            log.info("guardarPagoInteses|| Registro ABONO int. gest. Actual");
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParCodcred(pCodcred);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParCodmod(pCodmod);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParTprcod(EnumGenTipoParametro.CUENTA_PAGO_INTERESES_INT_GESTION_ACTUAL_HABER.getValor());
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParTabestado(1901);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParEstado(1);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParAuditusr(pUsuario);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParAuditfho(new Date());
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParAuditwst(pEstacion);
            persist(pGenParametroPagoInteresDto.getAbonoIntGestActual(), pUsuario);

            log.info("guardarPagoInteses|| Registro ESQUEMA");
            pGenParametroPagoInteresDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroPagoInteresDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroPagoInteresDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_PAGO_INTERESES.getValor());
            pGenParametroPagoInteresDto.getEsquema().setParTabestado(1901);
            pGenParametroPagoInteresDto.getEsquema().setParEstado(1);
            pGenParametroPagoInteresDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroPagoInteresDto.getEsquema().setParAuditfho(new Date());
            pGenParametroPagoInteresDto.getEsquema().setParAuditwst(pEstacion);
            persist(pGenParametroPagoInteresDto.getEsquema(), pUsuario);
        }catch (Exception e){
            log.error("guardarPagoInteses|| Excepcion: "+e.getMessage());
        }
    }

    public void guardarCertificacionPresupuestaria(GenParametroCertificacionPresupuestariaDto pGenParametroCertificacionPresupuestariaDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("guardarCertificacionPresupuestaria|| Registro Gestion anterior");
            pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParCodcred(pCodcred);
            pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParCodmod(pCodmod);
            pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParTprcod(EnumGenTipoParametro.GESTION_ANTERIOR_DEVENGADO_INTERESES.getValor());
            pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParTabestado(1901);
            pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParEstado(1);
            pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParAuditusr(pUsuario);
            pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParAuditfho(new Date());
            pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParAuditwst(pEstacion);
            persist(pGenParametroCertificacionPresupuestariaDto.getGestionAnterior(), pUsuario);

            log.info("guardarCertificacionPresupuestaria|| Registro ABONO int. gest. ant.");
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParCodcred(pCodcred);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParCodmod(pCodmod);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParTprcod(EnumGenTipoParametro.GESTION_ACTUAL_DEVENGADO_INTERESES.getValor());
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParTabestado(1901);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParEstado(1);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParAuditusr(pUsuario);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParAuditfho(new Date());
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParAuditwst(pEstacion);
            persist(pGenParametroCertificacionPresupuestariaDto.getGestionActual(), pUsuario);


            log.info("guardarCertificacionPresupuestaria|| Registro NOMBRE CORTO CREDITO");
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParCodcred(pCodcred);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParCodmod(pCodmod);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParTprcod(EnumGenTipoParametro.DESCRIPCION_CORTA_CREDITO.getValor());
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParTabestado(1901);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParEstado(1);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParAuditusr(pUsuario);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParAuditfho(new Date());
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParAuditwst(pEstacion);
            persist(pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito(), pUsuario);



        }catch (Exception e){
            log.error("guardarCertificacionPresupuestaria|| Excepcion: "+e.getMessage());
        }
    }

    public void guardarUtilesEscritorio(GenParametroUtilEscritorioDto pGenParametroUtilEscritorioDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("guardarUtilesEscritorio|| Registro de desembolso DEBITO");
            pGenParametroUtilEscritorioDto.getDebito().setParCodcred(pCodcred);
            pGenParametroUtilEscritorioDto.getDebito().setParCodmod(pCodmod);
            pGenParametroUtilEscritorioDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_UTILES_ESCRITORIO_DEBE.getValor());
            pGenParametroUtilEscritorioDto.getDebito().setParTabestado(1901);
            pGenParametroUtilEscritorioDto.getDebito().setParEstado(1);
            pGenParametroUtilEscritorioDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroUtilEscritorioDto.getDebito().setParAuditfho(new Date());
            pGenParametroUtilEscritorioDto.getDebito().setParAuditwst(pEstacion);
            persist(pGenParametroUtilEscritorioDto.getDebito(), pUsuario);

            log.info("guardarUtilesEscritorio|| Registro de desembolso ABONO 1");
            pGenParametroUtilEscritorioDto.getAbono1().setParCodcred(pCodcred);
            pGenParametroUtilEscritorioDto.getAbono1().setParCodmod(pCodmod);
            pGenParametroUtilEscritorioDto.getAbono1().setParTprcod(EnumGenTipoParametro.CUENTA_UTILES_ESCRITORIO_HABER.getValor());
            pGenParametroUtilEscritorioDto.getAbono1().setParTabestado(1901);
            pGenParametroUtilEscritorioDto.getAbono1().setParEstado(1);
            pGenParametroUtilEscritorioDto.getAbono1().setParAuditusr(pUsuario);
            pGenParametroUtilEscritorioDto.getAbono1().setParAuditfho(new Date());
            pGenParametroUtilEscritorioDto.getAbono1().setParAuditwst(pEstacion);
            persist(pGenParametroUtilEscritorioDto.getAbono1(), pUsuario);

            log.info("guardarUtilesEscritorio|| Registro de desembolso ABONO 2");
            pGenParametroUtilEscritorioDto.getAbono2().setParCodcred(pCodcred);
            pGenParametroUtilEscritorioDto.getAbono2().setParCodmod(pCodmod);
            pGenParametroUtilEscritorioDto.getAbono2().setParTprcod(EnumGenTipoParametro.CUENTA_UTILES_ESCRITORIO_HABER_SEGUNDO.getValor());
            pGenParametroUtilEscritorioDto.getAbono2().setParTabestado(1901);
            pGenParametroUtilEscritorioDto.getAbono2().setParEstado(1);
            pGenParametroUtilEscritorioDto.getAbono2().setParAuditusr(pUsuario);
            pGenParametroUtilEscritorioDto.getAbono2().setParAuditfho(new Date());
            pGenParametroUtilEscritorioDto.getAbono2().setParAuditwst(pEstacion);
            persist(pGenParametroUtilEscritorioDto.getAbono2(), pUsuario);

            log.info("guardarUtilesEscritorio|| Registro de desembolso ESQUEMA");
            pGenParametroUtilEscritorioDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroUtilEscritorioDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroUtilEscritorioDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_UTILES_ESCRITORIO.getValor());
            pGenParametroUtilEscritorioDto.getEsquema().setParTabestado(1901);
            pGenParametroUtilEscritorioDto.getEsquema().setParEstado(1);
            pGenParametroUtilEscritorioDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroUtilEscritorioDto.getEsquema().setParAuditfho(new Date());
            pGenParametroUtilEscritorioDto.getEsquema().setParAuditwst(pEstacion);
            persist(pGenParametroUtilEscritorioDto.getEsquema(), pUsuario);
        }catch (Exception e){
            log.error("guardarUtilesEscritorio|| Excepcion: "+e.getMessage());
        }
    }

    @Override
    public GenParametroDto recuperarPorCodCredito(Integer pCodcred) {
        log.info("recuperarPorCodCredito|| Ingresa");
        GenParametroDto genParametroDto = new GenParametroDto();

        try {
            List<GenParametro> listaGenParametro = genParametroQLLocal.obtenerPorCodCredito(pCodcred);

            if (!listaGenParametro.isEmpty()) {
                GenParametroDesembolsoDto genParametroDesembolso = new GenParametroDesembolsoDto();
                GenParametroRegTransitorioBonoDto genParametroRegTransitorioBono = new GenParametroRegTransitorioBonoDto();
                GenParametroDevengadoIntDto genParametroDevengadoInt = new GenParametroDevengadoIntDto();
                GenParametroIngCustodiaBonoTesoreriaDto genParametroIngCustodiaBonoTesoreria = new GenParametroIngCustodiaBonoTesoreriaDto();
                GenParametroAmortizacionCapitalDto genParametroAmortizacionCapital = new GenParametroAmortizacionCapitalDto();
                GenParametroRetiroBonoTesoreriaDto genParametroRetiroBonoTesoreria = new GenParametroRetiroBonoTesoreriaDto();
                GenParametroPagoInteresDto genParametroPagoInteres = new GenParametroPagoInteresDto();
                GenParametroCertificacionPresupuestariaDto genParametroCertificacionPresupuestaria = new GenParametroCertificacionPresupuestariaDto();
                GenParametroUtilEscritorioDto genParametroUtilEscritorio = new GenParametroUtilEscritorioDto();

                // Mapeamos parTprcod a su correspondiente GenParametro
                Map<Integer, GenParametro> parametroMap = listaGenParametro.stream()
                        .collect(Collectors.toMap(GenParametro::getParTprcod, valor -> valor));

                genParametroDesembolso.setDebito(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_DESEMBOLSO_CREDITO_DEBE.getValor(), new GenParametro()));
                genParametroDesembolso.setAbono(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_DESEMBOLSO_CREDITO_HABER.getValor(), new GenParametro()));
                genParametroDesembolso.setEsquema(parametroMap.getOrDefault(EnumGenTipoParametro.ESQUEMA_DESEMBOLSO_CREDITO.getValor(), new GenParametro()));
                genParametroDto.setGenParametroDesembolsoDto(genParametroDesembolso);

                genParametroRegTransitorioBono.setDebito(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_REGISTRO_TRANSITORIO_BONOS_DEBE.getValor(), new GenParametro()));
                genParametroRegTransitorioBono.setAbono(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_REGISTRO_TRANSITORIO_BONOS_HABER.getValor(), new GenParametro()));
                genParametroRegTransitorioBono.setEsquema(parametroMap.getOrDefault(EnumGenTipoParametro.ESQUEMA_REGISTRO_TRANSITORIO_BONOS.getValor(), new GenParametro()));
                genParametroDto.setGenParametroRegTransitorioBonoDto(genParametroRegTransitorioBono);

                genParametroDevengadoInt.setDebito(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_DEVENGADO_INTERESES_DEBE.getValor(), new GenParametro()));
                genParametroDevengadoInt.setAbono(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_DEVENGADO_INTERESES_HABER.getValor(), new GenParametro()));
                genParametroDevengadoInt.setEsquema(parametroMap.getOrDefault(EnumGenTipoParametro.ESQUEMA_DEVENGADO_INTERESES.getValor(), new GenParametro()));
                genParametroDto.setGenParametroDevengadoIntDto(genParametroDevengadoInt);

                genParametroIngCustodiaBonoTesoreria.setDebito(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_DEBE.getValor(), new GenParametro()));
                genParametroIngCustodiaBonoTesoreria.setAbono(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_HABER.getValor(), new GenParametro()));
                genParametroIngCustodiaBonoTesoreria.setEsquema(parametroMap.getOrDefault(EnumGenTipoParametro.ESQUEMA_INGRESO_CUSTODIA_BONOS_TESORERIA.getValor(), new GenParametro()));
                genParametroDto.setGenParametroIngCustodiaBonoTesoreriaDto(genParametroIngCustodiaBonoTesoreria);

                genParametroAmortizacionCapital.setDebitoCapInt(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_CAP_INT_DEBE.getValor(), new GenParametro()));
                genParametroAmortizacionCapital.setAbonoCapital(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_CAP_HABER.getValor(), new GenParametro()));
                genParametroAmortizacionCapital.setAbonoIntGestAnt(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_INT_GESTION_ANT_HABER.getValor(), new GenParametro()));
                genParametroAmortizacionCapital.setAbonoIntGestActual(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_INT_GESTION_ACTUAL_HABER.getValor(), new GenParametro()));
                genParametroAmortizacionCapital.setEsquema(parametroMap.getOrDefault(EnumGenTipoParametro.ESQUEMA_AMORTIZACION_CAPITAL_PAGO_INTERESES.getValor(), new GenParametro()));
                genParametroDto.setGenParametroAmortizacionCapitalDto(genParametroAmortizacionCapital);

                genParametroRetiroBonoTesoreria.setDebito(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_DEBE.getValor(), new GenParametro()));
                genParametroRetiroBonoTesoreria.setAbono(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_HABER.getValor(), new GenParametro()));
                genParametroRetiroBonoTesoreria.setEsquema(parametroMap.getOrDefault(EnumGenTipoParametro.ESQUEMA_RETIRO_CUSTODIA_BONOS_TESORERIA.getValor(), new GenParametro()));
                genParametroDto.setGenParametroRetiroBonoTesoreriaDto(genParametroRetiroBonoTesoreria);

                genParametroPagoInteres.setDebitoInteres(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_PAGO_INTERESES_INTERESES_DEBE.getValor(), new GenParametro()));
                genParametroPagoInteres.setAbonoIntGestAnt(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_PAGO_INTERESES_INT_GESTION_ANT_HABER.getValor(), new GenParametro()));
                genParametroPagoInteres.setAbonoIntGestActual(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_PAGO_INTERESES_INT_GESTION_ACTUAL_HABER.getValor(), new GenParametro()));
                genParametroPagoInteres.setEsquema(parametroMap.getOrDefault(EnumGenTipoParametro.ESQUEMA_PAGO_INTERESES.getValor(), new GenParametro()));
                genParametroDto.setGenParametroPagoInteresDto(genParametroPagoInteres);

                genParametroCertificacionPresupuestaria.setGestionAnterior(parametroMap.getOrDefault(EnumGenTipoParametro.GESTION_ANTERIOR_DEVENGADO_INTERESES.getValor(), new GenParametro()));
                genParametroCertificacionPresupuestaria.setGestionActual(parametroMap.getOrDefault(EnumGenTipoParametro.GESTION_ACTUAL_DEVENGADO_INTERESES.getValor(), new GenParametro()));
                genParametroCertificacionPresupuestaria.setNomCortoCredito(parametroMap.getOrDefault(EnumGenTipoParametro.DESCRIPCION_CORTA_CREDITO.getValor(), new GenParametro()));
                genParametroDto.setGenParametroCertificacionPresupuestariaDto(genParametroCertificacionPresupuestaria);

                genParametroUtilEscritorio.setDebito(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_UTILES_ESCRITORIO_DEBE.getValor(), new GenParametro()));
                genParametroUtilEscritorio.setAbono1(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_UTILES_ESCRITORIO_HABER.getValor(), new GenParametro()));
                genParametroUtilEscritorio.setAbono2(parametroMap.getOrDefault(EnumGenTipoParametro.CUENTA_UTILES_ESCRITORIO_HABER_SEGUNDO.getValor(), new GenParametro()));
                genParametroUtilEscritorio.setEsquema(parametroMap.getOrDefault(EnumGenTipoParametro.ESQUEMA_UTILES_ESCRITORIO.getValor(), new GenParametro()));
                genParametroDto.setGenParametroUtilEscritorioDto(genParametroUtilEscritorio);
            }

        }catch (Exception e){
            log.error("Excepcion al recuperar GenParametro por CodCredito: "+e.getMessage());
        }

        log.info("recuperarPorCodCredito|| Sale");
        return genParametroDto;
    }

    @Override
    public RespuestaOperacion modificarParametros(GenParametroDto pGenParametroDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion) {
        log.info("modificarParametros|| Ingresa");
        RespuestaOperacion respuestaOperacion = new RespuestaOperacion();

        try {
            modificarDesembolso(pGenParametroDto.getGenParametroDesembolsoDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            modificarRegistroTransitorioBonos(pGenParametroDto.getGenParametroRegTransitorioBonoDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            modificarDevengadoInteres(pGenParametroDto.getGenParametroDevengadoIntDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            modificarIngresoCustodiaBonosTesoreria(pGenParametroDto.getGenParametroIngCustodiaBonoTesoreriaDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            modificarAmortizacionCapital(pGenParametroDto.getGenParametroAmortizacionCapitalDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            modificarRetiroBonosTesoreria(pGenParametroDto.getGenParametroRetiroBonoTesoreriaDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            modificarPagoInteses(pGenParametroDto.getGenParametroPagoInteresDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            modificarCertificacionPresupuestaria(pGenParametroDto.getGenParametroCertificacionPresupuestariaDto(), pCodcred, pCodmod, pUsuario, pEstacion);
            modificarUtilesEscritorio(pGenParametroDto.getGenParametroUtilEscritorioDto(), pCodcred, pCodmod, pUsuario, pEstacion);

            respuestaOperacion.setEsValid(Boolean.TRUE);

            respuestaOperacion.setEsValid(Boolean.TRUE);
        }catch (Exception e){
            log.error("Excepcion al modificarParametros: "+e.getMessage());
            respuestaOperacion.setMensaje("Ocurri³ un problema al guardar los parametros.");
            respuestaOperacion.setEsValid(Boolean.FALSE);
        }

        log.info("modificarParametros|| Sale");
        return respuestaOperacion;
    }



    public void modificarDesembolso(GenParametroDesembolsoDto pGenParametroDesembolsoDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("modificarDesembolso|| Registro de desembolso DEBITO");
            pGenParametroDesembolsoDto.getDebito().setParCodcred(pCodcred);
            pGenParametroDesembolsoDto.getDebito().setParCodmod(pCodmod);
            pGenParametroDesembolsoDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_DESEMBOLSO_CREDITO_DEBE.getValor());
            pGenParametroDesembolsoDto.getDebito().setParTabestado(1901);
            pGenParametroDesembolsoDto.getDebito().setParEstado(1);
            pGenParametroDesembolsoDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroDesembolsoDto.getDebito().setParAuditfho(new Date());
            pGenParametroDesembolsoDto.getDebito().setParAuditwst(pEstacion);
            if (pGenParametroDesembolsoDto.getDebito()==null){
                persist(pGenParametroDesembolsoDto.getDebito(), pUsuario);
            }else{
                merge(pGenParametroDesembolsoDto.getDebito(), pUsuario);
            }

            log.info("modificarDesembolso|| Registro de desembolso ABONO");
            pGenParametroDesembolsoDto.getAbono().setParCodcred(pCodcred);
            pGenParametroDesembolsoDto.getAbono().setParCodmod(pCodmod);
            pGenParametroDesembolsoDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_DESEMBOLSO_CREDITO_HABER.getValor());
            pGenParametroDesembolsoDto.getAbono().setParTabestado(1901);
            pGenParametroDesembolsoDto.getAbono().setParEstado(1);
            pGenParametroDesembolsoDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroDesembolsoDto.getAbono().setParAuditfho(new Date());
            pGenParametroDesembolsoDto.getAbono().setParAuditwst(pEstacion);
            if (pGenParametroDesembolsoDto.getAbono()==null){
                persist(pGenParametroDesembolsoDto.getAbono(), pUsuario);
            }else{
                merge(pGenParametroDesembolsoDto.getAbono(), pUsuario);
            }

            log.info("modificarDesembolso|| Registro de desembolso ESQUEMA");
            pGenParametroDesembolsoDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroDesembolsoDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroDesembolsoDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_DESEMBOLSO_CREDITO.getValor());
            pGenParametroDesembolsoDto.getEsquema().setParTabestado(1901);
            pGenParametroDesembolsoDto.getEsquema().setParEstado(1);
            pGenParametroDesembolsoDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroDesembolsoDto.getEsquema().setParAuditfho(new Date());
            pGenParametroDesembolsoDto.getEsquema().setParAuditwst(pEstacion);
            if (pGenParametroDesembolsoDto.getEsquema()==null){
                persist(pGenParametroDesembolsoDto.getEsquema(), pUsuario);
            }else{
                merge(pGenParametroDesembolsoDto.getEsquema(), pUsuario);
            }
        }catch (Exception e){
            log.error("modificarDesembolso|| Excepcion: "+e.getMessage());
        }
    }

    public void modificarRegistroTransitorioBonos(GenParametroRegTransitorioBonoDto pGenParametroRegTransitorioBonoDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("modificarRegistroTransitorioBonos|| Registro DEBITO");
            pGenParametroRegTransitorioBonoDto.getDebito().setParCodcred(pCodcred);
            pGenParametroRegTransitorioBonoDto.getDebito().setParCodmod(pCodmod);
            pGenParametroRegTransitorioBonoDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_REGISTRO_TRANSITORIO_BONOS_DEBE.getValor());
            pGenParametroRegTransitorioBonoDto.getDebito().setParTabestado(1901);
            pGenParametroRegTransitorioBonoDto.getDebito().setParEstado(1);
            pGenParametroRegTransitorioBonoDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroRegTransitorioBonoDto.getDebito().setParAuditfho(new Date());
            pGenParametroRegTransitorioBonoDto.getDebito().setParAuditwst(pEstacion);
            if (pGenParametroRegTransitorioBonoDto.getDebito()==null){
                persist(pGenParametroRegTransitorioBonoDto.getDebito(), pUsuario);
            }else{
                merge(pGenParametroRegTransitorioBonoDto.getDebito(), pUsuario);
            }

            log.info("modificarRegistroTransitorioBonos|| Registro ABONO");
            pGenParametroRegTransitorioBonoDto.getAbono().setParCodcred(pCodcred);
            pGenParametroRegTransitorioBonoDto.getAbono().setParCodmod(pCodmod);
            pGenParametroRegTransitorioBonoDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_REGISTRO_TRANSITORIO_BONOS_HABER.getValor());
            pGenParametroRegTransitorioBonoDto.getAbono().setParTabestado(1901);
            pGenParametroRegTransitorioBonoDto.getAbono().setParEstado(1);
            pGenParametroRegTransitorioBonoDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroRegTransitorioBonoDto.getAbono().setParAuditfho(new Date());
            pGenParametroRegTransitorioBonoDto.getAbono().setParAuditwst(pEstacion);
            if (pGenParametroRegTransitorioBonoDto.getAbono()==null){
                persist(pGenParametroRegTransitorioBonoDto.getAbono(), pUsuario);
            }else{
                merge(pGenParametroRegTransitorioBonoDto.getAbono(), pUsuario);
            }

            log.info("modificarRegistroTransitorioBonos|| Registro ESQUEMA");
            pGenParametroRegTransitorioBonoDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_REGISTRO_TRANSITORIO_BONOS.getValor());
            pGenParametroRegTransitorioBonoDto.getEsquema().setParTabestado(1901);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParEstado(1);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroRegTransitorioBonoDto.getEsquema().setParAuditfho(new Date());
            pGenParametroRegTransitorioBonoDto.getEsquema().setParAuditwst(pEstacion);
            if (pGenParametroRegTransitorioBonoDto.getEsquema()==null){
                persist(pGenParametroRegTransitorioBonoDto.getEsquema(), pUsuario);
            }else{
                merge(pGenParametroRegTransitorioBonoDto.getEsquema(), pUsuario);
            }
        }catch (Exception e){
            log.error("modificarRegistroTransitorioBonos|| Excepcion: "+e.getMessage());
        }
    }

    public void modificarDevengadoInteres(GenParametroDevengadoIntDto pGenParametroDevengadoIntDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("modificarDevengadoInteres|| Registro DEBITO");
            pGenParametroDevengadoIntDto.getDebito().setParCodcred(pCodcred);
            pGenParametroDevengadoIntDto.getDebito().setParCodmod(pCodmod);
            pGenParametroDevengadoIntDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_DEVENGADO_INTERESES_DEBE.getValor());
            pGenParametroDevengadoIntDto.getDebito().setParTabestado(1901);
            pGenParametroDevengadoIntDto.getDebito().setParEstado(1);
            pGenParametroDevengadoIntDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroDevengadoIntDto.getDebito().setParAuditfho(new Date());
            pGenParametroDevengadoIntDto.getDebito().setParAuditwst(pEstacion);
            if (pGenParametroDevengadoIntDto.getDebito()==null){
                persist(pGenParametroDevengadoIntDto.getDebito(), pUsuario);
            }else{
                merge(pGenParametroDevengadoIntDto.getDebito(), pUsuario);
            }

            log.info("modificarDevengadoInteres|| Registro ABONO");
            pGenParametroDevengadoIntDto.getAbono().setParCodcred(pCodcred);
            pGenParametroDevengadoIntDto.getAbono().setParCodmod(pCodmod);
            pGenParametroDevengadoIntDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_DEVENGADO_INTERESES_HABER.getValor());
            pGenParametroDevengadoIntDto.getAbono().setParTabestado(1901);
            pGenParametroDevengadoIntDto.getAbono().setParEstado(1);
            pGenParametroDevengadoIntDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroDevengadoIntDto.getAbono().setParAuditfho(new Date());
            pGenParametroDevengadoIntDto.getAbono().setParAuditwst(pEstacion);
            if (pGenParametroDevengadoIntDto.getAbono()==null){
                persist(pGenParametroDevengadoIntDto.getAbono(), pUsuario);
            }else{
                merge(pGenParametroDevengadoIntDto.getAbono(), pUsuario);
            }

            log.info("modificarDevengadoInteres|| Registro ESQUEMA");
            pGenParametroDevengadoIntDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroDevengadoIntDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroDevengadoIntDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_DEVENGADO_INTERESES.getValor());
            pGenParametroDevengadoIntDto.getEsquema().setParTabestado(1901);
            pGenParametroDevengadoIntDto.getEsquema().setParEstado(1);
            pGenParametroDevengadoIntDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroDevengadoIntDto.getEsquema().setParAuditfho(new Date());
            pGenParametroDevengadoIntDto.getEsquema().setParAuditwst(pEstacion);
            if (pGenParametroDevengadoIntDto.getEsquema()==null){
                persist(pGenParametroDevengadoIntDto.getEsquema(), pUsuario);
            }else{
                merge(pGenParametroDevengadoIntDto.getEsquema(), pUsuario);
            }
        }catch (Exception e){
            log.error("modificarDevengadoInteres|| Excepcion: "+e.getMessage());
        }
    }

    public void modificarIngresoCustodiaBonosTesoreria(GenParametroIngCustodiaBonoTesoreriaDto pGenParametroIngCustodiaBonoTesoreriaDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("modificarIngresoCustodiaBonosTesoreria|| Registro DEBITO");
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParCodcred(pCodcred);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParCodmod(pCodmod);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_DEBE.getValor());
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParTabestado(1901);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParEstado(1);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParAuditfho(new Date());
            pGenParametroIngCustodiaBonoTesoreriaDto.getDebito().setParAuditwst(pEstacion);
            if (pGenParametroIngCustodiaBonoTesoreriaDto.getDebito()==null){
                persist(pGenParametroIngCustodiaBonoTesoreriaDto.getDebito(), pUsuario);
            }else{
                merge(pGenParametroIngCustodiaBonoTesoreriaDto.getDebito(), pUsuario);
            }

            log.info("modificarIngresoCustodiaBonosTesoreria|| Registro ABONO");
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParCodcred(pCodcred);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParCodmod(pCodmod);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_INGRESO_CUSTODIA_BONOS_TESORERIA_HABER.getValor());
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParTabestado(1901);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParEstado(1);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParAuditfho(new Date());
            pGenParametroIngCustodiaBonoTesoreriaDto.getAbono().setParAuditwst(pEstacion);
            if (pGenParametroIngCustodiaBonoTesoreriaDto.getAbono()==null){
                persist(pGenParametroIngCustodiaBonoTesoreriaDto.getAbono(), pUsuario);
            }else{
                merge(pGenParametroIngCustodiaBonoTesoreriaDto.getAbono(), pUsuario);
            }

            log.info("modificarIngresoCustodiaBonosTesoreria|| Registro ESQUEMA");
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_INGRESO_CUSTODIA_BONOS_TESORERIA.getValor());
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParTabestado(1901);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParEstado(1);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParAuditfho(new Date());
            pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema().setParAuditwst(pEstacion);
            if (pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema()==null){
                persist(pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema(), pUsuario);
            }else{
                merge(pGenParametroIngCustodiaBonoTesoreriaDto.getEsquema(), pUsuario);
            }
        }catch (Exception e){
            log.error("modificarIngresoCustodiaBonosTesoreria|| Excepcion: "+e.getMessage());
        }
    }

    public void modificarAmortizacionCapital(GenParametroAmortizacionCapitalDto pGenParametroAmortizacionCapitalDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("modificarAmortizacionCapital|| Registro DEBITO Cap. Int");
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParTprcod(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_CAP_INT_DEBE.getValor());
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getDebitoCapInt().setParAuditwst(pEstacion);
            //merge(pGenParametroAmortizacionCapitalDto.getDebitoCapInt(), pUsuario);
            if (pGenParametroAmortizacionCapitalDto.getDebitoCapInt()==null){
                persist(pGenParametroAmortizacionCapitalDto.getDebitoCapInt(), pUsuario);
            }else{
                merge(pGenParametroAmortizacionCapitalDto.getDebitoCapInt(), pUsuario);
            }


            log.info("modificarAmortizacionCapital|| Registro HABER  Cap. Int");
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParTprcod(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_CAP_HABER.getValor());
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getAbonoCapital().setParAuditwst(pEstacion);
            if (pGenParametroAmortizacionCapitalDto.getAbonoCapital()==null){
                persist(pGenParametroAmortizacionCapitalDto.getAbonoCapital(), pUsuario);
            }else{
                merge(pGenParametroAmortizacionCapitalDto.getAbonoCapital(), pUsuario);
            }



            log.info("modificarAmortizacionCapital|| Registro ABONO int. gest. ant.");
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParTprcod(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_INT_GESTION_ANT_HABER.getValor());
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt().setParAuditwst(pEstacion);
            if (pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt()==null){
                persist(pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt(), pUsuario);
            }else{
                merge(pGenParametroAmortizacionCapitalDto.getAbonoIntGestAnt(), pUsuario);
            }

            log.info("modificarAmortizacionCapital|| Registro ABONO int. gest. Actual");
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParTprcod(EnumGenTipoParametro.CUENTA_AMORTIZACION_CAPITAL_PAGO_INTERESES_INT_GESTION_ACTUAL_HABER.getValor());
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual().setParAuditwst(pEstacion);
            if (pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual()==null){
                persist(pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual(), pUsuario);
            }else{
                merge(pGenParametroAmortizacionCapitalDto.getAbonoIntGestActual(), pUsuario);
            }

            log.info("modificarAmortizacionCapital|| Registro ESQUEMA");
            pGenParametroAmortizacionCapitalDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_AMORTIZACION_CAPITAL_PAGO_INTERESES.getValor());
            pGenParametroAmortizacionCapitalDto.getEsquema().setParTabestado(1901);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParEstado(1);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroAmortizacionCapitalDto.getEsquema().setParAuditfho(new Date());
            pGenParametroAmortizacionCapitalDto.getEsquema().setParAuditwst(pEstacion);
            if (pGenParametroAmortizacionCapitalDto.getEsquema()==null){
                persist(pGenParametroAmortizacionCapitalDto.getEsquema(), pUsuario);
            }else{
                merge(pGenParametroAmortizacionCapitalDto.getEsquema(), pUsuario);
            }
        }catch (Exception e){
            log.error("modificarAmortizacionCapital|| Excepcion: "+e.getMessage());
        }
    }

    public void modificarRetiroBonosTesoreria(GenParametroRetiroBonoTesoreriaDto pGenParametroRetiroBonoTesoreriaDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("modificarRetiroBonosTesoreria|| Registro de desembolso DEBITO");
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParCodcred(pCodcred);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParCodmod(pCodmod);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_DEBE.getValor());
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParTabestado(1901);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParEstado(1);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParAuditusr(pUsuario);
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParAuditfho(new Date());
            pGenParametroRetiroBonoTesoreriaDto.getDebito().setParAuditwst(pEstacion);
            if (pGenParametroRetiroBonoTesoreriaDto.getDebito()==null){
                persist(pGenParametroRetiroBonoTesoreriaDto.getDebito(), pUsuario);
            }else{
                merge(pGenParametroRetiroBonoTesoreriaDto.getDebito(), pUsuario);
            }

            log.info("modificarRetiroBonosTesoreria|| Registro de desembolso ABONO");
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParCodcred(pCodcred);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParCodmod(pCodmod);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParTprcod(EnumGenTipoParametro.CUENTA_RETIRO_CUSTODIA_BONOS_TESORERIA_HABER.getValor());
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParTabestado(1901);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParEstado(1);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParAuditusr(pUsuario);
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParAuditfho(new Date());
            pGenParametroRetiroBonoTesoreriaDto.getAbono().setParAuditwst(pEstacion);
            if (pGenParametroRetiroBonoTesoreriaDto.getAbono()==null){
                persist(pGenParametroRetiroBonoTesoreriaDto.getAbono(), pUsuario);
            }else{
                merge(pGenParametroRetiroBonoTesoreriaDto.getAbono(), pUsuario);
            }

            log.info("modificarRetiroBonosTesoreria|| Registro de desembolso ESQUEMA");
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_RETIRO_CUSTODIA_BONOS_TESORERIA.getValor());
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParTabestado(1901);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParEstado(1);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParAuditfho(new Date());
            pGenParametroRetiroBonoTesoreriaDto.getEsquema().setParAuditwst(pEstacion);
            if (pGenParametroRetiroBonoTesoreriaDto.getEsquema()==null){
                persist(pGenParametroRetiroBonoTesoreriaDto.getEsquema(), pUsuario);
            }else{
                merge(pGenParametroRetiroBonoTesoreriaDto.getEsquema(), pUsuario);
            }
        }catch (Exception e){
            log.error("modificarRetiroBonosTesoreria|| Excepcion: "+e.getMessage());
        }
    }

    public void modificarPagoInteses(GenParametroPagoInteresDto pGenParametroPagoInteresDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("modificarPagoInteses|| Registro DEBITO Int");
            pGenParametroPagoInteresDto.getDebitoInteres().setParCodcred(pCodcred);
            pGenParametroPagoInteresDto.getDebitoInteres().setParCodmod(pCodmod);
            pGenParametroPagoInteresDto.getDebitoInteres().setParTprcod(EnumGenTipoParametro.CUENTA_PAGO_INTERESES_INTERESES_DEBE.getValor());
            pGenParametroPagoInteresDto.getDebitoInteres().setParTabestado(1901);
            pGenParametroPagoInteresDto.getDebitoInteres().setParEstado(1);
            pGenParametroPagoInteresDto.getDebitoInteres().setParAuditusr(pUsuario);
            pGenParametroPagoInteresDto.getDebitoInteres().setParAuditfho(new Date());
            pGenParametroPagoInteresDto.getDebitoInteres().setParAuditwst(pEstacion);
            if (pGenParametroPagoInteresDto.getDebitoInteres()==null){
                persist(pGenParametroPagoInteresDto.getDebitoInteres(), pUsuario);
            }else{
                merge(pGenParametroPagoInteresDto.getDebitoInteres(), pUsuario);
            }

            log.info("modificarPagoInteses|| Registro ABONO int. gest. ant.");
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParCodcred(pCodcred);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParCodmod(pCodmod);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParTprcod(EnumGenTipoParametro.CUENTA_PAGO_INTERESES_INT_GESTION_ANT_HABER.getValor());
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParTabestado(1901);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParEstado(1);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParAuditusr(pUsuario);
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParAuditfho(new Date());
            pGenParametroPagoInteresDto.getAbonoIntGestAnt().setParAuditwst(pEstacion);
            if (pGenParametroPagoInteresDto.getAbonoIntGestAnt()==null){
                persist(pGenParametroPagoInteresDto.getAbonoIntGestAnt(), pUsuario);
            }else{
                merge(pGenParametroPagoInteresDto.getAbonoIntGestAnt(), pUsuario);
            }

            log.info("modificarPagoInteses|| Registro ABONO int. gest. Actual");
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParCodcred(pCodcred);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParCodmod(pCodmod);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParTprcod(EnumGenTipoParametro.CUENTA_PAGO_INTERESES_INT_GESTION_ACTUAL_HABER.getValor());
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParTabestado(1901);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParEstado(1);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParAuditusr(pUsuario);
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParAuditfho(new Date());
            pGenParametroPagoInteresDto.getAbonoIntGestActual().setParAuditwst(pEstacion);
            if (pGenParametroPagoInteresDto.getAbonoIntGestActual()==null){
                persist(pGenParametroPagoInteresDto.getAbonoIntGestActual(), pUsuario);
            }else{
                merge(pGenParametroPagoInteresDto.getAbonoIntGestActual(), pUsuario);
            }

            log.info("modificarPagoInteses|| Registro ESQUEMA");
            pGenParametroPagoInteresDto.getEsquema().setParCodcred(pCodcred);
            pGenParametroPagoInteresDto.getEsquema().setParCodmod(pCodmod);
            pGenParametroPagoInteresDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_PAGO_INTERESES.getValor());
            pGenParametroPagoInteresDto.getEsquema().setParTabestado(1901);
            pGenParametroPagoInteresDto.getEsquema().setParEstado(1);
            pGenParametroPagoInteresDto.getEsquema().setParAuditusr(pUsuario);
            pGenParametroPagoInteresDto.getEsquema().setParAuditfho(new Date());
            pGenParametroPagoInteresDto.getEsquema().setParAuditwst(pEstacion);
            if (pGenParametroPagoInteresDto.getEsquema()==null){
                persist(pGenParametroPagoInteresDto.getEsquema(), pUsuario);
            }else{
                merge(pGenParametroPagoInteresDto.getEsquema(), pUsuario);
            }
        }catch (Exception e){
            log.error("modificarPagoInteses|| Excepcion: "+e.getMessage());
        }
    }

    public void modificarCertificacionPresupuestaria(GenParametroCertificacionPresupuestariaDto pGenParametroCertificacionPresupuestariaDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("modificarCertificacionPresupuestaria|| Registro Gestion anterior");
            if (pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().getParParametro()!=null && !(pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().getParParametro().equals(""))){
                pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParCodcred(pCodcred);
                pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParCodmod(pCodmod);
                pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParTprcod(EnumGenTipoParametro.GESTION_ANTERIOR_DEVENGADO_INTERESES.getValor());
                pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParTabestado(1901);
                pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParEstado(1);
                pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParAuditusr(pUsuario);
                pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParAuditfho(new Date());
                pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().setParAuditwst(pEstacion);
                if (pGenParametroCertificacionPresupuestariaDto.getGestionAnterior().getId()==null){
                    persist(pGenParametroCertificacionPresupuestariaDto.getGestionAnterior(), pUsuario);
                }else{
                    merge(pGenParametroCertificacionPresupuestariaDto.getGestionAnterior(), pUsuario);
                }

            }
                //getNomCortoCredito
            log.info("modificarCertificacionPresupuestaria|| Registro gestion actual");
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParCodcred(pCodcred);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParCodmod(pCodmod);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParTprcod(EnumGenTipoParametro.GESTION_ACTUAL_DEVENGADO_INTERESES.getValor());
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParTabestado(1901);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParEstado(1);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParAuditusr(pUsuario);
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParAuditfho(new Date());
            pGenParametroCertificacionPresupuestariaDto.getGestionActual().setParAuditwst(pEstacion);
            if (pGenParametroCertificacionPresupuestariaDto.getGestionActual()==null){
                persist(pGenParametroCertificacionPresupuestariaDto.getGestionActual(), pUsuario);
            }else{
                merge(pGenParametroCertificacionPresupuestariaDto.getGestionActual(), pUsuario);
            }

            log.info("modificarCertificacionPresupuestaria|| Registro NOMBRE CORTO CREDITO");
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParCodcred(pCodcred);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParCodmod(pCodmod);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParTprcod(EnumGenTipoParametro.DESCRIPCION_CORTA_CREDITO.getValor());
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParTabestado(1901);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParEstado(1);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParAuditusr(pUsuario);
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParAuditfho(new Date());
            pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito().setParAuditwst(pEstacion);
            if (pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito()==null){
                persist(pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito(), pUsuario);
            }else{
                merge(pGenParametroCertificacionPresupuestariaDto.getNomCortoCredito(), pUsuario);
            }

        }catch (Exception e){
            log.error("modificarCertificacionPresupuestaria|| Excepcion: "+e.getMessage());
        }
    }

    public void modificarUtilesEscritorio(GenParametroUtilEscritorioDto pGenParametroUtilEscritorioDto, Integer pCodcred, Integer pCodmod, String pUsuario, String pEstacion){
        try {
            log.info("modificarUtilesEscritorio|| Registro de desembolso DEBITO");
            if (pGenParametroUtilEscritorioDto.getDebito().getParParametro()!=null && !(pGenParametroUtilEscritorioDto.getDebito().getParParametro().equals(""))){
                pGenParametroUtilEscritorioDto.getDebito().setParCodcred(pCodcred);
                pGenParametroUtilEscritorioDto.getDebito().setParCodmod(pCodmod);
                pGenParametroUtilEscritorioDto.getDebito().setParTprcod(EnumGenTipoParametro.CUENTA_UTILES_ESCRITORIO_DEBE.getValor());
                pGenParametroUtilEscritorioDto.getDebito().setParTabestado(1901);
                pGenParametroUtilEscritorioDto.getDebito().setParEstado(1);
                pGenParametroUtilEscritorioDto.getDebito().setParAuditusr(pUsuario);
                pGenParametroUtilEscritorioDto.getDebito().setParAuditfho(new Date());
                pGenParametroUtilEscritorioDto.getDebito().setParAuditwst(pEstacion);
                if (pGenParametroUtilEscritorioDto.getDebito()==null){
                    persist(pGenParametroUtilEscritorioDto.getDebito(), pUsuario);
                }else{
                    merge(pGenParametroUtilEscritorioDto.getDebito(), pUsuario);
                }

            }

            if (pGenParametroUtilEscritorioDto.getAbono1().getParParametro()!=null && !(pGenParametroUtilEscritorioDto.getAbono1().getParParametro().equals(""))){
                log.info("modificarUtilesEscritorio|| Registro de desembolso ABONO 1");
                pGenParametroUtilEscritorioDto.getAbono1().setParCodcred(pCodcred);
                pGenParametroUtilEscritorioDto.getAbono1().setParCodmod(pCodmod);
                pGenParametroUtilEscritorioDto.getAbono1().setParTprcod(EnumGenTipoParametro.CUENTA_UTILES_ESCRITORIO_HABER.getValor());
                pGenParametroUtilEscritorioDto.getAbono1().setParTabestado(1901);
                pGenParametroUtilEscritorioDto.getAbono1().setParEstado(1);
                pGenParametroUtilEscritorioDto.getAbono1().setParAuditusr(pUsuario);
                pGenParametroUtilEscritorioDto.getAbono1().setParAuditfho(new Date());
                pGenParametroUtilEscritorioDto.getAbono1().setParAuditwst(pEstacion);
                if (pGenParametroUtilEscritorioDto.getAbono1().getId()==null){
                    persist(pGenParametroUtilEscritorioDto.getAbono1(), pUsuario);
                }else{
                    merge(pGenParametroUtilEscritorioDto.getAbono1(), pUsuario);
                }

            }

            if (pGenParametroUtilEscritorioDto.getAbono2().getParParametro()!=null && !(pGenParametroUtilEscritorioDto.getAbono2().getParParametro().equals(""))){
                log.info("modificarUtilesEscritorio|| Registro de desembolso ABONO 2");
                pGenParametroUtilEscritorioDto.getAbono2().setParCodcred(pCodcred);
                pGenParametroUtilEscritorioDto.getAbono2().setParCodmod(pCodmod);
                pGenParametroUtilEscritorioDto.getAbono2().setParTprcod(EnumGenTipoParametro.CUENTA_UTILES_ESCRITORIO_HABER_SEGUNDO.getValor());
                pGenParametroUtilEscritorioDto.getAbono2().setParTabestado(1901);
                pGenParametroUtilEscritorioDto.getAbono2().setParEstado(1);
                pGenParametroUtilEscritorioDto.getAbono2().setParAuditusr(pUsuario);
                pGenParametroUtilEscritorioDto.getAbono2().setParAuditfho(new Date());
                pGenParametroUtilEscritorioDto.getAbono2().setParAuditwst(pEstacion);
                if (pGenParametroUtilEscritorioDto.getAbono2()==null){
                    persist(pGenParametroUtilEscritorioDto.getAbono2(), pUsuario);
                }else{
                    merge(pGenParametroUtilEscritorioDto.getAbono2(), pUsuario);
                }

            }

            if (pGenParametroUtilEscritorioDto.getEsquema().getParParametro()!=null && !(pGenParametroUtilEscritorioDto.getEsquema().getParParametro().equals(""))){
                log.info("modificarUtilesEscritorio|| Registro de desembolso ESQUEMA");
                pGenParametroUtilEscritorioDto.getEsquema().setParCodcred(pCodcred);
                pGenParametroUtilEscritorioDto.getEsquema().setParCodmod(pCodmod);
                pGenParametroUtilEscritorioDto.getEsquema().setParTprcod(EnumGenTipoParametro.ESQUEMA_UTILES_ESCRITORIO.getValor());
                pGenParametroUtilEscritorioDto.getEsquema().setParTabestado(1901);
                pGenParametroUtilEscritorioDto.getEsquema().setParEstado(1);
                pGenParametroUtilEscritorioDto.getEsquema().setParAuditusr(pUsuario);
                pGenParametroUtilEscritorioDto.getEsquema().setParAuditfho(new Date());
                pGenParametroUtilEscritorioDto.getEsquema().setParAuditwst(pEstacion);
                if (pGenParametroUtilEscritorioDto.getEsquema()==null){
                    persist(pGenParametroUtilEscritorioDto.getEsquema(), pUsuario);
                }else{
                    merge(pGenParametroUtilEscritorioDto.getEsquema(), pUsuario);
                }


            }

        }catch (Exception e){
            log.error("modificarUtilesEscritorio|| Excepcion: "+e.getMessage());
        }
    }


    @Override
    public String getNumeroCuenta(Integer codcred,Integer codmod,Integer tipo) throws OperationException {
        return genParametroQLLocal.getNumeroCuenta(codcred, codmod, tipo);
    }

} // end class

