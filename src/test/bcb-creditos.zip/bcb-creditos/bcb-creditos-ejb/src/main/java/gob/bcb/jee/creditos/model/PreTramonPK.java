package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;

/**
 * The primary key class for the pre_tramon database table.
 * 
 */
@Getter
@Setter
@Embeddable
public class PreTramonPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="tmo_numtrx")
	private Integer tmoNumtrx;

	@Column(name="tmo_codcred", insertable=false, updatable=false)
	private Integer tmoCodcred;

	@Column(name="tmo_codmod", insertable=false, updatable=false)
	private Integer tmoCodmod;

	public PreTramonPK() {
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PreTramonPK)) {
			return false;
		}
		PreTramonPK castOther = (PreTramonPK)other;
		return 
			(this.tmoNumtrx == castOther.tmoNumtrx)
			&& (this.tmoCodcred == castOther.tmoCodcred)
			&& (this.tmoCodmod == castOther.tmoCodmod);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.tmoNumtrx;
		hash = hash * prime + this.tmoCodcred;
		hash = hash * prime + this.tmoCodmod;
		
		return hash;
	}
}
