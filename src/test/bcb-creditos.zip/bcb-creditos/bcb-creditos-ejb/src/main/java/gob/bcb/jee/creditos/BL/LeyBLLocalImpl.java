/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocalImpl
 * 10/11/2015 - 12:15:59
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.LeyQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.LeyDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.Ley;
import gob.bcb.jee.creditos.util.Cttes;


@Stateless
@LocalBean
public class LeyBLLocalImpl extends
        GenericBLLocalImpl<Ley, Integer>
        implements LeyBLLocal {
  
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;
    /*
     * Inyeccion de los metodos para consulta (QL)
     */
    @Inject
    LeyQLLocal parametrosQLLocal;

    @Inject
    LeyDao parametroDao;

    @Override
    public GenericQLLocal<Ley, Integer> getQLBean() {
        return parametrosQLLocal;
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.BL.GenericBLLocalImpl#getGenericDao()
     */
    @Override
    public GenericDao<Ley, Integer> getGenericDao() {
        return parametroDao;
    }

	@Override
	public void validar(Ley entity) throws OperationException, EntityValidationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Integer getIdNuevo() throws OperationException {

		return parametrosQLLocal.getIdNuevo();
	}

	

}
