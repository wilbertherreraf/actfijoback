package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;


/**
 * The persistent class for the pre_tasaspre database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="pre_tasaspre")
@NamedQuery(name="PreTasaspre.findAll", query="SELECT p FROM PreTasaspre p")
@NamedQueries({
    @NamedQuery(name = PreTasaspre.NQ_LIST_ALL, query = "SELECT a FROM PreTasaspre a"),
    @NamedQuery(name = PreTasaspre.NQ_GET_BY_ID, query = "SELECT p FROM PreTasaspre p where p.id.mtpCodcred=:valor1 and p.id.mtpCodmod=:valor2 order by p.id.mtpFechavig "),
   // @NamedQuery(name = PreTasaspre.NQ_GET_BY_ID_MAX, query = "SELECT p FROM PreTasaspre p where p.id.mtpCodcred=:valor1 and p.id.mtpCodmod=:valor2 order by p.id.mtpFechavig desc limit 1 ")
    
})
public class PreTasaspre extends EntidadAutorizable<PreTasasprePK> implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String ENTITY ="PreTasaspre";
	  public static final String NQ_GET_BY_ID =ENTITY+"GetById";
	  public static final String NQ_GET_BY_ID_MAX =ENTITY+"GetByIdMax";
	  public static final String NQ_LIST_ALL = ENTITY + "ListAll";	
	@Id
	private PreTasasprePK id;

	@Column(name="mtp_tbase")
	private Double mtpTbase;
	
	@Column(name="mtp_tspread")
	private Double mtpTspread;
	
	@Column(name="mtp_tabintmdias")
	private Integer mtpTabintmdias;
	
	@Column(name="mtp_intmdias")
	private Integer mtpIntmdias;
	
	@Column(name="mtp_tabintydias")
	private Integer mtpTabintydias;
	
	@Column(name="mtp_intydias")
	private Integer mtpIntydias;
	
	@Column(name="mtp_tabtrxstaau")
	private Integer mtpTabtrxstaau;	

	@Column(name="mtp_trxstaau")
	private Integer mtpTrxstaau;
	
	@Column(name="mtp_auditusr")
	private String mtpAuditusr;
	
	@Column(name="mtp_auditfho")
	private Timestamp mtpAuditfho;

	@Column(name="mtp_auditwst")
	private String mtpAuditwst;

	

	

	public PreTasaspre() {
	}

	@Override
	public PreTasasprePK getId() {
		return id;
	}

	@Override
	public void setId(PreTasasprePK id) {
		this.id=id;
	}

	
}
