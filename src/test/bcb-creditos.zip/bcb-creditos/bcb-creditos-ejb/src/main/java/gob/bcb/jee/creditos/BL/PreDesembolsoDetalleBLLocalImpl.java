package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PreDesembolsoDetalleQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.dao.PreDesembolsoDetalleDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;
import gob.bcb.jee.creditos.util.Cttes;

import javax.inject.Inject;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * PreDesembolsoDetalleBLLocalImpl
 *
 * @author mcramos
 * 11/02/2025
 */
@Stateless
@LocalBean
public class PreDesembolsoDetalleBLLocalImpl extends
        GenericBLLocalImpl<PreDesembolsoDetalle, Integer> implements
        PreDesembolsoDetalleBLLocal {

    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;

    @Inject
    PreDesembolsoDetalleQLLocal preDesembolsoDetalleQLLocal;

    @Inject
    PreDesembolsoDetalleDao preDesembolsoDetalleDao;

    @Override
    public void validar(PreDesembolsoDetalle entity) throws OperationException, EntityValidationException {

    }

    @Override
    public GenericQLLocal<PreDesembolsoDetalle, Integer> getQLBean() {
        return preDesembolsoDetalleQLLocal;
    }

    @Override
    public GenericDao<PreDesembolsoDetalle, Integer> getGenericDao() {
        return preDesembolsoDetalleDao;
    }

    @Override
    public PreDesembolsoDetalle obtenerPorCodDesembolso(Integer pCodDesembolso) {
        return preDesembolsoDetalleQLLocal.obtenerPorCodDesembolso(pCodDesembolso);
    }

    @Override
    public Integer getEstadoDesembolsoDetalle(Integer codcred,Integer codmod,Integer coddsb) throws OperationException {
        return preDesembolsoDetalleQLLocal.getEstadoDesembolsoDetalle(codcred, codmod, coddsb);
    }

    @Override
    public List<String> getLeyesPrestamo(String leyes) throws OperationException {
        return preDesembolsoDetalleQLLocal.getLeyesPrestamo(leyes);
    }
}

