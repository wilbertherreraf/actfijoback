/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.BL.EmpresaBLLocal
 * 10/11/2015 - 12:15:23
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.BL;

import java.sql.Timestamp;
import java.util.List;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.AuxPlanpagos;

/**
 * Interface para el negocio del a entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface AuxPlanpagosBLLocal extends
    GenericBLLocal<AuxPlanpagos, Integer>
{
	public Integer getCantidad(Integer coddsb)throws OperationException;
	public Integer getCantidadPreAutorizado(Integer coddsb)throws OperationException;
	public Integer getCantidadNoPreAutorizado(Integer coddsb,Integer codgenerado)throws OperationException;
	public Integer getCantidadAutorizado(Integer coddsb,Integer codgenerado,Integer codaut)throws OperationException;
	public void preautorizar(Integer coddsb, String usuario, Timestamp fecha,Integer estado,Integer codseleccionado)throws OperationException;
	public List<Object[]> mostrarPlanDePagosDisponibles(Integer codcred,Integer coddsb)throws OperationException;
	
	public List<Object[]> mostrarPlanDePagosAux(Integer codcred,Integer coddsb,Integer codMod)throws OperationException;	
	public List<Object[]> mostrarPlanDePagosConsolAux(Integer codcred,Integer codMod)throws OperationException;
	public void actualizarConsolidadoAux(Integer codcred,Integer codmod,Integer codmodtmp)throws OperationException;	
	public void actualizarDesembolsoAux(Integer codcred,Integer codmod,Integer codmodtmp,Integer coddsb)throws OperationException;
}
