package gob.bcb.jee.creditos.QL;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import gob.bcb.jee.creditos.entidades.PreRegistrogarantias;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreCustodiaGarantia;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * PreCustodiaGarantiaQLLocalImpl
 *
 * @author mcramos
 * 21/02/2025
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class PreCustodiaGarantiaQLLocalImpl extends
        GenericQLLocalImpl<PreCustodiaGarantia, Integer> implements
        PreCustodiaGarantiaQLLocal{

    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    protected org.apache.log4j.Logger log = Logger.getLogger(this.getClass());

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

    public PreCustodiaGarantia buscarPorId(Integer id) {
        String nativeQuery = " select t from PreCustodiaGarantia t where t.id=:id ";

        Query query = entityManager.createQuery(nativeQuery).setParameter("id", id);
        List result = query.getResultList();
        if (result.size() > 0) {
            return (PreCustodiaGarantia) result.get(0);
        }

        return null;
    }

    public PreCustodiaGarantia guardarCustGar(PreCustodiaGarantia entity) {
        try {
            if (entity.getId() == null) {
                entityManager.persist(entity);
                PreCustodiaGarantia d = buscarPorId(entity.getId());
                return d;
            } else {
                PreCustodiaGarantia d = entityManager.merge(entity);
                return d;
            }
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public PreCustodiaGarantia obtenerPorCodDesembolso(Integer pCodDesembolso) {
        PreCustodiaGarantia preCustodiaGarantia = new PreCustodiaGarantia();
        String nativeQuery=" select * from d_creditos.pre_custodia_garantia where dsb_coddsb=:dsb_coddsb and estado IN (1,2,3) ";

        try {
            Query query=entityManager.createNativeQuery(nativeQuery, PreCustodiaGarantia.class).setParameter("dsb_coddsb", pCodDesembolso);
            preCustodiaGarantia = (PreCustodiaGarantia) query.getSingleResult();

        } catch (NoResultException e) {
            String error = "No se encontro una custodia de garantia para : " + pCodDesembolso;
            log.error(error);
            preCustodiaGarantia = new PreCustodiaGarantia();
        }
        return preCustodiaGarantia;
    }

    @Override
    public Integer getEstadoCustodiaGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException {
        String nativeQuery= " SELECT NVL(r.estado, 0) as estado  " +
                " FROM (SELECT 0 as estado FROM systables WHERE tabid = 1) dummy " +
                " LEFT JOIN d_creditos.pre_custodia_garantia r " +
                " ON r.codmod=:codmod " +
                " and codcred=:codcred " +
                " and dsb_coddsb=:coddsb  " +
                " and r.estado IN (1,2,3)  ";

        Query query=entityManager.createNativeQuery(nativeQuery);
        query.setParameter("codcred", codcred);
        query.setParameter("codmod", codmod);
        query.setParameter("coddsb", coddsb);

        Object valor= query.getSingleResult();


        if(valor!=null) {
            return (int) valor;
        }
        return 0;
    }
}
