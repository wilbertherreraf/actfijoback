package gob.bcb.jee.creditos.pojo;

import gob.bcb.jee.creditos.model.PreDesemb;
import gob.bcb.jee.creditos.model.PreRetiroGarantia;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * PreRetiroGarantiaDto
 *
 * @author mcramos
 * 12/03/2025
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PreRetiroGarantiaDto implements Serializable {
    PreDesemb desembolso;
    PreRetiroGarantia retiroGarantia;
}
