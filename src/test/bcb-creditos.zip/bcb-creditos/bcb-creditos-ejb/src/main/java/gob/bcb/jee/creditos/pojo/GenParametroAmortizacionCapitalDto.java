package gob.bcb.jee.creditos.pojo;

import gob.bcb.jee.creditos.entidades.GenParametro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * GenParametroAmortizacionCapitalDto
 *
 * @author mcramos
 * 15/01/2025
 */
@Getter
@Setter
@NoArgsConstructor
public class GenParametroAmortizacionCapitalDto implements Serializable {
    private GenParametro debitoCapInt = new GenParametro();
    private GenParametro abonoCapital = new GenParametro();
    private GenParametro abonoIntGestAnt = new GenParametro();
    private GenParametro abonoIntGestActual = new GenParametro();
    private GenParametro esquema = new GenParametro();
}
