package gob.bcb.jee.creditos.excepciones;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.excepciones
 * 19/07/2016 - 02:51 PM
 * Código base:
 * Creado por aescobar
 */
@Getter
@Setter
public class EntityValidationException extends Exception {

    private List<String> fieldErrors;

    public EntityValidationException(String mensaje){
        super(mensaje);
    }

    public EntityValidationException(String mensaje, List<String> fieldErrors)
    {
        super(mensaje);
        this.fieldErrors = fieldErrors;
    }

    public EntityValidationException(String mensaje, Throwable e,List<String> fieldErrors)
    {
        super(mensaje, e);
        this.fieldErrors = fieldErrors;
    }

    public void addFieldError(String error){
        if(fieldErrors == null)
            fieldErrors = new ArrayList<String>();
        fieldErrors.add(error);
    }

}
