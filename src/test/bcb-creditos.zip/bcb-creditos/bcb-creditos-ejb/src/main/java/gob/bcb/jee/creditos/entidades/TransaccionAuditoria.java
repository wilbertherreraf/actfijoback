/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.entidades.TransaccionAuditoria
 * 22/03/2016 - 17:58:22
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.entidades;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Clase para la entidad TransaccionAuditoria
 *
 *
 * @author ysalinas
 *
 */
@Entity
@Table(name = "TRANSACCION_AUDITORIA")
@Getter
@Setter

public class TransaccionAuditoria extends Entidad<String> implements Serializable
{

    public static final String ENTITY = "TransaccionAuditoria";
    public static final String NQ_SEARCH_BY_TIPO = ENTITY + "SearchByTipo";

    @Id
    @NotNull
    @Column(name = "COD_TRANSACCION", updatable = false)
    private String id;

    @Column(name = "DESCRIPCION", nullable = false)
    private String descripcion;

    public TransaccionAuditoria() {
    super();
    }

    public TransaccionAuditoria(String codTransaccion) {
        super();
        this.id = codTransaccion;
    }

    @Override
    public String toString() {
        return "TransaccionAuditoria{" +
                "id=" + id +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TransaccionAuditoria that = (TransaccionAuditoria) o;

        if (descripcion != null ? !descripcion.equals(that.descripcion) : that.descripcion != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (descripcion != null ? descripcion.hashCode() : 0);
        return result;
    }
}
