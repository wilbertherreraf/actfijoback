/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.Empresa;

import javax.ejb.Local;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface EmpresaQLLocal extends
        GenericQLLocal<Empresa, Integer>
{

}
