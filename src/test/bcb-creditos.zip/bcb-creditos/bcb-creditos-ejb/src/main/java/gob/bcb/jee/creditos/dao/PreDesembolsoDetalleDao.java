package gob.bcb.jee.creditos.dao;

import java.io.Serializable;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * PreDesembolsoDetalleDao
 *
 * @author mcramos
 * 11/02/2025
 */
@Stateless
public class PreDesembolsoDetalleDao extends GenericDao<PreDesembolsoDetalle, Integer> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public PreDesembolsoDetalleDao() {
    }

    public PreDesembolsoDetalleDao(Class<PreDesembolsoDetalle> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
}
