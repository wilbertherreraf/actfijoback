package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the pre_parmtasas database table.
 * 
 */
@Embeddable
public class PreParmtasasPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.DATE)
	@Column(name="pta_fecvig")
	private java.util.Date ptaFecvig;

	@Column(name="pta_codmon", insertable=false, updatable=false)
	private Integer ptaCodmon;

	public PreParmtasasPK() {
	}
	public java.util.Date getPtaFecvig() {
		return this.ptaFecvig;
	}
	public void setPtaFecvig(java.util.Date ptaFecvig) {
		this.ptaFecvig = ptaFecvig;
	}
	public Integer getPtaCodmon() {
		return this.ptaCodmon;
	}
	public void setPtaCodmon(Integer ptaCodmon) {
		this.ptaCodmon = ptaCodmon;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PreParmtasasPK)) {
			return false;
		}
		PreParmtasasPK castOther = (PreParmtasasPK)other;
		return 
			this.ptaFecvig.equals(castOther.ptaFecvig)
			&& (this.ptaCodmon == castOther.ptaCodmon);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.ptaFecvig.hashCode();
		hash = hash * prime + this.ptaCodmon;
		
		return hash;
	}
}
