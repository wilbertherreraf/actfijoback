
package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.model.Articulo;
import gob.bcb.jee.creditos.model.ArticuloPK;

import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;


@Stateless
public class ArticuloDao extends GenericDao<Articulo, Integer> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

   

    public ArticuloDao() {
    }

    public ArticuloDao(Class<Articulo> entityClass) {
        super(entityClass);
    }

    /*
     * (non-Javadoc)
     * @see gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}