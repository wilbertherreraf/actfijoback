
package gob.bcb.jee.creditos.BL;

import java.util.Date;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.jee.creditos.QL.GenericQLLocal;
import gob.bcb.jee.creditos.QL.PrePagocuotaQLLocal;
import gob.bcb.jee.creditos.QL.PrePrccontaQLLocal;
import gob.bcb.jee.creditos.QL.PreRegistrogarantiasQLLocal;
import gob.bcb.jee.creditos.dao.GenericDao;
import gob.bcb.jee.creditos.excepciones.EntityValidationException;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PrePlanpagos;
import gob.bcb.jee.creditos.model.PrePrcconta;
import gob.bcb.jee.creditos.util.Cttes;

/**
 * Implementacion para los metodos de consulta (BL) para la entidad PrePrcconta
 * 
 * @author wherrera
 */
@Stateless
@LocalBean
public class PrePrccontaBLLocalImpl extends GenericBLLocalImpl<PrePrcconta, Integer>   implements PrePrccontaBLLocal {
    private static final Logger log = LoggerFactory.getLogger(PrePrccontaBLLocalImpl.class);

    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    EntityManager em;

    @Inject
    PrePrccontaQLLocal prePrccontaQLLocal;
    @Inject
    private PrePagocuotaQLLocal prePagocuotaQLLocal;
    @Inject
    private PreRegistrogarantiasQLLocal preRegistrogarantiasQLLocal;

    @Override
    public void validar(PrePrcconta entity) throws OperationException, EntityValidationException {

    }

    @Override
    public GenericQLLocal<PrePrcconta, Integer> getQLBean() {
        return prePrccontaQLLocal;
    }


    @Override
    public Integer getNextId() throws OperationException {
        return prePrccontaQLLocal.getNextId();
    }

    public PrePrcconta guardarPrcconta(PrePrcconta prePrcconta) {
        return prePrccontaQLLocal.guardarPrcconta(prePrcconta);
    }
    
    public PrePrcconta buscarPorId(Integer prcCodprc) {
        PrePrcconta prc = prePrccontaQLLocal.buscarPorId(prcCodprc);
        if (prc == null) {
            //throw new RuntimeException("Operación PrePrcconta inexistente: " + prcCodprc);
        }

        return prc;
    }

    public PrePrcconta generarComprobanteDevengado(PrePrcconta prePrcconta) {

        log.info("Inicio generar comprob coin dev cred {} id: {}", prePrcconta.getPrcCodcred(),
                prePrcconta.getPrcCodprc());
        PrePrcconta prePrc = prePrccontaQLLocal.guardarPrcconta(prePrcconta);

        String nroCmp = preRegistrogarantiasQLLocal.generarCmpbBonos(prePrc.getPrcCodprc(), prePrc.getPrcCodcmp(),
                prePrc.getPrcCodcred(), prePrc.getPrcCodmod(), prePrc.getPrcFecha(), prePrc.getPrcGlosa(),
                prePrc.getPrcAuditusrgen(), prePrc.getPrcAuditwstgen());

        prePrc = prePrccontaQLLocal.buscarPorId(prePrc.getPrcCodprc());
        log.info("==> FIN generar comprob coin dev prcconta {} nrocomprob: {}", 
                prePrc.getPrcCodprc(),prePrc.getPrcNroComprob());
        return prePrc;
    }

    public PrePlanpagos obtenerDevengamientoAFecha(Integer codcred, Integer codmod, Date fechaini, Date fecha) {
        Integer tipoproc = 3; // dev periodo mes
        prePagocuotaQLLocal.generarDevengadosCredito(codcred, codmod, fechaini, fechaini, tipoproc);
        return prePrccontaQLLocal.obtenerDevengamientoAFecha(codcred, codmod, fechaini, fecha);
    }

    public PrePrcconta buscarPorFechaDeven(Integer prcCodcred, Integer prcCodmod, Date prcFecha2) {
        return prePrccontaQLLocal.buscarPorFechaDeven(prcCodcred, prcCodmod, prcFecha2);
    }

    public PrePrcconta procesarDevengadoManual(PrePrcconta prePrccontaIn,String usuario, String estacion) {
        // guardamos en principio como no valido
        if (prePrccontaIn.getPrcNroComprob() == null) {
            throw new RuntimeException("Se requiere nro de comprobante");
        }

        log.info("En actualizar dev manual " + prePrccontaIn.getPrcNroComprob());
        PrePrcconta prePrcconta = prePrccontaQLLocal.guardarPrcconta(prePrccontaIn);
        prePrccontaQLLocal.cambiarEstadoOperComprob(prePrcconta.getPrcCodcmp(), prePrcconta.getPrcCodprc(),
					prePrcconta.getPrcCodcred(),
					prePrcconta.getPrcCodmod(), null, prePrcconta.getPrcFecha2(), Cttes.ESTOPER_ENREV, usuario, estacion);        

        return prePrccontaQLLocal.buscarPorId(prePrcconta.getPrcCodprc());
    }

    public void rechazarDevengadoManual(PrePrcconta prePrccontaIn,String usuario, String estacion) {
        Integer tipotrx = 9; 
        if (prePrccontaIn.getPrcCodprc() == null) {
            throw new RuntimeException("Operacion no registrada, con id nulo");
        }
        prePrccontaQLLocal.initProcesoConta(prePrccontaIn.getPrcCodcmp(),prePrccontaIn.getPrcCodprc(), tipotrx, prePrccontaIn.getPrcCodcred(), prePrccontaIn.getPrcCodmod(),
        null, prePrccontaIn.getPrcFecha2(), usuario, estacion);

    }

    public void actDeCoinDevengadoManual(PrePrcconta prePrccontaIn,String usuario, String estacion) {
        Integer tipotrx = 3; // actualizar
        if (prePrccontaIn.getPrcCodprc() == null) {
            throw new RuntimeException("Operacion no registrada con id nulo");
        }

        prePrccontaQLLocal.initProcesoConta(prePrccontaIn.getPrcCodcmp(),prePrccontaIn.getPrcCodprc(), tipotrx, prePrccontaIn.getPrcCodcred(), prePrccontaIn.getPrcCodmod(),
        null, prePrccontaIn.getPrcFecha2(), usuario, estacion);

    }

    public List<PrePrcconta> devengadosContByCred(Integer prcCodcred, Integer prcCodmod) {
        return prePrccontaQLLocal.devengadosContByCred(prcCodcred, prcCodmod);
    }

    public List<PrePrcconta> devsGenerados(Integer prcCodcred, Integer prcCodmod, Integer estado, Date fechaCont) {
        return prePrccontaQLLocal.devsGenerados(prcCodcred, prcCodmod, estado, fechaCont);
    }

    public void cambiarEstadoOperComprob(Integer tipocmp, Integer idtabla, Integer codcred, Integer codmod,
            Integer coddsb, Date fecha, Integer estado, String usuario, String estacion) {
        prePrccontaQLLocal.cambiarEstadoOperComprob(tipocmp, idtabla, codcred, codmod, coddsb, fecha, estado, usuario,
                estacion);
    } 

    public GenericDao<PrePrcconta, Integer> getGenericDao() {
        throw new UnsupportedOperationException("Unimplemented method 'getGenericDao'");
    }
}

