package gob.bcb.jee.creditos.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;

import gob.bcb.jee.creditos.util.Reflection;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Embeddable
public class PrePrestamosPK  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="pre_codmod")
	private Integer preCodmod;
	@GeneratedValue
	@Column(name="pre_codcred")
	private Integer preCodcred;
		

	public PrePrestamosPK() {
	}
	public PrePrestamosPK(Integer preCodmod, Integer preCodcred) {
		super();
		this.preCodcred = preCodcred;
		this.preCodmod = preCodmod;
	}

	

	@Override
	public String toString() {
		Reflection<PrePrestamosPK> reflex=new Reflection<PrePrestamosPK>();
		return reflex.imprimirCampos(this);
	}

    @Override
    public boolean equals(Object o) {
    	Reflection<PrePrestamosPK> reflex=new Reflection<PrePrestamosPK>();
		return reflex.equals(this,o);      
    }

    @Override
    public int hashCode() {
    	Reflection<PrePrestamosPK> reflex=new Reflection<PrePrestamosPK>();
		return reflex.generarHash(this);
    }  
}
