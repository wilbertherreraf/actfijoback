package gob.bcb.jee.creditos.QL;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import gob.bcb.jee.creditos.entidades.PreRegistrogarantias;
import gob.bcb.jee.creditos.excepciones.OperationException;

@Local
public interface PreRegistrogarantiasQLLocal extends
        GenericQLLocal<PreRegistrogarantias, Integer> {

    List<Object[]> getParametrosGlosa(Integer tipoOperacion) throws OperationException;

    public Integer getNumeroTotalDesembolso(Integer codcred,Integer codmod) throws OperationException;

    public String getNumeroSerieGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    public Integer getEstadoGarantia(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    public String generarCmpbBonos(Integer idTable,Integer tipoOperacion,Integer codcred,Integer codmod, Date fecha, String glosa, String usuario, String host) ;

    public Integer verificarRegistroTransitorioGarantias(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    PreRegistrogarantias obtenerPorCodDesembolso(Integer pCodDesembolso);

    PreRegistrogarantias buscarPorId(Integer id);

    PreRegistrogarantias guardarRegGar(PreRegistrogarantias entity);
}
