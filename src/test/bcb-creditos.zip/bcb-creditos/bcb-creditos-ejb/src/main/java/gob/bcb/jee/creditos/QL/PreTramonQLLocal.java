/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;

import java.sql.SQLException;
import java.util.Date;

import javax.ejb.Local;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreTramon;
import gob.bcb.jee.creditos.model.PreTramonPK;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface PreTramonQLLocal extends
        GenericQLLocal<PreTramon,PreTramonPK>
{

	public void reversaTransaccion(Integer codcred,Integer codmod,Integer numtrx, Date fechaOper,String usuario, String estacion)throws OperationException,SQLException;
	
	public void reversaTransaccionDif(Integer codcred,Integer codmod,Integer tipotrx, Date fecha, String usuario, String estacion)
			throws OperationException, SQLException;
	
}
