package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the gen_usuario database table.
 * 
 */
@Entity
@Table(name="gen_usuario")
@NamedQuery(name="GenUsuario.findAll", query="SELECT g FROM GenUsuario g")
public class GenUsuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="usr_codusr")
	private String usrCodusr;

	@Column(name="usr_auditfho")
	private Timestamp usrAuditfho;

	@Column(name="usr_audittrx")
	private String usrAudittrx;

	@Column(name="usr_auditusr")
	private String usrAuditusr;

	@Column(name="usr_auditwst")
	private String usrAuditwst;

	@Column(name="usr_codcoin")
	private String usrCodcoin;

	@Column(name="usr_nombre")
	private String usrNombre;

	@Column(name="usr_statreg")
	private Integer usrStatreg;

	@Column(name="usr_tabstatreg")
	private Integer usrTabstatreg;

	public GenUsuario() {
	}

	public String getUsrCodusr() {
		return this.usrCodusr;
	}

	public void setUsrCodusr(String usrCodusr) {
		this.usrCodusr = usrCodusr;
	}

	public Timestamp getUsrAuditfho() {
		return this.usrAuditfho;
	}

	public void setUsrAuditfho(Timestamp usrAuditfho) {
		this.usrAuditfho = usrAuditfho;
	}

	public String getUsrAudittrx() {
		return this.usrAudittrx;
	}

	public void setUsrAudittrx(String usrAudittrx) {
		this.usrAudittrx = usrAudittrx;
	}

	public String getUsrAuditusr() {
		return this.usrAuditusr;
	}

	public void setUsrAuditusr(String usrAuditusr) {
		this.usrAuditusr = usrAuditusr;
	}

	public String getUsrAuditwst() {
		return this.usrAuditwst;
	}

	public void setUsrAuditwst(String usrAuditwst) {
		this.usrAuditwst = usrAuditwst;
	}

	public String getUsrCodcoin() {
		return this.usrCodcoin;
	}

	public void setUsrCodcoin(String usrCodcoin) {
		this.usrCodcoin = usrCodcoin;
	}

	public String getUsrNombre() {
		return this.usrNombre;
	}

	public void setUsrNombre(String usrNombre) {
		this.usrNombre = usrNombre;
	}

	public Integer getUsrStatreg() {
		return this.usrStatreg;
	}

	public void setUsrStatreg(Integer usrStatreg) {
		this.usrStatreg = usrStatreg;
	}

	public Integer getUsrTabstatreg() {
		return this.usrTabstatreg;
	}

	public void setUsrTabstatreg(Integer usrTabstatreg) {
		this.usrTabstatreg = usrTabstatreg;
	}

}
