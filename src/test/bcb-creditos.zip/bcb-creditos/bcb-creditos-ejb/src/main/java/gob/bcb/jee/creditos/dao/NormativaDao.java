/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-creditos-ejb
 * gob.bcb.jee.creditos.dao.NormativaDao
 * 01/04/2016 - 17:25:16
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.Normativa;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * Clase Dao para el control de los Normativa
 *
 * @author ysalinas
 */
@Stateless
public class NormativaDao extends
        GenericDao<Normativa, Integer> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public NormativaDao() {
    }

    public NormativaDao(Class<Normativa> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}
