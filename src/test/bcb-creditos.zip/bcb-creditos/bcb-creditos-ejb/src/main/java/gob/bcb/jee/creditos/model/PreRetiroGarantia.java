package gob.bcb.jee.creditos.model;

import gob.bcb.jee.creditos.entidades.EntidadAutorizable;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * PreRetiroGarantia
 *
 * @author mcramos
 * 11/03/2025
 */
@Entity
@Table(name = "pre_retiro_garantia")
@Getter
@Setter
@NamedQueries({
        @NamedQuery(name = "PreRetiroGarantia.findAll", query = "SELECT p FROM PreRetiroGarantia p"),
        @NamedQuery(name = "PreRetiroGarantia.findById", query = "SELECT p FROM PreRetiroGarantia p WHERE p.id = :id")
})
public class PreRetiroGarantia extends EntidadAutorizable<Integer> implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    @Column(name = "id")
    private Integer id;

    
    @Column(name = "codcred")
    private Integer codcred;

    
    @Column(name = "codmod")
    private Integer codmod;

    
    @Column(name = "fecha")
    @Temporal(TemporalType.DATE)
    private Date fecha;

    @Column(name="nro_claveserie")
    private String nroClaveSerie;

    @Column(name = "acta_retiro")
    private String actaRetiro;

    @Column(name = "cuota")
    private Integer cuota;

    @Column(name = "fecha_vencimiento")
    @Temporal(TemporalType.DATE)
    private Date fechaVencimiento;

    @Column(name = "valor_cuota")
    private BigDecimal valorCuota;

    @Column(name = "rtg_codcmp")
    private Integer rtgCodcmp;
    
    @Column(name = "estado")
    private Integer estado;
    @Column(name = "cve_tipo_comprob")
    private String cveTipoComprob;

    @Column(name = "nro_comprobante_coin")
    private String nroComprobanteCoin;

    @Column(name = "glosa_coin")
    private String glosaCoin;

    @Column(name = "glosa_debe")
    private String glosaDebe;

    @Column(name = "glosa_haber")
    private String glosaHaber;

    @Column(name = "cambio_bd")
    private String cambioBd;

    @Column(name = "audit_usuario")
    private String auditUsuario;

    @Column(name = "audit_fechahora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahora;

    @Column(name = "audit_host")
    private String auditHost;

    @Column(name = "audit_usuario_genera")
    private String auditUsuarioGenera;

    @Column(name = "audit_fechahora_genera")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraGenera;

    @Column(name = "audit_host_genera")
    private String auditHostGenera;

    @Column(name = "audit_usuario_preautoriza")
    private String auditUsuarioPreautoriza;

    @Column(name = "audit_fechahora_preautoriza")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraPreautoriza;

    @Column(name = "audit_host_preautoriza")
    private String auditHostPreautoriza;

    @Column(name = "audit_usuario_autoriza")
    private String auditUsuarioAutoriza;

    @Column(name = "audit_fechahora_autoriza")
    @Temporal(TemporalType.TIMESTAMP)
    private Date auditFechahoraAutoriza;

    @Column(name = "audit_host_autoriza")
    private String auditHostAutoriza;

    @JoinColumn(name = "coddsb", referencedColumnName = "dsb_coddsb")
    @ManyToOne(optional = false)
    private PreDesemb coddsb;

    @Transient
    private Integer cuotaPagada;
}
