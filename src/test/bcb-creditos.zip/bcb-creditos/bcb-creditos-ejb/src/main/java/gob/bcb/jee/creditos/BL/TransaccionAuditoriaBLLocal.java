package gob.bcb.jee.creditos.BL;

import gob.bcb.jee.creditos.entidades.TransaccionAuditoria;

import javax.ejb.Local;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.BL
 * 28/06/2016 - 10:56 AM
 * Created por aescobar
 */

@Local
public interface TransaccionAuditoriaBLLocal extends GenericBLLocal<TransaccionAuditoria, String> {
}
