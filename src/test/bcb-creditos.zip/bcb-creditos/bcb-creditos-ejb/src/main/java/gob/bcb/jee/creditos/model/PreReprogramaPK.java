package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the pre_reprograma database table.
 * 
 */
@Embeddable
public class PreReprogramaPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="rpp_codrep")
	private Integer rppCodrep;

	@Column(name="rpp_codcred", insertable=false, updatable=false)
	private Integer rppCodcred;

	@Column(name="rpp_codmod", insertable=false, updatable=false)
	private Integer rppCodmod;

	public PreReprogramaPK() {
	}
	public Integer getRppCodrep() {
		return this.rppCodrep;
	}
	public void setRppCodrep(Integer rppCodrep) {
		this.rppCodrep = rppCodrep;
	}
	public Integer getRppCodcred() {
		return this.rppCodcred;
	}
	public void setRppCodcred(Integer rppCodcred) {
		this.rppCodcred = rppCodcred;
	}
	public Integer getRppCodmod() {
		return this.rppCodmod;
	}
	public void setRppCodmod(Integer rppCodmod) {
		this.rppCodmod = rppCodmod;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PreReprogramaPK)) {
			return false;
		}
		PreReprogramaPK castOther = (PreReprogramaPK)other;
		return 
			(this.rppCodrep == castOther.rppCodrep)
			&& (this.rppCodcred == castOther.rppCodcred)
			&& (this.rppCodmod == castOther.rppCodmod);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.rppCodrep;
		hash = hash * prime + this.rppCodcred;
		hash = hash * prime + this.rppCodmod;
		
		return hash;
	}
}
