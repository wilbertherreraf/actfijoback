/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.dao.FeriadoDao
 * 22/01/2016 - 10:51:59
 * Creado por ySalinas
 */
package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.LogAuditoria;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * Clase Dao para el control de los logs de auditoria
 *
 * @author ySalinas
 */
@Stateless
public class LogAuditoriaDao extends GenericDao<LogAuditoria, Long> implements
        Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    /**
     *
     */
    public LogAuditoriaDao() {
    }

    public LogAuditoriaDao(Class<LogAuditoria> entityClass) {
        super(entityClass);
    }

    /*
     * (non-Javadoc)
     * @see
     * gob.bcb.jee.creditos.jee.mse.QL.GenericQLLocalImpl#entityManager
     * ()
     */
    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

}