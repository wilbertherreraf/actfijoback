package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.GenParametro;
import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.HashMap;
import java.util.List;

/**
 * GenParametroQLLocalImpl
 *
 * @author mcramos
 * 13/01/2025
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class GenParametroQLLocalImpl extends GenericQLLocalImpl<GenParametro, Integer> implements GenParametroQLLocal {
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }

    @Override
    public List<GenParametro> obtenerPorCodCredito(Integer pCodCred) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("pCodcred", pCodCred);
        return listByNamedQuery(GenParametro.NQ_GET_LIST_BY_CREDITO, params);
    }

    @Override
    public String getNumeroCuenta(Integer codcred,Integer codmod,Integer tipo) throws OperationException {
        Object valor = null;
        try{
            String nativeQuery= " SELECT par_parametro  " +
                    " from d_creditos.gen_parametro " +
                    " where par_codmod=:codmod " +
                    " and par_codcred=:codcred " +
                    " and par_tprcod=:tipo  ";

            Query query=entityManager.createNativeQuery(nativeQuery);
            query.setParameter("codcred", codcred);
            query.setParameter("codmod", codmod);
            query.setParameter("tipo", tipo);

            valor= query.getSingleResult();

        }catch (NoResultException e){
            //no se encontro ningun resultado
            String error ="No se ha registrado el número de cuenta contable en el DEBE o HABER para el crédito. ";
            throw new OperationException(error);
        }

        return (valor!=null?valor.toString():"");
    } 

}
