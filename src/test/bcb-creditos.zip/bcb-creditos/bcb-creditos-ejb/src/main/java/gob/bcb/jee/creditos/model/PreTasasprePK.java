package gob.bcb.jee.creditos.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;
import javax.validation.constraints.Null;

import lombok.Getter;
import lombok.Setter;

/**
 * The primary key class for the pre_tasaspre database table.
 * 
 */
@Getter
@Setter
@Embeddable
public class PreTasasprePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="mtp_codmod", insertable=false, updatable=false)
	private Integer mtpCodmod;

	@Column(name="mtp_codcred", insertable=false, updatable=false)
	private Integer mtpCodcred;

	@Temporal(TemporalType.DATE)
	@Column(name="mtp_fechavig")	
	private java.util.Date mtpFechavig;

	public PreTasasprePK() {
	}
	
	public PreTasasprePK(Integer codcred,Integer codmod, Date fecha) {
		this.mtpCodcred =codcred;
		this.mtpCodmod=codmod;
		this.mtpFechavig=fecha;
		
	}
	

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PreTasasprePK)) {
			return false;
		}
		PreTasasprePK castOther = (PreTasasprePK)other;
		return 
			(this.mtpCodmod == castOther.mtpCodmod)
			&& (this.mtpCodcred == castOther.mtpCodcred)
			&& this.mtpFechavig.equals(castOther.mtpFechavig);
	}

	public int hashCode() {
		final Integer prime = 31;
		int hash = 17;
		hash = hash * prime + this.mtpCodmod;
		hash = hash * prime + this.mtpCodcred;
		hash = hash * prime + this.mtpFechavig.hashCode();
		
		return hash;
	}
}
