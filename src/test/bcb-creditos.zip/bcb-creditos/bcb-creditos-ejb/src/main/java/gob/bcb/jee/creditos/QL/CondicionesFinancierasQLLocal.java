package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.entidades.CondicionesFinancieras;

import javax.ejb.Remote;

/**
 * Banco Central de Bolivia
 * La Paz - Bolivia
 * bcb-creditos
 * gob.bcb.jee.creditos.QL
 * 29/11/2016 - 13:30 PM
 * Creado por aescobar
 */
@Remote
public interface CondicionesFinancierasQLLocal extends
        GenericQLLocal<CondicionesFinancieras, Long> {

}