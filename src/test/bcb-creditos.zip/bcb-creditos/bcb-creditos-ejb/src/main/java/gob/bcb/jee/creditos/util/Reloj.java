/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.mse.util.Reloj
 * 18/11/2015 - 08:58:56
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.util;

import lombok.Getter;
import lombok.Setter;


/**
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 * 
 * 
 * @author ysalinas
 * 
 */
@Getter
@Setter
public class Reloj
{
  private static String hora;
  private static String hora2;

 
  public static void main(String[] args)
  {

    // new ClockView();
    ClockView clockTest = new ClockView();
    // clockTest.setVisible(true);

    hora = clockTest.getHora();
    hora2 = clockTest.horaCapturada;

    Log.Info("LA HORA UNO ES : " + hora);
    Log.Info("LA HORA DOS ES : " + hora2);

  }
}
