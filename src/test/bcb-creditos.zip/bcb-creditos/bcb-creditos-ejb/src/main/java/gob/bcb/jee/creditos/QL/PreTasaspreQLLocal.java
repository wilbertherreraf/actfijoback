/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-mse-ejb
 * gob.bcb.jee.creditos.jee.creditos.QL.EmpresaQLLocal
 * 06/11/2015 - 15:02:02
 * Creado por ysalinas
 */
package gob.bcb.jee.creditos.QL;


import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreTasaspre;
import gob.bcb.jee.creditos.model.PreTasasprePK;

import java.util.Date;

import javax.ejb.Local;

/**
 * Interfaz para los metodos de consulta (QL) para la entidad Empresa
 * 
 * 
 * @author ysalinas
 * 
 */
@Local
public interface PreTasaspreQLLocal extends
        GenericQLLocal<PreTasaspre,PreTasasprePK>
{
	public double obtenerTasaVigente(Integer codcred,Integer codmod, Date fecha) throws OperationException;
	public PreTasaspre obtenerUltimaTasa(Integer codcred,Integer codmod) throws OperationException;
	public void update(Integer codcred,Integer codmod, Date fecha, Date newFecha, double tasa,Integer base ) throws OperationException;
}
