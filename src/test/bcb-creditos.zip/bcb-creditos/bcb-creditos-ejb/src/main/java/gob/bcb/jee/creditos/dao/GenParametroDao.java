package gob.bcb.jee.creditos.dao;

import gob.bcb.jee.creditos.entidades.GenParametro;
import gob.bcb.jee.creditos.util.Cttes;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.Serializable;

/**
 * GenParametroDao
 *
 * @author mcramos
 * 13/01/2025
 */
@Stateless
public class GenParametroDao extends GenericDao<GenParametro, Integer> implements Serializable {
    private static final long serialVersionUID = 1L;
    @PersistenceContext(unitName = Cttes.UP_CREDITOSBCB)
    private EntityManager entityManager;

    public GenParametroDao() {
    }

    public GenParametroDao(Class<GenParametro> entityClass) {
        super(entityClass);
    }

    @Override
    protected EntityManager entityManager() {
        return entityManager;
    }
}
