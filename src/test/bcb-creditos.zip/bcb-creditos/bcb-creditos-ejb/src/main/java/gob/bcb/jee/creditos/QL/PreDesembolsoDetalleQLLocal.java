package gob.bcb.jee.creditos.QL;

import gob.bcb.jee.creditos.excepciones.OperationException;
import gob.bcb.jee.creditos.model.PreDesembolsoDetalle;

import javax.ejb.Local;
import java.util.List;

/**
 * PreDesembolsoDetalleQLLocal
 *
 * @author mcramos
 * 11/02/2025
 */
@Local
public interface PreDesembolsoDetalleQLLocal extends GenericQLLocal<PreDesembolsoDetalle, Integer> {

    PreDesembolsoDetalle obtenerPorCodDesembolso(Integer pCodDesembolso);

    public Integer getEstadoDesembolsoDetalle(Integer codcred,Integer codmod,Integer coddsb) throws OperationException;

    public List<String> getLeyesPrestamo(String leyes) throws OperationException;

    PreDesembolsoDetalle guardarDsbDetalle(PreDesembolsoDetalle dsbDetalle);
}
