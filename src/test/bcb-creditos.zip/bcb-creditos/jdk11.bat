echo off
set JAVA_HOME=c:\Program Files\OpenLogic\jdk-11.0.22.7-hotspot
set PATH=%JAVA_HOME%\bin;%PATH%
echo "Version Java"
java -version