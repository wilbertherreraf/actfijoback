



DROP procedure IF exists d_creditos.p_updsumtrans;
create procedure d_creditos.p_updsumtrans(p_codmod integer, p_codcred integer, p_coddsbnumcuo integer, p_tipotrx integer, p_cobcodigo integer, p_fechatrx date, 
    p_importe decimal(20,2))
{
Actualiza el prestamo y el desembolso segun los montos efectivizados en pre_cobros
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| wherrera  |  2026.04.03   |          | se actualiza la sumatoria de pre_prestamos desde pre_desemb
----------------------------------------------------------------------------
call p_updsumtrans(17, 55, null, null, null, null,null)
}            
    define v_pre_montsusp, v_saldok, v_pre_monto,v_dsb_valor, v_mnt_dsb, v_mnt_cobros like pre_cobros.cob_valor;
	define v_sum_dsb_valor, v_sum_dsb_undsb, v_sum_dsb_saldo, v_sum_dsb_valorcuo like pre_cobros.cob_valor;
    define V_MNT_PRG_FECHA, V_MNT_PRGPEND_FECHA, V_MNT_PRG_ANT, v_cuo_valorpend, v_diff_mnt like pre_cobros.cob_valor;
    define v_cuo_tipoacu, v_dsb_coddsb, v_cuo_tipocuo, v_new_monpag integer;
    define v_min_fecvencuo, v_max_fecvencuo, v_feculttrx, v_fecultvto,v_dsb_fecplzven date;
    DEFINE v_new_status, v_pre_status, C_PRESTATUS_UNDSB, C_PRESTATUS_VIG, C_PRESTATUS_CANC INTEGER;
    define v_cont_tipodsb,v_contaux, C_TIPOCOB_DSB integer;
    define C_TIPOTRAN_DSB, C_TIPOTRAN_COB integer;
    define C_TIPOTRX_DIFER, C_TIPOCUO_CAP, C_TIPOCUO_INT integer;
    define v_updprestamos, v_difflastupd integer;
	DEFINE GLOBAL G_FLAG_EXETRIGGER_PRE INT DEFAULT -1;
	DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
	DEFINE C_FLAG_EXETRIGGER_PRE_NOEXE INTEGER;
	define v_pre_auditfho like pre_prestamos.pre_auditfho;
	
    let C_TIPOTRAN_COB = 2;
    LET C_TIPOTRAN_DSB = 1;
    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
    let C_TIPOCOB_DSB = 3;
    let C_PRESTATUS_UNDSB = 1;
    let C_PRESTATUS_VIG = 2;
    let C_PRESTATUS_CANC = 9;    
    LET C_TIPOTRX_DIFER = 4;
    LET C_FLAG_EXETRIGGER_PRE_NOEXE = 1;    
    let v_cuo_valorpend = 0;
    let v_updprestamos = 1;
    let v_difflastupd = 0;
    let v_pre_auditfho = null;
    let v_pre_status = null;
    
    	select pre_status, pre_monto, pre_auditfho, pre_saldo, pre_monliqent,pre_montsusp
    	into v_new_status, v_pre_monto, v_pre_auditfho, v_saldok, v_sum_dsb_undsb, v_pre_montsusp
    	from pre_prestamos
        where pre_codmod = p_codmod
        and pre_codcred = p_codcred;
    	
		IF (dbinfo ("sqlca.sqlerrd2") = 0) then
		
        	return;
    	end if    	
        let v_new_status = nvl(v_new_status,C_PRESTATUS_UNDSB);
    	if v_new_status = C_PRESTATUS_CANC then
    		return;
    	end if
    	
		if v_pre_auditfho is not null then
			let v_difflastupd = (CURRENT - v_pre_auditfho)::INTERVAL SECOND(9) TO SECOND::VARCHAR(10)::INTEGER;
		
    		if v_new_status > 0 and v_difflastupd <= 15 and v_difflastupd > 0 and  nvl(p_cobcodigo,0) != C_TIPOCOB_DSB and p_tipotrx is null then
    			-- la ultima actualizacion fue reciente
    		    			
    			return;
    		end if
    		
		end if

        let v_dsb_coddsb = null;
        
		select count(1)
        into v_cont_tipodsb 
		from aux_planpagos
		where acu_codcred = p_codcred
		and acu_codmod = p_codmod;
        
        if p_coddsbnumcuo is null or v_pre_auditfho is null then
        
            foreach
                select dsb_coddsb
                into v_dsb_coddsb
                from pre_desemb
                where dsb_codmod = p_codmod
                and dsb_codcred = p_codcred
                and dsb_tipodsb != 3 -- CERRADO  
                
                call p_updsumtrans_dsb(p_codcred, p_codmod, v_dsb_coddsb, p_fechatrx);
                
		        if v_cont_tipodsb > 0 then
			        select count(1)
			        into v_contaux 
					from aux_planpagos
					where acu_codcred = p_codcred
					and acu_codmod = p_codmod
			        and acu_coddsb = v_dsb_coddsb;
		        	
		        	if v_contaux > 0 then
						delete from aux_planpagos
						where acu_codcred = p_codcred
						and acu_codmod = p_codmod
						and acu_coddsb = v_dsb_coddsb
						and acu_auditfho < (select max(cuo_auditfho) 
							from pre_planpagos
							where cuo_codcred = acu_codcred
							and cuo_codmod = acu_codmod
							and cuo_coddsb = acu_coddsb
							and cuo_coddsb > 0
							and cuo_valor > 0);
		        	end if
				end if                
            end foreach
        else 
				call p_updsumtrans_dsb(p_codcred, p_codmod, p_coddsbnumcuo, p_fechatrx);
				if v_cont_tipodsb > 0 then
			        select count(1)
			        into v_contaux 
					from aux_planpagos
					where acu_codcred = p_codcred
					and acu_codmod = p_codmod
			        and acu_coddsb = p_coddsbnumcuo;
		        	
		        	if v_contaux > 0 then
						delete from aux_planpagos
						where acu_codcred = p_codcred
						and acu_codmod = p_codmod
						and acu_coddsb = p_coddsbnumcuo
						and acu_auditfho < (select max(cuo_auditfho) 
							from pre_planpagos
							where cuo_codcred = acu_codcred
							and cuo_codmod = acu_codmod
							and cuo_coddsb = acu_coddsb
							and cuo_coddsb > 0);
		        	end if
				end if   				
        end if
        
 		let v_dsb_fecplzven = null;
 		let v_feculttrx = null;
 		
        select nvl(sum(dsb_valor),0), nvl(sum(dsb_undsb),0), nvl(sum(dsb_saldo),0), nvl(sum(dsb_valorcuo),0),max(dsb_fecplzven), 
        max(dsb_feculttrx),count(distinct dsb_tipodsb) 
        into v_sum_dsb_valor, v_sum_dsb_undsb, v_sum_dsb_saldo, v_sum_dsb_valorcuo, v_dsb_fecplzven,
        v_feculttrx, v_cont_tipodsb
        from pre_desemb
        where dsb_codcred = p_codcred
        and dsb_codmod = p_codmod;
        
        let v_saldok = v_sum_dsb_undsb - v_sum_dsb_saldo;
        let v_new_status = nvl(v_new_status,C_PRESTATUS_UNDSB);
    
        if v_sum_dsb_undsb = 0 or v_sum_dsb_valor = 0 then
        	let v_new_status = C_PRESTATUS_UNDSB;
        end if
		if v_new_status = C_PRESTATUS_UNDSB then
		-- aseguramos que no hay movimientos en pp
        	select count(1)
        	into v_contaux
        	from pre_planpagos
        	where cuo_codcred = p_codcred
        	and cuo_codmod = p_codmod
        	and cuo_coddsb > 0
        	and cuo_valor > 0  
        	and cuo_valor > cuo_valorpend;
        
        	if v_contaux > 0 then
        		let v_new_status = C_PRESTATUS_VIG;
        	end if
        end if
 
        if v_sum_dsb_valor > 0 and v_sum_dsb_undsb > 0 and v_sum_dsb_valorcuo > 0 then
            let v_new_status = C_PRESTATUS_VIG;
        	call f_pp_minmax_plan(p_codcred, p_codmod, null, null) returning v_min_fecvencuo, v_max_fecvencuo;
        
        	if v_max_fecvencuo < (date(current)-8) then
        		let v_new_status = C_PRESTATUS_CANC;
				let v_feculttrx = v_max_fecvencuo;
        	end if
        end if

        if v_pre_monto > 0 and v_sum_dsb_valor > 0 and v_saldok <= 0.90 and v_pre_montsusp <= 0.90 and v_sum_dsb_undsb > 0 and v_sum_dsb_saldo > 0 then
        	CALL f_pp_sum_portipo(p_codcred, p_codmod, null, null, null, C_TIPOCUO_INT) returning V_MNT_PRG_FECHA, V_MNT_PRGPEND_FECHA;
        	let V_MNT_PRGPEND_FECHA = V_MNT_PRG_FECHA - (V_MNT_PRG_FECHA - V_MNT_PRGPEND_FECHA);
        	if V_MNT_PRGPEND_FECHA <= 0 then
            	let v_new_status = C_PRESTATUS_CANC;
        	end if
        end if        
        
        LET G_FLAG_EXETRIGGER_PRE = C_FLAG_EXETRIGGER_PRE_NOEXE;
		
        if v_new_status = C_PRESTATUS_CANC then
        		update pre_desemb
        		set dsb_tipodsb = 3,
        		dsb_monpag = 2
        		where dsb_codmod = p_codmod
        		and dsb_codcred = p_codcred;        
        end if
        
        update pre_prestamos
        set pre_saldo = v_saldok,
        pre_monliqent = v_sum_dsb_undsb,
        pre_montsusp = v_sum_dsb_valorcuo, -- cap cobrado en pp
        pre_feculttrx = nvl(v_feculttrx, pre_fecemi), --ultima actividad
        pre_fecplzven = v_dsb_fecplzven, --ultimo devengado
        pre_status = v_new_status,
        pre_auditfho = current
        where pre_codmod = p_codmod
        and pre_codcred = p_codcred;
        
        LET G_FLAG_EXETRIGGER_PRE = -1;

        call p_pp_dsb_cero_actxfecha(p_codcred, p_codmod, 1, null);
end procedure;


