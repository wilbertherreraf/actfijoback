

DROP function IF EXISTS d_creditos.f_fec_primervenc;
create function d_creditos.f_fec_primervenc(p_codcred integer, p_codmod integer, p_fecha date, p_statrepro integer)
    returning date, date, date, date, date

{***** ==> LOG <== *****
wherrera    2021-10-05  determina las fechas de primer desembolso, primer vencimiento a fecha,   

-- DESCRIPCION: determina el numero de periodos 
-- PARAMETROS INGRESO: p_codcred integer, p_codmod integer, p_fecha date, p_statrepro integer
--                     


-- PARAMETROS SALIDA:  date, date, date, date, date 
-- AUTOR: wherrera
-- CREACION: 2021-10-15

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| wherrera  |  2021-1015   |          | procedimiento para la amortizacion de saldos deudores
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  13-10-2025   | 2333600  | Ajustes en el procedimiento para añ¡¤©r el calculo de plan de pagos para creditos de 365 dias
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  20-11-2025   | 2663562  | Ajustes en el procedimiento para corregir la observacion en el reporte consolidado de plan de pagos
-----------------------------------------------------------------------------------------------------------------------------------------------------


}
    define v_min_fecvencuo, v_max_fecvencuo, v_min_fecdsb, v_fecini, v_feciniint date;
    define C_TIPOCUO_CAP, C_TIPOCUO_INT integer;
    define C_INPUT_PERIOD_EXACT integer;
    define v_numpers, v_rds_codrepro, v_rds_trxstaau integer;
    define v_pre_methodcapi, v_pre_unidplaz, v_mtp_intydias integer;
    define v_pre_nroperiodos, v_pre_nrogracia, v_pre_nrograciaint, v_pre_nropagos, v_pre_diasfijoper integer;
    define v_min_fectrx, v_fecmax_cap, v_rds_feculttrx, v_fecha_prim_venc date;
    define v_nroper_pp_cal, v_rds_unidplaz, v_rds_nroperiodos, v_rds_diasfijoper integer;
   
        
    let v_numpers = 0;
    LET C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
    let C_INPUT_PERIOD_EXACT = 3;
	let p_statrepro = nvl(p_statrepro, 3); --autorizado
    let v_min_fecdsb = f_dsb_fecmin(p_codmod, p_codcred, null);
	let v_mtp_intydias = 360;
    let v_rds_codrepro = f_rpro_ultrepro(p_codcred, p_codmod, p_fecha);

    call f_dsb_getmethod_plz(p_codcred, p_codmod, null) returning v_pre_methodcapi, v_pre_unidplaz;
    call f_get_info_genperiodos(p_codcred, p_codmod) returning v_pre_nroperiodos, v_pre_nrogracia, v_pre_nrograciaint, v_pre_nropagos, v_pre_diasfijoper; 
        
        select min(dsb_fecini) , min(dsb_feciniint) 
        into v_fecini, v_feciniint
        from pre_desemb 
        where dsb_codmod = p_codmod
        and dsb_codcred = p_codcred;
                 
	    if v_rds_codrepro > 0 then
    
	        SELECT rds_feculttrx, rds_fecini, rds_feciniint, rds_unidplaz, rds_nroperiodos, rds_diasfijoper, rds_trxstaau
	        into v_rds_feculttrx, v_fecini, v_feciniint, v_rds_unidplaz, v_rds_nroperiodos, v_rds_diasfijoper, v_rds_trxstaau
	        from pre_reprograma
	        where rds_codrepro = v_rds_codrepro;
	
	        if p_statrepro is not null then
	            if p_statrepro = 3 then
	                if v_rds_trxstaau = 3 then
	                    let v_min_fecdsb = v_rds_feculttrx;
	                    let v_pre_unidplaz = nvl(v_rds_unidplaz, v_pre_unidplaz);
	                    let v_pre_diasfijoper = nvl(v_rds_diasfijoper, v_pre_diasfijoper);
	                    let v_pre_nroperiodos = v_rds_nroperiodos;            
	                end if
	            else
	                let v_min_fecdsb = v_rds_feculttrx;
	                let v_pre_unidplaz = nvl(v_rds_unidplaz, v_pre_unidplaz);
	                let v_pre_diasfijoper = nvl(v_rds_diasfijoper, v_pre_diasfijoper);
	                let v_pre_nroperiodos = v_rds_nroperiodos;                        
	            end if
	        else
	            let v_min_fecdsb = v_rds_feculttrx;
	            let v_pre_unidplaz = nvl(v_rds_unidplaz, v_pre_unidplaz);
	            let v_pre_diasfijoper = nvl(v_rds_diasfijoper, v_pre_diasfijoper);
	            let v_pre_nroperiodos = v_rds_nroperiodos;                                
	        end if
	    end if

        if nvl(v_feciniint, v_fecini) < v_fecini then
            let v_fecha_prim_venc = nvl(v_feciniint, v_fecini);
        else 
            let v_fecha_prim_venc = v_fecini;
        end if

        call f_periodos_fechas(v_min_fecdsb, v_fecha_prim_venc, v_pre_unidplaz, v_pre_diasfijoper, C_INPUT_PERIOD_EXACT,1, 0) 
            returning v_numpers, v_nroper_pp_cal, v_fecmax_cap;
        -- requerido por formula
        let v_numpers = v_nroper_pp_cal - 1;
        
        if v_numpers < 0 then
            let v_numpers = 0;
        end if
        
        -- 1ra cuota
        let v_min_fecvencuo = f_periodo_fechafin(v_fecha_prim_venc, v_numpers * (-1), v_pre_unidplaz, v_pre_diasfijoper, null);
        
        if v_min_fecvencuo <= v_min_fecdsb then
            let v_numpers = v_nroper_pp_cal - 2;
            
            if v_numpers < 0 then
                let v_numpers = 0;
            end if
            
            -- 1ra cuota
            let v_min_fecvencuo = f_periodo_fechafin(v_fecha_prim_venc, v_numpers * (-1), v_pre_unidplaz, v_pre_diasfijoper, null);            
        end if
        
        let v_min_fectrx = f_dsb_fecmin_trx(p_codmod, p_codcred, null, 2);
        
        if v_min_fecvencuo <= v_min_fecdsb then
            let v_min_fecvencuo = v_fecha_prim_venc;
        end if
        
        if v_min_fectrx is not null then
            let v_min_fecvencuo = v_min_fectrx;
        end if
         
		SELECT  mtp_intydias
		INTO  v_mtp_intydias
		FROM  pre_tasaspre
		WHERE mtp_codcred = p_codcred
		and mtp_codmod = p_codmod
		AND   mtp_fechavig = (
		        SELECT MAX(mtp_fechavig) 
		        FROM  pre_tasaspre
		        WHERE mtp_codcred = p_codcred
		        and mtp_codmod = p_codmod
		        AND mtp_fechavig <= v_min_fecvencuo
		        );        
		
        if v_mtp_intydias = 365 then
       		let v_max_fecvencuo = f_periodo_fechafin_365(v_min_fecvencuo, v_pre_nroperiodos, v_pre_unidplaz, v_pre_diasfijoper, null, p_codcred); --  para creditos 365
        else
       		let v_max_fecvencuo = f_periodo_fechafin(v_min_fecvencuo, v_pre_nroperiodos, v_pre_unidplaz, v_pre_diasfijoper, null);
        end if
        
        return v_min_fecdsb, v_min_fecvencuo, v_fecini, v_feciniint, v_max_fecvencuo;
end function;





