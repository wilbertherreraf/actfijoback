

drop procedure if exists d_creditos.p_genop_crear_venc;
create procedure d_creditos.p_genop_crear_venc(p_tmo_t pre_tramon_t) 
--returnING varchar(50)
{
 wherrera 2021.11.05   genera una operacion de cobro de la deuda a una fecha determinada si existiera saldo
}
    define v_cuo_fecvencuo, v_acu_fecvencuo like pre_planpagos.cuo_fecvencuo;
    define v_sum_amort, v_mnt_amortiza_pp, v_mnt_amortiza, v_cob_valor, v_dsb_valoraux, v_cuo_valor, v_cuo_valorpend  like pre_planpagos.cuo_valor;
    define v_dsb_valor, v_dsb_undsb, v_dsb_saldo, v_panti_int, v_panti_cap like pre_desemb.dsb_valor;
    define v_idpagocuota,v_dsb_coddsb, v_cuo_coddsb, v_cuo_codcuo, v_firstreg, v_cuo_tipocuo integer;
    define C_TIPOTRX_PANTI, C_TIPOTRX_DIFER, C_TIPOCUO_CAP, C_TIPOCUO_INT,C_TIPOTRX_COB integer;
    define v_contar, v_contvenci, v_cob_codcob, v_cuo_tipotrx, v_cuo_tipoacu, v_tipotrx, v_nrocuota integer;
    define v_pre_codcli,v_isgracia, v_isvcto, is_gracia integer;
	define C_TIPOCOB_PANTI_CAP, C_TIPOCOB_PANTI_INT, C_TIPOTRX_DEVENG, C_TIPOCUO_DEVENG_INT integer;
    define v_rds_codrepro, v_conrepros, v_contregs integer;
    define v_dsb_fecdsb, v_cuo_fecfincuo date;
    define D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY date;
    define v_min_fecvencuo, v_fecini, v_fec31int, v_max_fecvencuo date;
	define v_int_cuota, v_cap_cuota, v_saldo_cap, v_total_int, v_total_cuota, v_mnt_int31dic, v_int_alfechavcto like pre_planpagos.cuo_valor;
	define v_capital_venc, v_interes_venc,v_cap_panti_vcto,v_int_panti_vcto,v_cap_dife_cob like pre_planpagos.cuo_valor;
	define v_max_codtpr, v_cmp_tipo, v_max_pagocta integer;
	define v_cmp_centro, v_pcu_tipocmp integer;
	define v_nrodoc varchar(235);
    define v_cob_t pre_cobros_t;
    define v_tmo_t pre_tramon_t;
    
    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
    LET C_TIPOTRX_DIFER = 4;    
    let C_TIPOTRX_COB = 2;
    LET C_TIPOTRX_PANTI = 3;    
    let v_firstreg = 0; 
	let C_TIPOCUO_DEVENG_INT = 28;
    let C_TIPOTRX_DEVENG = 8;
    LET C_TIPOCOB_PANTI_INT = 22;
    let C_TIPOCOB_PANTI_CAP = 12;
    
    select max(cuo_fecvencuo)
    into v_max_fecvencuo
    from pre_planpagos
    where cuo_codcred = p_tmo_t.tmo_codcred
    and cuo_codmod = p_tmo_t.tmo_codmod
    and cuo_fecvencuo <= p_tmo_t.tmo_fecvencuo
    and cuo_coddsb = nvl(p_tmo_t.tmo_coddsb, cuo_coddsb)
    and cuo_coddsb > 0
    and cuo_valor > 0;
        
    if p_tmo_t.tmo_tipotra is null or p_tmo_t.tmo_tipotra <= 0 then
    	raise exception -746, 0, "Gen oper Venc: parametro tipo de transaccion nulo cred: " || p_tmo_t.tmo_codcred;
    end if
    -- verificacmos reprogramaciones pendientes
    let v_rds_codrepro = f_rpro_ultrepro(p_tmo_t.tmo_codcred, p_tmo_t.tmo_codmod, v_max_fecvencuo + 1);
    
    if nvl(v_rds_codrepro, 0) > 0 then
        select count(*)
        into v_conrepros
        from pre_reprograma
        where rds_codrepro = v_rds_codrepro
        and rds_trxstaau in (1,2)
        and rds_statreg = 0;
        
        if v_conrepros > 0 then
            raise exception -746, 0, "Existen reprogramaciones pendientes a fecha " || v_max_fecvencuo || " elimine o autoririce ";
        end if
    end if
    
    select count(1)
    into v_contregs
    from pre_planpagos
    where cuo_codcred = p_tmo_t.tmo_codcred
    and cuo_codmod = p_tmo_t.tmo_codmod
    and cuo_fecvencuo < p_tmo_t.tmo_fecvencuo
    and cuo_fecvencuo = nvl(cuo_fecfincuo,cuo_fecvencuo)
    and cuo_coddsb = nvl(p_tmo_t.tmo_coddsb, cuo_coddsb)
    and cuo_tipotrx in (2,3)
    and cuo_coddsb > 0
    and cuo_valorpend > 0;

    if v_contregs > 0 then
    	if p_tmo_t.tmo_tipotra = C_TIPOTRX_COB then
			raise exception -746, 0, "COBRO: Existen cuotas pendientes anteriores a fecha " || p_tmo_t.tmo_fecvencuo;
    	elif p_tmo_t.tmo_tipotra = C_TIPOTRX_PANTI then
    		raise exception -746, 0, "P.ANT:Existen cuotas pendientes anteriores a fecha " || p_tmo_t.tmo_fecvencuo;
    	end if
    end if
    
    if p_tmo_t.tmo_tipotra = C_TIPOTRX_PANTI then
	    select count(1)
	    into v_contregs
	    from pre_planpagos
	    where cuo_codcred = p_tmo_t.tmo_codcred
	    and cuo_codmod = p_tmo_t.tmo_codmod
	    and cuo_fecvencuo <= p_tmo_t.tmo_fecvencuo
	    and cuo_fecvencuo = nvl(cuo_fecfincuo,cuo_fecvencuo)
	    and cuo_coddsb = nvl(p_tmo_t.tmo_coddsb, cuo_coddsb)
	    and cuo_coddsb > 0
	    and cuo_valorpend > 0
    	and cuo_tipocuo = C_TIPOCUO_DEVENG_INT;
    
	    if v_contregs > 0 then
			--raise exception -746, 0, "PANTICIP: Existen devengados pendientes a fecha " || p_tmo_t.tmo_fecvencuo;
	    end if    
	elif p_tmo_t.tmo_tipotra = C_TIPOTRX_COB then
	    select count(1)
	    into v_contregs
	    from pre_planpagos
	    where cuo_codcred = p_tmo_t.tmo_codcred
	    and cuo_codmod = p_tmo_t.tmo_codmod
	    and cuo_fecvencuo <= p_tmo_t.tmo_fecvencuo
	    and cuo_fecvencuo = nvl(cuo_fecfincuo,cuo_fecvencuo)
	    and cuo_coddsb = nvl(p_tmo_t.tmo_coddsb, cuo_coddsb)
	    and cuo_coddsb > 0
	    and cuo_valorpend > 0
    	and cuo_tipocuo in (12,22);
    
	    if v_contregs > 0 then
			raise exception -746, 0, "COBRO: Existen pag ant o devengados pendientes a fecha " || p_tmo_t.tmo_fecvencuo;
	    end if	
    end if
	
    let v_tipotrx = p_tmo_t.tmo_tipotra;
    let v_nrocuota = 0;
    
    select pre_codcli 
    into v_pre_codcli
    from  pre_prestamos
    where pre_codcred = p_tmo_t.tmo_codcred
    and pre_codmod = p_tmo_t.tmo_codmod;
    
    let v_sum_amort = 0;
    let v_contregs = 0;
    foreach
        select dsb_coddsb, dsb_valor, dsb_undsb, dsb_saldo, dsb_fecdsb
        into v_dsb_coddsb, v_dsb_valor, v_dsb_undsb, v_dsb_saldo, v_dsb_fecdsb
        from pre_desemb
        where dsb_codmod = p_tmo_t.tmo_codmod
        and dsb_codcred = p_tmo_t.tmo_codcred
        and dsb_coddsb = nvl(p_tmo_t.tmo_coddsb, dsb_coddsb)
        and dsb_valor > 0
        and dsb_undsb > 0
        and exists(select 1
            from pre_planpagos
            where cuo_coddsb = dsb_coddsb
            and cuo_codcred = dsb_codcred
            and cuo_codmod = dsb_codmod
            and cuo_tipocuo > 0
            and cuo_fecvencuo <= v_max_fecvencuo
            and cuo_valorpend > 0
            )
        order by dsb_coddsb
                
                let v_tmo_t = f_tmo_cpy_tramon_t(p_tmo_t);
                
                let v_tmo_t.tmo_valor = v_dsb_valor;
                let v_tmo_t.tmo_importe = v_dsb_valor;
                let v_tmo_t.tmo_coddsb = v_dsb_coddsb;

                if v_tmo_t.tmo_tipotra is null or v_tmo_t.tmo_tipotra <= 0 then
                	raise exception -746,0,"Tipo de transaccion nulo dsb: " || v_cuo_coddsb;
                end if
           		let v_int_cuota = 0;
           		let v_cap_cuota  = 0;
           		let v_saldo_cap = 0;
           		let v_total_cuota = 0;
			
                let v_mnt_amortiza = 0;
                
                foreach
                    select cuo_codcuo, cuo_valor, cuo_valorpend, cuo_fecvencuo, cuo_fecfincuo, cuo_coddsb, cuo_tipocuo, nvl(cuo_tipoacu, cuo_tipocuo), cuo_tipotrx
                    into v_cuo_codcuo, v_cuo_valor, v_cuo_valorpend, v_cuo_fecvencuo, v_cuo_fecfincuo, v_cuo_coddsb, v_cuo_tipocuo, v_cuo_tipoacu, v_cuo_tipotrx
                    from pre_planpagos
                    where cuo_codmod = v_tmo_t.tmo_codmod
                    and cuo_codcred = v_tmo_t.tmo_codcred
                    and cuo_coddsb = v_dsb_coddsb
                    and cuo_tipocuo > 0
                    and cuo_coddsb > 0
                    and cuo_valor > 0
                    and cuo_fecvencuo = v_tmo_t.tmo_fecvencuo
                    order by cuo_fecvencuo, cuo_tipocuo
                    
                    	let v_mnt_amortiza_pp = 0;
                    	
                    	if v_tipotrx in (2,3) then
                    		let v_cuo_tipotrx = nvl(v_cuo_tipotrx, C_TIPOTRX_COB);
                    	end if
                    	if v_tipotrx in (3) then
                    		if v_cuo_tipotrx not in (2,3,8) then
                    			continue foreach;
                    		end if
                    	end if
                        if v_cuo_valorpend > 0 and v_tmo_t.tmo_fecvencuo >= v_cuo_fecvencuo then
                            let v_contregs = v_contregs + 1;     
                            let v_cob_t = f_init_cob_t();
                            let v_cob_t.cob_tipocuo = v_cuo_tipocuo;
							let v_cob_t.cob_codigo = v_cuo_tipoacu;
                            let v_cob_t.cob_coddsb = v_cuo_coddsb;
                            let v_cob_t.cob_numcuo = v_cuo_codcuo;
                            let v_cob_t.cob_valor = 0;
                            let v_cob_t.cob_tipotrx = v_cuo_tipotrx;
							let v_cob_t.cob_fechproc = nvl(v_cuo_fecfincuo, v_cuo_fecvencuo);
                            
                            let v_cob_t = f_genop_recdatos_toper(v_tmo_t, v_cob_t);
                            let v_cob_t.cob_feccontab = v_cuo_fecvencuo;
                            
							if (v_cob_t.cob_codigo is null) then
								continue foreach;
                            	--raise exception -746,0,"Tipo de cobro nulo codcuo: " || v_cuo_codcuo || " tipo trans: " || v_cob_t.cob_tipocuo || "-" || v_tmo_t.tmo_tipotra;
                            end if                                   
                        	let v_cob_t.cob_valor = v_cuo_valorpend;
                            let v_sum_amort = v_sum_amort + 1;
                            
                            if v_cob_t.cob_valor > 0 then
                                if v_tmo_t.tmo_numtrx is null or v_tmo_t.tmo_numtrx = 0 then
                                    let v_tmo_t = f_genop_crear_tramon(v_tmo_t); 
                                end if
                                                                
                                if nvl(v_tmo_t.tmo_numtrx, 0) > 0 then
                                    let v_cob_codcob = f_genop_crear_cobro(v_tmo_t, v_cob_t);
                                end if
                            end if
                        end if
                end foreach;
                
                if nvl(v_tmo_t.tmo_numtrx, 0) > 0 then
                    call p_upd_tramon_amt_importe(v_tmo_t.tmo_codcred, v_tmo_t.tmo_codmod, v_tmo_t.tmo_numtrx);
                end if
    end foreach;
    
   	call p_updsumtrans(p_tmo_t.tmo_codmod, p_tmo_t.tmo_codcred, null, null, null, null, null);
                
    if v_sum_amort = 0 then
        --raise exception -746,0,"La operacion no produjo ningun registro Cred: " || p_tmo_t.tmo_codcred || " " || v_contregs;
    end if

	call p_upd_status_pre(p_tmo_t.tmo_codcred, p_tmo_t.tmo_codmod, null, p_tmo_t.tmo_fecvencuo, null, 
		p_tmo_t.tmo_tipotra, "PAGO", p_tmo_t.tmo_auditusr, p_tmo_t.tmo_auditwst);    

end procedure;


