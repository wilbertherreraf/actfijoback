


DROP procedure IF EXISTS d_creditos.p_get_datos_devengamiento_proceso;
create procedure d_creditos.p_get_datos_devengamiento_proceso(p_codprc integer) RETURNING INTEGER AS nro_desembolsos, integer as  nro_dias, DECIMAL(16,2) AS interes_devengado, DECIMAL(16,2) as desembolsado, DECIMAL(16,2) as saldocapital;

{
         -- DESCRIPCI: Obtiene los datos del devengamineto de un credito a partie de un proceso iniciado de la tablas correspondientes
         -- PARAMETROS INGRESO: p_codprc INTEGER                       Codigo de proceso
         -- PARAMETROS SALIDA: nro_desembolsos INTEGER                 Nro de desembolsos
         --                    nro_dias INTEGER                        Nro de         --                    interes_devengado DECIMAL(16,2)         Monto Interes devengado
         --                    desembolsado DECIMAL(16,2)              Monto Desembolsado
         --                    saldocapital DECIMAL(16,2)              Saldo Capital
         -- AUTOR: HENRY IVAN PANIQUE MIRANDA
         -- DEPENDENCIAS: CREDITOS (pre_prcconta, pre_tasaspre, pre_prestamos, pre_accrual, pre_desemb, pre_planpagos)
         -- CREACI:  30-11-2023
         -- SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  23-01-2025   | 2320476  | Ajuste en la consulta que obtiene los datos del devengamiento, columna 'interes_devengado'. Se agrego una condicion que verifica si existe desembolso el mismo mes del devengado.
---------------------------------------------------------------------------
--| wherrera|  05-05-2026   | 2320476  | sin uso p_get_datos_devengamiento retorna la misma informacion
----------------------------------------------------------------------------

}
	raise exception -746,0,"Proceso No implementado";
    RETURN 0, 0, 0, 0, 0;

END PROCEDURE;


