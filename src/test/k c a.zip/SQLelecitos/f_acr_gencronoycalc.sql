

		
DROP function IF EXISTS d_creditos.f_acr_gencronoycalc;

CREATE function d_creditos.f_acr_gencronoycalc(p_codmod integer, p_codcred integer, p_tipoproceso integer, p_fechaini date, p_fechafin date)
returning date
{
    calcula los devengados a una fecha desde la ultima de cierre
    p_fechaini determina la ult fecha devengada o anterior a la fecha de inicio del calendario
	wherrera 20260405 se modifica el calculo adicionando montos de pagos anticipadosen el calculo y periodos de devengados
	p_tipoproceso: tipo de proceso
		1: automatico diario
		2: por el usuario desde la interfaz
		3: procesos de consulta a fecha fin
		5: reproceso (proceso controlado realizado para reprocesos por el administrador)
}

    define v_fec_ult_conta,v_fec_ultact_pre, v_fechaini,v_fechafin, V_D_FECFINPER, V_D_FECINIPER, v_fecini_mes, v_fec_ini_intcorr, v_ultfec_pp_int date;
    define v_fec_procesado,v_fec_procesadodsb, v_pre_feculttrx,v_fec_ult_proc, v_fecini_periodo,v_day_prev, v_cuo_fecvencuo,v_fec_31MAntvencuo date;
    DEFINE C_UNIDPLAZ_DIAS, C_BASE_FISCAL, C_BASE_EXACTO INTEGER;
    DEFINE ST_D_PERIOD,END_D_PERIOD, v_LAST_D_M  DATE;
    DEFINE P_SEQ_PERIOD_a, P_SEQ_PERIOD INTEGER;
    define v_acr_codacr, v_acr_diasaccr,v_acr_diasaccrdsb integer;
    define C_UNIDPLAZ_ANUAL, v_cont_acr integer;
    define C_TIPOCOB_PANTI_CAP, C_BASEPERIDO_FISCAL, C_TIPOCUO_INT, C_TIPOCUO_CAP,C_TIPOCOB_DIFER_INT integer;
    define v_dsb_coddsb, v_cuo_coddsb , v_first integer;
    DEFINE C_UNIDPLAZ_MENSUAL, C_UNIDPLAZ_DIARIO, C_INIT_FECHAINI_FINIST, C_TIPOACR_DSB, C_TIPOACR_CLI, C_TIPOACR_PRE, C_TIPOACR_DETA, v_tipocalen INTEGER;
    define v_pre_codcli, v_acr_tipocuo integer;
    define v_acr_saldo,v_acr_saldoeffect, v_int_1dia,v_int_1diaeffect, v_capital_venc, v_interes_venc, v_cap_vencpend, v_int_vencpend, v_panti_cap_ant, v_int_netoant,v_int_netoantpend,v_cap_panti_vcto like pre_accrual.acr_valor;
    define v_cap_rec, v_cap_rec_ant, v_int_rec, v_int_rec_effect,v_cap_rec_effect, v_int_periodo,v_dev_int_ultact, v_diff,v_int_pa_rec,v_acr_interesper  like pre_accrual.acr_valor;
    define V_MNT_PRGPENDcap_FECHA, v_panti_intant,v_panti_intantpend,v_int_panti_vcto,v_interesper,v_acr_capitalper,v_cap_dife_cob,v_int_avcto  like pre_accrual.acr_valor;
    define v_cap_amort, v_cap_rec_antpend, v_int_dife_vencpend, v_int_dife_venc,v_panti_cap_antpend like pre_accrual.acr_valor;
    define v_int_periodoeffect like pre_accrual.acr_valor; 
    define v_min_fecvencuo, v_max_fecvencuo, v_dsb_fecdsb, v_fecsigvcto, v_feciniper,v_ST_D_M, v_END_D_M, v_fecdev, v_fecult_act date;
    define v_dsb_fecplzven, v_fec_31perant,v_sgte_devcont,v_sgte_dev_aprob date;
    define v_acr_tasavig float;
    define v_dsb_codmod, v_dsb_codcred,C_TIPOCOB_PANTI_INT,P_INTYDAYS,v_contar_regs  integer;
    define v_int_31perant, v_int_devmes, v_int_devmeseffect, v_difer_a_cobrar_int, v_dsb_valor, v_acr_undsb,v_cap_dife_venc,v_cap_dife_vencpend,v_cap_dife_cobpend  like pre_accrual.acr_valor;
    define C_ONE_DAY, v_diff_days, v_statacru,v_nro_desemb,v_cont_tipoacr integer;
    define C_TASAPERIODO, C_FECEVAL_FECVENCUO, C_FECEVAL_FECPROC, C_STATACRU_PEND, C_STATACRU_APROB, C_STATACRU_PROC integer;
    define v_TRAINTYDAYS, P_TRAINTYDAYS, P_TRAINTMDAYS,v_methodcapi, v_unidplaz,v_con_pa,v_con_difer integer;
     
    let C_TASAPERIODO = 0;
    LET C_UNIDPLAZ_DIAS = 7;
    LET C_BASE_EXACTO = 3;
    LET C_BASE_FISCAL = 2;
    let C_TIPOCUO_INT = 2;
    let C_TIPOCUO_CAP = 1;
    let C_STATACRU_PEND = 1;
    LET C_UNIDPLAZ_ANUAL = 3;
    LET C_UNIDPLAZ_DIARIO = 7;
    let C_UNIDPLAZ_MENSUAL = 6;
    LET C_BASEPERIDO_FISCAL = 2;
    LET C_TIPOACR_DETA = 1;
    let C_TIPOACR_DSB = 3;
    LET C_TIPOACR_CLI = 5;
    LET C_TIPOACR_PRE = 2;    
    LET C_TIPOCOB_PANTI_INT = 22;
    let C_TIPOCOB_PANTI_CAP = 12;
   	LET C_TIPOCOB_DIFER_INT = 24;
    let v_first = 0;
    LET C_INIT_FECHAINI_FINIST = 1;
    let C_FECEVAL_FECVENCUO = 1; 
    let C_FECEVAL_FECPROC = 2;
    let C_ONE_DAY = 1;
    let C_STATACRU_PEND = 1;
    let C_STATACRU_PROC = 2;
    let C_STATACRU_APROB = 3;
	let v_min_fecvencuo = null;
    let v_fec_ini_intcorr = null;
    let v_statacru = null;
    
    if p_fechafin is null then
    	raise exception -746,0,"Parametro fecha fin de devengamiento requerido";
    end if
    
	if p_tipoproceso is null then
		raise exception -746,0,"Parametro Tipoproceso requerido";
	end if
 
	select pre_codcli, nvl(pre_feculttrx,pre_fecemi) 
	into v_pre_codcli, v_pre_feculttrx
	from pre_prestamos
	where pre_codcred = p_codcred
	and pre_codmod = p_codmod;

	if dbinfo("sqlca.sqlerrd2") = 0 then   
       --Raise Exception  -746, 0, "Credito inexistente " || p_codcred || " - " || p_codmod;
		return null;
    end if       
	
    select count(1)
    into v_nro_desemb
	from pre_desemb
    where dsb_codmod = p_codmod
    and dsb_codcred = p_codcred
    and dsb_fecdsb <= p_fechafin
    and dsb_valor > 0
    and dsb_undsb > 0;
    
    if v_nro_desemb = 0 then
    	return null;
    end if
    
    call f_pp_minmax_plan(p_codcred, p_codmod, null, null) returning v_min_fecvencuo, v_max_fecvencuo;

    if v_min_fecvencuo is null then
    	return p_fechafin;
    end if
    
	if p_tipoproceso = 1 then
	-- automatico diario
		select max(fecha_devengado) 
		into v_min_fecvencuo
		from pre_registro_devengado_creditos
		where fecha_devengado < p_fechafin
		and codcred = p_codcred
		and codmod = p_codmod
		and fecha_devengado >= (p_fechafin-2);
	
		let v_fechaini = nvl(v_min_fecvencuo, p_fechafin-2);
		let v_fechafin = p_fechafin;
		
	elif p_tipoproceso = 2 then
	-- por el usuario recalcula si esta dentro el periodo
		let v_fechaini = p_fechaini;
		let v_fechafin = p_fechafin;
	
		if v_fechaini = v_fechafin then
			let v_fechaini = v_fechaini-1; 
		end if
		
	elif p_tipoproceso = 3 then
	-- consulta a dia especifico por prestamo
		let v_fechaini = nvl(p_fechaini,p_fechafin);
		let v_fechafin = p_fechafin;
	
		if v_fechaini = v_fechafin then
			let v_fechaini = v_fechaini-1; 
		end if
		
		
	elif p_tipoproceso = 5 then
	-- reprocesos
	    if p_fechaini is null then
	    	raise exception -746,0,"Reproceso devengado: Parametro fecha innicio de devengamiento requerido";
	    end if	
		let v_fechaini = p_fechaini;
		let v_fechafin = p_fechafin;
	
		update pre_accrual
		set acr_statacru = C_STATACRU_PEND 
		where acr_fecaccru between v_fechaini and v_fechafin
		and acr_codcred = p_codcred
		and acr_codmod = p_codmod
		and acr_coddsb > 0
		and acr_tipoacr in (2,3);	
	else 
	-- reprocesos
    	raise exception -746,0,"Reproceso devengado: tipo proceso no definido";
	end if

	if v_fechafin < v_fechaini then
		return v_fechafin;
	end if
	
	call f_GET_TRA_INT_YR_MTH_BASE(p_codmod, p_codcred) returning P_TRAINTYDAYS, P_TRAINTMDAYS;

	call f_dsb_getmethod_plz(p_codcred, p_codmod, null) returning v_methodcapi, v_unidplaz;
    
    let v_con_pa = 0;
    let v_contar_regs = 0;
    let v_con_difer = 0;    
    -- si tiene pa
    select count(1)
    into v_con_pa
    from pre_planpagos
    where cuo_tipocuo = C_TIPOCOB_PANTI_INT
    and cuo_codcred = p_codcred
    and cuo_codmod = p_codmod
    and cuo_coddsb > 0
    and cuo_fecvencuo <= v_fechafin
	and cuo_valor > 0;
    
    select count(1)
    into v_con_difer
    from pre_planpagos
    where cuo_tipoacu in (C_TIPOCOB_DIFER_INT,14)
    and cuo_tipotrx = 4
    and cuo_codcred = p_codcred
    and cuo_codmod = p_codmod
    and cuo_coddsb > 0
    and cuo_fecvencuo <= v_fechafin
    and cuo_valor > 0;

	let v_fec_ult_proc = f_acr_ult_fec_acr(p_codcred, p_codmod, null, v_fechafin, 3);

    foreach
        execute procedure f_getperiodos(v_fechaini, v_fechafin, C_UNIDPLAZ_DIARIO, C_BASEPERIDO_FISCAL, 0, C_INIT_FECHAINI_FINIST) 
            into P_SEQ_PERIOD,ST_D_PERIOD, END_D_PERIOD
		
	    select count(1)
	    into v_nro_desemb
		from pre_desemb
	    where dsb_codmod = p_codmod
	    and dsb_codcred = p_codcred
		and dsb_feculttrx <= END_D_PERIOD
	    and dsb_monpag = 5; -- modificado
	    
		let v_cont_tipoacr = 0;
		let v_cont_acr = 0;
		let v_statacru = 0;
		let v_fec_31MAntvencuo = mdy(month(END_D_PERIOD),1,year(END_D_PERIOD)) - 1;
		let v_fec_31perant = mdy(1,1,year(END_D_PERIOD)) - 1;

		let v_fec_ultact_pre = f_acr_ult_fec_acr(p_codcred, p_codmod, null, END_D_PERIOD-1, 5);
		let v_fec_ult_conta = f_acr_ult_fec_acr(p_codcred, p_codmod, NULL, END_D_PERIOD, 1);
		
		if v_fec_ultact_pre is null then
			continue foreach;
		end if
		
		let v_fec_procesado = null;
		
		select max(acr_fecaccru)
		into v_fec_procesado
		from pre_accrual
		where acr_codmod = p_codmod
		and acr_codcred = p_codcred 
		and acr_fecaccru < END_D_PERIOD
		and acr_fecaccru >= v_fec_ultact_pre
		and acr_fecproc < acr_fecaccru
		and acr_fecaccru > acr_fecini
		and acr_fecaccru <= acr_fecfin
		and acr_fecproc between acr_fecini and acr_fecfin
		and acr_fecproc < acr_fecfin
		and acr_tipoacr = 3
		and acr_fecproc >= v_fec_31perant
		and acr_statacru in (C_STATACRU_PROC, C_STATACRU_APROB);
		
		select count(distinct acr_tipoacr), count(distinct acr_statacru),min(acr_statacru)
		into v_cont_tipoacr, v_cont_acr,v_statacru
		from pre_accrual
		where acr_codmod = p_codmod
		and acr_codcred = p_codcred 
		and acr_fecproc < acr_fecaccru
		and acr_fecaccru > acr_fecini
		and acr_fecaccru <= acr_fecfin
		and acr_fecproc between acr_fecini and acr_fecfin
		and acr_fecproc < acr_fecfin	
		and acr_fecproc >= v_fec_procesado
		and acr_fecaccru = END_D_PERIOD;
        
		let v_statacru = nvl(v_statacru, C_STATACRU_PEND);
		if v_cont_tipoacr = 2 and v_cont_acr = 1 and v_nro_desemb = 0 and v_fec_procesado is not null then
			if v_statacru = C_STATACRU_APROB then
				-- registro aprobado
				continue foreach;
			end if
			if v_statacru = C_STATACRU_PROC and p_tipoproceso = 3 then
			-- registro procesado pero no se recalcula
				continue foreach;
			end if			
		end if
		
		select ST_D_M, END_D_M
		INTO v_ST_D_M, v_END_D_M
		from table(f_getperiodos(END_D_PERIOD, END_D_PERIOD, C_UNIDPLAZ_MENSUAL, 2, 0, 1)) per(SEQ_PERIOD,ST_D_M, END_D_M)
		WHERE SEQ_PERIOD = 1;
		
		let v_ST_D_M = mdy(month(v_END_D_M), 1,year(v_END_D_M));
		
		let v_acr_tasavig = f_gettasavigenteprest(p_codcred, p_codmod, END_D_PERIOD);
		let v_sgte_devcont = null;
		
		select min(prc_fecha_2) 
		into v_sgte_devcont
		from pre_prcconta 
		where prc_codcred = p_codcred 
		and prc_codmod = p_codmod
		AND prc_fecha_2 > END_D_PERIOD
		and length(trim(nvl(prc_nro_comprob, ""))) > 2
		and prc_nro_centro > 0	
		and prc_estado in (1,2,3);

		let v_sgte_dev_aprob = v_sgte_devcont;

		select min(prc_fecha_2) 
		into v_sgte_devcont
		from pre_prcconta 
		where prc_codcred = p_codcred 
		and prc_codmod = p_codmod
		AND prc_fecha_2 > END_D_PERIOD-1
		and length(trim(nvl(prc_nro_comprob, ""))) > 2
		and prc_nro_centro > 0	
		and prc_estado in (1,2,3);
		
		let v_sgte_dev_aprob = nvl(v_sgte_dev_aprob, v_sgte_devcont);
		let v_sgte_devcont = nvl(v_sgte_devcont,v_END_D_M);
		if v_sgte_devcont > v_END_D_M then
			let v_sgte_devcont = v_END_D_M;
		end if
		
		
		
        foreach 
            select dsb_codmod, dsb_codcred, dsb_coddsb, dsb_fecdsb, dsb_valor,dsb_fecplzven,
            (select MAX(cuo_fecvencuo)  
            	from pre_planpagos 
            	where cuo_coddsb = dsb_coddsb 
            	and cuo_codcred = dsb_codcred
            	and cuo_codmod = dsb_codmod 
            	and cuo_fecvencuo <= END_D_PERIOD)
            into v_dsb_codmod, v_dsb_codcred, v_dsb_coddsb, v_dsb_fecdsb, v_dsb_valor,v_dsb_fecplzven,
            v_fecult_act
            from pre_desemb
            where dsb_codmod = p_codmod
            and dsb_codcred = p_codcred
            and dsb_fecdsb < END_D_PERIOD 
            and dsb_valor > 0
            and dsb_undsb > 0
            order by dsb_fecdsb, dsb_coddsb
    
            if END_D_PERIOD between v_dsb_fecdsb and v_max_fecvencuo and v_dsb_fecdsb < END_D_PERIOD then
        		let v_interes_venc = 0;
                let v_capital_venc = 0;
                let v_interesper = 0;
                let v_acr_capitalper = 0;
                let v_cap_dife_venc = 0;
                let v_cap_dife_cob = 0;
            	let v_cap_panti_vcto = 0;
            	let v_int_panti_vcto = 0;
            	let v_panti_intant = 0;
            	let v_panti_intantpend = 0;
				let v_int_netoant = 0;
            	let v_int_netoantpend = 0;
            	let v_cap_vencpend = 0;
            	let v_int_vencpend = 0;
            	let v_acr_interesper = 0;
            	let v_int_dife_venc = 0;
            	let v_int_dife_vencpend = 0;
				let v_acr_tipocuo = null;
				let v_acr_codacr = null;
            	let v_fecdev = null;
            	let v_int_rec_effect = 0;
                let v_cuo_fecvencuo = END_D_PERIOD;
                let v_day_prev = v_cuo_fecvencuo - 1;
               	let v_fecini_periodo = v_ST_D_M - 1;
    			            
              	let v_fecsigvcto = f_pp_fec_sigper(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, v_cuo_fecvencuo-1, C_TIPOCUO_INT);

              	-- ult fecha de registro en pp de interes
				let v_ultfec_pp_int = f_acr_ult_fec_acr(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, v_cuo_fecvencuo-1, 2);              	
                let v_feciniper = f_pp_fechainiper(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, v_cuo_fecvencuo, C_TIPOCUO_INT);
              	
				-- dev mensual determinamos si pertenece al periodo
				if (v_fec_ultact_pre between v_fec_31MAntvencuo and v_END_D_M) and v_fec_ultact_pre < v_cuo_fecvencuo then
					let V_D_FECINIPER = v_fec_ultact_pre;
                elif (v_cuo_fecvencuo between v_fec_31MAntvencuo and v_END_D_M) and v_fec_ultact_pre < v_fec_31MAntvencuo then
                	let V_D_FECINIPER = v_fec_31MAntvencuo;
                else
                	let V_D_FECINIPER = v_fec_31MAntvencuo;
				end if
				
				let V_D_FECFINPER = v_sgte_devcont;
				
				if v_sgte_devcont > v_fecsigvcto then
					let V_D_FECFINPER = v_fecsigvcto;
				
					select min(fecha_vencimiento)
					INTO v_fecdev
					from pre_pagocuota
					where codcred = v_dsb_codcred
					and codmod = v_dsb_codmod
					and coddsb = v_dsb_coddsb
					and fecha_vencimiento > v_cuo_fecvencuo
					and length(trim(nvl(nro_comprobante_coin, ""))) > 2
					and estado in (1,2,3);
					
					if v_fecdev is not null and v_sgte_dev_aprob < v_fecdev then
						let v_sgte_dev_aprob = v_fecdev;
					end if
					
					let v_fecdev = nvl(v_fecdev, v_fecsigvcto);
					if v_fecdev < v_fecsigvcto then
						let V_D_FECFINPER = v_fecdev;
					end if
				end if				
				
            	call f_pp_sum_portipo(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, null, v_cuo_fecvencuo-1, C_TIPOCUO_CAP) 
                        returning v_cap_rec_ant, v_cap_rec_antpend;
            	
            	call f_pp_sum_portipo(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, null, v_cuo_fecvencuo-1 , C_TIPOCUO_INT) 
                        returning v_int_netoant, v_int_netoantpend;
            	
            	let v_panti_cap_antpend = 0;
            	let v_panti_cap_ant = 0;
            	if v_con_pa > 0 then
	              	call f_pp_sum_portipo(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, null, v_cuo_fecvencuo-1, C_TIPOCOB_PANTI_CAP) 
	                        returning v_panti_cap_ant, v_panti_cap_antpend;
	
	                call f_pp_sum_portipo(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, null, v_cuo_fecvencuo-1, C_TIPOCOB_PANTI_INT) 
	                        returning v_panti_intant, v_panti_intantpend;
				end if
				
            	if v_con_difer > 0 then
					call f_pp_sum_importetrx(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, null, v_cuo_fecvencuo-1, 2, 4, 4) 
	                    	returning v_int_dife_venc, v_int_dife_vencpend;
            	
                    call f_pp_sum_importetrx(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, v_cuo_fecvencuo, v_cuo_fecvencuo, 1, 4, 4) 
                    	returning v_cap_dife_venc, v_cap_dife_vencpend;
                    call f_pp_sum_importetrx(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, v_cuo_fecvencuo, v_cuo_fecvencuo, 1, 2, 4)
                    	returning v_cap_dife_cob, v_cap_dife_cobpend;
            	end if
            	
            	if v_fecult_act = v_cuo_fecvencuo then
					select nvl(sum(capital),0), nvl(sum(interes),0), nvl(sum(panti_cap),0), nvl(sum(panti_int),0),
					nvl(sum(capital_pend),0), nvl(sum(interes_pend),0)
					into v_capital_venc, v_interes_venc, v_cap_panti_vcto, v_int_panti_vcto,
					v_cap_vencpend,v_int_vencpend
					from (
		                select sum(cuo_valor) capital, 0 interes,0 panti_cap, 0 panti_int,
		                sum(cuo_valorpend) capital_pend, 0 interes_pend
		                from pre_planpagos
		                where cuo_tipocuo = C_TIPOCUO_CAP
		                and cuo_codcred = v_dsb_codcred
		                and cuo_codmod = v_dsb_codmod
		                and cuo_fecvencuo = v_cuo_fecvencuo
		                and cuo_coddsb = v_dsb_coddsb
					
		                union all 
	
		                select 0 , sum(cuo_valor), 0, 0,
		                0, sum(cuo_valorpend)
		                from pre_planpagos 
		                where cuo_tipocuo = C_TIPOCUO_INT
		                and cuo_codcred = v_dsb_codcred
		                and cuo_codmod = v_dsb_codmod
		                and cuo_fecvencuo = v_cuo_fecvencuo
		                and cuo_coddsb = v_dsb_coddsb
		                
		                union all
		                
		                select 0, 0 , sum(cuo_valor), 0,
		                sum(cuo_valorpend),0
		                from pre_planpagos
		                where cuo_tipocuo = C_TIPOCOB_PANTI_CAP
		                and cuo_codcred = v_dsb_codcred
		                and cuo_codmod = v_dsb_codmod
		                and cuo_fecvencuo = v_cuo_fecvencuo
		                and cuo_coddsb = v_dsb_coddsb
					
		                union all 
	
		                select 0 , 0, 0, sum(cuo_valor),
		                0,sum(cuo_valorpend)
		                from pre_planpagos 
		                where cuo_tipocuo = C_TIPOCOB_PANTI_INT
		                and cuo_codcred = v_dsb_codcred
		                and cuo_codmod = v_dsb_codmod
		                and cuo_fecvencuo = v_cuo_fecvencuo
		                and cuo_coddsb = v_dsb_coddsb	                
					);
		              
            	end if
            	
				let v_cap_rec = v_cap_rec_ant + v_panti_cap_ant;
            	let v_cap_rec_effect = f_getamtcobroscap(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, null, v_cuo_fecvencuo-1, C_TIPOCUO_CAP);
	           	-- monto capital a fec vcto
				let v_acr_capitalper = v_capital_venc + v_cap_panti_vcto;            	
				-- capital amortizado				
				let v_cap_amort = (v_cap_rec - (v_cap_rec_antpend + v_panti_cap_antpend)) + (v_acr_capitalper - v_cap_vencpend);            	            	
				let v_int_rec = v_int_netoant + v_panti_intant;
				let v_int_rec_effect = f_getamtcobroscap(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, null, v_cuo_fecvencuo-1, C_TIPOCUO_INT);
				let v_acr_interesper = v_interes_venc + v_int_panti_vcto;
				let v_int_31perant = 0;
				
				if v_feciniper < v_fec_31perant then
					-- fecha de inicio periodo para int corriente
					let v_fec_ini_intcorr = v_fec_31perant;
					let v_acr_saldo =  f_acr_saldo_fecha(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, v_fec_ini_intcorr, 1);
					let v_int_31perant = f_getinteres_pry(v_dsb_codcred, v_dsb_codmod, null, v_acr_saldo, v_feciniper, v_fec_ini_intcorr);
				else
					let v_fec_ini_intcorr = v_feciniper; 
				end if
				
				let v_acr_undsb = 0;
				if v_feciniper < v_ultfec_pp_int then
					let v_acr_saldo =  f_acr_saldo_fecha(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, v_ultfec_pp_int, 1);
					let v_acr_undsb = f_getinteres_pry(v_dsb_codcred, v_dsb_codmod, null, v_acr_saldo, v_feciniper, v_ultfec_pp_int);				
				end if
				
				let v_acr_saldo =  f_acr_saldo_fecha(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, v_cuo_fecvencuo, 1);
				let v_acr_saldoeffect = v_dsb_valor - v_cap_rec_effect;
                let v_int_1dia = f_getinteres_pry(v_dsb_codcred, v_dsb_codmod, null, v_acr_saldo, v_day_prev, v_cuo_fecvencuo);
				let v_int_1diaeffect = f_getinteres_pry(v_dsb_codcred, v_dsb_codmod, null, v_acr_saldoeffect, v_day_prev, v_cuo_fecvencuo);
             	let v_dev_int_ultact = f_getinteres_pry(v_dsb_codcred, v_dsb_codmod, null, v_acr_saldo, v_ultfec_pp_int, v_cuo_fecvencuo);
                let v_int_avcto = f_getinteres_pry(v_dsb_codcred, v_dsb_codmod, null, v_acr_saldo, v_fec_ini_intcorr, v_cuo_fecvencuo-1);
				let v_int_devmes = f_getinteres_pry(v_dsb_codcred, v_dsb_codmod, null, v_acr_saldo, V_D_FECINIPER, v_cuo_fecvencuo-1);
             	let v_int_devmeseffect = f_getinteres_pry(v_dsb_codcred, v_dsb_codmod, null, v_acr_saldoeffect, V_D_FECINIPER, v_cuo_fecvencuo-1);
                
                let v_int_periodo = v_acr_undsb + v_dev_int_ultact;
                
                if v_interes_venc > 0 then
                -- ajuste con el interes del pp
                    let v_diff = v_interes_venc - v_int_periodo;
                    if abs(v_diff) < 2 then
                    	let v_int_1dia = v_int_1dia + v_diff;
                    end if
                end if
                
				let v_int_devmes = v_int_devmes + v_int_1dia;
 				let v_int_devmeseffect = v_int_devmeseffect + v_int_1diaeffect; 				
                let v_int_avcto = v_int_avcto + v_int_1dia;

				if v_fec_ult_conta is not null and v_fec_ult_conta = v_cuo_fecvencuo then
					
				end if
				
				select max(acr_fecaccru)
				into v_fec_procesado
				from pre_accrual
				where acr_codmod = p_codmod
				and acr_codcred = p_codcred 
				and acr_fecaccru < v_cuo_fecvencuo
				and acr_fecproc < acr_fecaccru
				and acr_fecaccru > acr_fecini
				and acr_fecaccru <= acr_fecfin
				and acr_fecproc between acr_fecini and acr_fecfin
				and acr_fecproc < acr_fecfin
				and acr_tipoacr = C_TIPOACR_DETA
				and acr_fecproc >= v_feciniper
				and acr_statacru in (C_STATACRU_PROC, C_STATACRU_APROB);
				
				select max(acr_fecaccru)
				into v_fec_procesadodsb
				from pre_accrual
				where acr_codmod = p_codmod
				and acr_codcred = p_codcred 
				and acr_fecaccru < v_cuo_fecvencuo
				and acr_fecproc < acr_fecaccru
				and acr_fecaccru > acr_fecini
				and acr_fecaccru <= acr_fecfin
				and acr_fecproc between acr_fecini and acr_fecfin
				and acr_fecproc < acr_fecfin
				and acr_tipoacr = C_TIPOACR_DSB
				and acr_fecproc >= V_D_FECINIPER
				and acr_statacru in (C_STATACRU_PROC, C_STATACRU_APROB);
				
				call f_days_between_2_dates(v_feciniper, v_cuo_fecvencuo,P_TRAINTYDAYS,P_TRAINTMDAYS) returning v_acr_diasaccr, P_INTYDAYS;
                call f_days_between_2_dates(V_D_FECINIPER,v_cuo_fecvencuo,P_TRAINTYDAYS,P_TRAINTMDAYS) returning v_acr_diasaccrdsb, P_INTYDAYS;				
              	if v_fec_procesado is null then
              		if v_int_periodo > 0 and v_acr_saldo > 0 then
              			let v_fec_procesado = v_feciniper;
              		end if
              	end if
              	
				if v_fec_procesadodsb is null then
              		if v_int_devmes > 0 and v_acr_saldo > 0 then
              			let v_fec_procesadodsb = V_D_FECINIPER;
              		end if
              	end if
              	
            	let v_sgte_dev_aprob = nvl(v_sgte_dev_aprob, v_fec_procesadodsb);
				let v_statacru = C_STATACRU_PEND;
				-- fecha de proceso aprob mayor a fecha acr
				if date(current) >= v_cuo_fecvencuo then
	            	if (v_int_devmes > 0 and v_acr_saldo > 0 ) then
						let v_statacru = C_STATACRU_PROC;
	            	end IF
				
					if (v_sgte_dev_aprob >= v_cuo_fecvencuo and v_acr_saldo > 0) 
						or (v_acr_saldo > 0 ) then 
						let v_statacru = C_STATACRU_APROB;
					end if

					if v_max_fecvencuo <= v_fec_31perant then
						let v_statacru = C_STATACRU_APROB;
					end if
				end if
				
				select count(1), max(acr_codacr)
				into v_cont_acr, v_acr_codacr
				from pre_accrual
				where acr_codmod = v_dsb_codmod
				and acr_codcred = v_dsb_codcred 
				and acr_fecaccru = v_cuo_fecvencuo
				and acr_coddsb = v_dsb_coddsb
				and acr_tipoacr = C_TIPOACR_DETA;
				
				if v_cont_acr != 1 then
					delete from pre_accrual
					where acr_codmod = v_dsb_codmod
					and acr_codcred = v_dsb_codcred 
					and acr_fecaccru = v_cuo_fecvencuo
					and acr_coddsb = v_dsb_coddsb;
				
					let v_acr_codacr = null;
				end if
				
				if v_acr_codacr is null then
					let v_acr_codacr = f_acr_getnextid();
					
                    insert into pre_accrual (acr_codacr,acr_codmod,acr_codcred, acr_coddsb, acr_fecini, acr_fecfin, acr_fecaccru, 
                    acr_diasaccr, acr_saldo, acr_interes, acr_capital, acr_tasavig, acr_tipoacr, 
                    acr_valor, acr_valorpend, acr_codcli, acr_fecproc,acr_interesper,acr_capitalper,acr_undsb,
                    acr_auditfho, acr_statacru,acr_tipocuo,acr_capitalrec,acr_interesrec)
                    values(v_acr_codacr,v_dsb_codmod,v_dsb_codcred, v_dsb_coddsb, v_feciniper, v_fecsigvcto,v_cuo_fecvencuo, 
                    v_acr_diasaccr, v_acr_saldo,v_int_1dia,v_cap_rec,v_acr_tasavig, C_TIPOACR_DETA, 
                    v_int_devmes, v_int_rec, v_pre_codcli, v_fec_procesado,v_acr_interesper,v_acr_capitalper,v_int_31perant,
                    current, v_statacru,v_acr_tipocuo,v_cap_amort,v_int_rec_effect);
                else
                
                	update pre_accrual 
                	set acr_fecini = v_feciniper, 
                	acr_fecfin = v_fecsigvcto,
                    acr_diasaccr = v_acr_diasaccr, 
                    acr_saldo = v_acr_saldo,-- saldo k prog
                    acr_interes = v_int_1dia, -- i 1 d del saldo prog
                    acr_capital = v_cap_rec, -- sum k rec prog
                    acr_tasavig = v_acr_tasavig, 
                    acr_valor = v_int_devmes, -- i periodo prog
                    acr_valorpend = v_int_rec, -- i periodo prog 
                    acr_codcli = v_pre_codcli, 
                    acr_fecproc = v_fec_procesado,
                    acr_interesper = v_acr_interesper, -- i periodo del saldo effect
                    acr_capitalper = v_acr_capitalper,	-- saldo k periodo effect                    
                    acr_undsb = v_int_31perant, -- i al 31dicant saldo prog
                    acr_statacru = v_statacru, -- stat accru
                    acr_tipocuo = v_acr_tipocuo, 
                    acr_capitalrec = v_cap_amort,  
                    acr_interesrec = v_int_rec_effect,
                    acr_auditfho = current
                    where acr_codacr = v_acr_codacr;
                    
                end if
                
				let v_acr_codacr = null;
				
				select count(1), max(acr_codacr)
				into v_cont_acr, v_acr_codacr
				from pre_accrual
				where acr_codmod = v_dsb_codmod
				and acr_codcred = v_dsb_codcred 
				and acr_fecaccru = v_cuo_fecvencuo
				and acr_coddsb = v_dsb_coddsb
				and acr_tipoacr = C_TIPOACR_DSB;
				
				if v_cont_acr != 1 then
					delete from pre_accrual
					where acr_codmod = v_dsb_codmod
					and acr_codcred = v_dsb_codcred 
					and acr_fecaccru = v_cuo_fecvencuo
					and acr_coddsb = v_dsb_coddsb
					and acr_tipoacr = C_TIPOACR_DSB;
				
					let v_acr_codacr = null;
				end if

				if v_acr_codacr is null then
					let v_acr_codacr = f_acr_getnextid();
					
                    insert into pre_accrual (acr_codacr,acr_codmod,acr_codcred, acr_fecini, acr_fecfin, acr_fecaccru, acr_coddsb,
                    acr_diasaccr, acr_saldo, acr_interes, acr_capital, acr_tasavig, acr_tipoacr, 
                    acr_valor, acr_valorpend, acr_codcli, acr_fecproc,acr_interesper,acr_capitalper,acr_undsb,
                    acr_auditfho,acr_statacru,acr_tipocuo,acr_capitalrec,acr_interesrec)
                    values(v_acr_codacr,v_dsb_codmod,v_dsb_codcred, V_D_FECINIPER, V_D_FECFINPER,v_cuo_fecvencuo, v_dsb_coddsb,
                    v_acr_diasaccrdsb, v_acr_saldoeffect, v_int_devmeseffect, v_cap_rec, v_acr_tasavig, C_TIPOACR_DSB, 
                    v_int_periodo, v_int_avcto, v_pre_codcli, v_fec_procesadodsb,v_acr_interesper,v_acr_capitalper,v_int_31perant,
                    current,v_statacru,v_acr_tipocuo,v_cap_rec_effect,v_int_devmes); --v_int_rec_effect
                else
                
                	update pre_accrual 
                	set acr_fecini = V_D_FECINIPER, 
                	acr_fecfin = V_D_FECFINPER,
                    acr_diasaccr = v_acr_diasaccrdsb, 
                    acr_saldo = v_acr_saldoeffect, --saldo k eff
                    acr_interes = v_int_devmeseffect, -- i mensual effect
                    acr_capital = v_cap_rec, -- saldo k prog
                    acr_tasavig = v_acr_tasavig, 
                    acr_valor = v_int_periodo, -- i mensual prog  
                    acr_valorpend = v_int_avcto, 
                    acr_codcli = v_pre_codcli, 
                    acr_fecproc = v_fec_procesadodsb, --ult fecha de act de aprob
                    acr_interesper = v_int_devmes, -- i corr o panti a fec vcto 
                    acr_capitalper = v_acr_capitalper, -- k o panti a fec vcto
                    acr_undsb = v_int_31perant, -- i al 31dicant
                    acr_statacru = v_statacru, -- stat accru
                    acr_tipocuo = v_acr_tipocuo, -- tipo pp
                    acr_capitalrec = v_cap_rec_effect, -- k rec conta
                    acr_interesrec = v_int_rec_effect, -- i rec conta
                    acr_auditfho = current
                    where acr_codacr = v_acr_codacr;
                    
                	if dbinfo ("sqlca.sqlerrd2") = 0 then
                		raise exception -746,0,"regno excontarad " || v_acr_codacr || " " || v_dsb_codcred || " dsb " || v_dsb_coddsb || " " || v_cuo_fecvencuo; 
                	end if
                end if
                let v_contar_regs = v_contar_regs + 1;

            end if
        end foreach
        
        if v_contar_regs > 0 then
			call inserta_fecha_devengado(p_codcred,p_codmod,END_D_PERIOD, "user","estacion");
       	end if

    end foreach
                            
    if v_contar_regs > 0 then
		call p_updsumtrans(p_codmod, p_codcred, null, null, null, null, null);    
	    foreach 
	        select dsb_codmod, dsb_codcred, dsb_coddsb, dsb_fecdsb, dsb_valor
	        into v_dsb_codmod, v_dsb_codcred, v_dsb_coddsb, v_dsb_fecdsb, v_dsb_valor
	        from pre_desemb
	        where dsb_codmod = p_codmod
	        and dsb_codcred = p_codcred
	        and dsb_fecdsb < v_fechafin 
	        and dsb_valor > 0
	        and dsb_undsb > 0
	        
	        let v_fec_procesado = null;
	        
	        select max(acr_fecproc)
	        into v_fec_procesado
	        from pre_accrual
	        where acr_codmod = v_dsb_codmod
			and acr_codcred = v_dsb_codcred 
			and acr_fecaccru <= v_fechafin
			and acr_coddsb = v_dsb_coddsb
			and acr_tipoacr = C_TIPOACR_DSB
	        and acr_statacru = C_STATACRU_APROB; 
	        
	        let v_ultfec_pp_int = f_acr_ult_fec_acr(v_dsb_codcred, v_dsb_codmod, v_dsb_coddsb, v_fechafin, 3);
	        if v_fec_procesado is not null then
		        update pre_desemb
		        set dsb_monpag = 2,
		        dsb_fecplzven = v_fec_procesado
		        where dsb_codmod = p_codmod
		        and dsb_codcred = p_codcred
		        and dsb_coddsb = v_dsb_coddsb
		        and dsb_feculttrx <= v_ultfec_pp_int
	        	and dsb_fecplzven <= v_fec_procesado;
	        end if
	        
	    end foreach
	end if
	
    return v_fechafin;
end function;



