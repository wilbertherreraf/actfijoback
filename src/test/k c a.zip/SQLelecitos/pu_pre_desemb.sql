


DROP PROCEDURE IF exists d_creditos.pu_pre_desemb;
create procedure d_creditos.pu_pre_desemb(
o_dsb_coddsb		  like pre_desemb.dsb_coddsb	,
o_dsb_codcred         like pre_desemb.dsb_codcred   ,
o_dsb_codmod          like pre_desemb.dsb_codmod    ,
o_dsb_fecdsb          like pre_desemb.dsb_fecdsb    ,
o_dsb_fecini          like pre_desemb.dsb_fecini    ,
o_dsb_feciniint       like pre_desemb.dsb_feciniint ,
o_dsb_fecfin          like pre_desemb.dsb_fecfin    ,
o_dsb_feculttrx       like pre_desemb.dsb_feculttrx ,
o_dsb_tasa            like pre_desemb.dsb_tasa      ,
o_dsb_valor           like pre_desemb.dsb_valor     ,
o_dsb_valorcuo        like pre_desemb.dsb_valorcuo  ,
o_dsb_undsb           like pre_desemb.dsb_undsb     ,
o_dsb_saldo           like pre_desemb.dsb_saldo     ,
o_dsb_fecinidif       like pre_desemb.dsb_fecinidif ,
o_dsb_fecfindif       like pre_desemb.dsb_fecfindif ,
o_dsb_methodcapi      like pre_desemb.dsb_methodcapi,
o_dsb_tipodsb         like pre_desemb.dsb_tipodsb   ,
o_dsb_unidplaz        like pre_desemb.dsb_unidplaz  ,
o_dsb_unidplazint     like pre_desemb.dsb_unidplazint,
o_dsb_trxstaau        like pre_desemb.dsb_trxstaau,

n_dsb_fecdsb      like pre_desemb.dsb_fecdsb     ,
n_dsb_fecini      like pre_desemb.dsb_fecini     ,
n_dsb_feciniint   like pre_desemb.dsb_feciniint  ,
n_dsb_fecfin      like pre_desemb.dsb_fecfin     ,
n_dsb_tasa        like pre_desemb.dsb_tasa       ,
n_dsb_valor       like pre_desemb.dsb_valor      ,
n_dsb_valorcuo    like pre_desemb.dsb_valorcuo   ,
n_dsb_undsb       like pre_desemb.dsb_undsb      ,
n_dsb_saldo       like pre_desemb.dsb_saldo      ,
n_dsb_fecinidif   like pre_desemb.dsb_fecinidif  ,
n_dsb_fecfindif   like pre_desemb.dsb_fecfindif  ,
n_dsb_methodcapi  like pre_desemb.dsb_methodcapi ,
n_dsb_unidplaz    like pre_desemb.dsb_unidplaz   ,
n_dsb_unidplazint like pre_desemb.dsb_unidplazint,
n_dsb_trxstaau    like pre_desemb.dsb_trxstaau   
)

{
WHERRERA    20210922    (trigger upd)se crea el procedimiento que controla modificaciones sobre desembolsos
}
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    define C_CODDSB_CERO, C_FLAG_EXETRIGGER_PP_NOEXE integer;
    define v_prim_venc date;
                
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;

    if G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE then
        LET G_FLAG_EXETRIGGER_PP = -1;
        RETURN;
    end if
    
    LET G_FLAG_EXETRIGGER_PP = -1;

    call p_pre_desemb_valida(o_dsb_coddsb	,o_dsb_codcred      ,o_dsb_codmod       ,n_dsb_fecdsb       ,n_dsb_fecini       ,
    n_dsb_feciniint    ,n_dsb_fecfin       ,n_dsb_tasa         ,n_dsb_valor        ,
    n_dsb_valorcuo     ,n_dsb_undsb        ,n_dsb_saldo        ,n_dsb_fecinidif    ,n_dsb_fecfindif    ,
    n_dsb_methodcapi   ,n_dsb_unidplaz     ,n_dsb_unidplazint  );    
    
end procedure;


