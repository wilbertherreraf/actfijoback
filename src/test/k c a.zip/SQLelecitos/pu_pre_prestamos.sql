


DROP procedure IF EXISTS d_creditos.pu_pre_prestamos;
create procedure d_creditos.pu_pre_prestamos(o_PRE_CODCRED		like pre_prestamos.PRE_CODCRED		,
o_PRE_CODMOD        like pre_prestamos.PRE_CODMOD       ,
o_PRE_CODPROD       like pre_prestamos.PRE_CODPROD      ,
o_PRE_CODMON        like pre_prestamos.PRE_CODMON       ,
o_PRE_CODCLI        like pre_prestamos.PRE_CODCLI       ,
o_PRE_FECREG        like pre_prestamos.PRE_FECREG       ,
o_PRE_FECEMI        like pre_prestamos.PRE_FECEMI       ,
o_PRE_TASAPAC       like pre_prestamos.PRE_TASAPAC      ,
o_PRE_MONTO         like pre_prestamos.PRE_MONTO        ,
o_PRE_STATUS        like pre_prestamos.PRE_STATUS       ,
o_PRE_FECPLZVEN     like pre_prestamos.PRE_FECPLZVEN    ,
o_PRE_STATREG       like pre_prestamos.PRE_STATREG,
o_pre_trxstaau	like pre_prestamos.PRE_TRXSTAAU,				

n_PRE_CODCLI        like pre_prestamos.PRE_CODCLI       ,
n_PRE_FECREG        like pre_prestamos.PRE_FECREG       ,
n_PRE_FECEMI        like pre_prestamos.PRE_FECEMI       ,
n_PRE_TASAPAC       like pre_prestamos.PRE_TASAPAC      ,
n_PRE_FECPLZVEN    like pre_prestamos.PRE_FECPLZVEN       ,
n_PRE_MONTO         like pre_prestamos.PRE_MONTO        ,
n_PRE_STATUS        like pre_prestamos.PRE_STATUS       ,
n_PRE_STATREG       like pre_prestamos.PRE_STATREG,
n_pre_trxstaau	like pre_prestamos.PRE_TRXSTAAU
)
{
wherrera 20260505 se quita actualizacin de tasa 
}

    define errno integer;
    define errmsg char(255);
    define v_cont, v_verificar,P_TRAINTYDAYS, P_TRAINTMDAYS integer;
    define v_feculttrx date;
    
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PRE INT DEFAULT -1;
    DEFINE C_FLAG_EXETRIGGER_PRE_NOEXE INTEGER;
    
    LET C_FLAG_EXETRIGGER_PRE_NOEXE = 1;    
    let v_verificar = 0;
    
    if G_FLAG_EXETRIGGER_PRE = C_FLAG_EXETRIGGER_PRE_NOEXE then
        LET G_FLAG_EXETRIGGER_PRE = -1;
        RETURN;
    end if
    
    LET G_FLAG_EXETRIGGER_PRE = -1;

    if o_pre_status = 9 then
        let errmsg = "Prestamo suspendido no puede modificar.";
        raise exception -746, 0, errmsg;
    end IF
    
         if n_pre_monto <= 0 then
            let errno  = -1003;
            let errmsg = "El monto comprometido debe ser mayor  a cero";
            raise exception -746, 0, errmsg;
        end if;

        if n_PRE_FECEMI is null then
            let errmsg = "Fecha de emision debe tener valor.";
            raise exception -746, 0, errmsg;
        end if
        
        if n_PRE_TASAPAC is null or n_PRE_TASAPAC < 0 then
            let errmsg = "Tasa prestamo inicial debe ser mayor o igual a cero.";
            raise exception -746, 0, errmsg;
        end IF
        
	if nvl(o_pre_fecemi,n_pre_fecemi+1) != n_pre_fecemi or nvl(o_pre_tasapac,0) != n_pre_tasapac THEN
		let v_verificar = 1;	
	END IF
	
        if v_verificar = 1 THEN
        	let v_feculttrx = NULL;
        
	       	select max(dsb_feculttrx) 
	        INTO v_feculttrx
	        from pre_desemb
	        where dsb_codcred = o_pre_codcred
	        and dsb_codmod = o_pre_codmod;
        	
			let v_cont = 0;
        
        	IF v_feculttrx IS NOT NULL AND v_feculttrx > n_pre_fecemi THEN
				raise exception -746, 0, "No puede modificar tasa o fecha de emision, existen operaciones en fecha " || v_feculttrx || ", reprogramar si desea continuar";
        	END IF 
        	
        	IF o_pre_fecemi IS NOT NULL then
	        	SELECT count(1)
	        	INTO v_cont
			    FROM pre_tasaspre
			    WHERE mtp_codcred = o_pre_codcred
			    and mtp_codmod = o_pre_codmod
			    AND mtp_fechavig = o_pre_fecemi;        
        	END IF
                
        	IF v_cont = 0 THEN
        		call f_GET_TRA_INT_YR_MTH_BASE (o_pre_codmod,o_pre_codcred) returning P_TRAINTYDAYS, P_TRAINTMDAYS;
        	
		        insert into pre_tasaspre(mtp_codmod,mtp_codcred,mtp_fechavig,mtp_tbase,mtp_intydias, mtp_trxstaau, mtp_auditusr, mtp_auditwst, mtp_auditfho)
		        VALUES (o_pre_codmod,o_pre_codcred,n_pre_fecemi,n_pre_tasapac,P_TRAINTYDAYS, n_pre_trxstaau, null, null, current);
		    ELSE
                update pre_tasaspre
                set mtp_trxstaau = n_pre_trxstaau,
                mtp_fechavig = n_pre_fecemi,
                mtp_tbase = n_pre_tasapac,
                mtp_auditfho = current
                WHERE mtp_codcred = o_pre_codcred
                and mtp_codmod = o_pre_codmod
                AND   mtp_fechavig = o_pre_fecemi;
		    
        	END IF
        end if
end procedure;


