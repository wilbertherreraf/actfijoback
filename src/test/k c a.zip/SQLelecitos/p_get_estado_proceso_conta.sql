


DROP procedure IF EXISTS d_creditos.p_get_estado_proceso_conta;
create procedure d_creditos.p_get_estado_proceso_conta(p_codcmp integer, p_idtabla integer, p_codcred integer, p_codmod integer, p_coddsb integer,
p_nrocomprob varchar(10), p_fechaini date, p_fechafin date) 
RETURNING varchar(30),integer,integer,  integer,  integer, integer, integer,
	varchar(30),varchar(30), date,date, decimal(20,2), lvarchar(500)
	

         -- DESCRIPCI: obtiene datos del proceso contable de las operaciones
         -- AUTOR: HENRY IVAN PANIQUE MIRANDA
         -- CREACI:  30-11-2023
         -- SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
		-- wherrera 20260505 se modifica el procedimiento para retornar el estado de procesos contables registrados  

define v_nulito,w_prc_estado integer;
define v_tipoproc,v_nro_comprob,v_cve_tipo_comprob varchar(30);
define v_fecha_cont,v_fec_vcto date;
define v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmpoper,v_estado integer;
define v_monto, v_monto_b decimal(20,2);
define v_glosa lvarchar(500);

  	let p_fechaini = nvl(p_fechaini, mdy(1,1,1998));
  	let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));  	
	let v_monto = 0;
	let v_monto_b = 0; 
  	let w_prc_estado = null; 
  	let v_nulito = null;
  	let v_tipoproc = null;
  	let v_nro_comprob = null;
  	let v_cve_tipo_comprob = null;
	let v_fecha_cont = null;
	let v_fec_vcto = null;
	let v_idtabla = null;
	let v_codcred = null; 
	let v_codmod = null; 
	let v_coddsb = null;
	let v_tipocmpoper = null;
	let v_estado = null;
	let v_glosa = null;
  	
	foreach
		select tipoproc,idtabla,codcred, codmod, coddsb, tipocmp,estado,
		nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto,
		monto, glosa
		into v_tipoproc,v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmpoper,v_estado,
		v_nro_comprob,v_cve_tipo_comprob, v_fecha_cont,v_fec_vcto,
		v_monto, v_glosa
		from (
			select "REGGAR" tipoproc,id idtabla,codcred, codmod, coddsb , rgg_codcmp tipocmp, estado estado,
			nro_comprobante_coin nro_comprob, cve_tipo_comprob, fecha fecha_cont, fecha fec_vcto,
			valor_total_garantia monto, glosa_coin glosa
			from pre_registrogarantias
			union all
			select "DSB", id,codcred, codmod, dsb_coddsb ,pds_codcmp, estado,
			nro_comprobante_coin,cve_tipo_comprob, fecha, fecha,
			monto_desembolsar, glosa_coin
			from pre_desembolso_detalle
			union all
			select "CUSTGAR",id,codcred, codmod, dsb_coddsb , cug_codcmp, estado ,
			nro_comprobante_coin,cve_tipo_comprob, fecha, fecha,
			valor_total_garantia, glosa_coin
			from pre_custodia_garantia
			union all
			select "RETGAR",id,codcred, codmod, coddsb , rtg_codcmp, estado,
			nro_comprobante_coin,cve_tipo_comprob, fecha,fecha_vencimiento,
			valor_cuota, glosa_coin
			from pre_retiro_garantia
			union all
			select "COB",id,codcred, codmod, coddsb , pcu_tipocmp, estado,
			nro_comprobante_coin,cve_tipo_comprob, fecha,fecha_vencimiento,
			total_cuota_vencimiento, glosa_coin
			from pre_pagocuota
			union all
			select "DEV",prc_codprc,prc_codcred, prc_codmod, v_nulito, prc_codcmp, prc_estado,
			prc_nro_comprob,prc_cve_tipo_comprob,prc_fecha,prc_fecha_2,
			prc_montodeven,prc_glosa
			from pre_prcconta		
		)
		where tipocmp = nvl(p_codcmp,tipocmp)
		and idtabla = nvl(p_idtabla, idtabla) 
    	and codcred = nvl(p_codcred, codcred)
    	and codmod = nvl(p_codmod, codmod)
    	and nvl(nro_comprob,"") = nvl(p_nrocomprob,nvl(nro_comprob,""))
    	and fec_vcto between p_fechaini and p_fechafin
    	order by fec_vcto
	    	return v_tipoproc,v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmpoper,nvl(v_estado,1),
			v_nro_comprob,v_cve_tipo_comprob, v_fecha_cont,v_fec_vcto, nvl(v_monto,0), v_glosa with resume;
    end foreach
    
END PROCEDURE;



