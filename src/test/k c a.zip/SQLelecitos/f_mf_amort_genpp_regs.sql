

DROP function IF EXISTS d_creditos.f_mf_amort_genpp_regs;
create function d_creditos.f_mf_amort_genpp_regs(p_codcred integer, p_codmod integer, p_coddsb integer,p_tipotrx integer, p_codrepro integer,
    p_f_corterepro date, p_fecha_prim_venc date, p_fecha_prim_amort date, p_fecha_prim_amortint date, amt decimal(20,2), rate float, unidplaz integer, 
    p_nroamort_int INTEGER, NRODIASPERIODO INTEGER, p_usuario varchar(50), p_estacion varchar(50))
returning integer, integer, integer, integer, date, date, date,integer,decimal(15,7), 
	decimal(20,2), decimal(20,2), decimal(20,2), decimal(20,2), decimal(20,2), integer
{
	wherrera 20260505 funcion que retorna un plan de pagos reprogramado 
}
	
define v_interes, v_intper, v_amortper, v_capamortper, v_sidp,v_acu_montocuo, v_siap decimal(20,2);
define v_period, C_INPUT_PERIOD_EXACT, MONTHSPERPERIOD,P_TRAINTYDAYS, P_TRAINTMDAYS,NGRACIA,v_codacu,v_dsb_coddsb integer;
define v_fecha_prim_venc, v_LAST_DATE, fecha_ini, fecha_fin,v_ST_D_PERIOD, v_END_D_PERIOD,v_period_ant date;
define D_DIFFERENCE_IN_DAYS, v_first, v_TRAINTYDAYS,v_pre_methodcapi,C_REPROTEMPO, v_pre_unidplaz,v_SEQ_PERIOD integer;
define v_intper_float float;
define v_app_t, v_appaux_t aux_planpagos_t;

	let NGRACIA = 0;
    let C_INPUT_PERIOD_EXACT = 3;
	let C_REPROTEMPO = 5;
    let v_fecha_prim_venc = nvl(p_fecha_prim_venc, p_fecha_prim_amortint);
	
    let v_app_t = f_init_app_t();
    
	call f_GET_TRA_INT_YR_MTH_BASE(p_codmod, p_codcred) returning P_TRAINTYDAYS, P_TRAINTMDAYS;
	
    foreach 
        select cuo_codcuo, cuo_codcred, cuo_codmod, cuo_fecvencuo, 
        cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_valor,
        cuo_valorpend, cuo_coddsb, cuo_tabtipocuo,cuo_tipocuo, cuo_tipoacu,
        cuo_tabmonpag, cuo_monpag, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau,
        cuo_desemb
        into v_app_t.acu_numcuo, v_app_t.acu_codcred, v_app_t.acu_codmod, v_app_t.acu_fecvencuo,
        v_app_t.acu_fecinicuo, v_app_t.acu_fecfincuo, v_app_t.acu_capital, v_app_t.acu_interes, v_app_t.acu_cargos, v_app_t.acu_valor,
        v_app_t.acu_valorpend, v_app_t.acu_coddsb, v_app_t.acu_tabtipocuo,v_app_t.acu_tipocuo, v_app_t.acu_tipoacu,
        v_app_t.acu_tabmonpag, v_app_t.acu_monpag, v_app_t.acu_tabtipotrx, v_app_t.acu_tipotrx, v_app_t.acu_tabtrxstaau, v_app_t.acu_trxstaau,
        v_acu_montocuo
    	from pre_planpagos
    	where cuo_codcred = p_codcred
    	and cuo_codmod = p_codmod
    	--and cuo_coddsb = p_coddsb
    	and cuo_coddsb > 0
    	and cuo_valor > 0
    	and cuo_fecvencuo < p_f_corterepro
    	order by cuo_coddsb, cuo_fecvencuo
    	
    	call f_DAYS_BETWEEN_2_DATES(v_app_t.acu_fecinicuo, v_app_t.acu_fecvencuo, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS;
    	let v_app_t.acu_tasa = f_gettasavigenteprest(v_app_t.acu_codcred, v_app_t.acu_codmod, v_app_t.acu_fecvencuo-1);
    	
        return v_app_t.acu_numcuo,p_codcred,p_codmod, v_app_t.acu_coddsb, v_app_t.acu_fecvencuo, v_app_t.acu_fecinicuo, v_app_t.acu_fecfincuo,D_DIFFERENCE_IN_DAYS,v_app_t.acu_tasa, 
        v_app_t.acu_capital, v_app_t.acu_valor, v_app_t.acu_interes, v_app_t.acu_valorpend, v_app_t.acu_cargos, v_app_t.acu_tipocuo with resume;    	
    end foreach

    let v_appaux_t = f_init_app_t();
    let v_appaux_t.acu_codmod = p_codmod;
    let v_appaux_t.acu_codcred = p_codcred;
    let v_appaux_t.acu_fecvencuo = v_fecha_prim_venc;
    let v_appaux_t.acu_fecinicuo = p_f_corterepro;
    let v_appaux_t.acu_fecfincuo = p_fecha_prim_amort;
    let v_appaux_t.acu_tabtipodsb = 5;        
	let v_appaux_t.acu_tipodsb = p_codrepro;
    let v_appaux_t.acu_unidplaz = unidplaz;    
    
    if nvl(unidplaz,0) = 0 then
    	call f_dsb_getmethod_plz(p_codcred, p_codmod, p_coddsb) returning v_pre_methodcapi, v_pre_unidplaz;
    	let v_appaux_t.acu_unidplaz = v_pre_unidplaz;
    end if
    
    let v_appaux_t.acu_tasa = nvl(rate,0);	
	if nvl(rate,0) <= 0 then
		let v_app_t.acu_tasa = f_gettasavigenterepro(p_codcred, p_codmod,p_f_corterepro, 1);		
	end if
	
    let v_app_t = f_init_app_t();
    
    foreach
    	select dsb_coddsb
    	into v_dsb_coddsb
    	from pre_desemb
    	where dsb_codcred = p_codcred
    	and dsb_codmod = p_codmod
		order by dsb_fecdsb
		
		let v_siap = f_acr_saldo_fecha(p_codcred, p_codmod, v_dsb_coddsb, v_fecha_prim_venc, 1);
		let v_appaux_t.acu_capital = v_siap;
    	let v_appaux_t.acu_coddsb = v_dsb_coddsb;
		
		if v_siap > 0 then
		
		    foreach
		        execute procedure f_mf_amort_salddeudo( v_appaux_t, p_fecha_prim_amortint,p_tipotrx, p_codrepro,
		            p_nroamort_int, 0, NRODIASPERIODO) 
		            into v_app_t, D_DIFFERENCE_IN_DAYS  
		        return v_app_t.acu_numcuo, p_codcred, p_codmod, v_app_t.acu_coddsb, v_app_t.acu_fecvencuo, v_app_t.acu_fecinicuo, v_app_t.acu_fecfincuo,D_DIFFERENCE_IN_DAYS,v_app_t.acu_tasa, 
		        v_app_t.acu_capital, v_app_t.acu_valor, v_app_t.acu_interes, v_app_t.acu_valorpend, v_app_t.acu_cargos, v_app_t.acu_tipocuo with resume;
		    end foreach	
		end if
    end foreach
end function;


