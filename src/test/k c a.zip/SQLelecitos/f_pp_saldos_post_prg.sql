


drop function IF EXISTS d_creditos.f_pp_saldos_post_prg;
create function d_creditos.f_pp_saldos_post_prg(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_tipocuo integer)  
returning decimal(20,2)
{
wherrera 20260405 se modifica la consulta para obtener la suma de la cuota programada pendiente a fecha de aplicacion

call f_pp_saldos_post_prg(33, 17, null, "2018-12-10",2)  
call f_pp_saldos_post_prg(33, 17, 33001, "2018-12-10",1)
call f_pp_saldos_post_prg(12, 17, null, "2021-02-04",1)
}
define v_sum_valor_fecaplic  like pre_planpagos.cuo_valor;

	let v_sum_valor_fecaplic = 0;
	
	select nvl(sum(cuo_valor), 0)
	INTO v_sum_valor_fecaplic
	from (
		select cuo_valor, cuo_fecvencuo,cuo_fecfincuo,cuo_tipocuo,cuo_tipoacu,fecapliccuo,
			decode(fecapliccuo, 0, cuo_fecvencuo, date(fecapliccuo)) fecaplic
		from (
			select cuo_valor, cuo_fecvencuo,cuo_fecfincuo,cuo_tipocuo,cuo_tipoacu,
			f_pp_isgracia(cuo_codcred, cuo_codmod, cuo_coddsb, cuo_fecvencuo, cuo_tipocuo) fecapliccuo
			from pre_planpagos
			where cuo_codcred = p_codcred
			AND cuo_codmod = p_codmod
			and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
			AND cuo_coddsb > 0
			and cuo_fecvencuo < p_fecha
			AND cuo_tipocuo = p_tipocuo
		)
		where fecapliccuo > 0
	)
	where cuo_fecvencuo != fecaplic
	and fecaplic = p_fecha;
	
    return nvl(v_sum_valor_fecaplic, 0);
end function;



