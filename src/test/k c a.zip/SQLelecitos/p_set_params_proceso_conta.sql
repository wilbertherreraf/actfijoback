



DROP procedure IF EXISTS d_creditos.p_set_params_proceso_conta;
create procedure d_creditos.p_set_params_proceso_conta(p_codcmp integer, p_idtabla integer, 
p_codcred integer, p_codmod integer, p_coddsb integer, p_fecvcto date, p_numtrx integer,p_usuario varchar(15), p_estacion varchar(50))

{
         -- DESCRIPCI: establece los paramtros para el proeso indicado en las tablas correspondientes
         -- PARAMETROS INGRESO: p_idtabla integer                Codigo de proceso de comprobante
         -- PARAMETROS SALIDA: resultado integer                Resultado de la operacion
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
wherrera 20260505 para devengados y cobros el monto se registra en la tabla prcconta, se registra la informacion de los renglones de comprobante para operaciones 4,5,6,7
 } 
  define w_prc_fecha   date;
  define w_mes_anio    varchar(15);
  define w_pre_codcred integer;
  define w_pre_codmod  integer;
  define w_mes         integer;
  define w_nombre_corto varchar(100);
  
  define W_SOURCE_MATRIZ_PARAMETROS   INTEGER;
  define C_PARAM_COD_NCORTO,P_TRAINTYDAYS, P_TRAINTMDAYS, P_INTYDAYS INTEGER;
    
  --devengamiento
  DEFINE w_nro_desembolsos    INTEGER;
  DEFINE w_nro_dias , v_nro_dias          INTEGER;
  DEFINE w_interes_devengado  DECIMAL(16,2);
  DEFINE w_desembolsado,v_prc_montodeven       DECIMAL(16,2);
  DEFINE w_saldocapital,v_sum_acr_interes       DECIMAL(16,2);
  DEFINE w_pre_descrip, v_pre_descrip        VARCHAR(150);
  DEFINE w_pre_numcontra      VARCHAR(100);
  DEFINE W_pre_numresol       VARCHAR(100);
  define v_fechainidev, v_prc_fecinideven,v_dsb_fecdsb date;
define v_nomcred,v_nrodoc varchar(100);
define v_nrocuota,v_contar,w_codcmp,v_idpcuota,v_pcu_tipocmp, v_pre_codcli, v_max_codtpr, v_cont_ant, v_cont_fec integer;
define C_TIPOCUO_INT,C_TIPOCUO_CAP,C_TIPOCOB_PANTI_CAP,C_TIPOCOB_PANTI_INT integer;
define v_fecha,v_fec31int date;
define v_capital_venc,v_interes_venc,v_panti_cap,v_panti_intvcto,v_mnt_int31dic, v_int_alfechavcto,v_saldo_cap like pre_planpagos.cuo_valor;
define v_dsb_undsb, v_cap_cuota,v_int_cuota,v_total_int,v_total_cuota, v_int31dic, v_intalvcto like pre_planpagos.cuo_valor;
define  v_params_glosa, v_cmp_glosa,v_valores_glosa   LVARCHAR(500);
define v_nro_comprobante_coin,v_pre_numcontra, v_pre_numresol, v_nrocuenta varchar(50);
define v_nulito,w_prc_estado integer;
define v_tipoproc,v_nro_comprob,v_cve_tipo_comprob varchar(30);
define v_fecha_cont,v_fec_vcto date;
define v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_estado integer;
define v_monto, v_monto_mn decimal(20,2);
define v_glosa lvarchar(500);


	let C_TIPOCUO_INT = 2;
	let C_TIPOCUO_CAP = 1;
	let C_TIPOCOB_PANTI_CAP = 12;
	let C_TIPOCOB_PANTI_INT = 22;
	
     let W_SOURCE_MATRIZ_PARAMETROS = 1;
     let C_PARAM_COD_NCORTO = 42; --NOMBRE CORTO PROYECTO

	select tipoproc,idtabla,codcred, codmod, coddsb, tipocmp,estado,
	nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto,monto_mn, glosa
	into v_tipoproc,v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_estado,
	v_nro_comprob,v_cve_tipo_comprob, v_fecha_cont,v_fec_vcto, v_monto_mn, v_glosa
	from table(p_get_estado_proceso_conta(p_codcmp, nvl(p_idtabla,0), nvl(p_codcred, 0),p_codmod, null,null, null, null)) 
		t(tipoproc,idtabla,codcred, codmod, coddsb,tipocmp,estado,
			nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto, monto_mn, glosa)
	where estado in (1,2);

	if v_idtabla is null then
		raise exception -746,0,"GenActOper: Registro inexistente ID: '" || p_idtabla  || "' o con estado invalido, tipo CMPOPER: " || p_codcmp;
	end if
	
	if length(trim(nvl(v_nro_comprob,""))) > 0 then
		raise exception -746,0,"GenActOper: Registro ID: '" || p_idtabla  || "' con nro de comprobante registrado, tipo CMPOPER: " || p_codcmp;
	end if
	
  	select pre_codcli, trim(UPPER(pre_descrip)), trim(pre_numcontra), trim(pre_numresol)
    into v_pre_codcli,v_pre_descrip, v_pre_numcontra, v_pre_numresol
    from pre_prestamos
   	where pre_codcred = p_codcred
     and pre_codmod = p_codmod;  

			select par_parametro
	        into v_nomcred
	        from gen_parametro 
	        where par_codcred = p_codcred
	       	and par_codmod  = p_codmod
	        and par_tprcod  = C_PARAM_COD_NCORTO;

			
		if p_codcmp in (1,2) then
			call p_generar_renglon(p_idtabla, p_codcmp, p_codcred, p_codmod,null, p_usuario, p_estacion);
		elif p_codcmp = 3 then
		  	select prc_codcmp, prc_fecha_2, prc_codcred, prc_codmod , prc_montodeven, prc_fecinideven
		    into v_pcu_tipocmp, w_prc_fecha, w_pre_codcred, w_pre_codmod , v_prc_montodeven, v_prc_fecinideven
		    from pre_prcconta
		   	where prc_codprc =  p_idtabla; 
		  
			if dbinfo("sqlca.sqlerrd2") = 0 then
				raise exception -746,0,"DEV: Registro inexistente en pre_prcconta " || p_idtabla ;
			end if
			
		    LET w_mes_anio = f_reemplazar_parametros_glosa("MES_LIT",null,w_prc_fecha, null,null,null,null) || ' ' || YEAR(w_prc_fecha);
		  
			select cmp_glosa
			into v_cmp_glosa
	   		from gen_comprobante
	  		where cmp_codcmp = p_codcmp;
	
			CALL p_get_datos_devengamiento(p_codcred, p_codmod, v_prc_fecinideven, w_prc_fecha) 
				returning v_fechainidev, w_nro_desembolsos, w_nro_dias, w_interes_devengado, w_desembolsado, w_saldocapital, v_sum_acr_interes;
		
			LET v_valores_glosa = "DIAS=" || w_nro_dias; 
			LET v_valores_glosa = v_valores_glosa || "|MES=" || w_mes_anio;
			let v_valores_glosa = v_valores_glosa || "|NRODSB=" || w_nro_desembolsos;
			let v_valores_glosa = v_valores_glosa || "|NOMCRED=" || nvl(v_nomcred,v_pre_descrip);
			let v_valores_glosa = v_valores_glosa || "|MNTDSB=" || f_formatear_bigdecimal(w_desembolsado) ;
			let v_valores_glosa = v_valores_glosa || "|SLDCAP=" || f_formatear_bigdecimal(w_saldocapital);
			let v_valores_glosa = v_valores_glosa || "|NUMRESOL=" || nvl(v_pre_numresol,"");
			let v_valores_glosa = v_valores_glosa || "|NUMCONTRA=" || nvl(v_pre_numcontra,"");		
	    	
			LET v_params_glosa = f_reemplazar_parametros_glosa("CALCGLOSA",null,null, null,null,v_cmp_glosa,v_valores_glosa);
			
			update pre_prcconta
			set prc_glosa = v_params_glosa,
			prc_hora = current
	   		where prc_codprc =  p_idtabla
			and prc_estado = 1
	    	and length(trim(nvl(prc_nro_comprob, ""))) = 0;
	 
			call p_generar_renglon(p_idtabla, p_codcmp, p_codcred, p_codmod,null, p_usuario, p_estacion);
		elif p_codcmp in (4,5,6,7)  then
	
				select dsb_undsb,
				nvl((case  
					when dsb_nrodoc is null or length(trim(dsb_nrodoc)) < 5 then
						(select distinct pg.gard_claveserie from pre_garantiad pg where pg.gard_coddsb = dsb_coddsb)
					else
						dsb_nrodoc
				end), dsb_nrodoc), dsb_fecdsb
				into v_dsb_undsb, v_nrodoc, v_dsb_fecdsb
				from pre_desemb
				where dsb_coddsb = v_coddsb; 
	
				select count(dsb_coddsb) 
				into v_cont_ant
				from pre_desemb
				where dsb_codcred = p_codcred
				and dsb_codmod = p_codmod
				and dsb_valor > 0
				and dsb_fecdsb < v_dsb_fecdsb;
				
				select count(dsb_coddsb)
				into v_cont_fec
				from pre_desemb 
				where dsb_codcred = p_codcred
				and dsb_codmod = p_codmod
				and dsb_valor > 0
				and dsb_fecdsb = v_dsb_fecdsb
				and dsb_coddsb != v_coddsb
				and dsb_coddsb < v_coddsb;
				
				let v_cont_fec = v_cont_fec + v_cont_ant + 1; 
				
			    select count(distinct cuo_fecvencuo)
			    into v_nrocuota
			    from pre_planpagos
			    where cuo_codcred = p_codcred
			    and cuo_codmod = p_codmod 
			    and cuo_tipocuo in (C_TIPOCUO_INT, 24)
			    and cuo_valor > 0
			    and cuo_coddsb > 0
			    and cuo_fecvencuo < v_fec_vcto;
			    
			    let v_nrocuota = nvl(v_nrocuota, 0) + 1;
			    
			    let v_capital_venc = f_cobrostipocob_fven(p_codcred, p_codmod, v_coddsb, p_fecvcto,p_fecvcto, C_TIPOCUO_CAP, null);
			    let v_interes_venc = f_cobrostipocob_fven(p_codcred, p_codmod, v_coddsb, p_fecvcto,p_fecvcto, C_TIPOCUO_INT, null);
		
			    let v_panti_cap = f_cobrostipocob_fven(p_codcred, p_codmod, v_coddsb, p_fecvcto,p_fecvcto, C_TIPOCOB_PANTI_CAP, null);
			    let v_panti_intvcto = f_cobrostipocob_fven(p_codcred, p_codmod, v_coddsb, p_fecvcto,p_fecvcto, C_TIPOCOB_PANTI_INT, null);	    
		
		    	select sum(int_al31dic), sum(int_alfechavcto)
		    	into v_mnt_int31dic, v_int_alfechavcto
		    	from v_planpagos_resu 
		    	where codcred = p_codcred
		    	and codmod = p_codmod
		    	and coddsb = v_coddsb
		    	and fecha = p_fecvcto;
			    
		    	let v_mnt_int31dic = nvl(v_mnt_int31dic, 0);
		    	let v_int_alfechavcto = nvl(v_int_alfechavcto, 0);
		    	
		    	let v_saldo_cap = f_acr_saldo_fecha(p_codcred, p_codmod, v_coddsb, p_fecvcto, 1);
	
		    	let v_int_cuota = 0;
				let v_int31dic = 0;
				let v_intalvcto = 0;
		    	let v_int_cuota = v_interes_venc + v_panti_intvcto;
		    	
		    	if v_mnt_int31dic > 0 then
		    		if v_int_cuota >= v_mnt_int31dic then
		    			let v_int31dic = v_mnt_int31dic;
		    			let v_intalvcto = v_int_cuota - v_int31dic;
		    		else
		    			let v_int31dic = v_int_cuota;
		    			let v_intalvcto = v_int_cuota - v_int31dic;	    		
		    		end if
		    	else
					let v_intalvcto = v_int_cuota;	    	
		    	end if
				let v_total_int = v_int31dic + v_intalvcto;
		    	let v_cap_cuota = v_capital_venc + v_panti_cap; 
		    	
		    	let v_total_cuota = v_cap_cuota + v_total_int;   
		
		    	let v_pcu_tipocmp = 4;
		    	if v_cap_cuota > 0 then
			    	if v_pre_codcli in (2,10) then 
			  			let v_pcu_tipocmp = 5;
			    	end if
		    	else
		    		let v_pcu_tipocmp = 6;
		    		if v_pre_codcli in (2,10) then 
			  			let v_pcu_tipocmp = 7;
			    	end if
		    	end if
		
				select cmp_glosa
				into v_cmp_glosa
	       		from gen_comprobante
	      		where cmp_codcmp = v_pcu_tipocmp;
	
				LET v_valores_glosa = "FECVCTOMDY=" || f_reemplazar_parametros_glosa("FEC_SHORT",null,p_fecvcto, null,null,null,null);
				LET v_valores_glosa = v_valores_glosa || "|NRODSB=" || v_cont_fec;
				let v_valores_glosa = v_valores_glosa || "|NOMCRED=" || nvl(v_nomcred,v_pre_descrip);
				let v_valores_glosa = v_valores_glosa || "|SLDCAP=" || v_saldo_cap;
				let v_valores_glosa = v_valores_glosa || "|CLVSERIE=" || nvl(v_nrodoc,"");  
				let v_valores_glosa = v_valores_glosa || "|NROCUOTA=" || v_nrocuota; 
				let v_valores_glosa = v_valores_glosa || "|NUMRESOL=" || nvl(v_pre_numresol,"");
				let v_valores_glosa = v_valores_glosa || "|NUMCONTRA=" || nvl(v_pre_numcontra,"");		
		    	
				LET v_params_glosa = f_reemplazar_parametros_glosa("CALCGLOSA",null,null, null,null,v_cmp_glosa,v_valores_glosa);
				
		    	update pre_pagocuota
		    	set pcu_numtrx = nvl(pcu_numtrx,p_numtrx),
		    	pcu_tipocmp = v_pcu_tipocmp,
		    	total_cuota_vencimiento = v_total_cuota,
		    	pago_importe_capital = v_cap_cuota,
		    	pago_importe_intereses = v_int_cuota,
		    	intereses_gestion_anterior = v_int31dic,
		    	intereses_gestion_actual = v_intalvcto,
		    	total_saldo = v_saldo_cap,
		    	numero_cuota = v_nrocuota,
		    	nro_claveserie = v_nrodoc,
		    	glosa_coin = v_params_glosa,
		    	fecha = date(current),
		    	audit_usuario = p_usuario,
		    	audit_fechahora = current,
		    	audit_host = p_estacion
		    	where id = p_idtabla
		    	and coddsb = v_coddsb 
		    	and estado = 1
		    	and length(trim(nvl(nro_comprobante_coin, ""))) = 0;
	
		    	let v_contar = 0;
		    	
				select count(1)
				into v_contar
				from gen_prcparams
				where prp_codprc = p_idtabla
				and prp_tipoproc = v_pcu_tipocmp
				and prp_nroafectable is not null
				and prp_montomn > 0
				and prp_ctamov is not null
				and prp_nroreng > 0
				and prp_estado = 3;
					
		    	if v_contar = 0 then
		    		call p_generar_renglon(p_idtabla, v_pcu_tipocmp, p_codcred, p_codmod,null, p_usuario, p_estacion);
		    	end if
		elif p_codcmp = 8 then
			call p_generar_renglon(p_idtabla, p_codcmp, p_codcred, p_codmod,null, p_usuario, p_estacion);	
		elif p_codcmp = 9 then
			call p_generar_renglon(p_idtabla, p_codcmp, p_codcred, p_codmod,null, p_usuario, p_estacion);	    	
		elif p_codcmp = 10 then
			call p_generar_renglon(p_idtabla, p_codcmp, p_codcred, p_codmod,null, p_usuario, p_estacion);	    	
		end if
		
    
END PROCEDURE;


