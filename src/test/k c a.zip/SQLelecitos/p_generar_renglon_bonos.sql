


DROP procedure IF EXISTS d_creditos.p_generar_renglon_bonos;
create procedure d_creditos.p_generar_renglon_bonos(p_idtabla integer, p_codcmp integer,p_codcred integer, p_codmod integer, 
	p_centro integer, p_cmp_tipo varchar(1), p_cmp_nro varchar(7), p_gestion integer, p_nro_periodo integer, p_nro_dia integer, 
	p_usuario varchar(30), p_estacion varchar(50)) 
    
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO     |  Descripcion
---------------------------------------------------------------------------------------------------------------------------------------
--|  mcramos  |  19-03-2025   |  2352035  | Ajuste para actualizar la glosa se debe y haber en registro de desembolso
---------------------------------------------------------------------------------------------------------------------------------------   
--|  mcramos  |  05-03-2025   |  2367989  | Ajuste para generacion de reglon en registro de Custodia de Garantia
---------------------------------------------------------------------------------------------------------------------------------------
--|  mcramos  |  28-03-2025   |  2368094  | Ajuste para generacion de reglon en registro de Retiro de Garantia
---------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  06-05-2025   | 2401886   | Ajuste para generacion de comprobante para registro contable de Pago de Cuota
---------------------------------------------------------------------------------------------------------------------------------------      
--| acanqui   |  10-06-2025   | 2471161   | Ajuste para implementar la imputacion presupuestaria posterior a la generacion de comprobante del registro contable de Pago de Cuota
---------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  11-06-2025   | 2440644   | Ajuste para implementar el registro CRV SIGMA posterior a la generacion del comprobante del registro de desembolso
---------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  14-07-2025   | 2510352   | Ajuste para implementar la imputacion presupuestaria posterior a la generacion de comprobante del registro contable de Pago de Cuota tipo R
---------------------------------------------------------------------------------------------------------------------------------------
--| wherrera   |  05-03-2026   |  | genera renglones en coin para todas las operaciones
---------------------------------------------------------------------------------------------------------------------------------------
-- variables
define w_monto_mo          like contbcb@bcbux02:reng_comprob.monto_mo;
define w_factor_conv_mo_mn like contbcb@bcbux02:reng_comprob.factor_conv_mo_mn; 
define w_glosa_reng        like contbcb@bcbux02:reng_comprob.glosa_reng;
define v_prp_nroafectable     like contbcb@bcbux02:reng_comprob.nro_afectable; 
define w_monto_mn          like contbcb@bcbux02:reng_comprob.monto_mn;
define w_prl_nro_reng_esq          like contbcb@bcbux02:reng_comprob.nro_reng_esq;
define w_cp, w_cp_int,w_cp_monto_mn,w_cp_gestion,v_cve_dev_real VARCHAR(20);
define w_cp_imp,w_cp_cta,w_cp_cta_int, w_cp_renglon, w_cp_renglon_int, w_nro_renglones,v_nro_reng_cp_cmpb, v_nro_cp_cmpb       INTEGER;      
define v_prp_estado,w_codigo_cliente, v_numero_cuota, v_nro_renglon,v_cantpp INTEGER;
define v_prp_codtpr, w_nro_renglon_aux, x_imp_sigma,v_max_codtpr INTEGER;
define v_prp_mayor,w_tipo_sigma,v_rln_codlitmnt,v_prp_nrocp,w_prl_nro_afectable, w_prl_nro_mayor VARCHAR(20);
define v_idtabla,v_codcred, v_codmod, v_coddsb,v_estado,v_tipocmp,v_nro_centro,v_contar,v_contsigma,w_delim_pos integer;
define v_tipoproc, v_nro_comprob, v_cve_tipo_comprob,v_prp_ctamov,w_rln_dh,w_ctp_cp_rfa_default,w_cta_mov_moneda varchar(15);
define v_fec_vcto, v_fecha_cont date;
define v_monto_mn,w_prl_monto_mn,w_prl_monto_mo,v_mnt_imp decimal(20,2);
define v_glosa lvarchar(500);
define w_prl_factor_conv_mo_mn     like contbcb@bcbux02:reng_comprob.factor_conv_mo_mn;

	select tipoproc,idtabla,codcred, codmod, coddsb, tipocmp,estado,
	nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto,monto_mn, glosa
	into v_tipoproc,v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_estado,
	v_nro_comprob,v_cve_tipo_comprob, v_fecha_cont,v_fec_vcto, v_monto_mn, v_glosa
	from table(p_get_estado_proceso_conta(p_codcmp, nvl(p_idtabla,0), nvl(p_codcred, 0),p_codmod, null,null, null, null)) 
		t(tipoproc,idtabla,codcred, codmod, coddsb,tipocmp,estado,
			nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto, monto_mn, glosa);
	
	if v_idtabla is null then
		raise exception -746,0,"GENRENG: Registro inexistente ID: '" || p_idtabla  || "' tipo CMPOPER: " || p_codcmp;
	end if
	
	if v_estado != 1 then
		raise exception -746,0,"GENRENG: Estado de Registro invalido ID: '" || p_idtabla  || "' tipo CMPOPER: " || p_codcmp || " estado: " || v_estado;
	end if
	
	if length(trim(nvl(v_nro_comprob, ""))) > 0 then
		raise exception -746,0,"GENRENG: Operacion contable ID: '" || p_idtabla  || "' tipo CMPOPER: " || p_codcmp || " tiene nro comprobante: " || v_nro_comprob;		
	end if

	select count(1)
	into v_contar
	from gen_prcparams
    where prp_codprc = p_idtabla
    and prp_tipoproc = p_codcmp
    and prp_ctamov is not null
    and prp_montomo > 0
    and prp_estado = 2;
	
	if v_contar <= 1 then
		raise exception -746,0,"GENRENG: Operacion contable ID: '" || p_idtabla  || "' tipo CMPOPER: " || p_codcmp || " no tiene registrado renglones en gen_prcparams";	
	end if
	
	let w_cta_mov_moneda = "69"; --moneda por defecto en bolivianos de acuerdo a lo indicado por usuario
	
	select factor 
    into w_prl_factor_conv_mo_mn 
    from contbcb@bcbux02:factor_conv_mn 
    where cod_moneda = w_cta_mov_moneda 
    and fecha_dia = mdy(p_nro_periodo,p_nro_dia,p_gestion);
	
	let w_ctp_cp_rfa_default = "N";
	let w_cp_imp = 1;
	let v_nro_renglon = 0;
	let v_cve_dev_real = decode(p_codcmp, 3,"D", "R");
	let x_imp_sigma = 0;
	
	let v_contar = 0;
	
	foreach
	    select prp_montomo, prp_glosa,prp_ctamov, prp_dh,prp_codlit,prp_nrocp,prp_nroafectable
	    into w_prl_monto_mo, v_glosa,v_prp_ctamov,w_rln_dh, v_rln_codlitmnt,v_prp_nrocp,v_prp_nroafectable
	    from gen_prcparams
	    where prp_codprc = p_idtabla
	    and prp_tipoproc = p_codcmp
	    and prp_ctamov is not null
	    and prp_montomo > 0
	    and prp_estado = 2
		order by prp_nroreng
		
		let w_prl_nro_reng_esq = null;
		let w_prl_monto_mn = w_prl_monto_mo * w_prl_factor_conv_mo_mn;
	    
		call contbcb@bcbux02:nro_afect_mayor(v_prp_ctamov, w_cta_mov_moneda, p_centro) returning w_prl_nro_afectable, w_prl_nro_mayor;	

		let v_nro_renglon = v_nro_renglon + 1;

		insert into contbcb@bcbux02:reng_comprob(nro_centro, cve_tipo_comprob, nro_comprob, nro_reng, cve_debe_haber, monto_mo, factor_conv_mo_mn, 
    		glosa_reng, nro_mayor, nro_afectable, nro_reng_esq, monto_mn) 
    	values (p_centro, p_cmp_tipo, p_cmp_nro, v_nro_renglon, w_rln_dh, w_prl_monto_mo, w_prl_factor_conv_mo_mn,
        	v_glosa, w_prl_nro_mayor, w_prl_nro_afectable, w_prl_nro_reng_esq, w_prl_monto_mn);
	    
		if exists (select 1 
				from contbcb@bcbux02:afectable_partida a
				where a.nro_afectable = w_prl_nro_afectable 
				and a.cve_vigente = "V") then
				
			if p_codcmp in (3,4,5,6,7) then
				let v_mnt_imp = 0;					
				if v_cve_dev_real = "R" then
					if w_rln_dh = "H" then
						let v_mnt_imp = w_prl_monto_mn;
					end if
				elif v_cve_dev_real = "D" then
					if w_rln_dh = "D" then
						let v_mnt_imp = w_prl_monto_mn;
					end if
				end if
				
				if v_mnt_imp > 0 then
					let w_cp_renglon = null;
					let w_cp_cta = null;
					
					if v_prp_nrocp is null then
						Raise Exception  -746, 0, "Certificacion presupuestaria con valor invalido en gen_prcparams. renglon: " || v_nro_renglon;
					end if
					let w_delim_pos = INSTR(v_prp_nrocp, '-');
					IF w_delim_pos > 0 THEN
					  	let w_cp_cta = SUBSTR(v_prp_nrocp, 1, w_delim_pos - 1);
					  	let w_cp_renglon = SUBSTR(v_prp_nrocp, w_delim_pos + 1);
					else
						Raise Exception  -746, 0, "Certificacion presupuestaria  no esta parametrizada o formato incorrecto." || v_prp_nrocp;
					END IF;
					
					let v_nro_cp_cmpb = null; 
					let v_nro_reng_cp_cmpb = null;		
	
				    select nro_cp, nro_reng_cp
				    into v_nro_cp_cmpb, v_nro_reng_cp_cmpb
					from contbcb@bcbux02:reng_cp rcp, contbcb@bcbux02:afectable_partida ap
					where rcp.cod_partida = ap.cod_partida
					and ap.nro_afectable = w_prl_nro_afectable
					and ap.cve_vigente = "V"
					and rcp.gestion = p_gestion
					and rcp.nro_cp = w_cp_cta
					and rcp.nro_reng_cp = w_cp_renglon;
					
					IF (dbinfo ("sqlca.sqlerrd2") = 0) then
		          		raise exception -746, 0, "Imp presup sin registro en reng_cp, verifique en afectable partida y reng_cp, afect: " || w_prl_nro_afectable;
					end if
		    
					insert into contbcb@bcbux02:imp_presup(nro_centro, cve_tipo_comprob, nro_comprob, nro_reng, nro_imp, monto_imp_mn, 
							gestion, nro_cp, nro_reng_cp, cve_dev_real, cve_reform_aut)  
					values (p_centro, p_cmp_tipo, p_cmp_nro, v_nro_renglon, w_cp_imp, v_mnt_imp, 
					p_gestion, v_nro_cp_cmpb, v_nro_reng_cp_cmpb, v_cve_dev_real, w_ctp_cp_rfa_default) ;
				end if
			end if
		end if 
		
		-- verificacion afectable sigma
		select count(1)
		into v_contsigma
		from contbcb@bcbux02:afectable_sigma
		where nro_afectable = w_prl_nro_afectable
		and cve_vigente = "V";

		if p_codcmp = 2 and v_contsigma > 0 then
 		   	let x_imp_sigma = x_imp_sigma + 1;
		   	let w_tipo_sigma = "CRV";

           	insert into contbcb@bcbux02:imp_sigma (nro_centro, cve_tipo_comprob, nro_comprob, nro_reng, nro_imp, desc_imp, monto_imp_mo, cve_tipo_sigma, nro_doc_sigma)
			values(p_centro, p_cmp_tipo, p_cmp_nro, v_nro_renglon, x_imp_sigma, null, w_prl_monto_mo, w_tipo_sigma, p_cmp_nro);
		end if
		
		let v_contar = v_contar + 1;
	end foreach
	
	if v_contar <= 1 then
		raise exception -746, 0, "GENRENG: Operacion contable sin renglones suficientes, id: " || p_idtabla || " tipocmp: " || p_codcmp;				
	end if

	update gen_prcparams
	set prp_estado = 3,
	prp_auditusr = p_usuario,
	prp_auditfho = current,
	prp_auditwst = p_estacion
    where prp_codprc = p_idtabla
    and prp_tipoproc = p_codcmp
    and prp_montomo > 0
    and prp_estado = 2;	
	
end procedure;



