


DROP procedure IF EXISTS d_creditos.p_acr_devenga_cred;
create procedure d_creditos.p_acr_devenga_cred(p_codmod integer, p_codcred integer, p_fechaini date, p_fechafin date, tipoproc integer)
--returning integer, date, date
{
wherrera : 20211208 devenga un credito a una fecha, destina a proceso ejecutado en la vista
		20260505 se modifica el procedimiento con validaciones de parametros ingresados desde la vista
tipoproc 2: devenga periodo diario
3: util para act reporte
5: recupera datos de contbcb y actualiza en prcconta
6: recupera datos de contbcb y crea prcconta si no existe(util para gestiones anteriores), restriccion es uno por mes
}
    define v_dias,C_TIPOCUO_INT,C_PRESTATUS_CANC,C_STATACRU_PEND,C_STATACRU_PROC,v_prc_codprc integer;
    define v_fechafin, v_fec_ult_conta, v_ult_fec_acr,v_feciniper,v_acr_fecini,v_prc_fecha,v_prc_fecha_2 date;
    define v_pre_feculttrx, v_fec31ant, v_fin_gestionant, v_min_fecvencuo, v_max_fecvencuo date;
	define v_prc_nro_comprob, v_cuenta_mov, v_nro_afectablecoin varchar(30); 
	define v_fecult_dev_coin,v_ultfec_pp_int, v_fechaini,ST_D_PERIOD, END_D_PERIOD,v_fechacont date;
	define v_min_spect,v_contarprc, v_contcmp, C_UNIDPLAZ_DIARIO,P_SEQ_PERIOD,v_nro_dessembolsos,v_nro_dias integer;
	define v_userpreaut,v_nro_comprob,v_cve_tipo_comprob,v_nro_afectablecoind varchar(15);
	define C_MAX_DIFF_CONT, v_mnt_dev,v_dev_mes, v_total_desemb, v_saldo_cap, v_int_dias,v_diff decimal(20,2);
	define v_glosa lvarchar(500);
	define v_with_venc integer;

	let C_TIPOCUO_INT = 2;
	let C_PRESTATUS_CANC = 9;
    let C_STATACRU_PEND = 1;
    let C_STATACRU_PROC = 2;
	let C_MAX_DIFF_CONT = 3.00;
	
    let p_fechafin = nvl(p_fechafin, date(current));
    let v_fec31ant = mdy(month(p_fechafin),1,year(p_fechafin)) - 1;
	let v_pre_feculttrx = null;
  
	if tipoproc = 2 then
		let p_fechaini = nvl(p_fechaini,p_fechafin);
		let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, tipoproc, p_fechaini, p_fechafin);
    elif tipoproc = 3 then
    	let v_fec_ult_conta = f_acr_ult_fec_acr(p_codcred, p_codmod, NULL, p_fechafin, 1);
    	let v_fec_ult_conta = nvl(v_fec_ult_conta, v_fec31ant);
    	let v_feciniper = nvl(p_fechaini,v_fec_ult_conta);
    	
		update pre_accrual
		set acr_statacru = C_STATACRU_PEND
		where acr_codcred = p_codcred
		and acr_codmod = p_codmod
		and acr_coddsb > 0
		and acr_statacru = C_STATACRU_PROC
		and acr_fecaccru between v_feciniper and p_fechafin
		and acr_fecaccru > v_fec_ult_conta
		and acr_fecaccru > v_fec31ant;
    
		let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, tipoproc, v_feciniper, p_fechafin);
		
	elif tipoproc = 3 then
		let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, 3, p_fechafin, p_fechafin);
	elif tipoproc = 5 then
	-- recuperar datos contables
		select x.par_parametro,
			(select max(nro_afectable) --012510
			from contbcb@bcbux02:cuenta_movimiento cm,contbcb@bcbux02:cuenta_afectable ca 
			where cm.cod_Movimiento = ca.cod_Movimiento 
			and cm.cod_movimiento = x.par_parametro
			and cm.cve_Estado_Cuenta = 'V' 
			and ca.cve_Estado_Cuenta = 'V' 
			and ca.nro_Centro = 1 
			and ca.cod_Moneda = "69") 
		into v_cuenta_mov, v_nro_afectablecoin
		FROM gen_parametro x
		where par_tprcod = 3
		and par_codcred = p_codcred
		and par_codmod = p_codmod;	
	
		foreach 
			select prc_codprc, prc_nro_comprob, prc_fecha,prc_fecha_2
			into v_prc_codprc, v_prc_nro_comprob, v_prc_fecha,v_prc_fecha_2
			from pre_prcconta
			where prc_nro_centro > 0 
			and prc_codcred = p_codcred
			and prc_codmod = p_codmod
			and prc_estado in (1,2,3)
			and length(trim(nvl(prc_nro_comprob,""))) > 2
			and (prc_montodeven = 0 or prc_fecinideven is null)
			and prc_fecha is not null
			order by prc_fecha_2
			
			update pre_accrual
			set acr_statacru = C_STATACRU_PEND
			where acr_codcred = p_codcred
			and acr_codmod = p_codmod
			and acr_coddsb > 0
			--and acr_statacru = C_STATACRU_PROC
			and acr_fecaccru = v_prc_fecha_2;
	    
			let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, 3, v_prc_fecha_2, v_prc_fecha_2);
			
			let v_mnt_dev = 0;
			let v_nro_afectablecoin = nvl(v_nro_afectablecoin,"");
			
			if length(v_nro_afectablecoin) > 0 then
				select sum(r.monto_mn)
				into v_mnt_dev
				from contbcb@bcbux02:comprobante c, contbcb@bcbux02:reng_comprob r 
				where c.nro_comprob = r.nro_comprob 
				and c.nro_centro = r.nro_centro
				and c.cve_tipo_comprob = r.cve_tipo_comprob
				and c.nro_comprob = v_prc_nro_comprob
				and c.nro_centro = 1 
				and c.gestion = year(v_prc_fecha)
				and c.nro_periodo = month(v_prc_fecha)
				and r.nro_afectable = v_nro_afectablecoin
				and c.cve_estado_comprob = "A";
			
				select max(acr_fecini)
				into v_acr_fecini
				from pre_accrual
				where acr_codmod = p_codmod
				and acr_codcred = p_codcred 
				and acr_fecaccru = v_prc_fecha_2
				and acr_tipoacr = 3
				and acr_fecini < p_fechafin;
				
				let v_mnt_dev = nvl(v_mnt_dev,0);
				if v_mnt_dev = 0 then
					select sum(r.monto_mn)
					into v_mnt_dev
					from contbcb@bcbux02:comprobante c, contbcb@bcbux02:reng_comprob r 
					where c.nro_comprob = r.nro_comprob 
					and c.nro_centro = r.nro_centro
					and c.cve_tipo_comprob = r.cve_tipo_comprob
					and c.nro_comprob = v_prc_nro_comprob
					and c.nro_centro = 1 
					and c.gestion = year(v_prc_fecha_2)
					and c.nro_periodo = month(v_prc_fecha_2)
					and r.nro_afectable = v_nro_afectablecoin
					and c.cve_estado_comprob = "A";				
				end if
				if v_mnt_dev > 0 then
					update pre_prcconta
					set prc_montodeven = v_mnt_dev,
					prc_fecinideven = v_acr_fecini,
					prc_hora = current
					where prc_codprc = v_prc_codprc;			
				end if
			
			end if
			
		end foreach
	elif tipoproc = 6 then

		let v_fechaini = mdy(1,1,year(p_fechafin));
		let v_fechafin = mdy(12,31,year(p_fechafin));
		let C_UNIDPLAZ_DIARIO = 6;

		foreach
        	execute procedure f_getperiodos(v_fechaini, v_fechafin, C_UNIDPLAZ_DIARIO, 2, 0, 1) 
            	into P_SEQ_PERIOD,ST_D_PERIOD, END_D_PERIOD
			
            let v_ultfec_pp_int = f_acr_ult_fec_acr(p_codcred, p_codmod, null, END_D_PERIOD-1, 2);
            let v_ultfec_pp_int = nvl(v_ultfec_pp_int,END_D_PERIOD);
            
            let v_min_spect = 1;
            let v_with_venc = 0;
            
			if (v_ultfec_pp_int between ST_D_PERIOD and END_D_PERIOD) and (v_ultfec_pp_int < END_D_PERIOD) then
				let v_min_spect = v_min_spect + 1;
				let v_with_venc = 1;
			else
				let v_ultfec_pp_int = END_D_PERIOD;
			end if
			
			let v_contarprc = 0;
			
			select count(1)
			into v_contarprc
			from pre_prcconta
			where prc_nro_centro > 0 
			and prc_codcred = p_codcred
			and prc_codmod = p_codmod
			and prc_estado in (1,2,3)
			and year(prc_fecha) = year(END_D_PERIOD)  
			and month(prc_fecha) = month(END_D_PERIOD)
			and prc_montodeven > 0 
			and prc_fecinideven is not null
			and length(trim(nvl(prc_nro_comprob,""))) > 2;

			if v_contarprc != v_min_spect then
				-- el registro no existe o no cumple con los requisitos , se precede a la creacion o actualizacion
				if v_with_venc = 1 then
					let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, 2, v_ultfec_pp_int, v_ultfec_pp_int);
				end if
				let v_fecult_dev_coin = ST_D_PERIOD - 1;
				foreach
	        		execute procedure obtiene_interes_devengado(3,p_codcred, p_codmod, END_D_PERIOD, null,null) 
	            		into v_fechacont,v_nro_comprob,v_mnt_dev, v_cve_tipo_comprob,v_nro_afectablecoind,v_glosa

					if v_fechacont is not null and v_mnt_dev > 0 then
	            		let v_diff = 0;
						
						if v_fechacont < END_D_PERIOD and v_fechacont != v_ultfec_pp_int then 
							let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, 2, v_fechacont, v_fechacont);
							let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, 2, END_D_PERIOD, END_D_PERIOD);						
	            		else
							let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, 2, END_D_PERIOD, END_D_PERIOD);	            		
						end if
					
						call p_get_datos_devengamiento(p_codcred, p_codmod, v_fechacont, v_fechacont)
								returning v_ult_fec_acr, v_nro_dessembolsos, v_nro_dias, v_dev_mes, v_total_desemb, v_saldo_cap, v_int_dias;
						
						let v_diff = v_dev_mes - v_mnt_dev;
						let v_prc_fecha_2 = v_fechacont;
						
						if abs(v_diff) > C_MAX_DIFF_CONT then
							if v_with_venc = 1 then
								call p_get_datos_devengamiento(p_codcred, p_codmod, v_ultfec_pp_int, v_ultfec_pp_int)
										returning v_ult_fec_acr, v_nro_dessembolsos, v_nro_dias, v_dev_mes, v_total_desemb, v_saldo_cap, v_int_dias;
								let v_diff = v_dev_mes - v_mnt_dev;
								let v_prc_fecha_2 = v_ultfec_pp_int;
						
								if abs(v_diff) > C_MAX_DIFF_CONT then
									call p_get_datos_devengamiento(p_codcred, p_codmod, END_D_PERIOD, END_D_PERIOD)
											returning v_ult_fec_acr, v_nro_dessembolsos, v_nro_dias, v_dev_mes, v_total_desemb, v_saldo_cap, v_int_dias;
									let v_diff = v_dev_mes - v_mnt_dev;
									let v_prc_fecha_2 = END_D_PERIOD;
								end if
							else
								call p_get_datos_devengamiento(p_codcred, p_codmod, END_D_PERIOD, END_D_PERIOD)
										returning v_ult_fec_acr, v_nro_dessembolsos, v_nro_dias, v_dev_mes, v_total_desemb, v_saldo_cap, v_int_dias;
								let v_diff = v_dev_mes - v_mnt_dev;	
								let v_prc_fecha_2 = END_D_PERIOD;
							end if
						end if
						
						if abs(v_diff) > C_MAX_DIFF_CONT then
						-- ultimo intento comparamos a fecha vencimiento
							let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, 2, v_fechacont-2, v_fechacont+2);
				            let v_ultfec_pp_int = f_acr_ult_fec_acr(p_codcred, p_codmod, null, v_fechacont+2, 2);
				            let v_ultfec_pp_int = nvl(v_ultfec_pp_int,END_D_PERIOD);
						
							if (v_ultfec_pp_int between ST_D_PERIOD and END_D_PERIOD) and (v_ultfec_pp_int <= v_fechacont+2) then
								call p_get_datos_devengamiento(p_codcred, p_codmod, v_ultfec_pp_int, v_ultfec_pp_int)
										returning v_ult_fec_acr, v_nro_dessembolsos, v_nro_dias, v_dev_mes, v_total_desemb, v_saldo_cap, v_int_dias;
								let v_diff = v_dev_mes - v_mnt_dev;	
								let v_prc_fecha_2 = v_ultfec_pp_int;
							end if
						end if
						let v_userpreaut = "SISCRED";			
						if abs(v_diff) > C_MAX_DIFF_CONT then
						-- sino iguala 
							call p_get_datos_devengamiento(p_codcred, p_codmod, v_fechacont, v_fechacont)
										returning v_ult_fec_acr, v_nro_dessembolsos, v_nro_dias, v_dev_mes, v_total_desemb, v_saldo_cap, v_int_dias;
							let v_ult_fec_acr = v_fecult_dev_coin;
							let v_prc_fecha_2 = v_fechacont;
							let v_nro_dias = v_fechacont - v_fecult_dev_coin;
							let v_userpreaut = "SISCRED-DIFF";
							let v_diff = v_dev_mes - v_mnt_dev;
						end if
						
						if (abs(v_diff) < C_MAX_DIFF_CONT) then
							select count(1), max(prc_codprc)
							into v_contcmp, v_prc_codprc
							from pre_prcconta
							where prc_nro_centro = 1 
							and prc_codcred = p_codcred
							and prc_codmod = p_codmod
							and prc_estado in (1,2,3)
							and year(prc_fecha) = year(v_fechacont)  
							and month(prc_fecha) = month(v_fechacont) 
							and prc_nro_comprob = v_nro_comprob; 
							
							if v_contcmp = 1 then
							
								update pre_prcconta
								set prc_montodeven = v_mnt_dev,
								prc_cve_tipo_comprob = v_cve_tipo_comprob,
								prc_fecinideven = v_ult_fec_acr,
								prc_fecha = v_fechacont,
								prc_fecha_2 = v_prc_fecha_2,
								prc_estado = 3, -- autorizamos el registro pos en coin lo esta
								prc_auditusrpreaut = v_userpreaut,
								prc_glosa = v_glosa,
								prc_hora = current
								where prc_codprc = v_prc_codprc;

							else
								select max(prc_codprc) + 1
								into v_prc_codprc
								from pre_prcconta;
								
								INSERT INTO pre_prcconta (prc_codprc,prc_fecha,prc_fecinideven,prc_fecha_2,prc_codcmp,prc_codcred,prc_codmod,prc_montodeven,prc_hora,
									prc_estado,prc_nro_centro,prc_cve_tipo_comprob,prc_nro_comprob,prc_glosa,
									prc_auditusrgen,prc_auditfhogen,prc_auditwstgen,prc_auditusrpreaut) 
								VALUES (v_prc_codprc,v_fechacont,v_ult_fec_acr,v_prc_fecha_2,3,p_codcred,p_codmod,v_mnt_dev,current,
									3,1,v_cve_tipo_comprob,v_nro_comprob,v_glosa,
									'sistem',current,'host',v_userpreaut);								
							end if
						end if						
						-- devengamos nuevamente para actualizar a fecha
						update pre_accrual
						set acr_statacru = C_STATACRU_PEND
						where acr_codcred = p_codcred
						and acr_codmod = p_codmod
						and acr_coddsb > 0
						and acr_fecaccru = v_prc_fecha_2;

						let v_fechafin = f_acr_gencronoycalc(p_codmod, p_codcred, 2, v_prc_fecha_2, v_prc_fecha_2);
						let v_fecult_dev_coin = v_fechacont;

					end if	            		
            	end foreach
			end if
        end foreach
    end if

end procedure;


