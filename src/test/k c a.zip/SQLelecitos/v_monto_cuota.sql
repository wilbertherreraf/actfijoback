

DROP view IF EXISTS d_creditos.v_monto_cuota;
CREATE VIEW d_creditos.v_monto_cuota(acr_codcred,acr_codmod,acr_fecini,acr_fecaccru,acr_fecfin,acr_tipoacr,
dsb_contdsb,dsb_valor,dsb_undsb,
acr_tasavig,acr_diasaccr,acr_interes,acr_valor,acr_valorpend,
acr_capital,acr_saldo,acr_capitalper,acr_interesper,acr_undsb,acr_capitalrec,acr_interesrec) as

	select acr_codcred,acr_codmod,acr_fecini,acr_fecaccru,acr_fecfin,acr_tipoacr,
		(select count(1) from pre_desemb where dsb_codcred = acr_codcred and dsb_codmod = acr_codmod and dsb_fecdsb < acr_fecaccru) dsb_contdsb,	
		(select sum(dsb_valor) from pre_desemb where dsb_codcred = acr_codcred and dsb_codmod = acr_codmod and dsb_fecdsb < acr_fecaccru) dsb_valor,
		(select sum(dsb_undsb) from pre_desemb where dsb_codcred = acr_codcred and dsb_codmod = acr_codmod and dsb_fecdsb < acr_fecaccru) dsb_undsb,	
		acr_tasavig,acr_diasaccr,acr_interes,acr_valor,acr_valorpend,
		acr_capital,acr_saldo,acr_capitalper,acr_interesper,acr_undsb,acr_capitalrec,acr_interesrec
	from (
		select acr_codcred, acr_codmod, acr_fecini,acr_fecaccru, acr_fecfin,acr_tipoacr,
		max(acr_tasavig) acr_tasavig, max(acr_diasaccr) acr_diasaccr,sum(acr_interes) acr_interes, sum(acr_valor) acr_valor, sum(acr_valorpend) acr_valorpend, 
		sum(acr_capital) acr_capital, sum(acr_saldo) acr_saldo, sum(acr_capitalper) acr_capitalper, sum(acr_interesper) acr_interesper, sum(acr_undsb) acr_undsb,
		sum(acr_capitalrec) acr_capitalrec, sum(acr_interesrec) acr_interesrec
		from pre_accrual 
		GROUP BY acr_codcred, acr_codmod, acr_fecini,acr_fecaccru, acr_fecfin,acr_tipoacr
	)
;

