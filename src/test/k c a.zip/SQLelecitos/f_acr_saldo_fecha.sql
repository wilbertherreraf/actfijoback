


drop function if exists d_creditos.f_acr_saldo_fecha;
create function d_creditos.f_acr_saldo_fecha(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_pporpv integer)  
        returning decimal(20,2)
{
wherrera 20260405 modificacion de consulta de saldos programado o efectivizado, el saldo a una fecha es el monto desembolsado menos el recuperado anterior a la fecha evaluada
p_pporpv: 1 de plan pagos 
2/otro de plan de pagos aux
3 saldo efectivizado



}
    define V_MNT_DSB_ANT like pre_planpagos.cuo_valor;
    DEFINE v_saldok,v_cap_recpanti,v_cap_recpendpanti like pre_planpagos.cuo_valor;
    define v_cap_receffect,v_cap_recpend, v_cap_rec,v_sum_dif_valor like pre_planpagos.cuo_valor;
	define C_TIPOCOB_PANTI_CAP,C_TIPOCUO_CAP,C_TIPOCUO_INT integer;

    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
	let C_TIPOCOB_PANTI_CAP = 12;    
	let p_fecha = nvl(p_fecha, mdy(1,1,3000));
	let p_pporpv = nvl(p_pporpv, 1);
		
	if p_pporpv = 3 then
		let v_cap_rec = f_getamtcobroscap(p_codcred, p_codmod, p_coddsb, null, p_fecha-1, null);	
	else

		if p_pporpv = 2 then
		
			call f_pv_sum_portipo(p_codcred, p_codmod, p_coddsb, null, p_fecha-1, C_TIPOCUO_CAP, p_pporpv) returning v_cap_rec,v_cap_recpend;
			call f_pv_sum_portipo(p_codcred, p_codmod, p_coddsb, null, p_fecha-1, C_TIPOCOB_PANTI_CAP, p_pporpv) returning v_cap_recpanti,v_cap_recpendpanti;
						
			let v_cap_rec = v_cap_rec + v_cap_recpanti;	
		else
		
			let v_cap_rec = f_pp_sum_portipo_valor(p_codcred, p_codmod, p_coddsb, null, p_fecha-1, C_TIPOCUO_CAP);
			
		end if
	end if
	
	let V_MNT_DSB_ANT = f_getsumas_dsb(p_codmod, p_codcred, p_coddsb, null, p_fecha-1);
    let v_saldok = V_MNT_DSB_ANT - v_cap_rec;
	
    return nvl(v_saldok, 0);
end function;


