

DROP procedure IF EXISTS d_creditos.p_pp_dsb_cero_upd;
create procedure d_creditos.p_pp_dsb_cero_upd(p_codcred integer, p_codmod integer, p_tipocuo integer, p_fecvencuo date)
{
    wherrera 20260405 actualiza registros para el desembolso cero, resumen del prestamo
    
    
    
    select *	
    from v_planpagos_consol
    where codcred = 6
    and codmod = 17
    order by fechavencuo
    
    call p_pp_dsb_cero_upd(6, 17, 1, null)    
    call p_pp_dsb_cero_actxfecha(1, 17, 1, null);
    call p_pp_dsb_cero_actxfecha(2, 17, 1, null);
    call p_pp_dsb_cero_actxfecha(12, 17, 1, null);
    call p_pp_dsb_cero_actxfecha(13, 17, 1, null);
    call p_pp_dsb_cero_actxfecha(7, 17, 1, null);
    call p_pp_dsb_cero_actxfecha(6, 17, 1, null);
    
    select *
    from pre_planpagos
    where cuo_codcred = 6
    and cuo_coddsb = 0
    order by cuo_fecvencuo;
    
    
}
    define v_cuo_fecvencuo, v_cuo_fecfincuo  like aux_planpagos.acu_fecvencuo    ;
    define v_cuo_valor      like aux_planpagos.acu_valor        ;
    define v_cuo_valorpend  like aux_planpagos.acu_valorpend    ;
    define v_cuo_tipocuo    like aux_planpagos.acu_tipocuo      ;
    define C_CODDSB_CERO,v_cont_zero integer;
    define v_cuo_codcuo, v_cuo_monpag, v_cuo_tipotrx integer;
define v_codmod,v_codcred,v_dias, v_tipotrx  integer;	 
define v_fechaant,v_fechavencuo,v_cap_fecaplic, v_int_fecaplic,v_amortiza_cap date;
define v_saldo_inicio,v_amortizacion,v_amortizacion_saldo,v_interes,v_interes_saldo,v_cuota,v_cuo_cargos like aux_planpagos.acu_valor        ;	
define v_tasa	 like pre_tasaspre.mtp_tbase;
define v_estado_cuota , v_auditusr, v_auditwst varchar(100);
define v_pa_capital,v_pa_interes,v_otros,v_cap_prgpend_aplic,v_cap_effpend_aplic,v_int_effpend_aplic  like aux_planpagos.acu_valor        ;
define v_TRAINTYDAYS,v_TRAINTMDAYS, v_amortiza_int,v_int_prgpend_aplic, v_cuo_diferido integer; 
define C_TIPODSBCERO_SERVDEUDA, C_TIPODSBCERO_CONSOL integer; 

    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    define C_FLAG_EXETRIGGER_PP_NOEXE integer;
    
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;
    let C_CODDSB_CERO = 0;
 	let C_TIPODSBCERO_CONSOL = 1;
    let C_TIPODSBCERO_SERVDEUDA = 2;
    
    let v_auditusr = "ZERO";
    let v_auditwst = "ADM";
   	let v_cuo_cargos = 0;
    if p_tipocuo = C_TIPODSBCERO_CONSOL then
    -- marcamos todos como no procesados
	    update pre_planpagos
	    set cuo_trxstaau = 0
	    where cuo_codmod = p_codmod
	    and cuo_codcred = p_codcred
	    and cuo_coddsb = C_CODDSB_CERO
	    and (cuo_tipoacu = C_TIPODSBCERO_CONSOL or cuo_tipoacu is null);
    
	    foreach 
	    	select codmod, codcred, fechaant, fechavencuo, saldo_inicio, amortizacion, amortizacion_saldo, 
				interes	, interes_saldo	, dias	, tasa	, cuota	, estado_cuota, tipotrx
			into v_codmod,v_codcred,v_fechaant,v_fechavencuo,v_saldo_inicio,v_amortizacion,v_amortizacion_saldo,
			v_interes,v_interes_saldo,v_dias,v_tasa	,v_cuota,v_estado_cuota, v_tipotrx
	    	from v_planpagos_consol 
	    	where codcred = p_codcred
	    	and codmod = p_codmod
	    
	    		let v_cuo_codcuo = null;
	    		
	            select count(*), min(cuo_codcuo),max(cuo_fecfincuo)
	            into v_cont_zero, v_cuo_codcuo, v_int_fecaplic
	            from pre_planpagos
	            where cuo_codmod = p_codmod
	            and cuo_codcred = p_codcred
	            and cuo_coddsb = C_CODDSB_CERO
	            and cuo_fecvencuo = v_fechavencuo
	            and cuo_trxstaau = 0
	            and cuo_tipoacu = C_TIPODSBCERO_CONSOL;
	    		
	            let v_int_fecaplic = nvl(v_int_fecaplic, v_fechavencuo); 
	    		
	            let v_cuo_monpag = 1;
	            if (v_amortizacion_saldo + v_interes_saldo) = 0 then
					let v_cuo_monpag = 2;
				end if;
	            
				let v_cuo_cargos = 0; 	
		        let v_cuo_diferido = decode(v_tipotrx,4,1,v_tipotrx);

	            if v_cont_zero = 0 then
					let G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE;
				    let v_cuo_codcuo = f_pp_getnextid();
				
				    INSERT INTO pre_planpagos (cuo_codcuo, cuo_codcred, cuo_codmod, cuo_fecvencuo, 
				    cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_valor, cuo_desemb, 
				    cuo_valorpend, cuo_coddsb, cuo_tipocuo, cuo_monpag, cuo_tipotrx, cuo_tipoacu,cuo_numtrx,
				    cuo_diferido,cuo_trxstaau, cuo_auditusr, cuo_auditfho, cuo_auditwst) 
				    VALUES (v_cuo_codcuo, v_codcred, v_codmod, v_fechavencuo, 
				    v_fechaant, v_int_fecaplic, v_amortizacion, v_interes, v_interes_saldo, v_cuota, v_saldo_inicio,  
				    v_amortizacion_saldo, C_CODDSB_CERO, 0, v_cuo_monpag, v_tipotrx, C_TIPODSBCERO_CONSOL, v_dias,
				    v_cuo_diferido, 3, v_auditusr, current, v_auditwst);
				    
	            	let G_FLAG_EXETRIGGER_PP = -1;            
	            else
	            	let G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE;
	            	
	                update pre_planpagos
	                set cuo_fecinicuo   = v_fechaant,
	                cuo_fecfincuo   = v_int_fecaplic,
	                cuo_capital     = v_amortizacion,
	                cuo_interes     = v_interes,
	                cuo_cargos      = v_interes_saldo,
	                cuo_valor       = v_cuota       ,
	                cuo_valorpend   = v_amortizacion_saldo   ,
	    			cuo_desemb = v_saldo_inicio,
	                cuo_tipocuo     = 0,
	                cuo_tipotrx = v_tipotrx,
	                cuo_monpag      = v_cuo_monpag,
	    			cuo_numtrx = v_dias,
	    			cuo_diferido = v_cuo_diferido, 
	                cuo_trxstaau    = 3,
	                cuo_auditusr = v_auditusr,
	                cuo_auditwst = v_auditwst,
	                cuo_auditfho = current
	                where cuo_codcred = v_codcred
	                and cuo_codmod = v_codmod
	                and cuo_coddsb = C_CODDSB_CERO
	                and cuo_fecvencuo = v_fechavencuo
	            	and cuo_codcuo= v_cuo_codcuo
	                and cuo_tipoacu = C_TIPODSBCERO_CONSOL;
	            	
					let G_FLAG_EXETRIGGER_PP = -1;            	
	            end if
	    end foreach
		delete from pre_planpagos
	    where cuo_codmod = p_codmod
	    and cuo_codcred = p_codcred
	    and cuo_coddsb = C_CODDSB_CERO
	    and (cuo_tipoacu = C_TIPODSBCERO_CONSOL or cuo_tipoacu is null)
		and cuo_trxstaau = 0;
	end if
end procedure;


