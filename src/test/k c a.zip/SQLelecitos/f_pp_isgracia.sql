

drop function if exists d_creditos.f_pp_isgracia;
create function d_creditos.f_pp_isgracia(p_codcred integer, p_codmod integer, p_coddsb integer, p_fechavencuo date, p_tipocuo integer)
--returning integer, date, date
returning integer
{
wherrera: 2021.12.08 determina si la cuota es amortizable si y solo si no esta en periodo de gracia y la fecha del plan no haya sido diferido    
retorna : 0 no se encuentra
1: esta en periodo de gracia

		select cuo_codcred, cuo_codmod, cuo_coddsb, cuo_valor, cuo_fecvencuo,cuo_fecfincuo,cuo_tipocuo,cuo_tipoacu,
		f_pp_isgracia_borr(cuo_codcred, cuo_codmod, cuo_coddsb, cuo_fecvencuo, cuo_tipocuo) fecapliccuo
		from pre_planpagos
		where cuo_codcred = 13
		--and cuo_coddsb = 13001
		and cuo_coddsb > 0
}
define D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY, v_fecultrepro, v_rds_fecini, v_rds_feciniint date;
define C_TRXSTAAU_AUTORIZADO, C_TIPOREPRO_REPRO, C_TIPOTRX_DIFER, C_TIPOTRX_COB, C_TIPOCUO_CAP, C_TIPOCUO_INT integer;
define v_contar,v_contard, v_isgracia, v_vpp_tipocuo, v_vpp_codcred, v_vpp_codmod, v_vpp_coddsb integer;
define v_vpp_fecfincuo, v_fecaplic, v_fecultventrx, v_fecinicap, v_feciniint, v_fecant date;
define v_rds_feculttrx,v_dsb_min_fecini, v_dsb_min_feciniint,D_INI_PERGRACIA,D_FIN_PERGRACIA   date;
define v_orig varchar(10);

    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2; 
    let C_TIPOTRX_COB = 2;
	let C_TIPOREPRO_REPRO = 1;
    let v_isgracia = 0;
	let v_contard = 0;
    let v_contar = 0;
	--let v_fecant = f_pv_fechainiper(p_codcred, p_codmod, null, p_fechavencuo, p_tipocuo);
    let v_fecant = null;
	let D_INI_PERGRACIA = v_fecant;
	let D_FIN_PERGRACIA = null;
	let C_TRXSTAAU_AUTORIZADO = 3;
	let v_dsb_min_fecini = null;
	let v_dsb_min_feciniint = null;
		let v_rds_feculttrx = null;
		let v_rds_fecini = null;
		let v_rds_feciniint = null;
	let v_fecaplic = null;
    
	foreach
		select codmod, codcred, INI_PERGRACIA, FIN_PERGRACIA, tipocuo
		into v_vpp_codmod, v_vpp_codcred, D_INI_PERGRACIA, D_FIN_PERGRACIA, v_vpp_tipocuo
		from (
			select dsb_codmod codmod, dsb_codcred codcred, dsb_fecdsb INI_PERGRACIA,  
			(case 
			 when dsb_fecini = dsb_fecdsb then 
				(select min(cuo_fecvencuo) from pre_planpagos 
				where cuo_coddsb = dsb_coddsb 
				and cuo_tipocuo = C_TIPOCUO_CAP 
				and cuo_codcred = dsb_codcred
				and cuo_codmod = dsb_codmod
				)
			else 
				dsb_fecini
			end) FIN_PERGRACIA, 
			C_TIPOCUO_CAP tipocuo 
			from pre_desemb   
			where dsb_codmod = p_codmod 
			and dsb_codcred = p_codcred
			and dsb_coddsb = nvl(p_coddsb, dsb_coddsb)
			and dsb_fecdsb < p_fechavencuo
			and dsb_coddsb > 0
			
			union
			
			select dsb_codmod , dsb_codcred, dsb_fecdsb, 
			case 
			 when dsb_feciniint = dsb_fecdsb then 
				(select min(cuo_fecvencuo) from pre_planpagos 
				where cuo_coddsb = dsb_coddsb 
				and cuo_tipocuo = C_TIPOCUO_INT 
				and cuo_codcred = dsb_codcred
				and cuo_codmod = dsb_codmod
				)
			else dsb_feciniint
			end, 
			C_TIPOCUO_INT
			from pre_desemb
			where dsb_codmod = p_codmod 
			and dsb_codcred = p_codcred
			and dsb_coddsb = nvl(p_coddsb, dsb_coddsb)
			and dsb_fecdsb < p_fechavencuo
			
			union
			
			select rds_codmod , rds_codcred, rds_feculttrx, rds_fecini, C_TIPOCUO_CAP 
			from pre_reprograma
			where rds_codmod = p_codmod 
			and rds_codcred = p_codcred
			and rds_tiporepro = C_TIPOREPRO_REPRO
			and rds_feciniint is not null
			and rds_fecini is not null
			and rds_trxstaau = C_TRXSTAAU_AUTORIZADO 
			and rds_fecini > p_fechavencuo
			
			union
			
			select rds_codmod , rds_codcred, rds_feculttrx, rds_feciniint , C_TIPOCUO_INT
			from pre_reprograma
			where rds_codmod = p_codmod 
			and rds_codcred = p_codcred 
			and rds_tiporepro = C_TIPOREPRO_REPRO
			and rds_trxstaau = C_TRXSTAAU_AUTORIZADO
			and rds_feciniint is not null
			and rds_fecini is not null
			and rds_feciniint > p_fechavencuo
		)
		where INI_PERGRACIA < p_fechavencuo
		and FIN_PERGRACIA > p_fechavencuo
		and tipocuo = p_tipocuo
		
		let v_isgracia = 0;
		let v_fecaplic = null;	
		if p_fechavencuo between D_INI_PERGRACIA and D_FIN_PERGRACIA and p_fechavencuo > D_INI_PERGRACIA and p_fechavencuo < D_FIN_PERGRACIA then
			let v_fecaplic = D_FIN_PERGRACIA;
			let v_isgracia = 1;
			exit foreach;
	
		end if
			--return v_isgracia, D_INI_PERGRACIA, D_FIN_PERGRACIA with resume;		
	end foreach
	
	if v_isgracia = 0 then
		if p_coddsb is not null then
			select count(1), min(cuo_fecfincuo)
			into v_contar, v_fecaplic 
			from pre_planpagos
			where cuo_tipocuo = p_tipocuo
			and cuo_codcred = p_codcred
			and cuo_codmod = p_codmod
			and cuo_coddsb = p_coddsb
			and cuo_fecvencuo < cuo_fecfincuo
			and cuo_fecfincuo is not null
			and cuo_fecvencuo = p_fechavencuo
			and cuo_fecfincuo > p_fechavencuo;
		else
			select count(1), min(cuo_fecfincuo)
			into v_contar, v_fecaplic
			from pre_planpagos
			where cuo_tipocuo = p_tipocuo
			and cuo_codcred = p_codcred
			and cuo_codmod = p_codmod
			and cuo_coddsb > 0
			and cuo_fecvencuo < cuo_fecfincuo
			and cuo_fecfincuo is not null
			and cuo_fecvencuo = p_fechavencuo
			and cuo_fecfincuo > p_fechavencuo;			
		end if
--return v_isgracia, p_fechavencuo, v_fecaplic with resume;
		IF v_contar > 0 then
			let v_isgracia = 1; 
		end if		
	end if
   
    return nvl(v_fecaplic, 0);
end function;




		