

drop procedure if exists d_creditos.p_rpro_panti_metosaldodsb;
create procedure d_creditos.p_rpro_panti_metosaldodsb(p_codcred integer, p_codmod integer, 
p_codrepro integer, p_fecha date, p_fechaoper date, p_importe decimal(20,2), p_coduser varchar(100), P_ESTACION VARCHAR(100), p_tipo_pago CHAR(10))

{
    wherrera 2021.11.01 divide el saldo captial del pago anticipado entre el numero de cuotas restantes
	prorratea el importe entre los saldos cap de cada dsb 
	agrega C/I por dsb al cronograma
	prorrateo en cada dsb 
	actualiza montos de cronograma 

-- PARAMETROS SALIDA:  No devuelve ningun valor como resultado
-- AUTOR: wherrera
-- CREACION: 2021.11.01

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| wherrera  |  2021.11.01   |          | divide el saldo captial del pago anticipado entre el numero de cuotas restantes prorratea el importe entre los saldos cap de cada dsb agrega C/I por dsb al cronograma prorrateo en cada dsb actualiza montos de cronograma
----------------------------------------------------------------------------
--| acanqui   |  06-05-2024   | 1763004  | Adicióe opcion para realizar pagos con DISTRIBUCION LINEAL DE CUOTAS (DLC) O CONTRA LA SIGUIENTE CUOTA (CSC) SOLAMENTE PARA EL FNDR.
----------------------------------------------------------------------------
--| acanqui   |  31-12-2024   | 2300070  | Ajuste para obtener el saldo del pago anticipado de un pago anterior y sumarlo al interes actual (el ajuste solo se aplica cuando el saldo restante es mayor a cero).
----------------------------------------------------------------------------
--| wherrera |  01-04-2026   | 2763221  | En atención a la Comunicación Interna BCB-GSIS-SSI-CI-2026-22 mediante la cual se requiere generar un nuevo SDAPO referido al funcionamiento del Pago Anticipado, se corrije el algoritmo	
----------------------------------------------------------------------------
}


define v_contar, v_acu_codacu  integer;
define v_int_importe, v_cap_importe like pre_desemb.dsb_valor;
define v_diff_importe, v_ctrl_cap_pp , v_amt_sum_fec_int like pre_desemb.dsb_valor;
define v_int_periodo, v_sum_cuo_valor, v_sum_cuo_valorpend, v_controlsuma , v_importe_int, v_sum_pp_cap like pre_desemb.dsb_valor;
define v_fec_ini_rpro, V_D_FECINIPER, V_D_FECFINPER,v_dsb_fecdsb,v_fecsigvcto,v_feciniper,v_acu_fecvencuo date;
define v_cap_resto, v_int_restper,v_int_restper2,v_sum_desembolso, v_int_cobro,v_panti  like pre_planpagos.cuo_valor;
define v_amtacru, v_siap, v_sum_importe, v_importe_cap, v_cap_pp_prorra, v_siap_pp like pre_planpagos.cuo_valor;
define v_saldo_dev, v_sum_cap_valor, v_sum_cap_valorpend, v_int_adeuda, V_MNT_PRG, V_MNT_PRGPEND, v_sumdiff,v_acu_valor, v_acu_valorpend,v_int_dev like pre_planpagos.cuo_valor;

define v_fecha_ini_per, v_fecsigper, v_cuo_fecvencuo date;
define C_TIPOTRX_PANTI, C_TIPOCUO_CAP, C_TIPOCUO_INT, C_TIPOCOB_PANTI_CAP, C_TIPOCOB_PANTI_INT INTEGER;
define v_acu_tipocuo,v_codacu,v_contdesem, v_cuo_coddsb, v_cont , v_dsb_coddsb, v_cuo_codcuo, v_cuo_tipocuo, v_cuo_codcuoint integer; 
DEFINE C_TIPOTRX_DEVENG, C_TIPOCUO_DEVENG_INT, C_TIPOCOB_COB, C_TIPOPRORRA_AMORTIGUAL, C_TIPOPRORRA_SIAP, C_TIPOPRORRA_VALPEND INTEGER;
define v_app_t, v_appint_t, v_appaux_t aux_planpagos_t; 

define v_isgracia, v_dias, v_dsb_coddsb_int , v_aux_codacu,D_DIFFERENCE_IN_DAYS INTEGER;
define v_tasabase like pre_tasaspre.mtp_tbase;

let C_TIPOCUO_CAP = 1;
let C_TIPOCUO_INT = 2;
LET C_TIPOTRX_PANTI = 3;
LET C_TIPOTRX_DEVENG = 8;
LET C_TIPOCOB_PANTI_CAP = 12; 
LET C_TIPOCOB_PANTI_INT = 22;
let C_TIPOPRORRA_AMORTIGUAL = 3;
let C_TIPOPRORRA_SIAP = 2;
let C_TIPOPRORRA_VALPEND = 1;
let C_TIPOCOB_COB = 2;
let C_TIPOCUO_DEVENG_INT = 28;
let v_cont = 0;

let v_controlsuma = 0;
let v_sum_cuo_valor = 0;
let v_sum_pp_cap = 0;
let v_contar = 0;
let v_int_adeuda = 0;
    let v_cont = 0;
   
	let v_app_t = f_init_app_t();
	let v_app_t.acu_tipodsb = p_codrepro;
	let v_app_t.acu_codmod = p_codmod;
	let v_app_t.acu_codmodorig = p_codmod;
	let v_app_t.acu_codcred = p_codcred;
	let v_app_t.acu_cargos = 0;
	let v_app_t.acu_capital = 0;
	let v_app_t.acu_interes = 0;
	let v_app_t.acu_trxstaau = 1;
	let v_app_t.acu_monpag = 1;
	let v_app_t.acu_fecvencuo = p_fecha;
	let v_app_t.acu_fecfincuo = p_fecha;
	let v_app_t.acu_auditusr = p_coduser;
	let v_app_t.acu_auditwst = p_estacion;
	--let v_app_t.acu_tabtipodsb = C_TIPOTRX_PANTI;

	let v_contar = 0; 
	let v_fec_ini_rpro = f_pp_fechainiper(p_codcred, p_codmod, null, p_fecha, C_TIPOCUO_INT);
	foreach
		execute procedure f_dsb_prorrateo(p_codcred, p_codmod, p_fecha, p_importe)
	    	into v_dsb_coddsb, v_fecha_ini_per, v_dias, v_tasabase, v_cap_importe, v_siap, v_amtacru, v_int_dev,v_int_periodo, v_int_importe

		-- INSERTAMOS EL INTERES DEL PANTI
	    	let v_feciniper = f_pv_fechainiper(p_codcred, p_codmod, v_dsb_coddsb, p_fecha, C_TIPOCUO_INT);
			let v_sum_pp_cap = v_cap_importe + v_int_importe;
	
			if v_int_importe > 0 then				
				--REGISTRO DE PAGO ANTICIPADO
				let v_app_t.acu_fecinicuo = v_fecha_ini_per;
				let v_app_t.acu_fecfincuo = p_fecha;
	    		let v_app_t.acu_coddsb = v_dsb_coddsb;
				let v_app_t.acu_tasa = v_tasabase;
				let v_app_t.acu_cargos = v_int_periodo - v_int_dev;	-- saldo int		
				let v_app_t.acu_capital = v_siap;
				let v_app_t.acu_interes = v_int_dev; -- interes desde el ultimo pa o venc   	
				let v_app_t.acu_valor = v_int_importe;	-- prorrateado
				let v_app_t.acu_valorpend = v_int_importe;
				let v_app_t.acu_tipocuo = C_TIPOCOB_PANTI_INT;
				let v_app_t.acu_tipoacu = C_TIPOCOB_PANTI_INT; 
				let v_app_t.acu_tipotrx = C_TIPOTRX_PANTI;
				let v_app_t.acu_auditfho = current;
			
				let v_codacu = p_insauxplanpg(v_app_t);
			end if
-- insertamos un registro de interes a fecha de cobro
			if v_cap_importe > 0 then
				-- SI EL IMPORTE ES MAYOR AL INTERES A LA FECHA SE INSERTA UNA CUOTA EN EL PLAN DE INTERES Y AMORTIZA A CAPITAL SEGUN EL TIPO DE PAGO
			--prorrateado mayor al calculado
			-- SE REGISTRA EL PANTI DE CAPITAL
				let v_app_t.acu_fecinicuo = v_fecha_ini_per;
				let v_app_t.acu_fecfincuo = p_fecha;				
            	let v_app_t.acu_coddsb = v_dsb_coddsb;
				let v_app_t.acu_cargos = 0;			
				let v_app_t.acu_capital = 0;
				let v_app_t.acu_interes = 0;    	
				let v_app_t.acu_valor = v_cap_importe;        		
				let v_app_t.acu_valorpend = v_cap_importe;					
    			let v_app_t.acu_tipoacu = C_TIPOCOB_PANTI_CAP;   				 
   				let v_app_t.acu_tipocuo = C_TIPOCOB_PANTI_CAP;
				let v_app_t.acu_tipotrx = C_TIPOTRX_PANTI;
				let v_app_t.acu_auditfho = current;
				
				let v_codacu = p_insauxplanpg(v_app_t);

				call p_rpro_adj_crono(p_codcred, p_codmod, v_dsb_coddsb , p_codrepro ,v_cap_importe, p_fecha, p_coduser, p_estacion, p_tipo_pago);
			end if -- v_cap_importe > 0
			
			if v_int_importe + v_cap_importe > 0 then
		        -- ACTUALIZAMOS LOS INTERESES YA QUE LOS SALDOS SE MODIFICARON
		    	foreach
		            select acu_codacu, acu_valor, acu_valorpend, acu_fecvencuo, acu_tipocuo
		            into v_cuo_codcuo, v_acu_valor, v_acu_valorpend, v_cuo_fecvencuo, v_acu_tipocuo
			        from aux_planpagos
			        where acu_codmod = p_codmod
			        and acu_codcred = p_codcred
			        and acu_tipocuo in (C_TIPOCUO_INT)
			        and acu_coddsb = v_dsb_coddsb
			        and acu_coddsb > 0
			        AND acu_fecvencuo > p_fecha
			        and acu_tipodsb > 0
		            order by acu_fecvencuo
					-- 1 si solo es actualizacion de int => se reduce el valorpend desde inicio de periodo, 
					-- 2 modifica capital capital >= recalculo de iteres, la fecha es desde el ult fecha de aporte de capitla
	
				    let v_siap = 0;
			    
					if v_cap_importe <= 0 then
						let v_fec_ini_rpro = f_pv_fechainiper(p_codcred, p_codmod, v_dsb_coddsb, v_cuo_fecvencuo, C_TIPOCUO_INT);
					
						CALL f_getinteres_dsb(p_codcred, p_codmod, v_dsb_coddsb, v_fec_ini_rpro, v_cuo_fecvencuo, v_cuo_fecvencuo, 2) 
            				returning V_D_FECINIPER, V_D_FECFINPER, D_DIFFERENCE_IN_DAYS, v_tasabase, v_siap, v_saldo_dev, v_int_dev, v_int_periodo;
						
						let v_sum_cap_valor = 0;
						
						update aux_planpagos
						set acu_valor = v_int_dev + v_saldo_dev,  
						acu_valorpend = v_int_dev + v_saldo_dev,
						acu_montocuo = 0,
						acu_interes = v_int_dev, 
						acu_cargos = v_saldo_dev,	-- saldo int
						acu_fecinicuo = V_D_FECINIPER,
						acu_monpag = 1,
						acu_tipodsb = p_codrepro,
						acu_trxstaau = 1
						WHERE acu_codcred = p_codcred
						and acu_codmod = p_codmod
						and acu_coddsb = v_dsb_coddsb
			    		and acu_codacu = v_cuo_codcuo;
						
						exit foreach;
					else 

						select MAX(vpp_fecvencuo) 
					    into v_fec_ini_rpro
					    from v_pp_auxyplanpagos
					    where vpp_codmod = p_codmod
					    and vpp_codcred = p_codcred
					    and vpp_fecvencuo < v_cuo_fecvencuo
					    and vpp_tipocuo in (C_TIPOCUO_INT,C_TIPOCOB_PANTI_INT)
					    and vpp_coddsb = v_dsb_coddsb
					    and vpp_valor > 0
					    and vpp_coddsb > 0;
						
						CALL f_getinteres_dsb(p_codcred, p_codmod, v_dsb_coddsb, v_fec_ini_rpro, v_cuo_fecvencuo, v_cuo_fecvencuo, 2) 
            				returning V_D_FECINIPER, V_D_FECFINPER, D_DIFFERENCE_IN_DAYS, v_tasabase, v_siap, v_saldo_dev, v_int_dev, v_int_periodo;
						
						update aux_planpagos
						set acu_valor = v_int_periodo,
						acu_valorpend = v_int_periodo,
						acu_montocuo = 0,
						acu_interes = v_int_dev,
						acu_cargos = v_saldo_dev,
						acu_capital = v_siap,
						acu_fecinicuo = V_D_FECINIPER,
						acu_tipotrx = nvl(acu_tipotrx,C_TIPOCOB_COB),
						acu_tipoacu = nvl(acu_tipoacu,C_TIPOCUO_INT),
						acu_auditusr = p_coduser,
						acu_monpag = 1,
						acu_tipodsb = p_codrepro,
						acu_trxstaau = 1
						WHERE acu_codcred = p_codcred
						and acu_codmod = p_codmod
						and acu_coddsb = v_dsb_coddsb
			    		and acu_codacu = v_cuo_codcuo;

					end if
		    	end foreach			
			end if	    	
	end foreach

end procedure;


