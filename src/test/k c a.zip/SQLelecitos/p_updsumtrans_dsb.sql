

drop procedure if exists d_creditos.p_updsumtrans_dsb;
create procedure d_creditos.p_updsumtrans_dsb(p_codcred integer, p_codmod integer, p_coddsb integer, p_fechatrx date)

{
wherrera 20260505 se actualiza los valores del desembolso se adiciona informacion de devengados
}
    define v_dsb_saldo, v_dsb_undsb, v_dsb_valor, v_capitalfecha, v_incl_cap_amt like pre_cobros.cob_valor;
    define v_mnt_dsb, v_mnt_cobros, v_saldok like pre_cobros.cob_valor;
    define v_sum_dsb, v_sum_dsb_cobros, v_mtn_undsb, v_mtn_saldo_dsb like pre_cobros.cob_valor;
    define v_sum_cuo_valor, v_sum_cuo_valorpend,v_sum_panti, v_sum_pantipend, v_sum_tot_pend, v_dsb_valordeven like pre_cobros.cob_valor;
    define v_dsb_coddsb,v_difflastupd integer;
    define v_min_fecvencuo, v_max_fecvencuo, v_feculttrx, D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY date;
    define v_min_fecfincuo, v_dsb_fecdsb, v_dsb_fecplzven,v_dsb_feculttrx,v_dsb_fecini,v_dsb_feciniint date;
    define C_CODTAB_CAPINT,v_dsb_monpag integer;
    define C_TIPOTRAN_DSB, C_TIPOTRAN_COB integer;
    define C_TIPOCUO_CAP, C_TIPOCUO_PANTI_CAP, C_TIPOCUO_INT, C_TIPOCUO_PANTI_INT integer;
    
	DEFINE GLOBAL G_FLAG_EXETRIGGER_PRE INT DEFAULT -1;
	DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
	DEFINE C_FLAG_EXETRIGGER_PRE_NOEXE INTEGER;
	DEFINE v_dsb_tipodsb INTEGER;
	define v_dsb_auditfho like pre_desemb.dsb_auditfho;
	
    let C_TIPOTRAN_COB = 2;
    LET C_TIPOTRAN_DSB = 1;
    let C_CODTAB_CAPINT = 1720;
    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
	let C_TIPOCUO_PANTI_CAP = 12;
    let C_TIPOCUO_PANTI_INT = 22;
    LET C_FLAG_EXETRIGGER_PRE_NOEXE = 1;    
    LET v_dsb_tipodsb = 1; -- dsb solicitado
    let v_feculttrx = null;
    let v_saldok = 0;
	let v_dsb_valor = 0;
	let v_sum_cuo_valor = 0;
	let v_sum_cuo_valorpend = 0;
	let v_mnt_dsb = 0;
	let v_mnt_cobros = 0;
	let v_max_fecvencuo = null;
	let v_dsb_valordeven = 0;
	
    if p_coddsb is not null and p_coddsb > 0 then
    	select dsb_tipodsb,dsb_feculttrx, dsb_fecdsb,nvl(dsb_undsb,0), nvl(dsb_valor,0), nvl(dsb_saldo,0),
		dsb_fecplzven,dsb_auditfho,dsb_fecini,dsb_feciniint, dsb_monpag,dsb_valordeven    	
		into v_dsb_tipodsb,v_dsb_feculttrx,v_dsb_fecdsb,v_mnt_dsb, v_dsb_valor, v_mnt_cobros,
		v_dsb_fecplzven,v_dsb_auditfho,v_dsb_fecini,v_dsb_feciniint,v_dsb_monpag,v_dsb_valordeven
		from pre_desemb
		where dsb_coddsb = p_coddsb
    	and dsb_codcred = p_codcred
    	and dsb_codmod = p_codmod;
		
    	IF (dbinfo ("sqlca.sqlerrd2") = 0) THEN
        	return;
    	end if

		if v_dsb_auditfho is not null then
			let v_difflastupd = (CURRENT - v_dsb_auditfho)::INTERVAL SECOND(9) TO SECOND::VARCHAR(10)::INTEGER;
    		if v_dsb_tipodsb > 0 and v_difflastupd <= 8 and v_difflastupd > 0 and p_fechatrx is null then
    			-- la ultima actualizacion fue reciente
    			return;
    		end if
    		
		end if
		
		let v_dsb_tipodsb = nvl(v_dsb_tipodsb,1);
		let v_dsb_feculttrx = nvl(v_dsb_feculttrx, v_dsb_fecdsb);
		let v_dsb_auditfho = nvl(v_dsb_auditfho, current);
		let v_dsb_monpag = nvl(v_dsb_monpag, 1);
        let v_dsb_valordeven = nvl(v_dsb_valordeven, 0);
		
		let v_mnt_dsb = nvl(v_mnt_dsb, 0);
		if v_mnt_dsb <= 0 or v_mnt_dsb != v_dsb_valor then
    		let v_mnt_dsb = f_getamtdsb(p_codcred, p_codmod,p_coddsb, null, null);
		end if
		if v_mnt_dsb <= 0 then
			let v_dsb_tipodsb = 1;
		end if
        -- ultimo devengamiento contable
        let v_dsb_fecplzven = f_acr_ult_fec_acr(p_codcred, p_codmod, p_coddsb, last_day(date(current)), 1);
		let v_dsb_fecplzven = nvl(v_dsb_fecplzven, v_dsb_fecdsb);
		-- ultima actividad
		let v_feculttrx = f_acr_ult_fec_acr(p_codcred, p_codmod, p_coddsb, date(current), 3);
		
		if v_dsb_monpag != 2 then
			-- hubo cambio
			
		else
			if v_dsb_feculttrx = v_feculttrx and v_dsb_monpag = 2 then
				if v_dsb_tipodsb = 3 then
				-- cancelado
					return ;
				end if
			end if
		end if
		
    	let v_mnt_cobros = f_getamtcobroscap(p_codcred, p_codmod, p_coddsb, null, null, C_TIPOCUO_CAP);
		
		CALL f_pp_sum_portipo(p_codcred, p_codmod, p_coddsb, null, null, C_TIPOCUO_INT) returning v_sum_cuo_valor, v_sum_cuo_valorpend;
		CALL f_pp_sum_portipo(p_codcred, p_codmod, p_coddsb, null, null, C_TIPOCUO_PANTI_INT) returning v_sum_panti, v_sum_pantipend;
		let v_sum_cuo_valor = v_sum_cuo_valor + v_sum_panti;
		let v_sum_cuo_valorpend = v_sum_cuo_valorpend + v_sum_pantipend;
		
		--saldo en pp
		let v_sum_tot_pend = v_sum_cuo_valor - (v_sum_cuo_valor - v_sum_cuo_valorpend);
        if v_mnt_dsb > 0 or (v_sum_cuo_valor - v_sum_cuo_valorpend != 0) then
            let v_dsb_tipodsb = 2; -- vigente
        end if		
		CALL f_pp_sum_portipo(p_codcred, p_codmod, p_coddsb, null, null, C_TIPOCUO_CAP) returning v_sum_cuo_valor, v_sum_cuo_valorpend;
		CALL f_pp_sum_portipo(p_codcred, p_codmod, p_coddsb, null, null, C_TIPOCUO_PANTI_CAP) returning v_sum_panti, v_sum_pantipend;
		let v_sum_cuo_valor = v_sum_cuo_valor + v_sum_panti;
		let v_sum_cuo_valorpend = v_sum_cuo_valorpend + v_sum_pantipend;
		
		let v_saldok = v_sum_cuo_valor - v_sum_cuo_valorpend;
		
		let v_sum_cuo_valorpend = v_sum_cuo_valorpend + v_sum_pantipend;		
        IF (v_dsb_valor > 0 and v_saldok <= 0 and v_mnt_dsb > 0 and v_mnt_cobros > 0 and v_sum_cuo_valor > 0) 
        	or (v_dsb_valor > 0 and v_sum_tot_pend <= 0 and v_sum_cuo_valor > 0 and v_mnt_cobros > 0) then
       		
        	CALL f_pp_sum_portipo(p_codcred, p_codmod, p_coddsb, null, null, C_TIPOCUO_INT) returning v_sum_cuo_valor, v_sum_cuo_valorpend;
        	if v_sum_cuo_valor > 0 and v_sum_cuo_valorpend = 0 then
            	let v_dsb_tipodsb = 3; -- CERRADO        		
        	end if
        END if
        let v_dsb_auditfho = current;
        LET G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PRE_NOEXE;
        
        update pre_desemb 
        set dsb_undsb = v_mnt_dsb,
        dsb_saldo = v_mnt_cobros,
        dsb_tipodsb = v_dsb_tipodsb,
        dsb_feculttrx = v_feculttrx,
        dsb_fecplzven = v_dsb_fecplzven, -- fecha de ult devengado aprob
        dsb_valorcuo = v_sum_cuo_valor - v_sum_cuo_valorpend, --cobrado en pp
        dsb_auditfho = v_dsb_auditfho
        --dsb_valordeven = v_dsb_valordeven
        WHERE dsb_coddsb = p_coddsb;
        
        LET G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PRE_NOEXE;
    end if
end procedure;


