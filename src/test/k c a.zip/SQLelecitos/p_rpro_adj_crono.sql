

drop procedure if exists d_creditos.p_rpro_adj_crono;
create procedure d_creditos.p_rpro_adj_crono(p_codcred integer, p_codmod integer, p_coddsb integer, p_codrepro integer, p_importecap decimal(20,2), p_fecha date, p_coduser varchar(100), p_estacion varchar(100), p_tipo_pago char(10))
{
    wherrera 2021.11.05 recalcula intereses de un plan a partir de un afecha
	  
-- PARAMETROS SALIDA:  No devuelve ningun valor como resultado
-- AUTOR: wherrera
-- CREACION: 2021.11.01

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| wherrera  |  2021.11.05   |          | recalcula intereses de un plan a partir de un afecha
----------------------------------------------------------------------------
--| acanqui   |  06-05-2024   | 1763004  | Adició opcion para realizar pagos con DISTRIBUCION LINEAL DE CUOTAS (DLC) O CONTRA LA SIGUIENTE CUOTA (CSC) SOLAMENTE PARA EL FNDR.
----------------------------------------------------------------------------
--| wherera |  06-04-2025   | | Reformulacion de la funcion al generar registros de capitales y actualizando intereses requiere coddsb    
----------------------------------------------------------------------------
}

	define v_sum_int, v_cap_resto, v_int_restper, v_mnt_capper, v_mnt_cap_prorrateado like pre_planpagos.cuo_valor;
	define v_amtdiveq like pre_planpagos.cuo_valor;
	define v_acu_codacu LIKE pre_planpagos.cuo_codcuo;
    define v_amtacru, v_siap,v_acu_valor, v_acu_valorpend, v_sum_importe like pre_planpagos.cuo_valor;
    define V_MNT_PRG, V_MNT_PRGPEND, v_sumdiff, v_cuo_capital, v_dsb_valor like pre_planpagos.cuo_valor;
    define v_fecha_ini_per, v_fecsigper, v_cuo_fecvencuo, v_dsb_fecdsb, v_acu_fecvencuo, v_feciniper date;
    define v_codacu, C_TIPOCUO_CAP, C_TIPOCUO_INT, C_TIPOCOB_PANTI_CAP, C_TIPOCOB_PANTI_INT INTEGER;
    define v_first, v_cuo_coddsb, v_cont , v_cuo_codcuo, v_cuo_tipocuo, v_cuo_codcuoint, v_countfecvencuo, v_amt_sum_int integer; 
    DEFINE C_TIPOCOB_COB, C_TIPOTRX_PANTI, C_TIPOPRORRA_AMORTIGUAL, C_TIPOPRORRA_SIAP, C_TIPOPRORRA_VALPEND, v_aux_codacu INTEGER;
    define v_app_t, v_appint_t, v_appaux_t aux_planpagos_t;  
	define v_sum_cap_valor, v_sum_cap_valorpend, v_restp_cap_valor, v_restp_int_valor,v_siap_pp, v_cap_pp_prorra like pre_planpagos.cuo_valor;
	define V_MNT_DSB_ANT, v_sum_int_valor, v_scap_pa_valor, v_sint_pa_valor, v_interes_new like pre_planpagos.cuo_valor;   
    define TIPO_PAGO_CSC CHAR(10);
 	define V_D_FECINIPER, V_D_FECFINPER date;
 	define v_isgracia, v_dias,v_contar integer;
	define v_tasabase like pre_tasaspre.mtp_tbase;
 
	LET C_TIPOCOB_COB = 2;	
    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
    let C_TIPOTRX_PANTI = 3; 
    LET C_TIPOCOB_PANTI_CAP = 12;
    LET C_TIPOCOB_PANTI_INT = 22;
    let C_TIPOPRORRA_AMORTIGUAL = 3;
    let C_TIPOPRORRA_SIAP = 2;
    let C_TIPOPRORRA_VALPEND = 1;
   -- PARAMETRO PARA QUE EL PAGO DEL ANTICIPO SOLO AFECTE A LA SIGUIETE CUOTA
    let TIPO_PAGO_CSC='CSC';
    -- para uso de reportes el capital en la fecha que se mostrara 
	let v_mnt_capper = p_importecap;
    if p_importecap > 0 then
		if p_tipo_pago = "CSC" then
        -- SE ACTUALIZA LA SIGUIENTE CUOTA DE K EN EL PP
        	let v_fecsigper = f_pv_fec_sigper(p_codcred, p_codmod, p_coddsb, p_fecha, C_TIPOCUO_CAP);
        	let v_cuo_fecvencuo = v_fecsigper;
		    let v_sum_cap_valorpend = p_importecap;
			foreach
	            select acu_codacu, acu_valor, acu_valorpend, acu_fecvencuo
	            into v_cuo_codcuo, v_acu_valor, v_acu_valorpend, v_cuo_fecvencuo
		        from aux_planpagos
		        where acu_codmod = p_codmod
		        and acu_codcred = p_codcred
		        and acu_tipocuo = C_TIPOCUO_CAP
		        and acu_coddsb = p_coddsb
		        and acu_coddsb > 0
		        AND acu_fecvencuo >= v_fecsigper
	            order by acu_fecvencuo
	            
	            let v_sum_cap_valor = v_acu_valor - v_sum_cap_valorpend;

	            if v_sum_cap_valor <= 0 then
	            	let v_sum_cap_valor = 0;
	            end if
	            
				update aux_planpagos
				set acu_valor = v_sum_cap_valor,
				acu_valorpend = v_sum_cap_valor,
				acu_cargos = v_mnt_capper, 
				acu_montocuo = nvl(acu_montocuo,0) + p_importecap,
				acu_fecinicuo = p_fecha,
				acu_fecfincuo = acu_fecvencuo,
				acu_tipotrx = nvl(acu_tipotrx,C_TIPOCOB_COB),
				acu_tipoacu = nvl(acu_tipoacu,C_TIPOCUO_CAP),
				acu_auditusr = p_coduser,
				acu_monpag = 1,
				acu_tipodsb = p_codrepro,
				acu_trxstaau = 1
				WHERE acu_codcred = p_codcred
				and acu_codmod = p_codmod
				and acu_codacu = v_cuo_codcuo
        		and acu_tipocuo = C_TIPOCUO_CAP;
				
				let v_mnt_capper = 0;
				let v_sum_cap_valorpend = v_sum_cap_valorpend - v_acu_valor;
				if v_sum_cap_valorpend <= 0 then
					exit foreach;
				end if

	        end foreach
        else 
        	let v_fecsigper = f_pv_fec_sigper(p_codcred, p_codmod, p_coddsb, p_fecha, C_TIPOCUO_CAP);
        	foreach 
        		execute procedure f_pp_prorrateo(p_codcred, p_codmod, p_coddsb, null, v_fecsigper, p_importecap, null, p_tipo_pago, 0)
        		into v_cuo_coddsb, v_cuo_codcuo, v_cuo_fecvencuo, v_contar, v_siap_pp, v_cap_pp_prorra
        		
        		let V_D_FECINIPER = f_pv_fechainiper(p_codcred, p_codmod, v_cuo_coddsb, v_cuo_fecvencuo, C_TIPOCUO_INT);
        		
        		update aux_planpagos
				set acu_valor = nvl(acu_valor,0) - v_cap_pp_prorra,
				acu_valorpend = nvl(acu_valorpend,0) - v_cap_pp_prorra,
				acu_cargos = v_mnt_capper,
				acu_montocuo = nvl(acu_montocuo,0) + v_cap_pp_prorra,
				acu_fecfincuo = acu_fecvencuo,
				acu_fecinicuo = V_D_FECINIPER,
				acu_tipotrx = nvl(acu_tipotrx,C_TIPOCOB_COB),
				acu_tipoacu = nvl(acu_tipoacu,C_TIPOCUO_CAP),
				acu_auditusr = p_coduser,
				acu_monpag = 1,
				acu_tipodsb = p_codrepro,
				acu_trxstaau = 1
				where acu_codcred = p_codcred
				and acu_codmod = p_codmod
				and acu_codacu = v_cuo_codcuo
				and acu_tipocuo = C_TIPOCUO_CAP
        		and acu_coddsb = v_cuo_coddsb;
        		
        		let v_mnt_capper = 0;
        	end foreach
        end if
    end if        
    	
end procedure;


