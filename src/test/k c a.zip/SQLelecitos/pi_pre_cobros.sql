

DROP procedure IF EXISTS d_creditos.pi_pre_cobros;
create procedure d_creditos.pi_pre_cobros(o_cob_codcred		like pre_cobros.cob_codcred		,
    o_cob_codmod        like pre_cobros.cob_codmod      ,
    o_cob_numtrx        like pre_cobros.cob_numtrx      ,
    o_cob_codcob       like pre_cobros.cob_codcob     ,
    o_cob_feccontab     like pre_cobros.cob_feccontab   ,
    o_cob_fechproc      like pre_cobros.cob_fechproc    ,
    o_cob_codtab        like pre_cobros.cob_codtab      ,
    o_cob_codigo        like pre_cobros.cob_codigo      ,
    o_cob_valor         like pre_cobros.cob_valor       ,
    o_cob_codmon        like pre_cobros.cob_codmon      ,
    o_cob_numcuo like pre_cobros.cob_numcuo,
    o_cob_tabtipotrx    like pre_cobros.cob_tabtipotrx  ,
    o_cob_tipotrx       like pre_cobros.cob_tipotrx     ,
    o_cob_statreg       like pre_cobros.cob_statreg     ,
    o_cob_auditwst      like pre_cobros.cob_auditwst,
    o_cob_auditusr      like pre_cobros.cob_auditusr)

{
WHERRERA    20210922    (trigger)se crea el procedimiento que controla el flujo de las transacciones en el servicio de la deuda 
}
    define v_fecsigvcto,v_cuo_fecvencuo, v_pre_feclimite date;
    define c_tipocuo_cap,v_cuo_codcuo integer;
    define v_cuo_coddsb integer; 
    define C_CODTAB_CAPINT integer;
    define C_TIPOCOB_PANTI, C_TIPOTRAN_COB, C_TIPOTRAN_DSB integer;
    define C_CODTAB_DSB, C_CODTAB_CAP, C_CODTAB_INT, C_CODTAB_PANTI_CAP, C_CODTAB_PANTI_INT integer;
    DEFINE GLOBAL G_FLAG_EXETRIGGER_COB INT DEFAULT -1;
    define C_CODDSB_CERO, C_FLAG_EXETRIGGER_PP_NOEXE integer;
    define v_tmo_tipotra, v_tmo_tipocob integer;
    define n_cob_valor,v_cuo_valorpend like pre_cobros.cob_valor;
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    --SET DEBUG FILE TO '/opt/aplicaciones/siscred/logs/tracedb.log';            
    --TRACE 'begin trace';
    --TRACE ON;
    
    let C_TIPOTRAN_COB = 2;
    let C_TIPOTRAN_DSB = 1;
    let C_CODTAB_CAPINT = 1720;
    let C_CODTAB_CAP = 1;
    let C_CODTAB_INT = 2;
    LET C_CODTAB_PANTI_CAP = 12;
    LET C_CODTAB_PANTI_INT = 22;
    LET C_CODTAB_DSB = 3;    
    let n_cob_valor = 0;
    
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;

    if G_FLAG_EXETRIGGER_COB = C_FLAG_EXETRIGGER_PP_NOEXE then
        LET G_FLAG_EXETRIGGER_COB = -1;
        RETURN;
    end if
    
    LET G_FLAG_EXETRIGGER_COB = -1;

    select tmo_tipotra, tmo_tipocob
    into v_tmo_tipotra, v_tmo_tipocob
    from pre_tramon
    where tmo_codcred = o_cob_codcred
    and tmo_codmod = o_cob_codmod
    and tmo_numtrx = o_cob_numtrx;
    
    if v_tmo_tipotra is null then
        raise exception -746,0,"No existe definido el tipo de cobro " || o_cob_numtrx;
    end if

    if o_cob_codigo in (1,2) THEN
    
        update pre_planpagos
        set cuo_valorpend = cuo_valorpend - o_cob_valor,
        cuo_tipoacu = nvl(cuo_tipoacu, cuo_tipocuo),
        cuo_tipotrx = nvl(cuo_tipotrx, o_cob_tipotrx),
        cuo_fecfincuo = nvl(cuo_fecfincuo, cuo_fecvencuo),
        cuo_monpag = 2, --pagado
        cuo_auditwst = o_cob_auditwst,
        cuo_auditusr = o_cob_auditusr,
        cuo_auditfho = current
        where cuo_codcuo = o_cob_numcuo
        and cuo_codcred = o_cob_codcred
        and cuo_codmod = o_cob_codmod
        and cuo_valorpend >= o_cob_valor;

    elif o_cob_codigo in (11,13,18,21,23,28) then
        update pre_planpagos
        set cuo_valorpend = NVL(cuo_valorpend,0) - NVL(o_cob_valor,0),
        cuo_tipoacu = nvl(cuo_tipoacu, cuo_tipocuo),
        cuo_tipotrx = nvl(cuo_tipotrx, o_cob_tipotrx),
        cuo_fecfincuo = nvl(cuo_fecfincuo, cuo_fecvencuo),
        cuo_monpag = 2, --pagado
        cuo_auditwst = o_cob_auditwst,
        cuo_auditusr = o_cob_auditusr,
        cuo_auditfho = current
        where cuo_codcuo = o_cob_numcuo
        and cuo_codcred = o_cob_codcred
        and cuo_codmod = o_cob_codmod;    
    
    elif o_cob_codigo in (12,22) then
        update pre_planpagos
        set cuo_valorpend = cuo_valorpend - o_cob_valor,
        cuo_monpag = 2, --pagado
        cuo_auditwst = o_cob_auditwst,
        cuo_auditusr = o_cob_auditusr,
        cuo_auditfho = current
        where cuo_codcuo = o_cob_numcuo
        and cuo_codcred = o_cob_codcred
        and cuo_codmod = o_cob_codmod
        and cuo_valorpend >= o_cob_valor;

    elif o_cob_codigo in (14,24) THEN
    
        update pre_planpagos
        set  
        cuo_monpag = 3, --diferido
        cuo_auditwst = o_cob_auditwst,
        cuo_auditusr = o_cob_auditusr,
        cuo_auditfho = current
        where cuo_codcuo = o_cob_numcuo
        and cuo_codcred = o_cob_codcred
        and cuo_codmod = o_cob_codmod
        and cuo_tipoacu = o_cob_codigo;
       	
    elif o_cob_codigo = C_CODTAB_DSB then
    
        select pre_feclimite
        into v_pre_feclimite
        from pre_prestamos
        where pre_codmod = o_cob_codmod
        and pre_codcred = o_cob_codcred;
        
        if o_cob_fechproc > v_pre_feclimite then
            raise exception -746,0,"Fecha de proceso " || o_cob_fechproc || " mayor a la fecha limite de desembolso " || v_pre_feclimite;
        end if
        let G_FLAG_EXETRIGGER_PP = 1;
        
        update pre_desemb
        set dsb_undsb = NVL(o_cob_valor,0),
        dsb_tipodsb = 2, -- vigente
        dsb_monpag = 5,
        dsb_feculttrx = o_cob_fechproc,
        dsb_auditwst = o_cob_auditwst,
        dsb_auditusr = o_cob_auditusr,
        dsb_auditfho = current
        where dsb_coddsb = o_cob_numcuo;
        
        let G_FLAG_EXETRIGGER_PP = -1;        
    end if
    
end procedure;



