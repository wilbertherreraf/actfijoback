

drop procedure if exists d_creditos.p_generar_planpagosnue;
create procedure d_creditos.p_generar_planpagosnue(p_codcred integer, p_codmod integer, p_coddsb integer, p_codmodtmp integer, p_coduser varchar(100), p_estacion varchar(100))
    returning integer
{
wherrera genera un nuevo plan de pagos sin considerar lo registrado al momento

}
    define err_num, err_nro integer;
    define err_msg varchar(235); 
    
    define v_cont_dsb_cap integer;
    define v_cont integer;
    define v_pre_saldo like pre_prestamos.pre_saldo;
    define v_pre_statreg like pre_prestamos.pre_statreg;
    define v_contpp, C_STATREG_SUSP integer;
    define V_MNT_DSB_ANT, V_SUM_DBS_UNDSB_ANT, v_sum_dsb_saldo  like pre_desemb.dsb_valor;
    define p_diasperiodo integer;
    define v_feculttrx, v_min_fecvencuo, v_max_fecvencuo date;
    
    let p_diasperiodo = null;
    let C_STATREG_SUSP = 9;
    
BEGIN
    ON EXCEPTION  SET err_num, err_nro, err_msg  -- trap all errors
    END EXCEPTION with resume

    call p_srvdeu_initlog(p_coduser, p_estacion);  
    trace procedure; 
end
BEGIN
    ON EXCEPTION  SET err_num, err_nro, err_msg  -- trap all errors
        call p_log_error(err_num, err_nro, err_msg, null);
        raise exception err_num, err_nro, err_msg ;
    END EXCEPTION    
    
    let V_MNT_DSB_ANT = f_getsumas_dsb(p_codmod, p_codcred, p_coddsb, null, null);
    if V_MNT_DSB_ANT = 0 then
        raise exception -746,0,"No existe monto desembolsado registrado para coddsb " || p_coddsb;
    end if

    delete from aux_planpagos
    where acu_codmod = p_codmod
    and acu_codcred = p_codcred
    and acu_coddsb = p_coddsb;
    
    call p_genera_pp_capitales(p_codcred, p_codmod, p_coddsb, p_codmod, p_coduser, p_estacion);

    select count(*)       
    into v_cont 
    from aux_planpagos
    where acu_codmod = p_codmod
    and acu_codcred = p_codcred
    AND acu_coddsb = p_coddsb;
    
    if v_cont = 0 then
        raise exception -746,0,"No se registro ninguna informacion del plan pagos, revise parametros";
    end if
    
END
    call p_log_finlog();    
return v_cont;        
end procedure;
