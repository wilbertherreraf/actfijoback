


DROP procedure IF EXISTS d_creditos.p_get_datos_coin;
create procedure d_creditos.p_get_datos_coin(p_idtabla integer, p_codcmp integer, p_cve_tipo_operacion varchar(30)) returning varchar(20)

         -- DESCRIPCI: retorna ingormacion de coin
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- wherrera 20260505 retorna el esque de una operacion

   
   	DEFINE w_glosa          lVarchar(500);
	define v_prc_codprc,v_nro_centro integer;
	define v_prc_fecha,v_prc_fecha_2 date;
	define v_prc_nro_centro integer;
	define v_prc_nro_comprob varchar(30); 
	
define v_cod_esquemaresp, v_cod_esquema like contbcb@bcbux02:reng_esq.cod_esquema;
define v_cont_mayor, v_cont, v_cont_esq, nro_posi, v_diferencia integer;

let v_cont_esq = 0;
let nro_posi = 1;
let v_cod_esquemaresp = null;
        -- obtenmos los esquemas candidatos                    
    foreach
        select distinct cod_esquema
        into v_cod_esquema
        from
        (select re.cod_esquema,
            (select count(*)
                        from contbcb@bcbux02:reng_esq re0
                        where re0.cod_esquema = re.cod_esquema
                        and not exists (
                            select 1
                            from gen_prcparams cp2
                            where cp2.prp_codprc = p_idtabla
							and cp2.prp_tipoproc = p_codcmp
							and cp2.prp_dh = re0.cve_debe_haber
							and cp2.prp_mayor = re0.cod_mayor
                    )) inexistentes
        from contbcb@bcbux02:reng_esq re
        where re.cod_esquema in ('002944','003660','000115','002964','004424',
'003722','003853','003674','004541','003723',
'002219')
        and exists (select 1
                    from gen_prcparams rc
                    where rc.prp_codprc = p_idtabla
                    and rc.prp_dh = re.cve_debe_haber
                    and rc.prp_tipoproc = p_codcmp
                    and rc.prp_mayor= re.cod_mayor)
        ) esque
        where inexistentes = 0

            -- para cada esquema candidato verificamos que esten todos los registros en el comprobante
            select count(*) --distinct (regsreng - regs) diff
            into v_diferencia
            from (
                select *
                from 
                    (select distinct prp_dh,prp_mayor cod_mayor
                    from gen_prcparams
                    where prp_codprc = p_idtabla
                    and prp_tipoproc = p_codcmp
                    ) rm,
                outer
                (select re.cod_esquema, re.cve_debe_haber, re.cod_mayor
                from contbcb@bcbux02:reng_esq re
                where re.cod_esquema = v_cod_esquema) t
                where rm.prp_dh = t.cve_debe_haber
                and rm.cod_mayor = t.cod_mayor
            ) tr
            where cod_esquema is null;
            
            if (v_diferencia = 0) then
            -- esquema encontrado
                let v_cod_esquemaresp = v_cod_esquema;
            end if
            if (v_diferencia = 1) then
                if v_cod_esquemaresp is null then
                    let v_cod_esquemaresp = v_cod_esquema;
                end if
            end if
    end foreach;
    return v_cod_esquemaresp;  

END PROCEDURE;


