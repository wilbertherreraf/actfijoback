

drop procedure if exists d_creditos.p_cambia_estado_comprobante;
create procedure d_creditos.p_cambia_estado_comprobante(p_idtabla integer, p_codcmp integer, p_codcred integer, p_codmod integer,p_coddsb integer, 
	p_nro_comprob varchar(10),p_nro_centro integer, p_cve_tipocomprob varchar(5), p_fechacont date,p_nuevoestado varchar(5), 
	p_usuario varchar(15), p_estacion varchar(50))
	returning varchar(10)

         -- DESCRIPC: Procedimiento para cambiar el estado de los comprobantes a PREAUTORIZADO, AUTORIZADO o RECHAZADO
         -- PARAMETROS SALIDA: resultado integer                Resultado de la operacion
         -- AUTOR: ALVARO CANQUI
         -- CREAC:  06-02-2025
         -- SDAPO: 2344735
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
 		 ----------------------------------------------------------------------------------------------------------------------------------------------------
		 --|   Autor   |     Fecha     | SDAPO    |  Descripcion
		 ---------------------------------------------------------------------------
		 --| mcramos   |  28-03-2025   | 2368094  |  Ajuste para actualizar el estado del comprobante para registro de Retiro de Garantia
		 ----------------------------------------------------------------------------
		 --| mcramos   |  07-03-2025   | 2367989  |  Ajuste para actualizar el estado del comprobante para registro de Custodia de Garantia
		 ---------------------------------------------------------------------------------------------------------------------------------------
		 --| mcramos   |  28-03-2025   | 2368094  |  Ajuste para actualizar el estado del comprobante para registro de Retiro de Garantia
		 ---------------------------------------------------------------------------------------------------------------------------------------
		 --| acanqui   |  06-05-2025   | 2401886   | Ajuste para actualizar el estado del comprobante para registro de Pago de Cuota
		 ---------------------------------------------------------------------------------------------------------------------------------------
		 --| wherrera  |  06-05-2026   |    | se unifica el cambio de estado del comprobante	
		 ---------------------------------------------------------------------------------------------------------------------------------------

  define w_audit_usuario_genera varchar(30);
  define w_nro_centro       	integer;
 
  define v_codcred, v_codmod, v_coddsb  integer; 
  define w_nro_comprob_coin varchar(20); 
  define w_cve_estado_comprob_coin varchar(10); 
  define w_cod_usuario_coin varchar(20); 
	define w_fecha_coin,v_fecha_vencimiento, v_fecha date;
  define v_contar INTEGER;
  
  if p_nuevoestado is null then
     Raise Exception -746, 0, "El estado especificado no es valido.";
  end if   
  
  	if p_nuevoestado = "R" then
	  if length(trim(nvl(p_nro_comprob,""))) = 0 then
	  		return p_nuevoestado;
	  end if
	end if
	
	if length(trim(nvl(p_nro_comprob,""))) = 0 then
		Raise Exception -746, 0, "Cambio estado: Parametro nro comprobante debe tener valor idtabla:" || p_idtabla || " codcmp: " || p_codcmp || " nvoestado: " || p_nuevoestado;
	end if
	
	if p_nuevoestado not in("1","A","R") then
		Raise Exception -746, 0, "El parametro nuevo estado[" || p_nuevoestado || "] invalido se esperaba 1,A o R";
	end if
   
   let w_cve_estado_comprob_coin = null;
   
   select  cve_estado_comprob, cod_usuario
   into w_cve_estado_comprob_coin, w_cod_usuario_coin
   from contbcb@bcbux02:comprobante
   where nro_centro = p_nro_centro  
   and cve_tipo_comprob = p_cve_tipocomprob 
   and nro_comprob = p_nro_comprob;
  
   if dbinfo ("sqlca.sqlerrd2") = 0 then  
         Raise Exception -746, 0, "Cambio estado:Comprobante " || p_cve_tipocomprob || " - " || p_nro_comprob || " inexistente en COIN";
   end if

	if w_cve_estado_comprob_coin not in ("1","P","A","R") then
		Raise Exception -746, 0, "Cambio estado: Comprobante " || p_cve_tipocomprob || " - " || p_nro_comprob || " con estado invalido " || w_cve_estado_comprob_coin || " se esperaba P,1,A o R";		
	end if
	
	if w_cve_estado_comprob_coin in ("A","R") then
		-- se requiere que en siscred se sincronice el estado	
		return w_cve_estado_comprob_coin;
	end if
	
	if p_nuevoestado = w_cve_estado_comprob_coin then
	-- es mismo estado esperado no hacemos nada
		return w_cve_estado_comprob_coin;
	end if   
	
	if p_nuevoestado = "1" then
		if w_cve_estado_comprob_coin != "P" then
			Raise Exception -746, 0, "Preauto: Comprobante " || p_cve_tipocomprob || " - " || p_nro_comprob || " con estado invalido " || w_cve_estado_comprob_coin || " se esperaba P";
		end if 
   	end if
   
	if p_nuevoestado = "A" then
		if w_cve_estado_comprob_coin = "P" then
			-- se requiere que en siscred se sincronice el estado
			return w_cve_estado_comprob_coin;
		end if
   	end if
   	
	if p_nuevoestado = "R" then
		if w_cve_estado_comprob_coin not in ("P","1") then
			Raise Exception -746, 0, "Rechazar: Comprobante " || p_cve_tipocomprob || " - " || p_nro_comprob || " con estado invalido " || w_cve_estado_comprob_coin || " se esperaba P";
		end if		
	else
		select fecha_dia 
	    into w_fecha_coin 
	    from contbcb@bcbux02:dia   
		where cve_estado_dia = "A";
	
	    if w_fecha_coin is null then   
	       Raise Exception  -746, 0, "No existe Fecha habilitada en COIN ";
	    end if
	
	    if p_fechacont != w_fecha_coin then
	    	Raise Exception -746, 0, "Fecha contable operacion " || p_fechacont || " difiere con fecha COIN " || w_fecha_coin;
	    end if	
   	end if   	
   	
-- actualizamos el estado en el comprobante en el COIN
   update contbcb@bcbux02:comprobante   --preautorizar comprobante
   set cve_estado_comprob = p_nuevoestado,
       cod_usuario = p_usuario,
       fecha_hora = current,
       estacion = p_estacion 
   where nro_centro = p_nro_centro  
   and cve_tipo_comprob = p_cve_tipocomprob 
   and nro_comprob = p_nro_comprob;

	select count(1)
	into v_contar
	from contbcb@bcbux02:estado_comprob
	where nro_centro = p_nro_centro  
   and cve_tipo_comprob = p_cve_tipocomprob 
   and nro_comprob = p_nro_comprob
	and cve_estado_comprob = w_cve_estado_comprob_coin;
	
	if v_contar = 0 then
   		insert into contbcb@bcbux02:estado_comprob(nro_centro, cve_tipo_comprob, nro_comprob, cve_estado_comprob, cod_usuario, fecha_hora, estacion)
   		values (p_nro_centro, p_cve_tipocomprob, p_nro_comprob,w_cve_estado_comprob_coin, w_cod_usuario_coin, current, p_estacion);
	end if
    
	return p_nuevoestado;
END PROCEDURE;



