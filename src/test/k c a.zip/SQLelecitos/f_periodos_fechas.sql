


DROP function IF EXISTS d_creditos.f_periodos_fechas;
create function d_creditos.f_periodos_fechas(p_fechaini date , p_fechafin date, p_unidplaz integer, NRODIASPERIODO integer, INPUT_PERIOD_BASE integer, 
	INPUT_LASTDATE_EXACT INTEGER, INIT_FECHAINI INTEGER)
    returning integer, integer, date	
{
	retorna el numero de periodos por fechas y el periodos por calendario
	wherrera 20260505 se adiciona el parametro de INPUT_LASTDATE_EXACT 
}
   
    define v_fechafinper, fecha_ini, fecha_fin date;
    define C_INPUT_PERIOD_EXACT, C_MAX_PERIODOS integer;
    define V_YY_OUT, V_MM_OUT, V_DD_OUT, DR_REPMTS_PER_YEAR_OUT integer;
    define ST_D_PERIOD, END_D_PERIOD, v_fechainiper date;
    define v_numpers, v_numpers_periods, MONTHSPERPERIOD, v_first integer;
    
    let C_INPUT_PERIOD_EXACT = 3;
    let v_numpers = 0;
    let v_numpers_periods = 0;
    let fecha_fin = null;
    let C_MAX_PERIODOS = 1000;
    let v_first = 0;
    --let p_fechaini = p_fechaini + 1;

    if p_unidplaz in (1,7) and nvl(NRODIASPERIODO, 0) > 0 then
        let p_fechafin = nvl(p_fechafin, p_fechaini);    
        let v_fechafinper = p_fechaini;
        
        while v_fechafinper <= p_fechafin
            let v_fechafinper = v_fechafinper + NRODIASPERIODO;
            
            let v_numpers = v_numpers + 1; 
        end while
        let fecha_fin = v_fechafinper;
        let v_numpers_periods = v_numpers;

        return v_numpers, v_numpers_periods, fecha_fin;
    else
        foreach
            execute procedure f_getperiodos( p_fechaini, p_fechafin, p_unidplaz, INPUT_PERIOD_BASE, INPUT_LASTDATE_EXACT, INIT_FECHAINI)
                into v_numpers_periods,fecha_ini, fecha_fin
                if v_first = 0 then
                    let v_fechainiper = fecha_ini;
                    let v_first = 1;
                end if
        end foreach
        
        call f_PERIOD_BETWEEN (v_fechainiper, p_fechafin) returning V_YY_OUT, V_MM_OUT, V_DD_OUT;
        let DR_REPMTS_PER_YEAR_OUT = f_ISREPMTSPERYEAR(p_unidplaz);
        call f_infoperiodo(p_fechaini, p_fechaini, p_unidplaz, INPUT_PERIOD_BASE)returning MONTHSPERPERIOD, ST_D_PERIOD, END_D_PERIOD;    
        
        if MONTHSPERPERIOD = 0 then
            let MONTHSPERPERIOD = 1;
        end if
        
        let v_numpers = DR_REPMTS_PER_YEAR_OUT * V_YY_OUT + trunc(V_MM_OUT / MONTHSPERPERIOD);

        return abs(v_numpers), v_numpers_periods, fecha_fin;        
    end if
    

end function;
