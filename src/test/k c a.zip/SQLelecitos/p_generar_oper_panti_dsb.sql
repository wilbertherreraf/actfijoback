

drop procedure if exists d_creditos.p_generar_oper_panti_dsb;
create procedure d_creditos.p_generar_oper_panti_dsb(p_trxstaau integer, p_codrepro integer, p_fechaoper date, p_coduser varchar(100), P_ESTACION VARCHAR(100))
{
   wherrera    2021-10-06  procedimiento generarcion de pagos anticipados en tabla auxiliar pp 
1	REPROGRAMACION
2	PAGO ANTICIPADO
3	DIFERIMIENTO  


-- CREACION: 2021-10-06

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| wherrera  |  2021-10-06   |          | procedimiento generarcion de pagos anticipados
----------------------------------------------------------------------------
--| acanqui   |  06-05-2024   | 1763004  | Adici opcion para realizar pagos con DISTRIBUCION LINEAL DE CUOTAS (DLC) O CONTRA LA SIGUIENTE CUOTA (CSC) SOLAMENTE PARA EL FNDR.
----------------------------------------------------------------------------
---------------------------------------------------------------------------
--| wherrera  |  2026-04-05   |          | se reformula los pagos anticipados se incluye si hubo pa en el saldo y se modifica que la autorizacion del p.a. sea el mismo metodo 

}

    define v_rds_codmod, v_rds_codcred, v_rds_statreg integer;
    define v_rds_valor, v_rds_undsb, V_MNT_PRG, V_MNT_PRGPEND like pre_planpagos.cuo_valor; 
    define v_fecultdifer, v_fecultrepro, v_rds_fecini, v_feculttrx date;
    define v_rds_fecini_a, v_rds_feciniint_a date;
    define v_cuo_codcuo, C_TIPOREPRO_PANTI, C_TIPOTRX_DIFER,v_rds_trxstaau integer;

    define v_rds_tipo_pago, TIPO_PAGO_CSC, TIPO_PAGO_DLC CHAR(10);  
    define C_TRXSTAAU_ELIMINAR, C_TRXSTAAU_PREAUTORIZAR, C_TRXSTAAU_VIGENTE, C_TRXSTAAU_AUTORIZAR, v_contar, C_TIPOCUO_CAP, C_TIPOCUO_INT integer;
     
    let C_TIPOREPRO_PANTI = 2;
    let C_TIPOTRX_DIFER = 4;
   	let C_TIPOCUO_CAP = 1;
	let C_TIPOCUO_INT = 2;
    let C_TRXSTAAU_VIGENTE = 1;
    let C_TRXSTAAU_PREAUTORIZAR = 2;
    let C_TRXSTAAU_AUTORIZAR = 3;
	let C_TRXSTAAU_ELIMINAR = 9;
    let TIPO_PAGO_CSC='CSC';
    let TIPO_PAGO_DLC='DLC';
    let v_contar = 0;
    
    select rds_codmod, rds_codcred, rds_fecini, rds_valor, rds_undsb, rds_statreg, rds_tipo_pago,rds_trxstaau
    into v_rds_codmod, v_rds_codcred, v_rds_fecini, v_rds_valor, v_rds_undsb, v_rds_statreg, v_rds_tipo_pago,v_rds_trxstaau
    from pre_reprograma
    where rds_codrepro = p_codrepro
    and rds_tiporepro = C_TIPOREPRO_PANTI;

    if v_rds_codcred is null then
        raise exception -746,0,"Registro de pago anticipado inexistente o suspendido " || p_codrepro;
    end if
    
    if p_trxstaau = C_TRXSTAAU_ELIMINAR then
    	if v_rds_trxstaau = 3 then
    		raise exception -746,0,"Registro de pago anticipado AUTORIZADO " || p_codrepro;
    	end if
    	
		delete FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
    	and acu_tipodsb = p_codrepro;
    	
    	delete from pre_reprograma
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_PANTI
    	and rds_trxstaau != 3;
    	
    	return;
    end if
    

    if nvl(v_rds_undsb, 0) > 0 then
        raise exception -746,0,"Pago anticipado procesado " || p_codrepro;
    end if
    
    if nvl(v_rds_valor, 0) <= 0 then
        raise exception -746,0,"Importe pago anticipado debe ser mayor a cero " || p_codrepro;
    end if

    let v_feculttrx = f_rpro_fec_ultvalid(v_rds_codcred, v_rds_codmod);
    if v_feculttrx is null then
        raise exception -746,0,"No existe ningun cobro o desembolso realizado. RPRO: " || p_codrepro;
    end if

    if  v_feculttrx > v_rds_fecini then
        raise exception -746,0,"PANT: Fecha de ult trans. " || v_feculttrx || " mayor a fecha de pago anticipado " || v_rds_fecini;
    end if
    
    call f_rpro_fec_ultrepro(v_rds_codcred, v_rds_codmod, null) returning v_fecultrepro, v_rds_fecini_a, v_rds_feciniint_a;
    let v_fecultrepro = nvl(v_fecultrepro, f_dsb_fecmax_trx(v_rds_codmod, v_rds_codcred, null, C_TIPOTRX_DIFER));

    if v_fecultrepro is not null and v_fecultrepro >= v_rds_fecini then
        raise exception -746,0,"PANT: Fecha de pago ant. invalida debe ser mayor a: " || v_fecultrepro;
    end if

    if p_trxstaau = C_TRXSTAAU_VIGENTE then
    	SELECT count(*)
	    INTO v_contar
	    FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
	    AND acu_valor > 0
    	and acu_tipodsb > 0
    	and acu_trxstaau = C_TRXSTAAU_PREAUTORIZAR;
    
    	if v_contar > 0 then
    		raise exception -746, 0, "Credito en proceso de revision en tabla auxiliar";
    	end if
    	
    	if v_rds_tipo_pago is null or v_rds_tipo_pago not in ("DLC","CSC") then
    		raise exception -746, 0, "Tipo de prorrateo debe tener valor";
    	end if
   		-- copia valores de la tabla plan de pagos a la tabla 'aux_planpagos'
    	
		delete from aux_planpagos
	    where acu_codcred = v_rds_codcred
	    and acu_codmod = v_rds_codmod
		and acu_tabtipodsb = C_TIPOREPRO_PANTI;
	
		call p_cpy_planpagos_auxpp(v_rds_codcred, v_rds_codmod, C_TIPOREPRO_PANTI, p_codrepro, p_coduser, p_estacion);
    	
 		call p_rpro_panti_metosaldodsb(v_rds_codcred, v_rds_codmod, p_codrepro, v_rds_fecini, p_fechaoper, v_rds_valor, p_coduser, P_ESTACION, v_rds_tipo_pago);
 		
        update pre_reprograma
    	set rds_trxstaau = C_TRXSTAAU_VIGENTE,
    	rds_undsb = 0,
    	rds_auditusr = p_coduser,
    	rds_auditwst = P_ESTACION,
    	rds_auditfho = current
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_PANTI;    
    elif p_trxstaau = C_TRXSTAAU_PREAUTORIZAR then
    
	    SELECT count(*)
	    INTO v_contar
	    FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
	    AND acu_valor > 0
    	and acu_tipodsb = p_codrepro
	    and acu_trxstaau = C_TRXSTAAU_VIGENTE;
    
        IF v_contar = 0 THEN
    		raise exception -746, 0, "PAG ANT PREAUTO: No existen registros en tabla auxiliar, para cod " || p_codrepro;
    	END if
    
    	call p_control_auxpp(v_rds_codcred, v_rds_codmod, p_codrepro);
    	
        update pre_reprograma
    	set rds_trxstaau = C_TRXSTAAU_PREAUTORIZAR,
    	rds_auditusr = p_coduser,
    	rds_auditwst = P_ESTACION,
    	rds_auditfho = current
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_PANTI;
        
        update aux_planpagos
        set acu_trxstaau = C_TRXSTAAU_PREAUTORIZAR
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
    	and acu_tipodsb = p_codrepro
        and acu_trxstaau = C_TRXSTAAU_VIGENTE;
        
    elif p_trxstaau = C_TRXSTAAU_AUTORIZAR then
    
    	SELECT count(*)
	    INTO v_contar
	    FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
	    AND acu_valor > 0
    	and acu_tipodsb = p_codrepro
    	and acu_trxstaau = C_TRXSTAAU_PREAUTORIZAR;

        IF v_contar = 0 THEN
    		raise exception -746, 0, "PAG ANT AUTO: No existen registros en tabla auxiliar, para cod " || p_codrepro;
    	END if
    	
    	call p_cpy_auxpp_planpagos(v_rds_codcred, v_rds_codmod, null, p_codrepro, p_coduser, P_ESTACION);
    	
    	update pre_reprograma
    	set rds_trxstaau = C_TRXSTAAU_AUTORIZAR,
    	rds_undsb = rds_valor,
    	rds_auditusr = p_coduser,
    	rds_auditwst = P_ESTACION,
    	rds_auditfho = current
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_PANTI; 
    	-- borramos todo
		delete FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred;    	
       
    end if
   
end procedure;
                                                              

