


DROP procedure IF EXISTS d_creditos.p_get_id_proceso_conta;
create procedure d_creditos.p_get_id_proceso_conta(p_codcmp integer, p_codcred integer, p_codmod integer, p_fecha date, p_estado int) RETURNING INTEGER AS prc_estado;

         -- DESCRIPCI: Obtiene el ID de un proceso de comprobante a partir los parametros de la tabla correspondiente
         -- PARAMETROS INGRESO: p_codcmp integer                codigo de comprobante
         --                     p_codcred integer               Codigo de credito
         --                     p_codmod integer                Codigo de modulo
         --                     p_fecha date                    Fecha
         --                     p_estado int                    Estado del proceso
         -- PARAMETROS SALIDA: prc_estado integer               ID del proceso
         -- AUTOR: HENRY IVAN PANIQUE MIRANDA
         -- DEPENDENCIAS: CREDITOS (pre_prcconta)
         -- CREACI:  30-11-2023
         -- SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS

  define w_prc_codprc integer;
  
  if p_codcmp is null or p_codcmp = 0  then
	RETURN 0;
  end if   
    
  if p_fecha is null  then
	RETURN 0;
  end if   
  
  if p_codcred is null or p_codcred <= 0 then
	RETURN 0;
  end if   

  if p_codmod is null or p_codmod <= 0 then
	RETURN 0;
  end if   
 
   if p_estado is null or p_estado = 0  then
	RETURN 0;
  end if   
 
  let w_prc_codprc = null; 
  
  select max(prc_codprc) 
    into w_prc_codprc
    from pre_prcconta
   where prc_codcmp = p_codcmp 
     and prc_codcred = p_codcred
     and prc_codmod = p_codmod 
     and prc_fecha = p_fecha
     and prc_estado = p_estado;
    
    return nvl(w_prc_codprc, 0);
    
END PROCEDURE;



