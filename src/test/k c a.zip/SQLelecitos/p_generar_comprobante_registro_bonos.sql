


drop procedure if exists d_creditos.p_generar_comprobante_registro_bonos;
create procedure d_creditos.p_generar_comprobante_registro_bonos (p_idtabla integer, p_codcmp integer, p_codcred integer, p_codmod integer, p_fechacont date, p_glosa lvarchar(500), p_usuario varchar(15), p_estacion varchar(50))    
    returning varchar(15) as nro_comprob; 

         -- DESCRIPCION: Procedimiento para generar comprobantes en el COIN
         -- PARAMETROS INGRESO: p_idtabla integer				Id de la tabla pre_registrogarantias
   		 --						p_codcmp integer          Tipo de rgistro para la consulta Registro transitorio de garantias, 
         --                     p_codcred integer               Codigo de credito
         --                     p_codmod integer                Codigo de modulo
         --                     p_fechacont 			            Fecha de registro contable
         --                     p_glosa							Descripcion de la glosa que se registrara en el comprobante 
         --                     p_usuario varchar(15)           Codigo de usuario
         --                     p_estacion varchar(50)          Estacion de donde viene la solicitud (IP)
         -- PARAMETROS SALIDA: codprc as integer                Codigo de Proceso
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: CONTBCB (comprobante, dia)
         --               CREDITOS (gen_renglon, pre_prcconta) 
         -- CREACION:  05-02-2025
         -- SDAPO: 2344735
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
     --|   Autor  |     Fecha   |  Sdapo   |  Descripcion
	 ---------------------------------------------------------------------------
	 --| mcramos  |  05-03-2025 | 2367989  | Ajuste para generacion de comprobante para registro de Custodia de Garantia
	 ---------------------------------------------------------------------------
	 --| mcramos  |  12-03-2025 | 2368094  | Ajuste para generacion de comprobante para registro de Retiro de Garantia
	 ---------------------------------------------------------------------------
	 --| mcramos  |  05-03-2025 | 2367989  | Ajuste para generacion de comprobante para registro de Custodia de Garantia
	 ---------------------------------------------------------------------------
	 --| mcramos  |  12-03-2025 | 2368094  | Ajuste para generacion de comprobante para registro de Retiro de Garantia
	 ---------------------------------------------------------------------------
	 --| acanqui  |  06-05-2025 | 2401886  | Ajuste para generacion de comprobante para registro contable de Pago de Cuota
	 ---------------------------------------------------------------------------
	 --| wherrera  |  06-05-2026 |  | genera todos los comprobantes de tas operaciones, requiere que en gen_prcparams esten registrados
	 ---------------------------------------------------------------------------
define w_estado_ini_cmp   varchar(1);
define w_start_index,w_end_index,w_nro_parametro, w_estado,v_contar integer;    
define v_sgte_devcont, v_fecha,w_fecha_coin DATE;
define v_cve_tipo_comprob			VARCHAR(30);
define v_fecha_cont,v_fec_vcto date;
define w_cmp_centro, v_codcred, v_codmod,v_coddsb 	INTEGER;
define REGISTRO_TRANSITORIO_GARANTIAS,REGISTRO_CONTABLE_DESEMBOLSOS_EPNES,REGISTRO_CONTABLE_DESEMBOLSOS_MEFP  INTEGER;
define REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA INTEGER;
define REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA INTEGER;
define REG_CONT_PAGO_INTERESES_EPNE_MEFP,REG_CONT_PAGO_INTERESES_YPFB_FNDR INTEGER;
define w_cmp_esquema, v_cod_esquema   like gen_comprobante.cmp_esquema;
define v_glosa     lvarchar(500);
define w_cmp_dev_real  like gen_comprobante.cmp_dev_real;     
define w_cmp_tabestado like gen_comprobante.cmp_tabestado;
define w_cmp_estado    like gen_comprobante.cmp_estado;
define w_gestion, w_nro_periodo, w_nro_dia integer;     
define w_factor_conv_us_m  like contbcb@bcbux02:comprobante.factor_conv_us_mn;
define w_cod_unidad        like contbcb@bcbux02:comprobante.cod_unidad;
define w_nro_comprob,v_nro_comprob       like contbcb@bcbux02:comprobante.nro_comprob;
define w_cve_tipo_comprob  like contbcb@bcbux02:comprobante.cve_tipo_comprob;
define w_fecha_dia         like contbcb@bcbux02:dia.fecha_dia; 
define v_pcu_numtrx, W_ESTADO_HABILITADO, w_nro_renglones, v_nro_reng,v_rln_codrln, v_estado,v_idtabla,v_tipocmp integer;
define w_rln_numero        like gen_renglon.rln_numero;
define w_monto_bs, w_tot_debe, w_tot_haber,v_monto_mn like pre_pagocuota.pago_importe_capital;
define v_tipoproc varchar(30);

	let REGISTRO_TRANSITORIO_GARANTIAS=8;
    let REGISTRO_CONTABLE_DESEMBOLSOS_EPNES=1;
    let REGISTRO_CONTABLE_DESEMBOLSOS_MEFP=2;
    LET REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA=9;
    LET REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA=10; 
	LET REG_CONT_PAGO_INTERESES_EPNE_MEFP=6;
	LET REG_CONT_PAGO_INTERESES_YPFB_FNDR=7;
    let w_estado_ini_cmp = "P";     
    let W_ESTADO_HABILITADO = 1;

    if TRIM(p_usuario) IS NULL OR LENGTH(TRIM(p_usuario)) = 0 then
       Raise Exception  -746, 0, "GENCMPB:El valor proporcionado para el parametro usuario no es valido (p_usuario).";
    end if   

	let v_estado = null;
	let w_nro_comprob = null;
	let v_coddsb = null;
	let v_idtabla = null;
	
	select tipoproc,idtabla,codcred, codmod, coddsb, tipocmp,estado,
	nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto,monto_mn, glosa
	into v_tipoproc,v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_estado,
	v_nro_comprob,v_cve_tipo_comprob, v_fecha_cont,v_fec_vcto, v_monto_mn, v_glosa
	from table(p_get_estado_proceso_conta(p_codcmp, nvl(p_idtabla,0), nvl(p_codcred, 0),p_codmod, null,null, null, null)) 
		t(tipoproc,idtabla,codcred, codmod, coddsb,tipocmp,estado,
			nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto, monto_mn, glosa);

	if v_idtabla is null or v_estado != 1 then   
       Raise Exception  -746, 0, "GENCMPB:Registro inexistente id: " || p_idtabla || " tipocmp: " || p_codcmp ||  " o se encuentra en estado invalido " || v_estado;
    end if
	
    if length(trim(nvl(v_nro_comprob,""))) > 0 then
		Raise Exception -746, 0, "GENCMPB:Operacion contable id: "|| p_idtabla || " tipocmp: " || p_codcmp || " con numero de comprobante [" || v_nro_comprob || "] ";
	end if	    

	if p_codcmp=3 then 
		let v_sgte_devcont = null;
		
		select min(prc_fecha_2) 
		into v_sgte_devcont
		from pre_prcconta 
		where prc_codcred = p_codcred 
		and prc_codmod = p_codmod
		and prc_codcmp = p_codcmp
		AND prc_fecha_2 > v_fec_vcto
		and length(trim(nvl(prc_nro_comprob, ""))) > 2
		and prc_nro_centro > 0	
		and prc_estado in (1,2,3);
		
		if v_sgte_devcont is not null then
			Raise Exception -746, 0, "GENCMPB:Existe devengamientos posteriores en fecha "|| v_sgte_devcont || " aprobados cred: " || p_codcred || ", no puede continuar.";
		end if
    end if
    
    let v_cve_tipo_comprob = null;
    
  	let v_cod_esquema = p_get_datos_coin(p_idtabla, p_codcmp, null);
  -- recupera el texto que registro que se utilizara para la glosa, realiza una consulta a la tabla "gen_comprobante"
     select cmp_esquema, cmp_centro, cmp_tipo, cmp_dev_real, cmp_estado
     into w_cmp_esquema, w_cmp_centro, v_cve_tipo_comprob, w_cmp_dev_real, w_cmp_estado
      from gen_comprobante
      where cmp_codcmp = p_codcmp;    
	
    if not w_cmp_estado = W_ESTADO_HABILITADO then
       Raise Exception  -746, 0, "El tipo de comprobante especificado no esta habilitado. tipo: " || p_codcmp;
    end if
	let v_cod_esquema = nvl(v_cod_esquema, w_cmp_esquema);	
    -- obtiene fecha del COIN y compara con la fecha de rrgistro del proceso 
	select fecha_dia 
    into w_fecha_coin 
    from contbcb@bcbux02:dia   
	where cve_estado_dia = "A";

    if w_fecha_coin is null then   
       Raise Exception  -746, 0, "No existe Fecha habilitada en COIN ";
    end if   
    
	let w_nro_comprob = null;    
	-- obtener datos del header del comprobante
    Call p_get_header_comprobante(w_fecha_coin, w_cmp_centro, p_usuario, v_cve_tipo_comprob) 
    	returning w_nro_comprob, w_gestion, w_nro_periodo, w_nro_dia, w_fecha_dia, w_cod_unidad, w_factor_conv_us_m;
	
    let w_gestion = year(w_fecha_coin);
   	let w_nro_periodo = month(w_fecha_coin);
   	let w_nro_dia = day(w_fecha_coin);          
 
    Insert Into contbcb@bcbux02:comprobante (nro_centro, cve_tipo_comprob, nro_comprob, gestion, nro_periodo, nro_dia, fecha_valor, 
         factor_conv_us_mn, glosa_comprob, cod_esquema,cve_subesquema, nro_operacion, cve_estado_comprob,
         cod_usuario, fecha_hora, estacion, nro_aprobacion, cod_unidad, cve_dev_real) 
	Values (w_cmp_centro, v_cve_tipo_comprob, w_nro_comprob, w_gestion, w_nro_periodo, w_nro_dia, null,
         w_factor_conv_us_m, v_glosa, v_cod_esquema, null, 0, w_estado_ini_cmp,
         p_usuario, current, p_estacion, null, w_cod_unidad, w_cmp_dev_real);
                                    
	-- Generar Renglones
	call p_generar_renglon_bonos(p_idtabla, p_codcmp,p_codcred, p_codmod, 
	w_cmp_centro, v_cve_tipo_comprob, w_nro_comprob, w_gestion, w_nro_periodo, w_nro_dia, 
	p_usuario, p_estacion);

	-- ajuste de diferencial 
	select nvl(sum(monto_mn), 0) 
	into w_tot_debe  
	from contbcb@bcbux02:reng_comprob r
	where r.nro_centro  = w_cmp_centro 
	and r.cve_tipo_comprob = v_cve_tipo_comprob
	and r.nro_comprob  = w_nro_comprob
	and r.cve_debe_haber   = "D";
	
	select nvl(sum(monto_mn), 0) 
	into w_tot_haber  
	from contbcb@bcbux02:reng_comprob r
	where nro_centro       = w_cmp_centro
	and r.cve_tipo_comprob = v_cve_tipo_comprob
	and r.nro_comprob      = w_nro_comprob
	and r.cve_debe_haber   = "H";
	
	if nvl(w_tot_debe,0) <= 0 or nvl(w_tot_haber,0) <= 0 then
		raise exception -746,0,"Operacion no genero los reglones suficientes, id: " || p_idtabla || " tipocmp: "|| p_codcmp;
	end if
	
	if w_tot_debe <> w_tot_haber then
	    let w_monto_bs = w_tot_debe - w_tot_haber;
		
		select max(nro_reng)
		into w_nro_renglones
		from contbcb@bcbux02:reng_comprob r
		where nro_centro       = w_cmp_centro
		and r.cve_tipo_comprob = v_cve_tipo_comprob
		and r.nro_comprob      = w_nro_comprob;
	
		call contbcb@bcbux02:ajusta_dif_cambiario(w_cmp_centro, v_cve_tipo_comprob, w_nro_comprob, w_nro_renglones, w_monto_bs);
	end if;

	if p_codcmp=REGISTRO_TRANSITORIO_GARANTIAS then 
	      -- actualizar datos del proceso en la tabla pre_registrogarantias
		  update pre_registrogarantias
	      set fecha = w_fecha_coin,
	      nro_comprobante_coin = w_nro_comprob,
	      audit_usuario_genera = p_usuario,
	      audit_host_genera = p_estacion,
	      audit_fechahora_genera = current,
	      cve_tipo_comprob = v_cve_tipo_comprob
	      where id = p_idtabla
			and rgg_codcmp = p_codcmp; 
    elif p_codcmp = REGISTRO_CONTABLE_DESEMBOLSOS_EPNES or p_codcmp=REGISTRO_CONTABLE_DESEMBOLSOS_MEFP then
    
		update pre_desembolso_detalle
		set fecha = w_fecha_coin,
	    nro_comprobante_coin = w_nro_comprob,
		audit_usuario_genera = p_usuario,
	    audit_host_genera = p_estacion,
	    audit_fechahora_genera = current,
	      cve_tipo_comprob = v_cve_tipo_comprob       
	    where id = p_idtabla
		and pds_codcmp = p_codcmp; 
    elif p_codcmp=REGISTRO_CONTABLE_INGRESO_CUSTODIA_BONOS_TESORERIA then 
            -- actualizar datos del proceso en la tabla pre_custodia_garantia
        update pre_custodia_garantia
      	set fecha = w_fecha_coin,
        nro_comprobante_coin = w_nro_comprob,
		audit_usuario_genera = p_usuario,
	    audit_host_genera = p_estacion,
	    audit_fechahora_genera = current,        
	      cve_tipo_comprob = v_cve_tipo_comprob       
        where id = p_idtabla; 
    elif p_codcmp=REGISTRO_CONTABLE_RETIRO_CUSTODIA_BONOS_TESORERIA then 
            -- actualizar datos del proceso en la tabla pre_retiro_garantia
        update pre_retiro_garantia
        set fecha = w_fecha_coin,
		nro_comprobante_coin = w_nro_comprob,
		audit_usuario_genera = p_usuario,
	    audit_host_genera = p_estacion,
	    audit_fechahora_genera = current,		
	      cve_tipo_comprob = v_cve_tipo_comprob       
        where id = p_idtabla
		and rtg_codcmp = p_codcmp; 
    elif p_codcmp = 3 then
	     update pre_prcconta
	        set prc_nro_centro = w_cmp_centro,  
	            prc_cve_tipo_comprob = v_cve_tipo_comprob,
	            prc_nro_comprob = w_nro_comprob,
	            prc_fecha = w_fecha_coin,
			    prc_auditusrgen = p_usuario,
			    prc_auditfhogen = current,
			    prc_auditwstgen = p_estacion
	      where prc_codprc = p_idtabla
			and prc_codcmp = p_codcmp;
		
    elif p_codcmp in (4,5,6,7) then 
            -- actualiza datos del proceso en la tabla pre_pagocuota
      	update pre_pagocuota
      	set nro_comprobante_coin = w_nro_comprob,
      	fecha = w_fecha_coin,
    	audit_usuario_genera = p_usuario,
	    audit_host_genera = p_estacion,
	    audit_fechahora_genera = current,      	
	      cve_tipo_comprob = v_cve_tipo_comprob
  		where id = p_idtabla
    	and pcu_tipocmp = p_codcmp;
		
  		select pcu_numtrx
  		into v_pcu_numtrx
  		from pre_pagocuota
  		where id=p_idtabla;
  		
    	UPDATE pre_tramon 
		set tmo_numcta = w_nro_comprob,
		tmo_glosa = v_glosa
		where tmo_codmod = p_codmod
		and tmo_codcred = p_codcred 
		and tmo_coddsb = v_coddsb
		and tmo_numtrx = v_pcu_numtrx
		and tmo_fecvencuo = v_fec_vcto;
    end if
	CALL p_pre_act_1erpagovenc(p_codcred, p_codmod, v_coddsb, w_fecha_coin, p_idtabla, p_codcmp, 3);    
    return w_nro_comprob; 
          
end procedure;

