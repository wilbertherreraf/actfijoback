


DROP function IF EXISTS d_creditos.f_pp_sum_importetrx;
create function d_creditos.f_pp_sum_importetrx(p_codcred integer, p_codmod integer, p_coddsb integer, p_fechaini date, p_fechafin date, p_tipocuo integer, p_tipotrx integer, p_tipocob integer)
returning decimal(20,2) as VALOR, decimal(20,2) as VALORPEND

{
wherrera 20260505 se reformula la funcion, determina el monto de una transaccion
}
define v_sum_pp,v_sum_pppend like pre_planpagos.cuo_valor;
define v_sum_pp_pa,v_sum_pppend_pa like pre_planpagos.cuo_valor;
define v_sum_pp_df2,v_sum_pppend_df2 like pre_planpagos.cuo_valor;
define v_sum_pp_df,v_sum_pppend_df like pre_planpagos.cuo_valor;
define C_TIPOCUO_INT, C_TIPOTRX_COB, v_tipotrx, v_contar integer;

let v_sum_pp_df2 = 0;
let v_sum_pp_pa = 0;
let v_sum_pp_df = 0;
let v_sum_pp = 0;
let v_sum_pppend = 0;
let v_sum_pppend_pa = 0;
let v_sum_pppend_df2 = 0;
let v_sum_pppend_df = 0;

let C_TIPOCUO_INT = 2;
let C_TIPOTRX_COB = 2;

    let p_fechaini = nvl(p_fechaini, mdy(1,1,1980));
    let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));
    let v_tipotrx = nvl(p_tipotrx, 2); 
    let p_tipocob = nvl(p_tipocob, 0);
    let v_contar = 0;
    
    IF p_tipocob = 2 then
    -- cobro de k e i
        select nvl(sum(cuo_valor), 0) , nvl(sum(cuo_valorpend), 0) 
        INTO v_sum_pp, v_sum_pppend
        from pre_planpagos 
        where cuo_codcred = p_codcred 
        and cuo_codmod = p_codmod 
        and cuo_fecvencuo between p_fechaini and p_fechafin        
        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
        and cuo_coddsb > 0
        and cuo_tipocuo = nvl(p_tipocuo, cuo_tipocuo)
    	and cuo_tipocuo in (1,2);
        
    elif p_tipocob = 3 then
    -- anticipado
        select count(1) 
        INTO v_contar
        from pre_planpagos 
        where cuo_codcred = p_codcred 
        and cuo_codmod = p_codmod 
        and cuo_fecvencuo <= p_fechafin        
        and cuo_coddsb > 0
        AND cuo_tipocuo IN (12,22);
    
    	if v_contar > 0 then
	        select nvl(sum(cuo_valor), 0) , nvl(sum(cuo_valorpend), 0) 
	        INTO v_sum_pp, v_sum_pppend
	        from pre_planpagos 
	        where cuo_codcred = p_codcred 
	        and cuo_codmod = p_codmod 
	        and cuo_fecvencuo between p_fechaini and p_fechafin        
	        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
	        and cuo_coddsb > 0
	        and cuo_tipocuo = nvl(p_tipocuo, cuo_tipocuo)
	        AND cuo_tipocuo IN (12,22);
    	end if
    elif p_tipocob = 4 then

        select count(1) 
        INTO v_contar
        from pre_planpagos 
        where cuo_codcred = p_codcred 
        and cuo_codmod = p_codmod 
        and cuo_fecvencuo <= p_fechafin        
        and cuo_coddsb > 0
        and cuo_valor > 0
        and cuo_tipotrx = 4;
    	
    	if v_contar > 0 then
    		-- diferido a fecha origen    	
	    	if nvl(p_tipotrx, 4) = 4 then 
		        select nvl(sum(cuo_valor), 0) , nvl(sum(cuo_valorpend), 0) 
		        INTO v_sum_pp, v_sum_pppend
		        from pre_planpagos 
		        where cuo_codcred = p_codcred 
		        and cuo_codmod = p_codmod 
		        and cuo_fecvencuo between p_fechaini and p_fechafin
		        and cuo_fecvencuo < cuo_fecfincuo
		        and cuo_fecfincuo > p_fechafin
		        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
		        and cuo_coddsb > 0
				and cuo_tipocuo = nvl(p_tipocuo, cuo_tipocuo)
		        and cuo_tipocuo in (1,2)        
		        AND cuo_tipoacu IN (14,24)
		    	and cuo_tipotrx = 4;
	    	end if
	    -- diferidos a fecha cobro
	    	if nvl(p_tipotrx, 0) = 2 then
		        select count(1),nvl(sum(cuo_valor), 0) , nvl(sum(cuo_valorpend), 0) 
		        into v_contar,v_sum_pp_df2, v_sum_pppend_df2 
		        from pre_planpagos 
		        where cuo_codcred = p_codcred 
		        and cuo_codmod = p_codmod 
		        and cuo_fecvencuo between p_fechaini and p_fechafin
		        and cuo_fecvencuo = cuo_fecfincuo
		        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
		        and cuo_coddsb > 0
		        and cuo_tipocuo = nvl(p_tipocuo, cuo_tipocuo)
		        AND cuo_tipocuo IN (14,24);
		        
		        if v_contar = 0 then
		        -- para creditos anteriores a 2026-05
		        -- no existe registro de diferido en fecha de vencimiento
			        select nvl(sum(cuo_valor), 0) , nvl(sum(cuo_valorpend), 0) 
			        INTO v_sum_pp_df, v_sum_pppend_df
			        from pre_planpagos 
			        where cuo_codcred = p_codcred 
			        and cuo_codmod = p_codmod 
			        and cuo_fecfincuo between p_fechaini and p_fechafin
			        and cuo_fecvencuo < cuo_fecfincuo
			        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
			        and cuo_coddsb > 0
			        and cuo_tipocuo = nvl(p_tipocuo, cuo_tipocuo)
			        and cuo_tipocuo in (1,2)
			        AND cuo_tipoacu IN (14,24)
			    	and cuo_tipotrx = 4;
		        end if
	    	end if
		end if
    else
    	
        select nvl(sum(cuo_valor), 0) , nvl(sum(cuo_valorpend), 0) 
        INTO v_sum_pp, v_sum_pppend
        from (
	        select cuo_tipocuo, nvl(cuo_tipoacu, cuo_tipocuo) cuo_tipoacu,
	        nvl(cuo_tipotrx, 2) cuo_tipotrx, 
	        cuo_valor,cuo_valorpend
	        from pre_planpagos 
	        where cuo_codcred = p_codcred 
	        and cuo_codmod = p_codmod 
	        and cuo_fecvencuo between p_fechaini and p_fechafin        
	        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
	        and cuo_coddsb > 0
	        and cuo_tipocuo = nvl(p_tipocuo, cuo_tipocuo)
    	)
        where cuo_tipotrx = nvl(p_tipotrx, cuo_tipotrx);
	END IF 
	
    let v_sum_pp = v_sum_pp + v_sum_pp_pa + v_sum_pp_df + v_sum_pp_df2;
    let v_sum_pppend = v_sum_pppend + v_sum_pppend_pa + v_sum_pppend_df + v_sum_pppend_df2;
return v_sum_pp, v_sum_pppend;
end function;


