

DROP procedure IF EXISTS d_creditos.p_generar_operacion;
create procedure d_creditos.p_generar_operacion(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_fechaoper date, 
    p_accion integer, p_coduser varchar(100), P_ESTACION VARCHAR(100))
{
wherrera    2021-10-06  procedimiento generico de ejecucion de tareas, vease el codigo de catalogo 1 para ver la clasificacion, o el codigo puede ser creado a requerimiento
wherrera 20260505 se adiciona el proceso de cobro de pagos anticipados
}
    define err_num, err_nro integer;
    define err_msg varchar(235);    

    define C_TIPOTRX_PANTI, C_TIPOCOB_DSB, C_TIPOCOB_COB, C_TOPER_DSB_PRIN, C_TOPER_COB_PRINCINT integer;

    define C_TIPOCOB_GRAL, C_TIPOTRA_DSB, C_TIPOTRA_COB, C_TIPOCOB_APLC_CAPINT integer;
    define v_tmo_t pre_tramon_t;
    
    let C_TOPER_DSB_PRIN = 1;
    let C_TOPER_COB_PRINCINT = 2;
    LET C_TIPOTRX_PANTI = 3;    
    LET C_TIPOCOB_COB = 2;
    LET C_TIPOCOB_DSB = 1;
    LET C_TIPOCOB_APLC_CAPINT = 3;
    LET C_TIPOCOB_GRAL = 0;
    
BEGIN
    ON EXCEPTION  SET err_num, err_nro, err_msg  -- trap all errors
    END EXCEPTION with resume

    --call p_srvdeu_initlog(p_coduser, p_estacion);  
    --trace procedure; 
end
BEGIN
    ON EXCEPTION  SET err_num, err_nro, err_msg  -- trap all errors
        call p_log_error(err_num, err_nro, err_msg, null);
        raise exception err_num, err_nro, err_msg ;
    END EXCEPTION    
    --let v_tmo_t = f_genop_recdatos_pre(p_codcred, p_codmod, p_coddsb, p_fecha, p_fechaoper, p_accion, p_coduser, P_ESTACION);    
    
    if p_accion = C_TOPER_DSB_PRIN then
    	let v_tmo_t = f_genop_recdatos_pre(p_codcred, p_codmod, p_coddsb, p_fecha, p_fechaoper, p_accion, p_coduser, P_ESTACION);
    
        -- crear operacion de desembolso
        LET v_tmo_t.tmo_tipotra = C_TOPER_DSB_PRIN;
        LET v_tmo_t.tmo_tipocob = C_TIPOCOB_GRAL;
        call p_genop_crear_dsb(v_tmo_t);
    elif p_accion = C_TOPER_COB_PRINCINT then
        let v_tmo_t = f_genop_recdatos_pre(p_codcred, p_codmod, p_coddsb, p_fecha, p_fechaoper, p_accion, p_coduser, P_ESTACION);

    	update pre_planpagos
    	set cuo_tipotrx = C_TIPOCOB_COB 
    	where cuo_codcred = p_codcred
    	and cuo_codmod = p_codmod
    	and cuo_coddsb > 0
    	and cuo_fecvencuo = p_fecha
    	and cuo_valorpend > 0
    	and cuo_tipocuo in (1,2)
    	and cuo_tipotrx is null;
    	
        LET v_tmo_t.tmo_tipotra = C_TOPER_COB_PRINCINT;
        LET v_tmo_t.tmo_tipocob = C_TIPOCOB_APLC_CAPINT;    
        call p_genop_crear_venc(v_tmo_t);
    elif p_accion = C_TIPOTRX_PANTI then    
    	-- pagos anticipados
		let v_tmo_t = f_genop_recdatos_pre(p_codcred, p_codmod, p_coddsb, p_fecha, p_fechaoper, p_accion, p_coduser, P_ESTACION);

    	update pre_planpagos
    	set cuo_tipotrx = C_TIPOCOB_COB 
    	where cuo_codcred = p_codcred
    	and cuo_codmod = p_codmod
    	and cuo_coddsb > 0
    	and cuo_fecvencuo = p_fecha
    	and cuo_valorpend > 0
    	and cuo_tipocuo in (1,2)
    	and cuo_tipotrx is null;

    	update pre_planpagos
    	set cuo_tipotrx = C_TIPOTRX_PANTI 
    	where cuo_codcred = p_codcred
    	and cuo_codmod = p_codmod
    	and cuo_coddsb > 0
    	and cuo_fecvencuo = p_fecha
    	and cuo_valorpend > 0
    	and cuo_tipocuo in (12,22)    	
    	and cuo_tipotrx is null;
    	
        LET v_tmo_t.tmo_tipotra = C_TIPOTRX_PANTI;
        LET v_tmo_t.tmo_tipocob = C_TIPOCOB_APLC_CAPINT;    
        call p_genop_crear_venc(v_tmo_t);    
    elif p_accion = 5 then        
        call p_generar_oper_panti_dsb(p_codmod, p_codcred, p_fechaoper, p_coduser, P_ESTACION);    
    else 
		let v_tmo_t = f_genop_recdatos_pre(p_codcred, p_codmod, p_coddsb, p_fecha, p_fechaoper, p_accion, p_coduser, P_ESTACION);
        
    	update pre_planpagos
    	set cuo_tipoacu = cuo_tipocuo 
    	where cuo_codcred = p_codcred
    	and cuo_codmod = p_codmod
    	and cuo_coddsb > 0
    	and cuo_fecvencuo = p_fecha
    	and cuo_valorpend > 0
    	and cuo_tipocuo > 0
    	and cuo_tipotrx > 0
    	and cuo_tipoacu is null;
        
        LET v_tmo_t.tmo_tipotra = p_accion;
        LET v_tmo_t.tmo_tipocob = C_TIPOCOB_GRAL;    
		call p_genop_crear_venc(v_tmo_t);
    end if

END
    --call p_log_finlog();
end procedure;


