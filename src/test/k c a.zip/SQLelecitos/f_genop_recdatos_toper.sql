



drop function if exists d_creditos.f_genop_recdatos_toper;
create function d_creditos.f_genop_recdatos_toper(p_tmo_t pre_tramon_t, p_cob_t pre_cobros_t) 
            returning pre_cobros_t
{
wherrera    2021-10-05  determina la logica de la relacion entre el tipo de operacion del sistema y el tipo de operacion del registro en operacon
			2026-04-01 
}
    define C_TOPER_DSB_PRIN, C_TOPER_COB_PRINCINT integer;
    DEFINE C_CODTAB_OPERMAYOR, C_TIPOTRX_DSB, C_TIPOTRX_COB, C_TIPOTRA_REV_DSB, C_TIPOTRA_REV_COB, C_TIPOTRX_PACAP, C_TIPOTRX_PAINT INTEGER;
    DEFINE C_TIPOCOB_PANTI_CAP, C_TIPOCOB_PANTI_INT INTEGER;
    define C_TIPOTRA_DSB, C_TOPER_REVERSA_DSB, C_TOPER_REVERSA_COB integer;
    DEFINE C_TIPOCOB_DSB, C_TIPOCOB_COB, C_TIPOTRX_PANTI INTEGER;
    DEFINE C_TIPOTRX_DEVENG, C_TIPOTRX, C_TIPOTRX_DIFER, C_TIPOCOB_DIFCAP, C_TIPOCOB_DIFINT INTEGER;
    define C_TIPOCUO_CAP, C_TIPOCUO_INT integer;
    
    LET C_TIPOCOB_DSB = 1;
    LET C_TIPOCOB_COB = 2;
    LET C_TIPOTRX_PANTI = 3;
    let C_TOPER_DSB_PRIN = 1;
    let C_TOPER_COB_PRINCINT = 2;
    let C_TOPER_REVERSA_DSB = 20;
    let C_TOPER_REVERSA_COB = 21;
    let C_TIPOTRX_DSB = 1;
    let C_TIPOTRX_COB = 2;
    LET C_TIPOTRX_PACAP = 12;
    LET C_TIPOTRX_PAINT = 22;
    LET C_TIPOTRX_DIFER = 4;
    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
    LET C_TIPOTRA_DSB = 3;
    let C_TIPOCOB_PANTI_CAP = 12;
    let C_TIPOCOB_PANTI_INT = 22;
    LET C_TIPOCOB_DIFCAP = 14;
    LET C_TIPOCOB_DIFINT = 24;
    let C_CODTAB_OPERMAYOR = 1720;
    let C_TIPOTRX_DEVENG = 8;
    let C_TIPOTRX = 1705;
        
    let p_cob_t.cob_tabtipotrx = C_TIPOTRX;
    let p_cob_t.cob_codtab = C_CODTAB_OPERMAYOR;
    let p_cob_t.cob_tipotrx = nvl(p_cob_t.cob_tipotrx, p_tmo_t.tmo_tipotra);
    
    if p_tmo_t.tmo_tipotra = C_TIPOTRX_DSB then
        let p_cob_t.cob_codigo = C_TIPOTRA_DSB;
        let p_cob_t.cob_feccontab = p_tmo_t.tmo_fecvencuo;
        let p_cob_t.cob_fechproc = p_tmo_t.tmo_fecvencuo;
    	let p_cob_t.cob_tipotrx = p_tmo_t.tmo_tipotra;
    
    elif p_tmo_t.tmo_tipotra = C_TIPOTRX_COB then
        if p_cob_t.cob_tipotrx = C_TIPOTRX_COB then    
	        if p_cob_t.cob_tipocuo in (C_TIPOCUO_CAP, C_TIPOCOB_DIFCAP) then
	            let p_cob_t.cob_codigo = C_TIPOCUO_CAP;
	        elif p_cob_t.cob_tipocuo in (C_TIPOCUO_INT, C_TIPOCOB_DIFINT) then
	            let p_cob_t.cob_codigo = C_TIPOCUO_INT;
	    	else 
	    		let p_cob_t.cob_codigo = p_cob_t.cob_tipocuo;
	        end if
	    elif p_cob_t.cob_tipotrx = C_TIPOTRX_PANTI then
	    	let p_cob_t.cob_codigo = p_cob_t.cob_tipocuo;
    	elif p_cob_t.cob_tipotrx = C_TIPOTRX_DIFER then
    		let p_cob_t.cob_codigo = decode(p_cob_t.cob_tipocuo, 1,14,2,24,p_cob_t.cob_codigo);
	    else
	    	let p_cob_t.cob_codigo = p_cob_t.cob_tipocuo;
   		end if
   		
        let p_cob_t.cob_feccontab = p_tmo_t.tmo_fecvencuo;
        let p_cob_t.cob_fechproc = p_tmo_t.tmo_fecvencuo;        
        
    elif p_tmo_t.tmo_tipotra = C_TIPOTRX_PANTI then
    	if p_cob_t.cob_tipotrx = C_TIPOTRX_PANTI then
    	-- el mismo
    		let p_cob_t.cob_codigo = p_cob_t.cob_tipocuo;
    	elif p_cob_t.cob_tipotrx = C_TIPOTRX_DEVENG then
	    	let p_cob_t.cob_codigo = p_cob_t.cob_tipocuo;    	
	    else
    		-- no pertenece a la operacion	    
	    	let p_cob_t.cob_codigo = null;
		end if
        let p_cob_t.cob_feccontab = p_tmo_t.tmo_fecvencuo;
        let p_cob_t.cob_fechproc = p_tmo_t.tmo_fecvencuo;            
        
    elif p_tmo_t.tmo_tipotra = C_TIPOTRX_DIFER then
    	if p_cob_t.cob_tipotrx = C_TIPOTRX_DIFER then
	        if p_cob_t.cob_tipocuo = C_TIPOCUO_CAP then
	            let p_cob_t.cob_codigo = C_TIPOCOB_DIFCAP;
	        elif p_cob_t.cob_tipocuo = C_TIPOCUO_INT then            
	            let p_cob_t.cob_codigo = C_TIPOCOB_DIFINT;
	        end if
	    else
	    	if p_cob_t.cob_tipotrx = C_TIPOTRX_COB then
	    		let p_cob_t.cob_codigo = p_cob_t.cob_tipocuo;
    		else 
    		-- no pertenece a la operacion
    			let p_cob_t.cob_codigo = null;
    		end if
	    end if
        let p_cob_t.cob_feccontab = p_tmo_t.tmo_fecvencuo;
        let p_cob_t.cob_fechproc = p_tmo_t.tmo_fechproc;
    else
		let p_cob_t.cob_codigo = p_cob_t.cob_tipocuo;    
        let p_cob_t.cob_feccontab = p_tmo_t.tmo_fecvencuo;
        let p_cob_t.cob_fechproc = p_tmo_t.tmo_fecvencuo;        
    end if

    let p_cob_t.cob_codmon = p_tmo_t.tmo_codmon;
    
    return p_cob_t;
end function;



