

DROP function IF EXISTS d_creditos.f_rpo_pp_consodet;
create function d_creditos.f_rpo_pp_consodet(p_codcredin integer, p_codmod integer, p_coddsb integer, p_fechaini date, p_fechafin date)
returning integer AS codmod, integer as codcred, date as fechaant, date as fechavencuo, date as fechaefect, 
            decimal(20,2) as saldoinicio,  decimal(20,2) as amortizacion, decimal(20,2) as amortizacion_saldo, 
            decimal(20,2) as interes, decimal(20,2) as interes_saldo, integer as dias, float as tasa, decimal(20,2) as cuota, 
            decimal(20,2) as capital_amort, decimal(20,2) as interes_amort,
            decimal(20,2) as capital_difer, decimal(20,2) as interes_difer,
            decimal(20,2) as capital_efect, decimal(20,2) as interes_efect,
            decimal(20,2) as saldo_efect, decimal(20,2) as saldo_prog,
            decimal(20,2) as mnt_desemb, decimal(20,2) as mnt_nodesemb,
            decimal(20,2) as mnt_noprog
--returning integer

    define v_vpp_codcred, v_vpp_codmod, v_vpp_codmodtmp, v_vpp_coddsb, v_vpp_tipocuo, v_vpp_tipoacu, v_vpp_tipotrx, v_vpp_trxstaau integer;
    define v_vpp_fecvencuo date; 
    define v_vpp_valor, v_vpp_valorpend decimal(20,2); 
    define v_vpp_tablaorig varchar(250);
    define v_first, v_codreporte, v_cuo_codcuo integer;
    define v_appfound_t, v_app_t aux_planpagos_t;
    define C_TIPOCUO_CAP, C_TIPOCUO_INT integer;
    define v_fechaant, v_fechaini, v_fechafin date; 
    define v_int_gracia_incl, v_sum_cap, v_sum_capital, v_sum_capitalpend, v_sum_interes, v_sum_interespend like aux_planpagos.acu_valor;
    define V_MNT_DSB_ANT, v_saldok  like aux_planpagos.acu_valor;
    define v_fecultrepro, v_fecprim_venc, v_rds_fecini, v_rds_feciniint, v_fec_ultvenc date;
    define D_PRIMVCTO, D_INI_PERGRACIA, D_FIN_PERGRACIA, v_dsb_min_fecini, v_dsb_min_feciniint date;
    define v_pre_codmod, v_pre_codcred, v_isplan_auto, v_isgracia integer;
    define C_FECEVAL_FECVENCUO, C_FECEVAL_FECPROC integer;
    define v_int_amort, v_cap_amort, v_difer_no_incl, v_difer_a_cobrar, v_total_cuota  like aux_planpagos.acu_valor;
    define p_codcred integer;
    define v_mnt_noprog, v_capital_difer, v_interes_difer, v_capital_efect, v_interes_efect, v_saldo_efect, v_saldo_prog, v_mnt_desemb, v_mnt_nodesemb  like aux_planpagos.acu_valor;

    
    LET C_TIPOCUO_CAP = 1;
    LET C_TIPOCUO_INT = 2;
    let C_FECEVAL_FECVENCUO = 1;
    let C_FECEVAL_FECPROC = 2;
    let v_codreporte = f_getsession();
    let v_codreporte = f_getsession();        
    let p_fechaini = nvl(p_fechaini , mdy(1,1,1980));
    let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));
    
    let v_fechaini = null;
    let v_fechafin = mdy(1,1,3000);

    foreach 
        select pre_codmod, pre_codcred
        into p_codmod, p_codcred
        from pre_prestamos
        where pre_codcred = nvl(p_codcredin, pre_codcred)
        --and pre_fecemi <= p_fechafin
        and exists (select 1
        from pre_planpagos
        where cuo_fecvencuo <= p_fechafin
        and cuo_codcred = pre_codcred
        and cuo_codmod = pre_codmod
        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
        and cuo_coddsb > 0)
        order by pre_codcred
        
    let v_app_t = f_init_app_t();
    let v_fechaini = null;
    let v_codreporte = 0;
    LET v_sum_cap = 0;
    let v_fechaant = f_dsb_fecmin(p_codmod, p_codcred, null);
    let D_INI_PERGRACIA = null;
    let D_FIN_PERGRACIA = null;
    let v_first = 0;
    let v_isgracia = 0;
    let v_int_gracia_incl = 0;
    let v_total_cuota = 0;
    let v_sum_capital = 0;
                
    foreach
        select cuo_fecvencuo, cuo_fecfincuo, sum(vpp_capital), sum(vpp_capitalpend), sum(vpp_interes), sum(vpp_interespend)
        into v_app_t.acu_fecvencuo, v_app_t.acu_fecfincuo, v_sum_capital, v_sum_capitalpend, v_sum_interes, v_sum_interespend
        
        from (
        select cuo_fecvencuo, nvl(cuo_fecfincuo,cuo_fecvencuo) cuo_fecfincuo, sum(cuo_valor) vpp_capital, sum(cuo_valorpend) vpp_capitalpend, 0 vpp_interes , 0 vpp_interespend
                from pre_planpagos
                where cuo_codcred = p_codcred
                and cuo_coddsb > 0
                and cuo_codmod = p_codmod
                and cuo_tipocuo = C_TIPOCUO_CAP
                and cuo_fecvencuo <= p_fechafin
                and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
                group by 1,2
        union 
        select cuo_fecvencuo, nvl(cuo_fecfincuo,cuo_fecvencuo), 0, 0, sum(cuo_valor), sum(cuo_valorpend)
                from pre_planpagos
                where cuo_codcred = p_codcred
                and cuo_codmod = p_codmod
                and cuo_tipocuo = C_TIPOCUO_INT
                and cuo_coddsb > 0
                and cuo_fecvencuo <= p_fechafin
                and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
                group by 1,2
                )
        group by 1,2
        order by cuo_fecvencuo
            let v_isplan_auto = 3;
            let v_int_amort = 0;
            let v_cap_amort = 0;

            call f_fec_primervenc(p_codcred, p_codmod, v_app_t.acu_fecvencuo, v_isplan_auto) returning v_fecultrepro, v_fecprim_venc, v_rds_fecini, v_rds_feciniint, v_fec_ultvenc;
            
            if v_first = 0 then
                let D_PRIMVCTO = v_app_t.acu_fecvencuo;
                let v_first = 1;
                
                select min(dsb_fecini) , min(dsb_feciniint) 
                into v_dsb_min_fecini, v_dsb_min_feciniint
                from pre_desemb 
                where dsb_codmod = p_codmod
                and dsb_codcred = p_codcred;
                
                if nvl(v_rds_feciniint, v_dsb_min_feciniint) > v_app_t.acu_fecvencuo then
                    let D_INI_PERGRACIA = v_app_t.acu_fecvencuo;
                end if
                
                if nvl(v_rds_feciniint, v_dsb_min_feciniint) > nvl(D_INI_PERGRACIA, v_app_t.acu_fecvencuo) then
                    let D_FIN_PERGRACIA = nvl(v_rds_feciniint, v_dsb_min_feciniint);
                end if
            
                let D_FIN_PERGRACIA = nvl(D_FIN_PERGRACIA, v_app_t.acu_fecvencuo);
                let D_INI_PERGRACIA = nvl(D_INI_PERGRACIA, D_FIN_PERGRACIA); 
                
                if v_app_t.acu_fecvencuo >= p_fechaini then
                    let v_fechaini = v_app_t.acu_fecvencuo;
                end if
            else
                if v_fecultrepro is not null and v_fecultrepro >= v_fechaant then
                    let D_INI_PERGRACIA = v_app_t.acu_fecvencuo;
                    let D_FIN_PERGRACIA = v_app_t.acu_fecvencuo;
                end if
                
                if nvl(v_rds_feciniint, D_INI_PERGRACIA) > v_fechaant then
                    let D_INI_PERGRACIA = v_app_t.acu_fecvencuo;
                end if
                                
                if nvl(v_rds_feciniint, D_FIN_PERGRACIA) > nvl(D_INI_PERGRACIA, v_app_t.acu_fecvencuo) then
                    let D_FIN_PERGRACIA = nvl(v_rds_feciniint, D_FIN_PERGRACIA);
                end if
            
                let D_FIN_PERGRACIA = nvl(D_FIN_PERGRACIA, v_app_t.acu_fecvencuo);
                let D_INI_PERGRACIA = nvl(D_INI_PERGRACIA, D_FIN_PERGRACIA);                 
                
                if v_fechaini is null and v_app_t.acu_fecvencuo >= p_fechaini then
                    let v_fechaini = v_app_t.acu_fecvencuo;
                end if                
            end if
            
            if (v_app_t.acu_fecvencuo between D_INI_PERGRACIA and D_FIN_PERGRACIA) and v_app_t.acu_fecvencuo < D_FIN_PERGRACIA then
                let v_int_gracia_incl = v_int_gracia_incl + v_sum_interes;
                let v_isgracia = 1;
            else
                let D_INI_PERGRACIA = v_app_t.acu_fecvencuo;                 
                let D_FIN_PERGRACIA = v_app_t.acu_fecvencuo;
                let v_isgracia = 0;
            end if
            
            let V_MNT_DSB_ANT = f_getsumas_dsb(p_codmod, p_codcred, p_coddsb, null, v_app_t.acu_fecvencuo - 1);
            let v_saldok = V_MNT_DSB_ANT - v_sum_cap;

            let v_app_t.acu_tasa = f_gettasavigenteprest(p_codcred, p_codmod, v_fechaant);
            let v_app_t.acu_codcred = p_codcred;
            let v_app_t.acu_codmod = p_codmod;
            let v_app_t.acu_codmodorig = p_codmod;
            let v_app_t.acu_codmod = p_codmod;
            let v_app_t.acu_capital = v_saldok;
            let v_app_t.acu_valor = v_sum_capital;
            let v_app_t.acu_interes = v_sum_interes;
            let v_app_t.acu_cargos = v_sum_interespend;
            let v_app_t.acu_coddsb = p_coddsb;
            let v_app_t.acu_fecinicuo = v_fechaant;
            let v_app_t.acu_numcuo = v_app_t.acu_fecvencuo - v_fechaant;
            
            let v_capital_difer = f_cobrostipocob_fven(p_codcred, p_codmod, p_coddsb, v_app_t.acu_fecvencuo, v_app_t.acu_fecvencuo, C_FECEVAL_FECPROC, set{14});
            let v_interes_difer = f_cobrostipocob_fven(p_codcred, p_codmod, p_coddsb, v_app_t.acu_fecvencuo, v_app_t.acu_fecvencuo, C_FECEVAL_FECPROC, set{24});
            
            if v_isgracia = 0 then
               
                let v_int_amort = v_interes_difer;
                let v_int_amort = v_int_amort - f_cobrostipocob_fven(p_codcred, p_codmod, p_coddsb, v_app_t.acu_fecvencuo, v_app_t.acu_fecvencuo, C_FECEVAL_FECVENCUO, set{24});
                let v_int_amort = v_int_amort + v_int_gracia_incl + v_sum_interes;
                
                let v_cap_amort = v_capital_difer;
                let v_cap_amort = v_cap_amort - f_cobrostipocob_fven(p_codcred, p_codmod, p_coddsb, v_app_t.acu_fecvencuo, v_app_t.acu_fecvencuo, C_FECEVAL_FECVENCUO, set{14});
                let v_cap_amort = v_cap_amort + v_sum_capital;
                
                let v_total_cuota = v_cap_amort + v_int_amort;
            else
                --let v_total_cuota = v_difer_a_cobrar;
                let v_int_amort = v_interes_difer;
                let v_cap_amort = v_capital_difer;
                
                let v_total_cuota = v_cap_amort + v_int_amort;
                
                if v_app_t.acu_fecvencuo = v_app_t.acu_fecfincuo then
                    let v_app_t.acu_fecfincuo = D_FIN_PERGRACIA;
                end if
            end if
            
            let v_app_t.acu_valorpend = v_total_cuota;
            
            if v_fechaini is not null and v_app_t.acu_fecvencuo between v_fechaini and p_fechafin then
            
                let v_capital_efect = f_getamtcobroscap(p_codcred, p_codmod, p_coddsb, v_fechaant + 1, v_app_t.acu_fecvencuo, 1);
                let v_interes_efect = f_getamtcobroscap(p_codcred, p_codmod, p_coddsb, v_fechaant + 1, v_app_t.acu_fecvencuo, 2);
                let v_mnt_desemb = f_getamtdsb(p_codcred, p_codmod,p_coddsb, p_coddsb, v_app_t.acu_fecvencuo);
                let v_mnt_nodesemb = f_getamtundsb_vig(p_codcred, p_codmod, v_app_t.acu_fecvencuo);
                let v_saldo_efect = f_saldo_efect_k(p_codcred, p_codmod, p_coddsb, v_app_t.acu_fecvencuo - 1);
                let v_saldo_prog = f_acr_saldo_fecha(p_codcred, p_codmod, p_coddsb, v_app_t.acu_fecvencuo, 1) + 
                    f_cobrostipocob_fven(p_codcred, p_codmod, p_coddsb, null, v_app_t.acu_fecvencuo, C_FECEVAL_FECVENCUO, set{14}) - 
                    f_cobrostipocob_fven(p_codcred, p_codmod, p_coddsb, null, v_app_t.acu_fecvencuo, C_FECEVAL_FECPROC, set{14});
                let v_mnt_noprog = f_cobrostipocob_fven(p_codcred, p_codmod, p_coddsb, v_fechaant + 1, v_app_t.acu_fecvencuo, C_FECEVAL_FECVENCUO, set{13,23});
                
                let v_first = 2;
                
                return v_app_t.acu_codmodorig, v_app_t.acu_codcred, v_app_t.acu_fecinicuo, v_app_t.acu_fecvencuo, v_app_t.acu_fecfincuo, 
                v_app_t.acu_capital,  v_app_t.acu_valor, v_sum_capitalpend, 
                v_app_t.acu_interes, v_app_t.acu_cargos, v_app_t.acu_numcuo, v_app_t.acu_tasa, v_app_t.acu_valorpend, 
                v_cap_amort, v_int_amort ,
                v_capital_difer, v_interes_difer,
                v_capital_efect, v_interes_efect,
                v_saldo_efect, v_saldo_prog,
                v_mnt_desemb, v_mnt_nodesemb, v_mnt_noprog  with resume;
                
            end if
            
            if v_isgracia = 0 then
                let v_int_gracia_incl = 0;
            end if
            
            LET v_sum_cap = v_sum_cap + v_sum_capital;            
            let v_fechaant = v_app_t.acu_fecvencuo;
            
    	end foreach
    end foreach
 --   return v_codreporte;
end function;



