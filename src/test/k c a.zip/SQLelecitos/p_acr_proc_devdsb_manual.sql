


drop procedure IF EXISTS d_creditos.p_acr_proc_devdsb_manual;
create procedure d_creditos.p_acr_proc_devdsb_manual(p_tipoproceso integer, p_fechaini date, p_fechacierre date)
{
wherrera 2021.11.16     Devenga todos los prestamos desde una fecha procesos automaticos 

-- DESCRIPCION: Genera el devengado de todos los creditos registrados en el sistema 
-- PARAMETROS INGRESO: p_fechacierre date
--                     p_tipoproceso: 1 si es diario automatico
						2: ejecutado por el usuario
-- AUTOR: acanqui
-- CREACION: 2025-11-25

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| wherrera  | 20260505     |          | se modifica adicionando la fecha de ult devengamiento  y actualizacion de datos prestamo, en procesos automaticos no debew generar excepciones
											se ejecuta directamente el procedimiento de generacion de devengados
-----------------------------------------------------------------------------------------------------------------------------------------------------


}
define v_dsb_codmod, v_dsb_codcred, v_dsb_coddsb integer;
define v_feculttrx, v_fin_gestionant, v_ult_fec_acr, v_fechafinproc, p_fechafin , v_pge_feccierre, v_pge_fecultrep date;
define v_min_fecvencuo, v_max_fecvencuo,v_min_fecha_devengado date;
define p_codmod, C_PRESTATUS_CANC integer ;
define v_dsb_valorcuo like pre_prestamos.pre_monto;

    let v_fin_gestionant = mdy(12,31,year(current) -1);
    let p_fechacierre = nvl(p_fechacierre,date(current));
let C_PRESTATUS_CANC = 9;

    -- al cierre, se realiza la actualizacion de los prestamos en general
    foreach 
        select distinct dsb_codmod, dsb_codcred
        into v_dsb_codmod, v_dsb_codcred
        from pre_prestamos, pre_desemb
        where pre_codmod = dsb_codmod
        and pre_codcred = dsb_codcred
        and pre_saldo > 0
        and pre_montsusp > 0
        and pre_status != C_PRESTATUS_CANC
        order by dsb_codcred
        
		call p_updsumtrans(v_dsb_codmod, v_dsb_codcred, null, null, null, null, null);
    end foreach

    foreach 
        select distinct dsb_codmod, dsb_codcred
        into v_dsb_codmod, v_dsb_codcred
        from pre_prestamos, pre_desemb
        where pre_codmod = dsb_codmod
        and pre_codcred = dsb_codcred
        and dsb_valor > 0
        and dsb_undsb > 0
        and pre_status != C_PRESTATUS_CANC
        order by dsb_codcred

        if p_tipoproceso = 1 then
        	let v_fechafinproc = f_acr_gencronoycalc(v_dsb_codmod, v_dsb_codcred, p_tipoproceso, date(current), date(current));
		else
			let v_fechafinproc = f_acr_gencronoycalc(v_dsb_codmod, v_dsb_codcred, p_tipoproceso, p_fechaini, p_fechacierre);		
		end if
        -- codigo para insertar la fecha de devengado en caso de devengado manual
    end foreach

    update gen_parmgrales
    set pge_feccierre = p_fechacierre,
    pge_fecultrep = v_fechafinproc,
    pge_feccieant = v_fin_gestionant,
    pge_auditfho = current
    where pge_codgral = 17;
   

end procedure;


