


DROP procedure IF EXISTS d_creditos.inserta_fecha_devengado;
create procedure d_creditos.inserta_fecha_devengado(p_codcred integer, p_codmod integer, p_fecha date,usuario varchar(50), estacion varchar(30)) 

	-- DESCRIPCI: Inserta la fecha de devangado en la tabla pre_registro_devengado_creditos para obtener la cantidad de dias e interes 
         -- PARAMETROS INGRESO: p_codcmp integer                Codigo de Comprobante
         --                     p_codcred integer               Codigo de credito
         --                     p_codmod integer                Codigo de modulo
         --                     P_fecha_devengado               Fecha especificada por el usuario al que se toma los intereses devengados
         -- PARAMETROS SALIDA: 
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: 
         --               
         -- CREACI:  27-11-2025
         -- SDAPO: 2666825
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- ----------------------------------------------------------------------------------------------------------------------------------------------------
		--|   Autor   |     Fecha     | SDAPO    |  Descripcion
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|           |               |          |
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|  wherrera | 20260505      |          | se adiciona parametro codmod y se elimina los registros desde la fecha parametro  
		-----------------------------------------------------------------------------------------------------------------------------------------------------

	DEFINE RESULTADO INTEGER;
    let RESULTADO= 0;
-- codigo para eliminar las fechas de devengados posterior a la fecha que se esta registrando, este proceso se realiza de acuerdo al proceso de la tabla pre_accrual

	if p_fecha is null then
		return;
	end if
	
	delete from pre_registro_devengado_creditos
	where fecha_devengado = p_fecha
	and codcred = p_codcred
	AND codmod = p_codmod;

	INSERT INTO pre_registro_devengado_creditos (codcred, codmod, fecha_devengado, cambio_bd, audit_usuario, audit_fechahora, audit_host) 
	VALUES(p_codcred, p_codmod, p_fecha, null, usuario, current, estacion);

END PROCEDURE;


