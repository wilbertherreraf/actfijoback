

DROP procedure IF EXISTS d_creditos.pi_pre_planpagos;
create procedure d_creditos.pi_pre_planpagos(o_cuo_codcuo		like pre_planpagos.cuo_codcuo		,
o_cuo_codcred       like pre_planpagos.cuo_codcred      ,
o_cuo_codmod        like pre_planpagos.cuo_codmod       ,
o_cuo_numcuo        like pre_planpagos.cuo_numcuo       ,
o_cuo_fecvencuo     like pre_planpagos.cuo_fecvencuo    ,
o_cuo_capital       like pre_planpagos.cuo_capital      ,
o_cuo_interes       like pre_planpagos.cuo_interes      ,
o_cuo_cargos        like pre_planpagos.cuo_cargos       ,
o_cuo_desemb        like pre_planpagos.cuo_desemb       ,
o_cuo_valor         like pre_planpagos.cuo_valor        ,
o_cuo_valorpend     like pre_planpagos.cuo_valorpend    ,
o_cuo_monpag        like pre_planpagos.cuo_monpag       ,
o_cuo_coddsb        like pre_planpagos.cuo_coddsb       ,
o_cuo_numtrx        like pre_planpagos.cuo_numtrx       ,
o_cuo_tipocuo       like pre_planpagos.cuo_tipocuo      ,
o_cuo_tipoacu       like pre_planpagos.cuo_tipoacu      ,
o_cuo_tipotrx       like pre_planpagos.cuo_tipotrx
)

{
WHERRERA    20210922    
}
    define v_contmod, C_CUO_ENMODIF integer;
    define C_CODTAB_CAP, C_CODTAB_INT integer;
    define C_CODDSB_CERO, C_FLAG_EXETRIGGER_PP_NOEXE integer;
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
                
    let C_CODTAB_CAP = 1;
    let C_CODTAB_INT = 2;
    let C_CODDSB_CERO = 0;
    let C_CUO_ENMODIF = 5;
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;

    if G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE then
        LET G_FLAG_EXETRIGGER_PP = -1;
        RETURN;
    end if
    
    LET G_FLAG_EXETRIGGER_PP = -1;
    
    if nvl(o_cuo_coddsb, 0) = C_CODDSB_CERO then
    -- modulo cero 
        RETURN;
    end IF
    CALL p_pre_act_1erpagovenc(o_cuo_codcred, o_cuo_codmod, o_cuo_coddsb, o_cuo_fecvencuo, o_cuo_codcuo, o_cuo_tipotrx,10);
    
end procedure;



