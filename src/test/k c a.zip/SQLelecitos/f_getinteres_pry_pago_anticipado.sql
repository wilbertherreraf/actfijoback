DROP function IF EXISTS d_creditos.f_getinteres_pry_pago_anticipado;
create function d_creditos.f_getinteres_pry_pago_anticipado(p_codcred integer, p_codmod integer, p_coddsb integer, p_importe decimal (20,2), p_fechaini date, p_fechafin date)
    returning decimal(20,2)

{
    Funcion que realiza el calculo del interes por dia y lo multiplica por el numero de dias del pago al igual que el calulo de intereses devengados
	
-- DESCRIPCION: Procedimiento para generar pagos anticipados
-- PARAMETROS INGRESO:  p_codcred integer
--						p_codmod integer
--						p_coddsb integer
--						p_importe decimal(20,2)
--						p_fechaini date
--						p_fechafin date

-- PARAMETROS SALIDA:  Retorna el valor interes por dia y lo multiplica por el numero de dias del pago

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  06-05-2024   | 1763004  | Funcion que realiza el calculo del interes por dia y lo multiplica por el numero de dias del pago al igual que el calulo de intereses devengados.
----------------------------------------------------------------------------
--| wherrera |  01-04-2026   | 2763221  | Se inhabilita la funcion por ser duplicado de f_getinteres_pry.
----------------------------------------------------------------------------    
}

 raise EXCEPTION -746, 0, "f_getinteres_pry_pago_anticipado Metodo no implementado";
end function;
