


drop view if exists d_creditos.v_planpagos_resu;
create view d_creditos.v_planpagos_resu(acr_codacr,codcred,codmod,coddsb,fecha,fec_desemb,monto_desemb,desembolsado,nrodoc,codcli,
fec_31dicant,fec_1roene,fec_ultvenc,fec_ultdev_cont,fec_ult_activ,fec_ini_tramo2,tasavig,dias_deven,
int_devengado,int_periodo,int_contab,cap_amortizado,saldo_cap,capital_venc,interes_venc,
mnt_int31dic,
cap_dife_ant_venc,cap_dife_venc,cap_dife_cob,cap_panti_ant_vcto,int_panti_ant_vcto,cap_panti_vcto,int_panti_vcto,
int_al31dic,int_alfechavcto,int_cuota, cap_cuota,
acr_fecini,acr_fecfin,acr_capitalper,acr_interesper,acr_undsb,acr_tipoacr) as
select acr_codacr,acr_codcred codcred, acr_codmod codmod, acr_coddsb coddsb,acr_fecaccru fecha, dsb_fecdsb fec_desemb, dsb_valor monto_desemb,dsb_undsb desembolsado, dsb_nrodoc nrodoc,acr_codcli codcli,
fec_31dicant, fec_1roene,fec_ultvenc,fec_ultdev_cont,fec_ult_activ,fec_ini_tramo2,acr_tasavig tasavig,acr_diasaccr dias_deven,
acr_interes int_devengado,acr_valor int_periodo, acr_valorpend int_contab, acr_capital cap_amortizado, acr_saldo saldo_cap,capital_venc,interes_venc,
mnt_int31dic,
cap_dife_ant_venc,cap_dife_venc,cap_dife_cob, cap_panti_ant_vcto,int_panti_ant_vcto,cap_panti_vcto,int_panti_vcto,
acr_undsb int_al31dic,
acr_valorpend int_alfechavcto,
(interes_venc + int_panti_vcto) int_cuota,
(capital_venc + cap_panti_vcto - cap_dife_venc + cap_dife_cob) cap_cuota,
acr_fecini,acr_fecfin,acr_capitalper,acr_interesper,acr_undsb,acr_tipoacr  
from (
	select acr_codacr,acr_codcred , acr_codmod, acr_coddsb,dsb_fecdsb, dsb_valor,dsb_undsb, dsb_nrodoc,acr_codcli,
	(fec_1roene - 1) fec_31dicant, fec_1roene,fec_ultvenc,fec_ultdev_cont,fec_ult_activ,acr_fecini,acr_fecaccru, acr_fecfin,
	(case 
		when fec_ultvenc >= fec_1roene then
			fec_ultvenc + 1
		else
			fec_1roene
	end) fec_ini_tramo2,
	mnt_int31dic,
	acr_tasavig,acr_diasaccr,acr_interes,acr_valor, acr_valorpend, acr_capital, acr_saldo,acr_capitalper,acr_interesper,acr_undsb,acr_tipoacr,
	cap_dife_ant_venc,cap_dife_venc,cap_dife_cob,cap_panti_ant_vcto,int_panti_ant_vcto,capital_venc,interes_venc,cap_panti_vcto,int_panti_vcto
	from (
		select acr_codacr, acr_codcred , acr_codmod, acr_coddsb,dsb_fecdsb, dsb_valor,dsb_undsb, dsb_nrodoc,acr_codcli,
		acr_fecini,acr_fecaccru, acr_fecfin, 
		f_pp_fechainiper(acr_codcred, acr_codmod, acr_coddsb, acr_fecaccru, 2) fec_ultvenc,
		f_acr_ult_fec_acr(acr_codcred, acr_codmod, acr_coddsb, acr_fecaccru, 1) fec_ultdev_cont,
		acr_fecproc fec_ult_activ,		
		mdy(1,1,year(acr_fecaccru)) fec_1roene,
		acr_tasavig,acr_tipoacr,
		acr_diasaccr,acr_interes, acr_valor, acr_valorpend, acr_capital, acr_saldo,acr_capitalper,acr_interesper,acr_undsb,
		0 mnt_int31dic,		
		(select val from table (f_pp_sum_importetrx(acr_codcred , acr_codmod , acr_coddsb , acr_fecaccru, acr_fecaccru, 1, null, 2)) t_pp(val, valpend)) capital_venc,
		(select val from table (f_pp_sum_importetrx(acr_codcred , acr_codmod , acr_coddsb , acr_fecaccru, acr_fecaccru, 2, null, 2)) t_pp(val, valpend)) interes_venc,
		(select val from table (f_pp_sum_importetrx(acr_codcred , acr_codmod , acr_coddsb , null, acr_fecaccru-1, 1, 4, 4)) t_pp(val, valpend)) cap_dife_ant_venc,
		(select val from table (f_pp_sum_importetrx(acr_codcred , acr_codmod , acr_coddsb , acr_fecaccru, acr_fecaccru, 1, 4, 4)) t_pp(val, valpend)) cap_dife_venc,		
		(select val from table (f_pp_sum_importetrx(acr_codcred , acr_codmod , acr_coddsb , acr_fecaccru, acr_fecaccru, 1, 2, 4)) t_pp(val, valpend)) cap_dife_cob,		
		(select val from table (f_pp_sum_importetrx(acr_codcred , acr_codmod , acr_coddsb , null, acr_fecaccru-1, 12, null, 3)) t_pp(val, valpend)) cap_panti_ant_vcto,
		(select val from table (f_pp_sum_importetrx(acr_codcred , acr_codmod , acr_coddsb , null, acr_fecaccru-1, 22, null, 3)) t_pp(val, valpend)) int_panti_ant_vcto,
		(select val from table (f_pp_sum_importetrx(acr_codcred , acr_codmod , acr_coddsb , acr_fecaccru, acr_fecaccru, 12, null, 3)) t_pp(val, valpend)) cap_panti_vcto,
		(select val from table (f_pp_sum_importetrx(acr_codcred , acr_codmod , acr_coddsb , acr_fecaccru, acr_fecaccru, 22, null, 3)) t_pp(val, valpend)) int_panti_vcto		
		from pre_desemb, pre_accrual x
		where dsb_codcred = acr_codcred 
		and dsb_codmod = acr_codmod
		and dsb_coddsb = acr_coddsb
		and acr_tipoacr = 3

	)
);


