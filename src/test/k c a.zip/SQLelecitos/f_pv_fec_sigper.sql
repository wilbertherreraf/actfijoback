


DROP function IF EXISTS d_creditos.f_pv_fec_sigper;
create function d_creditos.f_pv_fec_sigper(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_tipocuo integer)
    returning date
    
    define v_fecfinper date;
    
        select min(vpp_fecvencuo)
        into v_fecfinper
        from v_pp_auxyplanpagos
        where vpp_codmod = p_codmod
        and vpp_codcred = p_codcred
        and vpp_fecvencuo > p_fecha
        and vpp_tipocuo = p_tipocuo
        and vpp_coddsb = p_coddsb
        and vpp_coddsb > 0;
    return nvl(v_fecfinper, p_fecha);
end function;

