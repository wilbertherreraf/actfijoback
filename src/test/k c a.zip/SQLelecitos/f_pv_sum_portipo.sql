


DROP function IF EXISTS d_creditos.f_pv_sum_portipo;
create function d_creditos.f_pv_sum_portipo(p_codcred integer, p_codmod integer, p_coddsb integer, p_fechaini date, p_fechafin date, p_tipocuo integer, p_tipocalc integer)
    returning DECIMAL(20,2), DECIMAL(20,2)
 {
 retorna las sumas del plan programado de la tabla auxiliar
 wherrera 2026-04-05 se reformula la funcion 
 call f_pv_sum_portipo(23, 17, 23001, "2026-05-01", "2026-06-27",2, null)

 }
    DEFINE v_cuo_capital, v_cuo_interes, v_cuo_valor, v_cuo_valorpend, v_acu_montocuo, v_cuo_desemb like pre_planpagos.cuo_capital;
	define C_TIPOCUO_DEVENG_INT, C_TIPOCUO_CAP, C_TIPOCUO_INT, C_TIPOCOB_PANTI_CAP, C_TIPOCOB_PANTI_INT integer;
    define v_fechaini, v_fecsigper date;
	define v_sum_cap_valor,v_sum_cap_valorpend, v_sum_cap_desemb like pre_planpagos.cuo_capital;
 	
    let v_sum_cap_valor = 0; 
    let v_sum_cap_valorpend = 0;
    
    let p_fechaini = nvl(p_fechaini, mdy(1,1,1980));
    let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));
    
	if p_tipocalc = 2 then
    	select nvl(sum(vpp_valor), 0), nvl(sum(vpp_valorpend), 0)
	    into v_sum_cap_valor,v_sum_cap_valorpend
	    from v_pp_auxyplanpagos
	    where vpp_codmod = p_codmod
	    and vpp_codcred = p_codcred
	    and vpp_coddsb = nvl(p_coddsb, vpp_coddsb)
	    and vpp_tipocuo = p_tipocuo
	    and vpp_fecvencuo between p_fechaini and p_fechafin;
	    
    else
	    call f_pp_sum_portipo(p_codcred, p_codmod, p_coddsb, p_fechaini, p_fechafin , p_tipocuo) 
                        returning v_sum_cap_valor,v_sum_cap_valorpend;
    end if
    
	return  nvl(v_sum_cap_valor, 0), nvl(v_sum_cap_valorpend, 0);    
    
end function;



