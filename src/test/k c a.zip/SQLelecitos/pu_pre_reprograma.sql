



DROP procedure IF EXISTS d_creditos.pu_pre_reprograma;
create procedure d_creditos.pu_pre_reprograma(
o_rds_codrepro		like pre_reprograma.rds_codrepro	,
o_rds_codcred       like pre_reprograma.rds_codcred     ,
o_rds_codmod        like pre_reprograma.rds_codmod      ,
o_rds_fecini        like pre_reprograma.rds_fecini      ,
o_rds_feciniint     like pre_reprograma.rds_feciniint   ,
o_rds_feculttrx     like pre_reprograma.rds_feculttrx   ,
o_rds_valor         like pre_reprograma.rds_valor       ,
o_rds_tasa         like pre_reprograma.rds_tasa       ,
o_rds_undsb         like pre_reprograma.rds_undsb       ,
o_rds_unidplaz      like pre_reprograma.rds_unidplaz    ,
o_rds_nroperiodos   like pre_reprograma.rds_nroperiodos ,
o_rds_nrogracia     like pre_reprograma.rds_nrogracia   ,
o_rds_nropagos      like pre_reprograma.rds_nropagos    ,
o_rds_diasfijoper   like pre_reprograma.rds_diasfijoper ,
o_rds_tiporepro     like pre_reprograma.rds_tiporepro   ,
o_rds_statreg       like pre_reprograma.rds_statreg,
o_rds_fecinidif     like pre_reprograma.rds_fecinidif,
o_rds_trxstaau      like pre_reprograma.rds_trxstaau,

n_rds_fecini        like pre_reprograma.rds_fecini      ,
n_rds_feciniint     like pre_reprograma.rds_feciniint   ,
n_rds_feculttrx     like pre_reprograma.rds_feculttrx   ,
n_rds_valor         like pre_reprograma.rds_valor       ,
n_rds_tasa         like pre_reprograma.rds_tasa       ,
n_rds_undsb         like pre_reprograma.rds_undsb       ,
n_rds_unidplaz      like pre_reprograma.rds_unidplaz    ,
n_rds_nroperiodos   like pre_reprograma.rds_nroperiodos ,
n_rds_nrogracia     like pre_reprograma.rds_nrogracia   ,
n_rds_nropagos      like pre_reprograma.rds_nropagos    ,
n_rds_diasfijoper   like pre_reprograma.rds_diasfijoper ,
n_rds_tiporepro     like pre_reprograma.rds_tiporepro   ,
n_rds_statreg       like pre_reprograma.rds_statreg,
n_rds_fecinidif     like pre_reprograma.rds_fecinidif,
n_rds_trxstaau      like pre_reprograma.rds_trxstaau,
n_rds_auditusr      like pre_reprograma.rds_auditusr,
n_rds_auditwst      like pre_reprograma.rds_auditwst
)

{
WHERRERA    20210922    (trigger upd)se crea el procedimiento que controla modificaciones sobre desembolsos

NOTA: la fecha de aplicaion de la tasa de reprogramacion es la fecha de reprogramcion + 1 dia en la tabla de tasas
}
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    define C_CODDSB_CERO, C_FLAG_EXETRIGGER_PP_NOEXE integer;
    define v_prim_venc,v_ult_act date;
    define v_feculttrx, v_fecini_efecttasa date;
    define C_TIPOREPRO_REPRO,v_intydias integer;
    
    let C_TIPOREPRO_REPRO = 1;
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;

    if G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE then
        LET G_FLAG_EXETRIGGER_PP = -1;
        RETURN;
    end if
    
    LET G_FLAG_EXETRIGGER_PP = -1;
    
    if nvl(o_rds_statreg, 1) = 9 then 
        raise exception -746,0,"Reprogramacion suspendida no puede modificar";
    end if

    let v_feculttrx = nvl(n_rds_feculttrx,n_rds_fecini);
	let v_feculttrx = nvl(v_feculttrx, n_rds_feciniint);
    
    if o_rds_tiporepro = C_TIPOREPRO_REPRO then
        let v_fecini_efecttasa = o_rds_fecinidif;
        
        if o_rds_statreg != n_rds_statreg and n_rds_statreg = 9 then
            call p_actualizartasa(o_rds_codcred, o_rds_codmod, v_fecini_efecttasa, null, null, 9, n_rds_auditusr, n_rds_auditwst);
        	let v_feculttrx = v_fecini_efecttasa;
        else
	    	if n_rds_fecinidif is null then
	    		raise exception -746, 0, "TRGR: Reprogramacion fecha corte debe tener valor, idrepro: " || o_rds_codrepro;
	    	end if
	    	if n_rds_feciniint is null then
	    		raise exception -746, 0, "TRGR: Reprogramacion primera fecha de amortizacion interes debe tener valor, idrepro: " || o_rds_codrepro;
	    	end if
	    	if n_rds_fecini is null then
	    		raise exception -746, 0, "TRGR: Reprogramacion primera fecha de amortizacion capital debe tener valor, idrepro: " || o_rds_codrepro;
	    	end if        
	    	
            if nvl(n_rds_tasa, 0) > 0 then
            	if n_rds_unidplaz is null then
            		raise exception -746, 0, "TRGR: Reprogramacion requiere unidplaz, idrepro: " || o_rds_codrepro;
            	end if
            	
            	let v_intydias = 360; 
				if o_rds_trxstaau != n_rds_trxstaau and n_rds_trxstaau = 3 then
				
					if n_rds_unidplaz in (13,26,22) then
						let v_intydias = 365;
					end if
					
					call p_actualizartasa(o_rds_codcred, o_rds_codmod, n_rds_fecinidif, n_rds_tasa, v_intydias, 3, n_rds_auditusr, n_rds_auditwst);
            	else
            		call p_actualizartasa(o_rds_codcred, o_rds_codmod, n_rds_fecinidif, n_rds_tasa, v_intydias, 2, n_rds_auditusr, n_rds_auditwst);
				end if
			else
				call p_actualizartasa(o_rds_codcred, o_rds_codmod, n_rds_fecinidif, 0, null, 9, n_rds_auditusr, n_rds_auditwst);
            end if
        end if
    end if
    
    let v_ult_act = v_feculttrx; 
	if v_feculttrx is not null then
    	let v_ult_act = f_acr_ult_fec_acr(o_rds_codcred, o_rds_codmod, null, v_feculttrx, 2);
    else
    	let v_ult_act = f_acr_ult_fec_acr(o_rds_codcred, o_rds_codmod, null, date(current), 2);
    end if

	CALL p_pre_act_1erpagovenc(o_rds_codcred, o_rds_codmod, null, v_ult_act, o_rds_codrepro, o_rds_tiporepro,6);    
end procedure;



