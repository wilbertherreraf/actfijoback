


DROP procedure IF exists d_creditos.p_upd_status_pre;
create procedure d_creditos.p_upd_status_pre(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_idtabla integer, 
	p_tipotrx integer, p_codproceso varchar(30), p_usuario varchar(50), p_estacion varchar(50))
{ wherrera 20260505 actualiza las operaciones para las operaciones contables
call p_upd_status_pre(11, 17, null, "2025-05-28", null,	2, "PAGADO", "asdf", "asf")
}
	
    define V_SUM_DBSVALOR, V_SUM_DBSUNDSB, V_SUM_DBSCOBS,v_capital_venc,v_panti_cap,v_cap_cuota,v_diff like pre_cobros.cob_valor;
    DEFINE v_pre_monliqent, v_pre_saldo,v_mnt_dev,v_tmo_importe LIKE PRE_PRESTAMOS.PRE_SALDO;
    DEFINE v_cont,v_numtrx, v_dsb_coddsb, v_new_status, v_pre_status, C_PRESTATUS_UNDSB, C_PRESTATUS_VIG, C_PRESTATUS_CANC INTEGER;
    define C_STATACRU_PROC, C_STATACRU_PEND,v_contar, v_idpcuota,v_codcmp,v_pcu_tipocmp,v_pre_codcli integer;
    define v_fecha,v_fecha_cont_coin date;
	define v_nro_comprob,v_nro_afectablecoind,v_cve_tipo_comprob_coin,v_nro_comprob_coin varchar(10);
	define v_estado integer;
    define v_glosa lvarchar(500);
define v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_nroregs integer;

    let C_PRESTATUS_UNDSB = 1;
    let C_PRESTATUS_VIG = 2;
    let C_PRESTATUS_CANC = 9;
    let C_STATACRU_PROC = 2;
    let C_STATACRU_PEND = 1;
    
    select count(1)
    into v_cont
    from pre_tramon, pre_desemb
    where tmo_coddsb = dsb_coddsb 
    and tmo_codcred = p_codcred
    and tmo_codmod = p_codmod
    and tmo_fecvencuo = p_fecha
    and tmo_tipotra = p_tipotrx
 	AND tmo_statreg = 0
 	and tmo_trxstaau in (1,2);
	    
    if v_cont > 0 then
		update pre_accrual
		set acr_statacru = C_STATACRU_PEND 
		where acr_codcred = p_codcred
		and acr_codmod = p_codmod
		and acr_coddsb > 0
		and acr_statacru = C_STATACRU_PROC
    	and acr_fecaccru = p_fecha;
    
		let v_fecha = f_acr_gencronoycalc(p_codmod, p_codcred, 2, p_fecha, p_fecha);
	end if

  	select pre_codcli
    into v_pre_codcli
    from pre_prestamos
   	where pre_codcred = p_codcred
     and pre_codmod = p_codmod;
  	
    foreach
	    select tmo_coddsb,tmo_numtrx,tmo_importe
	    into v_dsb_coddsb, v_numtrx,v_tmo_importe
	    from pre_tramon, pre_desemb
	    where tmo_coddsb = dsb_coddsb 
	    and tmo_codcred = p_codcred
	    and tmo_codmod = p_codmod
	    and tmo_fecvencuo = p_fecha
	    and tmo_tipotra in (2,3)
     	AND tmo_statreg = 0
     	--and tmo_trxstaau in (1,2)
     	
     		let v_idpcuota = null;
    
	     	select id,pcu_tipocmp
	     	into v_idpcuota,v_codcmp
	     	from pre_pagocuota
	     	where codcred = p_codcred 
	     	and codmod = p_codmod
	     	and coddsb = v_dsb_coddsb 
	     	and fecha_vencimiento = p_fecha
	     	and pcu_numtrx = v_numtrx
	     	and pcu_tipocmp in (4,5,6,7)
	     	and estado in (1,2,3);
		    
			if v_idpcuota is null then
			    let v_idpcuota = Nvl((select max(id) from pre_pagocuota), 0) + 1;
				let v_codcmp = 4;
			
			    INSERT INTO pre_pagocuota(id, codcred, codmod, coddsb,pcu_numtrx, fecha_vencimiento, fecha, 
			    pcu_tipocmp,
			    total_cuota_vencimiento, pago_importe_capital, pago_importe_intereses,intereses_gestion_anterior, intereses_gestion_actual,
			    total_saldo, numero_cuota, nro_claveserie, estado, audit_usuario, audit_fechahora, audit_host)
			    VALUES (v_idpcuota, p_codcred, p_codmod, v_dsb_coddsb, v_numtrx,p_fecha, date(current),
			    v_codcmp,
			    0, 0, 0, 0, 0,
			    0, 0, null,1, p_usuario, current, p_estacion);
			end if
			
	     	select nro_comprobante_coin, estado,pcu_tipocmp
	     	into v_nro_comprob, v_estado,v_codcmp
	     	from pre_pagocuota
	     	where codcred = p_codcred 
	     	and codmod = p_codmod
	     	and coddsb = v_dsb_coddsb 
	     	and id = v_idpcuota;
			
	     	if p_codproceso = "PAGADO" and v_nro_comprob is null then
	     		let v_capital_venc = f_cobrostipocob_fven(p_codcred, p_codmod, v_dsb_coddsb, p_fecha,p_fecha, 1, null);
	     		let v_panti_cap = f_cobrostipocob_fven(p_codcred, p_codmod, v_dsb_coddsb, p_fecha,p_fecha, 12, null);
	     		let v_cap_cuota = v_capital_venc + v_panti_cap;
	     	
		    	let v_codcmp = 4;
		    	if v_cap_cuota > 0 then
			    	if v_pre_codcli in (2,10) then 
			  			let v_codcmp = 5;
			    	end if
		    	else
		    		let v_codcmp = 6;
		    		if v_pre_codcli in (2,10) then 
			  			let v_codcmp = 7;
			    	end if
		    	end if
		    	let v_cont = 0;
		    	foreach
			    	execute procedure obtiene_interes_devengado(v_codcmp,p_codcred, p_codmod, p_fecha, null, null) 
			            		into v_fecha_cont_coin,v_nro_comprob_coin,v_mnt_dev, v_cve_tipo_comprob_coin,v_nro_afectablecoind,v_glosa
					let v_diff = v_mnt_dev - v_tmo_importe;
					if abs(v_diff) < 2 then		    	
				    	update pre_pagocuota
				    	set total_cuota_vencimiento = v_mnt_dev,
				    	glosa_coin = v_glosa,
				    	nro_comprobante_coin = v_nro_comprob_coin,
				    	cve_tipo_comprob = v_cve_tipo_comprob_coin,
				    	fecha_vencimiento = p_fecha,
				    	estado = 3,
				    	pcu_tipocmp = v_codcmp,
				    	fecha = v_fecha_cont_coin,
				    	audit_usuario = p_usuario,
				    	audit_fechahora = current,
				    	audit_host = p_estacion
				    	where id = v_idpcuota
				    	and codcred = p_codcred
				    	and codmod = p_codmod
				    	and pcu_tipocmp = v_codcmp
			    		and estado = 1;		
		    			let v_cont = v_cont + 1;
		    		end if
			  	end foreach
		    	
			  	if v_cont = 0 then
			  		update pre_pagocuota
			  		set estado = 5
			  		where id = v_idpcuota;
			  	end if
	     	else
		     	if length(trim(nvl(v_nro_comprob,""))) = 0 and v_estado in (1,2) then
					call p_set_params_proceso_conta(v_codcmp, v_idpcuota, p_codcred, p_codmod, v_dsb_coddsb, p_fecha, v_numtrx,p_usuario, p_estacion);
		     	end if
		     end if
	end foreach

    
end procedure;


