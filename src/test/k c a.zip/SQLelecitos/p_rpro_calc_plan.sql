


DROP procedure IF EXISTS d_creditos.p_rpro_calc_plan;
create procedure d_creditos.p_rpro_calc_plan(p_trxstaau integer, p_codrepro integer, p_fechaoper date, p_coduser varchar(100), P_ESTACION VARCHAR(100))


{***** ==> LOG <== *****
wherrera    2021-10-05  recalcula los valores de la reprogramacion en el cronograma
wherrera    2026-04-05  se modifica la eliminacion de registros de auxiliar plan
call p_rpro_calc_plan(1,59,null, "user", "tes")
}
define err_num, err_nro integer;
define err_msg varchar(235);
define v_rds_feciniint, v_rds_feculttrx, v_rds_fecini, v_rds_fecfin, v_rds_fecinidif  date;
define v_rds_methodcapi, v_pre_methodcapi, v_pre_unidplaz integer;
define v_rds_codrepro, v_rds_diasfijoper, v_rds_unidplaz, v_rds_statreg integer;
define v_rds_valor, v_rds_saldo, v_rds_undsb,V_SUM_DBSUNDSB, V_SUM_DBSCOBS like pre_reprograma.rds_valor;
define v_rds_nroperiodos, v_rds_nrogracia, v_rds_nrograciaint, v_rds_nropagos integer;
define v_new_nroperiodos, v_new_nropagos, v_new_nrogracia, v_new_nrograciaint integer;
define v_fecha_prim_venc,v_fec_prim_venc, v_fecha_fin_venc,v_f_corterepro,v_fecha_prim_amort,v_fecha_prim_amortint date;
define v_dsb_coddsb			like pre_desemb.dsb_coddsb			;
DEFINE v_dsb_valor, v_siap like pre_desemb.dsb_valor;
DEFINE v_nroper_pp_cal, C_TIPOREPRO_REPRO, C_INPUT_PERIOD_EXACT, C_TIPOCUO_CAP, C_TIPOCUO_INT, C_TIPOOPER_REPRO INTEGER;
DEFINE v_tasabase, v_rds_tasa FLOAT;
define v_fecmax_cap, v_feculttrx, V_D_FECFINPER, V_D_FECINIPER, v_dsb_fecdsb, C_TRXSTAAU_AUT date;
define v_app_t, v_appaux_t aux_planpagos_t;
define C_TRXSTAAU_ELIMINAR, C_TRXSTAAU_PREAUTORIZAR,C_TIPOCOB_PANTI_CAP, C_TRXSTAAU_VIGENTE, C_TRXSTAAU_AUTORIZAR, v_contar integer;
DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
DEFINE C_FLAG_EXETRIGGER_PRE_NOEXE INTEGER;
define v_numpers,v_rds_codmod, v_rds_codcred, v_rds_tipo_pago,v_rds_trxstaau integer;

   	let C_TIPOCUO_CAP = 1;
	let C_TIPOCUO_INT = 2;
    let C_TRXSTAAU_VIGENTE = 1;
    let C_TRXSTAAU_PREAUTORIZAR = 2;
    let C_TRXSTAAU_AUTORIZAR = 3;
	let C_TRXSTAAU_ELIMINAR = 9;
    let C_TIPOREPRO_REPRO = 1;
    let C_INPUT_PERIOD_EXACT = 3;
    LET C_TIPOOPER_REPRO = 12;
   	let C_TIPOCOB_PANTI_CAP = 12;
    let C_TRXSTAAU_AUT = 3;
    LET C_FLAG_EXETRIGGER_PRE_NOEXE = 1;        

    select rds_fecini, rds_feciniint, rds_fecfin, rds_valor, rds_saldo, rds_unidplaz, rds_feculttrx, rds_fecinidif,
            rds_nroperiodos, rds_nrogracia, rds_nropagos, rds_diasfijoper, rds_statreg, rds_tasa,
            rds_codmod, rds_codcred, rds_undsb, rds_tipo_pago,rds_trxstaau
    into v_rds_fecini, v_rds_feciniint, v_rds_fecfin, v_rds_valor, v_rds_saldo, v_rds_unidplaz, v_rds_feculttrx, v_rds_fecinidif,
            v_rds_nroperiodos, v_rds_nrogracia, v_rds_nropagos, v_rds_diasfijoper, v_rds_statreg, v_rds_tasa,
            v_rds_codmod, v_rds_codcred, v_rds_undsb, v_rds_tipo_pago,v_rds_trxstaau
    from pre_reprograma 
    where rds_codrepro = p_codrepro
    and rds_tiporepro = C_TIPOREPRO_REPRO;

    IF (dbinfo ("sqlca.sqlerrd2") = 0) and p_trxstaau != C_TRXSTAAU_ELIMINAR THEN
        raise exception -746, 0, "Registros de Reprogramacion inexistente o autorizado " || p_codrepro;  
    end if

    if v_rds_codcred is null  and p_trxstaau != C_TRXSTAAU_ELIMINAR then
        raise exception -746,0,"Registro de reprogramacion inexistente o suspendido " || p_codrepro;
    end if

    call p_updsumtrans(v_rds_codmod, v_rds_codcred, null, 1, 3, null, null);
    
    if p_trxstaau = C_TRXSTAAU_ELIMINAR then
    	if v_rds_trxstaau = 3 then
    		raise exception -746,0,"Registro de reprogramacion AUTORIZADO " || p_codrepro;
    	end if
    	
		delete FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
    	and acu_tipodsb = p_codrepro;
    	
    	delete from pre_reprograma
    	where rds_codrepro = p_codrepro
    	and rds_trxstaau != 3
    	;
    	return;
    end if
    
    call p_rpro_valida_repro(p_codrepro, p_trxstaau);
    
    if p_trxstaau = C_TRXSTAAU_VIGENTE then
    	SELECT count(*)
	    INTO v_contar
	    FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
	    AND acu_valor > 0
    	and acu_tipodsb > 0
    	and acu_trxstaau = 2;
    
    	if v_contar > 0 then
    		raise exception -746, 0, "Credito en proceso de revision en tabla auxiliar";
    	end if
	    if v_rds_feciniint < v_rds_fecinidif then
			let v_feculttrx = f_acr_ult_fec_acr(v_rds_codcred, v_rds_codmod, null, v_rds_feciniint-1, 2);
	    else
			let v_feculttrx = f_acr_ult_fec_acr(v_rds_codcred, v_rds_codmod, null, v_rds_fecinidif-1, 2);    
	    end if
	    
    	delete from pre_reprograma
    	where rds_codrepro != p_codrepro
    	and rds_trxstaau = 1
    	and rds_codmod = v_rds_codmod
    	and rds_codcred = v_rds_codcred
    	and rds_tiporepro = C_TIPOREPRO_REPRO;
    	
   		-- copia valores de la tabla plan de pagos a la tabla 'aux_planpagos'
   		
   		select count(1)
   		into v_contar
		from pre_planpagos
	    where cuo_fecvencuo > v_feculttrx
	    and cuo_codcred = v_rds_codcred
	    and cuo_codmod = v_rds_codmod
   		and cuo_coddsb > 0
   		and cuo_valor != cuo_valorpend 
   		and cuo_valor > 0;

   		if v_contar > 0 then
   			raise exception -746, 0, "Existen movimientos en el plan de pagos posterior a ult movimiento " || v_feculttrx;
   		end if
   		
	    call p_mf_amort_genplan(v_rds_codcred, v_rds_codmod, C_TIPOREPRO_REPRO, p_codrepro, v_rds_fecinidif, v_rds_fecini, v_rds_feciniint, 
			v_rds_tasa, v_rds_unidplaz, v_rds_nroperiodos, p_coduser, p_estacion);
 		
        update pre_reprograma
    	set rds_trxstaau = C_TRXSTAAU_VIGENTE,
    	rds_undsb = 0,
    	rds_auditusr = p_coduser,
    	rds_auditwst = P_ESTACION,
    	rds_auditfho = current
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_REPRO;    
    elif p_trxstaau = C_TRXSTAAU_PREAUTORIZAR then
    
	    SELECT count(*)
	    INTO v_contar
	    FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
	    AND acu_valor > 0
    	and acu_tipodsb = p_codrepro
	    and acu_trxstaau = C_TRXSTAAU_VIGENTE;
    
        IF v_contar = 0 THEN
    		raise exception -746, 0, "PAG ANT PREAUTO: No existen registros en tabla auxiliar, para cod " || p_codrepro;
    	END if
    
    	call p_control_auxpp(v_rds_codcred, v_rds_codmod, p_codrepro);
    	
        update pre_reprograma
    	set rds_trxstaau = C_TRXSTAAU_PREAUTORIZAR,
    	rds_auditusr = p_coduser,
    	rds_auditwst = P_ESTACION,
    	rds_auditfho = current
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_REPRO;
        
        update aux_planpagos
        set acu_trxstaau = C_TRXSTAAU_PREAUTORIZAR
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
    	and acu_tipodsb = p_codrepro
        and acu_trxstaau = C_TRXSTAAU_VIGENTE;
        
    elif p_trxstaau = C_TRXSTAAU_AUTORIZAR then
    
    	SELECT count(*)
	    INTO v_contar
	    FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
	    AND acu_valor > 0
    	and acu_tipodsb = p_codrepro
    	and acu_trxstaau = C_TRXSTAAU_PREAUTORIZAR;

        IF v_contar = 0 THEN
    		raise exception -746, 0, "PAG ANT AUTO: No existen registros en tabla auxiliar, para cod " || p_codrepro;
    	END if
    	
    	call p_cpy_auxpp_planpagos(v_rds_codcred, v_rds_codmod, null, p_codrepro, p_coduser, P_ESTACION);
    	
    	update pre_reprograma
    	set rds_trxstaau = C_TRXSTAAU_AUTORIZAR,
    	rds_undsb = rds_valor,
    	rds_auditusr = p_coduser,
    	rds_auditwst = P_ESTACION,
    	rds_auditfho = current
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_REPRO; 
    	
		delete FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred;    	
       
    end if
    
    
   
end procedure;



