


DROP PROCEDURE IF EXISTS d_creditos.p_copiar_planpagos_aux;
create procedure d_creditos.p_copiar_planpagos_aux(p_codcred integer, p_codmod integer, p_codmodtmp INTEGER, p_coduser varchar(100))
{
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| wherrera |  31-03-2026   | 2763221  | En atención a la Comunicación Interna BCB-GSIS-SSI-CI-2026-22 mediante la cual se requiere generar un nuevo SDAPO referido al funcionamiento del Pago Anticipado.
----------------------------------------------------------------------------
}
	raise EXCEPTION -746,0,"p_copiar_planpagos_aux Metodo no implementado";
end procedure;


