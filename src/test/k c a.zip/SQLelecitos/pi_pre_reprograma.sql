


DROP procedure IF EXISTS d_creditos.pi_pre_reprograma;
create procedure d_creditos.pi_pre_reprograma(
o_rds_codrepro		like pre_reprograma.rds_codrepro	,
o_rds_codcred       like pre_reprograma.rds_codcred     ,
o_rds_codmod        like pre_reprograma.rds_codmod      ,
o_rds_fecini        like pre_reprograma.rds_fecini      ,
o_rds_feciniint     like pre_reprograma.rds_feciniint   ,
o_rds_feculttrx     like pre_reprograma.rds_feculttrx   ,
o_rds_valor         like pre_reprograma.rds_valor       ,
o_rds_tasa         like pre_reprograma.rds_tasa       ,
o_rds_undsb         like pre_reprograma.rds_undsb       ,
o_rds_unidplaz      like pre_reprograma.rds_unidplaz    ,
o_rds_nroperiodos   like pre_reprograma.rds_nroperiodos ,
o_rds_nrogracia     like pre_reprograma.rds_nrogracia   ,
o_rds_nropagos      like pre_reprograma.rds_nropagos    ,
o_rds_diasfijoper   like pre_reprograma.rds_diasfijoper ,
o_rds_tiporepro     like pre_reprograma.rds_tiporepro   ,
o_rds_statreg       like pre_reprograma.rds_statreg,
o_rds_fecinidif     like pre_reprograma.rds_fecinidif,
o_rds_auditusr      like pre_reprograma.rds_auditusr,
o_rds_auditwst      like pre_reprograma.rds_auditwst
)

{
WHERRERA    20210922    (trigger)se crea el procedimiento para control de operaciones de reprogramaciones
}
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    define C_TIPOREPRO_REPRO, C_TIPOREPRO_PANTI, C_CODDSB_CERO, C_FLAG_EXETRIGGER_PP_NOEXE integer;
    define v_feculttrx, v_fecini_efecttasa date;
   
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;
    LET C_TIPOREPRO_REPRO = 1;
    LET C_TIPOREPRO_PANTI = 2;
    
    if G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE then
        LET G_FLAG_EXETRIGGER_PP = -1;
        RETURN;
    end if
    
    LET G_FLAG_EXETRIGGER_PP = -1;
    
    if o_rds_tiporepro is null then 
        raise exception -746,0,"Tipo de reprogramacion debe tener valor.";
    end if
    
    let v_feculttrx = f_dsb_fecmax_trx(o_rds_codmod, o_rds_codcred, NULL, null);
    
    if v_feculttrx is null then
        raise exception -746,0,"RPRO: No existe ningun cobro o desembolso realizado.";
    end if
    
    if o_rds_tiporepro = C_TIPOREPRO_PANTI then 
        if o_rds_fecini is null then
            raise exception -746,0,"RPRO: fecha de reprogramacion requerido.";
        end if
        if nvl(o_rds_valor, 0) <= 0 then
            raise exception -746,0,"RPRO: Importe reprogramacion requerido.";
        end if
        
        if v_feculttrx > o_rds_fecini THEN
            raise exception -746,0,"RPRO: Fecha de pago anticipado debe ser mayor a ult transaccion " || v_feculttrx;
        end if
        
        let v_feculttrx = f_dsb_fecmax_trx(o_rds_codmod, o_rds_codcred, NULL, 4);
        
        if v_feculttrx is not null and v_feculttrx >= o_rds_fecini THEN
            raise exception -746,0,"RPRO: Existeen diferimientos para el credito " || v_feculttrx;
        end if
        
    elif o_rds_tiporepro = C_TIPOREPRO_REPRO then 
    	if o_rds_fecinidif is null then
    		raise exception -746, 0, "RPRO: Fecha inicio de reprogramacion o corte debe tener valor";
    	end if
    	if o_rds_feciniint is null then
    		raise exception -746, 0, "RPRO: Fecha primera amortizacion interes debe tener valor";
    	end if
    	if o_rds_fecini is null then
    		raise exception -746, 0, "RPRO: Fecha primera amortizacion capital debe tener valor";
    	end IF
	    if nvl(o_rds_nroperiodos, 0) <= 0 then
	        raise exception -746,0,"Numero de periodos interes debe ser mayor a 1";
	    end IF
	    
	    IF LEAST(o_rds_fecini,o_rds_feciniint) < o_rds_fecinidif THEN
	    	raise exception -746,0,"Fecha reprogramacion o corte debe ser menor a primera fecha amort. capital e interes";
	    END if
    end if
    

end procedure;


