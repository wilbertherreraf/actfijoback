

DROP function IF EXISTS d_creditos.f_mf_amort_salddeudo;
CREATE function d_creditos.f_mf_amort_salddeudo( p_app_t aux_planpagos_t, p_fecha_prim_amortint date, p_tipotrx integer, p_codrepro integer,  
	p_nroamort_int INTEGER, p_nroamort_cap INTEGER, NRODIASPERIODO INTEGER)
returning aux_planpagos_t, integer
{***** ==> LOG <== *****
 
wherrera 2021-10-15 tabla de amortizacion de saldos deudores

-- DESCRIPCION: Procedimiento para generar plan de pagos
-- PARAMETROS SALIDA:  aux_planpagos_t
-- AUTOR: wherrera
-- CREACION: 2021-10-15

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| wherrera  |  2021-1015   |          | procedimiento para la amortizacion de saldos deudores
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| acanqui   |  13-10-2025   | 2333600  | Ajustes en el procedimiento para anadir el calculo de plan de pagos para creditos de 365 dias
-----------------------------------------------------------------------------------------------------------------------------------------------------
--| wherreta  |  05-05-2026 |  | Se modifica para reprogramaciones  
-----------------------------------------------------------------------------------------------------------------------------------------------------

}
    define v_intperiodo, v_amt_resto, v_capamortper, v_siap, v_cap_amort_per, v_amortper, v_sidp decimal(20,2);
    define v_period, C_TASAPERIODO, C_INPUT_PERIOD_EXACT, v_nroper_cap integer;
    define v_first, D_DIFFERENCE_IN_DAYS , MONTHSPERPERIOD, v_TRAINTYDAYS integer;
    define v_nroper_calendar, v_nroper_pp, v_nroper_pp_cal, v_mtp_intydias integer;
    define v_intper,v_tasabase float;
    define v_fechaper, v_fecvencuo, v_fechaini, v_fecmax_cap, v_fecini_cap, v_fechalimit_prg,v_feculttrx, v_ultvenc date;
	define v_f_corterepro, v_fecha_prim_venc, v_fecha_prim_amort, v_fecha_prim_amortint,v_dsb_fecdsb date;
    define v_app_t,v_appaux_t  aux_planpagos_t;
    --define D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY date;
    DEFINE C_TASAPERIODO_ANUAL, C_TIPOCUO_INT, C_TIPOCUO_CAP,v_pre_methodcapi, v_pre_unidplaz INTEGER;
    define P_TRAINTYDAYS, P_TRAINTMDAYS integer;
    define C_NROMAXPERS, v_contctrl integer;
    define FLAG_GESTION_365 INTEGER;
    define result_redondeado  INTEGER;
   
    
    -- determina si existe un pp 
    let C_TIPOCUO_INT = 2;
    let C_TIPOCUO_CAP = 1;
    let v_first = 0;
    let C_TASAPERIODO = 0;
    let C_INPUT_PERIOD_EXACT = 3;
    let C_TASAPERIODO_ANUAL = 1;
    let v_cap_amort_per = 0;
    let p_nroamort_int = nvl(p_nroamort_int, 0);
    let p_nroamort_cap = nvl(p_nroamort_cap, 0);  --   
    let C_NROMAXPERS = 1000;
    let v_contctrl = 0;
    let NRODIASPERIODO = nvl(NRODIASPERIODO, 0);
    let v_fechalimit_prg = null;

    let v_fecha_prim_amort = p_app_t.acu_fecfincuo;
    
    let FLAG_GESTION_365=0;
    let result_redondeado=0;
    
    if p_nroamort_cap <= 0 and p_nroamort_int <= 0 then
    	raise exception -746,0,"GENPP: Generacion de PP requiere nro amortizaciones de capital o interes";
    end if
    
    if v_fecha_prim_amort is null then
    	raise exception -746,0,"GENPP: Generacion de PP requiere fecha primera amortizacion de capital";
    end if
    
    if p_fecha_prim_amortint is null then
    	raise exception -746,0,"GENPP: Generacion de PP requiere fecha primera amortizacion de interes";
    end if
    if v_fecha_prim_amort < p_fecha_prim_amortint then
    	raise exception -746,0,"GENPP: Generacion de PP con primera cuota de capital " || v_fecha_prim_amort || " menor a primera cuota interes " || p_fecha_prim_amortint;
    end if    
    let v_fecha_prim_venc = nvl(p_app_t.acu_fecvencuo, p_fecha_prim_amortint);
    
    let v_f_corterepro = nvl(p_app_t.acu_fecinicuo, p_fecha_prim_amortint);
    
    if v_f_corterepro > p_fecha_prim_amortint then
    	let v_f_corterepro = p_fecha_prim_amortint;
    end if
    
    call f_GET_TRA_INT_YR_MTH_BASE(p_app_t.acu_codmod , p_app_t.acu_codcred ) returning P_TRAINTYDAYS, P_TRAINTMDAYS;

    if p_nroamort_int > 0 then
    	-- OBTIENE LA ULTIMA FECHA DE VENCIMIENTO DEL PLAN DE PAGOS
        let v_fechalimit_prg = f_periodo_fechafin(p_fecha_prim_amortint, p_nroamort_int, p_app_t.acu_unidplaz, NRODIASPERIODO, 3);
    end if
    
    if v_fechalimit_prg is null and p_nroamort_cap > 0 then
    	-- OBTIENE LA ULTIMA FECHA DE VENCIMIENTO DEL PLAN DE PAGOS
        let v_fechalimit_prg = f_periodo_fechafin(v_fecha_prim_amort, p_nroamort_cap, p_app_t.acu_unidplaz, NRODIASPERIODO, 3);
    end if
    
    -- nro de periodos captial
    if p_nroamort_cap = 0 then
        call f_periodos_fechas(v_fecha_prim_amort, v_fechalimit_prg, p_app_t.acu_unidplaz, NRODIASPERIODO, C_INPUT_PERIOD_EXACT,1, 0) -- no modif fefin y v_fecha_prim_amort es fin 1er per  
    		returning p_nroamort_cap, v_nroper_calendar, v_fecmax_cap;    
    end if
    
	select dsb_fecdsb
	into v_dsb_fecdsb
	from pre_desemb
	where dsb_coddsb = p_app_t.acu_coddsb;
	
	call f_dsb_getmethod_plz(p_app_t.acu_codcred, p_app_t.acu_codmod, p_app_t.acu_coddsb) returning v_pre_methodcapi, v_pre_unidplaz;
	
	if v_dsb_fecdsb < v_f_corterepro and v_f_corterepro < p_fecha_prim_amortint then
		-- es repro, registramos en el pp la fecha corte o de repro
		let v_feculttrx = f_acr_ult_fec_acr(p_app_t.acu_codcred, p_app_t.acu_codmod, p_app_t.acu_coddsb, v_f_corterepro-1, 2);
		let v_siap = f_acr_saldo_fecha(p_app_t.acu_codcred, p_app_t.acu_codmod, p_app_t.acu_coddsb, v_f_corterepro, 1);
		let v_tasabase = f_gettasavigenteprest(p_app_t.acu_codcred, p_app_t.acu_codmod, v_f_corterepro-1);
	
		call f_DAYS_BETWEEN_2_DATES(v_feculttrx, v_f_corterepro, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS;	
		let v_intperiodo = round(v_siap * D_DIFFERENCE_IN_DAYS * f_tasaindiceperiodo(p_app_t.acu_unidplaz, v_tasabase, C_TASAPERIODO, v_TRAINTYDAYS, 1), 2);
		
        let v_app_t = f_init_app_t();
		
        let v_app_t.acu_codmod = p_app_t.acu_codmod;
        let v_app_t.acu_codcred = p_app_t.acu_codcred;
        let v_app_t.acu_coddsb = p_app_t.acu_coddsb;
        let v_app_t.acu_fecinicuo = v_feculttrx;
        let v_app_t.acu_fecvencuo = v_f_corterepro;
       	let v_app_t.acu_fecfincuo = v_f_corterepro;        
        let v_app_t.acu_numcuo = null; --reserv codcuo
        let v_app_t.acu_capital = v_siap;    
       	let v_app_t.acu_tasa = v_tasabase;
        let v_app_t.acu_valor = 0;
        let v_app_t.acu_interes = v_intperiodo;
        
        return v_app_t,D_DIFFERENCE_IN_DAYS with resume;
	end if
    -- p_app_t.acu_capital (es monto que se desembolsara)
    let p_app_t.acu_capital = nvl(p_app_t.acu_capital, 0); -- EN CASO DE QUE EL IMPORTE DESEMBOLSADO SEA NULO LE ASIGNA CERO
     
    if p_app_t.acu_capital <= 0 then
		let p_app_t.acu_capital = f_acr_saldo_fecha(p_app_t.acu_codcred, p_app_t.acu_codmod, p_app_t.acu_coddsb, p_fecha_prim_amortint, 1);    
    end if
    
    let v_cap_amort_per = p_app_t.acu_capital;

    IF p_nroamort_cap > 0 then
        let v_cap_amort_per = p_app_t.acu_capital / p_nroamort_cap;
    end if

    let v_cap_amort_per = round(v_cap_amort_per, 2);
    
    if p_app_t.acu_unidplaz in (1,7) and NRODIASPERIODO <= 0 then
        raise exception -746,0, "Periodicidad irregular debe tener dias periodos mayor a cero.";
    end if
    
    let v_capamortper = 0;
    let v_period = 1; 
    let v_siap = p_app_t.acu_capital; -- monto a desembolsar
    let v_amt_resto = p_app_t.acu_capital; -- monto a desembolsar
    let v_fechaper = v_fecha_prim_venc; -- primera fecha de vencimiento

    let v_mtp_intydias = 360;
	if p_app_t.acu_unidplaz in (13,26,22) then
		--let v_mtp_intydias = 365;
	end if

	let v_amt_resto = v_siap; -- monto a desembolsar
	let v_fechaini = v_f_corterepro;

	if p_tipotrx > 0 and p_codrepro > 0 then
		select max(acu_fecvencuo)
	    into v_ultvenc
		from aux_planpagos
		where acu_codcred = p_app_t.acu_codcred
		and acu_codmod = p_app_t.acu_codmod
		and acu_tipodsb = p_codrepro
		and acu_tabtipodsb = p_tipotrx
		and acu_fecvencuo >= v_f_corterepro;
			
	    foreach 
			select acu_codacu, acu_codcred, acu_codmod, acu_fecvencuo, acu_numcuo,
	        acu_fecinicuo, acu_fecfincuo, acu_tipocuo, acu_tipoacu
	        into v_app_t.acu_codacu, v_app_t.acu_codcred, v_app_t.acu_codmod, v_app_t.acu_fecvencuo,v_app_t.acu_numcuo,
	        v_app_t.acu_fecinicuo, v_app_t.acu_fecfincuo, v_app_t.acu_tipocuo, v_app_t.acu_tipoacu
	    	from aux_planpagos
	    	where acu_codcred = p_app_t.acu_codcred
	    	and acu_codmod = p_app_t.acu_codmod
	    	and acu_tipodsb = p_codrepro
	    	and acu_tabtipodsb = 5
	    	and acu_fecvencuo >= v_f_corterepro
	    	order by acu_fecvencuo
	    	
				let v_appaux_t = f_init_app_t();
	
		        call f_DAYS_BETWEEN_2_DATES(v_fechaini, v_app_t.acu_fecvencuo, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS;        
				let v_appaux_t.acu_numcuo = null;
		        let v_appaux_t.acu_capital = v_siap;    
		        let v_appaux_t.acu_fecinicuo = v_fechaini;
				let v_appaux_t.acu_fecvencuo = v_app_t.acu_fecvencuo;
		        if v_appaux_t.acu_fecvencuo >= p_fecha_prim_amortint then
		        -- fecha de proceso de interes
		            let v_appaux_t.acu_fecfincuo = v_appaux_t.acu_fecvencuo;
		        else        
		            let v_appaux_t.acu_fecfincuo = p_fecha_prim_amortint;
		        end if
		        
		        let v_appaux_t.acu_tasa = p_app_t.acu_tasa;
		        if p_app_t.acu_tasa is null or p_app_t.acu_tasa <= 0 then
		        	let v_appaux_t.acu_tasa = f_gettasavigenterepro(p_app_t.acu_codcred, p_app_t.acu_codmod,v_appaux_t.acu_fecvencuo-1, 3); 
		        end if
		        
		        let v_intper = round(v_siap * D_DIFFERENCE_IN_DAYS * f_tasaindiceperiodo(p_app_t.acu_unidplaz, v_app_t.acu_tasa, C_TASAPERIODO, v_TRAINTYDAYS, 1), 2);
		     	let v_appaux_t.acu_valor = 0;
		        
		        if v_app_t.acu_fecvencuo >= v_fecha_prim_amort then
		        	let v_appaux_t.acu_valor = v_cap_amort_per;
		        end if
		        if v_app_t.acu_fecvencuo >= v_ultvenc then
		        	let v_appaux_t.acu_valor = v_siap; 
		        end if
		        
		        let v_sidp = round(v_siap - v_app_t.acu_valor, 2);        
		        
		        let v_appaux_t.acu_interes = v_intper;
		        
		        return v_appaux_t,D_DIFFERENCE_IN_DAYS with resume;
		
		        let v_siap = v_sidp;
		        let v_period = v_period + 1;
		        let v_amt_resto = v_amt_resto - v_cap_amort_per;        
		        LET v_fechaper = v_app_t.acu_fecvencuo;
		        let v_contctrl = v_contctrl + 1;    	
	    		let v_app_t.acu_tasa = f_gettasavigenteprest(p_app_t.acu_codcred, p_app_t.acu_codmod, v_app_t.acu_fecvencuo-1);
				let v_app_t.acu_capital = v_amt_resto; 
			    let v_app_t.acu_capital = v_siap;    
			    let v_app_t.acu_fecinicuo = v_fechaini;
	        
	        let v_amt_resto = v_amt_resto - v_cap_amort_per; 
	        let v_fechaini = v_app_t.acu_fecvencuo;
	    end foreach
	else
	    WHILE (v_fechaper < v_fechalimit_prg) or (v_amt_resto > 0 and v_period = 1 and p_nroamort_int = 1) -- while para generar el plan de pagos
	        let v_app_t = f_init_app_t();
			
	        let v_app_t.acu_codmod = p_app_t.acu_codmod;
	        let v_app_t.acu_codcred = p_app_t.acu_codcred;
	        let v_app_t.acu_coddsb = p_app_t.acu_coddsb;    
	    
			if v_first = 0 then
				let v_fechaini = v_f_corterepro;
			else
				let v_fechaini = v_fechaper;		
			end if
			
	      		let v_mtp_intydias = nvl(v_mtp_intydias, 0);
	
				if v_mtp_intydias != 365 then 
		 		 -- codigo original para creditos con 360 dias
		 			if v_first = 0 then
						let v_fecvencuo = v_fechaper;
			            let v_first = 1;
			            let v_app_t.acu_fecinicuo = v_f_corterepro;
			            let v_fechaini = v_f_corterepro;
			        else
			            IF NRODIASPERIODO > 0 AND p_app_t.acu_unidplaz IN(1,7) THEN
			                let v_app_t.acu_fecinicuo = v_fechaper + 1;
			                let v_fecvencuo = v_fechaper + NRODIASPERIODO;
			            else
			                --call f_infoperiodo(v_fechaper + 1, v_fechaper, p_app_t.acu_unidplaz, C_INPUT_PERIOD_EXACT) returning MONTHSPERPERIOD, v_fechaini, v_fecvencuo;		            
							let v_fecvencuo = f_periodo_fechafin(v_fechaper, 2, p_app_t.acu_unidplaz, NRODIASPERIODO, 3);
			            end if
			            let v_app_t.acu_fecinicuo = v_fechaper;
			            let v_fechaini = v_fechaper;
			               
			        end if
			        let v_app_t.acu_fecvencuo = v_fecvencuo;            
			        -- v_fecha_prim_amort almacena la fecha ini de cap
			        if v_app_t.acu_fecvencuo >= v_fecha_prim_amort then
			            if nvl(v_cap_amort_per, 0) <= 0 then
			                let v_cap_amort_per = v_amt_resto;
			            end if
			            
			            let v_capamortper = v_amt_resto - v_cap_amort_per;
			            if v_capamortper < 0 then
			                let v_capamortper = v_amt_resto;
			            else
			                if v_app_t.acu_fecvencuo < v_fechalimit_prg then
			                    let v_capamortper = v_cap_amort_per;
			                else 
			                    let v_capamortper = v_amt_resto;
			                end if
			            end if
			            
			            if v_capamortper <= 0 then
			                let v_amt_resto = 0;
			                exit while;
			            end if
			        end if        
			
			        call f_DAYS_BETWEEN_2_DATES(v_fechaini, v_app_t.acu_fecvencuo, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS;        
			
			        let v_app_t.acu_capital = v_siap;    
			        let v_app_t.acu_fecinicuo = v_fechaini;
	
			        if v_app_t.acu_fecvencuo >= p_fecha_prim_amortint then
			        -- fecha de proceso de interes
			            let v_app_t.acu_fecfincuo = v_app_t.acu_fecvencuo;
			        else        
			            let v_app_t.acu_fecfincuo = p_fecha_prim_amortint;
			        end if
			        let v_app_t.acu_tasa = p_app_t.acu_tasa;
			        if p_app_t.acu_tasa is null or p_app_t.acu_tasa <= 0 then
			        	let v_app_t.acu_tasa = f_gettasavigenteprest(p_app_t.acu_codcred, p_app_t.acu_codmod, v_app_t.acu_fecvencuo-1);
			        end if
			        
			        let v_intper = round(v_siap * D_DIFFERENCE_IN_DAYS * f_tasaindiceperiodo(p_app_t.acu_unidplaz, v_app_t.acu_tasa, C_TASAPERIODO, P_TRAINTYDAYS, 1), 2);
			        
			        let v_sidp = round(v_siap - v_capamortper, 2);        
			        
			        let v_app_t.acu_valor = v_capamortper;
			        let v_app_t.acu_interes = v_intper;
			        
			        return v_app_t,D_DIFFERENCE_IN_DAYS with resume;
			
			        let v_siap = v_sidp;
			        let v_period = v_period + 1;
			        let v_amt_resto = v_amt_resto - v_capamortper;        
			        LET v_fechaper = v_app_t.acu_fecvencuo;
			        let v_contctrl = v_contctrl + 1;
	   		 		   	
	       		 end if
	      		
				if v_mtp_intydias = 365 then	
	   		 		 if v_first = 0 then
				            call f_infoperiodo(null, v_fecha_prim_venc, p_app_t.acu_unidplaz, C_INPUT_PERIOD_EXACT) returning MONTHSPERPERIOD, v_fechaini, v_fecvencuo;
				           
				            let v_first = 1;
				            let v_app_t.acu_fecinicuo = v_f_corterepro;
				            let v_fechaini = v_f_corterepro;
				           
				            let v_app_t.acu_fecvencuo = v_fecvencuo; -- CODIGO AnaADIDO
				            call f_DAYS_BETWEEN_2_DATES(v_fechaini, v_app_t.acu_fecvencuo, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS; -- CODIGO AADIDO
				     else
				            IF NRODIASPERIODO > 0 AND p_app_t.acu_unidplaz IN(1,7) then					            
				                let v_app_t.acu_fecinicuo = v_fechaper + 1;
				                let v_fecvencuo = v_fechaper + NRODIASPERIODO;
				                let v_app_t.acu_fecvencuo = v_fecvencuo; -- CODIGO AnaADIDO
				            else
				       			call f_infoperiodo(v_fechaper + 1, v_fechaper, p_app_t.acu_unidplaz, C_INPUT_PERIOD_EXACT) returning MONTHSPERPERIOD, v_fechaini, v_fecvencuo;
				       			
			       				if FLAG_GESTION_365=0 then
					       				let FLAG_GESTION_365=1;	
					       			
					       				if MOD(DAY(v_fecvencuo), 2) = 0 then -- verificarmos que el dia de la fecha de vencimiento de cuota anterior es par
					       					let v_app_t.acu_fecvencuo = v_fecvencuo-1;
					       				else
					       					let v_app_t.acu_fecvencuo = v_fecvencuo+1;	
					       				end if
					       				--let v_app_t.acu_fecvencuo = v_fecvencuo-1;								       				
					       				let v_fechaini=v_fechaini-1; 
					       		else
					       				let FLAG_GESTION_365=0;
										let v_app_t.acu_fecvencuo = v_fecvencuo;
					       		end if	
				            end if
				            
				            let v_app_t.acu_fecinicuo = v_fechaini;
				            let v_fechaini = v_fechaper;
				           
				            call f_DAYS_BETWEEN_2_DATES(v_fechaini, v_app_t.acu_fecvencuo, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS; -- CODIGO AADIDO
			           		if FLAG_GESTION_365=0 then
			           			if MOD(DAY(v_fecvencuo), 2) = 0 then -- verificarmos que el dia de la fecha de vencimiento de cuota anterior es par
						       		let D_DIFFERENCE_IN_DAYS=D_DIFFERENCE_IN_DAYS+1;				
						       	else
						       		let D_DIFFERENCE_IN_DAYS=D_DIFFERENCE_IN_DAYS-1;			
						       	end if	
				       		end if
				     end if
			        if v_app_t.acu_fecvencuo >= v_fecha_prim_amort then
			            if nvl(v_cap_amort_per, 0) <= 0 then
			                let v_cap_amort_per = v_amt_resto;
			            end if
			            
			            let v_capamortper = v_amt_resto - v_cap_amort_per;
			          
			            if v_capamortper < 0 then
			                let v_capamortper = v_amt_resto;
			            else
			                if v_app_t.acu_fecvencuo < v_fechalimit_prg then
			                	-- codigo aadido para sumar el ajuste en la ultima cuota del plan de pagos para creditos de 365 dias
			                	if v_capamortper >0 and v_capamortper < 1 then
			                		let v_capamortper = v_cap_amort_per+v_capamortper;
			                	else
			                		let v_capamortper = v_cap_amort_per;
			                	end if
			                    --let v_capamortper = v_cap_amort_per; -- codigo original
			                else 
			                    let v_capamortper = v_amt_resto;
			                end if
			            end if
			            
			            if v_capamortper <= 0 then
			                let v_amt_resto = 0;
			                exit while;
			            end if
			        end if        
			
			        --let v_app_t.acu_numcuo = v_period;
			        let v_app_t.acu_capital = v_siap;    
			        let v_app_t.acu_tasa = p_app_t.acu_tasa;
			        let v_app_t.acu_fecinicuo = v_fechaini;
	
			        if p_fecha_prim_amortint <= v_app_t.acu_fecvencuo then
			        -- fecha de proceso de interes
			            let v_app_t.acu_fecfincuo = v_app_t.acu_fecvencuo;
			        else        
			            let v_app_t.acu_fecfincuo = p_fecha_prim_amortint;
			        end if
			        
			        if p_app_t.acu_tasa is null or p_app_t.acu_tasa <= 0 then
			            let v_app_t.acu_tasa = f_gettasavigenteprest(p_app_t.acu_codcred, p_app_t.acu_codmod, v_fechaini);
			        end if
			         -- obtiene el interes de acuerdo a la cantidad de dias que se encuentra en la variable D_DIFFERENCE_IN_DAYS
			         -- let v_intper = round(v_siap * f_tasaindiceperiodo(p_app_t.acu_unidplaz, v_app_t.acu_tasa, C_TASAPERIODO, P_TRAINTYDAYS, D_DIFFERENCE_IN_DAYS), 2);
		            let v_intper = round(((v_siap * v_app_t.acu_tasa)/36000), 2)* D_DIFFERENCE_IN_DAYS ; -- multiplicacion de dias por fuera del redondeo 
			        let v_sidp = round(v_siap - v_capamortper, 2);        
			        
			        let v_app_t.acu_valor = v_capamortper;
			        let v_app_t.acu_interes = v_intper;
		        
			        return v_app_t,D_DIFFERENCE_IN_DAYS with resume;
			
			        let v_siap = v_sidp;
			        let v_period = v_period + 1;
			        let v_amt_resto = v_amt_resto - v_capamortper;        
					--LET v_fechaper = v_app_t.acu_fecvencuo; -- codigo original
			        LET v_fechaper = v_fecvencuo; -- codigo ajustado
			        let v_contctrl = v_contctrl + 1;
				end if
				
		        if v_contctrl > C_NROMAXPERS then
		            --exit while;
		            raise exception -746,0,"Atencion!! Numero de periodos excede el limite, revise los parametros.";
		        end if
	    end while
    end if
end function;




