


drop function if exists d_creditos.f_infoperiodo;
CREATE function d_creditos.f_infoperiodo( INPUT_D_PERIOD_START DATE, INPUT_D_PERIOD_END DATE, INPUT_PERIODICITY integer, INPUT_PERIOD_BASE integer)
returning integer, DATE, DATE
-- INPUT_EXACTFECVALOR: 0= fecha exacta, 1= mover a fecha habil
 -- 1	IRREGULAR                         
-- 2	SEMESTRAL
-- 3	ANUAL                         
-- 5	TRIMESTRAL
-- 6	MENSUAL                       
-- 7	DIARIO                       
--INPUT_PERIOD_BASE 
--  3: fechas exactas
--  2: periodo fiscal
--  1: calendario
    DEFINE ST_D_PERIOD,END_D_PERIOD, ST_D_PERIODHABIL, END_D_PERIODHABIL DATE;
    DEFINE ST_MM_BUDGET, END_MM_PERIOD, i, ST_MM_PERIOD, FREQUENCYPERYEAR, MONTHSPERPERIOD, P_SEQ_PERIOD integer;
    DEFINE C_MODGRAL INTEGER ;
    DEFINE v_factor integer;
    DEFINE W_FIRST_DATE DATE;
    DEFINE W_LAST_DATE DATE;
    
    let ST_D_PERIODHABIL = null;
    let END_D_PERIODHABIL = null;
    let v_factor = 1;
    let ST_D_PERIOD = INPUT_D_PERIOD_START;    
    if INPUT_D_PERIOD_START is null then
        let ST_D_PERIOD = INPUT_D_PERIOD_END;
        let v_factor = -1;
    end if
    
    let ST_MM_BUDGET = 0;
    let MONTHSPERPERIOD = 0;
    let P_SEQ_PERIOD = 0;
    let C_MODGRAL = 1 ;
    let FREQUENCYPERYEAR = 0;

    IF (INPUT_PERIOD_BASE = 2) THEN
    -- mes inicio anio fiscal
        SELECT TO_NUMBER(clv_valor)
           INTO ST_MM_BUDGET
           from sac_claves 
            where clv_codclv = 'MESINIFISC';
        let ST_MM_BUDGET = nvl(ST_MM_BUDGET, 1);
     END IF;

    let FREQUENCYPERYEAR    = f_ISREPMTSPERYEAR(INPUT_PERIODICITY);
    
    IF( INPUT_PERIODICITY in (1,7) ) THEN -- DIARIO irregular
        let P_SEQ_PERIOD = P_SEQ_PERIOD + 1;
        
        if ST_D_PERIOD is not null and INPUT_D_PERIOD_END is not null and INPUT_D_PERIOD_END < ST_D_PERIOD then
            return MONTHSPERPERIOD, INPUT_D_PERIOD_END, ST_D_PERIOD;
        else
            return MONTHSPERPERIOD, ST_D_PERIOD, INPUT_D_PERIOD_END;
        end if
        
        -- return MONTHSPERPERIOD, ST_D_PERIOD, INPUT_D_PERIOD_END;
    ELSE
        IF( INPUT_PERIODICITY IN (6,16) ) THEN --mesnual
            let MONTHSPERPERIOD = 1;
            IF( INPUT_PERIOD_BASE = 3 ) THEN -- periodos EXCATOs
                let END_D_PERIOD = ADD_MONTHS( ST_D_PERIOD, MONTHSPERPERIOD * v_factor) - 1;
            ELSE
                let END_D_PERIOD = LAST_DAY( ST_D_PERIOD);
            END IF;
        ELSE
            IF( INPUT_PERIODICITY  IN (5, 15) ) THEN --TRIMESTRAL
                let MONTHSPERPERIOD     = 3;
                -- let FREQUENCYPERYEAR    = 4;
            ELIF( INPUT_PERIODICITY IN (2,12) ) THEN -- SEMESTRAL
                let MONTHSPERPERIOD     = 6;
                -- let FREQUENCYPERYEAR    = 2;
            ELIF( INPUT_PERIODICITY IN (3, 13) ) THEN -- ANUAL
                let MONTHSPERPERIOD     = 12;
                -- let FREQUENCYPERYEAR    = 1;
            END IF;
            
            --let ST_D_PERIOD = INPUT_D_PERIOD_START;
            -- PERIODO BASE DE CAP
            IF( NVL( INPUT_PERIOD_BASE, 3 ) = 3 ) THEN -- exacos
                let END_D_PERIOD = ADD_MONTHS( ST_D_PERIOD, MONTHSPERPERIOD * v_factor) - 1;
            ELIF( INPUT_PERIOD_BASE = 1 ) THEN -- calendar
                let ST_MM_PERIOD = month(ST_D_PERIOD); -- TO_NUMBER( TO_CHAR( INPUT_D_PERIOD_START, 'MM' ) );

                FOR I = 1 TO FREQUENCYPERYEAR 
                    IF(( ST_MM_PERIOD / MONTHSPERPERIOD ) <= I ) THEN
                        let END_MM_PERIOD = I * MONTHSPERPERIOD;
                        EXIT;
                    END IF;
                END FOR;
                let END_D_PERIOD = ADD_MONTHS( LAST_DAY( ST_D_PERIOD), (END_MM_PERIOD - ST_MM_PERIOD) * v_factor );
            ELSE -- fiscal
                let ST_MM_PERIOD = month(ST_D_PERIOD); -- TO_NUMBER( TO_CHAR( INPUT_D_PERIOD_START, 'MM' ) );
                IF ST_MM_PERIOD < ST_MM_BUDGET THEN
                    let ST_MM_PERIOD = ST_MM_PERIOD + 12;
                END IF;
                FOR I = 1 TO FREQUENCYPERYEAR
                    IF(( ST_MM_PERIOD - ST_MM_BUDGET + 1 ) / MONTHSPERPERIOD <= I ) THEN
                        let END_MM_PERIOD =( MONTHSPERPERIOD * I ) + ST_MM_BUDGET - 1;
                        EXIT;
                    END IF;
                END FOR;
                let END_D_PERIOD =  ADD_MONTHS( LAST_DAY( ST_D_PERIOD ), (END_MM_PERIOD - ST_MM_PERIOD) * v_factor );
            END IF;
        END IF;
    END IF;
    
    if ST_D_PERIOD > END_D_PERIOD then
        let W_FIRST_DATE = END_D_PERIOD;
        let W_LAST_DATE = ST_D_PERIOD;
    else
        let W_FIRST_DATE = ST_D_PERIOD;
        let W_LAST_DATE = END_D_PERIOD;    
    end if
    
    --        let W_FIRST_DATE = ST_D_PERIOD;
    --    let W_LAST_DATE = END_D_PERIOD;    
        return MONTHSPERPERIOD, W_FIRST_DATE, W_LAST_DATE;
END FUNCTION;


