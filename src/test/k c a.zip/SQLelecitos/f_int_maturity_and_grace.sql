


DROP function IF EXISTS d_creditos.f_int_maturity_and_grace;
create function d_creditos.f_int_maturity_and_grace(p_codmod integer, p_codcred integer, p_coddsb integer)
      returning date, date, date, date, date
{
wherrera: 2021.12.08    retorna::
primera fecha de desembolso
primer vcto 
primer vtco kapital
primer vcto interes
ultima cuota de amortizacion
}
    define D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY date;
    define G_D_MATURITY, G_D_GRACE, G_D_GRACEINT  date;
    define v_fecmin, v_fecmax, v_dsb_fecini, v_dsb_feciniint, v_dsb_fecdsb date;
    define v_fecmindsb, v_fecprimvencap, v_fecprimvenint date;
    define v_dsb_coddsb integer;
    define v_pre_methodcapi, v_pre_unidplaz, v_pre_nroperiodos, v_pre_nrogracia, v_pre_nrograciaint, v_pre_nropagos, v_pre_diasfijoper integer;
    DEFINE v_dsb_undsb, v_dsb_saldo like pre_desemb.dsb_valor; 

    call f_dsb_getmethod_plz(p_codcred, p_codmod, null) returning v_pre_methodcapi, v_pre_unidplaz;
    call f_get_info_genperiodos(p_codcred, p_codmod) returning v_pre_nroperiodos, v_pre_nrogracia, v_pre_nrograciaint, v_pre_nropagos, v_pre_diasfijoper; 
            
        let G_D_GRACE = NULL;
        let G_D_GRACEINT = NULL;
        let G_D_MATURITY = NULL;
        let v_fecmin = null;
        let D_PRIMVCTO = null;
        let v_fecmindsb = null;

        foreach 
            select dsb_coddsb, dsb_fecdsb , dsb_fecini, dsb_feciniint, nvl(dsb_undsb, 0), nvl(dsb_saldo, 0)
            into v_dsb_coddsb, v_dsb_fecdsb, v_dsb_fecini, v_dsb_feciniint, v_dsb_undsb, v_dsb_saldo
            from pre_desemb 
            where dsb_codmod = p_codmod
            and dsb_codcred = p_codcred
            and dsb_coddsb = nvl(p_coddsb, dsb_coddsb)
            order by dsb_fecdsb
            
                IF nvl(v_fecmindsb, v_dsb_fecdsb) >= v_dsb_fecdsb then
                    let v_fecmindsb = v_dsb_fecdsb;
                end if
                
               IF (NVL(G_D_GRACE, v_dsb_fecini) >= v_dsb_fecini) THEN
                  let G_D_GRACE = v_dsb_fecini;
               END IF;
               
               IF (NVL(G_D_GRACEINT, v_dsb_feciniint) >= v_dsb_feciniint) THEN
                  let G_D_GRACEINT = v_dsb_feciniint;
               END IF;
               
               let v_fecmax = null;
               if v_dsb_saldo > 0 then
                    call f_pp_minmax_plan(p_codcred, p_codmod, v_dsb_coddsb, null) returning v_fecmin, v_fecmax;
                end if
                
               IF (NVL(G_D_MATURITY, NVL(v_fecmax,v_dsb_fecini)) <= NVL(v_fecmax,v_dsb_fecini)) THEN
                  let G_D_MATURITY = NVL(v_fecmax,v_dsb_fecini);
               END IF;
         END foreach

        let D_SIGN = v_fecmindsb;
        
        let v_fecprimvencap = f_periodo_fechafin(G_D_GRACE, v_pre_nrogracia * (-1), v_pre_unidplaz, v_pre_diasfijoper, null);
        let v_fecprimvenint = f_periodo_fechafin(G_D_GRACEINT, v_pre_nrograciaint * (-1), v_pre_unidplaz, v_pre_diasfijoper, null);                  
        
        if v_fecprimvencap <= v_fecprimvenint then
            let D_PRIMVCTO = v_fecprimvencap;
        else 
            let D_PRIMVCTO = v_fecprimvenint;
        end if    

        let D_GRACE = G_D_GRACE;
        let D_GRACEINT = G_D_GRACEINT;
        
        if D_PRIMVCTO > D_GRACEINT then
            let D_PRIMVCTO = D_GRACEINT;
        end if
        
        if D_PRIMVCTO > D_GRACE then
            let D_PRIMVCTO = D_GRACE;
        end if

        let v_fecmax = f_periodo_fechafin(D_PRIMVCTO, v_pre_nroperiodos, v_pre_unidplaz, v_pre_diasfijoper, null);
        
        if v_fecmax < G_D_MATURITY then
            let D_MATURITY = G_D_MATURITY;
        else
            let D_MATURITY = v_fecmax;
        end if

        return D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY;
        
END function;




