


DROP function IF EXISTS d_creditos.f_pp_cuota_amortiza;
create function d_creditos.f_pp_cuota_amortiza(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_tipocuo integer, p_pporpv integer)
        returning decimal(20,2)
{
wherrera: 2026.05.05    se cambia para determinar el monto amortizado a una fecha
p_pporpv: 1 del pp general
2: para el pp auxiliar
}
    define C_TIPOCOB_PANTI_CAP, C_TIPOTRX_COB, C_TIPOCUO_CAP, C_TIPOCUO_INT integer;
    define v_sum_dif_fecdiff,v_sum_dif_feccob,v_sum_cap_valor, v_scap_pa_valor, v_sum_dif_valor, v_mnt_amort like pre_planpagos.cuo_valor;
    
    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
    let C_TIPOTRX_COB = 2;
    let C_TIPOCOB_PANTI_CAP = 12;
	let v_sum_cap_valor = 0;
	let v_scap_pa_valor = 0;
	let v_sum_dif_valor = 0;
	let v_mnt_amort = 0;
    let v_sum_dif_fecdiff = 0;
    let v_sum_dif_feccob = 0;
	let p_pporpv = nvl(p_pporpv, 1);
	
    let p_fecha = nvl(p_fecha, mdy(1,1,3000));
	if (p_pporpv = 2) then
		select nvl(sum(vpp_valor), 0)
	    into v_sum_cap_valor
	    from v_pp_auxyplanpagos
	    where vpp_codmod = p_codmod
	    and vpp_codcred = p_codcred
	    and vpp_fecvencuo = p_fecha
	    and vpp_tipocuo in (C_TIPOCUO_CAP,C_TIPOCOB_PANTI_CAP)
	    and vpp_coddsb = nvl(p_coddsb, vpp_coddsb)
	    and vpp_coddsb > 0;
	    
		select nvl(sum(vpp_valor), 0)
	    into v_scap_pa_valor
	    from v_pp_auxyplanpagos
	    where vpp_codmod = p_codmod
	    and vpp_codcred = p_codcred
	    and vpp_fecvencuo = p_fecha
	    and vpp_tipocuo = C_TIPOCOB_PANTI_CAP
	    and vpp_coddsb = nvl(p_coddsb, vpp_coddsb)
	    and vpp_coddsb > 0;
		
	else
		select nvl(sum(cuo_valor), 0)
	    into v_sum_cap_valor
	    from pre_planpagos
	    where cuo_codmod = p_codmod
	    and cuo_codcred = p_codcred
	    and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
	    and cuo_coddsb > 0
	    and cuo_tipocuo in (C_TIPOCUO_CAP,C_TIPOCOB_PANTI_CAP)
	    and cuo_fecvencuo = p_fecha; --feval

		let v_sum_dif_fecdiff = f_pp_sum_importetrx(p_codcred , p_codmod , p_coddsb , p_fecha, p_fecha, 1, 4, 4);		    
		let v_sum_dif_feccob = f_pp_sum_importetrx(p_codcred , p_codmod , p_coddsb , p_fecha, p_fecha, 1, 2, 4);
		let v_sum_dif_valor = v_sum_dif_feccob - v_sum_dif_fecdiff; 
	end if
	
    let v_mnt_amort = v_sum_cap_valor + v_scap_pa_valor + v_sum_dif_valor;
    return nvl(v_mnt_amort, 0);

end function;


