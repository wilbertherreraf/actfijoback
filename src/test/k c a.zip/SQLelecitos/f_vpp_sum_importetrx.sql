

DROP function IF EXISTS d_creditos.f_vpp_sum_importetrx;
create function d_creditos.f_vpp_sum_importetrx(p_codcred integer, p_codmod integer, p_coddsb integer, p_fechaini date, p_fechafin date, p_tipocuo integer, p_tipotrx integer, p_tipoacu integer)
returning decimal(20,2) as VALOR, decimal(20,2) as VALORPEND

define v_sum_pp,v_sum_pppend like pre_planpagos.cuo_valor;
define C_TIPOCUO_INT, C_TIPOTRX_COB integer;

let C_TIPOCUO_INT = 2;
let C_TIPOTRX_COB = 2;

    let p_fechaini = nvl(p_fechaini, mdy(1,1,1980));
    let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));

    select nvl(sum(vpp_valor), 0) , nvl(sum(vpp_valorpend), 0) 
    INTO v_sum_pp, v_sum_pppend
    from v_pp_auxyplanpagos
    where vpp_codcred = p_codcred 
    and vpp_codmod = p_codmod 
    and vpp_fecvencuo between p_fechaini and p_fechafin        
    and vpp_coddsb = nvl(p_coddsb, vpp_coddsb)
    and vpp_coddsb > 0
    and vpp_tipocuo = nvl(p_tipocuo, vpp_tipocuo);

return v_sum_pp, v_sum_pppend;
end function;



