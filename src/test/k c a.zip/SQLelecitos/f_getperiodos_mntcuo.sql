


drop function if exists d_creditos.f_getperiodos_mntcuo;
create function d_creditos.f_getperiodos_mntcuo(v_app_t aux_planpagos_t, v_feciniint date, D_MATURITY date, 
    NPER integer, NRODIASPERIODO INTEGER)
    returning integer, integer, integer, integer, date, date

{***** ==> LOG <== *****
wherrera    2021-10-05  determina el numero de periodos 
}
    define v_fecha_fin_venc, v_fecha_prim_venc, v_fecmax_cap date;
    define v_min_fecdsb, v_min_fecvencuo, v_fecini, v_max_fecvencuo date;
    define C_TIPOCUO_CAP, C_TIPOCUO_INT integer;
    define C_INPUT_PERIOD_EXACT integer;
    define v_new_nropagos, v_new_nrograciaint, v_new_nrogracia, v_new_nroperiodos, v_nroper_pp_cal, v_numpers integer;

    let v_numpers = 0;
    LET C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
    let C_INPUT_PERIOD_EXACT = 3;
            
        if nvl(v_feciniint, v_app_t.acu_fecfincuo) < v_app_t.acu_fecfincuo then
            let v_fecha_prim_venc = nvl(v_feciniint, v_app_t.acu_fecfincuo);
        else 
            let v_fecha_prim_venc = v_app_t.acu_fecfincuo;
        end if
        -- periodos entre dsb - min 1er vcto

        call f_periodos_fechas(v_app_t.acu_fecinicuo, v_fecha_prim_venc, v_app_t.acu_unidplaz, NRODIASPERIODO, C_INPUT_PERIOD_EXACT, 1,0) 
            returning v_numpers, v_nroper_pp_cal, v_fecmax_cap;
        -- requerido por formula
        let v_numpers = v_nroper_pp_cal - 1;
        
        if v_numpers < 0 then
            let v_numpers = 0;
        end if
        
        -- 1ra cuota
        let v_app_t.acu_fecvencuo = f_periodo_fechafin(v_fecha_prim_venc, v_numpers * (-1), v_app_t.acu_unidplaz, NRODIASPERIODO, null);
        if v_app_t.acu_fecvencuo <=  v_app_t.acu_fecinicuo then
            let v_numpers = v_nroper_pp_cal - 2;
            
            if v_numpers < 0 then
                let v_numpers = 0;
            end if
            
            -- 1ra cuota
            let v_app_t.acu_fecvencuo = f_periodo_fechafin(v_fecha_prim_venc, v_numpers * (-1), v_app_t.acu_unidplaz, NRODIASPERIODO, null);        
        
        end if
        --raise exception -746,0,v_app_t.acu_fecinicuo || " " || v_fecha_prim_venc || " " || v_nroper_pp_cal || " " || v_numpers || " plz " || v_app_t.acu_unidplaz || " np " || NRODIASPERIODO || " " || v_app_t.acu_fecvencuo;        
        let v_fecha_fin_venc = f_periodo_fechafin(v_app_t.acu_fecvencuo, NPER, v_app_t.acu_unidplaz, NRODIASPERIODO, null);
        
        if v_fecha_fin_venc >= nvl(D_MATURITY, v_fecha_fin_venc) then
        --desembolso posterior al gral
            let v_fecha_fin_venc = nvl(D_MATURITY, v_fecha_fin_venc);
        end if
        
        call f_fec_primervenc(v_app_t.acu_codcred, v_app_t.acu_codmod, v_feciniint, 3)
            returning v_min_fecdsb, v_min_fecvencuo, v_fecini, v_feciniint, v_max_fecvencuo;
        
        let v_fecha_fin_venc = v_max_fecvencuo;
        
        call f_periodos_fechas(v_app_t.acu_fecvencuo, v_fecha_fin_venc, v_app_t.acu_unidplaz, NRODIASPERIODO, C_INPUT_PERIOD_EXACT,1,0) 
            returning v_new_nroperiodos, v_nroper_pp_cal, v_fecmax_cap;
                    
        call f_periodos_fechas(v_app_t.acu_fecfincuo, v_fecha_fin_venc, v_app_t.acu_unidplaz, NRODIASPERIODO, C_INPUT_PERIOD_EXACT,1, 0) 
            returning v_new_nropagos, v_nroper_pp_cal, v_fecmax_cap;
        
        call f_periodos_fechas(v_app_t.acu_fecvencuo, v_app_t.acu_fecfincuo, v_app_t.acu_unidplaz, NRODIASPERIODO, C_INPUT_PERIOD_EXACT,1, 0) 
            returning v_new_nrogracia, v_nroper_pp_cal, v_fecmax_cap;
        
        let v_new_nrogracia = v_new_nrogracia - 1;
        if v_new_nrogracia < 0 then
            let v_new_nrogracia = 0;
        end if
        call f_periodos_fechas(v_app_t.acu_fecvencuo, v_feciniint, v_app_t.acu_unidplaz, NRODIASPERIODO, C_INPUT_PERIOD_EXACT, 1,0) 
            returning v_new_nrograciaint, v_nroper_pp_cal, v_fecmax_cap;
            
        let v_new_nrograciaint = v_new_nrograciaint - 1;
        
        if v_new_nrograciaint < 0 then
            let v_new_nrograciaint = 0;
        end if
                    
    return v_new_nroperiodos, v_new_nropagos, v_new_nrogracia, v_new_nrograciaint, v_app_t.acu_fecvencuo, v_fecha_fin_venc;
end function;
