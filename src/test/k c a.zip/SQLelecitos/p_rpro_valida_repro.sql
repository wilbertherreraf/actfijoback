


DROP procedure IF exists d_creditos.p_rpro_valida_repro;
create procedure d_creditos.p_rpro_valida_repro(p_codrepro integer, p_tipotrx integer)

define v_rds_feciniint, v_rds_feculttrx, v_rds_fecini, v_rds_fecfin  date;
define v_rds_methodcapi, v_rds_unidplazint, v_pre_methodcapi integer;
define v_rds_codrepro, v_rds_diasfijoper, v_rds_unidplaz, v_rds_statreg integer;
define v_rds_undsb, v_rds_valor, v_rds_saldo like pre_reprograma.rds_valor;
define v_rds_nroperiodos, v_rds_nrogracia, v_rds_nropagos integer;
define v_rds_codmod, v_rds_codcred, v_repropend,v_rds_trxstaau integer;
define v_feculttrx,v_rds_fecinidif,v_fmenor date;
define v_cont, C_TIPOREPRO_REPRO,v_rds_tiporepro integer;
    
    let C_TIPOREPRO_REPRO = 1;
    
    if p_tipotrx = 9 then
    	return;
    end if
    
    select rds_codmod, rds_codcred, rds_fecini, rds_feciniint, rds_fecfin, rds_undsb,rds_valor, rds_saldo, rds_unidplaz, rds_unidplazint, rds_feculttrx,
            rds_nroperiodos, rds_nrogracia, rds_nropagos, rds_diasfijoper, rds_statreg,rds_tiporepro,rds_trxstaau,rds_fecinidif
    into v_rds_codmod, v_rds_codcred, v_rds_fecini, v_rds_feciniint, v_rds_fecfin, v_rds_undsb, v_rds_valor, v_rds_saldo, v_rds_unidplaz, v_rds_unidplazint, v_rds_feculttrx,
            v_rds_nroperiodos, v_rds_nrogracia, v_rds_nropagos, v_rds_diasfijoper, v_rds_statreg,v_rds_tiporepro,v_rds_trxstaau,v_rds_fecinidif
    from pre_reprograma
    where rds_codrepro = p_codrepro
    and rds_statreg = 0;
	
    IF (dbinfo("sqlca.sqlerrd2") = 0) THEN
        raise exception -746, 0, "Registro de Reprogramacion inexistente o suspendido " || p_codrepro;  
    end if
    
    if v_rds_trxstaau = 3 or v_rds_trxstaau = 9 then
    	return;
    end if
    
    select pre_feculttrx
    into v_feculttrx
    from pre_prestamos
    where  pre_codcred = v_rds_codcred
    and pre_codmod = v_rds_codmod;
    
    let v_feculttrx = nvl(v_feculttrx,f_acr_ult_fec_acr(v_rds_codcred, v_rds_codmod, null, date(current), 3));
    
    if v_rds_tiporepro = C_TIPOREPRO_REPRO then
    	if v_rds_fecinidif is null then
    		raise exception -746, 0, "Registro de Reprogramacion fecha corte debe tener valor, idrepro: " || p_codrepro;
    	end if
    	if v_rds_feciniint is null then
    		raise exception -746, 0, "Registro de Reprogramacion primera fecha de amortizacion interes debe tener valor, idrepro: " || p_codrepro;
    	end if
    	if v_rds_fecini is null then
    		raise exception -746, 0, "Registro de Reprogramacion primera fecha de amortizacion capital debe tener valor, idrepro: " || p_codrepro;
    	end if
    	let v_fmenor = LEAST(v_rds_fecini,v_rds_feciniint,v_rds_fecinidif);
    
	    select count(1) 
	    into v_cont
	    from pre_desemb 
	    where dsb_codcred = v_rds_codcred
	    and dsb_codmod = v_rds_codmod
	    and dsb_fecdsb < v_fmenor; 
	    
	    if v_cont = 0 then
	    	raise exception -746,0,"No existe ningun desembolso anterior a fecha: " || v_fmenor;
	    end if
	    
	    if v_feculttrx is null then
	        raise exception -746,0,"No existe ninguna transaccion realizada, no puede reprogramar, modifique cronograma." || p_codrepro ;
	    end if
	
	    if nvl(v_rds_nroperiodos, 0) <= 0 then
	        raise exception -746,0,"Numero de periodos requerido " || p_codrepro ;
	    end if
	    
	    if v_feculttrx >= v_fmenor then
	        raise exception -746,0,"Fecha de ultima actividad(" || v_feculttrx || ") mayor a fecha de reprogramacion " || v_fmenor;
	    end if
	    
	    select count(1)
	    into v_cont
	    from pre_reprograma
	    where rds_codmod = v_rds_codmod
	    and rds_codcred = v_rds_codcred
	    and rds_statreg = 0
	    and rds_trxstaau in (1,2)
	    and rds_tiporepro = C_TIPOREPRO_REPRO
	    and rds_codrepro != p_codrepro;
	    
	    if v_cont > 0 then
	        raise exception -746,0,"Existen reprogramaciones pendientes";
	    end if
	    
	    select count(1)
	    into v_cont
	    from pre_reprograma
	    where rds_codmod = v_rds_codmod
	    and rds_codcred = v_rds_codcred
	    and rds_statreg = 0
	    and rds_trxstaau in (1,2,3)
	    and rds_tiporepro = C_TIPOREPRO_REPRO
	    and rds_fecinidif = v_rds_fecinidif
	    and rds_codrepro != p_codrepro;
	    
	    if v_cont > 0 then
	        raise exception -746,0,"Existen reprogramaciones para fecha " || v_rds_fecinidif || " elimine o suspenda las otras reprogramaciones para continuar.";
	    end if	    
    end if    
end procedure;


