

DROP function IF EXISTS d_creditos.f_getgracia;
create function d_creditos.f_getgracia(p_codcred integer, p_codmod integer, p_fecha date, p_tipocuo integer)
returning integer, integer, integer
{***** ==> LOG <== *****

wherrera    2021-11-05  identificador de ultima reprogramacion anterior a una fecha
}
    define v_year, v_month, v_days integer;
    define v_min_fecdsb, v_min_fecvencuo, v_fecini, v_feciniint, v_max_fecvencuo, v_pre_fecprimpag date;
    define C_TIPOCUO_INT, C_TIPOCUO_CAP integer;
    define v_pre_nroperiodos, v_pre_nrogracia, v_pre_nrograciaint, v_pre_nropagos, v_pre_diasfijoper integer;
	define v_pre_fecplzven,v_dsb_fecdsb , v_dsb_fecini, v_dsb_fecfin, v_dsb_feciniint date;
    
    let C_TIPOCUO_INT = 2;
    let C_TIPOCUO_CAP = 1;

    let p_tipocuo = nvl(p_tipocuo, C_TIPOCUO_CAP);
    
    if p_codmod is null then
    	let p_codmod = (select max(pre_codmod) from pre_prestamos where pre_codcred = p_codcred);
    end if
    
	call f_get_info_genperiodos(p_codcred, p_codmod) returning v_pre_nroperiodos, v_pre_nrogracia, v_pre_nrograciaint, v_pre_nropagos, v_pre_diasfijoper;

	        if p_tipocuo = C_TIPOCUO_INT then
	            return v_pre_nrograciaint, 0, 0;
	        else
	            return v_pre_nrogracia, 0, 0;
	        end if
        

end function;


