

DROP function IF EXISTS d_creditos.f_gettasavigenterepro;
create function d_creditos.f_gettasavigenterepro(p_codcred integer, p_codmod integer,p_fecha date, p_trxstaau integer) returning float
{
determina la tasa vigente de un prestamo
wherrera 20260505 se ajusta para extraer la tasa para uso en procesos de reprogramacion

f_gettasavigenterepro.sql
v_pv_planpagos_consol.sql
v_pv_planpagos_dsb.sql
}
     define v_mtp_fechavig,v_rds_fecinidif date;
     define v_rds_tasa, v_mtp_tbase like pre_tasaspre.mtp_tbase;
     define v_mtp_tspread like pre_tasaspre.mtp_tspread;
    define v_cont , v_mtp_codmod, v_mtp_codcred integer;
	
	let v_rds_fecinidif = null;
	let v_mtp_fechavig = null;
	
        SELECT max(rds_fecinidif),max(rds_tasa)
        INTO v_rds_fecinidif,v_rds_tasa
        from pre_reprograma
		where rds_codcred = p_codcred
		and rds_codmod = p_codmod
		and rds_tasa > 0
		and rds_tiporepro = 1
		and rds_statreg = 0
		and rds_trxstaau in (1,2)
		and rds_fecinidif = (
			select max(x.rds_fecinidif)
	        from pre_reprograma x
			where x.rds_codcred = p_codcred
			and x.rds_codmod = p_codmod
			and x.rds_fecinidif <= p_fecha
			and x.rds_tasa > 0
			and x.rds_tiporepro = 1
			and x.rds_statreg = 0
			and x.rds_trxstaau in (1,2)			
		);
	
		SELECT  mtp_fechavig, mtp_tbase 
		into v_mtp_fechavig, v_mtp_tbase
		FROM  pre_tasaspre
		where mtp_tbase > 0
		and mtp_codcred = p_codcred
		and mtp_codmod = p_codmod
 		AND mtp_fechavig = (
            SELECT MAX(x.mtp_fechavig) 
            FROM  pre_tasaspre x
            WHERE x.mtp_codcred = p_codcred
            and x.mtp_codmod = p_codmod
            AND   x.mtp_fechavig <= p_fecha
            and x.mtp_tbase > 0
            );
		
	let v_mtp_tbase = nvl(v_mtp_tbase,0);
	
	if v_rds_fecinidif is null then
		return v_mtp_tbase;
	end if
	
	let v_rds_tasa = nvl(v_rds_tasa, 0);
	if v_mtp_fechavig is null then
		return v_rds_tasa;
	end if
	
	if v_rds_fecinidif < v_mtp_fechavig then
		return v_mtp_tbase;
	end if
   
    RETURN v_rds_tasa;
END FUNCTION;

