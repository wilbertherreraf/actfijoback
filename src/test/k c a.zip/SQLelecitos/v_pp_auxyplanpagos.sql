


drop view if exists d_creditos.v_pp_auxyplanpagos;
create view d_creditos.v_pp_auxyplanpagos(vpp_codcred, vpp_codmod, vpp_coddsb, vpp_fecvencuo,vpp_fecfincuo, vpp_valor , vpp_valorpend, vpp_cargos, vpp_desemb,
		vpp_interes,
		vpp_tipocuo, vpp_tipotrx, vpp_trxstaau) as
select acu_codcred, acu_codmod, acu_coddsb, acu_fecvencuo, acu_fecfincuo, acu_valor , acu_valorpend, acu_cargos, acu_montocuo,
		acu_interes,
		acu_tipocuo, acu_tipotrx, acu_trxstaau
from(
	select acu_codcred, acu_codmod, acu_coddsb, acu_fecvencuo, acu_fecfincuo, acu_valor , acu_valorpend, nvl(acu_cargos,0) acu_cargos, nvl(acu_montocuo,0) acu_montocuo,
		nvl(acu_interes,0) acu_interes, 
		acu_tipocuo, acu_tipotrx, nvl(acu_trxstaau,1) acu_trxstaau
	from aux_planpagos 
	where acu_coddsb > 0
	and (not exists(
			select 1
			from pre_planpagos
			where cuo_coddsb = acu_coddsb
			and cuo_codcred = acu_codcred
			and cuo_codmod = acu_codmod
		)
		or (acu_tipodsb > 0
			and exists(
				select 1
				from pre_reprograma
				where rds_codcred = acu_codcred
				and rds_codmod = acu_codmod
				and rds_trxstaau in (1,2)
				and rds_codrepro = acu_tipodsb
				and rds_statreg = 0
			))
		)
	union 
	select cuo_codcred, cuo_codmod, cuo_coddsb, cuo_fecvencuo, cuo_fecfincuo,cuo_valor, cuo_valorpend, nvl(cuo_cargos,0), nvl(cuo_desemb,0),
		nvl(cuo_interes,0),
		cuo_tipocuo, cuo_tipotrx,nvl(cuo_trxstaau,1)
	from pre_planpagos    
	where cuo_coddsb > 0 
	and not exists (select 1
		from aux_planpagos 
	    where acu_codcred = cuo_codcred
		and acu_codmod = cuo_codmod
		and acu_coddsb = cuo_coddsb
		and acu_tipodsb > 0
		and exists(
			select 1
			from pre_reprograma
			where rds_codcred = acu_codcred
			and rds_codmod = acu_codmod
			and rds_trxstaau in (1,2)
			and rds_codrepro = acu_tipodsb
			and rds_statreg = 0
		)		
	) 
) 
order by acu_codmod, acu_codcred, acu_coddsb, acu_fecvencuo;



