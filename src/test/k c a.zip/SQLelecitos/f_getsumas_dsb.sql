
DROP function IF EXISTS d_creditos.f_getsumas_dsb;
create function d_creditos.f_getsumas_dsb(p_codmod integer, p_codcred integer, p_coddsb integer, p_fechaini date, p_fechafin date)
    returning decimal(20,2)
{
retorna montos a fecha desembolso registrado en desembolso: a desembolsar,  desembolsado y cobrado

}    
    define v_amt_dsb, v_sum_valor, v_dsb_undsb like pre_desemb.dsb_valor;
    
    let p_fechaini = nvl(p_fechaini, mdy(1,1,1980));
    let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));

    if p_coddsb is null then
        select nvl(sum(dsb_valor), 0), nvl(sum(dsb_undsb), 0)
        into v_sum_valor, v_dsb_undsb
        from pre_desemb
        where dsb_codmod = p_codmod
        and dsb_codcred = p_codcred
        and dsb_fecdsb between p_fechaini and p_fechafin;
    else
        select nvl(sum(dsb_valor), 0), nvl(sum(dsb_undsb), 0)
        into v_sum_valor, v_dsb_undsb
        from pre_desemb
        where dsb_coddsb = p_coddsb
    	and dsb_fecdsb between p_fechaini and p_fechafin;    
    end if
    
    let v_amt_dsb = v_sum_valor;
    
    if v_dsb_undsb > 0 then
    	let v_amt_dsb = v_dsb_undsb; 
    end if
    
    return nvl(v_amt_dsb, 0);
end function;


