

DROP procedure IF exists d_creditos.p_rpro_aprob_planpagos;
create procedure d_creditos.p_rpro_aprob_planpagos(p_codcred integer, p_codmod integer, p_codmodtmp INTEGER, p_codrepro integer, p_coduser varchar(100), p_estacion varchar(100))

    define err_num, err_nro integer;
    define err_msg varchar(235);    

define v_rds_feciniint, v_rds_feculttrx, v_rds_fecini, v_rds_fecfin  date;
define v_dsb_coddsb, v_rds_methodcapi, v_rds_unidplazint, v_pre_methodcapi integer;
define v_rds_codrepro, v_rds_diasfijoper, v_rds_unidplaz, v_rds_statreg integer;
define v_dsb_valor, v_rds_undsb, v_rds_valor, v_rds_saldo like pre_reprograma.rds_valor;
define V_MNT_PRG_FECHA, V_MNT_PRGPEND_FECHA like pre_reprograma.rds_valor;
define v_rds_nroperiodos, v_rds_nrogracia, v_rds_nropagos integer;
define v_feculttrx date;
define C_TIPOREPRO_REPRO, v_cont integer;
DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;

    LET C_TIPOREPRO_REPRO = 1;
    
BEGIN
    ON EXCEPTION  SET err_num, err_nro, err_msg  -- trap all errors
    END EXCEPTION with resume

--    call p_srvdeu_initlog(p_coduser, p_estacion);  
    --trace procedure; 
end
BEGIN
    ON EXCEPTION  SET err_num, err_nro, err_msg  -- trap all errors
        call p_log_error(err_num, err_nro, err_msg, null);
        raise exception err_num, err_nro, err_msg ;
    END EXCEPTION    
                
    select rds_fecini, rds_feciniint, rds_fecfin, rds_undsb,rds_valor, rds_saldo, rds_unidplaz, rds_feculttrx, rds_statreg
    into v_rds_fecini, v_rds_feciniint, v_rds_fecfin, v_rds_undsb, v_rds_valor, v_rds_saldo, v_rds_unidplaz, v_rds_feculttrx, v_rds_statreg
    from pre_reprograma
    where rds_codrepro = p_codrepro
    and rds_tiporepro = C_TIPOREPRO_REPRO;

    if v_rds_statreg = 9 then
        raise exception -746,0, "Reprogramacion no se encuentra vigente " || p_codrepro;
    end if

    let v_cont = f_pv_contar(p_codcred, p_codmod, null);
    
    if v_cont = 0 then
        raise exception -746,0, "No existen registros de plan de pagos generado " || p_codrepro;
    end if

    let v_feculttrx = f_dsb_fecmax_trx(p_codmod, p_codcred, null, null);
    
    if v_feculttrx is null then
        raise exception -746,0,"REPRO: No existe ninguna transaccion realizada, reprogramacion invalida, genere cronograma.";
    end if
    
    call p_cpy_auxpp_planpagos(p_codcred, p_codmod, null, p_codrepro, p_coduser, p_estacion);
    
    update pre_reprograma
    set rds_undsb = 1,
    rds_valor = 1,
    rds_trxstaau = 3,
    rds_auditusr = p_coduser,
    rds_auditwst = p_estacion,
    rds_auditfho = current
    where rds_codrepro = p_codrepro;
END
    --call p_log_finlog();
        
end procedure;


