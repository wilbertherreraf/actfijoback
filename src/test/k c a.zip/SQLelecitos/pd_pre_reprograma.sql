


DROP procedure IF EXISTS d_creditos.pd_pre_reprograma;
create procedure d_creditos.pd_pre_reprograma(
o_rds_codrepro		like pre_reprograma.rds_codrepro	,
o_rds_codcred       like pre_reprograma.rds_codcred     ,
o_rds_codmod        like pre_reprograma.rds_codmod      ,
o_rds_fecini        like pre_reprograma.rds_fecini      ,
o_rds_feciniint     like pre_reprograma.rds_feciniint   ,
o_rds_feculttrx     like pre_reprograma.rds_feculttrx   ,
o_rds_fecinidif     like pre_reprograma.rds_fecinidif,
o_rds_valor         like pre_reprograma.rds_valor       ,
o_rds_undsb         like pre_reprograma.rds_undsb       ,
o_rds_saldo         like pre_reprograma.rds_saldo       ,
o_rds_unidplaz      like pre_reprograma.rds_unidplaz    ,
o_rds_nroperiodos   like pre_reprograma.rds_nroperiodos ,
o_rds_nrogracia     like pre_reprograma.rds_nrogracia   ,
o_rds_nropagos      like pre_reprograma.rds_nropagos    ,
o_rds_diasfijoper   like pre_reprograma.rds_diasfijoper ,
o_rds_tiporepro     like pre_reprograma.rds_tiporepro   ,
o_rds_trxstaau      like pre_reprograma.rds_trxstaau    ,
o_rds_statreg       like pre_reprograma.rds_statreg     ,
o_rds_auditusr      like pre_reprograma.rds_auditusr    ,
o_rds_auditwst      like pre_reprograma.rds_auditwst

)

{
WHERRERA    20210922    (trigger)se crea el procedimiento para control de operaciones en la eliminacion de desembolso
}
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    define C_FLAG_EXETRIGGER_PP_NOEXE integer;
    define C_TIPOREPRO_REPRO integer;
    define v_feculttrx, v_fecini_efecttasa date;
    
    let C_TIPOREPRO_REPRO = 1;    
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;
    
    if G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE then
        LET G_FLAG_EXETRIGGER_PP = -1;
        RETURN;
    end if
    
    LET G_FLAG_EXETRIGGER_PP = -1;
    
    if o_rds_tiporepro = C_TIPOREPRO_REPRO and o_rds_fecinidif is not null then
        let v_fecini_efecttasa = o_rds_fecinidif ;
        call p_actualizartasa(o_rds_codcred, o_rds_codmod, o_rds_fecinidif,	0,null,	9, o_rds_auditusr, o_rds_auditwst);
    end if
     
end procedure;


