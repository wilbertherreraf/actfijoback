

DROP procedure IF EXISTS d_creditos.p_mf_amort_genplan;
create procedure d_creditos.p_mf_amort_genplan(p_codcred integer, p_codmod integer, p_tipotrx integer, p_codrepro integer,
    p_f_corterepro date, p_fecha_prim_amort date, p_fecha_prim_amortint date, rate float, unidplaz integer, 
    p_nroamort_int INTEGER, p_usuario varchar(50), p_estacion varchar(50))
{
wherrera salva el plan de pagos generado de manera temporal en aux_planpagos
}

define v_period_ctrl, C_INPUT_PERIOD_EXACT, MONTHSPERPERIOD, v_codacu,v_SEQ_PERIOD integer;
define v_LAST_DATE, v_fecha_ini, fecha_fin,v_period_ant,v_ST_D_PERIOD, v_END_D_PERIOD,v_fechaini,v_ultvcto_t1 date;
define C_REPRO_END, C_REPRO_INI,C_TASAPERIODO, D_DIFFERENCE_IN_DAYS, v_first, C_TIPOCUO_CAP, C_TIPOCUO_INT,C_REPROTEMPO,C_TIPOTRX_COB integer;
define v_pre_methodcapi, v_pre_unidplaz, v_nropers,v_codrepro,v_nroamort_cap,v_contar,v_dsb_coddsb integer;
define v_intper_float float;
define v_fechalimit_prg,v_dsb_fecdsb,v_fecha_prim_amortint,v_f_corterepro,v_fecha_prim_venc,v_fecha_prim_amort,v_fecmax_cap,v_feculttrx date;
define v_app_t,v_appaux_t aux_planpagos_t;
define v_sumper, v_cap_amort_per,v_dsb_valor,v_siap, v_sum_ctrl, v_int_acum,v_pre_saldo decimal(20,2);
define v_dsb_fecini,v_dsb_feciniint date;
define v_pre_nroperiodos integer;
define C_TIPOREPRO_REPRO,v_nroamort_int,P_TRAINTYDAYS, P_TRAINTMDAYS,v_TRAINTYDAYS,v_nroper_calendar,C_TIPORPRO_CALENDAR,NRODIASPERIODO integer;

let C_INPUT_PERIOD_EXACT = 3;

let C_TIPOCUO_CAP = 1 ;
let C_TIPOCUO_INT = 2;
let C_REPRO_INI = 999;
let C_REPRO_END = -999;
let C_REPROTEMPO = 999;
let C_TASAPERIODO = 0;
let C_TIPOTRX_COB = 2;
let C_TIPOREPRO_REPRO = 5;
let C_TIPORPRO_CALENDAR = 12; 
let NRODIASPERIODO = 0; 

	select pre_saldo, pre_nroperiodos
	into v_pre_saldo,v_pre_nroperiodos
	from pre_prestamos
	where pre_codcred = p_codcred
	and pre_codmod = p_codmod;
	
	-- eliminamos todos los temporales de repros
	delete from aux_planpagos
    where acu_codcred = p_codcred
    and acu_codmod = p_codmod
	and acu_tabtipodsb = C_REPROTEMPO;

	select min(dsb_fecdsb),min(dsb_fecini),min(dsb_feciniint) 
	into v_dsb_fecdsb,v_dsb_fecini,v_dsb_feciniint
	from pre_desemb
	where dsb_codcred = p_codcred
	and dsb_codmod = p_codmod
	and dsb_valor > 0;
	
	if v_dsb_feciniint is null then
		update pre_desemb
		set dsb_feciniint = f_pp_fec_sigper(dsb_codcred, dsb_codmod, dsb_coddsb, dsb_fecdsb, 2)
		where dsb_undsb > 0
		and dsb_feciniint = dsb_fecdsb;
	
		select min(dsb_fecdsb),min(dsb_fecini),min(dsb_feciniint) 
		into v_dsb_fecdsb,v_dsb_fecini,v_dsb_feciniint
		from pre_desemb
		where dsb_codcred = p_codcred
		and dsb_codmod = p_codmod
		and dsb_valor > 0;	
	end if
	
	let p_f_corterepro = nvl(p_f_corterepro, v_dsb_fecdsb);
	
	let v_app_t = f_init_app_t();
	let v_app_t.acu_interes = 0;
	let v_app_t.acu_cargos = 0;
    let v_app_t.acu_codmod = p_codmod;
    let v_app_t.acu_codcred = p_codcred;
    let v_app_t.acu_coddsb = null;
    let v_app_t.acu_capital = 0;
    let v_app_t.acu_valor = 0;
    let v_app_t.acu_valorpend = 0;
    let v_app_t.acu_trxstaau = 1;
    let v_app_t.acu_monpag = 1;
    let v_app_t.acu_auditusr = p_usuario;
    let v_app_t.acu_auditwst = p_estacion;
    let v_app_t.acu_auditfho = current;
    let v_app_t.acu_tabtipodsb = C_REPROTEMPO;		

	let p_nroamort_int = nvl(p_nroamort_int,v_pre_nroperiodos);
    if nvl(p_nroamort_int,v_pre_nroperiodos) <= 0 then
    	let p_nroamort_int = 1;
    end if
    
	let p_fecha_prim_amortint = nvl(p_fecha_prim_amortint,v_dsb_feciniint);
    if p_fecha_prim_amortint is null then
    	let p_fecha_prim_amortint = f_periodo_fechafin(v_dsb_fecdsb, 1, unidplaz, 0, 3);
    	--raise exception -746,0,"GENPP: Generacion de PP requiere fecha primera amortizacion de interes";
    end if
	
    if p_f_corterepro >= p_fecha_prim_amortint or p_f_corterepro > v_dsb_fecdsb then
    	let p_f_corterepro = v_dsb_fecdsb;
    end if
    
    let v_END_D_PERIOD = f_periodo_fechafin(p_f_corterepro, p_nroamort_int, unidplaz, 0, 3);
    
    if v_END_D_PERIOD > mdy(1,1,2135) then
    	raise exception -746,0,"GENPP: Periodo final excede el permitido " || v_END_D_PERIOD;
    end if
    
    if p_nroamort_int > 365 then
    	raise exception -746,0,"GENPP: Numero de Periodos interes excede el permitido " || p_nroamort_int;
    end if
    let v_fecha_prim_amort = nvl(p_fecha_prim_amort, p_fecha_prim_amortint);

	call f_dsb_getmethod_plz(p_codcred, p_codmod, null) returning v_pre_methodcapi, v_pre_unidplaz;    
    if nvl(unidplaz,0) = 0 then
    	let unidplaz = v_pre_unidplaz;
    end if    
	let v_fecha_ini = v_dsb_fecdsb;
	
	let v_intper_float = f_gettasavigenteprest(p_codcred, p_codmod, p_f_corterepro);	
	let v_app_t.acu_unidplaz = unidplaz;	
	let v_app_t.acu_tasa = v_intper_float;
	let v_app_t.acu_capital = 0;
	let v_app_t.acu_fecinicuo = v_dsb_fecini;
	let v_app_t.acu_fecfincuo = v_dsb_feciniint;


	let v_period_ctrl = 0;
	-- periodos tramo 1 
    foreach 
		select distinct cuo_fecvencuo
        into v_app_t.acu_fecvencuo
    	from pre_planpagos
    	where cuo_codcred = p_codcred
    	and cuo_codmod = p_codmod
    	and cuo_fecvencuo < p_f_corterepro
    	and cuo_tipocuo in (1,2,12,22)
    	and cuo_coddsb > 0
    	and cuo_valor > 0
    	order by cuo_fecvencuo

            let v_app_t.acu_fecvencuo = v_app_t.acu_fecvencuo;
        	let v_app_t.acu_tabtipodsb = C_REPROTEMPO;		
    		let v_app_t.acu_tipodsb = p_codcred;
            let v_app_t.acu_coddsb = null;
            let v_codacu = p_insauxplanpg(v_app_t);
            let v_period_ctrl = v_period_ctrl + 1;
    end foreach
    
    if v_period_ctrl = 0 then
    	let p_f_corterepro = v_dsb_fecdsb;
    end if
    
    let v_LAST_DATE = p_fecha_prim_amortint;
    
    let v_fecha_ini = null;
    
    if p_f_corterepro < p_fecha_prim_amortint then
    -- tramo p_f_corterepro -> p_fecha_prim_amortint    
	    foreach 
			select SEQ_PERIOD,ST_D_PERIOD, END_D_PERIOD
			into v_SEQ_PERIOD,v_ST_D_PERIOD, v_END_D_PERIOD
			from table(f_getperiodos(p_f_corterepro, p_fecha_prim_amortint,unidplaz, 3, 1, 0)) --fin no se modifica ini es fin de 1ervcto 
			t(SEQ_PERIOD,ST_D_PERIOD, END_D_PERIOD)
	    	order by END_D_PERIOD desc
	    	
			let v_period_ant = f_periodo_fechafin(v_LAST_DATE, -1, unidplaz, 0, 3);
			let v_app_t.acu_tabtipodsb = C_REPROTEMPO;		
	    	let v_app_t.acu_tipodsb = p_codcred;
			let v_app_t.acu_coddsb = null;
			
			if v_period_ant > p_f_corterepro then
	            let v_app_t.acu_fecvencuo = v_period_ant;
	          
	            let v_codacu = p_insauxplanpg(v_app_t);
			else
	            if p_f_corterepro > v_dsb_fecdsb then		
		            let v_app_t.acu_fecvencuo = p_f_corterepro;
		            let v_codacu = p_insauxplanpg(v_app_t);
		            let v_period_ant = p_f_corterepro;
	            else
	            	let v_period_ant = v_dsb_fecdsb;
		        end if
	            exit foreach;
			end if
			let v_LAST_DATE = v_period_ant;
	    end foreach
	end if
	
    let v_LAST_DATE = f_periodo_fechafin(p_fecha_prim_amortint, p_nroamort_int, unidplaz, 0, 3);
    
	select max(acu_fecvencuo)
	into v_fecha_ini
	from aux_planpagos
	where acu_codcred = p_codcred
	and acu_codmod = p_codmod
	and acu_tipodsb = p_codcred
	and acu_tabtipodsb = C_REPROTEMPO
	and acu_coddsb is null
	and acu_fecvencuo < p_fecha_prim_amortint;
    
    let v_fecha_ini = nvl(v_fecha_ini, v_dsb_fecdsb);
    
    let v_nropers = 0;
    -- tramo p_fecha_prim_amortint -> ult venc 
    foreach 
		select SEQ_PERIOD,ST_D_PERIOD, END_D_PERIOD
		into v_SEQ_PERIOD,v_ST_D_PERIOD, v_END_D_PERIOD
		from table(f_getperiodos(p_fecha_prim_amortint,v_LAST_DATE,unidplaz, 3, 0, 0)) --fin se modifica ini es fin de 1ervcto 
			t(SEQ_PERIOD,ST_D_PERIOD, END_D_PERIOD)
		
    	let v_nropers = v_nropers + 1;
    	
		let v_period_ant = f_periodo_fechafin(v_LAST_DATE, -1, unidplaz, 0, 3);
		
        let v_app_t.acu_fecvencuo = v_END_D_PERIOD;
        let v_app_t.acu_tabtipodsb = C_REPROTEMPO;		
    	let v_app_t.acu_tipodsb = p_codcred;
		let v_app_t.acu_coddsb = null;
        let v_codacu = p_insauxplanpg(v_app_t);
        
        if v_nropers >= p_nroamort_int then
        	exit foreach;
        end if
    end foreach    
    
    if p_tipotrx = C_TIPORPRO_CALENDAR then
    	return;
    end if
    ------------ FILL CALENDAR -----------------
    delete from pre_reprograma
    where rds_codcred = p_codcred
    and rds_codmod = p_codmod
    and rds_tiporepro = C_TIPOREPRO_REPRO
    and rds_auditusr = p_usuario
    and rds_trxstaau = 1;
    
	let v_codrepro = f_rpro_crear_reprograma(p_codcred, p_codmod, C_TIPOREPRO_REPRO, p_codrepro, p_usuario, p_estacion);
    
    delete from aux_planpagos
    where acu_codcred = p_codcred
    and acu_codmod = p_codmod
	and acu_tabtipodsb = C_TIPOREPRO_REPRO;

	--tramo desemb p_f_corterepro
	call p_cpy_planpagos_auxpp(p_codcred, p_codmod, C_TIPOREPRO_REPRO, v_codrepro, p_usuario, p_estacion);

    delete from aux_planpagos
    where acu_fecvencuo >= p_f_corterepro
    and acu_codcred = p_codcred
    and acu_codmod = p_codmod
    and acu_tipodsb = v_codrepro
    and acu_tabtipodsb = C_TIPOREPRO_REPRO;
	
    -- verificamos que p_fecha_prim_amortint este en el plan
    select count(1)
    into v_contar 
    from aux_planpagos
	where acu_codcred = p_codcred
	and acu_codmod = p_codmod
	and acu_tipodsb = p_codcred
	and acu_tabtipodsb = C_REPROTEMPO
	and acu_coddsb is null
	and acu_fecvencuo = p_fecha_prim_amortint;
	
	if v_contar = 0 then
		raise exception -746,0,"Error en elab plan pagos fecha fecha_prim_amortint " || p_fecha_prim_amortint || " no se encuentra en periodos";
	end if
    
	if v_fecha_prim_amort < p_fecha_prim_amortint then
		let v_fecha_prim_amort = p_fecha_prim_amortint;
	end if
	
    select count(1)
    into v_contar 
    from aux_planpagos
	where acu_codcred = p_codcred
	and acu_codmod = p_codmod
	and acu_tipodsb = p_codcred
	and acu_tabtipodsb = C_REPROTEMPO
	and acu_coddsb is null
	and acu_fecvencuo = v_fecha_prim_amort;
	
	if v_contar = 0 then
		-- ajuste 
		select max(acu_fecvencuo)
		into v_fecha_prim_amort
		from aux_planpagos
		where acu_codcred = p_codcred
		and acu_codmod = p_codmod
		and acu_tipodsb = p_codcred
		and acu_tabtipodsb = C_REPROTEMPO
		and acu_coddsb is null
		and acu_fecvencuo < v_fecha_prim_amort;

		--raise exception -746,0,"Error en elab plan pagos fecha fecha_prim_amort " || p_fecha_prim_amort || " no se encuentra en periodos";
	end if	
	
    let v_appaux_t = f_init_app_t();
    
    --------------- POPULATE DATA ---------------------------------
    
	select max(acu_fecvencuo)
    into v_fechalimit_prg
	from aux_planpagos
	where acu_codcred = p_codcred
	and acu_codmod = p_codmod
	and acu_tipodsb = p_codcred
	and acu_tabtipodsb = C_REPROTEMPO
	and acu_coddsb is null
	and acu_fecvencuo >= p_f_corterepro;

    call f_GET_TRA_INT_YR_MTH_BASE(p_codmod , p_codcred ) returning P_TRAINTYDAYS, P_TRAINTMDAYS;
    
    foreach
    	select dsb_coddsb, dsb_fecdsb,dsb_valor 
    	into v_dsb_coddsb, v_dsb_fecdsb,v_dsb_valor
    	from pre_desemb
    	where dsb_codcred = p_codcred
    	and dsb_codmod = p_codmod
    	and dsb_valor > 0
		order by dsb_fecdsb, dsb_coddsb

			let v_sum_ctrl = 0;
		    let v_ultvcto_t1 = null;
    		let v_int_acum = 0;
			select MIN(acu_fecvencuo)
		    into v_fecha_prim_amortint
			from aux_planpagos
			where acu_codcred = p_codcred
			and acu_codmod = p_codmod
			and acu_tipodsb = p_codcred
			and acu_tabtipodsb = C_REPROTEMPO
			and acu_coddsb is null
			and acu_fecvencuo > v_dsb_fecdsb
			and acu_fecvencuo > p_f_corterepro;
			
			let v_fecha_prim_amortint = nvl(v_fecha_prim_amortint, p_fecha_prim_amortint);
			if v_fecha_prim_amortint < p_fecha_prim_amortint then
				let v_fecha_prim_amortint = p_fecha_prim_amortint;  
			end if

			select max(acu_fecvencuo)
		    into v_f_corterepro
			from aux_planpagos
			where acu_codcred = p_codcred
			and acu_codmod = p_codmod
			and acu_tipodsb = p_codcred
			and acu_tabtipodsb = C_REPROTEMPO
			and acu_coddsb is null
			and acu_fecvencuo < v_fecha_prim_amortint
			and acu_fecvencuo >= v_dsb_fecdsb;

			let v_f_corterepro = nvl(v_f_corterepro,p_f_corterepro);
			
			if v_f_corterepro < v_dsb_fecdsb then
				let v_f_corterepro = v_dsb_fecdsb;
			end if
			
			update aux_planpagos
			set acu_tasa = f_gettasavigenteprest(p_codcred, p_codmod, acu_fecvencuo - 1)
		    where acu_fecvencuo < v_f_corterepro
		    and acu_codcred = p_codcred
		    and acu_codmod = p_codmod
		    and acu_tipodsb = v_codrepro
		    and acu_coddsb = v_dsb_coddsb
		    and acu_tabtipodsb = C_TIPOREPRO_REPRO;
		
			select max(acu_fecvencuo)
		    into v_ultvcto_t1
			from aux_planpagos
			where acu_codcred = p_codcred
			and acu_codmod = p_codmod
			and acu_tipodsb = v_codrepro
			and acu_tabtipodsb = C_TIPOREPRO_REPRO
			and acu_coddsb = v_dsb_coddsb
			and acu_fecvencuo < v_f_corterepro
			and acu_tipocuo in (2,22);
			
			let v_ultvcto_t1 = nvl(v_ultvcto_t1, v_dsb_fecdsb);
			
			select min(acu_fecvencuo)
		    into v_fecha_prim_amort
			from aux_planpagos
			where acu_codcred = p_codcred
			and acu_codmod = p_codmod
			and acu_tipodsb = p_codcred
			and acu_tabtipodsb = C_REPROTEMPO
			and acu_coddsb is null
			and acu_fecvencuo >= p_fecha_prim_amort
			and acu_fecvencuo >= v_fecha_prim_amortint
			and acu_fecvencuo > v_dsb_fecdsb;
			
			if p_fecha_prim_amort <= v_dsb_fecdsb then
				let v_fecha_prim_amort = v_fecha_prim_amortint;
			else
				let v_fecha_prim_amort = nvl(v_fecha_prim_amort, v_fecha_prim_amortint);
			end if
			
			call f_periodos_fechas(v_fecha_prim_amortint, v_fechalimit_prg, unidplaz, NRODIASPERIODO, C_INPUT_PERIOD_EXACT,1, 0) -- no modif fefin y v_fecha_prim_amort es fin 1er per  
    			returning v_nroamort_int, v_nroper_calendar, v_fecmax_cap;
			
			if v_nroamort_int < p_nroamort_int then
				let v_nroamort_int = p_nroamort_int;
			end if
			
			call f_periodos_fechas(v_fecha_prim_amort, v_fechalimit_prg, unidplaz, NRODIASPERIODO, C_INPUT_PERIOD_EXACT,1, 0) -- no modif fefin y fechaini es fin 1er per  
    			returning v_nroamort_cap, v_nroper_calendar, v_fecmax_cap;

            let v_app_t = f_init_app_t();
            let v_app_t.acu_codmod = p_codmod;
            let v_app_t.acu_codcred = p_codcred;
			let v_app_t.acu_interes = 0;
			let v_app_t.acu_cargos = 0;
            let v_app_t.acu_tipotrx = C_TIPOTRX_COB;
            let v_app_t.acu_coddsb = v_dsb_coddsb;
            let v_app_t.acu_tasa = 0;
            let v_app_t.acu_trxstaau = 1;
            let v_app_t.acu_monpag = 1;
            let v_app_t.acu_auditusr = p_usuario;
            let v_app_t.acu_auditwst = p_estacion;
            let v_app_t.acu_auditfho = current;
            let v_app_t.acu_tabtipodsb = C_TIPOREPRO_REPRO;
            let v_app_t.acu_tipodsb = v_codrepro;
            
			let v_feculttrx = f_acr_ult_fec_acr(p_codcred, p_codmod, v_dsb_coddsb, v_f_corterepro-1, 2);
            let v_feculttrx = nvl(v_feculttrx, v_dsb_fecdsb);

            let v_fechaini = v_ultvcto_t1;
			let v_siap = f_acr_saldo_fecha(p_codcred, p_codmod, v_dsb_coddsb, v_fecha_prim_amortint, 1);
            
			let v_cap_amort_per = v_siap;			
		    IF v_nroamort_cap > 0 then
		        let v_cap_amort_per = v_siap / v_nroamort_cap;
		    end if
			 
			if nvl(rate,0) <= 0 then 
				let rate = f_gettasavigenterepro(p_codcred, p_codmod,v_f_corterepro, 3);
			end if
            
		    foreach 
				select acu_fecvencuo
		        into v_appaux_t.acu_fecvencuo
		    	from aux_planpagos
		    	where acu_codcred = p_codcred
		    	and acu_codmod = p_codmod
				and acu_tipodsb = p_codcred
				and acu_tabtipodsb = C_REPROTEMPO
				and acu_coddsb is null
		    	and acu_fecvencuo > v_dsb_fecdsb
		    	and acu_fecvencuo > v_ultvcto_t1
		    	order by acu_fecvencuo
		    	
					if v_appaux_t.acu_fecvencuo <= v_f_corterepro then
						let v_intper_float = f_gettasavigenteprest(p_codcred, p_codmod, v_appaux_t.acu_fecvencuo-1);
					else
						let v_intper_float = rate;
					end if
	    			let v_app_t.acu_tasa = v_intper_float;
		            let v_app_t.acu_fecinicuo = v_fechaini;
		            let v_app_t.acu_fecvencuo = v_appaux_t.acu_fecvencuo;
		            
        			call f_DAYS_BETWEEN_2_DATES(v_fechaini, v_app_t.acu_fecvencuo, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, v_TRAINTYDAYS;		            
		            ------ iiiiiiiiiiiiiiiii ------
	    			let v_app_t.acu_cargos = round(v_siap * D_DIFFERENCE_IN_DAYS * f_tasaindiceperiodo(unidplaz, v_intper_float, C_TASAPERIODO, v_TRAINTYDAYS, 1), 2);
        			let v_app_t.acu_valor = 0;
        			let v_app_t.acu_valorpend = 0;
			        if v_appaux_t.acu_fecvencuo >= v_fecha_prim_amortint then
			        -- fecha de proceso de interes
			    		let v_app_t.acu_fecfincuo = v_appaux_t.acu_fecvencuo;
			        	--let v_app_t.acu_cargos = v_int_acum + v_app_t.acu_valor;
        				let v_app_t.acu_valor = v_int_acum + v_app_t.acu_cargos;
        				let v_app_t.acu_valorpend = v_app_t.acu_valor;
			        	let v_int_acum = 0;
				    else        
				        let v_app_t.acu_fecfincuo = v_fecha_prim_amortint;
			        	let v_int_acum = v_int_acum + v_app_t.acu_cargos;
				    end if		
				    let v_app_t.acu_tipocuo = C_TIPOCUO_INT;
				    let v_app_t.acu_tipotrx = C_TIPOTRX_COB;
        			let v_app_t.acu_tipoacu = C_TIPOCUO_INT;
			        let v_app_t.acu_capital = v_siap;
			        
				    let v_codacu = p_insauxplanpg(v_app_t);
			        
				    ------- kkkkkkkkkkkk -----------------
				 	let v_app_t.acu_valor = 0;
				    let v_app_t.acu_cargos = 0;
				    if v_app_t.acu_fecvencuo >= v_fecha_prim_amort then
				    	let v_app_t.acu_valor = v_cap_amort_per;
				    end if
				    
				    if v_app_t.acu_fecvencuo >= v_fechalimit_prg then
				    	let v_app_t.acu_valor = v_siap; 
				    end if				    
					
		            let v_app_t.acu_tipocuo = C_TIPOCUO_CAP;
		            let v_app_t.acu_tipoacu = C_TIPOCUO_CAP;
		            let v_app_t.acu_capital = 0;
		            let v_app_t.acu_valorpend = v_app_t.acu_valor;
		            
	            	let v_codacu = p_insauxplanpg(v_app_t);
	            	let v_fechaini = v_app_t.acu_fecvencuo;
	            	let v_siap = v_siap - v_app_t.acu_valor; 
			end foreach -- f repro -> ult vcto
			
			select sum(acu_valor)
			into v_sumper
			from aux_planpagos
			where acu_codcred = p_codcred
			and acu_codmod = p_codmod
			and acu_tipodsb = v_codrepro
			and acu_tabtipodsb = C_TIPOREPRO_REPRO
			and acu_tipocuo = C_TIPOCUO_CAP
			and acu_coddsb = v_dsb_coddsb;	

			if nvl(v_sumper,0) != v_dsb_valor then
				raise exception -746,0,"GenPP: Suma de capital " || v_sumper || " difiere del monto desembolsado " || v_dsb_valor || " dsb: " || v_dsb_coddsb;
			end if
			
	end foreach -- dsb
	-- ctrlses
{
    delete from aux_planpagos
	where acu_codcred = p_codcred
	and acu_codmod = p_codmod
	and acu_tipodsb = p_codcred
	and acu_tabtipodsb = C_REPROTEMPO;
}	
end procedure;



