

DROP procedure IF EXISTS d_creditos.p_pp_control_dif_dsb;
create procedure d_creditos.p_pp_control_dif_dsb(p_codcred integer, p_codmod integer, p_coddsb integer)
define v_dsb_coddsb integer;
define v_panti_cap, V_MNT_PRG_FECHA, V_MNT_PRGPEND_FECHA, v_dsb_valor like pre_planpagos.cuo_valor;
{
wherrera 20260405 funcion que controla el monto desembolsado con el plan de pagos, se ajusta la diferencia a un margen de un bs
}

    foreach
        select dsb_coddsb, dsb_valor
        into v_dsb_coddsb, v_dsb_valor
        from pre_desemb
        where dsb_codmod = p_codmod
        and dsb_codcred = p_codcred
        AND dsb_undsb > 0
        and dsb_coddsb = nvl(p_coddsb, dsb_coddsb)
        
        let V_MNT_PRG_FECHA = f_pp_sum_portipo_valor(p_codcred, p_codmod, v_dsb_coddsb, null, null, 1);

        if v_dsb_valor > 0 and V_MNT_PRG_FECHA > 0 and abs(v_dsb_valor - V_MNT_PRG_FECHA) > 2 then
            raise exception -746,0,"Suma plan de pagos(" || V_MNT_PRG_FECHA || ") para DSB : " || v_dsb_coddsb || " mayor al desembolsado(" || v_dsb_valor || ") revise los datos." ;
        end if
    end foreach;

end procedure;


