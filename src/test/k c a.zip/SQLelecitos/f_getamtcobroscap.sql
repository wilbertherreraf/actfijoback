

DROP function if exists d_creditos.f_getamtcobroscap;
create function d_creditos.f_getamtcobroscap(p_codcred integer, p_codmod integer, p_coddsb integer, p_fechaini date,p_fechafin date, p_tipocuo integer) returning DECIMAL(20,2)
/*
wherrea 2021.11.03 Objetivo: calcula el monto cobrado o pagado
*/
    DEFINE v_amtdsb, v_sum_cobro, v_cob_valor like pre_cobros.cob_valor;
    define v_cuo_codcuo like pre_planpagos.cuo_codcuo;
    define v_cuo_coddsb  like pre_planpagos.cuo_coddsb;
	define C_TIPOCUO_INT,C_TIPOCUO_PANTI_INT,C_TIPOCUO_PANTI_CAP, C_TIPOCUO_CAP integer;
    define v_cuo_fecvencuo date;

	let C_TIPOCUO_CAP = 1;
	let C_TIPOCUO_INT = 2;	
	let C_TIPOCUO_PANTI_CAP = 12;
	let C_TIPOCUO_PANTI_INT = 22;	
    let p_fechaini = nvl(p_fechaini, mdy(1,1,1980));
    let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));
    
    let v_sum_cobro = 0;
  	let p_tipocuo = nvl(p_tipocuo, 1);
    
    if p_tipocuo = 2 then
	    if p_coddsb is not null then
	        SELECT nvl(sum(cob_valor), 0)
	        into v_sum_cobro
	        FROM pre_tramon, pre_cobros
	        WHERE tmo_codcred = cob_codcred
	        AND tmo_codmod = cob_codmod 
	        AND tmo_numtrx = cob_numtrx
	        AND tmo_codcred = p_codcred
	        and tmo_codmod = p_codmod
	        AND tmo_coddsb = p_coddsb
	        AND cob_codigo IN (C_TIPOCUO_PANTI_INT, C_TIPOCUO_INT)
	        and tmo_fecvencuo between p_fechaini and p_fechafin
	        AND cob_statreg = 0
	        and exists (
	            select 1
	            from pre_planpagos
	            where cuo_codmod = p_codmod
	            and cuo_codcred = p_codcred
	            and cuo_coddsb = tmo_coddsb
	            and cuo_codcuo = cob_numcuo
	            and cuo_coddsb > 0                
	        );
	    
	    else
	        SELECT nvl(sum(cob_valor), 0)
	        into v_sum_cobro
	        FROM pre_tramon, pre_cobros
	        WHERE tmo_codcred = cob_codcred
	        AND tmo_codmod = cob_codmod 
	        AND tmo_numtrx = cob_numtrx
	        AND tmo_codcred = p_codcred
	        and tmo_codmod = p_codmod
	        AND cob_codigo IN (C_TIPOCUO_PANTI_INT, C_TIPOCUO_INT)
	        and tmo_fecvencuo between p_fechaini and p_fechafin
	        AND cob_statreg = 0
	        and exists (
	            select 1
	            from pre_planpagos
	            where cuo_codmod = p_codmod
	            and cuo_codcred = p_codcred
	            and cuo_coddsb = tmo_coddsb
	            and cuo_codcuo = cob_numcuo
	            and cuo_coddsb > 0                
	        );
		end if    
    else
	    if p_coddsb is not null then
	        SELECT nvl(sum(cob_valor), 0)
	        into v_sum_cobro
	        FROM pre_tramon, pre_cobros
	        WHERE tmo_codcred = cob_codcred
	        AND tmo_codmod = cob_codmod 
	        AND tmo_numtrx = cob_numtrx
	        AND tmo_codcred = p_codcred
	        and tmo_codmod = p_codmod
	        AND tmo_coddsb = p_coddsb
	        AND cob_codigo IN (C_TIPOCUO_PANTI_CAP, C_TIPOCUO_CAP)
	        and tmo_fecvencuo between p_fechaini and p_fechafin
	        AND cob_statreg = 0
	        and exists (
	            select 1
	            from pre_planpagos
	            where cuo_codmod = p_codmod
	            and cuo_codcred = p_codcred
	            and cuo_coddsb = tmo_coddsb
	            and cuo_codcuo = cob_numcuo
	            and cuo_coddsb > 0                
	        );
	    
	    else
	        SELECT nvl(sum(cob_valor), 0)
	        into v_sum_cobro
	        FROM pre_tramon, pre_cobros
	        WHERE tmo_codcred = cob_codcred
	        AND tmo_codmod = cob_codmod 
	        AND tmo_numtrx = cob_numtrx
	        AND tmo_codcred = p_codcred
	        and tmo_codmod = p_codmod
	        AND cob_codigo IN (C_TIPOCUO_PANTI_CAP, C_TIPOCUO_CAP)
	        and tmo_fecvencuo between p_fechaini and p_fechafin
	        AND cob_statreg = 0
	        and exists (
	            select 1
	            from pre_planpagos
	            where cuo_codmod = p_codmod
	            and cuo_codcred = p_codcred
	            and cuo_coddsb = tmo_coddsb
	            and cuo_codcuo = cob_numcuo
	            and cuo_coddsb > 0                
	        );
		end if
    end if    
    return nvl(v_sum_cobro, 0);
end function;
