

DROP function IF EXISTS d_creditos.f_gettasavigenteprest;
create function d_creditos.f_gettasavigenteprest(p_codcred integer, p_codmod integer,p_fecha date) returning float
{
determina la tasa vigente de un prestamo
wherrera 2026-05-05 se ellimina la tasa spread ya que no hay tasas penales
}
     define v_mtp_fechavig date;
     define v_mtp_tbase like pre_tasaspre.mtp_tbase;
     define v_mtp_tspread like pre_tasaspre.mtp_tspread;
    define v_cont integer;
    
        SELECT  mtp_tbase,mtp_tspread,mtp_fechavig
        INTO  v_mtp_tbase, v_mtp_tspread,v_mtp_fechavig
       FROM  pre_tasaspre
       WHERE mtp_codcred = p_codcred
       and mtp_codmod = p_codmod
       and mtp_tbase > 0 
       AND   mtp_fechavig = (
            SELECT MAX(x.mtp_fechavig) 
            FROM  pre_tasaspre x
            WHERE x.mtp_codcred = p_codcred
            and x.mtp_codmod = p_codmod
            AND   x.mtp_fechavig <= p_fecha
            );
               
    let v_mtp_tbase = nvl(v_mtp_tbase,0);
   
    RETURN v_mtp_tbase;
END FUNCTION;


