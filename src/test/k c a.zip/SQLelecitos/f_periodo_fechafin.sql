


DROP function IF EXISTS d_creditos.f_periodo_fechafin;
create function d_creditos.f_periodo_fechafin(p_fechaini date , p_nroperiodos integer, p_unidplaz integer, INIT_FECHAINI integer, INPUT_PERIOD_BASE integer)
    returning date
{
-- calcula la ultima fecha segun el nr de periodos
wherrera 20260505 se ajusta para periodos positivos 
}
    
    define V_YY_OUT, V_MM_OUT, V_DD_OUT integer;
    define fecha_ini, fecha_fin, ST_D_PERIODHABIL, END_D_PERIODHABIL date;
    define C_INPUT_PERIOD_EXACT, MONTHSPERPERIOD,v_numpers_periods integer;
    define v_step, v_iniper, v_finper, i, v_numpers, DR_REPMTS_PER_YEAR_OUT,INIT_FECHAINI,INPUT_LASTDATE_EXACT integer;
    define ST_D_PERIOD, END_D_PERIOD date;
    
    let C_INPUT_PERIOD_EXACT = 3;
    let v_numpers = 0;
    let fecha_fin = p_fechaini;
    let fecha_ini = null;
    let INPUT_PERIOD_BASE = nvl(INPUT_PERIOD_BASE, C_INPUT_PERIOD_EXACT);
    let v_iniper = 1;
    let v_step = 1;
    let v_finper = p_nroperiodos;
    let INIT_FECHAINI = 0; -- 0: p_fechaini es el pri venc
    let INPUT_LASTDATE_EXACT = 0; -- se mod ult fecha 
    if nvl(p_nroperiodos, 0) = 0 then
        return p_fechaini;
    end if
    
    if nvl(p_nroperiodos, 0) < 0 then
        let v_iniper = abs(p_nroperiodos);
        let v_finper = 1;
        let v_step = -1;
    else 
    	let fecha_ini = p_fechaini;
    end if
    
		call f_infoperiodo(p_fechaini, p_fechaini, p_unidplaz, INPUT_PERIOD_BASE) returning MONTHSPERPERIOD, ST_D_PERIOD, END_D_PERIOD;
   
		if INPUT_PERIOD_BASE = 3 then
	    	if nvl(p_nroperiodos, 0) < 0 then
	    		let V_MM_OUT = MONTHSPERPERIOD * p_nroperiodos;
	    		let END_D_PERIOD = ADD_MONTHS(p_fechaini,V_MM_OUT);
				let fecha_ini = END_D_PERIOD;
	    		return fecha_ini;
	    	else
		    	let V_MM_OUT = MONTHSPERPERIOD * p_nroperiodos;
		    	let END_D_PERIOD = ADD_MONTHS(p_fechaini,V_MM_OUT);
	    		return END_D_PERIOD;
	    	end if
	    else
			let V_MM_OUT = MONTHSPERPERIOD * p_nroperiodos;
			let END_D_PERIOD = ADD_MONTHS(p_fechaini,V_MM_OUT);
		
	        foreach 
	            execute procedure f_getperiodos(p_fechaini, END_D_PERIOD, p_unidplaz, INPUT_PERIOD_BASE, INPUT_LASTDATE_EXACT, INIT_FECHAINI)
	                into v_numpers_periods,fecha_ini, fecha_fin
	                let v_numpers = v_numpers + 1;
	    
					if v_numpers_periods < p_nroperiodos then
					else
						exit foreach;
					end if
	        end foreach
	   	end if
    return fecha_fin;
end function;


