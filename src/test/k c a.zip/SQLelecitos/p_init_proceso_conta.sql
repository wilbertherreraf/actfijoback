


DROP procedure IF EXISTS d_creditos.p_init_proceso_conta;
create procedure d_creditos.p_init_proceso_conta(p_tipocmp integer, p_idtabla integer, p_tipotrx integer, p_codcred integer, p_codmod integer, p_coddsb integer, 
	p_usuario varchar(15), p_estacion varchar(50))
{
          DESCRIPCI: realiza procesos contra coin
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
          HISTORIAL DE CAMBIOS
         
         wherrera 20260519 centraliza las operaciones de los registros contables contra coin 
}

  define v_tipoproc,v_nro_comprob,v_nro_comprob_coin,v_cve_tipo_comprob,v_cve_tipo_comprob_coin,v_nro_afectablecoind,v_cta_mov,v_cve_debe_haber varchar(30);
  define v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_estado,v_nroregs integer;
  define C_TIPOTRXCOIN_ACT,C_TIPOTRXCOIN_REG,C_TIPOTRXCOIN_RECHAZAR,v_contar,v_max_codtpr,v_nro_reng integer;
  define v_fechacont, v_fecha_cont,v_fecha_cont_coin,v_fec_vcto date;
  define v_mnt_dev,v_monto_mo, v_monto_mn decimal(20,2);
  define v_glosa,v_glosa_reng lvarchar(500);
  define v_nom_movimiento varchar(200);
  define v_nro_mayor, v_nro_afectable varchar(30);

  let C_TIPOTRXCOIN_REG = 2;
  let C_TIPOTRXCOIN_RECHAZAR = 9; 
  let C_TIPOTRXCOIN_ACT = 3;
  
	select tipoproc,idtabla,codcred, codmod, coddsb, tipocmp,estado,
	nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto,monto_mn, glosa
	into v_tipoproc,v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_estado,
	v_nro_comprob,v_cve_tipo_comprob, v_fecha_cont,v_fec_vcto, v_monto_mn, v_glosa
	from table(p_get_estado_proceso_conta(nvl(p_tipocmp,0), nvl(p_idtabla,0), p_codcred,p_codmod, null,null, null, null)) 
		t(tipoproc,idtabla,codcred, codmod, coddsb,tipocmp,estado,
			nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto, monto_mn, glosa)
	where nro_comprob is not null
	and fecha_cont is not null
	and estado in (3,8);
	
	if v_idtabla is null then
		raise exception -746,0,"PROCCONT: Operacion inexistente " || p_idtabla || " tipooper: " || p_tipocmp || " cred " || p_codcred;  
	end if
	let v_contar = 0;
	if p_tipotrx = C_TIPOTRXCOIN_REG then	
		-- verificamos si el comprobante no fue registrado
		if length(trim(nvl(v_nro_comprob,""))) > 0 then 
			select count(1)
			into v_contar
			from table(p_get_estado_proceso_conta(null, null, null,null, null,v_nro_comprob, null, null)) 
				t(tipoproc,idtabla,codcred, codmod, coddsb,tipocmpoper,estado,
					nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto, monto_mn, glosa)
			where idtabla != v_idtabla
			and estado in (1,2,3);
		else
			raise exception -746,0,"PROCCONT: Operacion id: " || v_idtabla || " tipooper: " || v_tipocmp || " cred " || v_codcred || ", requiere comprobante";		
		end if
		
		if v_contar > 0 then
			raise exception -746,0,"PROCCONT: Operacion id: " || v_idtabla || " tipooper: " || v_tipocmp || " cred " || v_codcred || ", el comprobante ya fue registrado, cmpb: " || v_nro_comprob;		
		end if			
	end if
	
	select count(1)
	into v_contar
	from gen_prcparams
	where prp_codprc = v_idtabla
	and prp_tipoproc = v_tipocmp
	and prp_montomn > 0
	and prp_ctamov is not null
	and prp_nroreng > 0
	and prp_estado = 3;

	if v_contar = 0 then
		delete from gen_prcparams
		where prp_codprc = v_idtabla
		and prp_tipoproc = v_tipocmp;
		let v_nroregs = 0;
    	foreach
	    	execute procedure obtiene_interes_devengado(v_tipocmp,v_codcred, p_codmod, v_fecha_cont, null, v_nro_comprob) 
	            		into v_fecha_cont_coin,v_nro_comprob_coin,v_mnt_dev, v_cve_tipo_comprob_coin,v_nro_afectablecoind,v_glosa
	            		
        	let v_nroregs = v_nroregs + 1;
        	if v_tipocmp = 3 then
	    		update pre_prcconta
	    		set	prc_fecha = v_fecha_cont_coin,
	    		prc_nro_centro = 1,
	    		prc_estado = 3,
	    		prc_glosa = v_glosa,
	    		prc_cve_tipo_comprob = v_cve_tipo_comprob_coin,
	    		prc_montodeven = v_mnt_dev,
	    		prc_hora = current,
	             prc_auditusrgen = p_usuario,
	             prc_auditfhogen = current,
	             prc_auditwstgen = p_estacion	    		
			   	where prc_codprc = v_idtabla
			  	and prc_codcred = v_codcred
			  	and prc_codmod = v_codmod
			  	and prc_codcmp = v_tipocmp
			  	and prc_nro_comprob = v_nro_comprob_coin
        		and prc_estado in (3,8);
    		elif v_tipocmp = 8 then
		    	update pre_registrogarantias
		    	set valor_total_garantia = v_mnt_dev,
		    	glosa_coin = v_glosa,
		    	cve_tipo_comprob = v_cve_tipo_comprob_coin,
		    	estado = 3,
		    	fecha = v_fecha_cont_coin,
		    	audit_usuario = p_usuario,
		    	audit_fechahora = current,
		    	audit_host = p_estacion
		    	where id = v_idtabla
		    	and codcred = v_codcred
		    	and codmod = v_codmod
		    	and rgg_codcmp = v_tipocmp 
		    	and nro_comprobante_coin = v_nro_comprob_coin
    			and estado in (3,8);		        
    		elif v_tipocmp in (1,2) then
		    	update pre_desembolso_detalle
		    	set monto_desembolsar = v_mnt_dev,
		    	glosa_coin = v_glosa,
		    	cve_tipo_comprob = v_cve_tipo_comprob_coin,
		    	estado = 3,
		    	fecha = v_fecha_cont_coin,
		    	audit_usuario = p_usuario,
		    	audit_fechahora = current,
		    	audit_host = p_estacion
		    	where id = v_idtabla
		    	and codcred = v_codcred
		    	and codmod = v_codmod
		    	and pds_codcmp = v_tipocmp 
		    	and nro_comprobante_coin = v_nro_comprob_coin
    			and estado in (3,8);		        	
    		elif v_tipocmp = 9 then
		    	update pre_custodia_garantia
		    	set valor_total_garantia = v_mnt_dev,
		    	glosa_coin = v_glosa,
		    	cve_tipo_comprob = v_cve_tipo_comprob_coin,
		    	estado = 3,
		    	fecha = v_fecha_cont_coin,
		    	audit_usuario = p_usuario,
		    	audit_fechahora = current,
		    	audit_host = p_estacion
		    	where id = v_idtabla
		    	and codcred = v_codcred
		    	and codmod = v_codmod
		    	and cug_codcmp = v_tipocmp 
		    	and nro_comprobante_coin = v_nro_comprob_coin
    			and estado in (3,8);		        	
    		elif v_tipocmp = 9 then
		    	update pre_retiro_garantia
		    	set valor_cuota = v_mnt_dev,
		    	glosa_coin = v_glosa,
		    	cve_tipo_comprob = v_cve_tipo_comprob_coin,
		    	estado = 3,
		    	fecha = v_fecha_cont_coin,
		    	audit_usuario = p_usuario,
		    	audit_fechahora = current,
		    	audit_host = p_estacion
		    	where id = v_idtabla
		    	and codcred = v_codcred
		    	and codmod = v_codmod
		    	and rtg_codcmp = v_tipocmp 
		    	and nro_comprobante_coin = v_nro_comprob_coin
    			and estado in (3,8);		        	
    		elif v_tipocmp in (4,5,6,7) then
		    	update pre_pagocuota
		    	set total_cuota_vencimiento = v_mnt_dev,
		    	glosa_coin = v_glosa,
		    	cve_tipo_comprob = v_cve_tipo_comprob_coin,
		    	estado = 3,
		    	fecha = v_fecha_cont_coin,
		    	audit_usuario = p_usuario,
		    	audit_fechahora = current,
		    	audit_host = p_estacion
		    	where id = v_idtabla
		    	and codcred = v_codcred
		    	and codmod = v_codmod
		    	and pcu_tipocmp = v_tipocmp 
		    	and nro_comprobante_coin = v_nro_comprob_coin
    			and estado in (3,8);			    		
    		end if
    		
    		foreach
    			select nro_reng, cve_debe_haber, monto_mo, glosa_reng, nro_mayor, nro_afectable, monto_mn
    			into v_nro_reng, v_cve_debe_haber, v_monto_mo, v_glosa_reng, v_nro_mayor, v_nro_afectable, v_monto_mn
    			from contbcb@bcbux02:reng_comprob r
    			where r.nro_comprob = v_nro_comprob_coin
				and r.cve_tipo_comprob = v_cve_tipo_comprob_coin
				and r.nro_centro = 1
    			order by nro_reng
    			
					select max(cm.nom_movimiento),max(ca.cod_movimiento)
					into v_nom_movimiento, v_cta_mov
					from contbcb@bcbux02:cuenta_movimiento cm,contbcb@bcbux02:cuenta_afectable ca 
					where cm.cod_Movimiento = ca.cod_Movimiento
					and cm.cve_Estado_Cuenta = 'V' 
					and ca.cve_Estado_Cuenta = 'V' 
					and ca.nro_Centro = 1 
					and ca.nro_afectable = v_nro_afectable
					and ca.cod_Moneda = "69";		
 
							let v_max_codtpr = nvl((select (max (prp_codtpr)) from gen_prcparams where prp_codprc = v_idtabla and prp_tipoproc = v_tipocmp), 0) + 1;
							
				    		insert into gen_prcparams(prp_codprc, prp_tipoproc,prp_codtpr,prp_nroreng,prp_codlit, prp_glosa, prp_montomo,prp_montomn,
				    			prp_ctamov,prp_dh,prp_mayor,prp_nroafectable,prp_value,prp_estado,prp_auditusr,prp_auditfho,prp_auditwst)
				    		values (v_idtabla, v_tipocmp,v_max_codtpr,v_nro_reng, null, v_glosa_reng, v_monto_mo, v_monto_mn, 
			    				v_cta_mov,v_cve_debe_haber,v_nro_mayor,v_nro_afectable, v_nom_movimiento,3,p_usuario,current,p_estacion);			    			
    		end foreach
	  	end foreach
	end if
	
END PROCEDURE;


