


DROP procedure IF EXISTS d_creditos.p_genera_pp_capitales;
create procedure d_creditos.p_genera_pp_capitales(p_codcred integer, p_codmod integer, p_coddsb integer, p_codmodtmp integer, p_coduser varchar(100), p_estacion varchar(100))

{
   wherrera    2021-10-06  barre la tabla desembolsos y llama al proc que crea los plazos en el plan de pagos 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| wherrera |  3-04-2026   | 1763004  | se elimina la actualizacion de pre_desemb si y solo si no tiene transacciones
----------------------------------------------------------------------------
   call p_genera_pp_capitales(84, 19, p_coddsb, p_coddsb, p_coduser, p_estacion);
}
    define v_dsb_coddsb			like pre_desemb.dsb_coddsb			;
    define v_dsb_fecdsb         like pre_desemb.dsb_fecdsb          ;
    define v_dsb_fecini         like pre_desemb.dsb_fecini          ;
    define v_dsb_fecfin         like pre_desemb.dsb_fecfin          ;
    define v_dsb_undsb, v_dsb_valor          like pre_desemb.dsb_undsb           ;
    define v_numpers, v_new_nroperiodos, v_new_nropagos integer;
    DEFINE v_siap, v_capamortper, v_intper, v_amortper, v_sidp like pre_desemb.dsb_valor;
    define v_dsb_feciniint date;
    DEFINE C_INPUT_PERIOD_EXACT, C_TIPOCUO_CAP, C_TIPOCUO_INT, MONTHSPERPERIOD INTEGER;
    define  v_pre_nroperiodos, v_pre_nrogracia, v_pre_nrograciaint, v_pre_nropagos, v_pre_diasfijoper integer;
    define v_nroper_pp_cal, v_pre_methodcapi, v_pre_unidplaz, v_new_nrogracia, v_new_nrograciaint integer;
     define v_fecha_prim_venc, v_fecmax_cap,v_fecha_fin_venc date;
     define D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY date;
    define v_app_t aux_planpagos_t;    
    
        let v_numpers = 0;
        LET C_TIPOCUO_CAP = 1;
        let C_TIPOCUO_INT = 2;
        let C_INPUT_PERIOD_EXACT = 3;

        select dsb_fecdsb, dsb_fecini, dsb_feciniint, dsb_undsb,dsb_valor
        into v_dsb_fecdsb, v_dsb_fecini, v_dsb_feciniint, v_dsb_undsb,v_dsb_valor
        from pre_desemb
        where dsb_coddsb = p_coddsb;

        call f_dsb_getmethod_plz(p_codcred, p_codmod, null) returning v_pre_methodcapi, v_pre_unidplaz;
        call f_get_info_genperiodos(p_codcred, p_codmod) returning v_pre_nroperiodos, v_pre_nrogracia, v_pre_nrograciaint, v_pre_nropagos, v_pre_diasfijoper; 
        
        if v_pre_unidplaz is null then
            raise exception -746,0,"Periodicidad debe tener valor, revise datos del prestamo.";
        end if
        
        if v_pre_unidplaz in (1,7) and nvl(v_pre_diasfijoper, 0) <= 0 then
            raise exception -746,0,"Periodicidad irregular, se requiere dias periodo, revise datos del prestamo.";
        end if
        
        if nvl(v_pre_nroperiodos, 0) <= 0  then
            raise exception -746,0,"Nro de periodos debe ser mayor a cero revise parametros prestamo " || p_codcred;
        end if
        
        if nvl(v_pre_nrogracia, 0) + nvl(v_pre_nropagos, 0) > v_pre_nroperiodos then
            raise exception -746,0,"Nro de periodos (" || v_pre_nroperiodos || ") es menor a nro pagos(" || nvl(v_pre_nropagos, 0) || ") mas nro gracia " || nvl(v_pre_nrogracia, 0);
        end IF
        
        call f_INT_MATURITY_AND_GRACE(p_codmod, p_codcred, NULL) returning D_SIGN, D_PRIMVCTO, D_GRACE, D_GRACEINT, D_MATURITY;
         
        let v_app_t = f_init_app_t();
                
        let v_app_t.acu_codmod = p_codmod;
        let v_app_t.acu_codmodorig = p_codmod;
        let v_app_t.acu_codcred = p_codcred;
        let v_app_t.acu_coddsb = p_coddsb;
        let v_app_t.acu_trxstaau = 1;
        let v_app_t.acu_monpag = 1;
        let v_app_t.acu_auditusr = p_coduser;
        let v_app_t.acu_auditwst = p_estacion;
        let v_app_t.acu_methodcapi = v_pre_methodcapi;
        let v_app_t.acu_unidplaz = v_pre_unidplaz;
        let v_app_t.acu_capital = v_dsb_valor;
        let v_app_t.acu_fecinicuo = v_dsb_fecdsb;
        let v_app_t.acu_fecfincuo = v_dsb_fecini;
        let v_app_t.acu_tipodsb = f_getsession();
        
        call f_getperiodos_mntcuo(v_app_t, v_dsb_feciniint, D_MATURITY, v_pre_nroperiodos, v_pre_diasfijoper)
            returning v_new_nroperiodos, v_new_nropagos, v_new_nrogracia, v_new_nrograciaint, v_fecha_prim_venc, v_fecha_fin_venc; 

        let v_app_t.acu_fecvencuo = v_fecha_prim_venc;
--        let v_fecha_fin_venc = f_periodo_fechafin(v_fecha_prim_venc, v_pre_nroperiodos, v_app_t.acu_unidplaz, v_pre_diasfijoper, null);
        let v_fecha_fin_venc = null;
        -- generacion
        call p_mf_amort_genplan(11, v_app_t, v_dsb_feciniint, 
            v_new_nroperiodos, v_new_nrogracia, v_new_nrograciaint, v_new_nropagos, v_pre_diasfijoper);

        update pre_desemb
        set dsb_nroperiodos = v_pre_nroperiodos,
        dsb_nrogracia = v_pre_nrogracia,
        dsb_nropagos = v_pre_nropagos
        where dsb_coddsb = p_coddsb; 
end procedure;


