


DROP function IF EXISTS d_creditos.f_getinteres_pry;
create function d_creditos.f_getinteres_pry(p_codcred integer, p_codmod integer, p_coddsb integer, p_importe decimal (20,2), 
    p_fechaini date, p_fechafin date)
    returning decimal(20,2)
{
	wherrera 20260501 multiplicacion de dias por fuera del redondeo
}
    define v_dsb_methodcapi, v_dsb_unidplaz integer;
    define DR_REPMTS_PER_YEAR_OUT integer;
    define D_DIFFERENCE_IN_DAYS, v_INTYDAYS integer;
    define v_amtacru, v_amtint decimal(20,2);
    define v_tasabase float;
    define P_TRAINTYDAYS, P_TRAINTMDAYS integer;
    define V_D_FECINIPER date;
    DEFINE C_TASAPERIODO INTEGER;
    define C_ONE_DAY integer;

    LET C_TASAPERIODO = 0;
    let C_ONE_DAY = 1;
    let p_importe = nvl(p_importe, 0);
    
    if p_importe = 0 then
    	return 0;
    end if
    
    call f_GET_TRA_INT_YR_MTH_BASE(p_codmod , p_codcred ) returning P_TRAINTYDAYS, P_TRAINTMDAYS;
    let v_tasabase = f_gettasavigenteprest(p_codcred, p_codmod, p_fechaini);
    
    select pre_unidplaz
    into v_dsb_unidplaz
    from pre_prestamos
    where pre_codmod = p_codmod
    and pre_codcred = p_codcred;
    
    call f_DAYS_BETWEEN_2_DATES(p_fechaini, p_fechafin, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, P_TRAINTYDAYS; 
    -- ajuste el redondeo se hace por fuera
    let v_amtacru = p_importe * f_tasaindiceperiodo(v_dsb_unidplaz, v_tasabase, C_TASAPERIODO, P_TRAINTYDAYS, C_ONE_DAY);
    
    return round(v_amtacru, 2)* D_DIFFERENCE_IN_DAYS;
end function;
