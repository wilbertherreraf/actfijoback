

drop procedure IF EXISTS d_creditos.p_rpro_calc_plan_difer;
create procedure d_creditos.p_rpro_calc_plan_difer(p_trxstaau integer, p_codrepro integer, p_fechaoper date,  
    p_fecor1igdif date, p_fecdest1dif date, p_coduser varchar(100), p_estacion varchar(100))
{
wherrera    2021-10-05  recalcula los valores del DIFERIMIENTO
wherrera    2026-05-05  centraliza los procesos de registro pre auto y autorizacion desde el cliente web
}
    define err_num, err_nro integer;
    define err_msg varchar(235);    

    define V_MNT_PRG, V_MNT_PRGPEND, V_MNT_PRGPENDINT,v_amtacru,v_siap like pre_desemb.dsb_valor;
    define V_D_FECINIPER, V_D_FECFINPER, v_fecsigper, v_feculttrx date;
    define v_cuo_fecvencuo, v_min_fecvencuo, v_max_fecvencuo date;    
    DEFINE v_cuo_codcuo, v_contdif, C_TIPOCUO_INT, C_TIPOCUO_CAP, C_TIPOTRX_DIFER, C_TIPOCOB_APLC_CAPINT INTEGER;
    define C_TIPOCOB_COB,C_TRXSTAAU_VIGENTE, C_TRXSTAAU_PREAUTORIZAR, C_TRXSTAAU_AUTORIZAR, C_TRXSTAAU_ELIMINAR integer;
	define v_isgracia, v_dias, v_dsb_coddsb_int , v_aux_codacu, v_aux_codacunew INTEGER;
	define v_tasabase like pre_tasaspre.mtp_tbase;
    define v_tmo_t pre_tramon_t;
	define v_contar, v_cuo_coddsb integer;
	define v_rds_codmod, v_rds_codcred, v_rds_statreg integer;
    define v_rds_valor, v_rds_undsb like pre_planpagos.cuo_valor; 
    define v_fecultdifer, v_fecultrepro, v_rds_fecini,v_rds_fecfin date;
    define v_rds_fecini_a, v_rds_feciniint_a date;
    define C_TIPOREPRO_DIFER, v_rds_trxstaau,v_rds_tipo_pago integer;
    
    LET C_TIPOCOB_APLC_CAPINT = 3;
    LET C_TIPOTRX_DIFER = 4;
    let C_TIPOREPRO_DIFER = 3;
    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
    let C_TRXSTAAU_VIGENTE = 1;
    let C_TRXSTAAU_PREAUTORIZAR = 2;
    let C_TRXSTAAU_AUTORIZAR = 3;
	let C_TRXSTAAU_ELIMINAR = 9;
    let C_TIPOCOB_COB = 2;

    select rds_codmod, rds_codcred, rds_fecini, rds_fecfin, rds_valor, rds_undsb, rds_statreg, rds_tipo_pago,rds_trxstaau
    into v_rds_codmod, v_rds_codcred, v_rds_fecini,v_rds_fecfin, v_rds_valor, v_rds_undsb, v_rds_statreg, v_rds_tipo_pago,v_rds_trxstaau
    from pre_reprograma
    where rds_codrepro = p_codrepro
    and rds_tiporepro = C_TIPOREPRO_DIFER;
    
	if v_rds_codcred is null then
        raise exception -746,0,"Registro de diferimiento inexistente o suspendido " || p_codrepro;
    end if    
    
	if p_trxstaau = C_TRXSTAAU_ELIMINAR then
    	if v_rds_trxstaau = 3 then
    		raise exception -746,0,"Registro de DIFERIMIENTO AUTORIZADO " || p_codrepro;
    	end if

		delete FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
		and acu_tipodsb = p_codrepro;
    	        
    	delete from pre_reprograma
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_DIFER;
    	
    	return;
    end if    
    
    if v_rds_fecini is null or v_rds_fecfin is null then
        raise exception -746,0,"Fecha de diferimiento destino y origen deben tener valor";
    end if

    if f_pp_get_reguniq(v_rds_codcred, v_rds_codmod, null, v_rds_fecini, null) = 0 or f_pp_get_reguniq(v_rds_codcred, v_rds_codmod, null, v_rds_fecfin, null) = 0 then
        raise exception -746,0,"Fecha de diferimiento origen y destino deben deben estar registrados en el plan de pagos.";
    end if
    if v_rds_fecini >= v_rds_fecfin then
        raise exception -746,0,"Fecha de diferimiento destino debe ser mayor al de origen";
    end if

    let v_feculttrx = f_rpro_fec_ultvalid(v_rds_codcred, v_rds_codmod);
    
    if v_feculttrx is null then
        raise exception -746,0,"No existe ningun cobro o desembolso realizado.";
    end if

    if v_feculttrx >= v_rds_fecini then
        raise exception -746,0,"Fecha a diferir " || v_rds_fecini || " debe ser mayor o igual a ult transcc. " || v_feculttrx;
    end if

    select count(*)
    into v_contdif 
    from pre_planpagos
    where cuo_codcred = v_rds_codcred
    and cuo_codmod = v_rds_codmod
    and cuo_fecvencuo = v_rds_fecini
    and cuo_tipotrx = 4
    and cuo_coddsb > 0;
    
    if v_contdif > 0 then
        raise exception -746,0,"Cuota para fecha origen diferida " || v_rds_fecini;
    end if
    
    select count(*)
    into v_contdif 
    from pre_planpagos
    where cuo_codcred = v_rds_codcred
    and cuo_codmod = v_rds_codmod
    and cuo_fecfincuo = v_rds_fecini
    and cuo_tipotrx = 4
    and cuo_valorpend > 0
    and cuo_fecvencuo < nvl(cuo_fecfincuo, cuo_fecvencuo)
    and cuo_coddsb > 0;

    if v_contdif > 0 then
        raise exception -746,0,"Existen cuotas diferidas para fecha " || v_rds_fecini || " sin cobrar.";
    end if
        
    let v_cuo_codcuo = f_pp_operacionpend(v_rds_codcred, v_rds_codmod, null, v_rds_fecini -1);    
    
    if nvl(v_cuo_codcuo, 0) > 0 then
        --raise exception -746, 0, "Existen cuotas (cod: " || v_cuo_codcuo || ") pendientes a fecha.";
    end if

    call f_pp_minmax_plan(v_rds_codcred, v_rds_codmod, null, null) returning v_min_fecvencuo, v_max_fecvencuo;

    if (v_rds_fecini between v_min_fecvencuo and v_max_fecvencuo) and (v_rds_fecfin between v_min_fecvencuo and v_max_fecvencuo) then
    else
        raise exception -746,0,"Fechas de diferimiento deben estar entre " || v_min_fecvencuo || " - " || v_max_fecvencuo;
    end if
 
    if p_trxstaau = C_TRXSTAAU_VIGENTE then
    	SELECT count(*)
	    INTO v_contar
	    FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
	    AND acu_valor > 0
    	and acu_tipodsb > 0
    	and acu_trxstaau = C_TRXSTAAU_PREAUTORIZAR;
    
    	if v_contar > 0 then
    		raise exception -746, 0, "DIFER: Credito en proceso de revision en tabla auxiliar";
    	end if
    	
		delete from aux_planpagos
	    where acu_codcred = p_codcred
	    and acu_codmod = p_codmod
		and acu_tabtipodsb = C_TIPOREPRO_DIFER;
		
		call p_cpy_planpagos_auxpp(v_rds_codcred, v_rds_codmod, C_TIPOREPRO_DIFER, p_codrepro, p_coduser, p_estacion);
    	
    	-- MARCAMOS LA CUOTA ORIGEN DE FECHA ORIGEN COMO DIFERIDO A FECHA DESTINO
    	update aux_planpagos
    	set acu_fecfincuo = v_rds_fecfin, 
    	acu_tipoacu = decode(acu_tipocuo,1,14,24),
    	acu_tipotrx = 4,
    	acu_trxstaau = 1,
    	acu_monpag = 1,
    	acu_tipodsb = p_codrepro
    	where acu_codcred = v_rds_codcred
    	and acu_codmod = v_rds_codmod
    	and acu_coddsb > 0
    	and acu_tipocuo in (1,2)
    	and acu_valorpend > 0
    	and nvl(acu_tipotrx,2) = 2
    	and nvl(acu_tipoacu, acu_tipocuo) in (1,2)
    	and acu_fecvencuo = v_rds_fecini
    	and acu_fecvencuo = nvl(acu_fecfincuo, acu_fecvencuo);
    
    	-- REGISTRAMOS LOS MONTOS EN LA FECHA DESTINO EN UN CAMPO TEMPO
		update aux_planpagos x
		set x.acu_montocuo = (select nvl(sum(c.acu_valor),0) 
			from aux_planpagos c 
			where c.acu_coddsb = x.acu_coddsb
			and c.acu_codcred = x.acu_codcred
			and c.acu_codmod = x.acu_codmod
			and c.acu_tipoacu = decode(x.acu_tipocuo, 1,14,24)
			and c.acu_tipotrx = 4
			and c.acu_trxstaau = 1
			and c.acu_monpag = 1
			and c.acu_tipocuo = x.acu_tipocuo
			and c.acu_fecvencuo < c.acu_fecfincuo
			and c.acu_fecfincuo = x.acu_fecvencuo
			and c.acu_valorpend > 0
			),
    	x.acu_tipotrx = 2,
    	x.acu_tipoacu = x.acu_tipocuo,
    	x.acu_trxstaau = 1,
    	x.acu_monpag = 1,
    	x.acu_tipodsb = p_codrepro			
		where x.acu_tipocuo in (1,2)
		and nvl(x.acu_tipotrx,2) = 2  
		and x.acu_codcred = v_rds_codcred
		and x.acu_codmod = v_rds_codmod
		and x.acu_coddsb > 0
		--and x.acu_valorpend > 0
		and x.acu_fecvencuo = v_rds_fecfin
    	and x.acu_fecvencuo = nvl(x.acu_fecfincuo, x.acu_fecvencuo);

		-- CREAMOS REGISTROS EN AUXILIAR DE TIPO DIFERIDO 
		foreach 
	        select acu_codacu
	        into v_aux_codacu
	        from aux_planpagos
	        where acu_tipocuo in (1,2)
			and acu_codcred = v_rds_codcred
			and acu_codmod = v_rds_codmod
			and acu_coddsb > 0
			and acu_trxstaau = 1
			and acu_tipotrx = 4
			and acu_tipoacu in (14,24)
			and acu_fecvencuo = v_rds_fecini
			and acu_fecfincuo = v_rds_fecfin
			and acu_valorpend > 0
	        order by acu_coddsb, acu_fecvencuo, acu_tipocuo
	        	let v_aux_codacunew = f_pv_getnextid();
	        	-- se intercambia los tipos acu y cuo para la operacion del mayor
			    INSERT INTO aux_planpagos (acu_codacu, acu_codcred, acu_codmod, acu_fecvencuo, 
			    acu_fecinicuo, acu_fecfincuo, acu_capital, acu_interes, acu_cargos, acu_valor, 
			    acu_valorpend, acu_coddsb, acu_tasa, acu_tipodsb, 
			    acu_tipocuo, acu_methodcapi, acu_unidplaz, acu_tipoacu, acu_monpag, acu_tipotrx, 
			    acu_trxstaau, acu_auditusr, acu_auditfho, acu_auditwst) 
			    select v_aux_codacunew, acu_codcred, acu_codmod, acu_fecfincuo, 
			    acu_fecvencuo, acu_fecfincuo, acu_capital, acu_interes, acu_cargos, acu_valor, 
			    acu_valorpend, acu_coddsb, acu_tasa, p_codrepro, 
			    acu_tipoacu, acu_methodcapi, acu_unidplaz, acu_tipocuo, 1, 2, 
			    1, acu_auditusr, acu_auditfho, acu_auditwst
				from aux_planpagos	
	        	where acu_codacu = v_aux_codacu;
			    
	    end foreach
    
		update pre_reprograma
    	set rds_trxstaau = C_TRXSTAAU_VIGENTE,
    	rds_undsb = 0,
    	rds_auditusr = p_coduser,
    	rds_auditwst = P_ESTACION,
    	rds_auditfho = current
    	where rds_codrepro = p_codrepro;
		
	elif p_trxstaau = C_TRXSTAAU_PREAUTORIZAR then
	    SELECT count(*)
	    INTO v_contar
	    FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
	    AND acu_valor > 0
    	and acu_tipodsb = p_codrepro
		and acu_trxstaau = C_TRXSTAAU_VIGENTE;
    
        IF v_contar = 0 THEN
    		raise exception -746, 0, "DIFER PREAUTO: No existen registros en tabla auxiliar, para cod " || p_codrepro;
    	END if
    
    	call p_control_auxpp(v_rds_codcred, v_rds_codmod, p_codrepro);
    	
        update pre_reprograma
    	set rds_trxstaau = C_TRXSTAAU_PREAUTORIZAR,
    	rds_auditusr = p_coduser,
    	rds_auditwst = P_ESTACION,
    	rds_auditfho = current
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_DIFER;
        
        update aux_planpagos
        set acu_trxstaau = C_TRXSTAAU_PREAUTORIZAR
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
    	and acu_tipodsb = p_codrepro;
        
    elif p_trxstaau = C_TRXSTAAU_AUTORIZAR then
    
    	SELECT count(*)
	    INTO v_contar
	    FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred
	    AND acu_coddsb > 0
	    AND acu_valor > 0
    	and acu_tipodsb = p_codrepro
    	and acu_trxstaau = C_TRXSTAAU_PREAUTORIZAR;

        IF v_contar = 0 THEN
    		raise exception -746, 0, "DIFER AUTO: No existen registros en tabla auxiliar, codrepro: " || p_codrepro;
    	END if
    	
    	call p_cpy_auxpp_planpagos(v_rds_codcred, v_rds_codmod, null, p_codrepro, p_coduser, P_ESTACION);

	    let v_tmo_t = f_genop_recdatos_pre(v_rds_codcred, v_rds_codmod, null, v_rds_fecini, v_rds_fecfin, NULL, p_coduser, P_ESTACION);
	    
	    let v_tmo_t.tmo_fecvencuo = v_rds_fecini;
	    let v_tmo_t.tmo_fechcon = v_rds_fecfin;
	    let v_tmo_t.tmo_fechproc = v_rds_fecfin;
	    let v_tmo_t.tmo_fechreg = CURRENT;
	    let v_tmo_t.tmo_tipotra = C_TIPOTRX_DIFER;
	    let v_tmo_t.tmo_tipocob = C_TIPOCOB_APLC_CAPINT;
	    
	    call p_genop_crear_venc(v_tmo_t);
    	
    	update pre_reprograma
    	set rds_trxstaau = C_TRXSTAAU_AUTORIZAR,
    	rds_undsb = 0,
    	rds_auditusr = p_coduser,
    	rds_auditwst = P_ESTACION,
    	rds_auditfho = current
    	where rds_codrepro = p_codrepro
    	and rds_tiporepro = C_TIPOREPRO_DIFER; 
    	
		delete FROM aux_planpagos
	    WHERE acu_codmod = v_rds_codmod
	    AND acu_codcred = v_rds_codcred;    		
		
    END if

	--MODIFICAMOS EL PLAN
    --call p_log_finlog();    
end procedure;


