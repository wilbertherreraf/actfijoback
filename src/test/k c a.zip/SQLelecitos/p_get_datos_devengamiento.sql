


drop procedure if exists d_creditos.p_get_datos_devengamiento;
create procedure d_creditos.p_get_datos_devengamiento(p_codcred integer, p_codmod integer, p_fechaini date, p_fechafin date) 
RETURNING date as per_ini, INTEGER AS nro_desembolsos, integer as  nro_dias, DECIMAL(16,2) AS interes_devengado, DECIMAL(16,2) as desembolsado, 
DECIMAL(16,2) as saldocapital, DECIMAL(16,2) AS interes_devengado_form;

{
         -- DESCRIP: Obtiene los datos del devengamineto de un credito a una fecha especificada de la tablas correspondientes
         -- PARAMETROS INGRESO: p_codcred integer                       Codigo de credito
         --                     p_codmod integer                        Codigo de modulo
         --                     p_fecha date                            Fecha de devengado
         -- PARAMETROS SALIDA: nro_desembolsos INTEGER                  Nro de desembolsos
         --                    nro_dias INTEGER                         Nro de                    interes_devengado DECIMAL(16,2)          Monto Interes devengado
         --                    desembolsado DECIMAL(16,2)               Monto Desembolsado
         --                    saldocapital DECIMAL(16,2)               Saldo Capital
         -- AUTOR: HENRY IVAN PANIQUE MIRANDA
         -- DEPENDENCIAS: CREDITOS (pre_tasaspre,pre_prestamos,pre_accrual,pre_desemb,pre_planpagos)
         -- CREACI:  30-11-2023
         -- SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         ----------------------------------------------------------------------------------------------------------------------------------------------------
		 --|   Autor   |     Fecha     | SDAPO    |  Descripcion
		 ---------------------------------------------------------------------------
		 --| acanqui   |  15-11-2024   | 2235171  | Adicion de columna para realizar la sumatoria de los intereses devengados sin verificar si tiene pago mes (dato adicionado para el formulario de credito devengados).
		 ---------------------------------------------------------------------------
		 --| wherrera |  15-05-2026   | | se unifica la logica de la extraccion de datos del devengamiento
		 ----------------------------------------------------------------------------
}

DEFINE v_nro_dessembolsos, v_contar, v_contardias    	INTEGER;
DEFINE v_acr_coddsb, v_nro_dias           	INTEGER;
DEFINE w_interes_devengado  	DECIMAL(16,2);
DEFINE w_desembolsado       	DECIMAL(16,2);
DEFINE w_saldocapital       	DECIMAL(16,2);
DEFINE w_interes_devengado_form DECIMAL(16,2);
define v_prc_montodeven, v_int_dias, v_acr_interes like pre_accrual.acr_interes;
define P_TRAINTYDAYS, P_TRAINTMDAYS,P_INTYDAYS integer;
DEFINE v_dev_mes  		DECIMAL(16,2);
DEFINE v_total_desemb       		DECIMAL(16,2);
DEFINE v_saldo_cap,w_total_amortizacion       		DECIMAL(16,2);
DEFINE v_dev_mes_form  	DECIMAL(16,2);
define v_pre_feculttrx, v_ult_fec_acr,v_fechaini,v_fechafin, v_acr_fecaccru,v_prc_fecha, v_fec_31MAntvencuo date;
define C_STATACRU_PROC,C_TIPOCUO_CAP,C_PRESTATUS_VIG,v_pre_status integer;
     
    let v_nro_dessembolsos = 0;
    let v_nro_dias = 0;
    let v_dev_mes = 0;
    let v_total_desemb = 0;
    let v_saldo_cap = 0;
    let v_dev_mes_form = 0;
    let w_interes_devengado_form=0;
   	let w_total_amortizacion = 0;
	let v_int_dias = 0;
    let C_TIPOCUO_CAP = 1;
	let C_PRESTATUS_VIG = 2;
    let C_STATACRU_PROC = 2;
    
	select max(dsb_contdsb), max(acr_fecini), sum(dsb_undsb), max(acr_diasaccr), sum(acr_interes), sum(acr_saldo), sum(acr_interesper)
	into v_nro_dessembolsos,v_ult_fec_acr, v_total_desemb,v_nro_dias, v_dev_mes,v_saldo_cap,v_int_dias 
	from v_monto_cuota
	where acr_codcred = p_codcred 
	and acr_codmod =  p_codmod  
	and acr_fecaccru = p_fechafin
	and acr_tipoacr = 3;
           	
 	RETURN v_ult_fec_acr, nvl(v_nro_dessembolsos,0), nvl(v_nro_dias,0), nvl(v_dev_mes,0), 
 		nvl(v_total_desemb,0), nvl(v_saldo_cap,0), nvl(v_int_dias,0);
	
END PROCEDURE;
