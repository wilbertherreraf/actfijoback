


DROP procedure IF EXISTS d_creditos.p_set_estado_proceso_conta;
create procedure d_creditos.p_set_estado_proceso_conta(p_tipocmp integer, p_idtabla integer, p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, 
	p_nvoestado integer, p_usuario varchar(15), p_estacion varchar(50))
{
          DESCRIPCI: Cambia o actualiza el estado del proceso y el comprobante en coin
          AUTOR: HENRY IVAN PANIQUE MIRANDA
          CREACI:  30-11-2023
          SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
          HISTORIAL DE CAMBIOS
         wherrera 20260506 se adiciona procesos de actualizacion en pre_planpagos en devengados y se adiciona que en un dia puede existir mas comprobantes de dias devengados diferentes 
}

  define w_prc_estado integer;
  define v_idtabla,v_codcred, v_codmod, v_coddsb,v_estado,v_tipocmp,v_nro_centro,v_contar,v_contcmpcoin integer;
  define v_tipoproc, v_nro_comprob, v_cve_tipo_comprob ,v_nuevoestado ,v_nvostat_espect varchar(15);
  define v_fec_vcto, v_fecha_cont,w_fecha_coin date;
  define v_monto_mn decimal(20,2);
  define v_glosa lvarchar(500);
 
  if p_nvoestado is null or p_nvoestado <= 0 then
     Raise Exception -746, 0, "El estado especificado no es valido.";
  end if   
  
	let v_tipoproc = null;
	let v_codcred = null; 
	let v_codmod = null; 
	let v_coddsb = null;

	select tipoproc,idtabla,codcred, codmod, coddsb, tipocmp,estado,
	nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto,monto_mn, glosa
	into v_tipoproc,v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_estado,
	v_nro_comprob,v_cve_tipo_comprob, v_fecha_cont,v_fec_vcto, v_monto_mn, v_glosa
	from table(p_get_estado_proceso_conta(p_tipocmp, nvl(p_idtabla,0), nvl(p_codcred, 0),p_codmod, null,null, null, null)) 
		t(tipoproc,idtabla,codcred, codmod, coddsb,tipocmp,estado,
			nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto, monto_mn, glosa)
	where estado in (1,2,3);
	
	if v_idtabla is null then
		raise exception -746,0,"Cambio estado: Registro inexistente ID: '" || p_idtabla  || "' tipo CMPOPER: " || p_tipocmp;
	end if
	
	select cmp_centro 
	into v_nro_centro
	from gen_comprobante
	where cmp_codcmp= p_tipocmp;
	
	let v_nuevoestado = decode(p_nvoestado,1,"P",2,"1",3,"A",4,"R","0");
	let v_nvostat_espect = "0";
	
	if p_nvoestado in (2,3) and v_estado != p_nvoestado then
		select count(1)
		into v_contar
		from gen_prcparams
	    where prp_codprc = v_idtabla
	    and prp_tipoproc = v_tipocmp
	    and prp_ctamov is not null
	    and prp_nroreng > 0
	    and prp_montomo > 0
    	and prp_estado = 3;
    
    	if v_contar < 2 then
    		Raise Exception  -746, 0, "Camb Estado: Registros insuficientes en gen_prcparams para tipo: " || p_tipocmp || " idtabla = " || v_idtabla;
    	end if
	end if
	
	let w_prc_estado = p_nvoestado;
	let v_contcmpcoin = 0;
	
	if length(trim(nvl(v_nro_comprob,""))) > 0 then
		if p_nvoestado = 8 then
			select count(1) 
			into v_contcmpcoin
			from table(obtiene_interes_devengado(p_tipocmp,v_codcred, v_codmod, v_fecha_cont, v_cve_tipo_comprob, v_nro_comprob)) 
			t (fecha_cont_coin,nro_comprob_coin,mnt_dev, cve_tipo_comprob_coin,nro_afectablecoind,glosa);		
		else
			select count(1) 
			into v_contcmpcoin
			from table(obtiene_interes_devengado(p_tipocmp,v_codcred, v_codmod, v_fecha_cont, null, v_nro_comprob)) 
			t (fecha_cont_coin,nro_comprob_coin,mnt_dev, cve_tipo_comprob_coin,nro_afectablecoind,glosa);
		end if
	end if
	
	if p_nvoestado = 8 then
		if length(trim(nvl(v_nro_comprob,""))) = 0 then
			raise exception -746,0,"Se requiere nro de Comprobante " || v_idtabla;
		end if
		if v_contcmpcoin = 0 then
			raise exception -746,0,"Comprobante inexistente en coin o en estado no aprobado, nroCmpb: " || v_nro_comprob || " fecha: " || v_fecha_cont || " idoper: " || v_idtabla;
		end if
	end if
	
	if v_contcmpcoin = 0 then
	-- cmpb no autorizado
		if v_estado in (1,2) then
			if length(trim(nvl(v_nro_comprob,""))) > 0 and v_nuevoestado in ("1","A","R") then
				call p_cambia_estado_comprobante(v_idtabla, p_tipocmp, p_codcred, p_codmod,p_coddsb, 
				v_nro_comprob,v_nro_centro, v_cve_tipo_comprob, v_fecha_cont, v_nuevoestado, p_usuario, p_estacion) returning v_nvostat_espect;
		
				let w_prc_estado = decode(v_nvostat_espect, "P",1,"1",2,"A",3,"R",4,5);
				let v_contcmpcoin = decode(v_nvostat_espect,"A",1,0);
			end if
		end if
	else
		if v_contcmpcoin > 1 then
			let v_contcmpcoin = 0;
			if length(trim(nvl(v_nro_comprob,""))) > 0 and length(trim(nvl(v_cve_tipo_comprob,""))) > 0 then	
				select count(1) 
				into v_contcmpcoin
				from table(obtiene_interes_devengado(p_tipocmp,v_codcred, v_codmod, v_fecha_cont, v_cve_tipo_comprob, v_nro_comprob)) 
				t (fecha_cont_coin,nro_comprob_coin,mnt_dev, cve_tipo_comprob_coin,nro_afectablecoind,glosa);		
			end if
		end if
	end if

	if v_contcmpcoin = 1 then
		let w_prc_estado = 3;
	end if
	
	if p_tipocmp = 8 then 
	      -- actualizar datos del proceso en la tabla pre_registrogarantias
		  update pre_registrogarantias
	      set estado = w_prc_estado,
	    audit_usuario_preautoriza = decode(v_nvostat_espect, "1", p_usuario, audit_usuario_preautoriza),
	    audit_fechahora_preautoriza = decode(v_nvostat_espect, "1", current::datetime year to second, audit_fechahora_preautoriza),
	    audit_host_preautoriza = decode(v_nvostat_espect, "1", p_estacion, audit_host_preautoriza),
	    audit_usuario_autoriza = decode(v_nvostat_espect, "A",p_usuario,"R", p_usuario, audit_usuario_autoriza),
	    audit_fechahora_autoriza = decode(v_nvostat_espect, "A",current::datetime year to second,"R", current::datetime year to second, audit_fechahora_autoriza),
	    audit_host_autoriza = decode(v_nvostat_espect, "A",p_estacion,"R", p_estacion, audit_host_autoriza)
	      where id = v_idtabla
		and codcred = p_codcred
		and codmod = p_codmod; 
	
    elif p_tipocmp in (1,2) then
    
		update pre_desembolso_detalle
		set estado = w_prc_estado,
	    audit_usuario_preautoriza = decode(v_nvostat_espect, "1", p_usuario, audit_usuario_preautoriza),
	    audit_fechahora_preautoriza = decode(v_nvostat_espect, "1", current::datetime year to second, audit_fechahora_preautoriza),
	    audit_host_preautoriza = decode(v_nvostat_espect, "1", p_estacion, audit_host_preautoriza),
	    audit_usuario_autoriza = decode(v_nvostat_espect, "A",p_usuario,"R", p_usuario, audit_usuario_autoriza),
	    audit_fechahora_autoriza = decode(v_nvostat_espect, "A",current::datetime year to second,"R", current::datetime year to second, audit_fechahora_autoriza),
	    audit_host_autoriza = decode(v_nvostat_espect, "A",p_estacion,"R", p_estacion, audit_host_autoriza)       
	    where id = v_idtabla
		and codcred = p_codcred
		and codmod = p_codmod; 
		
    elif p_tipocmp = 9 then 
            -- actualizar datos del proceso en la tabla pre_custodia_garantia
        update pre_custodia_garantia 
        set estado = w_prc_estado,
	    audit_usuario_preautoriza = decode(v_nvostat_espect, "1", p_usuario, audit_usuario_preautoriza),
	    audit_fechahora_preautoriza = decode(v_nvostat_espect, "1", current::datetime year to second, audit_fechahora_preautoriza),
	    audit_host_preautoriza = decode(v_nvostat_espect, "1", p_estacion, audit_host_preautoriza),
	    audit_usuario_autoriza = decode(v_nvostat_espect, "A",p_usuario,"R", p_usuario, audit_usuario_autoriza),
	    audit_fechahora_autoriza = decode(v_nvostat_espect, "A",current::datetime year to second,"R", current::datetime year to second, audit_fechahora_autoriza),
	    audit_host_autoriza = decode(v_nvostat_espect, "A",p_estacion,"R", p_estacion, audit_host_autoriza)       
        where id = v_idtabla
		and codcred = p_codcred
		and codmod = p_codmod;
    
    elif p_tipocmp = 10 then 
            -- actualizar datos del proceso en la tabla pre_retiro_garantia
        update pre_retiro_garantia 
        set estado = w_prc_estado,
	    audit_usuario_preautoriza = decode(v_nvostat_espect, "1", p_usuario, audit_usuario_preautoriza),
	    audit_fechahora_preautoriza = decode(v_nvostat_espect, "1", current::datetime year to second, audit_fechahora_preautoriza),
	    audit_host_preautoriza = decode(v_nvostat_espect, "1", p_estacion, audit_host_preautoriza),
	    audit_usuario_autoriza = decode(v_nvostat_espect, "A",p_usuario,"R", p_usuario, audit_usuario_autoriza),
	    audit_fechahora_autoriza = decode(v_nvostat_espect, "A",current::datetime year to second,"R", current::datetime year to second, audit_fechahora_autoriza),
	    audit_host_autoriza = decode(v_nvostat_espect, "A",p_estacion,"R", p_estacion, audit_host_autoriza)       
        where id = v_idtabla
		and codcred = p_codcred
		and codmod = p_codmod; 
    
    elif p_tipocmp = 3 then
	     update pre_prcconta
	        set prc_estado = w_prc_estado,  
		prc_auditusrpreaut = decode(v_nvostat_espect, "1", p_usuario, prc_auditusrpreaut),
	    prc_auditfhopreaut = decode(v_nvostat_espect, "1", current::datetime year to second, prc_auditfhopreaut),
	    prc_auditwstpreaut = decode(v_nvostat_espect, "1", p_estacion, prc_auditwstpreaut),
	    prc_auditusraut = decode(v_nvostat_espect, "A",p_usuario,"R", p_usuario, prc_auditusraut),
	    prc_auditfhoaut = decode(v_nvostat_espect, "A",current::datetime year to second,"R", current::datetime year to second, prc_auditfhoaut),
	    prc_auditwstaut = decode(v_nvostat_espect, "A",p_estacion,"R", p_estacion, prc_auditwstaut)
	      where prc_codprc = v_idtabla
		and prc_codcred = p_codcred
		and prc_codmod = p_codmod;
    
    elif p_tipocmp in (4,5,6,7) then 
            -- actualiza datos del proceso en la tabla pre_pagocuota

      	update pre_pagocuota
      	set estado = w_prc_estado,
	    audit_usuario_preautoriza = decode(v_nvostat_espect, "1", p_usuario, audit_usuario_preautoriza),
	    audit_fechahora_preautoriza = decode(v_nvostat_espect, "1", current::datetime year to second, audit_fechahora_preautoriza),
	    audit_host_preautoriza = decode(v_nvostat_espect, "1", p_estacion, audit_host_preautoriza),
	    audit_usuario_autoriza = decode(v_nvostat_espect, "A",p_usuario,"R", p_usuario, audit_usuario_autoriza),
	    audit_fechahora_autoriza = decode(v_nvostat_espect, "A",current::datetime year to second,"R", current::datetime year to second, audit_fechahora_autoriza),
	    audit_host_autoriza = decode(v_nvostat_espect, "A",p_estacion,"R", p_estacion, audit_host_autoriza)
  		where id=v_idtabla
		and codcred = p_codcred
		and codmod = p_codmod;

		UPDATE pre_tramon 
		set tmo_trxstaau = decode(w_prc_estado,1,1,2,2,3,3,tmo_trxstaau),
		tmo_statreg = decode(w_prc_estado,4,9,5,9,7,9,tmo_statreg),
		tmo_auditfho = current,
		tmo_auditwst = p_estacion,
		tmo_auditusr = p_usuario		
		where tmo_codmod = p_codmod
		and tmo_codcred = p_codcred 
		and tmo_coddsb = p_coddsb
		and tmo_tipotra in (2,3)
		and tmo_statreg = 0
		and tmo_numtrx = (select pcu_numtrx
			from pre_pagocuota
			where id = v_idtabla
			and pcu_tipocmp = v_tipocmp 
			and codcred = tmo_codcred
			and codmod = tmo_codmod
			and coddsb = tmo_coddsb);    
    end if

    if w_prc_estado = 3 then
    	if v_contcmpcoin = 1 then
    		if p_nvoestado = 8 then
    			call p_init_proceso_conta(v_tipocmp, v_idtabla, 2, v_codcred, v_codmod, null, p_usuario, p_estacion);
    		else
    			if w_prc_estado = v_estado then
					call p_init_proceso_conta(v_tipocmp, v_idtabla, 1, v_codcred, v_codmod, null, p_usuario, p_estacion);
    			end if
    		end if
    	end if
    end if

    	update gen_prcparams
		set prp_estado = 1,
		prp_auditusr = p_usuario,
		prp_auditfho = current,
		prp_auditwst = p_estacion
	    where prp_codprc = v_idtabla
	    and prp_tipoproc = v_tipocmp
	    and (prp_ctamov is null or prp_nroafectable is null);
    	
    	update gen_prcparams
		set prp_estado = decode(w_prc_estado,1,prp_estado,2,prp_estado,3,3,4),
		prp_auditusr = p_usuario,
		prp_auditfho = current,
		prp_auditwst = p_estacion
	    where prp_codprc = v_idtabla
	    and prp_tipoproc = v_tipocmp
	    and prp_ctamov is not null
	    and prp_nroafectable is not null
	    and prp_nroreng > 0
	    and prp_montomo > 0;
    
END PROCEDURE;



