



DROP function IF EXISTS d_creditos.f_tasaindiceperiodo;
create function d_creditos.f_tasaindiceperiodo(p_unidplaz integer, p_tasa float, p_tasaesanual integer, P_TRA_INT_Y_DAYS integer, P_TRA_INT_M_DAYS integer) 
    returning float
    {
    -- p_tasaesanual 0: es interes del periodo, 1: es tasa anual
    wherrera 20260405 ajuste del calculo de redondeo, es por fuera del redondeo por lo que el numero de decimales debe ser el ampliado NO asi el redondeado
    }
define v_nroperanio, DR_REPMTS_PER_YEAR_OUT, v_TRA_INT_Y_DAYS, D_NO_OF_FULL_DAYS integer;
define v_tasabase float;

    let P_TRA_INT_M_DAYS = nvl(P_TRA_INT_M_DAYS, 1);
    let P_TRA_INT_Y_DAYS = nvl(P_TRA_INT_Y_DAYS, 1);

    let p_tasaesanual = nvl(p_tasaesanual, 0);
    
    if p_tasaesanual != 0 then
        let p_tasaesanual = 1;
    end if
    
    if P_TRA_INT_Y_DAYS is null or P_TRA_INT_Y_DAYS = 0 then
        let P_TRA_INT_Y_DAYS = 1;
    end if            
    if P_TRA_INT_M_DAYS is null then
        let P_TRA_INT_M_DAYS = 1;
    end if                
    
    let v_nroperanio = f_ISREPMTSPERYEAR(p_unidplaz) * p_tasaesanual; 
    if v_nroperanio = 0 then
        let v_nroperanio = 1;
    end if
    
    if P_TRA_INT_Y_DAYS >= 360 then
        let v_nroperanio = 1;
    end if
    
    if P_TRA_INT_Y_DAYS = 1 then
        if p_unidplaz in (12,13,15,16) then -- exacto
            if p_tasaesanual = 0 then
                let v_nroperanio = 1;
            end if
        elif p_unidplaz in (1, 7) then -- irregular diario
            if p_tasaesanual = 1 then
                let v_nroperanio = 360;
            end if
        end if    
    end if

    let v_tasabase = p_tasa / (100 * v_nroperanio) * (P_TRA_INT_M_DAYS/P_TRA_INT_Y_DAYS) ;

	RETURN v_tasabase;
END FUNCTION;




