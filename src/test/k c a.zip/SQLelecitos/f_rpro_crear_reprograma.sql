


DROP function IF EXISTS d_creditos.f_rpro_crear_reprograma;
create function d_creditos.f_rpro_crear_reprograma(p_codcred integer, p_codmod integer, p_tipotrx integer, p_codrepro integer, p_coduser varchar(100), p_estacion varchar(100))
returning integer
{***** ==> LOG <== *****
wherrera    2021-10-05  inicia la reprogramacion del credito copia datos de los desembolsos en pre_reprograma
}

define v_rds_feculttrx, v_rds_fecini, v_rds_fecfin, v_rds_feciniint  date;
define v_rds_methodcapi, v_rds_unidplaz integer;
define v_cont,v_rds_codrepro integer;
define C_TIPOREPRO_REPRO, C_TIPOCUO_INT,C_TIPOREPRO_TEMPO, C_REPRO_END, C_REPRO_INIT integer;
define v_pre_nroperiodos, v_pre_nrogracia, v_pre_nrograciaint, v_pre_nropagos, v_pre_diasfijoper integer;
define v_fecha_ini, V_D_FECFINPER, v_min_fecvencuo, v_max_fecvencuo date;
define v_rds_nrodoc varchar(50);

    let C_TIPOCUO_INT = 2;
    LET C_TIPOREPRO_REPRO = 1;
    LET C_TIPOREPRO_TEMPO = 5;
    let C_REPRO_INIT = 999;
    let C_REPRO_END = -999;
    let v_rds_nrodoc = null;
    
    IF p_codrepro > 0 and p_tipotrx = C_REPRO_INIT then
    -- simularmos registro de sesiones
		SELECT count(1), max(rds_codrepro)
		INTO v_cont, v_rds_codrepro
		FROM pre_reprograma
		WHERE rds_codcred = p_codcred
    	and rds_tiporepro = C_TIPOREPRO_TEMPO
    	and rds_codmod = p_codmod
    	and rds_auditusr = p_coduser
    	and rds_nrodoc = "" || p_codrepro;
    
    	IF v_cont = 1 THEN
    		return v_rds_codrepro;
    	END if
    	
    	delete FROM pre_reprograma
		WHERE rds_codcred = p_codcred
    	and rds_tiporepro = C_TIPOREPRO_TEMPO
    	and rds_codmod = p_codmod
    	and rds_auditusr = p_coduser;
    	
    	let v_rds_nrodoc = "" || p_codrepro;
    	let p_tipotrx = C_TIPOREPRO_TEMPO;
	END IF

    if p_tipotrx = C_REPRO_END then
    	delete FROM pre_reprograma
		WHERE rds_codcred = p_codcred
    	and rds_tiporepro = C_TIPOREPRO_TEMPO
    	and rds_codmod = p_codmod
    	and rds_auditusr = p_coduser;
    
    	return null;
    end if
    
    let v_rds_codrepro = f_rpro_getnextid();    
    
    insert into pre_reprograma(rds_codrepro, rds_codcred, rds_codmod,rds_nrodoc, 
    rds_tiporepro, rds_trxstaau, rds_auditfho, rds_auditusr,rds_auditwst, rds_statreg)
    values(v_rds_codrepro, p_codcred, p_codmod,v_rds_nrodoc,  
    nvl(p_tipotrx, C_TIPOREPRO_REPRO), 1, current, p_coduser, p_estacion, 0); 
    
    return v_rds_codrepro;
end function;


