


drop function if exists d_creditos.f_dsb_prorrateo;
create function d_creditos.f_dsb_prorrateo(p_codcred integer, p_codmod integer, p_fecha date, p_importe decimal(20,2))
returning integer, date, integer, decimal(15,5), decimal(20,2), decimal(20,2), decimal(20,2), decimal(20,2), decimal(20,2), decimal(20,2)

{
-- call f_dsb_prorrateo(6, 17, "2026-05-27", 75792.42)
 
wherrera 2021.11.01 prorrateo del importe entre el saldo capital programado
wherrera 2026.04.03 control del importe a prorratear
}
define v_dsb_coddsb, v_contar, v_cont integer;
define v_amt_cuo_pend, v_dsb_valor, v_dsb_undsb, v_new_unpaid,v_new_unpaid_k, v_dsb_saldo like pre_desemb.dsb_valor;
define v_amt_sum_int, v_dsb_resto,v_dsb_resto_int, v_siap, v_amtacru like pre_desemb.dsb_valor;  
define v_mnt_sobra, v_sum_dsb, v_int_importe, v_amt_sum_cap,v_amt_sum_siap , v_sum_diff_int like pre_desemb.dsb_valor;
define v_int_dev, v_int_neto, v_cap_importe, v_sum_cuo_valorpend, v_controlsuma , v_importe_int like pre_desemb.dsb_valor;
define V_D_FECINIPER, V_D_FECFINPER, v_dsb_fecdsb,v_fecsigvcto,v_feciniper,v_fec_ini_rpro date;
DEFINE D_DIFFERENCE_IN_DAYS, v_dias, v_isgracia, C_TIPOCUO_INT, C_TIPOCUO_CAP INTEGER;
define v_tasabase like pre_tasaspre.mtp_tbase; 

LET C_TIPOCUO_CAP = 1;
LET C_TIPOCUO_INT = 2;
let v_controlsuma = 0;
let v_amt_sum_int = 0;
let v_cap_importe = 0;
let v_contar = 0;
let v_amt_sum_cap = 0;
let v_amt_sum_siap = 0;


        foreach 
            select dsb_coddsb, dsb_fecdsb, dsb_valor
            into v_dsb_coddsb, v_dsb_fecdsb, v_dsb_valor
            from pre_desemb
            where dsb_codmod = p_codmod 
            and dsb_codcred = p_codcred
            and dsb_valor > 0
            AND dsb_fecdsb < p_fecha
            and exists (select 1
                from pre_planpagos
                where cuo_codmod = dsb_codmod
                and cuo_codcred = dsb_codcred
                and cuo_coddsb = dsb_coddsb
                and cuo_valor > 0
                and cuo_fecvencuo >= p_fecha
            )            
            order by dsb_fecdsb
            let v_fec_ini_rpro = f_pp_fechainiper(p_codcred, p_codmod, v_dsb_coddsb, p_fecha, C_TIPOCUO_INT);
            CALL f_getinteres_dsb(p_codcred, p_codmod, v_dsb_coddsb, v_fec_ini_rpro, p_fecha, p_fecha, 2) 
            	returning V_D_FECINIPER, V_D_FECFINPER, D_DIFFERENCE_IN_DAYS, v_tasabase, v_siap, v_amtacru, v_int_dev, v_int_neto;

        	let v_amt_sum_siap = v_amt_sum_siap + v_siap;
        	let v_amt_sum_int = v_amt_sum_int + v_int_neto;
        	let v_contar = v_contar + 1;
        end foreach
        
        if v_contar = 0 or p_importe <= 0 or v_amt_sum_siap <= 0 then
            return;
        end if
		let v_amt_sum_cap = 0;
        if v_amt_sum_int >= p_importe then
        	let v_amt_sum_cap = p_importe - v_amt_sum_int; 
		end if
		
        let v_cont = 0;
        let v_sum_dsb = 0;
        let v_dsb_resto = p_importe;
		let v_amt_cuo_pend = 0;                
		let v_sum_diff_int = 0;
		if v_amt_sum_int - p_importe > 0 then
       		let v_sum_diff_int = v_amt_sum_int - p_importe;
		end if
        foreach
            select dsb_coddsb, dsb_fecdsb, dsb_valor
            into v_dsb_coddsb, v_dsb_fecdsb, v_dsb_valor
            from pre_desemb
            where dsb_codmod = p_codmod 
            and dsb_codcred = p_codcred
            and dsb_valor > 0
            AND dsb_fecdsb < p_fecha
            and exists (select 1
                from pre_planpagos
                where cuo_codmod = dsb_codmod
                and cuo_codcred = dsb_codcred
                and cuo_coddsb = dsb_coddsb
                and cuo_valor > 0
                and cuo_fecvencuo >= p_fecha
            )            
            order by dsb_fecdsb
            	let v_fec_ini_rpro = f_pp_fechainiper(p_codcred, p_codmod, v_dsb_coddsb, p_fecha, C_TIPOCUO_INT);
            	CALL f_getinteres_dsb(p_codcred, p_codmod, v_dsb_coddsb, v_fec_ini_rpro, p_fecha, p_fecha, 2) 
            		returning V_D_FECINIPER, V_D_FECFINPER, D_DIFFERENCE_IN_DAYS, v_tasabase, v_siap, v_amtacru, v_int_dev, v_int_neto;
        
                let v_cont = v_cont + 1;
                let v_int_importe = 0;            
                let v_new_unpaid = 0;
                let v_new_unpaid_k = 0;
        		let v_cap_importe = 0;
                let v_importe_int = v_int_neto;
                if v_amt_sum_int - p_importe > 0 then
                    if v_amt_sum_siap - v_amt_cuo_pend != 0 then
                        let v_new_unpaid = round(v_siap / (v_amt_sum_siap - v_amt_cuo_pend)  * (v_amt_sum_int - p_importe) , 2);
                    else
                        let v_new_unpaid = 0;
                    end if
                    let v_int_importe = round(v_importe_int - v_new_unpaid, 2);
                else
                    let v_new_unpaid = 0;
                	let v_int_importe = v_importe_int;

                	if p_importe - v_amt_sum_int > 0 then
	                	if v_amt_sum_siap - v_amt_cuo_pend != 0 then
							let v_new_unpaid_k = round(v_siap / (v_amt_sum_siap - v_amt_cuo_pend)  * (v_amt_sum_siap - p_importe) , 2);
	                	else
	                		let v_new_unpaid_k = 0;
	                	end if                	
                		let v_cap_importe = round(v_siap - v_new_unpaid_k, 2);
                		let v_cap_importe = v_cap_importe - v_int_importe;
                	end if
                end if
				
                let v_sum_diff_int = v_sum_diff_int - v_new_unpaid;
                let v_sum_dsb = v_sum_dsb + v_int_importe;
                let v_controlsuma = v_controlsuma + v_cap_importe + v_int_importe;
                
                IF v_contar = v_cont then
                	let v_mnt_sobra = 0; 
                	
                	if v_amt_sum_int - p_importe > 0 then
                    	let v_mnt_sobra = p_importe - v_sum_dsb;
                		let v_int_importe = v_int_importe + v_mnt_sobra;
                	else
                		let v_mnt_sobra = p_importe - v_controlsuma;
                		let v_cap_importe = v_cap_importe + v_mnt_sobra; 
                	end if
                	
                    return v_dsb_coddsb, v_dsb_fecdsb, D_DIFFERENCE_IN_DAYS, v_tasabase, v_cap_importe, v_siap, v_amtacru, v_int_dev, v_int_neto, v_int_importe with resume;
                    exit foreach;
                else
                    let v_dsb_resto = v_dsb_resto - v_int_importe; 
                    return v_dsb_coddsb, V_D_FECINIPER, D_DIFFERENCE_IN_DAYS, v_tasabase, v_cap_importe,  v_siap, v_amtacru, v_int_dev, v_int_neto, v_int_importe with resume;
                end if
        end foreach;
                
end function;


