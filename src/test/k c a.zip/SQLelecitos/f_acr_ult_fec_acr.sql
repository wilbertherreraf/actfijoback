

DROP function if exists d_creditos.f_acr_ult_fec_acr;
create function d_creditos.f_acr_ult_fec_acr(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_tipoacr integer)
    returning date
    {
    wherrera 20260505 retorna la ultima fecha de un devengamiento segun el plan depagos ult vencimiento de interes o pagoanticipado o desembolso
p_tipoacr: tipo de proceso
	-- 1: ultimo devengamiento registrado en prconta
	-- 2: ultimo vencimiento interes
	-- 3: ultima actividad , util para conocer si hubo cambios
	-- 5: ultimo devengamiento contabilizado o ult vencimiento
	-- 6: devengamiento mensual 

    }
    define v_fecha, v_fecsigvcto, v_acr_fecaccru_ant, v_pge_feccierre, v_pge_fecultrep, v_fecult_dev, V_D_FECINIPER date;
    define C_TIPOCUO_DIFER_INT, C_TIPOCUO_DEVENG_INT,v_cont,C_COBCODIGO_DSB, C_TIPOCUO_INT, C_TIPOCUO_PANTI_INT integer;
	define v_rds_fecini,v_ult_dsb, v_prc_fecha_fin, v_LAST_D_M,v_END_D_M,v_ST_D_M,V_FECINIPER, V_FECULT_PER_ANT date;
	define C_SGTE_DEVENGAMIENTO integer;
	define v_tmo_fechcon, v_fec_ult_actpp,v_sgte_dev,v_dsb_fecdsb date;
	define v_sum_pp,v_cuo_valor,v_cuo_valorpend like pre_planpagos.cuo_valor;
	
	let C_SGTE_DEVENGAMIENTO = 13;
	let C_TIPOCUO_INT = 2;
	let C_TIPOCUO_PANTI_INT = 22;
	LET C_TIPOCUO_DIFER_INT = 24;
	let v_cont = 0;
	let p_fecha = nvl(p_fecha, current);
	let v_LAST_D_M = last_day(p_fecha); -- ultimo dia del mes
	let v_fecult_dev = null;
	let v_prc_fecha_fin = null;
	let v_ST_D_M = mdy(month(p_fecha), 1,year(p_fecha));
	LET C_COBCODIGO_DSB = 3; 
	let v_ult_dsb = null;
	let V_D_FECINIPER = null;
	let v_sgte_dev = null;
	let C_TIPOCUO_DEVENG_INT = 28;
	let v_fecha = p_fecha;

	if p_tipoacr in (1,3,5) then
		let v_fecult_dev = f_acr_ult_fec_proc(p_codcred, p_codmod, p_coddsb, p_fecha);
	end if
	
	if p_tipoacr = 1 then
	-- ultimo con comprobante
		return v_fecult_dev;
	end if	
	let v_dsb_fecdsb = null;
	let v_fecsigvcto = p_fecha + 1;
	let V_D_FECINIPER = null;
	
	if p_tipoacr in (2,5) then
		select max(fec_ini_per)
		into V_D_FECINIPER
		from (
			select MAX(cuo_fecvencuo) fec_ini_per 
		    from pre_planpagos
		    where cuo_codmod = p_codmod
		    and cuo_codcred = p_codcred
		    and cuo_fecvencuo < v_fecsigvcto
		    and cuo_tipocuo = C_TIPOCUO_INT
		    and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
		    and CUO_valor > 0
		    and cuo_coddsb > 0
		
		    union
		    
			select MAX(cuo_fecvencuo) fec_ini_per 
		    from pre_planpagos
		    where cuo_codmod = p_codmod
		    and cuo_codcred = p_codcred
		    and cuo_fecvencuo < v_fecsigvcto
		    and cuo_tipocuo = C_TIPOCUO_PANTI_INT
		    and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
		    and CUO_valor > 0
		    and cuo_coddsb > 0
		    
		    union 
		    
			select max(dsb_fecdsb)
		    from pre_desemb
		    where dsb_codmod = p_codmod
		    and dsb_codcred = p_codcred
		    and dsb_fecdsb < v_fecsigvcto
		    and dsb_coddsb = nvl(p_coddsb,dsb_coddsb)
			and dsb_valor > 0
			and dsb_undsb > 0	    
		);
	end if	

	if p_tipoacr = 2 then
		return V_D_FECINIPER;
	end if
	
	if p_tipoacr = 3 then
		if v_fecult_dev is null then
			select max(dsb_fecdsb)
			into v_dsb_fecdsb
		    from pre_desemb
		    where dsb_codmod = p_codmod
		    and dsb_codcred = p_codcred
		    and dsb_fecdsb < v_fecsigvcto
		    and dsb_coddsb = nvl(p_coddsb,dsb_coddsb)
			and dsb_valor > 0
			and dsb_undsb > 0;
		
			if v_dsb_fecdsb is null then
				return null;
			end if
			
			select MAX(cuo_fecvencuo) fec_ini_per
			into v_fecult_dev
		    from pre_planpagos
		    where cuo_codmod = p_codmod
		    and cuo_codcred = p_codcred
		    and cuo_fecvencuo < v_fecsigvcto
		    and cuo_tipocuo in (C_TIPOCUO_INT,C_TIPOCUO_PANTI_INT)
		    and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
		    and CUO_valor > 0
		    and cuo_coddsb > 0;
			
			let v_fecult_dev = nvl(v_fecult_dev, v_dsb_fecdsb + 1);
		else
			if v_fecult_dev = p_fecha then
				return v_fecult_dev;
			end if		
		end if
			
		-- ultima actividad 
		let v_fec_ult_actpp = null;
		
        select max(cuo_fecvencuo)
        into v_fec_ult_actpp
        from pre_planpagos
        where cuo_codcred = p_codcred
        and cuo_codmod = p_codmod
        and cuo_fecvencuo < v_fecsigvcto
        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
        and cuo_coddsb > 0
        and cuo_valor > 0
        and cuo_tipotrx != 4
        and cuo_tipocuo in (1,2,22,12)
        and cuo_fecvencuo >= v_fecult_dev
		and cuo_valor != cuo_valorpend;
		
		if v_fec_ult_actpp is not null then
		--raise exception -746,0,"adf " || v_fecult_dev;
			return v_fec_ult_actpp;
		else 
	        select max(cuo_fecvencuo)
        	into v_fec_ult_actpp
	        from pre_planpagos
	        where cuo_codcred = p_codcred
	        and cuo_codmod = p_codmod
	        and cuo_fecvencuo < v_fecsigvcto
	        and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
	        and cuo_coddsb > 0
	        and cuo_valor > 0
	        and cuo_tipotrx = 4
	        and cuo_fecvencuo < cuo_fecfincuo;
			
			if v_fec_ult_actpp is not null then
				if v_fecult_dev is null or v_fecult_dev < v_fec_ult_actpp then
					return v_fec_ult_actpp;
				end if
			end if
		end if
		
		let v_tmo_fechcon = null;
		
		select max(tmo_fechreg)
		into v_tmo_fechcon
		from pre_tramon
		where tmo_codcred = p_codcred
		and tmo_codmod = p_codmod
		and tmo_coddsb = nvl(p_coddsb, tmo_coddsb)
		and tmo_statreg = 0
		and tmo_tipotra in (2,3)
		and tmo_fechreg < v_fecsigvcto
		and tmo_fechreg >= v_fecult_dev;
		
		return nvl(v_tmo_fechcon,v_fecult_dev);
	end if
	
	if p_tipoacr = 5 then
		if nvl(v_fecult_dev, V_D_FECINIPER) >= V_D_FECINIPER then
			let V_D_FECINIPER = nvl(v_fecult_dev, V_D_FECINIPER);
		end if
		return V_D_FECINIPER;
	end if
	
    return V_D_FECINIPER;
end function;


