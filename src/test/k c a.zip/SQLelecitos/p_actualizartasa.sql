


DROP procedure IF EXISTS d_creditos.p_actualizartasa;
create procedure d_creditos.p_actualizartasa(p_codcred integer, p_codmod integer, f_tasa date,	p_newtasa float,p_intydias integer, 
	p_tipotrx integer, p_auditusr varchar(100), p_auditwst varchar(100))

{
	wherrera 20260505 se ajusta para posibles errores de registro
}
        define errno integer;
        define errmsg char(255);

    define v_feculttrx, v_mtp_fechavig date;
    define tasa,v_mtp_tbase float;
    define spreed float;
    define cont_tasa,v_mtp_intydias integer;
	
	--# si ya existe Actualizar
	LET cont_tasa = 0;
	let v_mtp_tbase = NULL;
	
	if f_tasa is null then
		return;
	end if
	
   	select max(dsb_feculttrx) 
    INTO v_feculttrx
    from pre_desemb
    where dsb_codcred = p_codcred
    and dsb_codmod = p_codmod
   	AND dsb_feculttrx IS NOT null;
	
    delete from pre_tasaspre
    WHERE mtp_codcred = p_codcred
    and mtp_codmod = p_codmod
    AND mtp_fechavig = f_tasa
	AND mtp_tbase <= 0;

	SELECT count(1) 
    INTO cont_tasa
    FROM pre_tasaspre
    WHERE mtp_codcred = p_codcred
    and mtp_codmod = p_codmod
    AND mtp_fechavig = f_tasa;
    
	IF p_tipotrx = 9 THEN
		IF cont_tasa > 0 AND v_feculttrx IS NOT NULL AND v_feculttrx > f_tasa THEN
			raise exception -746, 0, "REPRO: Existen operaciones [" || v_feculttrx || "] posteriores a fecha de reprogramacion, no se puede eliminar, cred: " || p_codcred;
		END IF
		
        delete from pre_tasaspre
        WHERE mtp_codcred = p_codcred
        and mtp_codmod = p_codmod
        AND mtp_fechavig = f_tasa;		
		
		RETURN;
	END if

	IF v_feculttrx IS NOT NULL AND v_feculttrx > f_tasa THEN
		raise exception -746, 0, "REPRO: Existen operaciones [" || v_feculttrx || "] posteriores a fecha de reprogramacion, cred: " || p_codcred;
	END IF 

	IF cont_tasa = 0 THEN
		IF p_newtasa > 0 and p_tipotrx = 3 THEN
	        insert into pre_tasaspre(mtp_codmod,mtp_codcred,mtp_fechavig,mtp_tbase,mtp_intydias, mtp_trxstaau, mtp_auditusr, mtp_auditwst, mtp_auditfho)
	        VALUES (p_codmod,p_codcred,f_tasa,p_newtasa,nvl(p_intydias, 360), 3, p_auditusr, p_auditwst, current);
		END if
	else
        
        UPDATE pre_tasaspre 
        SET mtp_tbase = p_newtasa,
        mtp_intydias = p_intydias,
        mtp_auditusr = p_auditusr,
        mtp_auditfho = current,
        mtp_auditwst = p_auditwst
        WHERE mtp_codcred = p_codcred
        and mtp_codmod = p_codmod
        AND   mtp_fechavig = f_tasa
        and mtp_trxstaau in (1,2,3);		
	END IF

END procedure;
