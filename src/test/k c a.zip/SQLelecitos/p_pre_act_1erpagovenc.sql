

DROP procedure IF EXISTS d_creditos.p_pre_act_1erpagovenc;
create procedure d_creditos.p_pre_act_1erpagovenc(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_tipocuo integer, p_tipotrx integer, p_origenproc integer)
{
wherrera 20260405 se anula las tareas de actualizacion  por sobrecarga en actualizaciones, y se cambia para comunicar cambios
p_origenproc : 2 modifica plan pagos
3: modifica operacion contable
5: modifica operacion contable estado
6: reprogramacion
8: proc contable devenga
10: trigg er pp
}
	define v_cont, v_contmod, C_CUO_ENMODIF, C_STATACRU_PEND integer;
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PRE INT DEFAULT -1;
    DEFINE C_FLAG_EXETRIGGER_PRE_NOEXE INTEGER;
	define v_fecha, v_ult_act date;

	let C_CUO_ENMODIF = 5;
	let C_FLAG_EXETRIGGER_PRE_NOEXE = 1;
	let C_STATACRU_PEND = 1;

	select count(1)
	into v_cont 
	from pre_desemb
	where dsb_codcred = p_codcred
	and dsb_codmod = p_codmod
	and dsb_monpag = C_CUO_ENMODIF;
	
	if p_coddsb > 0 then
		update pre_desemb 
		set dsb_monpag = C_CUO_ENMODIF
		where dsb_codcred = p_codcred
		and dsb_codmod = p_codmod
		and dsb_coddsb = p_coddsb
		and dsb_monpag != C_CUO_ENMODIF;
			
	else
		update pre_desemb 
		set dsb_monpag = C_CUO_ENMODIF
		where dsb_codcred = p_codcred
		and dsb_codmod = p_codmod
		and dsb_monpag != C_CUO_ENMODIF;
	end if

	if v_cont > 0 and p_origenproc = 10 then
		return;		
	end if
	if p_fecha is null then
		let v_fecha = date(current);
		let v_ult_act = f_acr_ult_fec_acr(p_codcred, p_codmod, null, v_fecha, 5);
	
		update pre_accrual
		set acr_statacru = C_STATACRU_PEND 
		where acr_codcred = p_codcred
		and acr_codmod = p_codmod
		and acr_coddsb > 0
		and acr_fecaccru >= v_ult_act;	
	else 
		let v_ult_act = p_fecha;
		
		update pre_accrual
		set acr_statacru = C_STATACRU_PEND 
		where acr_codcred = p_codcred
		and acr_codmod = p_codmod
		and acr_coddsb > 0
		and acr_fecaccru = p_fecha;		
	end if
	
end procedure;


