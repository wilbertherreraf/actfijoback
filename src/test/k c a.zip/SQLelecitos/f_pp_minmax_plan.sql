

DROP function IF EXISTS d_creditos.f_pp_minmax_plan;
create function d_creditos.f_pp_minmax_plan(p_codcred integer, p_codmod integer, p_coddsb integer, p_tipocuo integer)
    returning date, date
    define v_min_fecvencuo, v_max_fecvencuo date;

    let v_max_fecvencuo = null;
    let v_min_fecvencuo = null;
    
    select min(cuo_fecvencuo), max(cuo_fecvencuo)
    into v_min_fecvencuo, v_max_fecvencuo
    from pre_planpagos
    where cuo_codmod = p_codmod
    and cuo_codcred = p_codcred
    and cuo_tipocuo = nvl(p_tipocuo, cuo_tipocuo)
    and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
    and cuo_coddsb > 0;

    return v_min_fecvencuo, v_max_fecvencuo;
end function;


