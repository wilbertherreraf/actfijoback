

DROP procedure IF EXISTS d_creditos.p_generar_renglon;
create procedure d_creditos.p_generar_renglon(p_idtabla integer, p_codcmp integer, p_codcred integer, p_codmod integer,p_coddsb integer, 
	p_usuario varchar(30), p_estacion varchar(50))
{    
          DESCRIPCI: Obtiene los datos de un parametro de la tabla correspondiente
         ---------------------------------------------------------------------------------------------------------------------------------------------------------
          HISTORIAL DE CAMBIOS
         - 
----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  10-07-2024   | 2085127  | Cambio de tipo de variable para generar el Interes Devengado.
---------------------------------------------------------------------------
--| WHERRERA |  15-05-2026   | | se modifica para la generacion preliminar de renglones           
----------------------------------------------------------------------------
		 
 }        
-- variables
  define v_tipoproc,v_nro_comprob,v_nro_comprob_coin,v_cve_tipo_comprob,v_cve_tipo_comprob_coin,v_nro_afectablecoind,v_cta_mov,v_cve_debe_haber varchar(30);
  define v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_estado,v_nroregs,w_delim_pos integer;
  define C_TIPOTRXCOIN_ACT,C_TIPOTRXCOIN_REG,C_TIPOTRXCOIN_RECHAZAR,v_contar,v_contafecpart,v_max_codtpr,v_nro_reng integer;
  define v_fechacont, v_fecha_cont,v_fecha_cont_coin,v_fec_vcto date;
  define v_mnt_dev,v_monto_mo, v_monto_mn,w_prl_monto_mn decimal(20,2);
  define v_valores_glosa,v_glosa,v_glosa_reng lvarchar(500);
  define v_nom_movimiento varchar(200);
  define v_nro_mayor, v_nro_afectable,w_cta_mov_moneda,w_rln_dh,w_prl_nro_afectable, w_prl_nro_mayor varchar(30);
 define v_fechainidev,v_fec31int,v_fecha_vencimiento date;
-- Variables para el manejo de los renglones del comprobante
 define w_cp, w_cp_int,w_cp_gestant,w_cp_gestion,w_cp_uor,w_cp_rfa,w_cp_top VARCHAR(20);
 define w_cp_imp,w_cp_cta,w_cp_cta_int, w_cp_renglon, w_cp_renglon_int, w_nro_renglones,v_nro_reng_cp_cmpb, v_nro_cp_cmpb       INTEGER;      
 define v_nro_claveserie,v_nomcred,w_parametros_glosa,v_rln_codlitcta,v_rln_codlitmnt,w_par_parametro,v_numero_libreta, v_descripcion_libreta VARCHAR(250);
 define v_prp_estado,w_codigo_cliente, v_numero_cuota, v_nro_renglon,v_cantpp INTEGER;
 define v_total_cuota_vencimiento, w_pago_importe_capital,w_interes_devengado, w_desembolsado, w_saldocapital, v_sum_acr_interes,w_prl_monto_mo DECIMAL (20,2);
 define w_intereses_gestion_anterior,v_pago_importe_capital, v_intereses_gestion_anterior, v_intereses_gestion_actual, v_total_saldo DECIMAL (20,2);
 define v_prp_codtpr, w_nro_renglon_aux, x_imp_sigma,W_ESTADO_HABILITADO INTEGER;
 define v_prp_mayor,w_tipo_sigma,w_cta_mov,v_prp_nrocp      VARCHAR(20);
 define W_IMP_PRESUP_PAGO_CUOTA,w_nro_desembolsos, w_nro_dias,v_nrocuota,w_rln_numero,w_cmp_centro INTEGER;
 define C_CODPARM_CP_ACT,C_CODPARM_CP_ANT integer;
 define w_prl_factor_conv_mo_mn     like contbcb@bcbux02:reng_comprob.factor_conv_mo_mn;
define v_glosa_reng_con_param, v_rln_numero, w_rln_partpr_ctamov, w_rln_partpr_glosa, w_par_codpar,w_par_tprcod integer;

  let C_TIPOTRXCOIN_REG = 2;
  let C_TIPOTRXCOIN_RECHAZAR = 9; 
  let C_TIPOTRXCOIN_ACT = 3;

    let W_ESTADO_HABILITADO = 1;
	let C_CODPARM_CP_ACT = 25;
	let C_CODPARM_CP_ANT = 26;
    let w_codigo_cliente=0;
    let w_nro_renglon_aux=0;
    let x_imp_sigma=0;
    let W_IMP_PRESUP_PAGO_CUOTA=4;
    
	select tipoproc,idtabla,codcred, codmod, coddsb, tipocmp,estado,
	nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto,monto_mn, glosa
	into v_tipoproc,v_idtabla,v_codcred, v_codmod, v_coddsb,v_tipocmp,v_estado,
	v_nro_comprob,v_cve_tipo_comprob, v_fecha_cont,v_fec_vcto, v_monto_mn, v_glosa
	from table(p_get_estado_proceso_conta(p_codcmp, nvl(p_idtabla,0), nvl(p_codcred, 0),p_codmod, null,null, null, null)) 
		t(tipoproc,idtabla,codcred, codmod, coddsb,tipocmp,estado,
			nro_comprob,cve_tipo_comprob, fecha_cont,fec_vcto, monto_mn, glosa);
	
	if v_idtabla is null then
		raise exception -746,0,"GENRENG: Registro inexistente ID: '" || p_idtabla  || "' tipo CMPOPER: " || p_codcmp;
	end if
	
	if v_estado != 1 then
		raise exception -746,0,"GENRENG: Estado de Registro invalido ID: '" || p_idtabla  || "' tipo CMPOPER: " || p_codcmp || " estado: " || v_estado;
	end if
	
	if length(trim(nvl(v_nro_comprob, ""))) > 0 then
		raise exception -746,0,"GENRENG: Operacion contable ID: '" || p_idtabla  || "' tipo CMPOPER: " || p_codcmp || " tiene nro comprobante: " || v_nro_comprob;		
	end if
   -- obtenemos el codigo del cliente del credito w_codigo_cliente
	  select pre_codcli 
	  into w_codigo_cliente 
	  from pre_prestamos 
	  where pre_codcred=p_codcred 
   		and pre_codmod=p_codmod; 
  
	let w_cta_mov_moneda = "69"; --moneda por defecto en bolivianos de acuerdo a lo indicado por usuario
	
	select factor 
    into w_prl_factor_conv_mo_mn 
    from contbcb@bcbux02:factor_conv_mn 
    where cod_moneda = w_cta_mov_moneda 
    and fecha_dia = v_fecha_cont;
	
	let w_prl_factor_conv_mo_mn = nvl(w_prl_factor_conv_mo_mn,1);
	
	delete from gen_prcparams
	where prp_codprc = p_idtabla
	and prp_tipoproc = p_codcmp;
	
	let v_nro_renglon = 0;
	
	select par_parametro
	into v_nomcred
	from gen_parametro 
	where par_tprcod = 42 
	and par_codcred = p_codcred 
	and par_codmod = p_codmod;	
	
	let v_nomcred = nvl(v_nomcred,"S/D");
	
	select par_parametro 
	into w_cp_gestion
	from gen_parametro   
	where par_codcred =p_codcred 
	and par_codmod =p_codmod 
	and par_tprcod = C_CODPARM_CP_ACT;

	select par_parametro 
	into w_cp_gestant 
	from gen_parametro   
	where par_codcred =p_codcred 
	and par_codmod =p_codmod 
	and par_tprcod = C_CODPARM_CP_ANT;	
	
     select cmp_centro
     into w_cmp_centro
      from gen_comprobante
      where cmp_codcmp = p_codcmp;  	
	foreach 
		select	rln_numero,	rln_partpr_ctamov, rln_dh,	rln_codlitmnt,  
		rln_partpr_glosa, rln_glosa,par_codpar, rln_codlitcta, par_parametro,par_tprcod
		into v_rln_numero, w_rln_partpr_ctamov, w_rln_dh,	v_rln_codlitmnt,  
		w_rln_partpr_glosa, w_parametros_glosa,w_par_codpar,v_rln_codlitcta, w_cta_mov,w_par_tprcod
		FROM gen_renglon, gen_parametro 
		where rln_partpr_ctamov = par_tprcod 
		and rln_codcmp = p_codcmp
		and par_codcred = p_codcred
		and par_codmod  = p_codmod
		and rln_estado = W_ESTADO_HABILITADO
		order by rln_codcmp, rln_numero

			let v_prp_nrocp = null;		
			let w_cta_mov_moneda = "69"; --moneda por defecto en bolivianos de acuerdo a lo indicado por usuario    
	
			call contbcb@bcbux02:nro_afect_mayor (w_cta_mov, w_cta_mov_moneda, w_cmp_centro) returning w_prl_nro_afectable, w_prl_nro_mayor;
			
			if w_prl_nro_afectable is null then
				raise exception -746,0,"Cta Movimiento " || w_cta_mov || "-" || w_cta_mov_moneda || " inexistente en contbcb.";
			end if
			
			let v_prp_mayor = (select cm.cod_mayor
					from contbcb@bcbux02:cuenta_mayor cm, contbcb@bcbux02:concepto_mayor com 
					where cm.cod_mayor = com.cod_mayor 
					and cm.nro_mayor = w_prl_nro_mayor);
			
			let v_nom_movimiento = null;
			
			select max(cm.nom_movimiento)
			into v_nom_movimiento
			from contbcb@bcbux02:cuenta_movimiento cm,contbcb@bcbux02:cuenta_afectable ca 
			where cm.cod_Movimiento = ca.cod_Movimiento 
			and cm.cod_movimiento = w_cta_mov
			and cm.cve_Estado_Cuenta = 'V' 
			and ca.cve_Estado_Cuenta = 'V' 
			and ca.nro_Centro = 1 
			and ca.cod_Moneda = w_cta_mov_moneda;				

			select count(1)
			into v_contafecpart
			from contbcb@bcbux02:afectable_partida a
			where a.nro_afectable = w_prl_nro_afectable 
			and a.cve_vigente = "V";
			
			let w_prl_monto_mo = 0;
			LET v_glosa_reng = null;
		   if p_codcmp = 8 then -- registro transitorio de garantias
		       	select  numero_desembolso
		       	into w_nro_desembolsos
		       	from pre_registrogarantias
		       	where id= p_idtabla;
		   
				LET v_valores_glosa = "NRODSB=" || w_nro_desembolsos; 
				LET v_valores_glosa = v_valores_glosa || "|NOMCRED=" || v_nomcred;
		   		LET v_glosa_reng = f_reemplazar_parametros_glosa("CALCGLOSA",null,null, null,null,w_parametros_glosa,v_valores_glosa);
				
	   			let w_prl_monto_mo = nvl(v_monto_mn, 0);
		   elif p_codcmp in (1,2) then -- registro de desembolsos EPNES
		        SELECT numero_libreta, descripcion_libreta
		        INTO v_numero_libreta, v_descripcion_libreta
		        from pre_desembolso_detalle pdd 
		        WHERE id = p_idtabla
		   		and pds_codcmp = p_codcmp;
		   
		   		let w_nro_desembolsos = (select count(*) from pre_desemb where dsb_codcred= p_codcred and dsb_codmod=p_codmod);
				LET v_valores_glosa = "NRODSB=" || w_nro_desembolsos; 
				LET v_valores_glosa = v_valores_glosa || "|NOMCRED=" || v_nomcred;
		   		LET v_valores_glosa = v_valores_glosa || "|DESLIB=" || v_descripcion_libreta;
		   		
		   		if length(trim(nvl(v_numero_libreta,""))) > 0 then
		   			LET v_valores_glosa = v_valores_glosa || "|NROLIB=" || v_numero_libreta;
		   		end if
		   		
		   		LET v_valores_glosa = v_valores_glosa || "|CTAMOV=" || w_cta_mov;
		   		
				LET v_glosa_reng = f_reemplazar_parametros_glosa("CALCGLOSA",null,null, null,null,w_parametros_glosa,v_valores_glosa);
		   
		   		let w_prl_monto_mo = nvl(v_monto_mn, 0);
		   		
				if v_rln_numero = 1 then
		    		update pre_desembolso_detalle
		            set glosa_debe = v_glosa_reng
		            where id = p_idtabla
					and pds_codcmp = p_codcmp;
		    	elif v_rln_numero = 2 then
		    		update pre_desembolso_detalle
		            set glosa_haber = v_glosa_reng
		            where id = p_idtabla
					and pds_codcmp = p_codcmp;
		    	end if
		    	
		    elif  p_codcmp=9 then -- registro custodia de garantia
		    	
		    	let v_cantpp = (select count(1) from v_planpagos_dsb v where v.codcred = p_codcred and v.codmod = p_codmod and v.coddsb = v_coddsb);
				let v_nro_claveserie = (SELECT max(gard_claveserie) from pre_garantiad where gard_codmod=p_codmod and gard_codcred=p_codcred and gard_coddsb=v_coddsb);
		    	
		    	LET v_valores_glosa = "CANTPP=" || v_cantpp; 
				LET v_valores_glosa = v_valores_glosa || "|SERIE=" || nvl(v_nro_claveserie,"S/D");
		    	
				LET v_glosa_reng = f_reemplazar_parametros_glosa("CALCGLOSA",null,null, null,null,w_parametros_glosa,v_valores_glosa);
				
				let w_prl_monto_mo = nvl(v_monto_mn, 0);
				
		        if v_rln_numero = 1 then
		            update pre_custodia_garantia
		            set glosa_debe = v_glosa_reng
		            where id = p_idtabla;
		    
		     	elif v_rln_numero = 2 then
		        	update pre_custodia_garantia
		            set glosa_haber = v_glosa_reng
		            where id = p_idtabla;
		        end if				
		   elif  p_codcmp=10 then -- registro retiro de garantia
		   		select cuota
		   		into v_nrocuota
		        from pre_retiro_garantia prg
		        WHERE id = p_idtabla;
		     	
		   		let v_nro_claveserie = (SELECT max(gard_claveserie) from pre_garantiad where gard_codmod=p_codmod and gard_codcred=p_codcred and gard_coddsb=v_coddsb);
		    	LET v_valores_glosa = "NROCUOTA=" || v_nrocuota; 
				LET v_valores_glosa = v_valores_glosa || "|SERIE=" || nvl(v_nro_claveserie,"S/D");
		    	
				LET v_glosa_reng = f_reemplazar_parametros_glosa("CALCGLOSA",null,null, null,null,w_parametros_glosa,v_valores_glosa);		     	
				let w_prl_monto_mo = nvl(v_monto_mn, 0);

		        if v_rln_numero = 1 then
					update pre_retiro_garantia
					set glosa_debe = v_glosa_reng
					where id = p_idtabla;
				elif v_rln_numero = 2 then
					update pre_retiro_garantia
					set glosa_haber = v_glosa_reng
					where id = p_idtabla;
		        end if
			elif p_codcmp = 3 then -- registro contable pago de deuda
			  	select prc_fecha_2, prc_montodeven
			    into v_fecha_vencimiento, v_intereses_gestion_actual
			    from pre_prcconta
			   	where prc_codprc =  p_idtabla;
			
				CALL p_get_datos_devengamiento(p_codcred, p_codmod, v_fecha_vencimiento, v_fecha_vencimiento) 
					returning v_fechainidev, w_nro_desembolsos, w_nro_dias, w_interes_devengado, w_desembolsado, w_saldocapital, v_sum_acr_interes;
				
				LET v_valores_glosa = "DIAS=" || w_nro_dias; 
				LET v_valores_glosa = v_valores_glosa || "|MES=" || f_reemplazar_parametros_glosa("MES_LIT",null,v_fecha_vencimiento, null,null,null,null);
				let v_valores_glosa = v_valores_glosa || "|NRODSB=" || w_nro_desembolsos;
				
				LET v_glosa_reng = f_reemplazar_parametros_glosa("CALCGLOSA",null,null, null,null,w_parametros_glosa,v_valores_glosa);
				let v_intereses_gestion_actual = nvl(v_intereses_gestion_actual, 0);
				
				if v_intereses_gestion_actual > 0 and v_rln_codlitmnt = "INT_DEVENG" then
					let w_prl_monto_mo = nvl(v_intereses_gestion_actual,0);					
				end if
				
				if w_prl_monto_mo > 0 then
					if v_contafecpart > 0 then 
						if w_rln_dh = "D" then
						------------ cps --------------------
							if w_cp_gestion is null then
								raise exception -746,0,"Cuenta " || w_cta_mov || " sin partida presup. registrada en GenParametro";
							end if
							
				           	let v_prp_nrocp = w_cp_gestion;
						end if
					end if
				end if
			elif p_codcmp in (4,5,6,7) then -- registro contable pago de deuda
				-- fase de creacion de los renglones
				select fecha_vencimiento, pago_importe_capital, intereses_gestion_anterior, intereses_gestion_actual,
		    	total_saldo, numero_cuota, nro_claveserie, total_cuota_vencimiento
		    	into v_fecha_vencimiento, v_pago_importe_capital, v_intereses_gestion_anterior, v_intereses_gestion_actual,
		    	v_total_saldo, v_numero_cuota, v_nro_claveserie, v_total_cuota_vencimiento
		    	from pre_pagocuota
	     		where id = p_idtabla;
		    	
				let v_fec31int = mdy(1,1,year(v_fecha_vencimiento)) - 1; 
	    		LET v_valores_glosa = "FECLIT=" || f_reemplazar_parametros_glosa("FEC_LIT",null,v_fecha_vencimiento, null,null,null,null);
				LET v_valores_glosa = v_valores_glosa || "|ANIOVCTO=" || year(v_fec31int);
				LET v_valores_glosa = v_valores_glosa || "|FECVCTOMDY=" || f_reemplazar_parametros_glosa("FEC_SHORT",null,v_fecha_vencimiento, null,null,null,null);
				
	    		if v_pago_importe_capital > 0 and v_rln_codlitmnt = "TOTAL_CUOTA_I_K" then
	    			let w_prl_monto_mo = v_total_cuota_vencimiento; 
	    		elif v_pago_importe_capital > 0 and v_rln_codlitmnt = "CUOTA_K" then
	    			let w_prl_monto_mo = v_pago_importe_capital; 
	    		elif v_intereses_gestion_anterior > 0 and v_rln_codlitmnt = "INT_31DIC_GANT" then
	    			let w_prl_monto_mo = v_intereses_gestion_anterior;
	    		elif v_intereses_gestion_actual> 0 and v_rln_codlitmnt = "INT_FEC_VCTO" then
	    			let w_prl_monto_mo = v_intereses_gestion_actual;
	    		elif v_rln_codlitmnt = "INT_TOTAL" then
	    			let w_prl_monto_mo = v_intereses_gestion_anterior + v_intereses_gestion_actual; 
				end if

	    		LET v_glosa_reng = f_reemplazar_parametros_glosa("CALCGLOSA",null,null, null,null,w_parametros_glosa,v_valores_glosa);					
    			
	    		if w_prl_monto_mo > 0 then
					if w_rln_dh = "H" then
						if v_contafecpart > 0 then
							------------ cps --------------------
							if w_cp_gestion is null then
								raise exception -746,0,"Cuenta " || w_cta_mov || " sin partida presup. registrada en GenParametro";
							end if
						
				           	let v_prp_nrocp = w_cp_gestion;						
							if v_rln_codlitcta = "CTA_RECINT_ACUM" then
				           		let v_prp_nrocp = w_cp_gestant;
				           	end if
						end if
					--------------------------------
					end if
	    		end if -->0
		   	end if -- 4.5.6.7

			let w_cp_renglon = null;
			let w_cp_cta = null;
			
			if v_prp_nrocp is not null then 
				let w_delim_pos = INSTR(v_prp_nrocp, '-');
				IF w_delim_pos > 0 THEN
				  	let w_cp_cta = SUBSTR(v_prp_nrocp, 1, w_delim_pos - 1);
				  	let w_cp_renglon = SUBSTR(v_prp_nrocp, w_delim_pos + 1);
				end if

				select count(1)
			    into v_contar
				from contbcb@bcbux02:reng_cp rcp, contbcb@bcbux02:afectable_partida ap
				where rcp.cod_partida = ap.cod_partida
				and ap.nro_afectable = w_prl_nro_afectable
				and ap.cve_vigente = "V"
				and rcp.gestion = year(v_fecha_cont)
				and rcp.nro_cp = w_cp_cta
				and rcp.nro_reng_cp = w_cp_renglon;
				
				if v_contar = 0 then
					raise exception -746,0,"Afectable con CP " || w_prl_nro_afectable || " sin registro en COIN cta: " || v_prp_nrocp;
				end if		   	
			end if
			
		    let w_prl_monto_mn = w_prl_monto_mo * w_prl_factor_conv_mo_mn;
		    -- inseetr en reng_comprob
		    if w_prl_monto_mo > 0 then
		    	let v_nro_renglon = v_nro_renglon + 1;
				let v_max_codtpr = nvl((select (max (prp_codtpr)) from gen_prcparams where prp_codprc = p_idtabla and prp_tipoproc = p_codcmp), 0) + 1;
				
	    		insert into gen_prcparams(prp_codprc, prp_tipoproc,prp_codtpr,prp_nroreng,prp_codlit, prp_glosa, prp_montomo,prp_montomn,
	    			prp_ctamov,prp_dh,prp_mayor,prp_nroafectable,prp_value,prp_nrocp,prp_estado,prp_auditusr,prp_auditfho,prp_auditwst)
	    		values (p_idtabla, p_codcmp,v_max_codtpr,v_nro_renglon, v_rln_codlitmnt, v_glosa_reng, w_prl_monto_mo, w_prl_monto_mn, 
					w_cta_mov,w_rln_dh,v_prp_mayor,w_prl_nro_afectable, v_nom_movimiento, v_prp_nrocp,2,p_usuario,current,p_estacion);
			end if
    end foreach
	
          
end procedure;


