


DROP procedure IF EXISTS d_creditos.p_cpy_planpagos_auxpp;
create procedure d_creditos.p_cpy_planpagos_auxpp(p_codcred integer, p_codmod integer, p_tiporepro integer, p_codrepro INTEGER, p_coduser varchar(100), p_estacion varchar(100))
{***** ==> LOG <== *****

wherrera 20210922 copia y sobre escritura de datos desde la tabla pre_planpagos a aux_planpagos util en reprogramaciones o pagos anticipados 
wherrera 20260405 se elimina la generarcion de codigo de plan para el backup
}
    define v_cuo_coddsb, v_cuo_codcuo, v_acu_codacu		like aux_planpagos.acu_codacu		;
    define v_acu_codcred    like aux_planpagos.acu_codcred      ;
    define v_acu_codmod     like aux_planpagos.acu_codmod       ;
    define v_acu_numcuo     like aux_planpagos.acu_numcuo       ;
    define v_cuo_fecvencuo, v_acu_fecvencuo  like aux_planpagos.acu_fecvencuo    ;
    define v_cuo_valor, v_acu_valor      like aux_planpagos.acu_valor        ;
	define v_acu_montocuo like aux_planpagos.acu_montocuo;
    define v_cuo_valorpend, v_acu_valorpend  like aux_planpagos.acu_valorpend    ;
    define v_acu_coddsb     like aux_planpagos.acu_coddsb       ;
    define v_codpp_ha, v_cuo_tipocuo integer;
    define v_codacu,C_TIPOTRX_PANTI,C_TIPOOPER_REPRO,C_TIPOCOB_PANTI_CAP,C_TIPOCOB_PANTI_INT integer;
    define v_appfound_t, v_app_t aux_planpagos_t;

	LET C_TIPOTRX_PANTI = 3;
	LET C_TIPOOPER_REPRO = 12;
	LET C_TIPOCOB_PANTI_CAP = 12; 
	LET C_TIPOCOB_PANTI_INT = 22;

	update pre_planpagos
    set cuo_numcuo = null
    where cuo_codmod = p_codmod
	AND cuo_codcred = p_codcred;
	
    let v_app_t = f_init_app_t();
    let v_app_t.acu_tipodsb = p_codrepro;
	let v_app_t.acu_tabtipodsb = p_tiporepro;
     let v_app_t.acu_auditusr = p_coduser;
     let v_app_t.acu_auditfho = current;
     let v_app_t.acu_auditwst = p_estacion;
    
    foreach 
        select cuo_codcuo, cuo_codcred, cuo_codmod, cuo_fecvencuo, 
        cuo_fecinicuo, cuo_fecfincuo, cuo_capital, cuo_interes, cuo_cargos, cuo_valor,
        cuo_valorpend, cuo_coddsb, cuo_tabtipocuo,cuo_tipocuo, cuo_tipoacu,
        cuo_tabmonpag, cuo_monpag, cuo_tabtipotrx, cuo_tipotrx, cuo_tabtrxstaau, cuo_trxstaau,
        cuo_desemb
        into v_app_t.acu_numcuo, v_app_t.acu_codcred, v_app_t.acu_codmod, v_app_t.acu_fecvencuo,
        v_app_t.acu_fecinicuo, v_app_t.acu_fecfincuo, v_app_t.acu_capital, v_app_t.acu_interes, v_app_t.acu_cargos, v_app_t.acu_valor,
        v_app_t.acu_valorpend, v_app_t.acu_coddsb, v_app_t.acu_tabtipocuo,v_app_t.acu_tipocuo, v_app_t.acu_tipoacu,
        v_app_t.acu_tabmonpag, v_app_t.acu_monpag, v_app_t.acu_tabtipotrx, v_app_t.acu_tipotrx, v_app_t.acu_tabtrxstaau, v_app_t.acu_trxstaau,
        v_acu_montocuo
        from pre_planpagos
        where cuo_codmod = p_codmod
        and cuo_codcred = p_codcred
        and cuo_coddsb > 0
        order by cuo_coddsb, cuo_fecvencuo, cuo_tipocuo
        	 let v_app_t.acu_codmodorig = p_codmod;
        	let v_acu_codacu = f_pv_getnextid();
        	
		    INSERT INTO aux_planpagos (acu_codacu, acu_codcred, acu_codmod, acu_codmodorig, acu_numcuo, acu_fecvencuo, 
		    acu_fecinicuo, acu_fecfincuo, acu_capital, acu_interes, acu_cargos, acu_valor, 
		    acu_valorpend, acu_coddsb, acu_tasa, acu_tabtipodsb, acu_tipodsb, 
		    acu_tipocuo, acu_methodcapi, acu_unidplaz, acu_tipoacu, acu_monpag, acu_tipotrx, 
		    acu_trxstaau, acu_auditusr, acu_auditfho, acu_auditwst) 
		    VALUES (v_acu_codacu, v_app_t.acu_codcred, v_app_t.acu_codmod, v_app_t.acu_codmodorig, v_app_t.acu_numcuo, v_app_t.acu_fecvencuo, 
		    v_app_t.acu_fecinicuo, v_app_t.acu_fecfincuo, v_app_t.acu_capital, v_app_t.acu_interes, v_app_t.acu_cargos, v_app_t.acu_valor, 
		    v_app_t.acu_valorpend, v_app_t.acu_coddsb, v_app_t.acu_tasa, v_app_t.acu_tabtipodsb, v_app_t.acu_tipodsb, 
		    v_app_t.acu_tipocuo, v_app_t.acu_methodcapi, v_app_t.acu_unidplaz, v_app_t.acu_tipoacu, v_app_t.acu_monpag, v_app_t.acu_tipotrx, 
		    1, v_app_t.acu_auditusr, v_app_t.acu_auditfho, v_app_t.acu_auditwst);

		    update pre_planpagos
		    set cuo_numcuo = v_acu_codacu
		    where cuo_codcuo = v_app_t.acu_numcuo;
    end foreach
end procedure;


 