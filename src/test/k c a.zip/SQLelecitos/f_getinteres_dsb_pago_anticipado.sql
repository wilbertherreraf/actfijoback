drop function if exists d_creditos.f_getinteres_dsb_pago_anticipado;
create function d_creditos.f_getinteres_dsb_pago_anticipado(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date)
    returning decimal(20,2)

{
    wherrera: 2021.12.08 retorna el interes de un desembolso a una fecha
	
-- DESCRIPCION: Procedimiento para generar pagos anticipados
-- PARAMETROS INGRESO:  p_codcred integer
-- 						p_codmod integer 
--						p_coddsb integer
--						p_fecha date

-- PARAMETROS SALIDA:  Retorna el valor interes a una fecha 

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  06-05-2024   | 1763004  | Adicióe opcion para realizar pagos con DISTRIBUCION LINEAL DE CUOTAS (DLC) O CONTRA LA SIGUIENTE CUOTA (CSC) SOLAMENTE PARA EL FNDR.
----------------------------------------------------------------------------
--| wherrera |  01-04-2026   | 2763221  | Se inhabilita la funcion por ser duplicado de f_getinteres_pry.    
----------------------------------------------------------------------------
}

	raise exception -746,0,"f_getinteres_dsb_pago_anticipado Metodo no implementado";
	
end function;
