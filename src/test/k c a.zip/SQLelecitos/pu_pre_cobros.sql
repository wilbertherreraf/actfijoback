

DROP procedure IF EXISTS d_creditos.pu_pre_cobros;
create procedure d_creditos.pu_pre_cobros(o_cob_codcred		like pre_cobros.cob_codcred		,
o_cob_codmod        like pre_cobros.cob_codmod      ,
o_cob_numtrx        like pre_cobros.cob_numtrx      ,
o_cob_codcob       like pre_cobros.cob_codcob     ,
o_cob_feccontab     like pre_cobros.cob_feccontab   ,
o_cob_fechproc      like pre_cobros.cob_fechproc    ,
o_cob_codtab        like pre_cobros.cob_codtab      ,
o_cob_codigo        like pre_cobros.cob_codigo      ,
o_cob_valor         like pre_cobros.cob_valor       ,
o_cob_codmon        like pre_cobros.cob_codmon      ,
o_cob_numcuo like pre_cobros.cob_numcuo,
o_cob_tabtipotrx    like pre_cobros.cob_tabtipotrx  ,
o_cob_tipotrx       like pre_cobros.cob_tipotrx     ,
o_cob_statreg       like pre_cobros.cob_statreg     ,

n_cob_feccontab     like pre_cobros.cob_feccontab   ,
n_cob_fechproc      like pre_cobros.cob_fechproc    ,
n_cob_codtab        like pre_cobros.cob_codtab      ,
n_cob_codigo        like pre_cobros.cob_codigo      ,
n_cob_valor         like pre_cobros.cob_valor       ,
n_cob_codmon        like pre_cobros.cob_codmon      ,
n_cob_tabtipotrx    like pre_cobros.cob_tabtipotrx  ,
n_cob_tipotrx       like pre_cobros.cob_tipotrx     ,
n_cob_statreg       like pre_cobros.cob_statreg     )

{
WHERRERA    20210922    (trigger upd)se crea el procedimiento que controla modificaciones a transasaciones del servicio de la deuda
}
    define C_CODTAB_CAPINT integer;
    define C_TIPOCOB_PANTI, C_TIPOTRAN_DSB, C_TIPOTRAN_COB integer;
    define C_CODTAB_DSB, C_CODTAB_CAP, C_CODTAB_INT, C_TIPOPRORRA_AMORTIGUAL integer;
    define v_siap, v_dsb_valor, v_mnt_dsb, v_mnt_cobros like pre_cobros.cob_valor;
    define v_tmo_coddsb, v_tmo_tipotra, v_tmo_tipocob integer;
    define v_tmo_auditusr, v_tmo_auditwst varchar(200);
    DEFINE GLOBAL G_FLAG_EXETRIGGER_COB INT DEFAULT -1;
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    define C_CODDSB_CERO, C_FLAG_EXETRIGGER_PP_NOEXE integer;
            
    let C_TIPOTRAN_COB = 2;
    LET C_TIPOTRAN_DSB = 1;
    let C_CODTAB_CAPINT = 1720;
    let C_CODTAB_CAP = 1;
    let C_CODTAB_INT = 2;
    let C_CODTAB_DSB = 3;    
    let C_TIPOPRORRA_AMORTIGUAL = 3;
     LET C_TIPOCOB_PANTI = 3;  
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;

    if G_FLAG_EXETRIGGER_COB = C_FLAG_EXETRIGGER_PP_NOEXE then
        LET G_FLAG_EXETRIGGER_COB = -1;
        RETURN;
    end if
    
    LET G_FLAG_EXETRIGGER_COB = -1;
        
    if o_cob_statreg = 9 then
        raise exception -746,0,"Registro suspendido no puede continuar." || o_cob_codcob;
    end if

    select tmo_tipotra, tmo_tipocob, tmo_coddsb, tmo_auditusr, tmo_auditwst
    into v_tmo_tipotra, v_tmo_tipocob, v_tmo_coddsb, v_tmo_auditusr, v_tmo_auditwst
    from pre_tramon
    where tmo_codcred = o_cob_codcred
    and tmo_codmod = o_cob_codmod
    and tmo_numtrx = o_cob_numtrx;
    
    if v_tmo_tipotra is null then
        raise exception -746,0,"No existe definido el tipo de cobro " || o_cob_numtrx;
    end if

    if o_cob_statreg != 9 and n_cob_statreg = 9 then
    -- reversa
        if o_cob_codigo = C_CODTAB_DSB then
            call f_getsumas_dsb_efect(o_cob_codmod, o_cob_codcred, o_cob_numcuo, null, null) returning v_dsb_valor, v_mnt_dsb, v_mnt_cobros;
            
            if v_mnt_cobros > 0 then
                raise exception -746,0,"Desembolso con cobros en el plan de pagos, no puede revertir " || o_cob_numcuo;
            end if

        elif o_cob_codigo in (14, 24) then
                update pre_planpagos
                set cuo_valorpend = cuo_valor,
                cuo_auditwst = v_tmo_auditwst,
                cuo_auditusr = v_tmo_auditusr, 
                cuo_auditfho = current                				
                where cuo_codcuo = o_cob_numcuo
                and cuo_codcred = o_cob_codcred
                and cuo_codmod = o_cob_codmod
                AND cuo_tipocuo = o_cob_codigo
				and cuo_valorpend = 0;
        else
                let G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE;
                
                update pre_planpagos
                set cuo_valorpend = cuo_valor,
                cuo_auditwst = v_tmo_auditwst,
                cuo_auditusr = v_tmo_auditusr, 
                cuo_auditfho = current                
                where cuo_codcuo = o_cob_numcuo
                and cuo_codcred = o_cob_codcred
                and cuo_codmod = o_cob_codmod
				and cuo_valorpend = 0;
                
                let G_FLAG_EXETRIGGER_PP = -1;
        end if
    end if
    
    
end procedure;




