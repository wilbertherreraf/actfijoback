


DROP function IF EXISTS d_creditos.obtiene_interes_devengado;
CREATE function d_creditos.obtiene_interes_devengado(p_tipocmp integer, p_codcred INTEGER, p_codmod INTEGER, p_fecha date, p_cvetipocomprob varchar(1), p_nrocomprob varchar(10))
    RETURNING date, varchar(30),DECIMAL(20,2),varchar(10), varchar(30), lvarchar(500)

{
-- DESCRIPCION: Obtiene el interes acumulado por numero de credito de acuerdo al ultimo pago realizado por la EPNE hasta la fecha actual.
-- PARAMETROS INGRESO: 	p_codcred INTEGER 
--						p_codmod INTEGER
--						p_fecha_interes VARCHAR(20)

-- PARAMETROS SALIDA:  valor_interes DECIMAL
-- AUTOR: acanqui
-- CREACION: 18.06.2024

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| acanqui   |  18-06-2024   | 2005026  | Obtiene el interes acumulado por numero de credito de acuerdo al ultimo pago realizado por la EPNE hasta la fecha actual.
wherrera 20260505 retorna los datos registrados en contbcb de los devengados en el mes para un credito 
----------------------------------------------------------------------------
	call obtiene_interes_devengado(3,43, 18, "2016-08-02",null);
	call obtiene_interes_devengado(5,43, 18, "2016-08-02",null);
	call obtiene_interes_devengado(3,43, 18, "2019-01-20","0945945");
	call obtiene_interes_devengado(5,43, 18, "2019-02-20",null);
2016-08-02
2017-02-02
2017-07-28
}

DEFINE v_result_numeral VARCHAR(50);
DEFINE v_interes_mensual 	decimal(20,2);
define v_glosa lvarchar(500);
define v_fechacont, v_fechaini, v_fecha, v_fec_ult_dev date;
define v_contar,v_contarprc, v_nro_periodo, v_gestion,v_nro_centro integer; 
define v_mnt_dev, w_total_desembolsado, w_total_saldocapital, v_sum_acr_interes decimal(20,2);
define v_cve_tipo_comprob,v_nro_comprob, v_cuenta_movd, v_nro_afectablecoind, v_cuenta_movh, v_nro_afectablecoinh,v_cod_esquema varchar(30);

	let v_mnt_dev = 0;
	let v_nro_periodo = month(p_fecha); 
	let v_gestion = year(p_fecha);
	
	select x.par_parametro,
		(select max(nro_afectable) 
		from contbcb@bcbux02:cuenta_movimiento cm,contbcb@bcbux02:cuenta_afectable ca 
		where cm.cod_Movimiento = ca.cod_Movimiento 
		and cm.cod_movimiento = x.par_parametro
		and cm.cve_Estado_Cuenta = 'V' 
		and ca.cve_Estado_Cuenta = 'V' 
		and ca.nro_Centro = 1 
		and ca.cod_Moneda = "69") 
	into v_cuenta_movd, 
		v_nro_afectablecoind
	FROM gen_renglon, gen_parametro x 
	where rln_partpr_ctamov = x.par_tprcod 
	and rln_codcmp = p_tipocmp
	and rln_estado = 1
	and rln_numero = 1
	and par_codcred = p_codcred
	and par_codmod = p_codmod
	and length(par_parametro) > 2;	

	select x.par_parametro,
		(select max(nro_afectable) 
		from contbcb@bcbux02:cuenta_movimiento cm,contbcb@bcbux02:cuenta_afectable ca 
		where cm.cod_Movimiento = ca.cod_Movimiento 
		and cm.cod_movimiento = x.par_parametro
		and cm.cve_Estado_Cuenta = 'V' 
		and ca.cve_Estado_Cuenta = 'V' 
		and ca.nro_Centro = 1 
		and ca.cod_Moneda = "69") 
	into v_cuenta_movh, 
		v_nro_afectablecoinh
	FROM gen_renglon, gen_parametro x 
	where rln_partpr_ctamov = x.par_tprcod 
	and rln_codcmp = p_tipocmp
	and rln_estado = 1
	and rln_numero = 2
	and par_codcred = p_codcred
	and par_codmod = p_codmod
	and length(par_parametro) > 2;	
	
	let v_glosa = null;
	if p_nrocomprob is null and v_nro_afectablecoind is not null and v_nro_afectablecoinh is not null then
		foreach
			select c.nro_comprob, c.cve_tipo_comprob, c.nro_centro, mdy(c.nro_periodo, c.nro_dia, c.gestion),c.cod_esquema,c.glosa_comprob
			into v_nro_comprob, v_cve_tipo_comprob,v_nro_centro, v_fechacont,v_cod_esquema, v_glosa
			from contbcb@bcbux02:comprobante c 
			where c.nro_centro = 1 
			and c.gestion = v_gestion
			and c.nro_periodo = v_nro_periodo
			and c.cve_estado_comprob = "A"
			and c.cve_tipo_comprob in ("G","S")
			and exists (
				select 1
				from contbcb@bcbux02:reng_comprob r
				where r.nro_comprob = c.nro_comprob 
				and r.nro_centro = 1
				and r.cve_tipo_comprob = c.cve_tipo_comprob
				and r.nro_afectable = v_nro_afectablecoind
				and r.cve_debe_haber = "D"
				and r.nro_reng = 1
			)
			and exists (select 1
				from contbcb@bcbux02:reng_comprob r0
				where c.nro_comprob = r0.nro_comprob 
				and c.nro_centro = r0.nro_centro
				and c.cve_tipo_comprob = r0.cve_tipo_comprob
				and r0.nro_afectable = v_nro_afectablecoinh
				and r0.cve_debe_haber = "H")
			order by c.nro_dia 
			
				select sum(r.monto_mn)
				into v_mnt_dev
				from contbcb@bcbux02:reng_comprob r 
				where r.nro_comprob = v_nro_comprob
				and r.cve_tipo_comprob = v_cve_tipo_comprob
				and r.nro_centro = v_nro_centro
				and r.cve_debe_haber = "D"
				and r.nro_reng = 1;
			
				return v_fechacont,v_nro_comprob,v_mnt_dev, v_cve_tipo_comprob,v_cod_esquema, v_glosa with resume;
		end foreach
	else
		if v_nro_afectablecoind is not null then
			foreach
				select c.nro_comprob, c.cve_tipo_comprob, c.nro_centro, mdy(c.nro_periodo, c.nro_dia, c.gestion),c.cod_esquema,c.glosa_comprob
				into v_nro_comprob, v_cve_tipo_comprob,v_nro_centro, v_fechacont,v_cod_esquema, v_glosa
				from contbcb@bcbux02:comprobante c 
				where c.nro_centro = 1 
				and c.gestion = v_gestion
				and c.nro_periodo = v_nro_periodo
				and c.cve_estado_comprob = "A"
				and c.cve_tipo_comprob = nvl(p_cvetipocomprob, c.cve_tipo_comprob)				
				and c.cve_tipo_comprob in ("G","S")
				and c.nro_comprob = p_nrocomprob
				and exists (
					select 1
					from contbcb@bcbux02:reng_comprob r
					where r.nro_comprob = c.nro_comprob 
					and r.nro_centro = 1
					and r.cve_tipo_comprob = c.cve_tipo_comprob
					and r.nro_afectable = v_nro_afectablecoind
					and r.cve_debe_haber = "D"
					and r.nro_reng = 1
				)				
				order by c.nro_dia 
				
						select sum(r.monto_mn)
						into v_mnt_dev
						from contbcb@bcbux02:reng_comprob r 
						where r.nro_comprob = v_nro_comprob
						and r.cve_tipo_comprob = v_cve_tipo_comprob
						and r.nro_centro = v_nro_centro
						and r.cve_debe_haber = "D"
						and r.nro_reng = 1;
					
						return v_fechacont,v_nro_comprob,v_mnt_dev, v_cve_tipo_comprob,v_cod_esquema, v_glosa with resume;
			end foreach
		end if
    end if
END FUNCTION;



