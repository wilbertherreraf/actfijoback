



DROP function IF EXISTS d_creditos.f_pv_fechainiper;
create function d_creditos.f_pv_fechainiper(p_codcred integer, p_codmod integer, p_coddsb integer, p_feciniper date, p_tipocuo integer) 
    returning date
{
wherrera: 2021.12.05    fecha anterior en cronograma
}
    define C_TIPOCUO_INT, v_cont integer;
    define v_pre_fecemi, v_f_tramin_dsb, v_f_tramax_dsb, v_fecfinper date;
    define v_sum_tradsb_valor decimal (18,2);
    
    LET C_TIPOCUO_INT = 2;
	let v_cont = 0;
    
    if p_feciniper is not null then
	    select count(*)
	    into v_cont
	    from v_pp_auxyplanpagos
	    where vpp_codcred = p_codcred
	    and vpp_codmod = p_codmod
	    and vpp_tipocuo in (p_tipocuo,22)
	    and vpp_coddsb = nvl(p_coddsb,vpp_coddsb)
	    and vpp_fecvencuo < p_feciniper;
	end if
	
    if v_cont > 0 then
        select max(vpp_fecvencuo)
        into v_fecfinper
        from v_pp_auxyplanpagos
        where vpp_codcred = p_codcred
        and vpp_codmod = p_codmod
        and vpp_coddsb = nvl(p_coddsb,vpp_coddsb)
        and vpp_tipocuo in (p_tipocuo,22)
        and vpp_fecvencuo < p_feciniper;
        
        return v_fecfinper;        
    ELSE
        let v_f_tramin_dsb = f_dsb_fecmin(p_codmod, p_codcred, p_coddsb);

        if (v_f_tramin_dsb is null) or (v_f_tramin_dsb >= nvl(p_feciniper,v_f_tramin_dsb))then
            select pre_fecemi
            into v_pre_fecemi
            from pre_prestamos
            where pre_codmod = p_codmod
            and pre_codcred = p_codcred;
            
            return v_pre_fecemi;
        else 
            return v_f_tramin_dsb;
        end if
    end if

end FUNCTION;


