

DROP procedure IF EXISTS d_creditos.p_insauxplanpg;
create procedure d_creditos.p_insauxplanpg(p_app_t aux_planpagos_t)
returning integer
    define v_acu_codacu like aux_planpagos.acu_codacu;
    
    let v_acu_codacu = f_pv_getnextid();
    --let v_acu_codacu = f_pp_getnextid();

    INSERT INTO aux_planpagos (acu_codacu, acu_codcred, acu_codmod, acu_codmodorig, acu_numcuo, acu_fecvencuo, 
    acu_fecinicuo, acu_fecfincuo, acu_capital, acu_interes, acu_cargos, acu_valor, 
    acu_valorpend, acu_coddsb, acu_tasa, acu_tabtipodsb, acu_tipodsb, 
    acu_tipocuo, acu_methodcapi, acu_unidplaz, acu_tipoacu, acu_monpag, acu_tipotrx, 
    acu_trxstaau, acu_auditusr, acu_auditfho, acu_auditwst) 
    VALUES (v_acu_codacu, p_app_t.acu_codcred, p_app_t.acu_codmod, p_app_t.acu_codmodorig, p_app_t.acu_numcuo, p_app_t.acu_fecvencuo, 
    p_app_t.acu_fecinicuo, p_app_t.acu_fecfincuo, p_app_t.acu_capital, p_app_t.acu_interes, p_app_t.acu_cargos, p_app_t.acu_valor, 
    p_app_t.acu_valorpend, p_app_t.acu_coddsb, p_app_t.acu_tasa, p_app_t.acu_tabtipodsb,p_app_t.acu_tipodsb, 
    p_app_t.acu_tipocuo, p_app_t.acu_methodcapi, p_app_t.acu_unidplaz, p_app_t.acu_tipoacu, p_app_t.acu_monpag, p_app_t.acu_tipotrx, 
    p_app_t.acu_trxstaau, p_app_t.acu_auditusr, p_app_t.acu_auditfho, p_app_t.acu_auditwst);

    return v_acu_codacu;
end procedure;


