

drop function if exists d_creditos.f_pp_prorrateo;
create function d_creditos.f_pp_prorrateo(p_codcred integer, p_codmod integer, p_coddsb integer, p_codcuo integer, p_fecha date, p_importe decimal(20,2), p_tipoprorra integer, p_tipo_pago char(10), p_capitalresto decimal(20,2))
returning integer, integer, date, integer, decimal(20,2), decimal(20,2)

{
    wherrera 2021.11.01 prorrateo del monto de la operacion entre las amortizaciones de capital restantes
	p_tipoprorra : 1 prorrateo del monto pendiente, 
				   2: prorrateo por saldo, 
				   3: cuotas iguales saldo sobre el nro de cuotas
	
-- PARAMETROS SALIDA:  retorna valores de prorrateo por monto depndiente, por saldo y saldo sobre el numero de cuotas
-- AUTOR: wherrera
-- CREACION: 2021.11.01

----------------------------------------------------------------------------------------------------------------------------------------------------
--|   Autor   |     Fecha     | SDAPO    |  Descripcion
---------------------------------------------------------------------------
--| wherrera  |  2021.11.01   |          | prorrateo del monto de la operacion
----------------------------------------------------------------------------
--| acanqui   |  06-05-2024   | 1763004  | Adició opcion para realizar pagos con DISTRIBUCION LINEAL DE CUOTAS (DLC) O CONTRA LA SIGUIENTE CUOTA (CSC) SOLAMENTE PARA EL FNDR.
---------------------------------------------------------------------------
--| wherrera  |  2026.04.05   |          | prorrateo de un importe entre el resto del plan de pagos
				   
				   begin work;
      call f_pp_prorrateo(6, 17, 6001, 0, "2010-01-01", 10777333.23, 1, "DLC", 0) ;
      commit work;
              select cuo_codcuo, cuo_valor, cuo_valorpend, cuo_fecvencuo, cuo_coddsb, cuo_tipocuo 
              --count(*), nvl(sum(cuo_valor),0)
        from pre_planpagos
        where cuo_codmod = 17
        and cuo_codcred = 6
        and cuo_tipocuo = 1
        and cuo_coddsb = 6001
        and cuo_coddsb > 0
        AND cuo_fecvencuo >= "2010-01-01";
}

	define v_cuo_coddsb  like pre_planpagos.cuo_codcuo;
    define v_cuo_fecvencuo like pre_planpagos.cuo_fecvencuo;
    define v_cuo_siap, v_acu_valorpend, v_acu_valor, v_sum_importe, v_cuo_valor, v_cuo_valorpend  like pre_planpagos.cuo_valor;
    define v_cuo_ult, v_cuo_codcuo, v_cuo_tipocuo, v_cont integer;
    define v_new_unpaid, v_sum_fecvencuo, v_amt_sum_fec, V_MNT_PRG_NEW, V_MNT_PRG_ANT, V_MNT_PRGPEND_ANT like pre_planpagos.cuo_valor;
    define v_mnt_capitalper, v_amt_cuo_pend, v_mnt_sobra, V_MNT_PRG_FECHA,v_controlsuma like pre_planpagos.cuo_valor;
    define v_fechafin, v_fechamin date;
    define p_pcent_in float;
    define c_plus decimal(20,2);
    define C_TIPOCUO_CAP, C_TIPOCUO_INT INTEGER;
    DEFINE C_TIPOPRORRA_AMORTIGUAL, C_TIPOPRORRA_SIAP, C_TIPOPRORRA_VALPEND INTEGER;
   
    define TIPO_PAGO_CSC CHAR(10);
    define TIPO_PAGO_DLC CHAR(10);
    define div_capresto_dias decimal(20,2);
    define credito_fndr INTEGER;
   
    define v_pathlog varchar(250); -- log
    let v_pathlog = 'f_pp_prorrateo.log'; -- log
    SET DEBUG FILE TO v_pathlog; -- log
    
   -- PARAMETRO PARA QUE EL PAGO DEL ANTICIPO SOLO AFECTE A LA SIGUIETE CUOTA UTILIZADO PARA CREDITO FNDR
    	let TIPO_PAGO_CSC='CSC';
   -- PARAMETRO PARA QUE EL PAGO DEL ANTICIPO SOLO AFECTE A LA SIGUIETE CUOTA UTILIZADO PARA CREDITO FNDR
    	let TIPO_PAGO_DLC='DLC';
    	let credito_fndr=43;
   		let v_fechafin = mdy(1,1,3000);
    
        let p_pcent_in = 0.01;
        let c_plus = 1;
        let C_TIPOCUO_CAP = 1;
        let C_TIPOPRORRA_AMORTIGUAL = 3;
        let C_TIPOPRORRA_SIAP = 2;
        let C_TIPOPRORRA_VALPEND = 1;
        
        if p_tipo_pago is not null then
        	let p_tipoprorra = decode(p_tipo_pago, TIPO_PAGO_DLC, 3, 1); 
        end if
        
        if p_coddsb is null then
            let v_fechafin = p_fecha;
        end if
        
        let v_amt_cuo_pend = 0;        
        let v_sum_fecvencuo = 0;
        let v_cuo_ult = 0;
        let V_MNT_PRGPEND_ANT = 0;

        select count(*), nvl(sum(acu_valor),0)
        into v_cuo_ult,v_amt_sum_fec
        from aux_planpagos
        where acu_codmod = p_codmod
        and acu_codcred = p_codcred
        and acu_tipocuo = C_TIPOCUO_CAP
        and acu_coddsb = nvl(p_coddsb, acu_coddsb)
        and acu_coddsb > 0
        AND acu_fecvencuo >= p_fecha;

        if (p_importe > v_amt_sum_fec) then
            raise exception -746,0,"Importe: " || p_importe || " mayor a suma cap. " || v_amt_sum_fec;
        end if;
        
       -- En caso de CSC solo retorna 1, porqure solo tiene que afectar a la siguiente cuuota
		-- Obtiene el valor del monto total a pagar para la siguiente cuota el monto divide el monto total por la cantidad de registros sin pagar
        let v_mnt_capitalper = round(p_importe/ v_cuo_ult, 2);    
       
        let v_cont = 0;
        let v_controlsuma = 0;
        let v_mnt_sobra = 0;

        foreach
            select acu_codacu, acu_valor, acu_valorpend, acu_fecvencuo, acu_coddsb, acu_tipocuo
            into v_cuo_codcuo, v_acu_valor, v_acu_valorpend, v_cuo_fecvencuo, v_cuo_coddsb, v_cuo_tipocuo
	        from aux_planpagos
	        where acu_codmod = p_codmod
	        and acu_codcred = p_codcred
	        and acu_tipocuo = C_TIPOCUO_CAP
	        and acu_coddsb = nvl(p_coddsb, acu_coddsb)
	        and acu_coddsb > 0
	        AND acu_fecvencuo >= p_fecha
            order by acu_coddsb, acu_fecvencuo

            let v_cont = v_cont + 1;
            let v_sum_importe = 0;            
            let v_new_unpaid = 0;
            if v_amt_sum_fec - p_importe > 0 then
                if (v_amt_sum_fec - v_amt_cuo_pend) != 0 then
                    let v_new_unpaid = round(v_acu_valor / (v_amt_sum_fec - v_amt_cuo_pend)  * (v_amt_sum_fec - p_importe) , 2);
                else
                    let v_new_unpaid = v_acu_valor;
                end if
                let v_sum_importe = v_acu_valor - v_new_unpaid;
            else
                let v_new_unpaid = 0;
            end if
			
            if C_TIPOPRORRA_AMORTIGUAL = nvl(p_tipoprorra,1) then
            	let v_sum_importe = v_mnt_capitalper;
			end if
                -- return v_app_t with resume;
                let V_MNT_PRGPEND_ANT = V_MNT_PRGPEND_ANT + v_sum_importe;
            
                IF v_cuo_ult = v_cont then
                    let v_mnt_sobra = p_importe - V_MNT_PRGPEND_ANT;
            		let v_controlsuma = v_controlsuma + (v_sum_importe + v_mnt_sobra);
            		return v_cuo_coddsb, v_cuo_codcuo, v_cuo_fecvencuo, v_cuo_ult, v_acu_valor, (v_sum_importe + v_mnt_sobra) with resume;
                	exit foreach;
                else
                	let v_controlsuma = v_controlsuma + v_sum_importe;
                    return v_cuo_coddsb, v_cuo_codcuo, v_cuo_fecvencuo, v_cont, v_acu_valor, v_sum_importe with resume;
                end if
        end foreach            

		if v_controlsuma != p_importe then
			--raise exception -746,0,"Diferencia del monto prorrateado " || p_importe || " y el importe " || v_controlsuma;
			return -1, 0, null, 0, p_importe, v_controlsuma with resume;
		end if   

end function;



