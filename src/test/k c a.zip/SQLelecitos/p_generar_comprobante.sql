


DROP procedure IF EXISTS d_creditos.p_generar_comprobante;
create procedure d_creditos.p_generar_comprobante (p_codprc integer, p_codcred integer, p_codmod integer, p_fecha_2 date, p_usuario varchar(15), p_estacion varchar(50))

         -- DESCRIPCI: Obtiene los datos de un parametro de la tabla correspondiente
         -- PARAMETROS INGRESO: p_codcmp integer                Codigo de Comprobante
         --                     p_codcred integer               Codigo de credito
         --                     p_codmod integer                Codigo de modulo
         --                     P_fecha_devengado               Fecha especificada por el usuario al que se toma los intereses devengados
         --                     p_usuario varchar(15)           Codigo de usuario
         --                     p_estacion varchar(50)          Estacion de donde viene la solicitud (IP)
         -- PARAMETROS SALIDA: codprc as integer                Codigo de Proceso
         -- AUTOR: HENRY IVAN PANIQUE MIRANDA
         -- DEPENDENCIAS: CONTBCB (comprobante, dia)
         --              CREDITOS (gen_renglon, pre_prcconta) 
         -- CREACI:  30-11-2023
         -- SDAPO: 1520473
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- ----------------------------------------------------------------------------------------------------------------------------------------------------
		--|   Autor   |     Fecha     | SDAPO    |  Descripcion
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|  acanqui  |  27-11-2025   | 2666825  | Ajustes en el procedimiento para obtener el valor de los dias e interes de devengado de acuerdo al requerimiento
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|           |               |          |
		-----------------------------------------------------------------------------------------------------------------------------------------------------
		--|    wherrera       |   20260505            |          | unificacion de procesos para devengados
		-----------------------------------------------------------------------------------------------------------------------------------------------------



      define w_codprc           integer;
      define w_estado_ini_cmp   varchar(1);
      define w_resultado        boolean;
      
      define W_SOURCE_MATRIZ_PARAMETROS   INTEGER;
      define W_SOURCE_DEFAULT             INTEGER;
      define W_SOURCE_MATRIZ_PROCESO      INTEGER;
      define C_PARM_COD_GLOSA             INTEGER;
    
      define w_par_parametro              VARCHAR(255);    
      DEFINE w_parametros_glosa           VARCHAR(255);
  
      DEFINE v_prc_glosa,w_par_glosa lVARCHAR(500);
      define w_start_index                  integer;     
      define w_end_index                    integer; 
      define w_nro_parametro                integer;    
      define w_ok                           boolean;    
     
      define w_tienePagoMes                 boolean;
      define w_tieneDesembolsoEnElMes       boolean;

--  definicion de variables del proceso

     define w_prc_fecha         like pre_prcconta.prc_fecha; 
     define w_prc_codcmp        like pre_prcconta.prc_codcmp; 
     define w_prc_codcred       like pre_prcconta.prc_codcred; 
     define w_prc_codmod        like pre_prcconta.prc_codmod; 
     define w_prc_estado        like pre_prcconta.prc_estado;
    
--   Definicion de Variables de la paramerizacion del comprobante
    
     define w_cmp_desc      like gen_comprobante.cmp_desc;
     define w_cmp_esquema   like gen_comprobante.cmp_esquema;
     define w_cmp_centro    like gen_comprobante.cmp_centro;     
     define w_cmp_tipo      like gen_comprobante.cmp_tipo;     
     define w_cmp_glosa     like gen_comprobante.cmp_glosa;
     define w_cmp_dev_real  like gen_comprobante.cmp_dev_real;     
     define w_cmp_tabestado like gen_comprobante.cmp_tabestado;
     define w_cmp_estado    like gen_comprobante.cmp_estado;

-- Definicion de Variables del header del comprobante

     define w_gestion           like contbcb@bcbux02:comprobante.gestion;
     define w_nro_periodo       like contbcb@bcbux02:comprobante.nro_periodo;
     define w_nro_dia           like contbcb@bcbux02:comprobante.nro_dia;     
     define w_factor_conv_us_m  like contbcb@bcbux02:comprobante.factor_conv_us_mn;
     define w_cod_unidad        like contbcb@bcbux02:comprobante.cod_unidad;
     define w_nro_comprob       like contbcb@bcbux02:comprobante.nro_comprob;
     define w_cve_tipo_comprob  like contbcb@bcbux02:comprobante.cve_tipo_comprob;
     define w_fecha_dia         like contbcb@bcbux02:dia.fecha_dia; 
	define v_prc_montodeven like pre_prcconta.prc_montodeven;
     
-- Variables para el manejo de los renglones del comprobante
     define v_contar, w_nro_renglones     integer;
     define w_rln_numero        like gen_renglon.rln_numero;
     define W_ESTADO_HABILITADO integer;
     define w_fecha_coin,v_fec_ult_dev , v_prc_fecinideven       date;
   
     define w_dif_devengado, v_fechafin date;	
     define w_cantidad_dias_devengado integer;

--  inicializacion de variables

     let w_estado_ini_cmp = "P";     
     let W_ESTADO_HABILITADO = 1;
     let W_SOURCE_MATRIZ_PARAMETROS = 1;
     let W_SOURCE_DEFAULT = 2;
     let W_SOURCE_MATRIZ_PROCESO = 3;     
     let C_PARM_COD_GLOSA = 27; --glosa 1 del comprobante
     
     let w_dif_devengado = 0;
     let w_cantidad_dias_devengado = 0;
       
--  Validar parametros

    if TRIM(p_usuario) IS NULL OR LENGTH(TRIM(p_usuario)) = 0 then
       Raise Exception  -746, 0, "[ERR_PGC_006] - El valor proporcionado para el parametro usuario no es valido (p_usuario).";
    end if   
    if p_codprc is null then
    	raise exception -746,0,"Parametro p_codprc nulo";
    end if
    
    select count(1)
	into v_contar
    from pre_prcconta   
    where prc_codcred = p_codcred
	and prc_codmod = p_codmod
	and prc_codprc = p_codprc
    and prc_estado in (1,2,3);

    if v_contar = 0 then
    	raise exception -746,0,"Registro contable " || p_codprc || " inexistente o rechazado cred:" || p_codcred || " para fecha devengado " || p_fecha_2;
    end if
    
--  iniciar proceso
    select prc_fecha, prc_codcmp, prc_codcred, prc_codmod, prc_estado, prc_fecinideven,prc_montodeven,
    prc_nro_comprob, prc_glosa
	into w_prc_fecha, w_prc_codcmp, w_prc_codcred, w_prc_codmod, w_prc_estado, v_prc_fecinideven,v_prc_montodeven,
	w_nro_comprob, v_prc_glosa
    from pre_prcconta   
    where prc_codcred = p_codcred
	and prc_codmod = p_codmod
	and prc_codprc = p_codprc
	and prc_fecha_2 = p_fecha_2
    and prc_estado in (1,2,3);

	if w_prc_estado = 3 then
		Raise Exception  -746, 0, "Registro contable autorizado cred: " || p_codcred || " para fecha " || p_fecha_2;
	end if
	
	if length(trim(nvl(w_nro_comprob, ""))) > 0 then
		raise exception -746,0, "Registro contable con numero comprobante " || w_nro_comprob || " para fecha dev:" || p_fecha_2;
	end if
	
	if nvl(v_prc_montodeven, 0) <= 0 then
		raise exception -746,0,"Monto devengado en registro contable debe ser mayor a cero, cod: " || p_codprc;
	end if
	
	if v_prc_fecinideven is null then
		raise exception -746,0,"Fecha inicio devengado nulo";
	end if	
	if v_prc_fecinideven >= p_fecha_2 then
		raise exception -746,0,"Fecha inicio devengado " || v_prc_fecinideven || " mayor o igual a la fecha devengado " || p_fecha_2;
	end if
	
    call p_set_params_proceso_conta ("DEV", p_codprc, p_codcred, p_codmod, null, p_fecha_2, null,p_usuario, p_estacion);
	
 -- obtener datos del proceso
    if w_prc_codcmp is null or w_prc_codcmp <=0 then
       Raise Exception -746, 0, "[ERR_PGC_001] - El valor para el parametro codigo de comprobante no es valido (codcmp).";
    end if   

   select fecha_dia 
     into w_fecha_coin 
     from contbcb@bcbux02:dia   
    where cve_estado_dia = "A";

    if w_prc_codcred is null or w_prc_codcred <=0 then
       Raise Exception  -746, 0, "[ERR_PGC_003] - El valor  para el parametro codigo de credito no es valido (codcred).";
    end if   

    if w_prc_codmod is null or w_prc_codmod <=0 then
       Raise Exception  -746, 0, "[ERR_PGC_004] - El valor  para el parametro modulo del credito no es valido (codmod).";
    end if   
    
    if w_prc_estado is null or w_prc_estado <> 1 then
       Raise Exception  -746, 0, "[ERR_PGC_005] - El estado del proceso no es pendiente (w_prc_estado).";
    end if
    
 -- obtener parametros del comprobante especificado
    call p_get_par_comprobante(w_prc_codcmp) 
    	returning w_cmp_desc, w_cmp_esquema, w_cmp_centro, w_cmp_tipo, w_cmp_glosa, w_cmp_dev_real, w_cmp_tabestado, w_cmp_estado;
 
    if not w_cmp_estado = W_ESTADO_HABILITADO then
       Raise Exception  -746, 0, "[ERR_PGC_007] - El comprobante especificado no esta habilitado. codcmp: " || w_prc_codcmp;
    end if
    
    select count(1)
    into w_nro_renglones
	from gen_renglon 
   	where rln_codcmp = w_prc_codcmp
    and rln_estado = W_ESTADO_HABILITADO;
       
    if w_nro_renglones = 0 then   
       Raise Exception  -746, 0, "[ERR_PGC_008] - El comprobante no tiene renglones parametrizados o con estado habilitado.";
    end if

    -- obtener datos del header del comprobante
    Call p_get_header_comprobante (w_fecha_coin, w_cmp_centro, p_usuario, w_cmp_tipo) 
    	returning w_nro_comprob, w_gestion, w_nro_periodo, w_nro_dia, w_fecha_dia, w_cod_unidad, w_factor_conv_us_m;
           
          -- insertar el comprobante   
    Insert Into contbcb@bcbux02:comprobante (nro_centro, cve_tipo_comprob, nro_comprob, gestion, nro_periodo, nro_dia, fecha_valor, 
                                     factor_conv_us_mn, glosa_comprob, cod_esquema,cve_subesquema, nro_operacion, cve_estado_comprob,
                                     cod_usuario, fecha_hora, estacion, nro_aprobacion, cod_unidad, cve_dev_real) 
                             Values (w_cmp_centro, w_cmp_tipo, w_nro_comprob, w_gestion, w_nro_periodo, w_nro_dia, null,
                                     w_factor_conv_us_m, v_prc_glosa, w_cmp_esquema, null, 0, w_estado_ini_cmp,
                                     p_usuario, current, p_estacion, null, w_cod_unidad, w_cmp_dev_real);
 -- Generar Renglones
    Foreach 
    	select rln_numero 
    	into w_rln_numero 
    	from gen_renglon 
    	where rln_codcmp = w_prc_codcmp 
    	and rln_numero > 0 
    	and rln_estado = w_estado_habilitado
    	
       	call p_generar_renglon(p_codprc, w_prc_codcmp, w_cmp_centro , w_cmp_tipo, w_nro_comprob, w_rln_numero, 
       		w_prc_codcred, w_prc_codmod, w_gestion, w_nro_periodo, w_nro_dia, w_fecha_coin) ;
    End Foreach
     update pre_prcconta
        set prc_nro_centro = w_cmp_centro,  
            prc_cve_tipo_comprob = w_cmp_tipo,
            prc_nro_comprob = w_nro_comprob,
            prc_fecha = w_fecha_coin
      where prc_codprc = p_codprc;

 	call p_init_proceso_conta(1, p_codprc, p_codcred, p_codmod, p_fecha_2, p_usuario, p_estacion);

end procedure;


