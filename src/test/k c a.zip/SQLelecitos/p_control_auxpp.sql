

DROP procedure IF EXISTS d_creditos.p_control_auxpp;
create procedure d_creditos.p_control_auxpp(p_codcred integer, p_codmod integer, p_codmodtmp integer)
{
wherrera    2021.10.06  controla datos del auxiliar antes de ser copiado a plan pagos, control por desembolso

}
    define v_acu_coddsb, v_acu_tipocuo integer;
    define v_sum_valor,v_dsb_valor, v_cuo_valor, v_cuo_valorpend like pre_desemb.dsb_valor;
    define C_TIPOCUO_CAP,C_TIPOCOB_PANTI_CAP integer;
    define V_MNT_DSB_ANT, V_SUM_DBS_UNDSB_ANT, v_sum_dsb_saldo  like pre_desemb.dsb_valor;
    define p_pcent_in float;
    define c_plus, c_minus decimal(20,2);
    
        let p_pcent_in = 0.01;
        let c_plus = 1;    
        let c_minus = -1;
    let C_TIPOCUO_CAP = 1;
    let C_TIPOCOB_PANTI_CAP = 12;
    let v_sum_valor = 0;
    let v_dsb_valor = 0;

    foreach
        select dsb_coddsb, dsb_valor
        into v_acu_coddsb, v_dsb_valor
        from pre_desemb
        where dsb_codmod = p_codmod
        and dsb_codcred = p_codcred
		order by dsb_coddsb
		
		    select nvl(sum(acu_valor), 0)
		    into v_cuo_valor
		    from aux_planpagos
		    where acu_codcred = p_codcred
		    and acu_codmod = p_codmod
		    and acu_tipocuo in (C_TIPOCUO_CAP,C_TIPOCOB_PANTI_CAP)
		    and acu_coddsb = v_acu_coddsb
		    and acu_tipodsb > 0;
    
	        if v_dsb_valor > 0 and v_cuo_valor > 0 and abs(v_dsb_valor - v_cuo_valor) > 2 then
	            raise exception -746,0,"Verif PP Auxiliar: Suma plan de pagos(" || v_cuo_valor || ") para DSB : " || v_acu_coddsb || " mayor al desembolsado(" || v_dsb_valor || ") revise los datos." ;
	        end if            
    end foreach
    
end procedure;



