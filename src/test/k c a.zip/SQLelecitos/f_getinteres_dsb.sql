

DROP function IF EXISTS d_creditos.f_getinteres_dsb;
create function d_creditos.f_getinteres_dsb(p_codcred integer, p_codmod integer, p_coddsb integer, p_feciniper date, p_fecha date, p_fecfinper date, p_tipocalc integer)
    returning date, date, integer, decimal(15,5), decimal(20,2), decimal(20,2), decimal(20,2), decimal(20,2)

{
wherrera: 2021.12.08 retorna el interes de un desembolso a una fecha del saldo programado
wherrera: 2026.04.05 se modifica el retorno de los datos de calculo, se considera si hay pag anticipados y diferidos
p_tipocalc: 2 calculado del pp auxiliar, otro del plan de pagos 


}
    define v_sumcapper, v_siap,v_siap2, v_amtacru like pre_planpagos.cuo_valor;   
    define V_D_FECINIPER, V_D_FECFINPER, v_fecsigper, v_feciniper, v_ult_fec_dev date;
    define C_TIPOCUO_DEVENG_INT, C_TIPOCUO_CAP, C_TIPOCUO_INT integer;
	define v_saldo_dev, v_cuo_valor, v_cuo_valorpend, v_int_dev,v_int_periodo like pre_planpagos.cuo_valor;
	define v_tasabase like pre_tasaspre.mtp_tbase;
   	define v_contar, C_TIPOCOB_PANTI_INT, v_isgracia, v_dias,P_TRAINTYDAYS, P_TRAINTMDAYS,D_DIFFERENCE_IN_DAYS integer;
	define v_acr_interes,v_sum_cap_valor, v_sum_cap_valorpend, v_restp_cap_valor, v_restp_int_valor,v_saldo_dev2 like pre_planpagos.cuo_valor;  
	define V_MNT_DSB_ANT, v_sum_int_valorpend, v_sum_int_valor, v_scap_pa_valor, v_sint_pa_valor like pre_planpagos.cuo_valor;


    let C_TIPOCUO_INT = 2;
    let C_TIPOCUO_CAP = 1;
    let C_TIPOCOB_PANTI_INT = 22;
    let v_isgracia = 0;
    let v_dias = 0;
	let C_TIPOCUO_DEVENG_INT = 28;
	let v_ult_fec_dev = null;
    let V_MNT_DSB_ANT = 0;
    let v_sint_pa_valor = 0;
    let v_contar = 0;
    if p_tipocalc = 2 then
    
    	if p_feciniper is null then
			let v_feciniper = f_pv_fechainiper(p_codcred, p_codmod, p_coddsb, p_fecha, C_TIPOCUO_INT);
    	else
    		let v_feciniper = p_feciniper; 
    	end if
    
    	select count(1)
		into v_contar
	    from v_pp_auxyplanpagos
	    where vpp_codmod = p_codmod
	    and vpp_codcred = p_codcred
	    and vpp_fecvencuo < p_fecha
	    and vpp_fecvencuo >= v_feciniper
	    and vpp_tipocuo = C_TIPOCOB_PANTI_INT
	    and vpp_coddsb = p_coddsb
	    and vpp_valor > 0
	    and vpp_coddsb > 0;
	
    	if v_contar > 0 then
			select MAX(vpp_fecvencuo)
			into v_ult_fec_dev
		    from v_pp_auxyplanpagos
		    where vpp_codmod = p_codmod
		    and vpp_codcred = p_codcred
		    and vpp_fecvencuo < p_fecha
		    and vpp_fecvencuo >= v_feciniper
		    and vpp_tipocuo = C_TIPOCOB_PANTI_INT
		    and vpp_coddsb = p_coddsb
		    and vpp_valor > 0
		    and vpp_coddsb > 0;
    	
			select nvl(sum(vpp_valor), 0)
		    into v_sint_pa_valor
		    from v_pp_auxyplanpagos
		    where vpp_codmod = p_codmod
		    and vpp_codcred = p_codcred
		    and vpp_coddsb = p_coddsb
		    and vpp_tipocuo = C_TIPOCOB_PANTI_INT
		    and vpp_fecvencuo between v_feciniper and v_ult_fec_dev
		    and vpp_fecvencuo > v_feciniper
		    and vpp_fecvencuo < p_fecha;    	
		else
			let v_ult_fec_dev = v_feciniper;
		end if

    else
    	if p_feciniper is null then
			let v_feciniper = f_pp_fechainiper(p_codcred, p_codmod, p_coddsb, p_fecha, C_TIPOCUO_INT);
    	else
    		let v_feciniper = p_feciniper; 
    	end if
    	    
    	select count(1)
		into v_contar
	    from pre_planpagos
	    where cuo_codmod = p_codmod
	    and cuo_codcred = p_codcred
	    and cuo_fecvencuo < p_fecha
	    and cuo_fecvencuo >= v_feciniper
	    and cuo_tipocuo = C_TIPOCOB_PANTI_INT
	    and cuo_coddsb = p_coddsb
	    and cuo_valor > 0
	    and cuo_coddsb > 0;
		
    	if v_contar > 0 then
			select MAX(cuo_fecvencuo)
			into v_ult_fec_dev
		    from pre_planpagos
		    where cuo_codmod = p_codmod
		    and cuo_codcred = p_codcred
		    and cuo_fecvencuo < p_fecha
		    and cuo_fecvencuo >= v_feciniper
		    and cuo_tipocuo = C_TIPOCOB_PANTI_INT
		    and cuo_coddsb = p_coddsb
		    and cuo_valor > 0
		    and cuo_coddsb > 0; 
    	
			select nvl(sum(cuo_valor), 0)
		    into v_sint_pa_valor
		    from pre_planpagos
		    where cuo_codmod = p_codmod
		    and cuo_codcred = p_codcred
		    and cuo_coddsb = p_coddsb
		    and cuo_tipocuo = C_TIPOCOB_PANTI_INT
		    and cuo_fecvencuo between v_feciniper and v_ult_fec_dev
		    and cuo_fecvencuo > v_feciniper
		    and cuo_fecvencuo < p_fecha;     	
		else
			let v_ult_fec_dev = v_feciniper;		
		end if
    end if
		
	let v_saldo_dev = 0;
    if v_feciniper < v_ult_fec_dev then
       	let v_siap = f_acr_saldo_fecha(p_codcred, p_codmod, p_coddsb, v_ult_fec_dev, p_tipocalc);    
		let v_saldo_dev = f_getinteres_pry(p_codcred, p_codmod, p_coddsb, v_siap, v_feciniper, v_ult_fec_dev);
    end if
    
	let v_saldo_dev = v_saldo_dev - v_sint_pa_valor;
	if v_saldo_dev < 0 then
		let v_saldo_dev = 0; 
	end if
	
	let v_siap = f_acr_saldo_fecha(p_codcred, p_codmod, p_coddsb, p_fecha, p_tipocalc);
	
	let v_int_dev = f_getinteres_pry(p_codcred, p_codmod, p_coddsb, v_siap, v_ult_fec_dev, p_fecha);
	
	let v_int_periodo = v_int_dev + v_saldo_dev;

	let v_amtacru = f_getinteres_pry(p_codcred, p_codmod, p_coddsb, v_siap, v_feciniper, p_fecha);
	
	let v_tasabase = f_gettasavigenteprest(p_codcred, p_codmod, p_fecha);
	
	call f_GET_TRA_INT_YR_MTH_BASE(p_codmod , p_codcred ) returning P_TRAINTYDAYS, P_TRAINTMDAYS;
	call f_DAYS_BETWEEN_2_DATES(v_ult_fec_dev, p_fecha, P_TRAINTYDAYS, P_TRAINTMDAYS) returning D_DIFFERENCE_IN_DAYS, P_TRAINTYDAYS;
	
	return v_ult_fec_dev, p_fecha, D_DIFFERENCE_IN_DAYS, v_tasabase, v_siap, v_saldo_dev, v_int_dev, v_int_periodo;    	
end function;



