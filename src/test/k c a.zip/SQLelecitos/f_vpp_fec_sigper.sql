



DROP function IF EXISTS d_creditos.f_vpp_fec_sigper;
create function d_creditos.f_vpp_fec_sigper(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_tipocuo integer)
    returning date
    
    define v_fecfinper date;
    define C_TIPOCOB_DIFCAP,C_TIPOCOB_DIFINT, C_TIPOCUO_INT integer; 
	LET C_TIPOCOB_DIFCAP = 14;
    LET C_TIPOCOB_DIFINT = 24;
	let C_TIPOCUO_INT = 2;
    
    let v_fecfinper = null;
    let p_fecha = nvl(p_fecha, mdy(1,1,1980));
    
    if p_coddsb is null then
        select min(vpp_fecvencuo)
        into v_fecfinper
        from v_pp_auxyplanpagos
        where vpp_codmod = p_codmod
        and vpp_codcred = p_codcred
        and vpp_tipocuo = p_tipocuo
        and vpp_fecvencuo > p_fecha
        and vpp_coddsb > 0;    
    else
        select min(vpp_fecvencuo)
        into v_fecfinper
        from v_pp_auxyplanpagos
        where vpp_codmod = p_codmod
        and vpp_codcred = p_codcred
        and vpp_fecvencuo > p_fecha
        and vpp_tipocuo = p_tipocuo
        and vpp_coddsb = p_coddsb
        and vpp_coddsb > 0;    
    end if

    return v_fecfinper;
end function;


