


DROP function If EXISTS d_creditos.f_acr_ult_fec_proc;
create function d_creditos.f_acr_ult_fec_proc(p_codcred integer, p_codmod integer , p_coddsb integer, p_fecha date)
    returning date
    {
    wherrera retorna la ultima fecha de devengado procesado contablemente a una fecha, se considera que si se proceso en la fecha a evaluar 
    }
    
    define v_prc_fecha_ini, v_prc_fecha_fin, v_acr_fecaccru_ant, v_pge_feccierre, v_pge_fecultrep date;

    let v_prc_fecha_fin = NULL;
    let v_prc_fecha_ini = NULL;
    let p_fecha = nvl(p_fecha, date(current)); 
   
	select min(prc_fecha_2) 
	INTO v_prc_fecha_fin
	from (
		select min(prc_fecha_2) prc_fecha_2
		from pre_prcconta 
		where prc_codcred = p_codcred 
		and prc_codmod = p_codmod
		AND prc_fecha_2 > p_fecha
		and length(trim(nvl(prc_nro_comprob, ""))) > 2
		and prc_nro_centro > 0	
		and prc_estado in (1,2,3)
		union
		select min(fecha_vencimiento)
		from pre_pagocuota
		where codcred = p_codcred
		and codmod = p_codmod
		and coddsb = nvl(p_coddsb, coddsb)
		and fecha_vencimiento > p_fecha
		and length(trim(nvl(nro_comprobante_coin, ""))) > 2
		and estado in (1,2,3)
	);
	
	let v_prc_fecha_fin = nvl(v_prc_fecha_fin, p_fecha + 1);
	
	select max(prc_fecha_2) 
	INTO v_prc_fecha_ini
	from (
		select max(prc_fecha_2) prc_fecha_2
		from pre_prcconta 
		where prc_codcred = p_codcred 
		and prc_codmod = p_codmod
		AND prc_fecha_2 < v_prc_fecha_fin
		and length(trim(nvl(prc_nro_comprob, ""))) > 2
		and prc_nro_centro > 0	
		and prc_estado in (1,2,3)
		union
		select max(fecha_vencimiento)
		from pre_pagocuota
		where codcred = p_codcred
		and codmod = p_codmod
		and coddsb = nvl(p_coddsb, coddsb)
		and fecha_vencimiento < v_prc_fecha_fin
		and length(trim(nvl(nro_comprobante_coin, ""))) > 2
		and estado in (1,2,3)
	);

    return v_prc_fecha_ini;
end function;


