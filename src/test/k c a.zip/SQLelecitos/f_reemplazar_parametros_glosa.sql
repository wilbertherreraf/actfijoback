


DROP function IF EXISTS d_creditos.f_reemplazar_parametros_glosa; --(varchar,integer,date,decimal,varchar,lvarchar,lvarchar);

CREATE function d_creditos.f_reemplazar_parametros_glosa(p_tipoglosa varchar(30), p_prccod integer, p_fecha date,
	p_monto decimal(20,2), p_cadena varchar(235),
	p_glosaareemplazar LVARCHAR(1024), p_cadena_parametros LVARCHAR(1024))
RETURNING LVARCHAR(1024);

		 -- DESCRIPCI: Procedimiento para generar las glosas de las CUENTAS DEBE y HABER
         -- PARAMETROS INGRESO: p_glosaareemplazar LVARCHAR               Cadena de la glos con los parametros que deben ser modificados
         --						p_cadena_parametros LVARCHAR        parametros que se reemplazaran en la cadena
		 --
		 --
         -- PARAMETROS SALIDA: resultado integer                Resultado con la glosa del comprobante
         -- AUTOR: ALVARO CANQUI
         -- DEPENDENCIAS: CREDITOS (pre_prcconta)
         --               CONTBCB (estado_comprob, comprobante) 
         -- CREACI:  06-02-2025
         -- SDAPO: 2344735
         -----------------------------------------------------------------------------------------------------------------------------------------------------------
         -- HISTORIAL DE CAMBIOS
         -- 
 		 ----------------------------------------------------------------------------------------------------------------------------------------------------
		 --|   Autor   |     Fecha     | SDAPO    |  Descripcion
		 ---------------------------------------------------------------------------
		 --|  wherrera         | 20260505               |          | se modifica para reemplazo de variables del formato NOMVAR=VALORVAR  
		 ----------------------------------------------------------------------------

DEFINE w_start_index INTEGER;
DEFINE w_end_index INTEGER;
DEFINE v_dia,w_mes, w_nro_parametro INTEGER;
DEFINE w_par_glosa lVARCHAR(500);
DEFINE w_resultado_glosa LVARCHAR(500);
define w_mes_anio varchar(100);

    DEFINE v_glosa lVARCHAR(500);
    DEFINE v_param VARCHAR(200);
    DEFINE v_valor VARCHAR(200);
    DEFINE v_nombre VARCHAR(100);
    DEFINE v_pos_equal INTEGER;
    DEFINE v_pos_pipe INTEGER;
    DEFINE v_temp VARCHAR(250);
    DEFINE v_resto VARCHAR(250);
    DEFINE v_param_trim VARCHAR(200);
    
LET w_start_index = 1;
LET w_nro_parametro = 1;
LET w_resultado_glosa = p_glosaareemplazar;
let w_mes_anio = "";
let v_dia = null;
let w_mes = null;

if p_tipoglosa = "GRAL" then
	if p_glosaareemplazar is null or length(trim(p_glosaareemplazar)) = 0 then
		return p_cadena_parametros;
	end if
	if p_cadena_parametros is null or length(trim(p_cadena_parametros)) = 0 then
		return p_glosaareemplazar;
	end if
	WHILE w_start_index > 0 
	    LET w_end_index = INSTR(p_cadena_parametros, '|', w_start_index);
	    
	    IF w_end_index > 0 THEN
	        LET w_par_glosa = SUBSTR(p_cadena_parametros, w_start_index, w_end_index - w_start_index);
	        LET w_start_index = w_end_index + 1;
	    ELSE
	        LET w_par_glosa = SUBSTR(p_cadena_parametros, w_start_index);
	        LET w_start_index = 0; -- Finaliza el bucle
	    END IF;
	
	    -- Reemplazar {#P1}, {#P2}, etc.
	    LET w_resultado_glosa = REPLACE(w_resultado_glosa, "{#P" || w_nro_parametro || "}", w_par_glosa);
	    LET w_nro_parametro = w_nro_parametro + 1;
	
	END WHILE;
	
	RETURN w_resultado_glosa;
end if
let w_resultado_glosa = "";

if p_fecha is not null then
	let v_dia = day(p_fecha);
	LET w_mes = MONTH(p_fecha);
	
	CASE w_mes
	    WHEN 1 THEN LET w_mes_anio = 'ENERO';
	    WHEN 2 THEN LET w_mes_anio = 'FEBRERO';
	    WHEN 3 THEN LET w_mes_anio = 'MARZO';
	    WHEN 4 THEN LET w_mes_anio = 'ABRIL';
	    WHEN 5 THEN LET w_mes_anio = 'MAYO';
	    WHEN 6 THEN LET w_mes_anio = 'JUNIO';
	    WHEN 7 THEN LET w_mes_anio = 'JULIO';
	    WHEN 8 THEN LET w_mes_anio = 'AGOSTO';
	    WHEN 9 THEN LET w_mes_anio = 'SEPTIEMBRE';
	    WHEN 10 THEN LET w_mes_anio = 'OCTUBRE';
	    WHEN 11 THEN LET w_mes_anio = 'NOVIEMBRE';
	    WHEN 12 THEN LET w_mes_anio = 'DICIEMBRE';
	END CASE;
end if
---- newwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww
if p_tipoglosa = "FEC_LIT" then
	let v_glosa = v_dia || ' DE ' || w_mes_anio || ' DE ' || year(p_fecha);
elif p_tipoglosa = "MES_LIT" then
	let v_glosa = w_mes_anio;
elif p_tipoglosa = "FEC_SHORT" then
	let v_glosa = COALESCE(TO_CHAR(p_fecha, '%d/%m/%Y'), 'NULL');
end if

	if p_cadena_parametros is null then
		return v_glosa;
	end if
	
	LET v_glosa = p_glosaareemplazar;
	
	LET v_temp = p_cadena_parametros;
	
	-- Agregar un separador al final para facilitar el procesamiento
	IF v_temp IS NOT NULL AND v_temp != '' THEN
	    IF SUBSTR(v_temp, LENGTH(v_temp), 1) != '|' THEN
	        LET v_temp = v_temp || '|';
	    END IF;
	END IF;
	
	WHILE LENGTH(v_temp) > 0 AND v_temp != '|'
	    -- Encontrar el primer '|'
	    LET v_pos_pipe = INSTR(v_temp, '|');
	    IF v_pos_pipe = 0 THEN
	        EXIT WHILE;
	    END IF;
	    -- Extraer el parámetro (sin el '|')
	    LET v_param = SUBSTR(v_temp, 1, v_pos_pipe - 1);
	    LET v_resto = SUBSTR(v_temp, v_pos_pipe + 1);
	    -- Limpiar espacios
	    LET v_param = TRIM(v_param);
	    -- Encontrar el '='
	    LET v_pos_equal = INSTR(v_param, '=');
	    IF v_pos_equal > 0 THEN
	        -- Extraer nombre y valor
	        LET v_nombre = TRIM(SUBSTR(v_param, 1, v_pos_equal - 1));
	        LET v_valor = TRIM(SUBSTR(v_param, v_pos_equal + 1));
	        
	        -- Reemplazar en la glosa (solo si el nombre no está vacío)
	        IF v_nombre IS NOT NULL AND v_nombre != '' THEN
	            LET v_glosa = REPLACE(v_glosa, '{#' || v_nombre || '}', v_valor);
	        END IF;
	    END IF;
	    
	    LET v_temp = v_resto;
	END WHILE;

RETURN v_glosa;
END FUNCTION;



