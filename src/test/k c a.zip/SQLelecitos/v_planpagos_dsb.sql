



DROP view IF EXISTS d_creditos.v_planpagos_dsb;
create view d_creditos.v_planpagos_dsb(codmod, codcred, coddsb, fechaant, fechavencuo, tipotrx, tipotrx_desc, saldo_inicio, amortizacion, amortizacion_saldo,
	interes_ini, saldo_dev,interes_dev,
interes	, interes_saldo	, dias	, tasa	, cuota	, estado_cuota,estado_auto, TRAINTYDAYS, TRAINTMDAYS) as 

	select codmod, codcred, coddsb, fechaant,fechavencuo, tipotrx,
	nvl((select des_descrip from gen_desctabla where des_codtab = 1705 and des_codigo = tipotrx),"OTRO") tipotrx_desc,
	saldo_inicio, amortizacion, amortizacion_saldo, 
	interes_ini, saldo_dev,(saldo_dev + interes_ini) interes_dev,
		interes, interes_saldo, dias, tasa,
		cuota,
		(case 
			when (amortizacion_saldo + interes_saldo) = 0 then
				"CANCELADO"
			else
				"SIN CANCELAR" 
		end) estado_cuota,
		(nvl((select des_descrip from gen_desctabla where des_codtab = 30 and des_codigo = trxstaau),"NN")) estado_auto,
		TRAINTYDAYS, TRAINTMDAYS 
		
	from (
		select codmod, codcred, coddsb, fechavencuo, amortizacion, amortizacion_saldo,
		interes, interes_saldo,
		cuota,
		interes_ini, saldo_dev,
		tipotrx,trxstaau,
			f_gettasavigenteprest(codcred, codmod, fechavencuo - 1) tasa,
			f_acr_saldo_fecha(codcred, codmod, coddsb, fechavencuo, 1) saldo_inicio,
			fechaant, TRAINTYDAYS, TRAINTMDAYS,
			(select diasaccr from table(f_days_between_2_dates(fechaant,fechavencuo,TRAINTYDAYS,TRAINTMDAYS)) t_d(diasaccr, INTYDAYS)) dias
		from (
			select codmod, codcred, coddsb, fechavencuo, amortizacion, amortizacion_saldo,
			interes, interes_saldo,
			cuota,
			interes_ini, saldo_dev,			
			tipotrx,trxstaau,
				(select TRAINTYDAYS from table(f_GET_TRA_INT_YR_MTH_BASE(codmod, codcred))t_d(TRAINTYDAYS, TRAINTMDAYS)) TRAINTYDAYS,
				(select TRAINTMDAYS from table(f_GET_TRA_INT_YR_MTH_BASE(codmod, codcred))t_d(TRAINTYDAYS, TRAINTMDAYS)) TRAINTMDAYS,
				f_acr_ult_fec_acr(codcred, codmod, coddsb, fechavencuo-1, 2) fechaant
	      	from (
				select codmod, codcred, coddsb, fechavencuo, tipotrx,max(trxstaau) trxstaau, sum(amortizacion) amortizacion, sum(amortizacion_saldo)amortizacion_saldo,  
				sum(interes_ini) interes_ini, sum(saldo_dev) saldo_dev, sum(interes) interes, sum(interes_saldo) interes_saldo,
				sum(cuota) cuota
				from (
	                select cuo_codmod codmod, cuo_codcred codcred, cuo_coddsb coddsb, cuo_fecvencuo fechavencuo,cuo_valor amortizacion, cuo_valorpend amortizacion_saldo, 
	                0 interes, 0 interes_saldo,
	                cuo_valor cuota,
	                0 interes_ini, 0 saldo_dev,
	                nvl(cuo_tipotrx, decode(cuo_tipocuo, 1,2,12,3,13,4,14,4,2)) tipotrx, 
	                nvl(cuo_trxstaau,1) trxstaau 
	                from pre_planpagos
	                where cuo_tipocuo in (1,12,13,14,15,16,17)
	                and cuo_coddsb  > 0
	                --and cuo_coddsb = 43001

	                union all 

	                select cuo_codmod , cuo_codcred, cuo_coddsb, cuo_fecvencuo,0 , 0 , 
	                cuo_valor , nvl(cuo_valorpend,0),
	                cuo_valor cuota,
	                nvl(cuo_interes,0), cuo_cargos,
	                nvl(cuo_tipotrx,decode(cuo_tipocuo, 2,2,22,3,23,4,24,4,2)) tipotrx, 
	                nvl(cuo_trxstaau,1)
	                from pre_planpagos
	                where cuo_tipocuo in (2,22,23,24,25,26,27)
	                and cuo_coddsb > 0
	                --and cuo_coddsb = 43001
	                
	                union all 

	                select cuo_codmod , cuo_codcred, cuo_coddsb, cuo_fecvencuo,0 , 0, 
	                0 , 0,
	                cuo_valor*-1 cuota,
	                0, 0,
	                cuo_tipotrx tipotrx, 
	                nvl(cuo_trxstaau,1)
	                from pre_planpagos
	                where cuo_tipotrx = 4
	                and cuo_fecvencuo < cuo_fecfincuo
	                and cuo_coddsb > 0
	                --and cuo_coddsb = 43001	                
	                
	                union all 

	                select cuo_codmod , cuo_codcred, cuo_coddsb, cuo_fecfincuo,0 , decode(cuo_tipocuo, 1,cuo_valor, 0) , 
	                0 , decode(cuo_tipocuo, 2,cuo_valor, 0),
	                cuo_valor cuota,
	                0, cuo_valor,
	                2 tipotrx, 
	                nvl(cuo_trxstaau,1)
	                from pre_planpagos
	                where cuo_tipotrx = 4
	                and cuo_fecvencuo < cuo_fecfincuo
	                and cuo_coddsb > 0
	                --and cuo_coddsb = 43001	                
 				)
				group by codmod, codcred, coddsb, fechavencuo, tipotrx
				order by fechavencuo
			)
	    )            
	)            
	order by codmod, codcred, coddsb, fechavencuo	              
;


