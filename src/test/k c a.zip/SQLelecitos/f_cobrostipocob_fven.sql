



DROP function IF EXISTS d_creditos.f_cobrostipocob_fven;
create function d_creditos.f_cobrostipocob_fven(p_codcred integer, p_codmod integer, p_coddsb integer, p_fechaini date,p_fechafin date, p_cobcodigo integer, p_lista set(integer not null)) 
    returning DECIMAL(20,2)
{
wherrea 2021.11.03 Objetivo: calcula el monto de cobros efectivizados por tipo de transaccion y tipo de fecha
call f_cobrostipocob_fven(12, 17, 12001, "2015-02-04","2015-02-04", 2, null)
select tmo_coddsb, pre_cobros.*
    from pre_tramon, pre_cobros
    where tmo_codmod = cob_codmod
    and tmo_codcred = cob_codcred
    and tmo_numtrx = cob_numtrx
    and cob_statreg = 0
    and cob_codigo = 2
    and tmo_codcred = 12
    and tmo_codmod = 17
    
    

}
    DEFINE v_amtdsb, v_sum_cobro, v_cob_valor like pre_cobros.cob_valor;
    define v_cuo_codcuo like pre_planpagos.cuo_codcuo;
    define v_cuo_coddsb  like pre_planpagos.cuo_coddsb;
    define v_contdsb, v_cob_codigo, v_cob_numcuo integer;
    define v_cuo_fecvencuo, v_cob_fechproc, v_cob_feccontab date;

    let p_fechaini = nvl(p_fechaini, mdy(1,1,1980));
    let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));
   
    let v_sum_cobro = 0;

    select sum(cob_valor)
    into v_sum_cobro
    from pre_tramon, pre_cobros
    where tmo_codmod = cob_codmod
    and tmo_codcred = cob_codcred
    and tmo_numtrx = cob_numtrx
    and cob_statreg = 0
    and cob_codigo = p_cobcodigo
    and tmo_codcred = p_codcred
    and tmo_codmod = p_codmod
    and tmo_coddsb = nvl(p_coddsb, tmo_coddsb)
    and cob_feccontab between p_fechaini and p_fechafin;
    
    return nvl(v_sum_cobro, 0);
end function;



