
DROP procedure if exists d_creditos.pd_pre_cobros;

create procedure d_creditos.pd_pre_cobros(o_cob_codcred		like pre_cobros.cob_codcred		,
    o_cob_codmod        like pre_cobros.cob_codmod      ,
    o_cob_numtrx        like pre_cobros.cob_numtrx      ,
    o_cob_codcob       like pre_cobros.cob_codcob     ,
    o_cob_feccontab     like pre_cobros.cob_feccontab   ,
    o_cob_fechproc      like pre_cobros.cob_fechproc    ,
    o_cob_codtab        like pre_cobros.cob_codtab      ,
    o_cob_codigo        like pre_cobros.cob_codigo      ,
    o_cob_valor         like pre_cobros.cob_valor       ,
    o_cob_codmon        like pre_cobros.cob_codmon      ,
    o_cob_numcuo like pre_cobros.cob_numcuo,
    o_cob_tabtipotrx    like pre_cobros.cob_tabtipotrx  ,
    o_cob_tipotrx       like pre_cobros.cob_tipotrx     ,
    o_cob_statreg       like pre_cobros.cob_statreg     )

    define c_tipocuo_cap integer;
    define c_tipotra_cob, c_tipocob_capint integer;
    define C_CODTAB_CAPINT integer;
    define C_TIPOTRAN_COB, C_TIPOTRAN_DSB integer;
    define C_CODTAB_CAP, C_CODTAB_INT integer;
    DEFINE GLOBAL G_FLAG_EXETRIGGER_COB INT DEFAULT -1;
    define C_CODDSB_CERO, C_FLAG_EXETRIGGER_PP_NOEXE integer;
    --SET DEBUG FILE TO '/opt/aplicaciones/siscred/logs/tracedb.log';            
    --TRACE 'begin trace';
    --TRACE ON;
    
    let c_tipotra_cob = 2;
    let c_tipocuo_cap = 1;
    let c_tipocob_capint = 1;
    let C_TIPOTRAN_COB = 2;
    let C_TIPOTRAN_DSB = 1;
    let C_CODTAB_CAPINT = 1720;
    let C_CODTAB_CAP = 1;
    let C_CODTAB_INT = 2;

    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;

    if G_FLAG_EXETRIGGER_COB = C_FLAG_EXETRIGGER_PP_NOEXE then
        LET G_FLAG_EXETRIGGER_COB = -1;
        RETURN;
    end if
    
    LET G_FLAG_EXETRIGGER_COB = -1;
    
    if o_cob_codigo in (1,2,11,12,13,14,18,21,22,23,24,28) then
            update pre_planpagos
            set cuo_valorpend = cuo_valorpend + o_cob_valor
            where cuo_codmod = o_cob_codmod
            and cuo_codcred = o_cob_codcred
            and cuo_codcuo = o_cob_numcuo
    		AND cuo_tipocuo = o_cob_codigo
    		AND cuo_valor >= (cuo_valorpend + o_cob_valor);
    end if
    


end procedure;

           


