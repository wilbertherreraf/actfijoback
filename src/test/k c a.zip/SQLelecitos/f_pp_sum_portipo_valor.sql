

DROP function IF EXISTS d_creditos.f_pp_sum_portipo_valor;
create function d_creditos.f_pp_sum_portipo_valor(p_codcred integer, p_codmod integer, p_coddsb integer, p_fechaini date, p_fechafin date, p_tipocuo integer)
    returning DECIMAL(20,2)
{
wherrera 20260505 agrupa los tipos de de cuota
1: capital
2: interes
}    
    DEFINE v_mnt_amort,v_sum_cap_valor,v_scap_pa_valor,v_k, v_cuo_valor, v_cuo_valorpend like pre_planpagos.cuo_capital;
	define C_TIPOCUO_CAP,C_TIPOCUO_INT,C_TIPOCOB_PANTI_CAP,C_TIPOCOB_PANTI_INT integer;

    let C_TIPOCUO_CAP = 1;
    let C_TIPOCUO_INT = 2;
	let C_TIPOCOB_PANTI_CAP = 12;
    let C_TIPOCOB_PANTI_INT = 22;
	let v_sum_cap_valor = 0;
	let v_scap_pa_valor = 0;
	let v_mnt_amort = 0;
    let p_fechaini = nvl(p_fechaini, mdy(1,1,1980));
    let p_fechafin = nvl(p_fechafin, mdy(1,1,3000));

	if p_tipocuo = C_TIPOCUO_CAP then
			select nvl(sum(cuo_valor), 0)
		    into v_sum_cap_valor
		    from pre_planpagos
		    where cuo_codmod = p_codmod
		    and cuo_codcred = p_codcred
		    and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
		    and cuo_coddsb > 0
		    and cuo_tipocuo in (C_TIPOCUO_CAP,C_TIPOCOB_PANTI_CAP)
		    and cuo_fecvencuo between p_fechaini and p_fechafin; --feval
	elif p_tipocuo = C_TIPOCUO_INT then
			select nvl(sum(cuo_valor), 0)
		    into v_sum_cap_valor
		    from pre_planpagos
		    where cuo_codmod = p_codmod
		    and cuo_codcred = p_codcred
		    and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
		    and cuo_coddsb > 0
		    and cuo_tipocuo in (C_TIPOCUO_INT,C_TIPOCOB_PANTI_INT)
		    and cuo_fecvencuo between p_fechaini and p_fechafin; --feval
	end if

    return  nvl(v_sum_cap_valor,0);
end function;


