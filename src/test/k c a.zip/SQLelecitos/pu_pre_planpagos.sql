


DROP procedure IF EXISTS d_creditos.pu_pre_planpagos;
create procedure d_creditos.pu_pre_planpagos(o_cuo_codcuo		like pre_planpagos.cuo_codcuo		,
o_cuo_codcred       like pre_planpagos.cuo_codcred      ,
o_cuo_codmod        like pre_planpagos.cuo_codmod       ,
o_cuo_numcuo        like pre_planpagos.cuo_numcuo       ,
o_cuo_fecvencuo     like pre_planpagos.cuo_fecvencuo    ,
o_cuo_valor         like pre_planpagos.cuo_valor        ,
o_cuo_valorpend     like pre_planpagos.cuo_valorpend    ,
o_cuo_monpag        like pre_planpagos.cuo_monpag       ,
o_cuo_coddsb        like pre_planpagos.cuo_coddsb       ,
o_cuo_numtrx        like pre_planpagos.cuo_numtrx       ,
o_cuo_tipocuo       like pre_planpagos.cuo_tipocuo      ,
o_cuo_tipoacu       like pre_planpagos.cuo_tipoacu      ,
o_cuo_tipotrx       like pre_planpagos.cuo_tipotrx,

n_cuo_fecvencuo     like pre_planpagos.cuo_fecvencuo    ,
n_cuo_valor         like pre_planpagos.cuo_valor        ,
n_cuo_valorpend     like pre_planpagos.cuo_valorpend    ,
n_cuo_coddsb        like pre_planpagos.cuo_coddsb       ,
n_cuo_monpag        like pre_planpagos.cuo_monpag       ,
n_cuo_numtrx        like pre_planpagos.cuo_numtrx,
n_cuo_tipoacu       like pre_planpagos.cuo_tipoacu      )

    define  errno    integer;
    define  errmsg   char(255);
    define  numrows  integer;
    define C_CODTAB_CAP, C_CODTAB_INT integer;
    define C_FLAG_EXETRIGGER_PP_NOEXE integer;
    DEFINE GLOBAL G_FLAG_EXETRIGGER_PP INT DEFAULT -1;
    define C_CUO_ENMODIF,C_CODDSB_CERO integer;
    define v_ult_plz date;
    
    let C_CODTAB_CAP = 1;
    let C_CODTAB_INT = 2;
    let C_CUO_ENMODIF = 5;
    LET C_FLAG_EXETRIGGER_PP_NOEXE = 1;
    let C_CODDSB_CERO = 0;

    if G_FLAG_EXETRIGGER_PP = C_FLAG_EXETRIGGER_PP_NOEXE then
        LET G_FLAG_EXETRIGGER_PP = -1;
        RETURN;
    end if
        
    LET G_FLAG_EXETRIGGER_PP = -1;

    if nvl(n_cuo_coddsb, 0) = C_CODDSB_CERO then
    -- modulo cero 
        RETURN;
    end if
	if o_cuo_valor != n_cuo_valor or o_cuo_valorpend != n_cuo_valorpend 
		or o_cuo_tipoacu != n_cuo_tipoacu 
		or o_cuo_monpag != n_cuo_monpag then  
    	CALL p_pre_act_1erpagovenc(o_cuo_codcred, o_cuo_codmod, o_cuo_coddsb, o_cuo_fecvencuo, o_cuo_codcuo, o_cuo_tipotrx, 10);
    end if
	
end procedure;


