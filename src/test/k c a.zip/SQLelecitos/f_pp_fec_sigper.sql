

DROP function IF EXISTS d_creditos.f_pp_fec_sigper;
create function d_creditos.f_pp_fec_sigper(p_codcred integer, p_codmod integer, p_coddsb integer, p_fecha date, p_tipocuo integer)
    returning date
{
wherrera retorna la fecha del siguiente periodo de pago, util para el calculo de interes
se corrige el parametro tipocuo si es nulo se asume el interes
}    
    define v_fecfinper date;
    define C_TIPOCOB_DIFCAP,C_TIPOCOB_DIFINT, C_TIPOCUO_INT integer; 
	LET C_TIPOCOB_DIFCAP = 14;
    LET C_TIPOCOB_DIFINT = 24;
	let C_TIPOCUO_INT = 2;

    select min(cuo_fecvencuo)
    into v_fecfinper
    from pre_planpagos
    where cuo_codmod = p_codmod
    and cuo_codcred = p_codcred
    and cuo_fecvencuo > p_fecha
    and cuo_tipocuo = nvl(p_tipocuo, C_TIPOCUO_INT)
    and cuo_coddsb = nvl(p_coddsb, cuo_coddsb)
    and cuo_coddsb > 0;
     
    return nvl(v_fecfinper, p_fecha);
end function;

