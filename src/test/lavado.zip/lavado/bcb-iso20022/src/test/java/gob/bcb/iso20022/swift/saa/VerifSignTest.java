package gob.bcb.iso20022.swift.saa;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.apache.xml.security.Init;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.transforms.params.XPath2FilterContainer;
import org.apache.xml.security.utils.JavaUtils;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import gob.bcb.iso20022.core.xml.JaxBConversionService;

public class VerifSignTest {
	private static final Logger log = LoggerFactory.getLogger(VerifSignTest.class);

	public static String input = "" + "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
			+ "<Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\" xml:base=\"http://www.acme.com/resources/\">\n"
			+ "  <SignedInfo xml:base=\"subresources/\"><!-- comment inside -->\n"
			+ "    <CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\" />\n"
			+ "    <SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\" />\n"
			+ "    <Reference URI=\"http://www.w3.org/TR/xml-stylesheet\">\n"
			+ "      <DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\" />\n"
			+ "      <DigestValue>60NvZvtdTB+7UnlLp/H24p7h4bs=</DigestValue>\n" + "    </Reference>\n" + "  </SignedInfo>\n" + "  <SignatureValue>\n"
			+ "    fKMmy9GYF2s8rLFrZdVugTOFuWx19ccX7jh5HqFd4vMOY7LWAj52ykjSdvtW3fNY\n"
			+ "    PPYGC4MFL19oPSId5GEsMtFMpGXB3XaCtoKjMCHQsN3+kom8YnGf7Ge1JNRcGty5\n" + "    0UsoP6Asj47+QR7QECT64uoziha4WRDVyXjDrg24W+U=\n"
			+ "  </SignatureValue>\n" + "  <KeyInfo>\n" + "    <KeyName>Lugh</KeyName>\n" + "  </KeyInfo>\n" + "</Signature>\n";

	public static final String expectedResult = "<SignedInfo xmlns=\"http://www.w3.org/2000/09/xmldsig#\" xml:base=\"http://www.acme.com/resources/subresources/\">\n"
			+ "    <CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"></CanonicalizationMethod>\n"
			+ "    <SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"></SignatureMethod>\n"
			+ "    <Reference URI=\"http://www.w3.org/TR/xml-stylesheet\">\n"
			+ "      <DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"></DigestMethod>\n"
			+ "      <DigestValue>60NvZvtdTB+7UnlLp/H24p7h4bs=</DigestValue>\n" + "    </Reference>\n" + "  </SignedInfo>";

	static {
		Init.init();
	}

	@Test
	public void testC14n11Base() {
		try {
			log.debug("======== inicio signValidLAUTestTest======================");
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();

			// documentBuilder.setErrorHandler(new
			// org.apache.xml.security.utils.IgnoreAllErrorHandler());
			byte inputBytes[] = input.getBytes();
			Document doc = builder.parse(new ByteArrayInputStream(inputBytes));
			//Document doc = JaxBConversionService.getDomFromString(input);
//			String signed = JaxBConversionService.getStringFromDom(doc);
//			log.info(signed);
			Canonicalizer c14n = Canonicalizer.getInstance(Canonicalizer.ALGO_ID_C14N11_OMIT_COMMENTS);

			XPathFactory xpf = XPathFactory.newInstance();
			XPath xPath = xpf.newXPath();
			xPath.setNamespaceContext(new DSNamespaceContext());
			ByteArrayOutputStream fos = new ByteArrayOutputStream(4096);
			StreamResult result = new StreamResult(fos);
			
			Node signedInfo = (Node) xPath.evaluate("//SignedInfo[1]", doc, XPathConstants.NODE);
			c14n.canonicalizeSubtree(signedInfo, fos);
			// fos.write(result);

			String s = new String(fos.toByteArray(), "UTF-8");
			log.info(fos.size() + " outtttttt " + s);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	public static void create(String filename, boolean withComments, boolean verbose) throws Exception {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		dbf.setNamespaceAware(true);

		DocumentBuilder db = dbf.newDocumentBuilder();
		String inputDoc = "<Document>\n" + "     <ToBeSigned>\n" + "       <!-- comment -->\n" + "       <Data />\n" + "       <NotToBeSigned>\n"
				+ "         <ReallyToBeSigned>\n" + "           <!-- comment -->\n" + "           <Data />\n" + "         </ReallyToBeSigned>\n"
				+ "       </NotToBeSigned>\n" + "     </ToBeSigned>\n" + "     <ToBeSigned>\n" + "       <Data />\n" + "       <NotToBeSigned>\n"
				+ "         <Data />\n" + "       </NotToBeSigned>\n" + "     </ToBeSigned>\n" + "</Document>";
		Document doc = db.parse(new ByteArrayInputStream(inputDoc.getBytes()));
		XMLSignature sig = new XMLSignature(doc, null, XMLSignature.ALGO_ID_MAC_HMAC_SHA1);

		doc.getDocumentElement().appendChild(sig.getElement());
		doc.getDocumentElement().appendChild(doc.createTextNode("\n"));

		Transforms transforms = new Transforms(doc);

		String filters[][] = { { XPath2FilterContainer.INTERSECT, "//ToBeSigned" }, { XPath2FilterContainer.SUBTRACT, "//NotToBeSigned" },
				{ XPath2FilterContainer.UNION, "//ReallyToBeSigned" } };

		transforms.addTransform(Transforms.TRANSFORM_XPATH2FILTER, XPath2FilterContainer.newInstances(doc, filters));
		if (withComments) {
			transforms.addTransform(Transforms.TRANSFORM_C14N_WITH_COMMENTS);
		}

		sig.addDocument("#xpointer(/)", transforms);

		String secretKey = "secret";

		sig.getKeyInfo().addKeyName("The UTF-8 octets of \"" + secretKey + "\" are used for signing (" + secretKey.length() + " octets)");
		sig.sign(sig.createSecretKey(secretKey.getBytes()));

		FileOutputStream fos = new FileOutputStream(filename);
		Canonicalizer c14n = Canonicalizer.getInstance(Canonicalizer.ALGO_ID_C14N_WITH_COMMENTS);
		c14n.canonicalizeSubtree(doc, fos);
		fos.flush();
//		try {
//			fos.write(full);
//		} finally {
//			fos.close();
//		}

		if (verbose) {
			log.info("-------------------------------------------------------------");
			log.info("Input to the transforms is");
			log.info("-------------------------------------------------------------");
			log.info(new String(sig.getSignedInfo().item(0).getContentsBeforeTransformation().getBytes()));
			log.info("-------------------------------------------------------------");
			log.info("The signed octets (output of the transforms) are ");
			log.info("-------------------------------------------------------------");
			// log.info(new
			// String(sig.getSignedInfo().item(0).getTransformsOutput().getBytes()));
			log.info("-------------------------------------------------------------");
			log.info("The document is ");
			log.info("-------------------------------------------------------------");
			log.info(new String(fos.toString()));
			log.info("-------------------------------------------------------------");
		}

		JavaUtils.writeBytesToFilename("e:/tmp/withComments.html", sig.getSignedInfo().item(0).getHTMLRepresentation().getBytes());
	}

	public static void main(String[] args) throws Exception {
		org.apache.xml.security.Init.init();

		boolean verbose = true;

		create("e:/tmp/withComments.xml", true, verbose);

	}

	public static void firmaTest() throws Exception {

		org.apache.xml.security.Init.init();

		File signatureFile = new File("");
		javax.xml.parsers.DocumentBuilderFactory dbf = javax.xml.parsers.DocumentBuilderFactory.newInstance();

		dbf.setNamespaceAware(true);

		javax.xml.parsers.DocumentBuilder db = dbf.newDocumentBuilder();
		org.w3c.dom.Document doc = db.parse(new FileInputStream(signatureFile));
		String BaseURI = signatureFile.toURI().toURL().toString();

		XPathFactory xpf = XPathFactory.newInstance();
		XPath xpath = xpf.newXPath();

		// xpath.setNamespaceContext(context);

		String expression = "//ds:Signature[1]";
		Element sigElement = (Element) xpath.evaluate(expression, doc, XPathConstants.NODE);

		expression = "//env:Body[1]";
		// context.putPrefix("env", "http://www.w3.org/2001/12/soap-envelope");
		Element bodyElement = (Element) xpath.evaluate(expression, doc, XPathConstants.NODE);
		bodyElement.setIdAttributeNS("http://schemas.xmlsoap.org/soap/security/2000-12", "id", true);

		XMLSignature sig = new XMLSignature(sigElement, BaseURI);
		boolean verify = sig.checkSignatureValue(sig.getKeyInfo().getPublicKey());

		System.out.println("The signature is" + (verify ? " " : " not ") + "valid");

		for (int i = 0; i < sig.getSignedInfo().getSignedContentLength(); i++) {
			boolean thisOneWasSigned = sig.getSignedInfo().getVerificationResult(i);

			if (thisOneWasSigned) {
				System.out.println("--- Signed Content follows ---");
				System.out.println(new String(sig.getSignedInfo().getSignedContentItem(i)));
			}
		}

		System.out.println("");
		System.out.println("Prior transforms");
		System.out.println(new String(sig.getSignedInfo().getReferencedContentBeforeTransformsItem(0).getBytes()));
	}

	public class DSNamespaceContext implements NamespaceContext {

		private Map<String, String> namespaceMap = new HashMap<String, String>();

		public DSNamespaceContext() {
			namespaceMap.put("ds", "http://www.w3.org/2000/09/xmldsig#");
		}

		public DSNamespaceContext(Map<String, String> namespaces) {
			this();
			namespaceMap.putAll(namespaces);
		}

		public String getNamespaceURI(String arg0) {
			return namespaceMap.get(arg0);
		}

		public void putPrefix(String prefix, String namespace) {
			namespaceMap.put(prefix, namespace);
		}

		public String getPrefix(String arg0) {
			for (String key : namespaceMap.keySet()) {
				String value = namespaceMap.get(key);
				if (value.equals(arg0)) {
					return key;
				}
			}
			return null;
		}

		public Iterator<String> getPrefixes(String arg0) {
			return namespaceMap.keySet().iterator();
		}
	}
}
