package gob.bcb.iso20022.excel;

import static gob.bcb.iso20022.excel.enums.FieldTypeEnum.STRING;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.excel.core.data.HeaderData;
import gob.bcb.iso20022.excel.core.data.HeaderDataBuilder;
import gob.bcb.iso20022.excel.core.listener.DataReadListener;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.translate.FormatEngine;

public class ReadExcelTest {
	private final static Logger log = LoggerFactory.getLogger(FormatEngine.class);

	//@Test
	public void genHdrXls() {
		try {
			log.info("inicializando format engine...");
			String nfile = "src/test/resources/xls/mppbas.xlsx";

			HeaderDataBuilder hdrDBuilder = headersXlsMX().nameSheet("mt103_pacs.008").firstRowData(2);

			ExcelFactory excelFactory = ExcelFactory.build().readInstance(nfile, SwfMencampos.class, hdrDBuilder.getHeaderContent(),
					hdrDBuilder.getNameSheet());
			excelFactory.setSheetName("mt103_pacs.008");

			List<SwfMencampos> swfMencampos = new ArrayList<>();
			excelFactory.read(new DataReadListener<SwfMencampos>((users -> {
				users.forEach(u -> {
					swfMencampos.add(u);
				});

			})));
			log.info("datos " + swfMencampos.size());
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}

	@Test
	public void readExpotsXls() {
		try {
			log.info("inicializando format engine...");
			String nfile = "src/test/resources/xls/exportaciones.xlsx";

			HeaderDataBuilder hdrDBuilder = headersXlsMX().nameSheet("BASE").firstRowData(2);

			ExcelFactory excelFactory = ExcelFactory.build().readInstance(nfile, SwfMencampos.class, hdrDBuilder.getHeaderContent(),
					hdrDBuilder.getNameSheet());
			excelFactory.setSheetName("BASE");

			List<SwfMencampos> swfMencampos = new ArrayList<>();
			excelFactory.read(new DataReadListener<SwfMencampos>((users -> {
				users.forEach(u -> {
					swfMencampos.add(u);
				});

			})));
			log.info("datos " + swfMencampos.size());
			swfMencampos.forEach(s -> {
				log.info(s.getMtfNemo() + " " + s.getMtfCodcampo());
			});
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}

	public static HeaderDataBuilder headersXlsMX() {

		HeaderDataBuilder headerDataBuilder = HeaderDataBuilder.instance();
		List<HeaderData> headerDataList = headerDataBuilder//
				.fill("mtfNemo", STRING, 0)//
				.fill("mtfCodcampo", STRING, 1)//
				.fill("mtfSecpadre", STRING, 2)//
				.fill("mtfCondicion", STRING, 3)//
				.fill("mtfExpresion", STRING, 4)//
				.fill("mtfCardinal", STRING, 5)//
				.firstRowData(2)//
				.build();
		return headerDataBuilder;
	}
}
