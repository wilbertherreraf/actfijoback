package gob.bcb.iso20022.rules;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.DocumentHelper;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.simy4.xpath.XmlBuilder;
import com.prowidesoftware.deprecation.DeprecationUtils;
import com.prowidesoftware.deprecation.DeprecationUtils.EnvironmentVariableKey;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field50F;
import com.prowidesoftware.swift.model.field.Field50K;
import com.prowidesoftware.swift.model.field.Field54D;
import com.prowidesoftware.swift.model.field.Field55B;
import com.prowidesoftware.swift.model.field.Field55D;
import com.prowidesoftware.swift.model.mt.AbstractMT;
import com.prowidesoftware.swift.model.mt.mt1xx.MT103;
import com.prowidesoftware.swift.model.mt.mt2xx.MT202;
import com.prowidesoftware.swift.model.mx.MxPacs00800109;
import com.prowidesoftware.swift.model.mx.MxPacs00900109;

import gob.bcb.iso20022.core.xml.ValidarConXsd;
import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.excel.ExcelFactory;
import gob.bcb.iso20022.excel.core.data.HeaderDataBuilder;
import gob.bcb.iso20022.excel.core.listener.DataReadListener;
import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.swift.CampoFormUtils;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.MappingRule;
import gob.bcb.iso20022.swift.MappingTable;
import gob.bcb.iso20022.swift.SplitRje;
import gob.bcb.iso20022.transforms.AmountCurrTransform;
import gob.bcb.iso20022.transforms.FuncDtTransform;
import gob.bcb.iso20022.transforms.GenListRulesTransform;
import gob.bcb.iso20022.transforms.TextSimpleTransform;
import gob.bcb.iso20022.translate.FormatEngine;
import gob.bcb.iso20022.utils.MxDataTypesConversor;
import gob.bcb.iso20022.utils.UtilsFile;

public class EngineMT103Test {
	private final Logger log = LoggerFactory.getLogger(getClass());

//	@Test
	public void executeRulesField202Test() {
		try {
			MappingTable mappingTable = new MappingTable("", FileFormat.MX, FileFormat.MX);

			List<Rule> rules = genRulesfromxls("", ""); // MTsDatos.rulesMt202();
			Map<String, IAction> actionsMap = mapActions();

			for (Rule r : rules) {
				MappingRule mapRule = new MappingRule();
				mapRule.setRule(r);

				IAction iaction = actionsMap.get(r.getOutcome());
				if (iaction == null) {
					throw new RuntimeException("Transformador inexistente " + r.getOutcome());
				}
				mapRule.setActTransform(iaction);
				mappingTable.addMappingRule(mapRule);
			}

			Map<String, Object> factsf = fieldsMtsFacts("src/test/resources/mts/mt9.txt");
			Engine engine0 = new Engine(rules, true);

			MappingRule mapRule0 = new MappingRule();
			mapRule0.putFacts(factsf);
			List<CompiledRule> matchingRules = engine0.executeAllCondicions(null, mapRule0, mapRule0.getMapFacts());

			matchingRules.forEach(r -> {
				log.info("Best " + r.getRule().getId() + "  " + r.getRule().getExpression() + " " + r.getRule().getAction());
			});

			for (MappingRule mapRule : mappingTable.getMappingRuleList()) {
				mapRule.clearFacts();
				mapRule.putFacts(factsf);
				log.info("*** Rule " + mapRule.getRule().getId() + " " + mapRule.getRule().getOutcome() + " " + mapRule.getRule().getAction());
				Engine engine = new Engine(Arrays.asList(mapRule.getRule()), true, mapRule.getMapFacts());
				engine.addAction(mapRule.getActTransform());
				//engine.executeAllActions(mapRule);
			}

			LinkedHashMap<String, Object> xmlProperties = new LinkedHashMap<String, Object>();

			for (MappingRule mapRule : mappingTable.getMappingRuleList()) {
				mapRule.getCampos().forEach(cf -> {
					log.info("RULE::> " + mapRule.getRule().getOutcome() + " :: " + cf.toStringCF() + " " + cf.getCatalogo() + " --> " + cf.getValor());
					if (cf.getValor() != null)
						xmlProperties.put(cf.getCatalogo(), cf.getValor());
				});
			}

			String cad = XmlToMap.xmlFromXPath4J(xmlProperties);

			// MxPacs00800109 mx = MxPacs00800109.parse(cad);
			MxPacs00900109 mx = MxPacs00900109.parse(cad);
			String mxXml = mx.message();

			System.out.println(mxXml);

			ValidarConXsd validarConXsd = new ValidarConXsd();
			List errors = validarConXsd.validate(mxXml, "src/main/resources/xsd/pacs/pacs.009.001.09.xsd"); // pacs.008.001.09
			errors.forEach(s -> {
				log.info("error " + s);
			});

		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

//	@Test
	public void executeRulesMasive() {
		try {
			long start = System.currentTimeMillis();
			String nfile = "src/test/resources/mts/siodex_202.txt";// sioc_202.txt //iacos_202.txt"; //siraladi_202.txt"; //siodex_202.txt";
			String str = UtilsFile.readFileAsString2(nfile);

			String[] rjes = SplitRje.splitSwift(str);
			int i = 1;
			List<Rule> rules = genRulesfromxls("e:/user.xlsx", "mt202m");
			for (String rje : rjes) {
				log.info("\n\n ################### MT ORIGEN [" + i++ + "] ###################  \n \n" + rje);
				MappingTable mappingTable = new MappingTable("", FileFormat.MX, FileFormat.MX);

				Map<String, IAction> actionsMap = mapActions();

				for (Rule r : rules) {
					MappingRule mapRule = new MappingRule();
					mapRule.setRule(r);

					IAction iaction = actionsMap.get(r.getOutcome());
					if (iaction == null) {
						throw new RuntimeException("Transformador inexistente " + r.getFullyQualifiedName()+ " "+ r.getOutcome());
					}
					mapRule.setActTransform(iaction);
					mappingTable.addMappingRule(mapRule);
				}

				Map<String, Object> factsf = fieldsMtsFactsRje(rje);

				for (MappingRule mapRule : mappingTable.getMappingRuleList()) {
					mapRule.putFacts(factsf);
					// log.info("*** Rule " + mapRule.getRule().getId() + " " +
					// mapRule.getRule().getOutcome() + " " + mapRule.getRule().getAction());
					Engine engine = new Engine(Arrays.asList(mapRule.getRule()), true, mapRule.getMapFacts());
					engine.addAction(mapRule.getActTransform());
					//engine.executeAllActions(mapRule);
				}
				String cad = XmlToMap.xmlFromXPath4J(mappingTable.xpathXmlValue());
				// MxPacs00800109 mx = MxPacs00800109.parse(cad);
				MxPacs00900109 mx = MxPacs00900109.parse(cad);
				String mxXml = mx.message();
				log.info("\n ooo00000OOOOOOOO [MT -> MX MAPEADO ] OOOOOOOO00000ooo ");
				log.info("\n" + mxXml);

				ValidarConXsd validarConXsd = new ValidarConXsd();
				List errors = validarConXsd.validate(mxXml, "src/main/resources/xsd/pacs/pacs.009.001.09.xsd"); // pacs.008.001.09
				log.info("\n TIENE ERRORES DE VALIDACION? " + (errors.size() > 0));
				if ((errors.size() > 0)) {
					log.info("\n-------------------------------------------------");
					errors.forEach(s -> {
						log.info("\n Detalle Error: " + s);
					});
					log.info("\n-------------------------------------------------");
				}
				// i++;
//				if (i > 3)
//					break;

			}
			long end = System.currentTimeMillis();
			log.info("Cloning with Apache Commons Lang took " + (end - start) + " milliseconds.");
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	//@Test
	public void executeRulesMasive103() {
		try {
			long start = System.currentTimeMillis();
			
			String nfile = "src/test/resources/mts/sioc_103.txt"; // siodex_103.txt
			String str = UtilsFile.readFileAsString2(nfile);

			DeprecationUtils.setEnv(EnvironmentVariableKey.NODELAY); // , EnvironmentVariableKey.NOLOG for PW
			DeprecationUtils.setEnv(EnvironmentVariableKey.NOLOG);
			DeprecationUtils.setEnv(EnvironmentVariableKey.NOEXCEPTION);

			String[] rjes = SplitRje.splitSwift(str);
			int i = 1;
			List<Rule> rules = genRulesfromxls("e:/user.xlsx", "mt103");
			
			for (String rje : rjes) {
				log.info("\n\n$$$$$$$$$$$$$$$$$$$$$ [" + i++ + "] $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ \n" + rje);
				MappingTable mappingTable = new MappingTable("", FileFormat.MX, FileFormat.MX);

				Map<String, IAction> actionsMap = mapActions();

				for (Rule r : rules) {
					MappingRule mapRule = new MappingRule();
					mapRule.setRule(r);

					IAction iaction = actionsMap.get(r.getOutcome());
					if (iaction == null) {
						throw new RuntimeException("Transformador inexistente " + r.getOutcome());
					}
					mapRule.setActTransform(iaction);
					mappingTable.addMappingRule(mapRule);
				}

				Map<String, Object> factsf = fieldsMtsFactsRje(rje);

				for (MappingRule mapRule : mappingTable.getMappingRuleList()) {
					mapRule.putFacts(factsf);
					// log.info("*** Rule " + mapRule.getRule().getId() + " " +
					// mapRule.getRule().getOutcome() + " " + mapRule.getRule().getAction());
					Engine engine = new Engine(Arrays.asList(mapRule.getRule()), true, mapRule.getMapFacts());
					engine.addAction(mapRule.getActTransform());
					//engine.executeAllActions(mapRule);
				}
				String cad = XmlToMap.xmlFromXPath4J(mappingTable.xpathXmlValue());
				// MxPacs00800109 mx = MxPacs00800109.parse(cad);
				MxPacs00800109 mx = MxPacs00800109.parse(cad);
				String mxXml = mx.message();

				log.info("\n\n" + mxXml);

				ValidarConXsd validarConXsd = new ValidarConXsd();
				List errors = validarConXsd.validate(mxXml, "src/main/resources/xsd/pacs/pacs.008.001.09.xsd"); // pacs.008.001.09
				log.info("\n TIENE ERRORES DE VALIDACION? " + (errors.size() > 0));
				
				errors.forEach(s -> {
					log.info("\n Detalle Error: " + s);
				});

				// i++;
				// if (i > 1)
				// break;

			}
			long end = System.currentTimeMillis();
			log.info("Cloning with Apache Commons Lang took " + (end - start) + " milliseconds.");
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	@Test
	public void executeRulesFactory() {
		try {
			long start = System.currentTimeMillis();
			String nfileRules = "e:/user.xlsx";
			String mt = "103";
			String sheet = "mt202m";
			sheet = "mt103"; //"mt202m";
			Integer firstRowData = 2;
			String pathXsd = "src/main/resources/xsd/pacs/pacs.009.001.09.xsd"; //"src/main/resources/xsd/pacs/pacs.008.001.09.xsd";
			pathXsd = "src/main/resources/xsd/pacs/pacs.008.001.09.xsd";
			
			String nfile = "src/test/resources/mts/siraladi_202.txt"; //"src/test/resources/mts/sioc_103.txt"; // siodex_103.txt
			nfile = "src/test/resources/mts/siodex_103.txt"; // siodex_103.txt
			
			String str = UtilsFile.readFileAsString2(nfile);

			DeprecationUtils.setEnv(EnvironmentVariableKey.NODELAY); // , EnvironmentVariableKey.NOLOG for PW
//			DeprecationUtils.setEnv(EnvironmentVariableKey.NOLOG);
//			DeprecationUtils.setEnv(EnvironmentVariableKey.NOEXCEPTION);

			String[] rjes = SplitRje.splitSwift(str);
			
			FormatEngine formatEngine = FormatEngine.getInstance().configRulesXls(nfileRules, sheet, firstRowData)//
					.readRulesXls(mt)//
					.initEngineRules()//
			// .putFacts(factsf)
			;
			int i = 1;
			for (String rje : rjes) {
				log.info("\n\n ################### MT ORIGEN [" + i++ + "] ###################  \n \n" + rje);				
				Map<String, Object> factsf = fieldsMtsFactsRje(rje);
				
//				String mxXml = formatEngine.translate(factsf, "pacs.008.001.09").toMx();
//				log.info("\n ooo00000OOOOOOOO [MT -> MX MAPEADO ] OOOOOOOO00000ooo ");
//				log.info("\n" + mxXml);
//
//				ValidarConXsd validarConXsd = new ValidarConXsd();
//				List errors = validarConXsd.validate(mxXml, pathXsd); // pacs.008.001.09
//				log.info("\n TIENE ERRORES DE VALIDACION? " + (errors.size() > 0));
//				if ((errors.size() > 0)) {
//					log.info("\n-------------------------------------------------");
//					errors.forEach(s -> {
//						log.info("\n Detalle Error: " + s);
//					});
//					log.info("\n-------------------------------------------------");
//				}
			}
			long end = System.currentTimeMillis();
			log.info("Cloning with Apache Commons Lang took " + (end - start) + " milliseconds.");
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	/*
	 * Max35Text ISODateTime Max15NumericText ActiveCurrencyAndAmount ISODate
	 * Max34Text BICFIIdentifier Max140Text Max70Text ExternalServiceLevel1Code
	 * ActiveOrHistoricCurrencyAndAmount BaseOneRate ChargeBearerType1Code
	 * AnyBICIdentifier AccountIdentification4Choice
	 */
	public static Map<String, IAction> mapActions() {
		TextSimpleTransform fAction = new TextSimpleTransform();
		fAction.addMethod(MxDataTypesConversor.class);

		GenListRulesTransform genListRulesTransform = new GenListRulesTransform();
		genListRulesTransform.addMethod(MxDataTypesConversor.class);

		AmountCurrTransform amtcurr = new AmountCurrTransform();
		amtcurr.addMethod(MxDataTypesConversor.class);
		FuncDtTransform fdates = new FuncDtTransform();
		fdates.addMethod(MxDataTypesConversor.class);

		Map<String, IAction> actionsMap = new HashMap<>();
		actionsMap.put(GenListRulesTransform.name, genListRulesTransform);
		actionsMap.put(fAction.getName(), fAction);
		actionsMap.put(amtcurr.getName(), amtcurr);
		actionsMap.put(fdates.getName(), fdates);

		return actionsMap;
	}

	public static Map<String, Object> fieldsMtsFactsRje(String mtrje) {
		Map<String, Object> facts = new LinkedHashMap<>();
		final AbstractMT source = MT103.parse(mtrje); //MT202.parse(mtrje);

		source.getFields().forEach(f -> {
			facts.put("F" + f.getName().toUpperCase(), f);
		});
		facts.put("sender", source.getSender());
		facts.put("receiver", source.getReceiver());

		return facts;
	}

	public Map<String, Object> fieldsMtsFacts(String nfile) {
		Map<String, Object> facts = new LinkedHashMap<>();
		String mtrje = UtilsFile.readFileAsString2(nfile); // m601.dos
		final AbstractMT source = MT202.parse(mtrje);

		source.getFields().forEach(f -> {
			facts.put("F" + f.getName().toUpperCase(), f);
		});
		facts.put("sender", source.getSender());
		facts.put("receiver", source.getReceiver());

		Field32A f32A = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89").setDate(Calendar.getInstance());
//		facts.put("F32A", f32A);

		Field55D f55D = new Field55D().setAccount("asdf1234").setNameAndAddress("dir y nomvreaaa");
//		facts.put("F55D", f55D);

		Field55B f55B = new Field55B().setAccount("4564adasf").setLocation("location");
//		facts.put("F55B", f55B);

		Field54D f54D = new Field54D().setNameAndAddressLine2("linea NameAndAddressLine2").setNameAndAddressLine3("linea NameAndAddressLine3")
				.setNameAndAddressLine4("linea NameAndAddressLine4");
//		facts.put("F54D", f54D);

		Field50K f50K = new Field50K().setAccount("asdf1234").setNameAndAddress("dir y nomvre")//
				.setNameAndAddressLine2("NameAndAddressLine2 K").setNameAndAddressLine3("NameAndAddressLine3 K");
//		facts.put("F50K", f50K);

		Field50F f50F = new Field50F()//
				.setComponent1("ctaNro FF")//
				.setComponent2("1")//
				.setComponent3("name debtor FF")//
				.setComponent4("2")//
				.setComponent5("location FF")//
				.setComponent6("3")//
				.setComponent7("plaza FF");
//		facts.put("F50F", f50F);

		facts.forEach((c, v) -> {
			if (v instanceof Field) {
				Field f = (Field) v;
				log.info("******>c " + c + " " + f.getValue());
				List<CampoForm> list = CampoFormUtils.objToPropertiesCf(f);
				list.forEach(cff -> {
//				log.info("		cf " + cff.toStringCF());
				});
			}
		});

		return facts;
	}

	public static String xmlFromXPath4J0(LinkedHashMap<String, Object> xmlProperties) {
		try {
			System.out.println("init ...");
			xmlProperties.entrySet().forEach(entry -> {
				System.out.println(entry.getKey() + " 	-> " + entry.getValue());
			});

			org.dom4j.Document document0 = new XmlBuilder().putAll(xmlProperties).build(DocumentHelper.createDocument());
			String cad = xmlToString(document0);
			System.out.println(cad);
			return cad;
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println(e);
			return null;
		}
	}

	public static String xmlToString(org.dom4j.Document xml) throws IOException {
		String lineSeparator = System.lineSeparator();
		OutputFormat format = OutputFormat.createCompactFormat();
		format.setIndentSize(4);
		format.setNewlines(true);
		format.setLineSeparator(lineSeparator);
		format.setSuppressDeclaration(true);
		StringWriter result = new StringWriter();
		XMLWriter writer = new XMLWriter(result, format);
		writer.write(xml);
		return result.toString().replaceFirst(lineSeparator, "");
	}

	public List<Rule> genRulesfromxls(String nfile, String sheet) {

		//HeaderDataBuilder headerDataBuilder = FormatEngine.headersXlsMX().instance(sheet);
		HeaderDataBuilder headerDataBuilder = FormatEngine.headersXlsMX().nameSheet(sheet).firstRowData(2);
//		List<HeaderData> headerDataList = headerDataBuilder//
//				.fill("mtfId", INTEGER, 0)//
//				.fill("mtfCodcampo", STRING, 3)//
//				// .fill("mtfCodmt", STRING )//
//				// .fill("mtfNro", INTEGER, 0)//
//				// .fill("mtfGrpopt", INTEGER )//
//				.fill("mtfNemo", STRING, 1)//
////        		.fill("mtfDescrip",                  STRING,3 )//
//				.fill("mtfReglavalid", STRING)//
////        		.fill("mtfStatus",                   STRING )//
//				.fill("mtfTipocampo", STRING, 11)//
//				.fill("mtfCondicion", STRING, 7)//
//				.fill("mtfExpresion", STRING, 8)//
//				.fill("mtfSecpadre", STRING, 5)//
//				// .fill("mtfBloque", STRING, 11)//
//				.fill("mtfFormato", STRING, 10)//
////        		.fill("mtfReglaswf",                 STRING )//
////        		.fill("mtfDatoadic",                 STRING )//
////        		.fill("mtfDefault",                  STRING )//
////        		.fill("mtfEstado",                   STRING )//
////        		.fill("mtfIndexiso",                 STRING )//
//				// .fill("mtfNivel", INTEGER,2 )//
//				.fill("mtfCardinal", STRING, 9)//
////        		.fill("mtfCambiavalor",              STRING )//
////        		.fill("mtfMinimo",                   STRING )//
////        		.fill("mtfValidacionerror",          STRING )//
////        		.fill("mtfCambiatipousr",            STRING )//
////        		.fill("mtfCardinalmult",             STRING,13 )//
//
////				.fill("mtfSinonimos", STRING, 17)//
////				.fill("mtfConvalornoreq", STRING, 18)//
////				.fill("mtfEsopcional", STRING, 19)//
////				.fill("mtfEsadicional", STRING, 20)//
//				.fill("mtfXmltag", STRING, 15)//
//				.fill("mtfSubaction", STRING, 16)//
//				.fill("mtfSubaction", STRING, 17)//
//				.fill("mtfSubaction", STRING, 18)//
//				.fill("mtfSubaction", STRING, 19)//
//				.fill("mtfSubaction", STRING, 20)//
//				.fill("mtfSubaction", STRING, 21)//
//				.firstRowData(2)//
//				.build();

		List<SwfMencampos> swfMencampos = new ArrayList<>();
		List<Rule> rules = new ArrayList<>();

		ExcelFactory.build().readInstance(nfile, SwfMencampos.class, headerDataBuilder.getHeaderContent(), headerDataBuilder.getNameSheet())//
				.read(new DataReadListener<SwfMencampos>((users -> {
					users.forEach(u -> {
						swfMencampos.add(u);
					});

				})));

		swfMencampos.forEach(u -> {
			Rule r = new Rule(u.getMtfNemo(), u.getMtfCodcampo(), u.getMtfCondicion(), u.getMtfReglavalid(), 1, u.getMtfSecpadre(), u.getMtfDescrip(), u.getMtfExpresion(),
					u.getMtfXmltag());
			int cont = 1;
			for (String sact : u.getMtfSubaction()) {
				if (!StringUtils.isBlank(sact)) {
					r.addAction(String.valueOf(cont++), sact);
				}
			}

			rules.add(r);
		});

		System.out.println("total " + rules.size());
		rules.forEach(r -> {
			System.out.println(r.getId() + " : " + r.getAction() + " " + r.getActions().size());
			r.getActions().forEach(a -> {
				System.out.println("	" + a.getAttribute() + " ==> " + a.getValue());
			});
		});
		return rules;
	}

}
