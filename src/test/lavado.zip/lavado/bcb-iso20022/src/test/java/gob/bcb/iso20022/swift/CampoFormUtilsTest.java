package gob.bcb.iso20022.swift;

import static org.mvel2.templates.TemplateCompiler.compileTemplate;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.mvel2.MVEL;
import org.mvel2.ParserContext;
import org.mvel2.compiler.CompiledExpression;
import org.mvel2.compiler.ExpressionCompiler;
import org.mvel2.integration.VariableResolverFactory;
import org.mvel2.integration.impl.MapVariableResolverFactory;
import org.mvel2.templates.CompiledTemplate;
import org.mvel2.templates.TemplateRuntime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field13C;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field21;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field36;
import com.prowidesoftware.swift.model.field.Field50A;
import com.prowidesoftware.swift.model.field.Field50B;
import com.prowidesoftware.swift.model.field.Field50D;
import com.prowidesoftware.swift.model.field.Field50F;
import com.prowidesoftware.swift.model.field.Field50K;
import com.prowidesoftware.swift.model.field.Field51A;
import com.prowidesoftware.swift.model.field.Field52A;
import com.prowidesoftware.swift.model.field.Field52D;
import com.prowidesoftware.swift.model.field.Field53A;
import com.prowidesoftware.swift.model.field.Field53B;
import com.prowidesoftware.swift.model.field.Field53D;
import com.prowidesoftware.swift.model.field.Field54A;
import com.prowidesoftware.swift.model.field.Field54B;
import com.prowidesoftware.swift.model.field.Field54D;
import com.prowidesoftware.swift.model.field.Field55A;
import com.prowidesoftware.swift.model.field.Field55B;
import com.prowidesoftware.swift.model.field.Field55D;
import com.prowidesoftware.swift.model.field.Field56A;
import com.prowidesoftware.swift.model.field.Field56C;
import com.prowidesoftware.swift.model.field.Field56D;
import com.prowidesoftware.swift.model.field.Field57A;
import com.prowidesoftware.swift.model.field.Field57B;
import com.prowidesoftware.swift.model.field.Field57C;
import com.prowidesoftware.swift.model.field.Field57D;
import com.prowidesoftware.swift.model.field.Field58A;
import com.prowidesoftware.swift.model.field.Field58B;
import com.prowidesoftware.swift.model.field.Field58D;
import com.prowidesoftware.swift.model.field.Field59;
import com.prowidesoftware.swift.model.field.Field70;
import com.prowidesoftware.swift.model.field.Field71A;
import com.prowidesoftware.swift.model.field.Field72;
import com.prowidesoftware.swift.model.field.Narrative;
import com.prowidesoftware.swift.model.field.Narrative.Builder;
import com.prowidesoftware.swift.model.field.NarrativeResolver;
import com.prowidesoftware.swift.model.field.OptionKPartyField;
import com.prowidesoftware.swift.model.field.SwiftParseUtils;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.transforms.GenListRulesTransform;
import gob.bcb.iso20022.utils.UtilsGeneric;

public class CampoFormUtilsTest {
	private static final Logger log = LoggerFactory.getLogger(CampoFormUtilsTest.class);

//	@Test
	public void objectToMapTest() {
		try {
			List<CampoForm> list = CampoFormUtils.classPropertiesCF(CampoForm.class);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
			});

			list = CampoFormUtils.classPropertiesCF(Field50F.class);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
			});

			list = CampoFormUtils.classPropertiesCF(Field50K.class);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
			});

			list = CampoFormUtils.classPropertiesCF(OptionKPartyField.class);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
			});

			list = CampoFormUtils.classPropertiesCF(Field32A.class);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
			});

			list = CampoFormUtils.classPropertiesCF(Instruccion.class);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
			});

			list = CampoFormUtils.classPropertiesCF(GenListRulesTransform.class);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
			});

			list = CampoFormUtils.classPropertiesCF(Field.class);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// @Test
	public void objectToMapFieldsTest() {
		try {
			Arrays.asList(Field13C.class, Field20.class, Field21.class, Field36.class, Field50A.class, Field50B.class, Field50D.class, Field50F.class,
					Field50K.class//
					, Field51A.class, Field52A.class, Field52D.class//
					, Field53A.class, Field53B.class, Field53D.class//
					, Field54A.class, Field54B.class, Field54D.class//
					, Field55A.class, Field55B.class, Field55D.class//
					, Field56A.class, Field56C.class, Field56D.class//
					, Field57A.class, Field57B.class, Field57C.class, Field57D.class//
					, Field58A.class, Field58B.class, Field58D.class//
					, Field59.class, Field57A.class, Field71A.class, Field72.class, Field70.class//
			).stream().forEach(f -> {
				System.out.println("------------------------------");
				List<CampoForm> list = CampoFormUtils.classPropertiesCF(f);
				list.forEach(cf -> {
					System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
				});
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// @Test
	public void mapPropertiesObjTest() {
		Field50F f50F = new Field50F();
		f50F.setComponent1("ctaNro");
		f50F.setComponent2("1");
		f50F.setComponent3("name");
		f50F.setComponent4("2");
		f50F.setComponent5("location");
		f50F.setComponent6("3");
		f50F.setComponent7("plaza");

		Field32A f32A = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89").setDate(Calendar.getInstance());
		Field50K f50K = new Field50K().setAccount("asdf1234").setNameAndAddress("dir y nomvre");
		Field53A f53A = new Field53A().setAccount("asdfa22a").setIdentifierCode("ASD452365");
		Field53D f53D = new Field53D().setAccount("asdfa22a").setNameAndAddress("nom y addressss").setNameAndAddressLine2("name an addd line 2");
		// f53D.setPartyIdentifier("/as65356/segundita");

		CampoForm campoForm = new CampoForm("valor", 1, "rule.getRule().getNamespace()", "rule.getRule().getName()");
		campoForm.setValorObj(f50K);
		// campoForm.getValorObj();
		try {
			List<CampoForm> list = CampoFormUtils.objToPropertiesCF(campoForm);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor() + "  -> " + cf.getValor());
			});

			list = CampoFormUtils.objToPropertiesCF(f50F);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor() + "  -> " + cf.getValor() + " nulo? "
						+ (cf.getValor() == null));
			});

			list = CampoFormUtils.objToPropertiesCF(f50K);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor() + "  -> " + cf.getValor() + " nulo? "
						+ (cf.getValor() == null));
			});

			list = CampoFormUtils.objToPropertiesCF(f32A);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor() + "  -> " + cf.getValor() + " nulo? "
						+ (cf.getValor() == null));
			});

			list = CampoFormUtils.objToPropertiesCF(f53A);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor() + "  -> " + cf.getValor() + " nulo? "
						+ (cf.getValor() == null));
			});

			list = CampoFormUtils.objToPropertiesCF(f53D);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor() + "  -> " + cf.getValor() + " nulo? "
						+ (cf.getValor() == null));
			});

			Field fld50K = new Field50K().setAccount("asdf1234").setNameAndAddress("dir y nomvre");
			Field70 fld70 = new Field70("/INV/81814");

			list = CampoFormUtils.objToPropertiesCf(fld70);
			list.forEach(cf -> {
				System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor() + "  -> " + cf.getValor() + " nulo? "
						+ (cf.getValor() == null));
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// @Test
	public void cfTest() {
		try {
			String ex = "objectKeyMaptributes[$aPerson] == foo";
			ex = "objectKeyMaptributes[$aPerson]";
			ex = "objectKeyMaptributes[foo];";
			ex = "objectKeyMaptributes[foo];";
			Field32A foo = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89").setDate(Calendar.getInstance());

			CampoForm person = new CampoForm();
			person.setValor("vvvvvvvvvvvvvvv");
			person.setObjectKeyMaptributes(new HashMap<Object, Field>());
			// person.getObjectKeyMaptributes().put(person, foo);
			person.getObjectKeyMaptributes().put(foo, foo);
//	    Map<Object, Field> map = new HashMap<Object, Field>();
//	    map.put("fo", foo);
//	    
//	    person.setObjectKeyMaptributes(map);

			Map<String, Class> inputs = new HashMap<String, Class>();
			inputs.put("this", CampoForm.class);
			inputs.put("foo", Field.class);
			inputs.put("$aPerson", CampoForm.class);

			ParserContext ctx = new ParserContext();
			ctx.setStrongTyping(true);
			// ctx.initializeTables();
			ctx.setInputs(inputs);
			ctx.initializeTables();

			Serializable expression = MVEL.compileExpression(ex, ctx);

			Map<String, Object> variables = new HashMap<String, Object>();
			variables.put("foo", foo);
			// variables.put("$aPerson", person);
			// variables.put("person", person);

			Object o = MVEL.executeExpression(expression, person, variables);
			// Object o = MVEL.executeExpression(expression, variables);
			System.out.println("r " + o);
//	    Field32A fo = (Field32A) o;
//	    System.out.println("r " + fo.getName());

			inputs = new HashMap<String, Class>();
			inputs.put("this", CampoForm.class);
			inputs.put("a", CampoForm.class);

			ctx = new ParserContext();
			ctx.setStrongTyping(true);
			// ctx.initializeTables();
			ctx.setInputs(inputs);
			ctx.initializeTables();

			Field32A fo = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89").setDate(Calendar.getInstance());
			CampoForm c = new CampoForm();
			c.setValor("eeeeeeeeeeeeeee");

			// Serializable compiled = MVEL.compileExpression("a.objectKeyMaptributes",
			// ctx);;
			Serializable compiled = MVEL.compileExpression("a.objectKeyMaptributes['valor3'];", ctx);
			;

			Map testMap = new HashMap();

			CampoForm b = new CampoForm();
			b.setValor("SSSSSSSSSSSSSSSSSSS");
			b.setObjectKeyMaptributes(new HashMap<>());
			b.getObjectKeyMaptributes().put("valor", "dog");
			b.getObjectKeyMaptributes().put("valor2", fo);
			b.getObjectKeyMaptributes().put("valor3", c);
			testMap.put("a", b);

			Object oo = MVEL.executeExpression(compiled, testMap);
			System.out.println("r " + oo);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// @Test
	public void execInstruccionTest() {
		try {
			Instruccion inst = new Instruccion();
			CampoForm cf = new CampoForm();

			Field32A f32A = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89").setDate(Calendar.getInstance());
			Field50K f50K = new Field50K().setAccount("asdf1234").setNameAndAddress("dir y nomvre");
			Field50F f50F = new Field50F()//
					.setComponent1("ctaNro")//
					.setComponent2("1")//
					.setComponent3("name")//
					.setComponent4("2")//
					.setComponent5("location")//
					.setComponent6("3")//
					.setComponent7("plaza");

			String exp = "F32A.amount";
			String exp2 = "output.valDecimal=F32A.amountAsBigDecimal; output.tabla=F32A.name;output.column='amountAsBigDecimal';output.valor=F32A.amount;output.valorObj=F32A;";

			Serializable compiled = MVEL.compileExpression(exp);
			Object o = MVEL.executeExpression(compiled, inst.getMappingTable().getMapFacts());

			System.out.println("rest " + o);

			exp2 = "output.valorObj=F32A;";

			compiled = MVEL.compileExpression(exp2);
			o = MVEL.executeExpression(compiled, inst.getMappingTable().getMapFacts());

			System.out.println("rest " + o + " -> " + cf.toStringCF());

			// *********************************//

			ParserContext ctx = new ParserContext();
			ctx.addImport(Instruccion.class);
			ctx.addImport(Field32A.class);
			ctx.addInput("input", Instruccion.class);
			ctx.addInput("F32A", Field32A.class);
			ctx.setStrongTyping(true);

			String exp3 = "input.mapFacts['F32A'];";
			exp3 = "((Field32A) input.mapFacts['F32A']).amountAsBigDecimal;";
			exp3 = "((Field32A) input.fact(\"F32A\")).amountAsBigDecimal;";
			Serializable exprCompiled = MVEL.compileExpression(exp3, ctx);

			o = MVEL.executeExpression(exprCompiled, inst.getMappingTable().getMapFacts());
			// Field32A f32A0 = (Field32A) o;

			// System.out.println("rest3 " + o + " -> " + f32A0.currencyString() + " " +
			// f32A0.getName());
			System.out.println("rest3 " + o);
			// *********************************//
			String exp5 = "((Field32A) input.mapFacts['F32A']).getName();";
			exp5 = "output.valorObj = input.mapFacts['F32A'];";
			exp5 = "output.valorObj = input.fact('F32A');";
			exp5 = "output.valorObj = input.fact('F32A');";

			Map<String, Class> inputs = new HashMap<String, Class>();
			inputs.put("input", Instruccion.class);
			inputs.put("output", CampoForm.class);
			// inputs.put("F32A", Field32A.class);
			// inputs.put("$aInstr", Instruccion.class);

			ctx = new ParserContext();
			ctx.setStrongTyping(true);
			ctx.setInputs(inputs);
			ctx.addImport(Instruccion.class);
			ctx.addImport(CampoForm.class);
			// ctx.addImport(Field32A.class);
			// ctx.initializeTables();

			exprCompiled = MVEL.compileExpression(exp5, ctx);

			cf = new CampoForm();

			Map<String, Object> vars = new HashMap<String, Object>();
//			vars.put("F32A", f32A);
			vars.put("input", inst);
			vars.put("output", cf);

			VariableResolverFactory varsResolver = new MapVariableResolverFactory(vars);

			o = MVEL.executeExpression(exprCompiled, varsResolver);

			System.out.println("rest5 " + o + " " + cf.toStringCF());

			List<CampoForm> list = CampoFormUtils.objToPropertiesCf(cf.getValorObj());
			list.forEach(cff -> {
				System.out.println("cf " + cff.toStringCF());
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// @Test
	public void fieldToCFTest() {
		try {
			CampoForm cf = new CampoForm();

			Field32A f32A = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89").setDate(Calendar.getInstance());
			Field50K f50K = new Field50K().setAccount("asdf1234").setNameAndAddress("dir y nomvre");
			Field50F f50F = new Field50F()//
					.setComponent1("ctaNro")//
					.setComponent2("1")//
					.setComponent3("name")//
					.setComponent4("2")//
					.setComponent5("location")//
					.setComponent6("3")//
					.setComponent7("plaza");

			Field f = Field.getField("50K", null);

			ParserContext ctx = new ParserContext();
			ctx.setStrongTyping(true);
			// ctx.addImport(Field32A.class);
			// ctx.addImport(CampoForm.class);
			ctx.addInput("this", f.getClass());
			ctx.addInput("field", f.getClass());
			ctx.initializeTables();

			Serializable compiled = MVEL.compileExpression("field.name", ctx);
			ExpressionCompiler expCom = new ExpressionCompiler("field.name", ctx);
			final CompiledExpression compiledExp = expCom.compile();

			System.out.println("rest5 ==> " + compiledExp.getKnownEgressType() + "");

			Map<String, Object> vars = new HashMap<String, Object>();
			vars.put("field", f);

			VariableResolverFactory varsResolver = new MapVariableResolverFactory(vars);

			Object o = MVEL.executeExpression(compiled, varsResolver);

			System.out.println("rest5 " + o);

			ctx.getVariableScope().forEach(s -> {
				ExpressionCompiler expC = new ExpressionCompiler("field." + s, ctx);
				CompiledExpression compiledExpression = null;
				String error = "";
				try {
					compiledExpression = expC.compile();
				} catch (Exception e) {
					// System.out.println("Error " + e.getMessage() );
					error = e.getMessage();
				}
				Object val = null;
				if (compiledExpression != null && compiledExpression.getKnownEgressType() != Void.TYPE) {
					try {
						val = MVEL.executeExpression(compiledExpression, varsResolver);
					} catch (Exception e) {
						// System.out.println("Error " + e.getMessage() );
						error = e.getMessage();
					}

//					System.out.println("var " + s + " vsi " + val );
				}

			});

			CampoForm campoForm = new CampoForm("valor", 1, "rule.getRule().getNamespace()", "rule.getRule().getName()");
			campoForm.setValorObj(f50K);

			List<CampoForm> list = CampoFormUtils.objToPropertiesCf(f);
			list.forEach(cff -> {
				System.out.println("cf " + cff.toStringCF());
			});

			list = CampoFormUtils.objToPropertiesCf(campoForm);
			list.forEach(cff -> {
				System.out.println("cf " + cff.toStringCF());
			});

			list = CampoFormUtils.objToPropertiesCf(f50F);
			list.forEach(cff -> {
				System.out.println("cf " + cff.toStringCF());
			});

			list = CampoFormUtils.objToPropertiesCf(f32A);
			list.forEach(cff -> {
				System.out.println("cf " + cff.toStringCF());
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void field72Test() {
		try {
			String s = "/ACC/FFC:983622168 BG BOLIVIA / /UNA CADENA LARGA asdf asf asf fsdf asdf  asdf CON MUCHO CONTENIDO ASI / / NO MAS ES QUE SE BA HACER";
			s = "/ACC/BANCO ITAU S.A. AGENCIA 0477\r\n//RIO CINELANDIA-0428 ASDF asf FASDF asdf\r\n//RIO DE JANEIRO-BRASIL";
			Field72 f = new Field72(s);
			// s = StringUtils.replaceChars(s, "\r\n", " ");
//			s = StringUtils.replace(s, "//", " ");
			Narrative n = NarrativeResolver.parseFormat2(f);
			System.out.println("narra " + n.getValue());

			String s5 = "/01/FFC:983622168 BG BOLIVIA /02/UNA CADENA LARGA asdf asf asf fsdf asdf  asdf CON MUCHO CONTENIDO ASI /03/NO MAS ES QUE SE BA HACER";
			Field72 f5 = new Field72(s5);
			Narrative na5 = NarrativeResolver.parseFormat5(f5);
			System.out.println("field 5 " + na5.getValue());

			Narrative na = NarrativeResolver.parseFormat8(s);
			System.out.println("narra 2 " + na.getValue());

			Narrative na1 = NarrativeResolver.parseFreeFormat(s);
			System.out.println("narra 3 " + na1.getValue());

			Field72 f2 = (Field72) FieldsCommand.f72(s).apply(null).get().getValorObj();
			System.out.println("field ==> " + f2.getValue());

			List<String> lines = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS, s, 5, "", "//", 1);
			StringBuilder sb = new StringBuilder();
			int i = 1;
			for (String cad : lines) {
				sb.append(cad).append(i++ < lines.size() ? "\r\n" : "");
				System.out.println("CAD = " + cad + " " + sb.length());
			}
			System.out.println("CAD = " + sb.toString() + " *");

			Builder b = Narrative.builder(34);
			b.addCodeword("AVBG", "asdf123456789 asf456 asf");
			b.addCodewordWithAmount("ADGD", "EUR", BigDecimal.valueOf(52365.88), "es ua cadena narratie de texto largo que debe parsear");

			String cadena = "/LNID/${lnid}///OCMT/${ocmt}///EXRT/AMOUNT ${exrt} ${exrt + 1002}";
			;
			Narrative naa = b.build();
			System.out.println("NAA " + naa.getValue() + " cadena: " + cadena);

			Map<String, Object> map = new HashMap<String, Object>();
			map.put("lnid", "Foo");
			map.put("ocmt", "Bar");
			map.put("exrt", BigDecimal.valueOf(458.36));

			Map<String, Object> codesmap = new HashMap<String, Object>();
			List<String> splitl = SwiftParseUtils.splitComponents(cadena, null, "//");
			splitl.forEach(cad -> {
				String codeword = StringUtils.substringBetween(cad, "/", "/");
				String text = StringUtils.substringAfter(cad, codeword + "/");
				// String text = StringUtils.substringBefore(codeword, "/");
				String texta = StringUtils.substringAfter(cad, "/");
				log.info("cadena {} cad{} : code: {} text: {} ->{}", cadena, cad, codeword, text, texta);
				codesmap.put(codeword, text);
			});

			Builder bN = Narrative.builder(35);
			Map<String, Object> mapf = new HashMap<String, Object>();
			mapf.put("lnid", "Foo");
			mapf.put("ocmt", new Date());
			mapf.put("exrt", BigDecimal.valueOf(458.36));

			codesmap.forEach((k, v) -> {
				CompiledTemplate compiled = compileTemplate(v.toString());
				Object o = TemplateRuntime.execute(compiled, mapf);

				log.info("resF {} {} :>> {}", k, v, o.toString());
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
