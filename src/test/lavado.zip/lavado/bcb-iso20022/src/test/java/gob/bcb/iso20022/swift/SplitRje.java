package gob.bcb.iso20022.swift;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.utils.UtilsFile;

public class SplitRje {
	private static final Logger log = LoggerFactory.getLogger(SplitRje.class);
	@Test
	public void splitFile() {
		String nfile = "src/test/resources/mts/siodex_202.txt";
		String str = UtilsFile.readFileAsString2(nfile);
		String [] rjes = splitSwift(str);
		int i = 0;
		for(String rje : rjes) {
			log.info("$$$$$$$$$$$$$$$"+ i++ +"$$$$$$$$$$$$$$$$$");
			log.info(rje);
		}
	}
	
	public static String[] splitSwift(String str) {
		ArrayList<Object> splitLista = new ArrayList<>();
		if (StringUtils.isBlank(str)) {
//			log.error("Error al dividir lote de mensajes swift Parametro nulo");
			throw new RuntimeException("Error al dividir lote de mensajes swift Parametro nulo");
		}

		str = str.concat("{1:}");
		str = str.replace("\r\n", "#|");

		String strIni = "\\{1:";
		String strFin = "\\{1:";

		Pattern pattern = Pattern.compile("" + strIni + "(.*?)(?=" + strFin + ")");
		Matcher matcher = pattern.matcher(str);

		while (matcher.find()) {
			String swiftPlano = matcher.group();
			swiftPlano = swiftPlano.replace("#|", "\r\n");
			splitLista.add(swiftPlano);
		}
//		log.info("SplitSwift Mensajes " + splitLista.size());

		String[] res = new String[splitLista.size()];
		return splitLista.toArray(res);		
	}

}
