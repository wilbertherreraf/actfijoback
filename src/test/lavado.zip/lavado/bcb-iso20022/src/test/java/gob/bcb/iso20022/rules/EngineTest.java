package gob.bcb.iso20022.rules;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.junit.jupiter.api.Test;

import gob.bcb.iso20022.exceptions.CompileException;
import gob.bcb.iso20022.exceptions.DuplicateNameException;
import gob.bcb.iso20022.exceptions.NoActionFoundException;
import gob.bcb.iso20022.exceptions.NoMatchingRuleFoundException;
import gob.bcb.iso20022.exceptions.ParseException;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.MappingTable;

public class EngineTest {
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	public Engine getEngine(List<Rule> rules, boolean throwExceptionIfCompilationFails) throws DuplicateNameException, CompileException, ParseException {
		return new Engine(rules, throwExceptionIfCompilationFails);
	}

//	//@Test
//	public void testSubrulesWithActions() {
//		SubRule sr1 = new SubRule("1", "true", "ch.maxant.test");
//		SubRule sr2 = new SubRule("2", "false", "ch.maxant.test");
//		Rule rule = new Rule("3", "#1 && !#2", "Bingo", 1, "ch.maxant.test");
//		List<Rule> rules = Arrays.asList(sr1, sr2, rule);
//
//		AbstractAction<MyInput, BigDecimal> action1 = new AbstractAction<MyInput, BigDecimal>("Bingo") {
//			public BigDecimal execute(MyInput input) {
//				return new BigDecimal("100.0");
//			}
//
//			@Override
//			public BigDecimal execute(MyInput input, Rule rule) {
//				// TODO Auto-generated method stub
//				return null;
//			}
//		};
//
//		List<AbstractAction<MyInput, BigDecimal>> actions = Arrays.asList(action1);
//
//		try {
//			Engine e = getEngine(rules, true);
//
//			MyInput input = new MyInput();
//
//			BigDecimal price = null;
//
//			price = e.executeBestAction(input, actions);
//
//			assertEquals(new BigDecimal("100.0"), price);
//
//		} catch (Exception ex) {
//			ex.printStackTrace();
//			fail();
//		}
//	}

	public static String upperCase(String s) {
		return s.toUpperCase();
	}
	
//	//@Test 
//	public void testExecuteBestActionManyActionsFiring() throws IOException {
//		Rule r1 = new Rule("SendEmailToUser", "input.config.sendUserEmail == true", "SendEmailToUser", 1, "ch.maxant.someapp.config");
//		Rule r2 = new Rule("SendEmailToModerator", "input.config.sendAdministratorEmail == true and input.user.numberOfPostings < 5", "SendEmailToModerator",
//				2, "ch.maxant.someapp.config");
//		r1.setAction("input.tipo = uppc('eee11111AAA'); System.out.println('===>' + input.tipo);");
//		
//		List<Rule> rules = Arrays.asList(r1, r2);
//
//		final List<String> messages = new ArrayList<String>();
//
//		AbstractAction<ForumSetup, Void> a1 = new AbstractAction<ForumSetup, Void>("SendEmailToUser") {
//			@Override
//			public Void execute(ForumSetup input) {
//				messages.add("Sending email to user!");
//				return null;
//			}
//
//			@Override
//			public Void execute(ForumSetup input, Rule rule) {
//				// TODO Auto-generated method stub
//				return null;
//			}
//		};
//		try {
//			Engine engine = getEngine(rules, true);
//			try {
//				engine.addMethod("uppc", EngineTest.class.getMethod("upperCase", String.class));
//			} catch (NoSuchMethodException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (SecurityException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			
//			ForumSetup setup = new ForumSetup();
//			setup.getConfig().setSendUserEmail(true);
//			setup.getConfig().setSendAdministratorEmail(true);
//			setup.getUser().setNumberOfPostings(2);
//			
//			engine.executeAllActions(setup, Arrays.asList(a1, a2));
//			
//			messages.forEach(m -> {
//				log.info("mm " + m);
//			});
//			log.info("form " + setup.getTipo());
//			assertEquals(2, messages.size());
//			assertEquals("Sending email to moderator!", messages.get(0));
//			assertEquals("Sending email to user!", messages.get(1));
//
//		} catch (DuplicateNameException e) {
//			fail(e.getMessage());
//		} catch (CompileException e) {
//			fail(e.getMessage());
//		} catch (ParseException e) {
//			fail(e.getMessage());
//		} catch (NoMatchingRuleFoundException e) {
//			fail(e.getMessage());
//		} catch (NoActionFoundException e) {
//			fail(e.getMessage());
//		}
//	}

	@Test 
	public void testExecuteAllActionsFiring() throws IOException {
		Rule r1 = new Rule("SendEmailToUserR", "input.config.sendUserEmail == true", "SendEmailToUser", 1, "ch.maxant.someapp.config", null, "'YYY';");
		Rule r2 = new Rule("SendEmailToModeratorR", "input.config.sendAdministratorEmail == true and input.user.numberOfPostings < 5", "SendEmailToModerator",
				2, "ch.maxant.someapp.config");
		r2.setAction("uppc('eee11111AAA');");
		r2.setAction("input.tipo = uppc('personita');");
		
		Rule r3 = new Rule("personareglaR", "input.config.sendAdministratorEmail == true and input.user.numberOfPostings < 5", "",
				1, "ch.maxant.someapp.config");
		r3.setAction("input.tipo = uppc('personita');");			
		List<Rule> rules = Arrays.asList(r1, r2, r3);

		Map<String, Object> facts = new HashMap<String, Object>();
		Map<String, Object> mapResult = new HashMap<String, Object>();
		
		final List<User> lu = new ArrayList<>();
		
		BiConsumer<Rule, ForumSetup> afterConditionC = (r , f) -> {
			User u = new User();
			u.setName(r.getExpression() + " " + f.getConfig().isSendAdministratorEmail() + " tipo " + f.getTipo());
			u.setNumberOfPostings(r.getPriority());
			lu.add(u);
		};
		
		BiConsumer<Person, Object> afterConditionCGen = (r , o) -> {
//			System.out.println("Env after object " + r.getAction() + " " + r.getName() + " ");
//			mapResult.putIfAbsent(r.getFullyQualifiedName(), o);
		};

		BiConsumer<Rule, Person> afterActionC = (r , f) -> {
			System.out.println("Env after IAction " + r.getAction() + " " + r.getName() + " ");
//			User u = new User();
//			u.setName(r.getExpression() + " " + f.getName() + " tipo " + f.getOther());
//			u.setNumberOfPostings(r.getPriority());
//			lu.add(u);
		};
		
		AbstractAction<ForumSetup, Person> a1 = new AbstractAction<ForumSetup, Person>("SendEmailToUser", afterActionC) {

			@Override
			protected Person initializeOutputResult(CompiledRule rule, ForumSetup input) {
				return null;
			}

		};

		AbstractAction<ForumSetup, Person> a2 = new AbstractAction<ForumSetup, Person>("SendEmailToModerator", afterActionC) {

			@Override
			protected Person initializeOutputResult(CompiledRule rule, ForumSetup input) {
				// TODO Auto-generated method stub
				return null;
			}
		};

		AbstractAction<ForumSetup, Person> a3 = new AbstractAction<ForumSetup, Person>("personareglaR", null) {

			@Override
			protected Person initializeOutputResult(CompiledRule rule, ForumSetup input) {
				// TODO Auto-generated method stub
				return null;
			}
		};
	
		try {
			Engine engine = new Engine(rules, true, facts);
			try {
				engine.addMethod("uppc", EngineTest.class.getMethod("upperCase", String.class));
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			ForumSetup setup = new ForumSetup();
			setup.getConfig().setSendUserEmail(true);
			setup.getConfig().setSendAdministratorEmail(true);
			setup.getUser().setNumberOfPostings(2);
			
			engine.addAction(a1).addAction(a3).addAction(a2);
			//engine.executeAllActions(setup, actions);
			//engine.executeAllActions(setup);
			
//			lpr.forEach(m -> {
//				log.info("person age " + m.getAge() + " " + m.getOther() + " " + m.getName());
//			});
			
			lu.forEach(m -> {
				log.info("User " + m.getNumberOfPostings() + " --> " + m.getName());
			});
			
			log.info("form " + setup.getTipo());
//			assertEquals(3, messages.size());
//			assertEquals("Sending email to moderator!", messages.get(0));
//			assertEquals("Sending email to user!", messages.get(1));

		} catch (DuplicateNameException e) {
			fail(e.getMessage());
		} catch (CompileException e) {
			fail(e.getMessage());
		} catch (ParseException e) {
			fail(e.getMessage());
		}
	}
	
//	//@Test 
//	public void testExecuteAllActionsMT() throws Exception {
//		Map<String, Object> facts = new HashMap<String, Object>();
//		Rule r1 = new Rule("dbtName", "true", "", 1, "pacs.001.001.01", null, "field50f.getComponent2();");
//
//		MyInput myInput = new MyInput();
//		MappingTable mappingTable = new MappingTable(FileFormat.MT, FileFormat.MX);
//		List<Rule> rules = Arrays.asList(r1);
//		
//		BiConsumer<Rule, MyInput> afterConditionCGen = (rule , fVars) -> {
//			rule.getAction();
//			mappingTable.addMappingRule(null);
//		};
//
//		AbstractAction<MyInput, MappingTable> a3 = new AbstractAction<MyInput, MappingTable>("personareglaR", afterConditionCGen) {
//
//		};
//		
//		Engine engine = new Engine(rules, true, facts);
//		engine.executeAllActions(myInput, Arrays.asList(a3));
//	}
	
	public static final class Person {
		private String name;
		private Integer age;
		private String other;
		
		public Person(int age) {
			this.age = age;
		}

		public Person(String name) {
			this.name = name;
		}

		public Person(String name, int age) {
			this.name = name;
			this.age = age;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Integer getAge() {
			return age;
		}

		public void setAge(Integer age) {
			this.age = age;
		}

		public String getOther() {
			return other;
		}

		public void setOther(String other) {
			this.other = other;
		}
	}

	public static final class MyInput {
		private Person p1;
		private Person p2;

		public Person getP1() {
			return p1;
		}

		public void setP1(Person p1) {
			this.p1 = p1;
		}

		public Person getP2() {
			return p2;
		}

		public void setP2(Person p2) {
			this.p2 = p2;
		}
	}

	public static final class Account {
		private int ageInMonths;

		public void setAgeInMonths(int ageInMonths) {
			this.ageInMonths = ageInMonths;
		}

		public int getAgeInMonths() {
			return ageInMonths;
		}
	}

	public static final class TarifRequest {
		private Person p;
		private Account a;

		public Person getPerson() {
			return p;
		}

		public void setPerson(Person p) {
			this.p = p;
		}

		public Account getAccount() {
			return a;
		}

		public void setAccount(Account a) {
			this.a = a;
		}
	}

	public static final class TravelRequest {
		private int distance;
		private Map<Object, Object> map = new HashMap<Object, Object>();

		public TravelRequest(int distance) {
			this.distance = distance;
		}

		public void put(Object key, Object value) {
			map.put(key, value);
		}

		public int getDistance() {
			return distance;
		}

		@SuppressWarnings("rawtypes")
		public Map getMap() {
			return map;
		}
	}

	public static final class ForumSetup {
		private Config config = new Config();
		private User user = new User();
		private String tipo;
		
		public Config getConfig() {
			return config;
		}

		public User getUser() {
			return user;
		}

		public String getTipo() {
			return tipo;
		}

		public void setTipo(String tipo) {
			this.tipo = tipo;
		}
	}

	public static final class Config {
		private boolean sendUserEmail;
		private boolean sendAdministratorEmail;

		public void setSendUserEmail(boolean sendUserEmail) {
			this.sendUserEmail = sendUserEmail;
		}

		public void setSendAdministratorEmail(boolean sendAdministratorEmail) {
			this.sendAdministratorEmail = sendAdministratorEmail;
		}

		public boolean isSendAdministratorEmail() {
			return sendAdministratorEmail;
		}

		public boolean isSendUserEmail() {
			return sendUserEmail;
		}
	}

	public static final class User {
		private String name ;
		private int numberOfPostings = 0;

		public void setNumberOfPostings(int numberOfPostings) {
			this.numberOfPostings = numberOfPostings;
		}

		public int getNumberOfPostings() {
			return numberOfPostings;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
	}

	public static final class Classroom {
		List<Person> students = new ArrayList<Person>();

		public List<Person> getStudents() {
			return students;
		}
	}
}
