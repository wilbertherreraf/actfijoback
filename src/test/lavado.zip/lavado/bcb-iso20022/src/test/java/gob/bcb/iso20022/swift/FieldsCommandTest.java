package gob.bcb.iso20022.swift;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.field.Field50F;
import com.prowidesoftware.swift.model.field.Field59F;

public class FieldsCommandTest {
	private static final Logger log = LoggerFactory.getLogger(FieldsCommandTest.class);

	@Test
	public void fieldsTest() {
		try {
			Field50F f = (Field50F) FieldsCommand.fld50F("10000012041872", "UNIVERSIDAD AMAZONICA DE PANDO", "AV.TCNL.ENRIQUE CORNEJO No. 092", null,
					"PANDO - BOLIVIA");
			log.info("ll {}", f.getValue());
			f = (Field50F) FieldsCommand.fld50F("10000012041872", "UNIVERSIDAD AMAZONICA DE PANDO MASD LARGA NOMBRE", "AV.TCNL.ENRIQUE CORNEJO No. 092", null,
					"PANDO - BOLIVIA");
			log.info("ll {}", f.getValue());
			f = (Field50F) FieldsCommand.fld50F("10000012041872", "UNIVERSIDAD AMAZONICA DE PANDO", "AV.TCNL.ENRIQUE CORNEJO No. 092 MAS LARGA DIRECCION",
					"ASDF", "PANDO - BOLIVIA");
			log.info("ll {}", f.getValue());
			f = (Field50F) FieldsCommand.fld50F("10000012041872", "UNIVERSIDAD AMAZONICA DE PANDO MAS LAR NOMBRE",
					"AV.TCNL.ENRIQUE CORNEJO No. 092 MAS LARGA DIRECCION", "BO", "PANDO - BOLIVIA");
			log.info("ll {}", f.getValue());

			// ctaNro 8901355062, name INTER-AMERICAN DEVELOPMENT BANK , address 1300 NEW
			// YORK AVENUE, N.W., ctry US, city WASHINGTON DC 20577, US
			Field59F f59F = (Field59F) FieldsCommand.fld59F("8901355062", "INTER-AMERICAN DEVELOPMENT BANK", "1300 NEW YORK AVENUE, N.W.", "US",
					"WASHINGTON DC 20577, US");
			log.info("f59F {}", f59F.getValue());
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
}
