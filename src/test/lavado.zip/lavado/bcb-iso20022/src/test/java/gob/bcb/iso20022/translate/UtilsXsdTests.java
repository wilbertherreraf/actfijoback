package gob.bcb.iso20022.translate; 

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.pojo.Node;
import gob.bcb.iso20022.utils.UtilsFile;


public class UtilsXsdTests {
	private static final Logger log = LoggerFactory.getLogger(UtilsXsdTests.class);
	
	@Test
	public void unmarshallXsdTest() {
		
		UtilsXsd utilsXsd = new UtilsXsd ();
		List<String> lc = new ArrayList<>();
		try {
			log.info("inicio test=========================");
			String nfile = "src/main/resources/xsd/head.001.001.03.xsd"; // head.001.001.03.xsd
			nfile = "src/test/resources/xsdpru/SAA_XML_v2_0_15.xsd";
			LinkedList<SwfMencampos> r = new LinkedList<SwfMencampos>();
			Node<SwfMencampos> root = utilsXsd.unmarshallXsd(nfile, "P009",r);
			List<SwfMencampos> resp = UtilsXsd.visitNode(root);
			for(SwfMencampos sc : r) {
				log.info(sc.getMtfNivel() + ": " + sc.toStringID() + "\t" + sc.getMtfNemo() + "\t :=> " + " " + sc.getMtfMinimo() + ":" + sc.getMtfCardinal() + " "
						+ sc.getMtfTipocampo() + " " + sc.getMtfXmltag() + " :: " + sc.getMtfSecpadre());
			}
			log.info("************************");
			for(SwfMencampos sc : resp) {
				sc.toStringID();
				lc.add((sc.getMtfId        ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfCodmt     ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfCodcampo  ()) + "|" +
						(sc.getMtfNro       ()) + "|" +
						(sc.getMtfGrpopt    ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfNemo      ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfDescrip   ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfCondicion ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfExpresion ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfReglavalid()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfXmltag    ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfStatus    ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfTipocampo ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfSecpadre  ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfBloque    ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfFormato   ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfReglaswf  ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfDatoadic  ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfDefault   ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfEstado    ()) + "|" +
						(sc.getMtfNivel     ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfMinimo    ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfCardinal  ()) + "|" +
						(sc.getMtfSubaction ()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfSubaction2()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfSubaction3()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfEsopcional()) + "|" +
						StringUtils.trimToEmpty(sc.getMtfSinonimos ())
);
					log.info(sc.getMtfId()+": "+ sc.getMtfNivel() + ": " + sc.toStringID() + "\t" + sc.getMtfNemo() + "\t :=> " + " " + sc.getMtfStatus() + ":" + sc.getMtfCardinal() + " "
							+ sc.getMtfTipocampo() + " " + sc.getMtfXmltag() + " :: " + sc.getMtfDatoadic()+ " :: " + sc.getMtfReglaswf());					
				
			}
			UtilsFile.grabaEnArchivo(lc, "e:/tmp/p009.txt");
		}catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	
	//@Test
	public void unmarshallXsd09Test() {
		
		UtilsXsd utilsXsd = new UtilsXsd (3);
		
		try {
			log.info("inicio test=========================");
			String nfile = "src/main/resources/xsd/pacs.009.001.09.xsd"; // head.001.001.03.xsd
			LinkedList<SwfMencampos> r = new LinkedList<SwfMencampos>();
			Node<SwfMencampos> root = utilsXsd.unmarshallXsd(nfile, "P009",r);
			List<SwfMencampos> resp = UtilsXsd.visitNode(root);
			for(SwfMencampos sc : r) {
				log.info(sc.getMtfNivel() + ": " + sc.toStringID() + "\t" + sc.getMtfNemo() + "\t :=> " + " " + sc.getMtfMinimo() + ":" + sc.getMtfCardinal() + " "
						+ sc.getMtfTipocampo() + " " + sc.getMtfXmltag() + " :: " + sc.getMtfSecpadre());
			}
			log.info("************************");
			for(SwfMencampos sc : resp) {
				
					log.info(sc.getMtfId()+": "+ sc.getMtfNivel() + ": " + sc.toStringID() + "\t" + sc.getMtfNemo() + "\t :=> " + " " + sc.getMtfStatus() + ":" + sc.getMtfCardinal() + " "
							+ sc.getMtfTipocampo() + " " + sc.getMtfXmltag() + " :: " + sc.getMtfDatoadic()+ " :: " + sc.getMtfReglaswf());					
				
			}
			
		}catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}	
}
