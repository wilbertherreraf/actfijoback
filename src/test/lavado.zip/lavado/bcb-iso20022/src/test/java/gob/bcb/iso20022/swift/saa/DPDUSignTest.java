package gob.bcb.iso20022.swift.saa;

import java.io.FileInputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.traversal.DocumentTraversal;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.NodeIterator;

import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.sun.org.apache.xpath.internal.CachedXPathAPI;

import gob.bcb.iso20022.core.xml.JaxBConversionService;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.utils.ArchivoUtil;
import gob.bcb.iso20022.utils.UtilsFile;

public class DPDUSignTest {
//// Nooooooooooooooooooooooooooooooooooooooooooooooo
	private static final Logger log = LoggerFactory.getLogger(DPDUSignTest.class);

	@Test
	public void dataPDUToSignTest() {
		try {
			log.info("======== inicio dataPDUToSaaTest======================");
			String nfile = "src/test/resources/mxs/saaconns.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			nfile = "src/test/resources/sign/saa.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			String xmlPDU = UtilsFile.readFileAsString2(nfile);
			final AbstractMX source = AbstractMX.parse(xmlPDU);

			DataPDUWriter w = new DataPDUWriter(source);
			DataPDU dataPDU = w.xml(xmlPDU).getDataPDU();
			String saaXml = w.xmlSaa();

			log.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
			log.info(saaXml);
			log.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			sign(dataPDU, saaXml);

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	//@Test
	public void validTest() {
		try {
			log.info("======== inicio dataPDUToSaaTest======================");
			String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><fo><valor>asd1</valor></fo>";
			String nfile = "src/test/resources/sign/saa.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			xml = UtilsFile.readFileAsString2(nfile);
			String xmlC = IOUtils.toString(new FileInputStream(nfile));
			xml = xml.replaceAll("\n|\r", "");
			xmlC = xmlC.replaceAll("\n|\r", "");
			String hashA = ArchivoUtil.hashString(xml);
			String hxmlC = ArchivoUtil.hashString(xmlC);
			log.info(hashA + " <- XML1 -> " + hxmlC);			
			Document document = JaxBConversionService.getDomFromString(xmlC);
			Document document2 = JaxBConversionService.documentBasedOnThe(xmlC.getBytes());
			
			byte[] xmlb1 = JaxBConversionService.createXmlUsing(document);
			String xml1 = new String(xmlb1, StandardCharsets.UTF_8);
			String xml2 = JaxBConversionService.getStringFromDom(document);
			String xml3 = JaxBConversionService.getStringFromDom(document2, false, false);			
			String hashB = ArchivoUtil.hashString(xml2);
			String hashC = ArchivoUtil.hashString(xml1);			
			log.info(hashB + " XML2 " + xml2);			
			log.info("HA " + hashA + " HB: "  + hashB + " HC "+ hashC);
			log.info(xmlC);
			log.info("*************************************");			
			log.info(xml1);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
	
	public void sign(DataPDU myDataPDU, String xmlSaa) throws Exception {
		JAXBContext jaxbContext = JAXBContext.newInstance(DataPDU.class);
// myDataPDU.setRevision("2.0.6");

// marshall the file
		Marshaller marshaller = jaxbContext.createMarshaller();

		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		domFactory.setNamespaceAware(true);
		DocumentBuilder docBuilder = domFactory.newDocumentBuilder();
		Document doc = docBuilder.newDocument();
		DOMResult domResult = new DOMResult(doc);
		marshaller.marshal(myDataPDU, domResult);

// get the document list
//Document document = (Document) domResult.getNode();
		xmlSaa = xmlSaa.replaceAll("\n|\r", "");
		Document document = JaxBConversionService.documentBasedOnThe(xmlSaa.getBytes());
// signing process
		XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");

		SignatureMethod signatureMethod = factory.newSignatureMethod("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256", null);

		CanonicalizationMethod canonicalizationMethod = factory.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (XMLStructure) null);

		List<Transform> transforms = new ArrayList<Transform>();
		transforms.add(factory.newTransform(Transform.ENVELOPED, (XMLStructure) null));
		transforms.add(factory.newTransform("http://www.w3.org/2001/10/xml-exc-c14n#", (XMLStructure) null));

		DigestMethod digestMethod = factory.newDigestMethod("http://www.w3.org/2001/04/xmlenc#sha256", null);

		Reference reference = factory.newReference("", digestMethod, transforms, null, null);
		log.info("Auiiiiiiiiiiiiiiiiiiiiiiii");
		SignedInfo signedInfo = factory.newSignedInfo(canonicalizationMethod, signatureMethod, Collections.singletonList(reference));

		String secretKey = "Abcd1234abcd1234Abcd1234abcd1234";
		SecretKeySpec secret_key = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");

		Element LAUElement = document.createElementNS("urn:swift:saa:xsd:saa.2.0", "Saa:LAU");
		LAUElement.setAttribute("xmlns:Saa", "urn:swift:saa:xsd:saa.2.0");
		// LAUElement.setAttribute("xmlns:Sw", "urn:swift:snl:ns.Sw");
		Element rootElement = document.getDocumentElement();
		rootElement.appendChild(LAUElement);

		DOMSignContext domSignContext = new DOMSignContext(secret_key, LAUElement);
		domSignContext.setDefaultNamespacePrefix("ds");

		XMLSignature signature = factory.newXMLSignature(signedInfo, null);
		signature.sign(domSignContext);
		
		// String s = JaxBConversionService.getStringFromDom(document, false, false);
		String signed = JaxBConversionService.getStringFromDom(document);
		log.info("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF " + signed.hashCode());
//	    signed = signed.replace("BKNY", "XXXX");
		log.info(signed);

		Node n0 = document.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "Signature").item(0);
		String eeC0 = node2XML(n0);
		
		String currentSystemId = "memory://";

		CachedXPathAPI xpathAPI = new CachedXPathAPI();
//		Element contexto = org.apache.xml.security.utils.XMLUtils.createDSctx(doc, "ds", "http://www.w3.org/2000/09/xmldsig#");
//		Element dsElem = (Element) xpathAPI.selectSingleNode(doc, "//ds:Signature", contexto);
//		XMLSignature  firma = new XMLSignature(dsElem, currentSystemId);

		// log.info(s);
		// KeySelector ks = new
		// KeySelectors.SecretKeySelector("testkey".getBytes("ASCII"));

		//Document docSign = JaxBConversionService.documentBasedOnThe(signed.getBytes());
		Document docSign = JaxBConversionService.documentBasedOnThe(signed.getBytes());
		String signedC = JaxBConversionService.getStringFromDom(docSign);
		log.info("SIGNEDS " + signed.hashCode() + " " + signedC.hashCode());
		
		String sk = "Abcd1234abcd1234Abcd1234abcd1234";
		SecretKeySpec sks = new SecretKeySpec(sk.getBytes(), "HmacSHA256");
		Element signatureElem = (Element) docSign.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "Signature").item(0);
		Node n = docSign.getElementsByTagNameNS("http://www.w3.org/2000/09/xmldsig#", "Signature").item(0);
		String eeC = node2XML(n);
		log.info("eeeeeeC " + eeC);
		log.info("eeC0 " + eeC0);		
		// DOMValidateContext dvc = new DOMValidateContext(sks,
		// document.getDocumentElement());
		DOMValidateContext dvc = new DOMValidateContext(sks, signatureElem);
		boolean v = signature.validate(dvc);
		log.info("Fimita valid " + v);

//        XMLSignature sig2 = factory.unmarshalXMLSignature(dvc);
//        boolean isEqSig = signature.equals(sig2);
//        log.info("Fimita iqbula " + isEqSig);
//        
//        boolean isval = sig2.validate(dvc);
//        log.info("Fimita valid " + isval);
		
		//Element es = getSignatureElement(docSign);		
		DOMValidateContext dvc2 = new DOMValidateContext(sks, signatureElem);
		XMLSignatureFactory factoryV = XMLSignatureFactory.getInstance("DOM");
		XMLSignature signatureV = factoryV.unmarshalXMLSignature(dvc2);
		boolean coreValidity = signatureV.validate(dvc2);
		
//		XMLSignature firma = new XMLSignature(signatureElem, currentSystemId);
		
		log.info("Fimita valid " + coreValidity);
		
		// Check core validation status
		if (coreValidity == false) {
			// check the validation status of each Reference
			Iterator<?> i = signatureV.getSignedInfo().getReferences().iterator();
			log.info("en i");
			while (i.hasNext()) {
				Reference reference2 = (Reference) i.next();
				boolean rb = reference2.validate(dvc2);
				log.info("en r " + rb);
			}
		}

		validate(docSign);
	}
	public void validate(Document doc) throws Exception {
		XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");

		NodeList sigList = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
		log.info("signs "  + sigList.getLength());
		if (sigList.getLength() == 0) {
		    throw new Exception("Cannot find Signature element");
		}
		String secretKey = "Abcd1234abcd1234Abcd1234abcd1234";
		SecretKeySpec secret_key = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");
		DOMValidateContext valContext = new DOMValidateContext(secret_key, sigList.item(0));
		XMLSignature signature = factory.unmarshalXMLSignature(valContext);

		log.info("Core validity: " + signature.validate(valContext));		
	}
	
    public static Element getSignatureElement(Document doc) {
        NodeIterator ni = ((DocumentTraversal)doc).createNodeIterator(
            doc.getDocumentElement(), NodeFilter.SHOW_ELEMENT, null, false);
        
        for (Node n = ni.nextNode(); n != null; n = ni.nextNode() ) {
            if ("Signature".equals(n.getLocalName())) {
                return (Element) n;
            }
        }
        return null;
    }
    
    public static String node2XML(Node node) throws TransformerException {
		String processedXML = null;

		// Transform the DOM tree into XML String
		TransformerFactory transFactory = TransformerFactory.newInstance();
		Transformer transformer = transFactory.newTransformer();
		//transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		DOMSource dSource = new DOMSource(node);
		StringWriter sw = new StringWriter();
		StreamResult sr = new StreamResult(sw);
		transformer.transform(dSource, sr);

		StringWriter anotherSW = (StringWriter) sr.getWriter();
		StringBuffer sBuffer = anotherSW.getBuffer();
		processedXML = sBuffer.toString();

		return processedXML;
	}    
}
