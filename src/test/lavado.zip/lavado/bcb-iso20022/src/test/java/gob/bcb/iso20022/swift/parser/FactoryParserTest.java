package gob.bcb.iso20022.swift.parser;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.IBAN;
import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.MxNode;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.mt.AbstractMT;
import com.prowidesoftware.swift.model.mx.AbstractMX;

import gob.bcb.iso20022.model.SwfReglasmerc;
import gob.bcb.iso20022.utils.UtilsFile;

public class FactoryParserTest {
	private static final Logger log = LoggerFactory.getLogger(FactoryParserTest.class);

	// @Test
	public void readMessage() {
		try {
			String nfile = "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			log.info(menplano);
			log.info("***************************");

			SwiftMessageAbstract sm = FactoryParser.createParser(menplano)//
			;

			sm.getBlock4().forEach(b -> {
				log.info("tipo " + b.getName() + " -> " + b.getValue());
			});
			AbstractMX mx = (AbstractMX) sm.getAbsMsg();
			MxNode document = MxNode.parse(mx.document());

			final MxNode groupHeader = document != null ? document.findFirstByName("GrpHdr") : null;

			MxNode reference = groupHeader.findFirst("./MsgId");

			log.info("nulo " + (reference == null));

			log.info(reference.path() + " *->" + reference.getValue());

			reference.setValue("asfasdf");

			MxNode reference0 = groupHeader.findFirst("./InstdAgt/finInstnId/pstlAdr");
			log.info("nulo ppppppppp");
			reference0.print();
			reference0.getChildren().forEach(n -> {
				log.info(n.path() + " *->" + n.getValue());
			});

			/*
			 * final MxNode groupHeader = n != null ? n.findFirstByName("GrpHdr") : null; if
			 * (groupHeader != null) { MxNode senderBic =
			 * groupHeader.findFirst("./InstgAgt/FinInstnId/BIC"); if (senderBic != null) {
			 * sender = bic11(senderBic.getValue()); updated = true; } MxNode receiverBic =
			 * groupHeader.findFirst("./InstdAgt/FinInstnId/BIC"); if (receiverBic != null)
			 * { receiver = bic11(receiverBic.getValue()); updated = true; } }
			 */
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	@Test
	public void recolectFields() {
		log.info("!!!!!!!!!!!!!!!!!! [ INICIO CONCURRENCIA ] !!!!!!!!!!!!!!!!!!");
		AtomicInteger ai = new AtomicInteger();
		ai.set(0);
		String inputDirectory = "e:/wil/projects/lavado/datos/mts20212022";
		List<String> lc = new ArrayList<>();
		List<String> lca = new ArrayList<>();
		UtilsFile.filesDir(inputDirectory).stream().forEach(f -> {
			int item = ai.addAndGet(1);
			try {
				String nFile = f.getAbsolutePath();
				String mtFile = UtilsFile.readFileAsString2(nFile);
				SwiftMessageAbstract sma = FactoryParser.createParser(mtFile);
				if (item <= 10000) {
					MtSwiftMessage swiftMessage = (MtSwiftMessage) sma.getMsg();
					log.info("=== {} -> [{}] {} =============", item, sma.getTypeMessage(), nFile);
					AbstractMT mt = (AbstractMT) sma.getAbsMsg();
					SwiftMessage swiftMsg = mt.getSwiftMessage();
					SwiftBlock4 b4 = swiftMsg.getBlock4();
					String key = "";
					List<Tag> t20 = b4.getTagsByNumber(20);
					List<Tag> t50 = b4.getTagsByNumber(50);
					List<Tag> t52 = b4.getTagsByNumber(52);
					List<Tag> t53 = b4.getTagsByNumber(53);
					List<Tag> t56 = b4.getTagsByNumber(56);
					List<Tag> t57 = b4.getTagsByNumber(57);
					List<Tag> t58 = b4.getTagsByNumber(58);
					List<Tag> t59 = b4.getTagsByNumber(59);

					SwfReglasmerc mkt = new SwfReglasmerc();
					SwfReglasmerc mkta = new SwfReglasmerc();
					BIC bic = new BIC(swiftMessage.getReceiver());
					mkta.setRhdCurrency(swiftMessage.getCurrency());
					mkta.setMktCustobic(swiftMessage.getReceiver());
					mkt.setRhdCurrency(swiftMessage.getCurrency());
					
					mkt.setRhdCountry(bic.getCountry());
					mkta.setRhdCountry(bic.getCountry());
					
					mkt.setMktPaymentcurr(swiftMessage.getCurrency());
					mkta.setMktPaymentcurr(swiftMessage.getCurrency());
					
					mkt.setRhdMethodtype(sma.getTypeMessage() + "-" + f.getName());
					mkta.setRhdMethodtype(sma.getTypeMessage() + "-" + f.getName());
					mkta.setRhdSecurity("TITS");
					mkta.setRhdMethodtype("SEC");
					
					if (sma.getTypeMessage().equals("103") || sma.getTypeMessage().equals("202")) {
						mkta.setRhdMethodtype("CASH");
						mkta.setRhdSecurity("CSH");
						mkt.setRhdCountry(swiftMessage.getCurrency());
						mkta.setRhdCountry(swiftMessage.getCurrency());
					}
					
					mkt.setRhdSecurity(mkta.getRhdSecurity());
					mkt.setRhdMethodtype(mkta.getRhdMethodtype());
					
					if (t20.size() > 0) {
						Field fld = t20.get(0).asField();
						mkt.setRhdAccesscode(fld.getValueDisplay());
						mkta.setRhdAccesscode(fld.getValueDisplay());
					}
					
					if (t50.size() > 0) {
						Field fld = t50.get(0).asField();
						log.info("	{} => {} val: {}", fld.getName(), fld.getComponents(), fld.getValueDisplay());

						if (fld.letterOption() == 'F') {
							mkt.setMktInstbic(null);
							mkt.setMktInstid(null);
							mkt.setMktInstname(fld.getComponent(3));
							mkt.setMktInstaddress(null);
							mkt.setMktInstctry(null);
							mkt.setMktCtacontab(fld.getComponent(1));
						} else if (fld.letterOption() == 'K') {
							mkt.setMktInstbic(null);
							mkt.setMktInstid(null);
							mkt.setMktInstname(fld.getComponent(2));
							mkt.setMktInstaddress(null);
							mkt.setMktInstctry(null);
							mkt.setMktCtacontab(fld.getComponent(1));
						}
					}
					if (t52.size() > 0) {
						Field fld = t52.get(0).asField();
						log.info("	{} => {} val: {}", fld.getName(), fld.getComponents(), fld.getValueDisplay());
						if (fld.letterOption() == 'A') {
							mkt.setMktInstbic(fld.getComponent(3));
							mkt.setMktInstid(null);
							mkt.setMktInstname(null);
							mkt.setMktInstaddress(null);
							mkt.setMktInstctry(null);
							mkt.setMktCtacontab(null);

						} else if (fld.letterOption() == 'D') {
							mkt.setMktInstbic(null);
							mkt.setMktInstid(null);
							mkt.setMktInstname(fld.getComponent(3));
							mkt.setMktInstaddress(null);
							mkt.setMktInstctry(null);
							mkt.setMktCtacontab(null);
						}
					}
					if (t53.size() > 0) {
						Field fld = t53.get(0).asField();
						log.info("	{} => {} val: {}", fld.getName(), fld.getComponents(), fld.getValueDisplay());
						if (fld.letterOption() == 'A') {
							//mkta.setMktCtaglbcusto(fld.getComponent(2));
						} else if (fld.letterOption() == 'B') {
							mkta.setMktCtaglbcusto(fld.getComponent(2));
							mkta.setMktInstname(fld.getComponent(3));
						}
					}

					if (t58.size() > 0) {
						Field fld = t58.get(0).asField();
						log.info("	{} => {} val: {}", fld.getName(), fld.getComponents(), fld.getValueDisplay());
						mkt.setMktCtaglbcusto(fld.getComponent(2));
						IBAN iban = new IBAN(fld.getComponent(2));
						boolean isIban = iban.isValid();
						if (isIban)
							mkt.setMktIdpartdepo2(fld.getComponent(2));
						mkt.setMktCustobic(swiftMessage.getReceiver());
						if (fld.letterOption() == 'A') {
							mkt.setMktRegbic(fld.getComponent(3));
							mkt.setMktRegname(null);
							mkt.setMktRegaddress(null);
							mkt.setMktRegcity(null);
							mkt.setMktRegctry(null);

						} else if (fld.letterOption() == 'D') {
							mkt.setMktRegbic(null);
							boolean isFW = fld.getComponent(2) != null && fld.getComponent(2).startsWith("/FW");
							if (isFW) {
								mkt.setMktIdpartdepo1(fld.getComponent(2));
								mkt.setRhdMethodtype("FED");
							}
							mkt.setMktRegname(fld.getComponent(3));
							mkt.setMktRegaddress(null);
							mkt.setMktRegcity(null);
							mkt.setMktRegctry(null);
						}
					}
					if (t59.size() > 0) {
						Field fld = t59.get(0).asField();
						log.info("	{} => {} val: {}", fld.getName(), fld.getComponents(), fld.getValueDisplay());
						IBAN iban = new IBAN(fld.getComponent(1));
						boolean isIban = iban.isValid();
						if (isIban)
							mkt.setMktIdpartdepo2(fld.getComponent(1));
						mkt.setMktCtaglbcusto(fld.getComponent(1));
						mkt.setMktCustobic(swiftMessage.getReceiver());						
						if (fld.letterOption() == 'A') {
							mkt.setMktRegbic(fld.getComponent(2));
							mkt.setMktRegname(null);
							mkt.setMktRegaddress(fld.getComponent(3));
							mkt.setMktRegcity(null);
							mkt.setMktRegctry(null);
						} else if (fld.letterOption() == 'F') {
							mkt.setMktRegbic(null);
							mkt.setMktRegname(fld.getComponent(3));
							mkt.setMktRegaddress(fld.getComponent(5));
							mkt.setMktRegcity(null);
							mkt.setMktRegctry(null);
						} else if (fld.letterOption() == null) {
							mkt.setMktRegbic(null);
							mkt.setMktRegname(fld.getComponent(2));
							mkt.setMktRegaddress(fld.getComponent(3));
							mkt.setMktRegcity(null);
							mkt.setMktRegctry(null);
						}
					}
					
					if (t57.size() > 0) {
						Field fld = t57.get(0).asField();
						log.info("	{} => {} val: {}", fld.getName(), fld.getComponents(), fld.getValueDisplay());
						mkt.setMktCustobic(null);
						mkt.setMktRelationship("S");
						
						if (fld.letterOption() == 'A') {
							mkt.setMktSubagentname(null);
							mkt.setMktSubagentaddress(null);
							mkt.setMktSubagentctry(null);
							// a/c#iban at gc
							IBAN iban = new IBAN(fld.getComponent(2));
							boolean isIban = iban.isValid();
							mkt.setMktCtalocalagent(fld.getComponent(2));
							if (isIban)
								mkt.setMktIdpartdepo2(fld.getComponent(2));
							mkt.setMktSubagentbic(fld.getComponent(3));							
							mkt.setMktCustobic(fld.getComponent(3));
						} else if (fld.letterOption() == 'D') {
							mkt.setMktSubagentname(fld.getComponent(3));
							mkt.setMktSubagentaddress(null);
							mkt.setMktSubagentbic(null);
							mkt.setMktSubagentctry(null);
							boolean isFW = fld.getComponent(2) != null && fld.getComponent(2).startsWith("/FW");
							if (isFW) {
								mkt.setMktAgentid(fld.getComponent(2));		
								mkt.setRhdMethodtype("FED");
							} else {
								mkt.setMktCtalocalagent(fld.getComponent(2));
							}
							
							mkt.setMktCustoname(fld.getComponent(3));
						}
					}
					if (t56.size() > 0) {
						Field fld = t56.get(0).asField();
						log.info("	{} => {} val: {}", fld.getName(), fld.getComponents(), fld.getValueDisplay());
						mkt.setMktRelationship("C");						
						if (fld.letterOption() == 'A') {
							mkt.setMktCorrespname(null);
							mkt.setMktCorrespbic(fld.getComponent(3));
							mkt.setMktCorrespaddress(null);
							mkt.setMktCorrespctry(null);
							mkt.setMktCorrespcity(null);
							mkt.setMktCorrespctacash(fld.getComponent(2));
						

						} else if (fld.letterOption() == 'D') {
							mkt.setMktCorrespname(fld.getComponent(3));
							mkt.setMktCorrespbic(null);
							mkt.setMktCorrespaddress(null);
							mkt.setMktCorrespctry(null);
							mkt.setMktCorrespcity(null);
							
							boolean isFW = fld.getComponent(2) != null && fld.getComponent(2).startsWith("/FW");
							if (isFW) {
								mkt.setMktIdpartdepo2(fld.getComponent(2));
								mkt.setRhdMethodtype("FED");
							} else {
								mkt.setMktCtalocalagent(fld.getComponent(2));
							}
							mkt.setMktCorrespctacash(fld.getComponent(1));							
							//mkt.setMktCorrespctasec(fld.getComponent(1));
						}
					}
					mkt.setMktCashctanumber(mkta.getMktCashctanumber());
					mkt.setMktReceivingagebic(mkta.getMktCustobic());
					mkta.setRhdMethodtype(mkt.getRhdMethodtype());
					if (!StringUtils.isBlank(mkt.getMktCustobic())) {
//						bic = new BIC(mkt.getMktCustobic());
//						mkt.setRhdCountry(bic.getCountry());	
					}
					
//					mkt.setMktReceivingagebic(null);
////					mkt.setMktCtaglbcusto(null);
//					
//					mkt.setMktCustoaddress(null);
//					mkt.setMktCustocity(null);
//					mkt.setMktCustocountry(null);
//					mkt.setMktCashctanumber(null);
//					mkt.setMktPaymentcurr(null);
//					mkt.setMktAltercurr(null);
//					//mkt.setMktIdpartdepo1(null);
//					mkt.setMktIdpartdepo2(null);
//					mkt.setMktIdpartdepo3(null);
//					//mkt.setMktAgentid(null);
//					mkt.setMktPartname(null);
//					mkt.setMktPartcity(null);
//					mkt.setMktPartctry(null);
//
//					mkt.setMktAlterctacash(null);
//					mkt.setMktInfoadic(null);
					
					lc.add(mkt.toStringSH());
					lca.add(mkta.toStringSH());
				}
			} catch (Exception e) {
				log.error("Error " + e.getMessage());
			}
		});
		
		try {
			UtilsFile.grabaEnArchivo(lc, "e:/tmp/fplano.txt");
			UtilsFile.grabaEnArchivo(lca, "e:/tmp/fplanoa.txt");
			log.info("fffffffffffinnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}			
	}

}
