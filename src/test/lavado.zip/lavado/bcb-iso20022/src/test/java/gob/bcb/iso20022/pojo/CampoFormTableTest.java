package gob.bcb.iso20022.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.Test;

public class CampoFormTableTest {

	@Test
	public void addFact() {
		Foo ba = new Foo();
		ba.setName("fooo name");

		Bar bar = new Bar();
		bar.setAge(100);
		bar.setName("nombre bar");

		CampoFormTable cft = new CampoFormTable("dbtr", ba)//
				.recProps()//
		;
		cft.newSEnt("cta")//
				.putAtr("nro", bar.getAge())//
				.putAtr("desccta", bar.getName())//
				.putAtr("bic", "ASDF2563")//
				.putAtr("count", null)//
				.putAtr("amount", new BigDecimal("5236.36"))//
				.putAtr("amount2", null)//
		;

		System.out.println("pojos: " + cft.getSubEnt().size());

		cft.getAtrib().forEach((k, v) -> {
			System.out.println("atribs key: " + k + " val key: " + v.toStringCF());
		});
		
		cft.getSubEnt().forEach((k, v) -> {
			System.out.println("pojo cta.key: " + k + " val key: " + v.getName());
		});

		System.out.println("atrib age: " + cft.atrS("name"));
		System.out.println("cta.nro: " + cft.sEnt("cta").fld("nro"));
		System.out.println("cta.amount: " + cft.sEnt("cta").fld("amount"));
		System.out.println("cta.amount: " + cft.sEnt("cta").fld("amount2"));		
		System.out.println("cta.bic: " + cft.sEnt("cta").fld("bic"));
		System.out.println("cta.bicx: " + cft.sEnt("cta").fld("bicx"));
		System.out.println("cta.count: " + cft.sEnt("cta").fldD("count"));
	}

	public class Bar {
		private String name = "dog";
		private boolean woof = true;
		private int age = 14;
		private String assignTest = "";
		private List<Integer> testList = new ArrayList<Integer>();
		private Integer[] intarray = new Integer[1];

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public boolean isWoof() {
			return woof;
		}

		public void setWoof(boolean woof) {
			this.woof = woof;
		}

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		public boolean isFoo(Object obj) {
			return obj instanceof Foo;
		}

		public String getAssignTest() {
			return assignTest;
		}

		public void setAssignTest(String assignTest) {
			this.assignTest = assignTest;
		}

		public List<Integer> getTestList() {
			return testList;
		}

		public void setTestList(List<Integer> testList) {
			this.testList = testList;
		}

		public String happy() {
			return "happyBar";
		}

//		public static int staticMethod() {
//			return 1;
//		}

		public Integer[] getIntarray() {
			return intarray;
		}

		public void setIntarray(Integer[] intarray) {
			this.intarray = intarray;
		}

		public boolean equals(Object o) {
			return o instanceof Bar;
		}
	}

	public class Foo {
		private Bar bar = new Bar();
		public String register;
		public String aValue = "";
		public String bValue = "";
		private String name = "dog";
		private int countTest = 0;
		private boolean boolTest = true;
		private char charTest;
		public char charTestFld;
		private Collection collectionTest;
//		private SampleBean sampleBean = new SampleBean();
		public Bar publicBar = new Bar();
		// public static final Bar STATIC_BAR = new Bar();

		private char[] charArray;

		private char[][] charArrayMulti;

		public void abc() {
		}

		public Bar getBar() {
			return bar;
		}

		public void setBar(Bar bar) {
			this.bar = bar;
		}

		public String happy() {
			return "happyBar";
		}

		public String toUC(String s) {
			register = s;
			return s.toUpperCase();
		}

		public int getNumber() {
			return 4;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Collection getCollectionTest() {
			return collectionTest;
		}

		public void setCollectionTest(Collection collectionTest) {
			this.collectionTest = collectionTest;
		}

//		public SampleBean getSampleBean() {
//			return sampleBean;
//		}
//
//		public void setSampleBean(SampleBean sampleBean) {
//			this.sampleBean = sampleBean;
//		}

		public int getCountTest() {
			return countTest;
		}

		public void setCountTest(int countTest) {
			this.countTest = countTest;
		}

		public boolean isBoolTest() {
			return boolTest;
		}

		public void setBoolTest(boolean boolTest) {
			this.boolTest = boolTest;
		}

		public char getCharTest() {
			return charTest;
		}

		public void setCharTest(char charTest) {
			this.charTest = charTest;
		}

		public char[] getCharArray() {
			return charArray;
		}

		public void setCharArray(char[] charArray) {
			this.charArray = charArray;
		}

		public char[][] getCharArrayMulti() {
			return charArrayMulti;
		}

		public void setCharArrayMulti(char[][] charArrayMulti) {
			this.charArrayMulti = charArrayMulti;
		}

		public boolean equals(Object o) {
			return o instanceof Foo;
		}
	}

}
