package gob.bcb.iso20022.swift.saa;

import java.io.IOException;
import java.io.StringReader;
import java.security.InvalidAlgorithmParameterException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXSource;

import org.apache.commons.lang3.Validate;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import com.prowidesoftware.swift.model.MxId;
import com.prowidesoftware.swift.model.MxSwiftMessage;
import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;
import com.prowidesoftware.swift.model.mx.MxParseUtils;
import com.prowidesoftware.swift.model.mx.MxReadParams;
import com.prowidesoftware.swift.model.mx.NamespaceAndElementFilter;
import com.prowidesoftware.swift.model.mx.NamespaceReader;
import com.prowidesoftware.swift.utils.SafeXmlUtils;

import gob.bcb.iso20022.core.xml.JaxBConversionService;
import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.utils.UtilsFile;

public class DataPDUWriterTest {
	private static final Logger log = LoggerFactory.getLogger(DataPDUWriterTest.class);

//	@Test
	public void dataPDUFromXmlTest() {
		try {
			log.info("======== inicio dataPDUFromXmlTest======================");
			DataPDUWriter w = new DataPDUWriter();
			//String xmlPDU = w.mapToSaaXMLj(mapPropsSaa1());
			String xmlPDU = XmlToMap.xmlSaaFromXPath(mapPropsSaa1(), "");
			boolean existDataPDU = NamespaceReader.elementExists(xmlPDU, "DataPDU");
			boolean existDoc = NamespaceReader.elementExists(xmlPDU, "Document");
			boolean existHdr = NamespaceReader.elementExists(xmlPDU, "AppHdr");

			Optional<String> nsDoc = NamespaceReader.findDocumentNamespace(xmlPDU);
			log.info((nsDoc.isPresent() ? nsDoc.get() : "NSNONE") + " existDoc? " + existDoc + " ***existDataPDU? " + existDataPDU + "***existHdr ? "
					+ existHdr + "******* xmlPDU " + xmlPDU);
			DataPDU pdu = w.xml(xmlPDU).getDataPDU();
			log.info("SenderReference " + pdu.getHeader().getMessage().getSenderReference());

			Optional<MxId> id = MxParseUtils.identifyMessage(xmlPDU);
			log.info("MxId " + id.isPresent());
			MxId idMx = new MxId("pacs.008.001.09");
			AbstractMX source = AbstractMX.parse(xmlPDU, idMx);
			// log.info(" HDR $$$$$$$$$$$$ \n" + hdr.xml());
			log.info("	*************** MX ************ \n " + source.message());

			SwiftMessageAbstract sm = FactoryParser.createParser(xmlPDU);
			log.info("	*************** sm.getMenPlano() ************ \n " + sm.getMenPlano());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	 //@Test
	public void dataPDUFromXmlNSTest() {
		try {
			log.info("======== inicio dataPDUFromXmlNSTest======================");
			String nfile = "src/test/resources/mxs/saaconns.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			String xmlPDU = UtilsFile.readFileAsString2(nfile);
			DataPDUWriter w = new DataPDUWriter();
			boolean existDataPDU = NamespaceReader.elementExists(xmlPDU, "DataPDU");
			boolean existHdr = NamespaceReader.elementExists(xmlPDU, "AppHdr");
			log.info("***existDataPDU? " + existDataPDU + "***existHdr ? " + existHdr + "******* xmlPDU ");
			DataPDU pdu = w.xml(xmlPDU).getDataPDU();
			log.info("PDU XML " + w.xmlSaa());
			
			Optional<MxId> id = MxParseUtils.identifyMessage(xmlPDU);
			log.info("MxId " + id.isPresent());
			if (id.isPresent()) {

				log.info("	MxId " + id.get().namespaceURI() + " id: " + id.get().id() + " BB: " + pdu.getBody().toString());
				final AbstractMX source = AbstractMX.parse(xmlPDU);
				// AppHdr hdr = source.getAppHdr();
				// log.info(" HDR $$$$$$$$$$$$ \n" + hdr.xml());
				log.info("	*************** MX ************ \n " + source.message());
			}

			SwiftMessageAbstract sm = FactoryParser.createParser(xmlPDU);
			log.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
			log.info(sm.getMenPlano());
			log.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++");

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	 
	 @Test
	public void dataPDUToSaaTest() {
		try {
			log.info("======== inicio dataPDUToSaaTest======================");
			String nfile = "src/test/resources/mxs/saaconns.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			String xmlPDU = UtilsFile.readFileAsString2(nfile);
			final AbstractMX source = AbstractMX.parse(xmlPDU);
			
			DataPDUWriter w = new DataPDUWriter(source); 
			DataPDU dataPDU = w.xml(xmlPDU).getDataPDU();
			String saaXml = w.xmlSaa();
			
			log.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
			log.info(saaXml);
			log.info("++++++++++++++++++++++" + (char)(0x1F) +"++++++++++++++++++++++++++++++++"+(char)(0x1F));
			sign(dataPDU, saaXml);
			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}	 
//	@Test
	public void xmlTest() {
		try {
			log.info("======== inicio ======================");
			String nfile = "src/test/resources/mxs/mx001.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			SwiftMessageAbstract ma = swfMsgAbst(nfile);
			String xmlPDU = XmlToMap.xmlSaaFromXPath(mapPropsSaa1(), "");
			DataPDUWriter w = new DataPDUWriter((AbstractMX) ma.getAbsMsg());
			//String xmlPDU = w.mapToSaaXMLj(mapPropsSaa1());
			log.info("************* xmlPDU " + xmlPDU);
			DataPDU pdu = w.xml(xmlPDU).getDataPDU();
			log.info("rev " + pdu.getRevision());
			log.info("SenderReference " + pdu.getHeader().getMessage().getSenderReference());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void xmlDataPDUFromXmlTest() {
		try {
			log.info("======== inicio xmlDataPDU======================");
			String nfile = "src/test/resources/mxs/mx001.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			SwiftMessageAbstract ma = swfMsgAbst(nfile);

			DataPDUWriter w = new DataPDUWriter((AbstractMX) ma.getAbsMsg());
			//String xmlPDU = w.mapToSaaXMLj(mapPropsSaa1());
			String xmlPDU = XmlToMap.xmlSaaFromXPath(mapPropsSaa1(), "");
			DataPDU pdu = w.xml(xmlPDU).getDataPDU();

			log.info("w.xmlPDU() " + w.xmlSaa());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}


	public void sign(DataPDU myDataPDU, String xmlSaa) throws JAXBException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, MarshalException,
			XMLSignatureException, TransformerException, ParserConfigurationException, SAXException, IOException {
		JAXBContext jaxbContext = JAXBContext.newInstance(DataPDU.class);
		// myDataPDU.setRevision("2.0.6");

		// marshall the file
		Marshaller marshaller = jaxbContext.createMarshaller();

		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		domFactory.setNamespaceAware(true);
		DocumentBuilder docBuilder = domFactory.newDocumentBuilder();
		Document doc = docBuilder.newDocument();
		DOMResult domResult = new DOMResult(doc);
		marshaller.marshal(myDataPDU, domResult);
		
		// get the document list
		//Document document = (Document) domResult.getNode();
		Document document = JaxBConversionService.getDomFromString(xmlSaa);
		// signing process
		XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");

		SignatureMethod signatureMethod = factory.newSignatureMethod("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256", null);

		CanonicalizationMethod canonicalizationMethod = factory.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (XMLStructure) null);

		List<Transform> transforms = new ArrayList<Transform>();
		transforms.add(factory.newTransform(Transform.ENVELOPED, (XMLStructure) null));
		transforms.add(factory.newTransform("http://www.w3.org/2001/10/xml-exc-c14n#", (XMLStructure) null));

		DigestMethod digestMethod = factory.newDigestMethod("http://www.w3.org/2001/04/xmlenc#sha256", null);

		Reference reference = factory.newReference("", digestMethod, transforms, null, null);
		log.info("Auiiiiiiiiiiiiiiiiiiiiiiii");
		SignedInfo signedInfo = factory.newSignedInfo(canonicalizationMethod, signatureMethod, Collections.singletonList(reference));

		String secretKey = "Abcd1234abcd1234Abcd1234abcd1234";
		SecretKeySpec secret_key = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");

		Element LAUElement = document.createElementNS("urn:swift:saa:xsd:saa.2.0", "Saa:LAU");
		LAUElement.setAttribute("xmlns:Saa", "urn:swift:saa:xsd:saa.2.0");
		Element rootElement = document.getDocumentElement();
		rootElement.appendChild(LAUElement);

		DOMSignContext domSignContext = new DOMSignContext(secret_key, LAUElement);
		domSignContext.setDefaultNamespacePrefix("ds");

		XMLSignature signature = factory.newXMLSignature(signedInfo, null);
		signature.sign(domSignContext);
		
		String s = JaxBConversionService.getStringFromDom(document, false, false);
		log.info(s);
	}

	public static SwiftMessageAbstract swfMsgAbst(String nfile) {
		try {
			// String nfile = "src/test/resources/mxs/saa01.txt"; //
			// "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			log.info("xmlMX nfile:: " + nfile);
			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			return sm;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;
	}

	public static LinkedHashMap<String, Object> mapPropsSaa() {
		LinkedHashMap<String, Object> mapSaa = new LinkedHashMap<String, Object>();
		mapSaa.put("/Saa:DataPDU/Saa:Revision", "2.0.13");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SenderReference", "BCEBBOLPAXXXDOCC 103B");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:MessageIdentifier", "pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Format", "MX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SubFormat", "Input");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:DN", "ou=xxx,o=bcebbolp,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:FullName/Saa:X1", "BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:DN", "ou=xxx,o=scblus33,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:FullName/Saa:X1", "SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:UserReference", "DOCC 103B");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:ServiceURI", "mp/mx/__mRWkJI2EeuXfsPBlWnVxg");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:MessageTypeURI", "mp/mx/__mRWkJI2EeuXfsPBlWnVxg/__mSksJI2EeuXfsPBlWnVxg");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:Priority", "Normal");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:Service", "swift.finplus");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestType", "pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestSubtype", "swift.cbprplus.02");

		return mapSaa;
	}

	public static LinkedHashMap<String, Object> mapPropsSaa1() {
		LinkedHashMap<String, Object> mapSaa = new LinkedHashMap<String, Object>();

		mapSaa.put("/Saa:DataPDU/Saa:Revision", "2.0.13");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SenderReference", "BCEBBOLPAXXXDOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:MessageIdentifier", "pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Format", "MX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SubFormat", "Input");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:DN", "ou=xxx,o=bcebbolp,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:FullName/Saa:X1", "BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:DN", "ou=xxx,o=scblus33,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:FullName/Saa:X1", "SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:UserReference", "DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:ServiceURI", "mp/mx/__mRWkJI2EeuXfsPBlWnVxg");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:MessageTypeURI", "mp/mx/__mRWkJI2EeuXfsPBlWnVxg/__mSksJI2EeuXfsPBlWnVxg");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Priority", "Normal");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Service", "swift.finplus");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestType", "pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestSubtype", "swift.cbprplus.02");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/Fr/FIId/FinInstnId/BICFI", "BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/To/FIId/FinInstnId/BICFI", "SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/BizMsgIdr", "DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/MsgDefIdr", "pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/BizSvc", "swift.cbprplus.02");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/CreDt", "2021-12-02T03:25:54+00:00");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/MsgId", "DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/CreDtTm", "9999-12-31T00:00:00+00:00");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/NbOfTxs", "1");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/SttlmMtd", "INDA");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/SttlmAcct/Id/Othr/Id", "3544020682001");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/InstrId", "DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/EndToEndId", "NOTPROVIDED");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/UETR", "035c661a-da4b-427f-ad76-b8d3182daa79");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmAmt", "8923793.51");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmDt", "2022-04-29");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/ChrgBr", "DEBT");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstgAgt/FinInstnId/BICFI", "BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstdAgt/FinInstnId/BICFI", "SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/BICFI", "CITIUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/Nm", "YACIMIENTOS PETROLIFEROS FISCALESBOLIVIANOS");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/StrtNm", "BUENO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/BldgNb", "185");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/TwnNm", "LA PAZ");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/Ctry", "BO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAcct/Id/Othr/Id", "3987");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAgt/FinInstnId/BICFI", "BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/Nm", "BANCO DE CREDITO E INVERSIONES");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/PstlAdr/TwnNm", "SANTIAGO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/PstlAdr/Ctry", "CL");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgtAcct/Id/Othr/Id", "36010307");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/Nm", "TRAFIGURA CHILE LIMITADA");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/Dept", "OFICINA 1401");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/StrtNm", "ISIDORA GOYENECHEA");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/BldgNb", "3365");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/TwnNm", "SANTIAGO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/Ctry", "CL");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id", "18553435");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/RmtInf/Ustrd",
				"PAGO A TRAFIGURA CHILE LIMITADA 21ER POST PAGO POR SUM HIDR LIQ OCCIDENTE 2021 SEGUN OP UPCA N");

		return mapSaa;
	}

	public static SAXSource createFilteredSAXSource(final String xml, final String localName) {
		XMLReader documentReader = SafeXmlUtils.reader(true, null);

		NamespaceAndElementFilter documentFilter = new NamespaceAndElementFilter(localName);
		documentFilter.setParent(documentReader);

		InputSource documentInputSource = new InputSource(new StringReader(xml));

		return new SAXSource(documentFilter, documentInputSource);
	}

	public static Object parse(final Class targetClass, final String xml, final Class<?>[] classes, final String localName, final MxReadParams params) {
		Objects.requireNonNull(targetClass, "target class to parse must not be null");
		Objects.requireNonNull(xml, "XML to parse must not be null");
		Validate.notBlank(xml, "XML to parse must not be a blank string");
		Objects.requireNonNull(classes, "object model classes aray must not be null");
		Validate.notBlank(localName, "The XML element to parse must not be null nor a blank string");
		Objects.requireNonNull(params, "unmarshalling params cannot be null");

		try {
			SAXSource saxSource = createFilteredSAXSource(xml, localName);
			log.info("saxSource " + saxSource.getSystemId());
			return parseSAXSource(saxSource, targetClass, classes, params);

		} catch (final Exception e) {
			// handleParseException(e);
			throw new RuntimeException(e);
//            return null;
		}
	}

	public static Object parseSAXSource(final SAXSource source, final Class targetClass, final Class<?>[] classes, final MxReadParams params) {
		Objects.requireNonNull(targetClass, "target class to parse must not be null");
		Objects.requireNonNull(source, "SAXSource to parse must not be null");
		Objects.requireNonNull(classes, "object model classes array must not be null");
		Objects.requireNonNull(params, "unmarshalling params cannot be null");

		try {
			JAXBContext context;
			if (params.context != null) {
				context = params.context;
			} else {
				context = JaxbContextLoader.INSTANCE.get(targetClass, classes);
			}

			final Unmarshaller unmarshaller = context.createUnmarshaller();

			if (params.adapters != null) {
				for (XmlAdapter adapter : params.adapters.asList()) {
					unmarshaller.setAdapter(adapter);
				}
			}

			JAXBElement element = unmarshaller.unmarshal(source, targetClass);
			if (element != null) {
				return element.getValue();
			}

		} catch (JAXBException | ExecutionException e) {
			throw new RuntimeException(e);
		}
		return null;
	}
}
