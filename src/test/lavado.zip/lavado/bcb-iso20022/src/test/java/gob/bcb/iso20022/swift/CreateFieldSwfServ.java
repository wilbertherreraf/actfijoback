package gob.bcb.iso20022.swift;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gob.bcb.iso20022.dao.SwfMencamposIsoDao;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.Part;

public class CreateFieldSwfServ extends CreateFieldSwf {
	private static final Log log = LogFactory.getLog(CreateFieldSwfServ.class);
	
	public CreateFieldSwfServ(SwfMsgParam swfMsgParam, SwfMencamposIsoDao swfMencamposDaoIn) {
		Instruccion instr = new Instruccion();
		instr.setSwfMsgParam(swfMsgParam);
		createService(instr,swfMencamposDaoIn);
	}
	@Override
	public void recuperarCampos( String bloque) {
		fieldSwf.instruccion.setTreeMencampos(rules());
	}
	
	public static LinkedHashMap<String, Object> mapPropsSaa1() {
		LinkedHashMap<String, Object> mapSaa = new LinkedHashMap<String, Object>();

		mapSaa.put("/Saa:DataPDU/Saa:Revision","2.0.13");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SenderReference","BCEBBOLPAXXXDOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:MessageIdentifier","pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Format","MX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SubFormat","Input");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:DN","ou=xxx,o=bcebbolp,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:FullName/Saa:X1","BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:DN","ou=xxx,o=scblus33,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:FullName/Saa:X1","SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:UserReference","DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:ServiceURI","mp/mx/__mRWkJI2EeuXfsPBlWnVxg");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:MessageTypeURI","mp/mx/__mRWkJI2EeuXfsPBlWnVxg/__mSksJI2EeuXfsPBlWnVxg");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Priority","Normal");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Service","swift.finplus");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestType","pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestSubtype","swift.cbprplus.02");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/Fr/FIId/FinInstnId/BICFI","BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/To/FIId/FinInstnId/BICFI","SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/BizMsgIdr","DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/MsgDefIdr","pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/BizSvc","swift.cbprplus.02");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/CreDt","2021-12-02T03:25:54+00:00");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/MsgId","DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/CreDtTm","9999-12-31T00:00:00+00:00");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/NbOfTxs","1");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/SttlmMtd","INDA");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/SttlmAcct/Id/Othr/Id","3544020682001");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/InstrId","DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/EndToEndId","NOTPROVIDED");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/UETR","035c661a-da4b-427f-ad76-b8d3182daa79");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmAmt","8923793.51");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmDt","2022-04-29");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/ChrgBr","DEBT");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstgAgt/FinInstnId/BICFI","BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstdAgt/FinInstnId/BICFI","SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/BICFI","CITIUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/Nm","YACIMIENTOS PETROLIFEROS FISCALESBOLIVIANOS");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/StrtNm","BUENO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/BldgNb","185");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/TwnNm","LA PAZ");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/Ctry","BO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAcct/Id/Othr/Id","3987");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAgt/FinInstnId/BICFI","BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/Nm","BANCO DE CREDITO E INVERSIONES");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/PstlAdr/TwnNm","SANTIAGO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/PstlAdr/Ctry","CL");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgtAcct/Id/Othr/Id","36010307");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/Nm","TRAFIGURA CHILE LIMITADA");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/Dept","OFICINA 1401");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/StrtNm","ISIDORA GOYENECHEA");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/BldgNb","3365");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/TwnNm","SANTIAGO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/Ctry","CL");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id","18553435");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/RmtInf/Ustrd","PAGO A TRAFIGURA CHILE LIMITADA 21ER POST PAGO POR SUM HIDR LIQ OCCIDENTE 2021 SEGUN OP UPCA N");

		return mapSaa;
	}

	public static SwfMsgParam recMsgParms(String mt, String formato) {
		SwfMsgParam swfMsgParam = new SwfMsgParam();

		swfMsgParam.setMenTypemessage(mt);
		swfMsgParam.setMenIdTMessageTx(mt);
		swfMsgParam.setMenHdrversion("head.001.001.01");
		swfMsgParam.setMenEmisor("BCEBBOLPXXX");
		swfMsgParam.setMenReceiver("SCBLUS33XXX");
		swfMsgParam.setMenBic("BCEBBOLPXXX");
		swfMsgParam.setMenCodmen(1);
		swfMsgParam.setMenCodmenOrig("123");
		swfMsgParam.setMenCodmenrefer("123ABC");
		String codigoOperacion = "ABC123";
		swfMsgParam.setMenIdoperacion(codigoOperacion);
		swfMsgParam.setMenGestion(GregorianCalendar.getInstance().get(Calendar.YEAR));
		swfMsgParam.setMenNrocorr(1);
		swfMsgParam.setMenCodmon("34");
		swfMsgParam.setMenFecreg(new Date());
		swfMsgParam.setMenFecauto(new Date());
		swfMsgParam.setMenCodusrswf("TST");
		swfMsgParam.setMenNrocorr(100);
		swfMsgParam.setMenFormato(formato);
		swfMsgParam.setMenCodapp("APPTEST");
		swfMsgParam.setMenFecvalor(new Date());
		String idMessage = "230101123ABC";
		swfMsgParam.setMenCodswift(idMessage);

		return swfMsgParam;
	}

	public static Part factDbtr() {
		Part debtr = new Part();
		debtr.setRole("debtr");

		debtr.setNm("nombre participante");
		debtr.setAddress("direccion xxx calle 88");
		debtr.setCtry("ES");
		debtr.setTwnNm("MADIR");
		return debtr;
	}
	
	public static LinkedHashMap<Integer, SwfMencampos> rules() {
		LinkedHashMap<Integer, SwfMencampos> treeMencampos = new LinkedHashMap<Integer, SwfMencampos>();
		SwfMencampos u = new SwfMencampos();
		u.setMtfNemo("1");
		u.setMtfCondicion("true"); 
		u.setMtfReglavalid("MTTOMX");
		u.setMtfNemo("01.01");
		u.setMtfDescrip("descrip");
		u.setMtfExpresion("output.valorObj=fCFNvl(notBlk(dbtr.nm),dbtr.nm,'','','')"); 
		u.setMtfXmltag("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/Nm");
		treeMencampos.put(1, u);
		return treeMencampos;
	}
}
