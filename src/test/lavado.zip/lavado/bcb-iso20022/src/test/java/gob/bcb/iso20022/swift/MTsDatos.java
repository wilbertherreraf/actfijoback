package gob.bcb.iso20022.swift;

import java.util.Arrays;
import java.util.List;

import gob.bcb.iso20022.rules.Rule;

public class MTsDatos {

	public static List<Rule> rulesMt103() {
		List<Rule> rules = Arrays.asList(
				new Rule("01.01.00.00.00.00", "MsgId", "input.containsFact({'F20'})", "Max35Text", 1 , "'01.01", "", "output.valor=F20.reference", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/MsgId" ),
				new Rule("01.02.00.00.00.00", "CreDtTm", "true", "FDATE", 1 , "'01.02", "", "", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/CreDtTm" ),
				new Rule("01.04.00.00.00.00", "NbOfTxs", "true", "Max15NumericText", 1 , "'01.04", "", "output.valor='1'", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/NbOfTxs" ),
				new Rule("01.06.00.00.00.00", "TtlIntrBkSttlmAmt", "input.containsFact({'F32AXX'})", "AMTCURR", 1 , "'01.06", "", "output.valor=F32A.amount", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/TtlIntrBkSttlmAmt" )
				.addAction("/message/Document/FIToFICstmrCdtTrf/GrpHdr/TtlIntrBkSttlmAmt/@Ccy", "outputsub.valor=F32A.currency;")//
				.addAction("/message/Document/FIToFICstmrCdtTrf/GrpHdr/TtlIntrBkSttlmAmt", "outputsub.valor=F32A.amount;")//
				,
				new Rule("01.07.00.00.00.00", "IntrBkSttlmDt", "input.containsFact({'F32AXX'})", "ISODate", 1 , "'01.07", "", "output.valor=fdate(F32A.dateAsCalendar, 'yyyy-MM-dd')", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/IntrBkSttlmDt" ),
				new Rule("01.08.01.00.00.00", "SttlmMtd", "true", "SettlementMethod1Code", 1 , "'01.08", "", "output.valor='CLRG'", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/SttlmMtd" ),
				new Rule("01.08.02.01.02.01", "Id", "input.containsFact({'F53B'})", "Max34Text", 1 , "'01.08", "", "output.valor=F53B.account", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/SttlmAcct/Id/Othr/Id" ),
				new Rule("01.08.04.01.01.00", "BICFI", "input.containsFact({'F53A'})", "BICFIIdentifier", 1 , "'01.08", "", "output.valor=F53A.bIC", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/InstgRmbrsmntAgt/FinInstnId/BICFI" ),
				new Rule("01.08.04.01.03.00", "Nm", "input.containsFact({'F53B','F53D'})", "Max140Text", 1 , "'01.08", "", "", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/InstgRmbrsmntAgt/FinInstnId/Nm" )
				.addAction("001", "outputsub.valor=F53B.location;")//
				.addAction("002", "outputsub.valor=F53D.nameAndAddressLine1;")//
				,
				new Rule("01.08.04.01.04.10", "AdrLine", "input.containsFact({'F53D'})", "GENLIST", 1 , "'01.08", "", "", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/InstgRmbrsmntAgt/FinInstnId/PstlAdr/AdrLine" )
				.addAction("001", "outputsub.valor=F53D.nameAndAddress2;")//
				.addAction("002", "outputsub.valor=F53D.nameAndAddress3;")//
				.addAction("003", "outputsub.valor=F53D.nameAndAddress4;")//
				,
				new Rule("01.08.05.01.02.01", "Id", "input.containsFact({'F53A','F53B','F53D'})", "Max34Text", 1 , "'01.08", "", "", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/InstgRmbrsmntAgtAcct/Id/Othr/Id" )
				.addAction("001", "outputsub.valor=F53A.account;")//
				.addAction("002", "outputsub.valor=F53B.account;")//
				.addAction("002", "outputsub.valor=F53D.account;")//
				,
				new Rule("01.08.06.01.01.00", "BICFI", "input.containsFact({'F54A'})", "BICFIIdentifier", 1 , "'01.08", "", "output.valor=F54A.bIC", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/InstdRmbrsmntAgt/FinInstnId/BICFI" ),
				new Rule("01.08.06.01.03.00", "Nm", "input.containsFact({'F54B','F54D'})", "Max140Text", 1 , "'01.08", "", "", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/InstdRmbrsmntAgt/FinInstnId/Nm")
				.addAction("001", "outputsub.valor=F54B.location;")//
				.addAction("002", "outputsub.valor=F54D.nameAndAddressLine1;")//
				,
				new Rule("01.08.06.01.04.10", "AdrLine", "input.containsFact({'F54D'})", "GENLIST", 1 , "'01.08", "", "", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/InstdRmbrsmntAgt/FinInstnId/PstlAdr/AdrLine")
				.addAction("002", "outputsub.valor=F54D.nameAndAddressLine2;")//
				.addAction("003", "outputsub.valor=F54D.nameAndAddressLine3;")//
				.addAction("004", "outputsub.valor=F54D.nameAndAddressLine4;")//
				,
				new Rule("01.08.07.01.02.01", "Id", "input.containsFact({'F54A','F54B','F54D'})", "Max34Text", 1 , "'01.08", "", "output.valor=F54A.account;output.valor=F54B.account;output.valor=F54D.account;", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/InstdRmbrsmntAgtAcct/Id/Othr/Id"),
				new Rule("01.08.08.01.01.00", "BICFI", "input.containsFact({'F55A'})", "BICFIIdentifier", 1 , "'01.08", "", "output.valor=F55A.bIC", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/ThrdRmbrsmntAgt/FinInstnId/BICFI" ),
				new Rule("01.08.08.01.03.00", "Nm", "input.containsFact({'F55B','F55D'})", "Max140Text", 1 , "'01.08", "", "", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/ThrdRmbrsmntAgt/FinInstnId/Nm")
				.addAction("001", "outputsub.valor=F55B.location;")//
				.addAction("002", "outputsub.valor=F55D.nameAndAddressLine1;")//
				,
				new Rule("01.08.08.01.04.10", "AdrLine", "input.containsFact({'F55D'})", "GENLIST", 1 , "'01.08", "", "", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/ThrdRmbrsmntAgt/FinInstnId/PstlAdr/AdrLine")
				.addAction("002", "outputsub.valor=F55D.nameAndAddressLine2;")//
				.addAction("003", "outputsub.valor=F55D.nameAndAddressLine3;")//
				.addAction("004", "outputsub.valor=F55D.nameAndAddressLine4;")//
				,
				new Rule("01.08.09.01.02.01", "Id", "input.containsFact({'F55A','F55B','F55D'})", "Max34Text", 1 , "'01.08", "", "output.valor=F55A.account;output.valor=F55B.account;output.valor=F55D.account;", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/ThrdRmbrsmntAgtAcct/Id/Othr/Id"),
				new Rule("01.09.03.01.00.00", "Cd", "true", "ExternalServiceLevel1Code", 1 , "'01.09", "", "output.valor='SDVA'", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/PmtTpInf/SvcLvl/Cd" ),
				new Rule("01.10.01.01.00.00", "BICFI", "", "BICFIIdentifier", 1 , "'01.10", "", "output.valor=sender.bic", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/InstgAgt/FinInstnId/BICFI" ),
				new Rule("01.11.01.01.00.00", "BICFI", "", "BICFIIdentifier", 1 , "'01.11", "", "output.valor=receiver.bic", "/message/Document/FIToFICstmrCdtTrf/GrpHdr/InstdAgt/FinInstnId/BICFI" ),
				new Rule("02.01.01.00.00.00", "InstrId", "input.containsFact({'F20'})", "Max35Text", 1 , "'02.01", "", "output.valor=F20.value", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/InstrId" ),
				new Rule("02.01.02.00.00.00", "EndToEndId", "input.containsFact({'F70'})", "Max35Text", 1 , "'02.01", "", "output.valor=F70.value", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/EndToEndId" ),
				new Rule("02.03.00.00.00.00", "IntrBkSttlmAmt", "input.containsFact({'F32A'})", "AMTCURR", 1 , "'02.03", "", "output.valor=F32A.amount;output.valor=F32A.currency", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmAmt")
				.addAction("/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmAmt/@Ccy", "outputsub.valor=F32A.currency;")//
				.addAction("/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmAmt", "outputsub.valor=F32A.amount;")//
				,
				new Rule("02.04.00.00.00.00", "IntrBkSttlmDt", "input.containsFact({'F32A'})", "ISODate", 1 , "'02.04", "", "output.valor=fdate(F32A.dateAsCalendar, 'yyyy-MM-dd')", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmDt" ),
				new Rule("02.06.01.00.00.00", "DbtDtTm", "input.containsFact({'F13C'})", "FDATE", 1 , "'02.06", "", "output.valor=F13C.timeIndicationAsCalendar", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/SttlmTmIndctn/DbtDtTm" ),
				new Rule("02.10.00.00.00.00", "InstdAmt", "input.containsFact({'F33B'})", "AMTCURR", 1 , "'02.10", "", "output.valor=F33B.amount;output.valor=F33B.currency", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstdAmt")
				.addAction("/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstdAmt/@Ccy", "outputsub.valor=F33B.currency;")//
				.addAction("/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstdAmt", "outputsub.valor=F33B.amount;")//				
				,
				new Rule("02.11.00.00.00.00", "XchgRate", "input.containsFact({'F36'})", "BaseOneRate", 1 , "'02.11", "", "output.valor=F36.rate", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/XchgRate" ),
				new Rule("02.12.00.00.00.00", "ChrgBr", "input.containsFact({'F23B'})", "ChargeBearerType1Code", 1 , "'02.12", "", "output.valor=F23B.type", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/ChrgBr" ),
				new Rule("02.18.01.01.00.00", "BICFI", "input.containsFact({'F56A'})", "BICFIIdentifier", 1 , "'02.18", "", "output.valor=F56A.bIC", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/BICFI" ),
				new Rule("02.18.01.03.00.00", "Nm", "input.containsFact({'F56B','F56D'})", "Max140Text", 1 , "'02.18", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/Nm")
				.addAction("001", "outputsub.valor=F56B.location;")//
				.addAction("002", "outputsub.valor=F56D.nameAndAddressLine1;")//
				,
				new Rule("02.19.01.02.01.00", "Id", "input.containsFact({'F56A','F56B','F56D'})", "Max34Text", 1 , "'02.19", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrmyAgt1Acct/Id/Othr/Id")
				.addAction("001", "outputsub.valor=F56A.account;")//
				.addAction("002", "outputsub.valor=F56B.account;")//
				.addAction("002", "outputsub.valor=F56D.account;")//
				,
				new Rule("02.26.01.00.00.00", "Nm", "input.containsFact({'F50F','F50K'})", "Max140Text", 1 , "'02.26", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/Nm")
				.addAction("001", "outputsub.valor=F50F.nameAndAddress1;")//
				.addAction("002", "outputsub.valor=F50K.nameAndAddressLine1;")//
				,
				new Rule("02.26.02.10.00.00", "AdrLine", "input.containsFact({'F50F'})", "GENLIST", 1 , "'02.26", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/AdrLine")
				.addAction("001", "outputsub.valor=F50F.nameAndAddress2;")//
				.addAction("001", "outputsub.valor=F50F.nameAndAddress3;")//
				.addAction("001", "outputsub.valor=F50F.nameAndAddress4;")//
				.addAction("001", "outputsub.valor=F50K.nameAndAddressLine2;")//
				.addAction("001", "outputsub.valor=F50K.nameAndAddressLine3;")//
				,
				new Rule("02.26.03.01.01.00", "AnyBIC", "input.containsFact({'F50A'})", "AnyBICIdentifier", 1 , "'02.26","", "output.valor=F50A.bIC", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/Id/OrgId/AnyBIC" ),
				new Rule("02.27.01.02.01.00", "Id", "input.containsFact({'F50A','F50F','F50K'})", "Max34Text", 1 , "'02.27", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAcct/Id/Othr/Id")
				.addAction("001", "outputsub.valor=F50A.account;")//
				.addAction("002", "outputsub.valor=F50F.account;")//
				.addAction("002", "outputsub.valor=F50K.account;")//				
				,
				new Rule("02.28.01.01.00.00", "BICFI", "", "BICFIIdentifier", 1 , "'02.28", "", "output.valor=F52A.bIC", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAgt/FinInstnId/BICFI" ),
				new Rule("02.28.01.03.00.00", "Nm", "input.containsFact({'F52D'})", "Max140Text", 1 , "'02.28", "", "output.valor=F52D.nameAndAddressLine1;", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAgt/FinInstnId/Nm" ),
				new Rule("02.28.01.04.10.00", "AdrLine", "input.containsFact({'F52D'})", "GENLIST", 1 , "'02.28", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAgt/FinInstnId/PstlAdr/AdrLine")
				.addAction("001", "outputsub.valor=F52D.nameAndAddressLine2;")//
				.addAction("002", "outputsub.valor=F52D.nameAndAddressLine3;")//
				.addAction("003", "outputsub.valor=F52D.nameAndAddressLine4;")//
				,
				new Rule("02.29.01.02.01.00", "Id", "input.containsFact({'F52A'})", "Max34Text", 1 , "'02.29", "", "output.valor=F52A.account;output.valor=F52D.account;", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAgtAcct/Id/Othr/Id"),
				new Rule("02.30.01.01.00.00", "BICFI", "", "BICFIIdentifier", 1 , "'02.30", "", "output.valor=F57A.bIC", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/BICFI" ),
				new Rule("02.30.01.03.00.00", "Nm", "input.containsFact({'F57B','F57C','F57D'})", "Max140Text", 1 , "'02.30", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/Nm")
				.addAction("001", "outputsub.valor=F57B.location;")//
				.addAction("002", "outputsub.valor=F57C.component1;")//
				.addAction("003", "outputsub.valor=F57D.nameAndAddressLine1")//				
				,
				new Rule("02.30.01.04.10.00", "AdrLine", "input.containsFact({'F57D'})", "GENLIST", 1 , "'02.30", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/PstlAdr/AdrLine")
				.addAction("001", "outputsub.valor=F57D.nameAndAddressLine2;")//
				.addAction("002", "outputsub.valor=F57D.nameAndAddressLine3;")//
				,
				new Rule("02.31.01.02.01.00", "Id", "input.containsFact({'F57A','F57C','F57B','F57D'})", "Max34Text", 1 , "'02.31", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgtAcct/Id/Othr/Id" )
				.addAction("001", "outputsub.valor=F57A.account;")//
				.addAction("002", "outputsub.valor=F57B.account;")//
				.addAction("002", "outputsub.valor=F57C.account;")//
				.addAction("002", "outputsub.valor=F57D.account;")//
				,
				new Rule("02.32.01.00.00.00", "Nm", "input.containsFact({'F59'})", "Max140Text", 1 , "'02.32", "", "output.valor=F59.nameAndAddressLine1;", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/Nm" ),
				new Rule("02.32.02.10.00.00", "AdrLine", "input.containsFact({'F59'})", "GENLIST", 1 , "'02.32", "", "", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/AdrLine" )
				.addAction("001", "outputsub.valor=F59.nameAndAddressLine2;")//
				.addAction("001", "outputsub.valor=F59.nameAndAddressLine3;")//
				,
				new Rule("02.32.03.01.01.00", "AnyBIC", "", "AnyBICIdentifier", 1 , "'02.32", "", "output.valor=F59A.bIC;", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/Id/OrgId/AnyBIC" ),
				new Rule("02.33.01.00.00.00", "Id", "", "AccountIdentification4Choice", 1 , "'02.33", "", "output.valor=F59.account;output.valor=F59A.account;", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Id" ),
				new Rule("02.35.02.00.00.00", "InstrInf", "", "Max140Text", 1 , "'02.35", "", "F72.narrativeLine1;F72.narrativeLine2;F72.narrativeLine3;", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstrForCdtrAgt/InstrInf" ),
				new Rule("02.41.01.00.00.00", "Ustrd", "", "Max140Text", 1 , "'02.41", "", "F70.narrativeLine1;F70.narrativeLine2;F70.narrativeLine3;", "/message/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/RmtInf/Ustrd" )
				);
		
		rules.forEach(r -> {
			if (!r.getOutcome().equals("GENLIST") && !r.getOutcome().equals("AMTCURR") && !r.getOutcome().equals("FDATE")) {
				r.setOutcome("MTTOMX");
			}
		});
		return rules;
	}

	
	public static List<Rule> rulesMt202() {
		List<Rule> rules = Arrays.asList(
				new Rule("01.01.00.00.00.00", "MsgId", "true", "MTTOMX", 1 , "r01.01", "", "output.valor='NONREF'", "/message/Document/FICdtTrf/GrpHdr/MsgId" ),
				new Rule("01.02.00.00.00.00", "CreDtTm", "true", "MTTOMX", 1 , "r01.02", "", "output.valor=isoDTime()", "/message/Document/FICdtTrf/GrpHdr/CreDtTm" ),
				new Rule("01.04.00.00.00.00", "NbOfTxs", "true", "MTTOMX", 1 , "r01.04", "", "output.valor='1'", "/message/Document/FICdtTrf/GrpHdr/NbOfTxs" ),
				new Rule("01.08.01.00.00.00", "SttlmMtd", "true", "MTTOMX", 1 , "r01.08", "", "output.valor='CLRG'", "/message/Document/FICdtTrf/GrpHdr/SttlmInf/SttlmMtd" ),
				new Rule("01.08.02.01.02.01", "Id", "input.containsFact({'F53B'})", "MTTOMX", 1 , "'01.08", "", "output.valor=F53B.account", "/message/Document/FICdtTrf/GrpHdr/SttlmInf/SttlmAcct/Id/Othr/Id" ),
				
				new Rule("01.08.04.01.03.00", "Nm", "input.containsFact({'F53B','F53D'})", "MTTOMX", 1 , "'01.08", "", "", "/message/Document/FICdtTrf/GrpHdr/SttlmInf/InstgRmbrsmntAgt/FinInstnId/Nm" )
				.addAction("001", "outputsub.valor=F53B.location;")//
				.addAction("002", "outputsub.valor=F53D.nameAndAddressLine1;")//
				,
				
				new Rule("02.01.01.00.00.00", "InstrId", "input.containsFact({'F20'})", "MTTOMX", 1 , "r02.01", "", "output.valor=F20.reference", "/message/Document/FICdtTrf/CdtTrfTxInf/PmtId/InstrId" ),
				new Rule("02.01.02.00.00.00", "EndToEndId", "input.containsFact({'F21'})", "MTTOMX", 1 , "r02.01", "", "output.valor=F21.reference", "/message/Document/FICdtTrf/CdtTrfTxInf/PmtId/EndToEndId" ),
				new Rule("02.01.04.00.00.00", "UETR", "true", "MTTOMX", 1 , "r02.01", "", "output.valor=genUIID()", "/message/Document/FICdtTrf/CdtTrfTxInf/PmtId/UETR" ),
				new Rule("02.03.00.00.00.00", "IntrBkSttlmAmt", "input.containsFact({'F32A'})", "AMTCURR", 1 , "r02.03", "", "", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrBkSttlmAmt" )
				.addAction("/message/Document/FICdtTrf/CdtTrfTxInf/IntrBkSttlmAmt/@Ccy", "outputsub.valor=F32A.currency;")//
				.addAction("/message/Document/FICdtTrf/CdtTrfTxInf/IntrBkSttlmAmt", "outputsub.valor=F32A.amount;")//
				,
				new Rule("02.04.00.00.00.00", "IntrBkSttlmDt", "input.containsFact({'F32A'})", "MTTOMX", 1 , "r02.04", "", "output.valor=isoDate(F32A.dateAsCalendar)", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrBkSttlmDt" ),
				new Rule("02.06.01.00.00.00", "DbtDtTm", "input.containsFact({'F13C'}) and F13C.contains('SNDTIME')", "MTTOMX", 1 , "r02.06", "", "output.valor=isoDTime(F13C.timeAsCalendar)", "/message/Document/FICdtTrf/CdtTrfTxInf/SttlmTmIndctn/DbtDtTm" ),
				new Rule("02.06.02.00.00.00", "CdtDtTm", "input.containsFact({'F13C'}) and F13C.contains('RNCTIME')", "MTTOMX", 1 , "r02.06", "", "output.valor=isoDTime(F13C.timeAsCalendar)", "/message/Document/FICdtTrf/CdtTrfTxInf/SttlmTmIndctn/CdtDtTm" ),
				new Rule("02.08.01.01.00.00", "BICFI", "input.containsFact({'F72XX'}) and F72.contains('INS')", "MTTOMX", 1 , "r02.08", "", "output.valor=F72.narrativeLine1", "/message/Document/FICdtTrf/CdtTrfTxInf/PrvsInstgAgt1/FinInstnId/BICFI" ),
				new Rule("02.14.01.01.00.00", "BICFI", "input.containsFact({'sender'})", "MTTOMX", 1 , "r02.14", "", "output.valor=sender.bic", "/message/Document/FICdtTrf/CdtTrfTxInf/InstgAgt/FinInstnId/BICFI" ),
				new Rule("02.14.01.02.01.01", "Cd", "input.containsFact({'F72'})", "MTTOMX", 1 , "r02.14", "", "", "/message/Document/FICdtTrf/CdtTrfTxInf/InstgAgt/FinInstnId/ClrSysMmbId/ClrSysId/Cd" ),
				new Rule("02.15.01.01.00.00", "BICFI", "input.containsFact({'receiver'})", "MTTOMX", 1 , "r02.15", "", "output.valor=receiver.bic", "/message/Document/FICdtTrf/CdtTrfTxInf/InstdAgt/FinInstnId/BICFI" ),
				new Rule("02.16.01.01.00.00", "BICFI", "input.containsFact({'F56A'})", "MTTOMX", 1 , "r02.16", "", "output.valor=F56A.bIC", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/BICFI" ),
				new Rule("02.16.01.02.01.01", "Cd", "input.containsFact({'F56A'})", "MTTOMX", 1 , "r02.16", "", "output.valor=buscarCd(F56A.account)", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/ClrSysMmbId/ClrSysId/Cd" ),
				new Rule("02.16.01.02.02.00", "MmbId", "input.containsFact({'F56A'})", "MTTOMX", 1 , "r02.16", "", "output.valor=F56A.account.substring(3)", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/ClrSysMmbId/MmbId" ),
				new Rule("02.16.01.04.00.00", "Nm", "input.containsFact({'F56D'})", "MTTOMX", 1 , "r02.16", "", "", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/Nm" )
				.addAction("002", "outputsub.valor=F56D.nameAndAddressLine1;")//
				,
				new Rule("02.16.01.05.16.00", "AdrLine", "input.containsFact({'F56D'})", "GENLIST", 1 , "r02.16", "", "output.valor=F56D.nameAndAddress", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/PstlAdr/AdrLine" )
				.addAction("002", "outputsub.valor=F56D.nameAndAddressLine2;")//
				,
				new Rule("02.17.01.02.01.00", "Id", "input.containsFact({'F56A','F56D'})", "MTTOMX", 1 , "r02.17", "", "", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1Acct/Id/Othr/Id" )
				.addAction("001", "outputsub.valor=F57A.account;")//
				.addAction("002", "outputsub.valor=F57D.account;")//
				,
				new Rule("02.23.01.01.00.00", "BICFI", "input.containsFact({'F52A'})", "MTTOMX", 1 , "r02.23", "", "output.valor=F52A.bIC", "/message/Document/FICdtTrf/CdtTrfTxInf/Dbtr/FinInstnId/BICFI" ),
				new Rule("02.23.01.04.00.00", "Nm", "input.containsFact({'F52D'})", "MTTOMX", 1 , "r02.23", "", "output.valor=F52D.nameAndAddressLine1;", "/message/Document/FICdtTrf/CdtTrfTxInf/Dbtr/FinInstnId/Nm" ),
				new Rule("02.23.01.05.16.00", "AdrLine", "input.containsFact({'F52D'})", "GENLIST", 1 , "r02.23", "", "", "/message/Document/FICdtTrf/CdtTrfTxInf/Dbtr/FinInstnId/PstlAdr/AdrLine" )
				.addAction("001", "outputsub.valor=F52D.nameAndAddressLine2;")//
				.addAction("002", "outputsub.valor=F52D.nameAndAddressLine3;")//
				.addAction("003", "outputsub.valor=F52D.nameAndAddressLine4;")//
				,
				new Rule("02.24.01.02.01.00", "Id", "input.containsFact({'F52A','F52D'})", "MTTOMX", 1 , "r02.24", "", "", "/message/Document/FICdtTrf/CdtTrfTxInf/DbtrAcct/Id/Othr/Id" )
				.addAction("001", "outputsub.valor=F52A.account;")//
				.addAction("002", "outputsub.valor=F52D.account;")//
				,
				new Rule("02.27.01.01.00.00", "BICFI", "input.containsFact({'F57A'})", "MTTOMX", 1 , "r02.27", "", "output.valor=F57A.bIC", "/message/Document/FICdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/BICFI" ),
				new Rule("02.27.01.04.00.00", "Nm", "input.containsFact({'F57D'})", "MTTOMX", 1 , "r02.27", "", "output.valor=F57D.nameAndAddressLine1;", "/message/Document/FICdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/Nm" )
				.addAction("003", "outputsub.valor=F57D.nameAndAddressLine1")//
				,
				new Rule("02.27.01.05.16.00", "AdrLine", "input.containsFact({'F57D'})", "GENLIST", 1 , "r02.27", "", "output.valor=F57D.nameAndAddressLine2;", "/message/Document/FICdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/PstlAdr/AdrLine" )
				.addAction("001", "outputsub.valor=F57D.nameAndAddressLine2;")//
				.addAction("002", "outputsub.valor=F57D.nameAndAddressLine3;")//
				,
				new Rule("02.28.01.02.01.00", "Id", "input.containsFact({'F57A','F57C','F57B','F57D'})", "MTTOMX", 1 , "r02.28", "", "", "/message/Document/FICdtTrf/CdtTrfTxInf/CdtrAgtAcct/Id/Othr/Id" )
				.addAction("001", "outputsub.valor=F57A.account;")//
				.addAction("002", "outputsub.valor=F57B.account;")//
				.addAction("002", "outputsub.valor=F57C.account;")//
				.addAction("002", "outputsub.valor=F57D.account;")//
				,
				new Rule("02.29.01.01.00.00", "BICFI", "input.containsFact({'F58A'})", "MTTOMX", 1 , "r02.29", "", "output.valor=F58A.bIC", "/message/Document/FICdtTrf/CdtTrfTxInf/Cdtr/FinInstnId/BICFI" ),
				new Rule("02.29.01.04.00.00", "Nm", "input.containsFact({'F58D'})", "MTTOMX", 1 , "r02.29", "", "output.valor=F58D.nameAndAddressLine1;", "/message/Document/FICdtTrf/CdtTrfTxInf/Cdtr/FinInstnId/Nm" ),
				new Rule("02.29.01.08.00.00", "MmbId", "input.containsFact({'F58D'})", "MTTOMX", 1 , "r02.29", "", "output.valor=F58D.account;", "/message/Document/FICdtTrf/CdtTrfTxInf/Cdtr/FinInstnId/ClrSysMmbId/MmbId" ),
				new Rule("02.29.01.05.16.00", "AdrLine", "input.containsFact({'F58D'})", "GENLIST", 1 , "r02.29", "", "", "/message/Document/FICdtTrf/CdtTrfTxInf/Cdtr/FinInstnId/PstlAdr/AdrLine" )
				.addAction("001", "outputsub.valor=F58D.nameAndAddressLine2;")//
				.addAction("002", "outputsub.valor=F58D.nameAndAddressLine3;")//
				.addAction("003", "outputsub.valor=F58D.nameAndAddressLine4;")//
				,
				new Rule("02.30.01.02.01.00", "Id", "input.containsFact({'F58A','F58D'})", "MTTOMX", 1 , "r02.30", "", "", "/message/Document/FICdtTrf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id" )
				.addAction("001", "outputsub.valor=F58A.account;")//
				.addAction("002", "outputsub.valor=F58D.account;")//
				,
				new Rule("02.33.02.00.00.00", "InstrInf", "input.containsFact({'F72XX'}) and F72.contains('ACC')", "MTTOMX", 1 , "r02.33", "", "output.valor=F72.narrativeLine2", "/message/Document/FICdtTrf/CdtTrfTxInf/InstrForNxtAgt/InstrInf" )
				);
		
		return rules;
	}
	
	
	public static List<Rule> rulesFactoryMT() {
		Rule r001 = new Rule("R0.001", "InstructionIdentification", "true", "CALC", 1, "F20", "", "",
				"CreditTransferTransactionInformation/PaymentIdentification/InstructionIdentification");
		
		Rule r002 = new Rule("R0.002", "DebitDateTime ", "input.containsFact({'F13C'})", "MTTOMX", 1, "F13C", "", "output.valor='SNDTIME';",
				"CreditTransferTransactionInformation/SettlementTimeIndication/DebitDateTime");
		Rule r003 = new Rule("R0.003", "CreditDateTime", "input.containsFact({'F13C'})", "MTTOMX", 1, "F13C", "", "RNCTIME)",
				"CreditTransferTransactionInformation/SettlementTimeIndication/CreditDateTime");
		Rule r004 = new Rule("R0.004", "TillTime ", "input.containsFact({'F13C'})", "MTTOMX", 1, "F13C", "", "TILTIME) ",
				"CreditTransferTransactionInformation/SettlementTimeRequest/TillTime");
		Rule r005 = new Rule("R0.005", "SettlementTimeRequestFromTime", "input.containsFact({'F13C'})", "MTTOMX", 1, "F13C", "", "FROTIME) ",
				"CreditTransferTransactionInformation/SettlementTimeRequestFromTime");
		Rule r006 = new Rule("R0.006", "RejectTime ", "input.containsFact({'F13C'})", "MTTOMX", 1, "F13C", "", "REJTIME)",
				"CreditTransferTransactionInformation/SettlementTimeRequest/RejectTime");
		Rule r007 = new Rule("R0.007", "LocalInstrument/Proprietary", "input.containsFact({'F23B'})", "MTTOMX", 1, "F23B", "",
				"output.valorObj=input.fact('F23B');", "CreditTransferTransactionInformation/PaymentTypeInformation/LocalInstrument/Proprietary")//
				.addAction("001", "output.valor=F23B.type;");
		
		Rule r008 = new Rule("R0.008", "ServiceLevel/Code ", "input.containsFact({'F23E'})", "MTTOMX", 1, "F23E", "", "output.valor='SDVA'",
				"CreditTransferTransactionInformation/PaymentTypeInformation/ServiceLevel/Code");
		Rule r009 = new Rule("R0.009", "CategoryPurpose/Code", "input.containsFact({'F23E'})", "MTTOMX", 1, "F23E", "", "(INTC, CORT) ",
				"CreditTransferTransactionInformation/PaymentTypeInformation/CategoryPurpose/Code");
		Rule r010 = new Rule("R0.010", "InstructionForCreditorAgent/Code", "input.containsFact({'F23E'})", "MTTOMX", 1, "F23E", "",
				"(CHQB, HOLD, PHOB, TELB)", "CreditTransferTransactionInformation/InstructionForCreditorAgent/Code");
		Rule r011 = new Rule("R0.011", "InstructionForCreditorAgent/InstructionInformation", "input.containsFact({'F23E'})", "MTTOMX", 1, "F23E",
				"", "(HOLD, PHOB, TELB)", "CreditTransferTransactionInformation/InstructionForCreditorAgent/InstructionInformation");
		Rule r012 = new Rule("R0.012", "Purpose/Proprietary", "input.containsFact({'F26T'})", "MTTOMX", 1, "F26T", "",
				"output.valorObj=input.fact('F26T');", "CreditTransferTransactionInformation/Purpose/Proprietary");
		Rule r013 = new Rule("R0.013", "InterBankSettlementAmount ", "input.containsFact({'F32A'})", "MTTOMX", 1, "F32A", "",
				"output.valorObj=input.fact('F32A');", "CreditTransferTransactionInformation/InterBankSettlementAmount ")//
		.addAction("001", "output.valor=F32A.amount;");

		Rule r014 = new Rule("R0.014", "InterBankSettlementDate", "input.containsFact({'F32A'})", "MTTOMX", 1, "F32A", "",
				"output.valorObj=input.fact('F32A');", "CreditTransferTransactionInformation/InterBankSettlementDate")//
//		r014.addAction("001", "output.fecha=F32A.dateAsCalendar;");
		.addAction("002", "output.valor=fdate(F32A.dateAsCalendar,'dd/MM/yyyy');");
		// r014.addAction("002", "output.valor=uppc('eerDADFADF');");

		Rule r015 = new Rule("R0.015", "InstructedAmount", "input.containsFact({'F33B'})", "MTTOMX", 1, "F33B", "",
				"output.valorObj=input.fact('F33B');", "CreditTransferTransactionInformation/InstructedAmount");
		Rule r016 = new Rule("R0.016", "ExchangeRate", "input.containsFact({'F36'})", "MTTOMX", 1, "F36", "",
				"output.valorObj=input.fact('F36 ');", "CreditTransferTransactionInformation/ExchangeRate");
		Rule r017 = new Rule("R0.017", "Debtor ", "input.containsFact({'F50a'})", "MTTOMX", 1, "F50a", "", "output.valorObj=input.fact('F50a');",
				"CreditTransferTransactionInformation/Debtor ");
		Rule r01701 = new Rule("R0.01701", "Debtor", "input.containsFact({'F50K'})", "CALC", 1, "F50K", "",
				"output.valorObj=input.fact('F50K');", "CreditTransferTransactionInformation/Debtor")//
		.addAction("001", "output.valor=F50K.nameAndAddressLine1;");

		Rule r01702 = new Rule("R0.01702", "Debtor ", "input.containsFact({'F50F'})", "MTTOMX", 1, "F50F", "",
				"output.valorObj=input.fact('F50F');", "CreditTransferTransactionInformation/Debtor")//
		.addAction("001", "output.valor=F50F.component3;");

		Rule r018 = new Rule("R0.018", "DebtorAccount", "input.containsFact({'F50a'})", "MTTOMX", 1, "F50a", "",
				"output.valorObj=input.fact('F50a');", "CreditTransferTransactionInformation/DebtorAccount");
		Rule r019 = new Rule("R0.019", "DebtorAgent ", "input.containsFact({'F52a'})", "MTTOMX", 1, "F52a", "",
				"output.valorObj=input.fact('F52a');", "CreditTransferTransactionInformation/DebtorAgent ");
		Rule r020 = new Rule("R0.020", "DebtorAgentAccount", "input.containsFact({'F52a'})", "MTTOMX", 1, "F52a", "",
				"output.valorObj=input.fact('F52a');", "CreditTransferTransactionInformation/DebtorAgentAccount");
		
		Rule r021 = new Rule("R0.021", "SettlementAccount", "input.containsFact({'F53a'})", "MTTOMX", 1, "F53a", "",
				"output.valorObj=input.fact('F53a');", "GroupHeader/SettlementInformation/SettlementAccount");
		
		Rule r02101 = new Rule("R0.02101", "SettlementAccount", "input.containsFact({'F53B'})", "MTTOMX", 1, "F53B", "",
				"output.valorObj=input.fact('F53B');", "GroupHeader/SettlementInformation/SettlementAccount")//
				.addAction("001", "output.valor=F53B.account;");
		
		Rule r022 = new Rule("R0.022", "InstructingReimbursementAgent ", "input.containsFact({'F53a'})", "MTTOMX", 1, "F53a", "",
				"output.valorObj=input.fact('F53a');", "GroupHeader/SettlementInformation/InstructingReimbursementAgent ");
		Rule r02201 = new Rule("R0.02201", "InstructingReimbursementAgent ", "input.containsFact({'F53B'})", "MTTOMX", 1, "F53B", "",
				"output.valorObj=input.fact('F53B');", "GroupHeader/SettlementInformation/InstructingReimbursementAgent ")//
				.addAction("001", "output.valor=F53B.location;");
		
		Rule r023 = new Rule("R0.023", "InstructingReimbursementAgentAccount", "input.containsFact({'F53a'})", "MTTOMX", 1, "F53a", "",
				"output.valorObj=input.fact('F53a');", "GroupHeader/SettlementInformation/InstructingReimbursementAgentAccount");
		
		Rule r02301 = new Rule("R0.02301", "InstructingReimbursementAgentAccount", "input.containsFact({'F53B'})", "MTTOMX", 1, "F53B", "",
				"output.valorObj=input.fact('F53B');", "GroupHeader/SettlementInformation/InstructingReimbursementAgentAccount") //;		
		.addAction("001", "output.valor=F53B.account;");
		
		Rule r024 = new Rule("R0.024", "InstructedReimbursementAgent", "input.containsFact({'F54a'})", "MTTOMX", 1, "F54a", "",
				"output.valorObj=input.fact('F54a');", "GroupHeader/SettlementInformation/InstructedReimbursementAgent");
		Rule r025 = new Rule("R0.025", "InstructedReimbursementAgentAccount", "input.containsFact({'F54a'})", "MTTOMX", 1, "F54a", "",
				"output.valorObj=input.fact('F54a');", "GroupHeader/SettlementInformation/InstructedReimbursementAgentAccount");
		Rule r026 = new Rule("R0.026", "ThirdReimbursementAgent ", "input.containsFact({'F55a'})", "MTTOMX", 1, "F55a", "",
				"output.valorObj=input.fact('F55a');", "GroupHeader/SettlementInformation/ThirdReimbursementAgent ");
		Rule r027 = new Rule("R0.027", "ThirdReimbursementAgentAccount", "input.containsFact({'F55a'})", "MTTOMX", 1, "F55a", "",
				"output.valorObj=input.fact('F55a');", "GroupHeader/SettlementInformation/ThirdReimbursementAgentAccount");
		Rule r028 = new Rule("R0.028", "IntermediaryAgent1 ", "input.containsFact({'F56a'})", "MTTOMX", 1, "F56a", "",
				"output.valorObj=input.fact('F56a');", "CreditTransferTransactionInformation/IntermediaryAgent1 ");
		Rule r02801 = new Rule("R0.02801", "IntermediaryAgent1 ", "input.containsFact({'F56A'})", "MTTOMX", 1, "F56A", "",
				"output.valorObj=input.fact('F56A');", "CreditTransferTransactionInformation/IntermediaryAgent1 ")
				.addAction("001", "output.valor=F56A.bIC;");
		
		Rule r029 = new Rule("R0.029", "IntermediaryAgent1Account", "input.containsFact({'F56a'})", "MTTOMX", 1, "F56a", "",
				"output.valorObj=input.fact('F56a');", "CreditTransferTransactionInformation/IntermediaryAgent1Account");
		Rule r02901 = new Rule("R0.02901", "IntermediaryAgent1Account", "input.containsFact({'F56B'})", "MTTOMX", 1, "F56B", "",
				"output.valorObj=input.fact('F56B');", "CreditTransferTransactionInformation/IntermediaryAgent1Account")//
				.addAction("001", "output.valor=F56B.account;");
		
		Rule r030 = new Rule("R0.030", "CreditorAgent ", "input.containsFact({'F57a'})", "MTTOMX", 1, "F57a", "",
				"output.valorObj=input.fact('F57a');", "CreditTransferTransactionInformation/CreditorAgent ");
		Rule r031 = new Rule("R0.031", "CreditorAgentAccount", "input.containsFact({'F57a'})", "MTTOMX", 1, "F57a", "",
				"output.valorObj=input.fact('F57a');", "CreditTransferTransactionInformation/CreditorAgentAccount");
		Rule r03101 = new Rule("R0.03101", "CreditorAgentAccount", "input.containsFact({'F57D'})", "MTTOMX", 1, "F57D", "",
				"output.valorObj=input.fact('F57D');", "CreditTransferTransactionInformation/CreditorAgentAccount")
				.addAction("001", "output.valor=F57D.account;");
		Rule r03001 = new Rule("R0.03001", "CreditorAgent ", "input.containsFact({'F57D'})", "MTTOMX", 1, "F57D", "",
				"output.valorObj=input.fact('F57D');", "CreditTransferTransactionInformation/CreditorAgent ")//
		.addAction("001", "output.valor=F57D.component3;");
		
		Rule r032 = new Rule("R0.032", "Creditor ", "input.containsFact({'F59a'})", "MTTOMX", 1, "F59a", "", "output.valorObj=input.fact('F59a');",
				"CreditTransferTransactionInformation/Creditor ");
		Rule r03201 = new Rule("R0.03201", "Creditor ", "input.containsFact({'F59'})", "MTTOMX", 1, "F59", "", "output.valorObj=input.fact('F59');",
				"CreditTransferTransactionInformation/Creditor ")//
				.addAction("001", "output.valor=F59.component2;");
		
		Rule r033 = new Rule("R0.033", "CreditorAccount", "input.containsFact({'F59a'})", "MTTOMX", 1, "F59a", "",
				"output.valorObj=input.fact('F59a');", "CreditTransferTransactionInformation/CreditorAccount");
		Rule r03301 = new Rule("R0.03301", "CreditorAccount", "input.containsFact({'F59'})", "MTTOMX", 1, "F59", "",
				"output.valorObj=input.fact('F59');", "CreditTransferTransactionInformation/CreditorAccount")
				.addAction("001", "output.valor=F59.account;");
		
		Rule r034 = new Rule("R0.034", "RemittanceInformation/Unstructured ", "input.containsFact({'F70'})", "MTTOMX", 1, "F70", "",
				"output.valorObj=input.fact('F70');", "CreditTransferTransactionInformation/RemittanceInformation/Unstructured ")//
				.addAction("001", "output.valor=F70.value;");
		
		Rule r035 = new Rule("R0.035", "PaymentIdentification/EndToEndIdentification", "input.containsFact({'F70'})", "MTTOMX", 1, "F70", "",
				"output.valor='ROC'", "CreditTransferTransactionInformation/PaymentIdentification/EndToEndIdentification");
		
		Rule r036 = new Rule("R0.036", "ChargeBearer", "input.containsFact({'F71A'})", "MTTOMX", 1, "F71A", "",
				"output.valorObj=input.fact('F71A');", "CreditTransferTransactionInformation/ChargeBearer")//
				.addAction("001", "output.valor=F71A.code;");
		
		Rule r037 = new Rule("R0.037", "ChargesInformation/Amount", "input.containsFact({'F71F'})", "MTTOMX", 1, "F71F", "",
				"output.valorObj=input.fact('F71F');", "CreditTransferTransactionInformation/ChargesInformation/Amount");
		Rule r038 = new Rule("R0.038", "ChargesInformation/Amount", "input.containsFact({'F71G'})", "MTTOMX", 1, "F71G", "",
				"output.valorObj=input.fact('F71G');", "CreditTransferTransactionInformation/ChargesInformation/Amount");
		
		Rule r039 = new Rule("R0.039", "InstructionForNextAgent/InstructionInformation ", "input.containsFact({'F72'})", "MTTOMX", 1, "F72", "",
				"output.valorObj=input.fact('F72 ');", "CreditTransferTransactionInformation/InstructionForNextAgent/InstructionInformation ");
		
		Rule r040 = new Rule("R0.040", "PreviousInstructingAgent ", "input.containsFact({'F72'})", "MTTOMX", 1, "F72", "", "(INS)",
				"CreditTransferTransactionInformation/PreviousInstructingAgent");
		Rule r041 = new Rule("R0.041", "CLSTime ", "input.containsFact({'F72'})", "MTTOMX", 1, "F72", "", "(CLSTIME)",
				"CreditTransferTransactionInformation/SettlementTimeRequest/CLSTime");
		
		Rule r042 = new Rule("R0.042", "RegulatoryReporting/Details/Information", "input.containsFact({'F77B'})", "MTTOMX", 1, "F77B", "",
				"output.valorObj=input.fact('F77B');", "CreditTransferTransactionInformation/RegulatoryReporting/Details/Information");

		List<Rule> rules = Arrays.asList(r001, r002, r003, r004, r005, r006, r007, r008, r009, r010, r011, r012, r013, r014, r015, r016, r017, r018, r019,
				r020, r021, r022, r023, r024, r025, r026, r027, r028, r029, r030, r031, r032, r033, r034, r035, r036, r037, r038, r039, r040, r041, r042,
				r01701, r01702, r02101, r02201, r02301, r02801, r02901, r03101,r03001,r03201, r03301);

		rules.forEach(r -> {
			r.addAction("1", "output.campoValue=" + r.getNamespace() + ".value;");
			//r.addAction("2", "output.column='value';");
			r.addAction("3", "output.putAtrib('path',rulein.path);");
			r.addAction("5", "output.putAtrib('idrule',rulein.id);");
			r.addAction("6", "output.putAtrib(rulein.path,output.valor);");
		});
		return rules;
	}

	public static void main(String[] args) {
//		final String id, final String name, final String expression, final String outcome, final int priority,
//        final String namespace, final String description, String action, String path
		rulesMt103().forEach(r -> {
			System.out.print(r.getId() + "\t" + r.getName()+ "\t" + r.getExpression()+ "\t" + r.getOutcome()+ "\t" + r.getNamespace()+ "\t" + r.getAction()+ "\t" + r.getPath() + "\t");
			//System.out.print(r.getId() + "\t" );			
			r.getActions().forEach(a -> {
				System.out.print(a.getAttribute() + "|" + a.getValue() + "\t");
			});
			System.out.println("" );
		});
	}
}
