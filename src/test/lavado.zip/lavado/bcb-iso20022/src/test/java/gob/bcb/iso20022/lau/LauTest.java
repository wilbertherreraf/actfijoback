package gob.bcb.iso20022.lau;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.bind.DatatypeConverter;
import javax.xml.crypto.dsig.XMLSignature;

import org.apache.commons.codec.binary.Base64;
import org.apache.xml.security.c14n.implementations.Canonicalizer20010315Excl;
import org.apache.xml.security.c14n.implementations.Canonicalizer20010315ExclWithComments;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import gob.bcb.iso20022.core.xml.JaxBConversionService;
import gob.bcb.iso20022.utils.UtilsFile;

public class LauTest {
	private static final Logger log = LoggerFactory.getLogger(LauTest.class);
	
	@Test
	public void smaUpdLAUMsgSignedTest() {
		String cad = "<ds:SignedInfo><ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"/><ds:SignatureMethod Algorithm=\"http://www.w3.org/2001/04/xmldsig-more#hmac-sha256\"/><ds:Reference URI=\"\"><ds:Transforms><ds:Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/><ds:Transform Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"/></ds:Transforms><ds:DigestMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#sha256\"/><ds:DigestValue>jrZE9w6whV+K80ZBIvmTiVCkkzgESQalYGm0ZeoQpzY=</ds:DigestValue></ds:Reference></ds:SignedInfo>";
		String pdu = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Saa:DataPDU xmlns:Saa=\"urn:swift:saa:xsd:saa.2.0\"><Saa:Revision>2.0.6</Saa:Revision></Saa:DataPDU>";
		pdu = "<Saa:DataPDU xmlns:Saa=\"urn:swift:saa:xsd:saa.2.0\"><Saa:Revision>2.0.6</Saa:Revision><Saa:LAU/></Saa:DataPDU>";
		String pdu2 = "<Saa:DataPDU xmlns:Saa=\"urn:swift:saa:xsd:saa.2.0\"><Saa:Revision>2.0.6</Saa:Revision><Saa:LAU></Saa:LAU></Saa:DataPDU>";
		String siginf = "<ds:SignedInfo xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\"><ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"></ds:CanonicalizationMethod><ds:SignatureMethod Algorithm=\"http://www.w3.org/2001/04/xmldsig-more#hmac-sha256\"></ds:SignatureMethod><ds:Reference URI=\"\"><ds:Transforms><ds:Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"></ds:Transform><ds:Transform Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"></ds:Transform></ds:Transforms><ds:DigestMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#sha256\"></ds:DigestMethod><ds:DigestValue>M20gJX6qxgbqYfNUiW+TGcmVY7l01FXzGTGA0lmYbds=</ds:DigestValue></ds:Reference></ds:SignedInfo>";
		String sigfin = "<Saa:DataPDU xmlns:Saa=\"urn:swift:saa:xsd:saa.2.0\"><Saa:Revision>2.0.6</Saa:Revision><Saa:LAU><ds:Signature xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\"><ds:SignedInfo><ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"/><ds:SignatureMethod Algorithm=\"http://www.w3.org/2001/04/xmldsig-more#hmac-sha256\"/><ds:Reference URI=\"\"><ds:Transforms><ds:Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/><ds:Transform Algorithm=\"http://www.w3.org/2001/10/xml-exc-c14n#\"/></ds:Transforms><ds:DigestMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#sha256\"/><ds:DigestValue>M20gJX6qxgbqYfNUiW+TGcmVY7l01FXzGTGA0lmYbds=</ds:DigestValue></ds:Reference></ds:SignedInfo><ds:SignatureValue>cGiIdplJ0XKYlkvjkoNWYLp5dNRumIt8y/nnAHPCEos=</ds:SignatureValue></ds:Signature></Saa:LAU></Saa:DataPDU>";
		try {
			log.info("====== Msg Signed test ==================");
			String nfile = "src/test/resources/sign/pacsaa.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			
			Document docSign = JaxBConversionService.getDomFromString(menplano);
			Node node = docSign.getDocumentElement().getParentNode();
			//Canonicalizer20010315Excl c = new Canonicalizer20010315ExclWithComments();
			
			//ByteArrayOutputStream bos = new ByteArrayOutputStream();
			//c.engineCanonicalizeSubTree(node, bos);
			String dataCano = JaxBConversionService.node2XMLCanno(node);
			
			//log.info("menplano " + menplano);
			//log.info("dataCano " + dataCano);
			AuthParameters authParameters = new AuthParameters("Abcd1234abcd1234","Abcd1234abcd1234");
			String keyString = "Abcd1234abcd1234Abcd1234abcd1234";
						
			LAU lau = new LAU();
			lau.setSecretKey(authParameters.getKey());
			
			byte[] sig = lau.sign(menplano.getBytes());
			
			String s256 = lau.generateHMacSHA256(keyString, siginf);
			String s1 = DatatypeConverter.printBase64Binary(sig);
			String sgHex = DatatypeConverter.printHexBinary(sig);
			String ss = new String(sig, StandardCharsets.UTF_8);
			String sig64 = Base64.encodeBase64String(sig);

			log.info("Base64Binary " + s1 + " sgHex " + sgHex + " sig64: " + sig64 + " utf: " + ss + " s256: " + s256);
			String s = lau.getSignedInfo();			
			String scanno = lau.getSignedInfoCanno();
			log.info("Siginfo Canno " + scanno);
			byte[] sisb = lau.sign(s.getBytes());
			
			String dig =  DatatypeConverter.printHexBinary(lau.sign(scanno.getBytes()));
			String digs2 = DatatypeConverter.printBase64Binary(lau.sign(scanno.getBytes()));
			String digpdu = lau.digest(dataCano);
			
			String ss1 = DatatypeConverter.printBase64Binary(sisb);
			log.info("digest " + lau.getDigestValue() + " " + digpdu);
			log.info("dig balue " + lau.getSignatureValue() + " canno: " + digs2);
			log.info("Siginfo " + ss1 + " digvanno::: " + dig + " digpdu: " + digpdu + " mac: " + digs2 + " mac2: " + lau.generateHMacSHA256(keyString, lau.getDigestValue()));
			

			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}	

}
