package gob.bcb.iso20022.core.xml;

import java.util.LinkedHashMap;
import java.util.Optional;

import org.dom4j.Node;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.internal.LinkedTreeMap;
import com.prowidesoftware.swift.model.mx.AbstractMX;

import gob.bcb.iso20022.utils.UtilsFile;

public class XmlToMapTest {
	private static final Logger log = LoggerFactory.getLogger(XmlToMapTest.class);

	// @Test
	public void xmlToJsonTest() {
		try {
			String nfile = "src/test/resources/mxs/mxpacs01.mx";
			String xml = UtilsFile.readFileAsString2(nfile);
			log.info("************************");
			AbstractMX mx = AbstractMX.parse(xml);
			String json = mx.toJson();
			log.info(json);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	//@Test
	public void xmlToTreeMapTest() {
		try {
			String nfile = "src/test/resources/mxs/cnsaa.txt";
			String xml = UtilsFile.readFileAsString2(nfile);
			log.info("************************");
			LinkedTreeMap<String, String> outMap = XmlToMap.xmlToProps(xml);
			outMap.forEach((k, v) -> {
				log.info(k + " -> " + v);
			});

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	@Test
	public void xmlFromMapTest() {
		try {
			String nfile = "src/test/resources/mxs/cnsaa.txt";
			String xml = UtilsFile.readFileAsString2(nfile);
			log.info("\n" + xml);
			log.info("---------------------------");
			LinkedTreeMap<String, String> outMap = XmlToMap.xmlToPropsNS(xml);
			outMap.forEach((k, v) -> {
				log.info(k + " -> " + v);
			});
			LinkedHashMap<String, Object> xmlProperties = new LinkedHashMap<String, Object>();
			outMap.forEach((k, v) -> {
				xmlProperties.put(k, v.toString());
			});
			String xmlout = XmlToMap.xmlSaaFromXPath(xmlProperties, "");
			log.info("***********OUT*************");
			log.info("\n" + xmlout);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

//	@Test
	public void xmlToTreeMapListTest() {
		try {
			String nfile = "src/test/resources/mxsmap/103a.txt";
			UtilsFile.filesDir("src/test/resources/mxmapp").forEach(f -> {
				String xml = UtilsFile.readFileAsString2(f.getAbsolutePath());
				log.info("************" + f.getAbsolutePath() + "************");
				LinkedTreeMap<String, String> outMap = XmlToMap.xmlToProps(xml);
				outMap.forEach((k, v) -> {
					log.info(k + " -> " + v);
				});
			});

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void findNodeTest() {
		try {
			String nfile = "src/test/resources/mxs/pacs008cli.xml";
			String xml = UtilsFile.readFileAsString2(nfile);
			log.info("************************");
			log.info(xml);
			Optional<Node> node = XmlToMap.findFirstByName(xml, "./CtrySubDvsn0");
			if (node.isPresent()) {
				log.info("Found!! " + node.get().getText());
			} else {
				log.info("Not Found!! ");
			}
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
}
