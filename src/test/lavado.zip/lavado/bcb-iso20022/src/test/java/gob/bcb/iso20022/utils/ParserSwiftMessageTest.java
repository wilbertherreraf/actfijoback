package gob.bcb.iso20022.utils;

import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.junit.jupiter.api.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;
import com.prowidesoftware.swift.model.AbstractSwiftMessage;
import com.prowidesoftware.swift.model.MxSwiftMessage;
import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.prowidesoftware.swift.model.mx.MxPacs00800109;

import gob.bcb.iso20022.core.xml.ValidarConXsd;
import gob.bcb.iso20022.utilsBank.Agreement;
import gob.bcb.iso20022.utilsBank.IsoCountry;
import gob.bcb.iso20022.utilsBank.creditor.CreditorIdentifier;

public class ParserSwiftMessageTest {
	private final Logger log = LoggerFactory.getLogger(getClass());

	@Test
	public void parserAbst() {
		try {
			MxPacs00800109 mx0 = null;

			String nfile = "src/test/resources/mts/M01.txt"; // siodex_103.txt
			String str = UtilsFile.readFileAsString2(nfile);
			AbstractSwiftMessage msg = ParserSwiftMessage.swiftMsgBase(str);
			//log.info(msg.getMessage());
			log.info(msg.getAmount() + " " + msg.getCategory() + " " + msg.getReceiver() + " " + msg.getProperties() + " " + msg.getMessageType());

			log.info(" ******************* ");
			nfile = "src/test/resources/mxs/mxpacs01.mx"; // siodex_103.txt
			str = UtilsFile.readFileAsString2(nfile);
			log.info(str);
			log.info(" ******************* ");

			MxSwiftMessage msg0 = (MxSwiftMessage) ParserSwiftMessage.swiftMsgBase(str);

			log.info(msg0.getMessage());
			log.info(msg0.getAmount() + " " + msg0.getCategory() + " " + msg0.getReceiver() + " " + msg0.getProperties() + " " + msg0.getMessageType());

			System.out.println(msg0.toJson());
			// Create XPath
			System.out.println("jjjjjjjjjjjjjjjjjjjjjjjjj ");
			AbstractMX mx = AbstractMX.parse(str);
			String json = mx.toJson();
			System.out.println(json);
			System.out.println("jjjjjjjjjjjjjjjjjjjjjjjjj ");
			System.out.println("");
//			Map<String, Object> result = new ObjectMapper().readValue(json, HashMap.class);
//			result.forEach((k, v) -> {
//				System.out.println(k + " -> " + v.getClass() + " " + v.getClass());
//			});

			System.out.println("++++++++++++++++++");
//			Map<String, Object> map = new Gson().fromJson(json, Map.class);
//			Map<String, String> outMap0 = new HashMap<String, String>();
//			mapTree(map, outMap0);

			System.out.println("------------------------------");
			Type type = new TypeToken<Map<String, Object>>() {
			}.getType();

			Type typed = new TypeToken<Map<String, Object>>() {
			}.getType();
			
			Gson gson = new GsonBuilder()//
					.registerTypeAdapter(type, new MapDeserializer())//
					//.registerTypeAdapter(typed, new StringDateMapDeserializer())//
					.create();
			
			Map<String, Object> blendedMap = gson.fromJson(json, type);
			Map<String, String> outMap = new HashMap<String, String>();
			System.out.println("------------------------------");
			mapTree("root", blendedMap, outMap);
			
			System.out.println("##########################");
			outMap.forEach((k, v) -> {
				System.out.println("	OUT==> " + k + " ->> " + v);
			});

		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	public static void readTree(String father, LinkedTreeMap<String, Object> map, Map<String, String> outMap) {
		System.out.println("	READTREE==> " + father + "=" + map.size());
		map.forEach((k, v) -> {
			String ntree = father + "." + k.toString();
			if (v instanceof LinkedTreeMap) {
				System.out.println("		Nvl ==> " + ntree + "=" + v + " class: " + v.getClass());
				readTree(ntree, (LinkedTreeMap) v, outMap);
			} else if (v instanceof ArrayList) {
				ArrayList arr = (ArrayList) v;
				arr.forEach(vv -> {
					System.out.println("		**> VALORARR ==> " + ntree + " :: " + v + " class: " + vv.getClass());
					LinkedTreeMap l = new LinkedTreeMap();
					l.put(k, vv);
					readTree(father, l, outMap);
				});
			} else {
				System.out.println("		**> VALOR ==> " + ntree + "=" + v + " class: " + v.getClass());
				outMap.put(ntree, v.toString());
			}
		});
	}

	public void mapTree(String root, Map<String, Object> map, Map<String, String> outMap) {
		//Map<String, String> outMap = new HashMap<String, String>();
		//String root = "root";
		// print map keys and values
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			String ntree = root + "." + entry.getKey();
			if (entry.getValue() instanceof LinkedTreeMap) {
				//readTree(ntree, (LinkedTreeMap<String, Object>) entry.getValue(), outMap);
				System.out.println("		Nvl ==> " + ntree + "=" + entry.getValue() + " class: " + entry.getValue().getClass());
				//year=2022.0, month=1.0, day=27.0, timezone=-2.147483648E9, hour=-2.147483648E9, minute=-2.147483648E9, second
				Map mapa = (Map) entry.getValue();
				if (mapa.containsKey("year") && mapa.containsKey("month")) {
					outMap.put(ntree, entry.getValue().toString());
				} else {
					mapTree(ntree, (Map<String, Object>) entry.getValue(), outMap);					
				}
				
			} else if (entry.getValue() instanceof ArrayList) {
				ArrayList arr = (ArrayList) entry.getValue();
				arr.forEach(vv -> {
					System.out.println("		**> VALORARR ==> " + ntree + " :: " + vv + " class: " + vv.getClass());

					if (vv instanceof LinkedTreeMap) {
						mapTree(ntree, (Map<String, Object>) vv, outMap);
					} else {
						LinkedTreeMap l = new LinkedTreeMap();
						l.put(entry.getKey(), vv);
						mapTree(ntree, l, outMap);						
					}
//					String json = vv.toString();
//					Type type = new TypeToken<Map<String, Object>>() {		}.getType();
//					Gson gson = new GsonBuilder().registerTypeAdapter(type, new MapDeserializer()).create();
//					Map<String, Object> blendedMap = gson.fromJson(json, type);				
//					mapTree(ntree,blendedMap, outMap);					
				});
//				LinkedTreeMap l = new LinkedTreeMap();
//				l.put(entry.getKey(), entry.getValue());
//				//readTree(ntree, l, outMap);
//				mapTree(ntree, l, outMap);
			} else if (entry.getValue() instanceof JsonObject) {
				String json = entry.getValue().toString();
				Type type = new TypeToken<Map<String, Object>>() {		}.getType();
				Gson gson = new GsonBuilder().registerTypeAdapter(type, new MapDeserializer()).create();
				System.out.println("ANTES DE JOB ==> " + entry.getKey() + "=" + ntree + " " + entry.getValue() + " class: "+ entry.getValue().getClass());
				Map<String, Object> blendedMap = gson.fromJson(json, type);	
				if (blendedMap.containsKey("year") && blendedMap.containsKey("month")) {
					outMap.put(ntree, entry.getValue().toString());
				}else {
					mapTree(ntree,blendedMap, outMap);					
				}
			} else {
				System.out.println("TREE ==> " + entry.getKey() + "=" + entry.getValue() + " " + entry.getValue().getClass());
				outMap.put(ntree, entry.getValue().toString());
			}
		}
		System.out.println("##########################");

	}

	public class MapDeserializer implements JsonDeserializer<Map<String, Object>> {
		private SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

		@Override
		public Map<String, Object> deserialize(JsonElement elem, Type type, JsonDeserializationContext context) throws JsonParseException {

			return elem.getAsJsonObject().entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e -> {
//				System.out.println("	XXX tipo json : " + e.getKey() + "::"+ e.getValue() + " " + e.getValue().getClass());
				if (e.getValue().isJsonObject()) {
					System.out.println("	--> JO " + e.getValue());
					return context.deserialize(e.getValue(), JsonObject.class);
				}
				return e.getValue().isJsonPrimitive() ? toPrimitive(e.getValue().getAsJsonPrimitive(), context) : //
				(
					context.deserialize(e.getValue(), Object.class)//
				);
			}));
//			return elem.getAsJsonObject().entrySet().stream()
//					.collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue().isJsonPrimitive() //
//							? toPrimitive(e.getValue().getAsJsonPrimitive(), context)
//							: ( //
//									e.getValue().getAsJsonPrimitive().isString() ?  
//											context.deserialize(e.getValue(), Object.class)//
//									: formatDate(e.getValue()) 
//									)));
		}

		private Object toPrimitive(JsonPrimitive jsonValue, JsonDeserializationContext context) {
			if (jsonValue.isBoolean())
				return jsonValue.getAsBoolean();
			else if (jsonValue.isString()) {
				
				return jsonValue.getAsString();
			}else {
				BigDecimal bigDec = jsonValue.getAsBigDecimal();
				Long l;
				Integer i;
				if ((i = toInteger(bigDec)) != null) {
					System.out.println("--------> CDE " + bigDec + " " + jsonValue);					
					return i;
				} else if ((l = toLong(bigDec)) != null) {
					return l;
				} else {
					System.out.println("	--------> DOUBLE " + bigDec + " " + jsonValue);
					return bigDec.doubleValue();
				}
			}
		}

		private Long toLong(BigDecimal val) {
			try {
				return val.toBigIntegerExact().longValue();
			} catch (ArithmeticException e) {
				return null;
			}
		}

		private Integer toInteger(BigDecimal val) {
			try {
				return val.intValueExact();
			} catch (ArithmeticException e) {
				return null;
			}
		}

		private Date formatDate(JsonElement value) {
			try {
				return format.parse(value.getAsString());
			} catch (ParseException ex) {
				throw new JsonParseException(ex);
			}
		}
	}

	public class StringDateMapDeserializer implements JsonDeserializer<Map<String, Object>> {

	    private SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

	    @Override
	    public Map<String, Object> deserialize(JsonElement elem, Type type, JsonDeserializationContext jsonDeserializationContext) {
	        System.out.println("Deserializer called");
	        log.info("Deserializer called");
	        return elem.getAsJsonObject()
	          .entrySet()
	          .stream()
	          .filter(e -> e.getValue().isJsonPrimitive())
	          .filter(e -> e.getValue().getAsJsonPrimitive().isString())
	          .collect(Collectors.toMap(Map.Entry::getKey, e -> formatDate(e.getValue(), jsonDeserializationContext)));
	    }

	    private Object formatDate(JsonElement value, JsonDeserializationContext context) {
	        try {
	            return format.parse(value.getAsString());
	        } catch (ParseException ex) {
	            //throw new JsonParseException(ex);
	        	
	            return context.deserialize(value, Object.class);
	        }
	    }

	}
}
