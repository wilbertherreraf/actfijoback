package gob.bcb.iso20022.expression.langParser;

import static org.mvel2.templates.TemplateCompiler.compileTemplate;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.mvel2.MVEL;
import org.mvel2.integration.VariableResolverFactory;
import org.mvel2.integration.impl.MapVariableResolverFactory;
import org.mvel2.templates.CompiledTemplate;
import org.mvel2.templates.TemplateRuntime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20C;
import com.prowidesoftware.swift.model.field.Field23G;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field72;
import com.prowidesoftware.swift.model.field.Narrative;
import com.prowidesoftware.swift.model.field.Narrative.Builder;
import com.prowidesoftware.swift.utils.LineWrapper;
import com.prowidesoftware.swift.model.field.SwiftParseUtils;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.model.SwfReglasmerc;
import gob.bcb.iso20022.rules.Rule;
import gob.bcb.iso20022.swift.FieldsCommand;
import gob.bcb.iso20022.utils.MxDataTypesConversor;
import gob.bcb.iso20022.utils.UtilsGeneric;

public class ExpressionsMVELTest {
	private static final Logger log = LoggerFactory.getLogger(ExpressionsMVELTest.class);

	// @Test
	public void templatesMap() {
		try {
			log.info("inicioooooooooo");
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("lnid", "Foo");
			map.put("ocmt", "Bar");
			map.put("exrt", BigDecimal.valueOf(458.36));

			String template = "/LNID/${lnid}///OCMT/${ocmt}///EXRT/${exrt}";

			VariableResolverFactory vrf = new MapVariableResolverFactory(map);
			CompiledTemplate compiled = compileTemplate(template);
			// Object o = TemplateRuntime.eval(template, vrf);
			Object o = TemplateRuntime.execute(compiled, map);
			log.info("res {}", o.toString());
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

//	@Test
	public void objectToMap() {
		try {
			log.info("inicioooooooooo");
			CampoForm output = new CampoForm();

			SwfMencampos swfMencampos = new SwfMencampos();
			swfMencampos.setMtfCodmt("103");
			swfMencampos.setMtfCodcampo("32A");
			swfMencampos.setMtfNemo("32A");

			SwfReglasmerc rm = new SwfReglasmerc();
			rm.setMktPaymentcurr("USD");

			BigDecimal m = BigDecimal.valueOf(456.23);

			SwfMsgParam msgP = new SwfMsgParam();
			msgP.setMenFecauto(new Date());

//			Field fgenF = fgen(name, qualifier, codeset, f20C());
//			fgenF = fgen(name, qualifier, codeset, f32A(new Date(), BigDecimal.valueOf(456.23), "USD"));

			// Function<SwfMencampos, Supplier<CampoForm>> f32AF =
			// f32A(msgP.getMenFecauto(), m, rm.getMktPaymentcurr());

			Method methodF = FieldsCommand.class.getMethod("fgen", SwfMencampos.class, String.class, String.class, String.class, Function.class);
			Method methodFS = FieldsCommand.class.getMethod("fgenS", SwfMencampos.class, String.class, String.class, String.class, Function.class);
			FieldsCommand fc = new FieldsCommand();
			Map<String, Object> vars = new HashMap<String, Object>();
			vars.put("fGen", methodF);
			vars.put("fGens", methodFS);
			vars.put("mkt", rm);
			vars.put("monto", m);
			vars.put("msgp", msgP);
			vars.put("funcs", fc);
			vars.put("swfcmp", swfMencampos);
			vars.put("output", output);

			vars.put("f20", FieldsCommand.class.getMethod("f20", String.class, Integer.class, Date.class));
			vars.put("f21", FieldsCommand.class.getMethod("f21", String.class));
			vars.put("f23B", FieldsCommand.class.getMethod("f23B", String.class));
			vars.put("f32A", FieldsCommand.class.getMethod("f32A", Date.class, String.class, BigDecimal.class));
			vars.put("f33B", FieldsCommand.class.getMethod("f33B", String.class, BigDecimal.class));
			vars.put("f50A", FieldsCommand.class.getMethod("f50A", String.class));
			vars.put("f50F", FieldsCommand.class.getMethod("f50F", String.class, String.class, String.class, String.class, String.class));
			vars.put("f50K", FieldsCommand.class.getMethod("f50K", Instruccion.class, String.class, String.class));
			vars.put("f50K", FieldsCommand.class.getMethod("f50K", String.class, String.class, String.class));
			vars.put("f52A", FieldsCommand.class.getMethod("f52A", String.class, String.class));
			vars.put("f52D", FieldsCommand.class.getMethod("f52D", String.class));
			vars.put("f53A", FieldsCommand.class.getMethod("f53A", String.class, String.class));
			vars.put("f53B", FieldsCommand.class.getMethod("f53B", String.class, String.class));
			vars.put("f53D", FieldsCommand.class.getMethod("f53D", String.class));
			vars.put("f54A", FieldsCommand.class.getMethod("f54A", String.class, String.class));
			vars.put("f54B", FieldsCommand.class.getMethod("f54B", String.class, String.class));
			vars.put("f54D", FieldsCommand.class.getMethod("f54D", String.class));
			vars.put("f56A", FieldsCommand.class.getMethod("f56A", String.class, String.class));
			vars.put("f56D", FieldsCommand.class.getMethod("f56D", String.class));
			vars.put("f57A", FieldsCommand.class.getMethod("f57A", String.class, String.class));
			vars.put("f57B", FieldsCommand.class.getMethod("f57B", String.class, String.class));
			vars.put("f57D", FieldsCommand.class.getMethod("f57D", String.class, String.class));
			vars.put("f58A", FieldsCommand.class.getMethod("f58A", String.class, String.class));
			vars.put("f58D", FieldsCommand.class.getMethod("f58D", String.class, String.class));
			vars.put("f58D", FieldsCommand.class.getMethod("f58D", String.class, String.class, String.class));
			vars.put("f59", FieldsCommand.class.getMethod("f59", String.class, String.class, String.class));
			vars.put("f70", FieldsCommand.class.getMethod("f70", String.class));
			vars.put("f71A", FieldsCommand.class.getMethod("f71A", String.class));
			vars.put("f71F", FieldsCommand.class.getMethod("f71F", String.class, BigDecimal.class));
			vars.put("f72", FieldsCommand.class.getMethod("f72", String.class));

			String expressionf = "output.valorObj=fGen(swfcmp, '32A', '','', f32A(msgp.menFecauto, mkt.mktPaymentcurr, monto))";

			Serializable compiled = MVEL.compileExpression(expressionf);

			MVEL.executeExpression(compiled, vars);
			log.info("en 111 {}", output.getValorObj());
			log.info("aaaaaaaaaaaaaaaa");
			expressionf = "output.valorObj=fGen(swfcmp, '20', 'SEME','', funcs.f20('XXX',1,msgp.menFecauto))";
			log.info("22222222222");
			compiled = MVEL.compileExpression(expressionf);
			log.info("333333333333");
			MVEL.executeExpression(compiled, vars);
			log.info("555555555555");
			log.info("en 222 {}", output.getValorObj());
			log.info("en 3333333333333");

			rm.setMktCorrespctry("CITYYYYYY");
			// vars.put("f20CF", FieldsCommand.f20Sup(rm));
			// Function<SwfMencampos, Supplier<CampoForm>> ff = s ->
			// FieldsCommand.f20Sup(rm, rm.getMktCorrespctry()).apply(s);
			expressionf = "output.valorObj=fGen(swfcmp, '20', 'SEME','', f20(mkt.mktCorrespctry))";
			expressionf = "output.valorObj=fGen(swfcmp, '20', 'SEME','', f20CF)";
			compiled = MVEL.compileExpression(expressionf);
			MVEL.executeExpression(compiled, vars);
			log.info("en 333 {}", output.getValorObj());

			rm.setMktCorrespctry("CITXXXXXXXXXXX");

			// expressionf = "output.valorObj=fGen(swfcmp, '20', 'ERTY','',
			// f20(mkt.mktCorrespctry))";
			expressionf = "output.valorObj=fGens(swfcmp, '20', 'ERTY','', f20CF)";
			// compiled = MVEL.compileExpression(expressionf, vars);
			MVEL.executeExpression(compiled, vars);
			log.info("en 55555 {}", output.getValorObj());

			Function<SwfMencampos, Optional<CampoForm>> f32A = sc -> {
				CampoForm cf = new CampoForm();
				Calendar c = GregorianCalendar.getInstance();
				c.setTime(new Date());
				Field field = new Field32A().setDate(c).setAmount(BigDecimal.valueOf(999.23)).setCurrency("EUR");
				cf.setValorObj(field);

				return Optional.of(cf);
			};
			vars.put("f32A", f32A);

			expressionf = "output.valorObj=fGen(swfcmp, '32A', '','', f32A)";
			compiled = MVEL.compileExpression(expressionf);
			MVEL.executeExpression(compiled, vars);
			log.info("en 666 {}", output.getValorObj());

		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	@Test
	public void campoNarrativeTest() {
		log.info("************ inico narraivtes ***************");
		try {
			List<String> narratives = Arrays.asList("/BNF/PAGO PRESTAMO ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}",
					"/BNF/INV 509098-0 ${REF}//LOAN ${REFA} DUE ${dateBO(FVCTO)}", "/BNF/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}", "/LNID/${REFA}",
					"/BNF/DAI/PEE/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/OFID LOAN No. ${REFA}//DUE ${dateBO(FVCTO)}//FREE OF CHARGE TO THE RECEIVER", "/BNF/${REF}",
					"/BNF/PROEX BOL ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}", "/BNF/REF.20220630 //PAGO ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}",
					"/BNF/COMISION DE ADMINISTRACION//VILLA TUNARI", "/BNF/PRINCIPAL REPAYMENT //${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/LOAN No. ${REFA}//MANAGEMENT FEE PAYMENT", "/BNF/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/${REFA}//ACC/PAY BEFORE 11:00 AM LOCAL TIME//MATURITY ${dateBO(FVCTO)}",
					"/BNF/BOLIVIA52013 ATTN:SONIA CRUZ //PAY BEFORE 10:00 AM LOCAL TIME",
					"/BNF/LOAN No.${REFA}//VENCIMIENTO ${dateBO(FVCTO)}//019ITT150948789R",
					"/REC/OUR/OUR DONT CHANGE FIELD //SEND 71 /BNF/PAGO ANTICIPADO PRESTAMO //FONDEN",
					"/BNF/3RA.CUOTA APORTE  CAPITAL/OC-BO 9NO.AUMENTO GENERAL //RESOLUCION NO.AG-7-10",
					"/BNF/10090600-100000413400//EUR 15-MAY-2022 LOAN ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/BOLIVIA2022 ATTN:SONIA CRUZ //PAY BEFORE 10:00 AM LOCAL TIME", "/BNF/PAGO AVAL CFC003073 //VCTO.22-05-2014",
					"/BNF/LOAN No. ${REFA}//MATURITY 21-01-2016//SUPPLEMENTARY PAYMENT//USD 10", "/BNF/LOAN No. ${REFA}//UNUTILIZED SPECIAL ACCOUNT",
					"/BNF/10090600-200000078400//USD 15-MAY-2022 LOAN ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/LNID/${lnid}/OCMT/${ntveAmt('',MNSWF,AMT)}/EXRT/AMOUNT ${exrt}", // "LNID/OCMT/EXRT",
					"/BNF/10054700-100000200800//USD 01-MAR-2022 LOAN ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/LOAN ADMIN-BOLIVIA ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}", "/BNF/LOAN No. ${REFA}//FRONT END FEE PAYMENT");
			narratives = Arrays.asList("/BNF/PAGO PRESTAMO ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}",
					"/BNF/INV 509098-0 ${REF}//LOAN ${REFA} DUE ${dateBO(FVCTO)}", "/BNF/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/LNID/${lnid}/OCMT/${ntveAmt('',MNSWF,AMT)}/EXRT/${exrt}", "/LNID/${REFA}", "formato libre ${dateBO(FVCTO)} de codiogo ${REFA} campo 70",
					"/BNF/DAI\\/PEE\\/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/OFID LOAN No. ${REFA}//DUE ${dateBO(FVCTO)}//FREE OF CHARGE TO THE RECEIVER");
			Map<String, Object> mapf = new HashMap<String, Object>();

			mapf.put("lnid", "929-SF-BO");
			mapf.put("exrt", BigDecimal.valueOf(6.86));
			mapf.put("FVCTO", new Date());
			mapf.put("REF", "REFERENCIA");
			mapf.put("REFA", "3942-BO");
			mapf.put("AMT", BigDecimal.valueOf(548669.23));
			mapf.put("MNSWF", "EUR");
			mapf.put("ntveAmt", ExpressionsMVELTest.class.getMethod("ntveAmt", String.class, String.class, BigDecimal.class));
			mapf.put("dateBO", MxDataTypesConversor.class.getMethod("dateBO", Date.class));
			mapf.put("ntveUnStr", ExpressionsMVELTest.class.getMethod("ntveUnStr", String.class, String.class));

			String strIni = "";
			String strFin = "/";
			Pattern pattern = Pattern.compile("" + strIni + "(/[A-Z0-9]{1,8}\\/)");

			for (String narr : narratives) {
				Map<String, String> cdmp = new LinkedHashMap<String, String>();
				Matcher matcher = pattern.matcher(narr);
				StringBuffer sb = new StringBuffer();
				log.info("	{}", narr);
				String cdLast = "";
				while (matcher.find()) {
					StringBuffer sb0 = new StringBuffer();
					String codeword = matcher.group(1);
					matcher.appendReplacement(sb0, "");
					if (!StringUtils.isBlank(cdLast)) {
						cdmp.put(cdLast, sb0.toString());
					}
					cdLast = codeword.replaceAll("/", "");
				}
				matcher.appendTail(sb);
				// log.info("***********tail -> {}", sb.toString());
				if (!StringUtils.isBlank(cdLast)) {
					cdmp.put(cdLast, sb.toString());
				} else {
					cdmp.put("", sb.toString());
				}

				Map<String, String> cdmpRes = new LinkedHashMap<String, String>();

				cdmp.forEach((k, v) -> {
					// log.info("{}:-> {}", k, v);
					CompiledTemplate compiled = compileTemplate(v);
					Object o = TemplateRuntime.execute(compiled, mapf);
					String txt = o.toString();
					String nrrtve = ntveUnStr(k, txt);
					cdmpRes.put(k, nrrtve);
					//log.info("	{} : {} -> {}", k, txt, nrrtve);
				});
				
				StringBuilder sbf = new StringBuilder();
				int i = 1;
			
				for(Entry<String, String> entry: cdmpRes.entrySet()) {
					String txt = entry.getValue();
					log.info("{} :: {} ", entry.getKey(), entry.getValue());
					sbf.append(txt).append(i++ < cdmpRes.size() ? "\r\n" : "");
				}
				Field72 f = new Field72(sbf.toString());
				log.info("fiel \n{} \n***************\n{}", sbf.toString(), f.getValue());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//@Test
	public void campNarrativeTest() {
		log.info("************ inico narraivtes ***************");
		try {
			List<String> narratives = Arrays.asList("/BNF/PAGO PRESTAMO ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}",
					"/BNF/INV 509098-0 ${REF}//LOAN ${REFA} DUE ${dateBO(FVCTO)}", "/BNF/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}", "/LNID/${REFA}",
					"/BNF/DAI\\/PEE\\/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/OFID LOAN No. ${REFA}//DUE ${dateBO(FVCTO)}//FREE OF CHARGE TO THE RECEIVER", "/BNF/${REF}",
					"/BNF/PROEX BOL ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}", "/BNF/REF.20220630 //PAGO ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}",
					"/BNF/COMISION DE ADMINISTRACION//VILLA TUNARI", "/BNF/PRINCIPAL REPAYMENT //${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/LOAN No. ${REFA}//MANAGEMENT FEE PAYMENT", "/BNF/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/${REFA}//ACC/PAY BEFORE 11:00 AM LOCAL TIME//MATURITY ${dateBO(FVCTO)}",
					"/BNF/BOLIVIA52013 ATTN:SONIA CRUZ //PAY BEFORE 10:00 AM LOCAL TIME",
					"/BNF/LOAN No.${REFA}//VENCIMIENTO ${dateBO(FVCTO)}//019ITT150948789R",
					"/REC/OUR/OUR DONT CHANGE FIELD //SEND 71 /BNF/PAGO ANTICIPADO PRESTAMO //FONDEN",
					"/BNF/3RA.CUOTA APORTE  CAPITAL/OC-BO 9NO.AUMENTO GENERAL //RESOLUCION NO.AG-7-10",
					"/BNF/10090600-100000413400//EUR 15-MAY-2022 LOAN ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/BOLIVIA2022 ATTN:SONIA CRUZ //PAY BEFORE 10:00 AM LOCAL TIME", "/BNF/PAGO AVAL CFC003073 //VCTO.22-05-2014",
					"/BNF/LOAN No. ${REFA}//MATURITY 21-01-2016//SUPPLEMENTARY PAYMENT//USD 10", "/BNF/LOAN No. ${REFA}//UNUTILIZED SPECIAL ACCOUNT",
					"/BNF/10090600-200000078400//USD 15-MAY-2022 LOAN ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/LNID/${lnid}/OCMT/${ntveAmt('',MNSWF,AMT)}/EXRT/AMOUNT ${exrt}", // "LNID/OCMT/EXRT",
					"/BNF/10054700-100000200800//USD 01-MAR-2022 LOAN ${REFA}//MATURITY ${dateBO(FVCTO)}",
					"/BNF/LOAN ADMIN-BOLIVIA ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}", "/BNF/LOAN No. ${REFA}//FRONT END FEE PAYMENT");
//			narratives = Arrays.asList("/BNF/PAGO PRESTAMO ${REFA}//VENCIMIENTO ${dateBO(FVCTO)}",
//					"/BNF/INV 509098-0 ${REF}//LOAN ${REFA} DUE ${dateBO(FVCTO)}", "/BNF/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}",
//					"/LNID/${lnid}/OCMT/${ntveAmt('',MNSWF,AMT)}/EXRT/${exrt}", "/LNID/${REFA}", "formato libre ${dateBO(FVCTO)} de codiogo ${REFA} campo 70",
//					"/BNF/DAI/PEE/LOAN No. ${REFA}//MATURITY ${dateBO(FVCTO)}",
//					"/BNF/OFID LOAN No. ${REFA}//DUE ${dateBO(FVCTO)}//FREE OF CHARGE TO THE RECEIVER");
			Map<String, Object> mapf = new HashMap<String, Object>();

			mapf.put("lnid", "929-SF-BO");
			mapf.put("exrt", BigDecimal.valueOf(6.86));
			mapf.put("FVCTO", new Date());
			mapf.put("REF", "REFERENCIA");
			mapf.put("REFA", "3942-BO");
			mapf.put("AMT", BigDecimal.valueOf(548669.23));
			mapf.put("MNSWF", "EUR");
//			mapf.put("ntveAmt", FieldsCommand.class.getMethod("ntveAmt", String.class, String.class, BigDecimal.class));
//			mapf.put("dateBO", MxDataTypesConversor.class.getMethod("dateBO", Date.class));
//			mapf.put("ntveUnStr", FieldsCommand.class.getMethod("ntveUnStr", String.class, String.class));

			for (String narr : narratives) {
				log.info("{}", narr);
				Map<String, String> cdmp = FieldsCommand.mapNarrative(narr, mapf);
				CampoForm cf0 = new CampoForm("Nrrtve", "infnxt", null);
				cf0.setValorObj(cdmp);
				
				CampoForm cf = FieldsCommand.f72Ntve(cf0).apply(null).get();
				
				Field72 f = (Field72) cf.getValorObj();
				log.info("=======> fiel {}", f.getValue());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static String ntveAmt(String codeword, String curr, BigDecimal amt) {
		Builder bN = Narrative.builder(35);
		bN.addCodewordWithAmount(codeword, curr, amt, null);
		Narrative nrrtve = bN.build();
		String prefix = "/" + StringUtils.trimToEmpty(codeword) + "/" + StringUtils.trimToEmpty(curr) + MxDataTypesConversor.amtFmt(amt);
		log.info("AMT {} - {}", nrrtve.getValue(), prefix);
		return nrrtve.getValue();
	}

	public static String ntveStr(String codeword, String narrative) {
		// estructurado
		Builder bN = Narrative.builder(35);
		bN.addCodeword(codeword, narrative);
		Narrative nrrtve = bN.build();
		return nrrtve.getUnstructured();
	}

	public static String ntveUnStr(String codeword, String narrative) {
		// estructurado
		Builder bN = Narrative.builder(UtilsGeneric.MAX_LINE_CHARS);
		log.info("narra {} :: {}", narrative , StringUtils.remove(narrative, '\\'));
		String cdSep = "//";
		List<String> result = SwiftParseUtils.splitComponents(narrative, "", cdSep);
		int start = 0;
		if (!StringUtils.isBlank(codeword)) {
			String txt = StringUtils.remove(result.get(0), '\\');
			bN.addCodeword(codeword, txt);
			start = 1;
		} else {
			cdSep = "";
		}

		for (int i = start; i < result.size(); i++) {
			List<String> lines = LineWrapper.wrapIntoList(result.get(i), UtilsGeneric.MAX_LINE_CHARS - 2);
			// log.info(" +UN ==> {} -> {}", result.get(i), lines.toString());
			for (String s : lines) {
				String txt = StringUtils.remove(s, '\\');
				bN.addUnstructured(cdSep + txt);
			}
		}

		Narrative nrrtve = bN.build();
		// log.info("UN ==> {}", nrrtve.getUnstructured(""));
		return nrrtve.getValue();
	}

	public static Function<SwfMencampos, Optional<CampoForm>> fff(Function<SwfMencampos, Optional<CampoForm>> fF) {
		return s -> {
			log.info("exec ..........." + fF);

			return fF.apply(s);
		};
	}

	public static Field fgen(String name, String qualifier, String codeset, CampoForm cf) {
		log.info("En fgen " + name + " null? " + (cf == null));
		// CampoForm cf = contentsF.apply(null).get();
		String contents = cf.getValor();
		Field field = null;

		if (name.equalsIgnoreCase("20C")) {
			field = new Field20C().setQualifier(qualifier).setReference(contents);
		} else if (name.equalsIgnoreCase("23G")) {
			field = new Field23G().setFunction(qualifier);
		} else if (name.equalsIgnoreCase("32A")) {
			field = new Field32A(cf.getValor());
		}
		return field;
	}

	public List<Rule> rulesFactory() {
		Rule r1 = new Rule("amount", "input.getMapFacts().containsKey('F32A')", "procesarFieldMT", 1, "F32A", "/root/documento/body/montotrx",
				"output.valorObj = input.fact('F32A');");
		r1.addAction("1", "output.valDecimal=F32A.amountAsBigDecimal;");
		r1.addAction("2", "output.column='amountAsBigDecimal';");

		List<Rule> rules = Arrays.asList(r1);
		return rules;
	}

	public static class Funciones {
		public Function<SwfMencampos, Supplier<CampoForm>> f20C() {
			return swfMencampos -> {
				return () -> {
					CampoForm cf = new CampoForm("val.getMtfCodmt()", "val.getMtfCodcampo()", "12345678");
					log.info("En fFP 3 {}", cf.getValor());
					return cf;
				};
			};
		}

		public Function<SwfMencampos, Supplier<CampoForm>> f20C(String valor) {
			return swfMencampos -> {
				return () -> {
					CampoForm cf = new CampoForm(swfMencampos.getMtfCodcampo(), "value", valor);
					return cf;
				};
			};
		}

		public static CampoForm f32A(Date fecha, BigDecimal amt, String curr) {
			log.info("En f32A 2 {}, {}", fecha, amt);
			Calendar c = GregorianCalendar.getInstance();
			c.setTime(fecha);
			Field32A field = new Field32A().setAmount(amt).setCurrency(curr).setDate(c);
			CampoForm cf = new CampoForm("val.getMtfCodmt()", "val.getMtfCodcampo()", field.getValue());
			log.info("En f32A 3");
			return cf;
		}
	}
}
