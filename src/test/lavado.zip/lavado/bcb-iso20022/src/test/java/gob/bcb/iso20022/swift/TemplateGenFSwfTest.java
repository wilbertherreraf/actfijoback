package gob.bcb.iso20022.swift;

import java.util.Calendar;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field50F;
import com.prowidesoftware.swift.model.field.Field50K;
import com.prowidesoftware.swift.model.field.Field59F;
import com.prowidesoftware.swift.model.mt.mt1xx.MT103;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.SwfMencampos;

public class TemplateGenFSwfTest {

	@Test
	public void generateCampoFormListTest() {
		
		Field50F f50F = new Field50F();
		f50F.setComponent1("ctaNro");
		f50F.setComponent2("1");
		f50F.setComponent3("name");		
		f50F.setComponent4("2");
		f50F.setComponent5("location");		
		f50F.setComponent6("3");
		f50F.setComponent7("plaza");

		Field59F f59F = new Field59F();

		SwfMencampos swfMencampos = new SwfMencampos();
		swfMencampos.setMtfNemo(f50F.getName());
		
		List<CampoForm> camposFormList = TemplateGenFSwf.convertToCampoForm().apply(swfMencampos, f50F);
		camposFormList.forEach(cf -> {
			System.out.println(cf.toStringCF());
		});
		
		Field32A f32A = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89").setDate(Calendar.getInstance());
		
		swfMencampos = new SwfMencampos();
		swfMencampos.setMtfNemo(f32A.getName());
		swfMencampos.setMtfNemo("SA.32A");
		
		camposFormList = TemplateGenFSwf.convertToCampoForm().apply(swfMencampos, f32A);
		camposFormList.forEach(cf -> {
			System.out.println(cf.toStringCF());
		});
		
		camposFormList = TemplateGenFSwf.fieldToCampoForm().apply(f32A);
		camposFormList.forEach(cf -> {
			System.out.println(cf.toStringCF());
		});
		
		Field50K f50K = new Field50K().setAccount("asdf1234").setNameAndAddress("dir y nomvre");
		
		camposFormList = TemplateGenFSwf.fieldToCampoForm().apply(f50K);
		camposFormList.forEach(cf -> {
			System.out.println(cf.toStringCF());
		});
		
		Field fld50K = new Field50K().setAccount("asdf1234").setNameAndAddress("dir y nomvre");
		
		camposFormList = TemplateGenFSwf.fieldToCampoForm().apply(fld50K);
		camposFormList.forEach(cf -> {
			System.out.println(cf.toStringCF());
		});		
	}
}
