package gob.bcb.iso20022.swift.saa;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.traversal.DocumentTraversal;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.prowidesoftware.swift.model.MxId;
import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.prowidesoftware.swift.model.mx.MxParseUtils;
import com.prowidesoftware.swift.model.mx.NamespaceReader;

import gob.bcb.iso20022.core.xml.JaxBConversionService;
import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.lau.AuthParameters;
import gob.bcb.iso20022.lau.LAU;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.utils.ArchivoUtil;
import gob.bcb.iso20022.utils.UtilsFile;

public class PduSignTest {
	private static final Logger log = LoggerFactory.getLogger(PduSignTest.class);
	public static String pdu = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Saa:DataPDU xmlns:Saa=\"urn:swift:saa:xsd:saa.2.0\"><Saa:Revision>2.0.6</Saa:Revision><Saa:LAU></Saa:LAU></Saa:DataPDU>";
	public static String secretKey = "Abcd1234abcd1234Abcd1234abcd1234";

	// @Test
	public void signVerfDocpru() {
		try {
			String nfile = "src/test/resources/sign/saa.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			// String xmlPDU = UtilsFile.readFileAsString2(nfile);
			log.info("======== inicio signverfpru======================");
			// log.info(xmlPDU);
			DataPDU myDataPDU = retPDU(nfile);
			Node node = docPdu(myDataPDU);
			log.info("======== xml from dataPDU ======================");
			log.info(node2XML(node));
			Document doc = pduToDoc(myDataPDU);
			String xmlDocPdu = JaxBConversionService.getStringFromDom(doc);
			log.info("-------------------xmlDocPdu------------");
			log.info(xmlDocPdu);
			String signed = signpru(doc);
			
			log.info("********************************signed*******************************");
			log.info(signed);

			Document docSign = JaxBConversionService.documentBasedOnThe(signed.getBytes());
			log.info("********************************Signature*******************************");
			log.info(xmlOfTag(docSign, "Signature"));
			log.info("DigestValue: " + valueOfTag(docSign, "DigestValue"));
			log.info("SignatureValue: " + valueOfTag(docSign, "SignatureValue"));
			verif(docSign);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void signverfXML() {
		try {
			pdu = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Saa:DataPDU xmlns:Saa=\"urn:swift:saa:xsd:saa.2.0\"><Saa:Revision>2.0.6</Saa:Revision></Saa:DataPDU>";
			// pdu = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><DataPDU
			// xmlns=\"urn:swift:saa:xsd:saa.2.0\"><Revision>2.0.6</Revision></DataPDU>";
			String nfile = "src/test/resources/sign/saa.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			log.info("======== inicio signverfXML Orig======================");
			// log.info(xmlPDU);
			String xmlRetPDU = xmlRetPDU(nfile);
			log.info("++++++++++++++++ xml from PDU++++++++++++++++");
			log.info(xmlRetPDU);
			Document document = JaxBConversionService.getDomFromString(xmlRetPDU);
			String xmlDocPdu = JaxBConversionService.getStringFromDom(document);
			log.info(".................. xml from PDU Doc..................");
			log.info(xmlDocPdu);
			Document documentVer = JaxBConversionService.getDomFromString(xmlDocPdu);
			String xmlDocPduVer = JaxBConversionService.getStringFromDom(documentVer);
			log.info("------------ xml from PDU Doc Ver------------");
			log.info(xmlDocPduVer);
			String hashDoc = ArchivoUtil.hashString(xmlDocPdu);
			String hashDocVer = ArchivoUtil.hashString(xmlDocPduVer);
			log.info("hash " + hashDoc + " Ver: " + hashDocVer);

			String signedXml = signXml(xmlDocPdu);
			log.info("------------ signed xml------------");
			log.info(signedXml);

			Document docSign = JaxBConversionService.getDomFromString(signedXml);
			log.info("********************************Signature*******************************");
			log.info(xmlOfTag(docSign, "Signature"));
			log.info("SignedInfo: " + xmlOfTag(docSign, "SignedInfo"));
			log.info("DigestValue: " + valueOfTag(docSign, "DigestValue"));
			log.info("SignatureValue: " + valueOfTag(docSign, "SignatureValue"));
			verif(docSign);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	//@Test
	public void signverfXMLSinNS() {
		try {
			String nfile = "src/test/resources/sign/pacsaa.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			log.info("======== inicio signverfXML Orig======================");
			// log.info(xmlPDU);
			final String xmlRetPDU = xmlRetPDUNS(nfile);
			String hashPdu = ArchivoUtil.hashString(xmlRetPDU);
			log.info("++++++++++++++++ xml from PDU++++++++++++++++");
			log.info(xmlRetPDU);
			Document document = JaxBConversionService.getDomFromString(xmlRetPDU);
			String xmlDocPdu = JaxBConversionService.getStringFromDom(document);
			String hashxmlDocPdu = ArchivoUtil.hashString(xmlDocPdu);
			log.info("Hash pdu " + hashPdu + " sioganable : " + hashxmlDocPdu);
			log.info(".................. xml Signable PDU Doc..................");
			log.info(xmlDocPdu);
			String signedXml = signXmlNS(xmlRetPDU);
			log.info("------------ signed xml------------");
			log.info(signedXml);
			Document docSign = JaxBConversionService.getDomFromString(signedXml);
			log.info("********************************Signature*******************************");
			log.info(xmlOfTag(docSign, "Signature"));
			log.info("SignedInfo: " + xmlOfTag(docSign, "SignedInfo"));
			log.info("DigestValue: " + valueOfTag(docSign, "DigestValue"));
			log.info("SignatureValue: " + valueOfTag(docSign, "SignatureValue"));
			verif(docSign);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	//@Test
	public void signDataPDUTest() {
		try {
			String nfile = "src/test/resources/sign/pacsaa.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			log.info("======== inicio signDataPDUTest======================");
			final String xmlRetPDU = xmlRetPDUNS(nfile);
			log.info("++++++++++++++++ xml from PDU++++++++++++++++");
			log.info(xmlRetPDU);
			String signedXml = signXmlNS(xmlRetPDU);
			log.info("------------ signed xml------------");
			log.info(signedXml);
			
			AuthParameters authParameters = new AuthParameters("Abcd1234abcd1234","Abcd1234abcd1234");
			LAU signer = new LAU();
			String signedPayload = signer.signXmlV2(xmlRetPDU, authParameters);
			log.info("############### signed LAU###############");
			log.info(signedPayload);
			Document docSign = JaxBConversionService.getDomFromString(signedXml);
			log.info("********************************Signature*******************************");
			log.info(xmlOfTag(docSign, "Signature"));
			log.info("SignedInfo: " + xmlOfTag(docSign, "SignedInfo"));
			log.info("DigestValue: " + valueOfTag(docSign, "DigestValue"));
			log.info("SignatureValue: " + valueOfTag(docSign, "SignatureValue"));
			boolean validSign = verif(docSign);
			boolean valid = signer.validate(signedXml, authParameters);
			log.info("validSign: " + validSign + " cLAU: " + valid);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
	
	@Test
	public void signValidLAUTest() {
		try {
			String nfile = "src/test/resources/sign/pacsaa.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			log.debug("======== inicio signValidLAUTestTest======================");
			String xmlPac = UtilsFile.readFileAsString2(nfile);
			DataPDUWriter w = new DataPDUWriter().xmlPduFromFile(nfile);
			final String xmlRetPDU = w.xmlSaa();
			log.info("++++++++++++++++ xml from PDU++++++++++++++++");
			log.info(xmlRetPDU);
			
			AuthParameters authParameters = new AuthParameters("Abcd1234abcd1234","Abcd1234abcd1234");
			LAU signer = new LAU();
			String signedPayload = signer.signXmlV2(xmlRetPDU, authParameters);
			log.info("############### signed LAU###############");
			log.info(signedPayload);
			boolean valid = signer.validate(signedPayload, authParameters);
			
			DataPDUWriter pduSign = new DataPDUWriter().xml(signedPayload);
			String xmlPDU = pduSign.xmlSaa();
			log.info("---------------- xmlPDU----------------");
			log.info(xmlPDU);
			String hashPdu = ArchivoUtil.hashString(signedPayload);
			String hashDoc = ArchivoUtil.hashString(xmlPDU);
			log.info("lauSig: " + hashPdu + " pduSigned: " + hashDoc);
			log.info("validSign: " + valid);
			log.info("SignedInfo: " + signer.getSignedInfo());
			log.info("DigestValue: " + signer.getDigestValue());
			String hex = DatatypeConverter.printHexBinary(signer.getSignatureValue().getBytes());			
			log.info("SignatureValue: " + signer.getSignatureValue() + " " + hex);
			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}		
	//@Test
	public void verificaHashXML() {
		try {
			String nfile = "src/test/resources/sign/pacsaa.xml"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			String xmlRetPDU = xmlRetPDUNS(nfile);
			log.info("++++++++++++++++ xml from PDU++++++++++++++++");
			log.info(xmlRetPDU);
			Document document = JaxBConversionService.getDomFromString(xmlRetPDU);
			String xmlDocPdu = JaxBConversionService.getStringFromDom(document);
			log.info(".................. xml from PDU Doc..................");
			log.info(xmlDocPdu);
			Document documentVer = JaxBConversionService.getDomFromString(xmlDocPdu);
			String xmlDocPduVer = JaxBConversionService.getStringFromDom(documentVer);
			log.info("------------ xml from PDU Doc Ver------------");
			log.info(xmlDocPduVer);
			String hashPdu = ArchivoUtil.hashString(xmlRetPDU);
			String hashDoc = ArchivoUtil.hashString(xmlDocPdu);
			String hashDocVer = ArchivoUtil.hashString(xmlDocPduVer);
			log.info("hashpdu: " + hashPdu + "hashDoc " + hashDoc + " Ver: " + hashDocVer);
			UtilsFile.grabaEnArchivo2(xmlRetPDU, "e:/tmp/xmlpdu.xml");
			UtilsFile.grabaEnArchivo2(xmlDocPdu, "e:/tmp/xmldocpdu.xml");
			UtilsFile.grabaEnArchivo2(xmlDocPduVer, "e:/tmp/xmldocver.xml");
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	public String signWithoutNS(Document document) {
		try {
			XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");
			SignatureMethod signatureMethod = factory.newSignatureMethod("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256", null);

			CanonicalizationMethod canonicalizationMethod = factory.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (XMLStructure) null);

			List<Transform> transforms = new ArrayList<Transform>();
			transforms.add(factory.newTransform(Transform.ENVELOPED, (XMLStructure) null));
			transforms.add(factory.newTransform("http://www.w3.org/2001/10/xml-exc-c14n#", (XMLStructure) null));

			DigestMethod digestMethod = factory.newDigestMethod("http://www.w3.org/2001/04/xmlenc#sha256", null);

			Reference reference = factory.newReference("", digestMethod, transforms, null, null);

			SignedInfo signedInfo = factory.newSignedInfo(canonicalizationMethod, signatureMethod, Collections.singletonList(reference));

			SecretKeySpec secret_key = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");

			Element LAUElement = document.createElement("Saa:LAU");
			Element rootElement = document.getDocumentElement();
			rootElement.appendChild(LAUElement);

			DOMSignContext domSignContext = new DOMSignContext(secret_key, LAUElement);
			domSignContext.setDefaultNamespacePrefix("ds");

			XMLSignature signature = factory.newXMLSignature(signedInfo, null);
			signature.sign(domSignContext);
			String signed = JaxBConversionService.getStringFromDom(document);
			return signed;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;
	}

	public String signpru(Document document) {
		try {
			XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");
			SignatureMethod signatureMethod = factory.newSignatureMethod("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256", null);

			CanonicalizationMethod canonicalizationMethod = factory.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (XMLStructure) null);

			List<Transform> transforms = new ArrayList<Transform>();
			transforms.add(factory.newTransform(Transform.ENVELOPED, (XMLStructure) null));
			transforms.add(factory.newTransform("http://www.w3.org/2001/10/xml-exc-c14n#", (XMLStructure) null));

			DigestMethod digestMethod = factory.newDigestMethod("http://www.w3.org/2001/04/xmlenc#sha256", null);

			Reference reference = factory.newReference("", digestMethod, transforms, null, null);

			SignedInfo signedInfo = factory.newSignedInfo(canonicalizationMethod, signatureMethod, Collections.singletonList(reference));

			SecretKeySpec secret_key = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");

			Element LAUElement = document.createElementNS("urn:swift:saa:xsd:saa.2.0", "Saa:LAU");
			LAUElement.setAttribute("xmlns:Saa", "urn:swift:saa:xsd:saa.2.0");
			Element rootElement = document.getDocumentElement();
			rootElement.appendChild(LAUElement);

			DOMSignContext domSignContext = new DOMSignContext(secret_key, LAUElement);
			domSignContext.setDefaultNamespacePrefix("ds");

			XMLSignature signature = factory.newXMLSignature(signedInfo, null);
			signature.sign(domSignContext);
			String signed = JaxBConversionService.getStringFromDom(document);
			return signed;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;
	}

	public String signXml(String xml) {
		try {
			Document document = JaxBConversionService.getDomFromString(xml);
			return signpru(document);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;

	}

	public String signXmlNS(String xml) {
		try {
			Document document = JaxBConversionService.getDomFromString(xml);
			return signWithoutNS(document);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;

	}

	public String signpru2(DataPDU myDataPDU) {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(DataPDU.class);
			Marshaller marshaller = jaxbContext.createMarshaller();
			DOMResult domResult = new DOMResult();
			marshaller.marshal(myDataPDU, domResult);
			Document document = (Document) domResult.getNode();
			XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");
			SignatureMethod signatureMethod = factory.newSignatureMethod("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256", null);

			CanonicalizationMethod canonicalizationMethod = factory.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (XMLStructure) null);

			List<Transform> transforms = new ArrayList<Transform>();
			transforms.add(factory.newTransform(Transform.ENVELOPED, (XMLStructure) null));
			transforms.add(factory.newTransform("http://www.w3.org/2001/10/xml-exc-c14n#", (XMLStructure) null));

			DigestMethod digestMethod = factory.newDigestMethod("http://www.w3.org/2001/04/xmlenc#sha256", null);

			Reference reference = factory.newReference("", digestMethod, transforms, null, null);

			SignedInfo signedInfo = factory.newSignedInfo(canonicalizationMethod, signatureMethod, Collections.singletonList(reference));

			SecretKeySpec secret_key = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");

			Element LAUElement = document.createElementNS("urn:swift:saa:xsd:saa.2.0", "Saa:LAU");
			LAUElement.setAttribute("xmlns:Saa", "urn:swift:saa:xsd:saa.2.0");
			Element rootElement = document.getDocumentElement();
			rootElement.appendChild(LAUElement);

			DOMSignContext domSignContext = new DOMSignContext(secret_key, LAUElement);
			domSignContext.setDefaultNamespacePrefix("ds");

			XMLSignature signature = factory.newXMLSignature(signedInfo, null);
			signature.sign(domSignContext);

			String signed = JaxBConversionService.getStringFromDom(document);
			return signed;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;
	}

	public Document pduToDoc(DataPDU myDataPDU) {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(DataPDU.class);
			Marshaller marshaller = jaxbContext.createMarshaller();

			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true);
			DocumentBuilder docBuilder = domFactory.newDocumentBuilder();
			Document document = docBuilder.newDocument();
			DOMResult domResult = new DOMResult(document);
			marshaller.marshal(myDataPDU, domResult);
			return document;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;
	}

	public DataPDU retPDU() {
		DataPDU myDataPDU = new DataPDU();
		myDataPDU.setRevision("2.0.6");
		return myDataPDU;
	}

	public String xmlRetPDU(String nFile) {
		String xmlPDU = UtilsFile.readFileAsString2(nFile);
		final AbstractMX source = AbstractMX.parse(xmlPDU);

		DataPDUWriter w = new DataPDUWriter(source).xml(xmlPDU);
		String xml = w.xmlSaa();
		return xml;
	}

	public String xmlRetPDUNS(String nFile) {
		String xmlPDU = UtilsFile.readFileAsString2(nFile);
		final AbstractMX source = AbstractMX.parse(xmlPDU);

		DataPDUWriter w = new DataPDUWriter(source).xml(xmlPDU);
		String xml = w.xmlSaa();
		return xml;
	}

	public DataPDU retPDU(String nFile) {
		String xmlPDU = UtilsFile.readFileAsString2(nFile);
		final AbstractMX source = AbstractMX.parse(xmlPDU);

		DataPDUWriter w = new DataPDUWriter(source);
		DataPDU dataPDU = w.xml(xmlPDU).getDataPDU();
		String xml = w.xmlSaa();
		log.info("+++++++++++++++++++++++++++ xml Transform ++++++++++++++++++++");
		log.info(xml);
		return dataPDU;
	}

	public Node docPdu(DataPDU myDataPDU) {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(DataPDU.class);
			Marshaller marshaller = jaxbContext.createMarshaller();
			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true);
			DocumentBuilder docBuilder = domFactory.newDocumentBuilder();
			Document document = docBuilder.newDocument();
			DOMResult domResult = new DOMResult(document);
			marshaller.marshal(myDataPDU, domResult);

			return domResult.getNode();
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;
	}

	public boolean verif(Document doc) {
		try {
			XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");

			NodeList sigList = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
			if (sigList.getLength() == 0) {
				throw new Exception("Cannot find Signature element");
			}
			SecretKeySpec secret_key = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");
			DOMValidateContext valContext = new DOMValidateContext(secret_key, sigList.item(0));
			XMLSignature signature = factory.unmarshalXMLSignature(valContext);
			return signature.validate(valContext);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return false;
	}

	public static String node2XML(Node node) throws TransformerException {
		if (node == null)
			return null;
		String processedXML = null;

		// Transform the DOM tree into XML String
		TransformerFactory transFactory = TransformerFactory.newInstance();
		Transformer transformer = transFactory.newTransformer();
		// transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		DOMSource dSource = new DOMSource(node);
		StringWriter sw = new StringWriter();
		StreamResult sr = new StreamResult(sw);
		transformer.transform(dSource, sr);

		StringWriter anotherSW = (StringWriter) sr.getWriter();
		StringBuffer sBuffer = anotherSW.getBuffer();
		processedXML = sBuffer.toString();

		return processedXML;
	}

	public Element getSignedInfo(Document doc) {
		try {
			XPathFactory xpf = XPathFactory.newInstance();
			XPath xpath = xpf.newXPath();

			String expression = "//ds:Signature[1]";
			Element sigElement = (Element) xpath.evaluate(expression, doc, XPathConstants.NODE);
			return sigElement;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;
	}

	public static String xmlOfTag(Document doc, String tag) throws ParserConfigurationException, SAXException, IOException, TransformerException {
		Node node = findTagInDoc(doc, tag);
		return node2XML(node);
	}

	public static String valueOfTag(Document doc, String tag) throws ParserConfigurationException, SAXException, IOException, TransformerException {
		Element e = findTagInDoc(doc, tag);
		return e.getTextContent();
	}

	public static Document getDomFromString(String xmlSource) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();

		return builder.parse(new InputSource(new StringReader(xmlSource)));
	}

	public static Element findTagInDoc(Document doc, String tag) {
		NodeIterator ni = ((DocumentTraversal) doc).createNodeIterator(doc.getDocumentElement(), NodeFilter.SHOW_ELEMENT, null, false);

		for (Node n = ni.nextNode(); n != null; n = ni.nextNode()) {
			if (tag.equals(n.getLocalName())) {
				return (Element) n;
			}
		}
		return null;
	}

	public void namespaceTest() {
		try {
			log.info("======== inicio dataPDUFromXmlTest======================");
			DataPDUWriter w = new DataPDUWriter();
			String xmlPDU = XmlToMap.xmlSaaFromXPath(mapPropsSaa1(), "");
			boolean existDataPDU = NamespaceReader.elementExists(xmlPDU, "DataPDU");
			boolean existDoc = NamespaceReader.elementExists(xmlPDU, "Document");
			boolean existHdr = NamespaceReader.elementExists(xmlPDU, "AppHdr");
			
			Optional<String> nsDoc = NamespaceReader.findDocumentNamespace(xmlPDU);
			log.info((nsDoc.isPresent() ? nsDoc.get() : "NSNONE")+ " existDoc? "+ existDoc+" ***existDataPDU? "+existDataPDU+"***existHdr ? "+existHdr+"******* xmlPDU "+ xmlPDU);
			DataPDU pdu = w.xml(xmlPDU).getDataPDU();
			log.info("SenderReference " + pdu.getHeader().getMessage().getSenderReference());
			
			Optional<MxId> id = MxParseUtils.identifyMessage(xmlPDU);
			log.info("MxId " + id.isPresent());
			MxId idMx = new MxId("pacs.008.001.07");
			AbstractMX source = AbstractMX.parse(xmlPDU, idMx);
			//log.info("	HDR $$$$$$$$$$$$ \n" + hdr.xml());				
			log.info("	*************** MX ************ \n " + source.message());				
			
			SwiftMessageAbstract sm = FactoryParser.createParser(xmlPDU);
			log.info("	*************** sm.getMenPlano() ************ \n " + sm.getMenPlano());			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}		
	}
	
	public static LinkedHashMap<String, Object> mapPropsSaa1() {
		LinkedHashMap<String, Object> mapSaa = new LinkedHashMap<String, Object>();

		mapSaa.put("/Saa:DataPDU/Saa:Revision","2.0.13");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SenderReference","BCEBBOLPAXXXDOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:MessageIdentifier","pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Format","MX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SubFormat","Input");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:DN","ou=xxx,o=bcebbolp,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:FullName/Saa:X1","BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:DN","ou=xxx,o=scblus33,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:FullName/Saa:X1","SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:UserReference","DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:ServiceURI","mp/mx/__mRWkJI2EeuXfsPBlWnVxg");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:MessageTypeURI","mp/mx/__mRWkJI2EeuXfsPBlWnVxg/__mSksJI2EeuXfsPBlWnVxg");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Priority","Normal");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Service","swift.finplus");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestType","pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestSubtype","swift.cbprplus.02");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/Fr/FIId/FinInstnId/BICFI","BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/To/FIId/FinInstnId/BICFI","SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/BizMsgIdr","DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/MsgDefIdr","pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/BizSvc","swift.cbprplus.02");
		mapSaa.put("/Saa:DataPDU/Saa:Body/AppHdr/CreDt","2021-12-02T03:25:54+00:00");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/MsgId","DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/CreDtTm","9999-12-31T00:00:00+00:00");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/NbOfTxs","1");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/SttlmMtd","INDA");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/GrpHdr/SttlmInf/SttlmAcct/Id/Othr/Id","3544020682001");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/InstrId","DOCC 103C");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/EndToEndId","NOTPROVIDED");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/PmtId/UETR","035c661a-da4b-427f-ad76-b8d3182daa79");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmAmt","8923793.51");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmDt","2022-04-29");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/ChrgBr","DEBT");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstgAgt/FinInstnId/BICFI","BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/InstdAgt/FinInstnId/BICFI","SCBLUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/BICFI","CITIUS33XXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/Nm","YACIMIENTOS PETROLIFEROS FISCALESBOLIVIANOS");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/StrtNm","BUENO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/BldgNb","185");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/TwnNm","LA PAZ");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Dbtr/PstlAdr/Ctry","BO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAcct/Id/Othr/Id","3987");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/DbtrAgt/FinInstnId/BICFI","BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/Nm","BANCO DE CREDITO E INVERSIONES");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/PstlAdr/TwnNm","SANTIAGO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgt/FinInstnId/PstlAdr/Ctry","CL");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAgtAcct/Id/Othr/Id","36010307");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/Nm","TRAFIGURA CHILE LIMITADA");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/Dept","OFICINA 1401");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/StrtNm","ISIDORA GOYENECHEA");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/BldgNb","3365");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/TwnNm","SANTIAGO");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/Cdtr/PstlAdr/Ctry","CL");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id","18553435");
		mapSaa.put("/Saa:DataPDU/Saa:Body/Document/FIToFICstmrCdtTrf/CdtTrfTxInf/RmtInf/Ustrd","PAGO A TRAFIGURA CHILE LIMITADA 21ER POST PAGO POR SUM HIDR LIQ OCCIDENTE 2021 SEGUN OP UPCA N");

		return mapSaa;
	}
		
}
