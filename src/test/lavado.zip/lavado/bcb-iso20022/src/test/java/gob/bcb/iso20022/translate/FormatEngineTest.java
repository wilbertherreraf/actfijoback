package gob.bcb.iso20022.translate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import java.util.logging.Level;
//import java.util.logging.Logger;
import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.MxId;
import com.prowidesoftware.swift.model.mt.AbstractMT;

import gob.bcb.iso20022.model.SwfReglasmerc;
import gob.bcb.iso20022.pojo.CampoFormTable;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.MappingRule;
import gob.bcb.iso20022.swift.MappingTable;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.transforms.FactValTransform;
import gob.bcb.iso20022.transforms.TextSimpleTransform;
import gob.bcb.iso20022.utils.UtilsFile;

public class FormatEngineTest {
	//private final Log log = LogFactory.getLog(getClass());
	private static final Logger log = LoggerFactory.getLogger(FormatEngineTest.class);
	private final static String MPPBAS_FILE = "src/test/resources/xls/mppbas.xlsx";
	private final static String mt103_pacs008_SHEET = "mt103_pacs.008";
	private final static String mt202_pacs009_SHEET = "mt202_pacs.009";
	private final static Integer firstRowData = 2;
	
	//@Test
	public void generarSwift() {
		try {
			Bar bean = new Bar();
			bean.setAge(100);
			bean.setName("name bean");
			
			Foo foo = new Foo();
			foo.setAge(100);
			foo.setName("name foo");
			foo.setMonto(BigDecimal.TEN);
			
			BIC bic = new BIC("CHASUS01123");
			CampoFormTable cft = new CampoFormTable("bean", bean).recProps();
			cft.newSEnt("foo")//
			.putAtr("nm", foo.getName()).putAtr("amount", foo.getMonto())//
			.putAtr("bic", bic.getBic8());
			;
			
			cft.newSEnt("bco")//
			.putAtr("calle", foo.getName()).putAtr("casanro", 555)//
			.putAtr("bic", bic.getBic8());
			;
			
			Map<String, Object> mapAtrs = new HashMap<String, Object>();
			mapAtrs.put("bic", "FHHRTY00");
			mapAtrs.put("nombre", "nombre intermediario");
			
			cft.newSEnt("intermediario", mapAtrs);
			
			String typeMessage= "pacs.009.001.09";			
			MappingTable mappingTable = new MappingTable(typeMessage, FileFormat.MT, FileFormat.MX);
			
			String nfile = "src/test/resources/mts/M03.txt";
			String mtrje = UtilsFile.readFileAsString2(nfile);
			
			SwiftMessageAbstract sma = FactoryParser.createParser(mtrje);
			
			AbstractMT amt = (AbstractMT) sma.getAbsMsg();

			log.info("MT MT MT MT MT MT MT MT  ");
			log.info(mtrje);
			
			amt.getFields().forEach(f -> {
				mappingTable.putFact("F" + f.getName().toUpperCase(), f);
			});
			
			mappingTable.putFact("sender", amt.getSender());
			mappingTable.putFact("receiver", amt.getReceiver());
			mappingTable.putFact("bean", cft);
			mappingTable.putFact("agtacree", cft);
			
			mappingTable.newFactAndAtribs("inter", bean, "bco", mapAtrs, false);
			
			MappingRule mapRule = new MappingRule();
			mapRule.addRule("instfin", "direccion", "valor line 1", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/PstlAdr/AdrLine[1]", new FactValTransform());
			mappingTable.addMappingRule(mapRule);
			
			mapRule = new MappingRule();
			mapRule.addRule("instfin", "adrline2", "output.valor=bean.sEnt('foo').fld('nm')", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/PstlAdr/AdrLine[2]", new TextSimpleTransform());
			mappingTable.addMappingRule(mapRule);
			
			mapRule = new MappingRule();
			mapRule.addRule("instfin", "adrline3", "output.valor=bean.atrS('name')", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/PstlAdr/AdrLine[3]", new TextSimpleTransform());
			mappingTable.addMappingRule(mapRule);
			
			mapRule = new MappingRule();
			mapRule.addRule("instfin", "adrline4", "output.valor=bean.sEnt('foo').fld('bic')", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/PstlAdr/AdrLine[4]", new TextSimpleTransform());
			mappingTable.addMappingRule(mapRule);
			
			FormatEngine formatEngine = FormatEngine.getInstance().configRulesXls(MPPBAS_FILE, mt202_pacs009_SHEET, firstRowData)//
					.readRulesXls(sma.messageType())//
					.initEngineRules()//
			;

			formatEngine = FormatEngine.getInstance().configRulesXls(MPPBAS_FILE, mt202_pacs009_SHEET, firstRowData)//
					.readRulesXls(sma.messageType())//
					.initEngineRules()//
			;
			formatEngine = FormatEngine.getInstance().configRulesXls(MPPBAS_FILE, mt202_pacs009_SHEET, firstRowData)//
					.readRulesXls(sma.messageType())//
					.initEngineRules()//
			;
			MappingTable mpptab = formatEngine.translate(mappingTable);
			mpptab.setTypeMessage(typeMessage);
			
			Map<String, String> mxProp = mpptab.toProperties();
			
			log.info("PROP PROP PROP " + typeMessage +  " - " + mpptab.getTypeMessage() + " PROP PROP PROP PROP PROP ");
			mxProp.forEach((k,v) -> {
				log.info(k + " => " + v);
			});
			
			String mxXml = mpptab.toXML();
			
			log.info("XML XML XML XML" + typeMessage +  " - " + mpptab.getTypeMessage() + " XML XML XML XML XML  ");
			log.info(mxXml);
			
			
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	@Test
	public void generarSwiftEvalRules() {
		try {
			SwfReglasmerc mkt = new SwfReglasmerc();
			
			Bar bean = new Bar();
			bean.setAge(100);
			bean.setName("name bean");
			
			Foo foo = new Foo();
			foo.setAge(100);
			foo.setName("name foo");
			foo.setMonto(BigDecimal.TEN);
			
			BIC bic = new BIC("CHASUS01123");
			CampoFormTable cft = new CampoFormTable("bean", bean).recProps();
			cft.newSEnt("foo")//
			.putAtr("nm", foo.getName()).putAtr("amount", foo.getMonto())//
			.putAtr("bic", bic.getBic8());
			;
			
			cft.newSEnt("bco")//
			.putAtr("calle", foo.getName()).putAtr("casanro", 555)//
			.putAtr("bic", bic.getBic8());
			;
			
			Map<String, Object> mapAtrs = new HashMap<String, Object>();
			mapAtrs.put("bic", "FHHRTY00");
			mapAtrs.put("nombre", "nombre intermediario");
			
			cft.newSEnt("intermediario", mapAtrs);
			
			String typeMessage= "pacs.009.001.09";			
			MappingTable mappingTable = new MappingTable(typeMessage, FileFormat.MT, FileFormat.MX);
			
			String nfile = "src/test/resources/mts/M03.txt";
			String mtrje = UtilsFile.readFileAsString2(nfile);
			
			SwiftMessageAbstract sma = FactoryParser.createParser(mtrje);
			
			AbstractMT amt = (AbstractMT) sma.getAbsMsg();

			log.info("MT MT MT MT MT MT MT MT  ");
			log.info(mtrje);
			
			amt.getFields().forEach(f -> {
				mappingTable.putFact("F" + f.getName().toUpperCase(), f);
			});
			
			mappingTable.putFact("sender", amt.getSender());
			mappingTable.putFact("receiver", amt.getReceiver());
			mappingTable.putFact("bean", cft);
			mappingTable.putFact("agtacree", cft);
			
			mappingTable.newFactAndAtribs("inter", bean, "bco", mapAtrs, false);
			
			MappingRule mapRule = new MappingRule();
			mapRule.addRule("instfin", "direccion", "valor line 1", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/PstlAdr/AdrLine[1]", new FactValTransform());
			mappingTable.addMappingRule(mapRule);
			
			mapRule = new MappingRule();
			mapRule.addRule("instfin", "adrline2", "output.valor=bean.sEnt('foo').fld('nm')", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/PstlAdr/AdrLine[2]", new TextSimpleTransform());
			mappingTable.addMappingRule(mapRule);
			
			mapRule = new MappingRule();
			mapRule.addRule("instfin", "adrline3", "output.valor=bean.atrS('name')", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/PstlAdr/AdrLine[3]", new TextSimpleTransform());
			mappingTable.addMappingRule(mapRule);
			
			mapRule = new MappingRule();
			mapRule.addRule("instfin", "adrline4", "output.valor=bean.sEnt('foo').fld('bic')", "/message/Document/FICdtTrf/CdtTrfTxInf/IntrmyAgt1/FinInstnId/PstlAdr/AdrLine[4]", new TextSimpleTransform());
			mappingTable.addMappingRule(mapRule);
			
			FormatEngine formatEngine = FormatEngine.getInstance().configRulesXls(MPPBAS_FILE, mt202_pacs009_SHEET, firstRowData)//
					.readRulesXls(sma.messageType())//
					.initEngineRules()//
			;

			formatEngine = FormatEngine.getInstance().configRulesXls(MPPBAS_FILE, mt202_pacs009_SHEET, firstRowData)//
					.readRulesXls(sma.messageType())//
					.initEngineRules()//
			;
			formatEngine = FormatEngine.getInstance().configRulesXls(MPPBAS_FILE, mt202_pacs009_SHEET, firstRowData)//
					.readRulesXls(sma.messageType())//
					.initEngineRules()//
			;
			MappingTable mpptab = formatEngine.translate(mappingTable);
			mpptab.setTypeMessage(typeMessage);
			
			Map<String, String> mxProp = mpptab.toProperties();
			
			log.info("PROP PROP PROP " + typeMessage +  " - " + mpptab.getTypeMessage() + " PROP PROP PROP PROP PROP ");
			mxProp.forEach((k,v) -> {
				log.info(k + " => " + v);
			});
			
			String mxXml = mpptab.toXML();
			
			log.info("XML XML XML XML" + typeMessage +  " - " + mpptab.getTypeMessage() + " XML XML XML XML XML  ");
			log.info(mxXml);
		
			
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	
	public class Bar {
		private String name = "dog";
		private boolean woof = true;
		private int age = 14;
		private BigDecimal monto;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public boolean isWoof() {
			return woof;
		}
		public void setWoof(boolean woof) {
			this.woof = woof;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public BigDecimal getMonto() {
			return monto;
		}
		public void setMonto(BigDecimal monto) {
			this.monto = monto;
		}
	}
	
	public class Foo {
		private String name = "dog";
		private boolean woof = true;
		private int age = 14;
		private BigDecimal monto;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public boolean isWoof() {
			return woof;
		}
		public void setWoof(boolean woof) {
			this.woof = woof;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public BigDecimal getMonto() {
			return monto;
		}
		public void setMonto(BigDecimal monto) {
			this.monto = monto;
		}
	}
}
