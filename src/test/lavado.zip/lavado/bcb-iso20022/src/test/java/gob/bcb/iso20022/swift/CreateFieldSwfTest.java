package gob.bcb.iso20022.swift;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.mx.AbstractMX;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.saa.DataPDUWriter;

public class CreateFieldSwfTest {
	private static final Logger log = LoggerFactory.getLogger(CreateFieldSwfTest.class);
	
	//@Test
	public void createMsgNoCompletoMx() {
		log.info("********** ininciooooooooooooooooooooooo /////////////////");
		try {
			String mt = "pacs.008.001.09";
			String formato = "MX";
			SwfMsgParam swfMsgParam = CreateFieldSwfServ.recMsgParms(mt, formato);
			CreateFieldSwfServ srv = new CreateFieldSwfServ(swfMsgParam, null);
			Instruccion instr = srv.initInstruccion();
			srv.addFact("instr", instr.getSwfMsgParam());
			srv.addFact("dbtr", CreateFieldSwfServ.factDbtr());
			srv.recuperarCampos("");
			srv.registerFuncsDef();
			srv.initEngine();
			srv.translate();
			instr.getMapTableResult().getMappingRuleList().forEach(m -> {
				log.info("" + m.getSwfCampo().getMtfId());
			});
			srv.translatePost();
			//srv.generaHeaderMsg();			
			srv.createMsgSwift();
			
			String xml = srv.createMsgSwift();
			log.info("................... " + xml);
			SwiftMessageAbstract sma = instr.getMessageHolder();
			log.info("==================== " + sma.getMenPlanoOrig());			
			DataPDUWriter w = new DataPDUWriter((AbstractMX) sma.getAbsMsg());
//			String xmlPDU = w.xml(sma.getMenPlanoOrig());
//			log.info("++++++++++++++++++++++\n " + xmlPDU);			
		}catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
	
	@Test
	public void createMsgCompletoMx() {
		log.info("********** inincioo createMsgCompletoMxooooooooooooooooooooo /////////////////");
		try {
			String mt = "pacs.008.001.09";
			String formato = "MX";
			SwfMsgParam swfMsgParam = CreateFieldSwfServ.recMsgParms(mt, formato);
			CreateFieldSwfServ srv = new CreateFieldSwfServ(swfMsgParam, null);
			Instruccion instr = srv.initInstruccion();
			srv.addFact("instr", instr.getSwfMsgParam());
			srv.addFact("dbtr", CreateFieldSwfServ.factDbtr());
			MappingTable mpptabResult = new MappingTable();
			
			CreateFieldSwfServ.mapPropsSaa1().entrySet().forEach(e -> {
				MappingRule mapRuleN = new MappingRule();
				CampoForm campoForm = new CampoForm();
				campoForm.setCatalogo(e.getKey());
				campoForm.setValor((String) e.getValue());
				mapRuleN.addCampo(campoForm);
				mpptabResult.getMappingRuleList().add(mapRuleN);
			});
			
			instr.setMapTableResult(mpptabResult);
			
			//srv.recuperarCampos("");
			srv.registerFuncsDef();
			srv.initEngine();
			//srv.translate();
//			instr.getMapTableResult().getMappingRuleList().forEach(m -> {
//				log.info("" + m.getSwfCampo().getMtfExpresion());
//			});
			srv.translatePost();
			//srv.generaHeaderMsg();			
			String xml = srv.createMsgSwift();
			log.info("................... " + xml);
			SwiftMessageAbstract sma = instr.getMessageHolder();
			log.info("====================\n " + sma.getMenPlanoOrig());			
			DataPDUWriter w = new DataPDUWriter((AbstractMX) sma.getAbsMsg());
//			String xmlPDU = w.xml(sma.getMenPlanoOrig());
//			log.info(xmlPDU.length() + " xmlPDUxmlPDUxmlPDUxmlPDUxmlPDUxmlPDUxmlPDU " + xmlPDU);
		}catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}	
}
