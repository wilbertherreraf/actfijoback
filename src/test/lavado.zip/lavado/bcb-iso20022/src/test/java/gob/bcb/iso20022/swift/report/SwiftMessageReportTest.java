package gob.bcb.iso20022.swift.report;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.pojo.ArchivoSinple;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.utils.UtilsFile;

public class SwiftMessageReportTest {
	private static final Logger log = LoggerFactory.getLogger(SwiftMessageReportTest.class);
	
	//@Test
	public void reportMtMessage() {
		try {
			String nfile = "src/test/resources/mts/M07.txt"; // siodex_103.txt
			
			String str = UtilsFile.readFileAsString2(nfile);
			
			SwiftMessageAbstract sm = FactoryParser.createParser(str).createBlock4Long();
			log.info("tipo " + str);
			sm.getBlock4().forEach(b -> {
				//log.info("tipo " + b.getName() + " -> " + b.getValue() + " => " + b.getReference());
			});
			
			
			SwiftMessageReport swiftMessageReport = new SwiftMessageReport();
			ArchivoSinple archivoSinple = swiftMessageReport.initReport(str, mp -> {
				mp.setMenCodapp("CODAPP");
				mp.setMenIdoperacion(mp.getMenCodapp()+"_" + System.currentTimeMillis());
			}).createReportFile(null);
			
			archivoSinple.setDirectory("e:/tmp");
			
			String p = UtilsFile.grabaEnArchivo(archivoSinple.getStream(), archivoSinple.getPathFile());
			log.info("info " + p);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	@Test
	public void reportMxMessage() {
		try {
			String nfile = "src/test/resources/mxs/saa.xml"; // siodex_103.txt
			
			String str = UtilsFile.readFileAsString2(nfile);
			
			SwiftMessageAbstract sm = FactoryParser.createParser(str);
			log.info("tipo " + sm.messageType());
			sm.createBlock4().getBlock4().forEach(b -> {
				log.info("tipo " + b.getName() + " -> " + b.getValue());
			});
			
			
			SwiftMessageReport swiftMessageReport = new SwiftMessageReport();
			ArchivoSinple archivoSinple = swiftMessageReport.initReport(str, mp -> {
				mp.setMenCodapp("COD APP");
			}).createReportFile("prumX.pdf");
			
			archivoSinple.setDirectory("e:/tmp");
			
			String p = UtilsFile.grabaEnArchivo(archivoSinple.getStream(), archivoSinple.getPathFile());
			log.info("info " + p);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	
}
