package gob.bcb.iso20022.swift.parser;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.sax.SAXSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.XPath;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.google.gson.internal.LinkedTreeMap;
import com.prowidesoftware.swift.model.MxId;
import com.prowidesoftware.swift.model.MxNode;
import com.prowidesoftware.swift.model.MxSwiftMessage;
import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.prowidesoftware.swift.model.mx.AppHdr;
import com.prowidesoftware.swift.model.mx.AppHdrParser;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;
import com.prowidesoftware.swift.model.mx.MxParseUtils;
import com.prowidesoftware.swift.model.mx.MxReadParams;
import com.prowidesoftware.swift.model.mx.NamespaceAndElementFilter;
import com.prowidesoftware.swift.model.mx.XmlEventWriter;
import com.prowidesoftware.swift.model.mx.dic.BusinessApplicationHeaderV01Impl;
import com.prowidesoftware.swift.model.mx.sys.MxXsys01200101;
import com.prowidesoftware.swift.utils.SafeXmlUtils;

import gob.bcb.iso20022.core.xml.JaxBConversionService;
import gob.bcb.iso20022.core.xml.SaaNamespaceContext;
import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.lau.AuthParameters;
import gob.bcb.iso20022.lau.LAU;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.swift.saa.model.ObjectFactory;
import gob.bcb.iso20022.swift.saa.model.SwAny;
import gob.bcb.iso20022.utils.UtilsFile;

/**
 * 
 * @author wherrera
 *
 */
public class SwiftMessageAbstractTest {
	private static final Logger log = LoggerFactory.getLogger(SwiftMessageAbstractTest.class);

	// @Test
	public void updDataPDUTest() {
		try {
			String typeMess = "pacs.008.001.08";
			String nfile = "src/test/resources/mxs/saa.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			JAXBContext context = JAXBContext.newInstance(ObjectFactory.class, AbstractMX.class, com.prowidesoftware.swift.model.mx.MxPacs00800108.class,
					com.prowidesoftware.swift.model.mx.BusinessAppHdrV02.class);
			log.info(menplano);
			SAXSource documentSource = createFilteredSAXSource(menplano, AbstractMX.DOCUMENT_LOCALNAME);
			SwiftMessageAbstract sm = FactoryParser.createParser(typeMess, menplano);
			log.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
			log.info(sm.getIdentifier());
			String x = sm.createMsg().fromMsg();
			log.info(sm.getMenPlano());
			log.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
			log.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
			log.info(x);
			Unmarshaller u = context.createUnmarshaller();

			// Object o = parseSAXSource(documentSource, DataPDU.class, null, new
			// MxReadParams());
			DataPDU dataPDU2 = (DataPDU) u.unmarshal(new StringReader(menplano));
			// DataPDU dataPDU = (DataPDU) o;
			SwAny swAny = new SwAny();

//			AbstractMX obj = (AbstractMX) sm.getAbsMsg();
//			AppHdr appHdr = obj.getAppHdr();
//			swAny.getContent().add(appHdr);
//			swAny.getContent().add(obj);

			dataPDU2.setBody(swAny);
			// dataPDU = (DataPDU) u.unmarshal(new StringReader(menplano));
//			log.info("ooooooo " + (o == null));			
			log.info("o.getRevision " + dataPDU2.getHeader());
			log.info("o.getRevision " + dataPDU2.getHeader().getMessage().getSenderReference());
			log.info("o.getRevision " + dataPDU2.getBody().getContent().size());
			dataPDU2.getBody().getContent().forEach(v -> {
				log.info("o.getRevision " + v.getClass().getSimpleName() + " " + v);
			});
			String dataXml = pruXMLEle(dataPDU2);
			log.info("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD\n" + dataXml);
			log.info("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD");
			JaxBConversionService jbs = JaxBConversionService.getInstance().initialize(new Class[] { ObjectFactory.class, AbstractMX.class,
					com.prowidesoftware.swift.model.mx.MxPacs00800108.class, com.prowidesoftware.swift.model.mx.BusinessAppHdrV02.class });

			org.w3c.dom.Document docSaa = jbs.toDocument(dataPDU2);

			org.w3c.dom.Element er = docSaa.getDocumentElement();
			er.setPrefix("Saa");
			SaaNamespaceContext ns = new SaaNamespaceContext();
			Map<String, String> mapSaa = new HashMap<>();
			mapSaa.put("Saa", "urn:swift:saa:xsd:saa.2.0");
			mapSaa.put("Sw", "urn:swift:snl:ns.Sw");
			mapSaa.put("SwInt", "urn:swift:snl:ns.SwInt");
			mapSaa.put("SwGbl", "urn:swift:snl:ns.SwGbl");
			mapSaa.put("SwSec", "urn:swift:snl:ns.SwSec");

			String namespaceSpecNS = "http://www.w3.org/2000/xmlns/";
			// er.setAttributeNS(namespaceSpecNS, "xmlns" , "urn:swift:saa:xsd:saa.2.0");
			for (Entry<String, String> entry : mapSaa.entrySet()) {
				// er.setAttributeNS(namespaceSpecNS, "xmlns:" + entry.getKey(),
				// entry.getValue());

			}

			String xmlSaa = jbs.getStringFromDom(docSaa, false, true);
			log.info("SAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
			log.info(xmlSaa);
			log.info("SAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASSSSSSSSSSSSSSSSSSSSSSSSS");
			Marshaller marshaller = context.createMarshaller();

			AbstractMX obj = (AbstractMX) sm.getAbsMsg();
			AppHdr appHdr = obj.getAppHdr();
			swAny.getContent().add(appHdr);
			swAny.getContent().add(obj);

			dataPDU2.setBody(swAny);

			final JAXBElement<? extends MxSwiftMessage> element = new JAXBElement(new QName("DataPDU"), dataPDU2.getClass(), null, dataPDU2);

			final StringWriter sw = new StringWriter();
			XmlEventWriter writer = new XmlEventWriter(sw, "Saa", true, "DataPDU", null, null);

			// Saa="urn:swift:saa:xsd:saa.2.0" xmlns:Sw="urn:swift:snl:ns.Sw"
			// xmlns:SwInt="urn:swift:snl:ns.SwInt" xmlns:SwGbl="urn:swift:snl:ns.SwGbl"
			// xmlns:SwSec="urn:swift:snl:ns.SwSec"

			// writer.setPreferredPrefixes(preferredPrefixes);
			writer.setNamespaceContext(ns);
			marshaller.marshal(element, writer);
			String xmlSaaMx = sw.getBuffer().toString();
			log.info("XXXXXXXXXXXXXXXXXXXXXXXXX");
			log.info(xmlSaaMx);

			// sm = FactoryParser.createParser(menplano);

//			log.info("***************************");
////			sm.updInstrId("./PmtId/InstrId", "88888/253656/VVV");
////			sm.updInstrId("./GrpHdr/MsgId", "88888/253656/VVV");
//			sm.updInstrId("", "88888/253656/VVV");
//			//sm.updInstrId2("./BizSvc", "LAUUUUUUUUUUUU");
//			sm.addBlockLAU("LAUUUUUUUUU");
//			log.info(sm.getMenPlano());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	public String pruXMLEle(DataPDU dataPDU) {
		try {
			JAXBContext context = JAXBContext.newInstance(DataPDU.class);

			final Marshaller marshaller = context.createMarshaller();

			final StringWriter sw = new StringWriter();
			JAXBElement<BusinessApplicationHeaderV01Impl> element = new JAXBElement(new QName("urn:swift:saa:xsd:saa.2.0", "DataPDU"), DataPDU.class, null,
					dataPDU);
			XmlEventWriter eventWriter = new XmlEventWriter(sw, "h", false, "DataPDU", null, null);
			marshaller.marshal(element, eventWriter);
			return sw.getBuffer().toString();

		} catch (JAXBException e) {
			log.error("Error writing head.001.001.01 XML:" + e.getMessage());
		}
		return null;
	}

	// @Test
	public void updDocumentMxTest() {
		try {
			String nfile = "src/test/resources/mxs/pacs008cli.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);

			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			log.info("***************************");
//			sm.updInstrId("./PmtId/InstrId", "88888/253656/VVV");
//			sm.updInstrId("./GrpHdr/MsgId", "88888/253656/VVV");
//			sm.updInstrId("", "88888/253656/VVV");
			// sm.updInstrId2("./BizSvc", "LAUUUUUUUUUUUU");
			AuthParameters authParameters = new AuthParameters("secret", "");
			sm.addBlockLAU(authParameters);
			log.info(sm.getMenPlano());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

//	@Test
	public void updFillDataTest() {
		try {
			String nfile = "src/test/resources/mxs/mxpacs02hdr.mx"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			log.info(menplano);
			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			log.info("***************************");
			sm.extractMetadata();
			log.info("S " + sm.getSwfMsgParam().getMenTypemessage());
			log.info("S " + sm.getSwfMsgParam().getMenEmisor() + " " + sm.getSwfMsgParam().getMenReceiver() + " idTrx: "
					+ sm.getSwfMsgParam().getMenIdTMessageTx());
			log.info("S idOper: " + sm.getSwfMsgParam().getMenIdoperacion() + " mon: " + sm.getSwfMsgParam().getMenCodmon() + " codSwf: "
					+ sm.getSwfMsgParam().getMenCodswift());
			log.info("S idOper: " + sm.getSwfMsgParam().getMenHash());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

//	@Test
	public void updFillDataMtTest() {
		String id = "iiiiiii";
		MDC.put("MDC_KEY", id);
		try {
			String nfile = "src/test/resources/mts/M01.txt";
			String menplano = UtilsFile.readFileAsString2(nfile);
			log.info(menplano);
			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			log.info("**********{}*****************", id);
			sm.extractMetadata();
			log.info("S " + sm.getSwfMsgParam().getMenTypemessage());
			log.info("S " + sm.getSwfMsgParam().getMenEmisor() + " " + sm.getSwfMsgParam().getMenReceiver() + " idTrx: "
					+ sm.getSwfMsgParam().getMenIdTMessageTx());
			log.info("S iiiiiii idOper: " + sm.getSwfMsgParam().getMenIdoperacion() + " mon: " + sm.getSwfMsgParam().getMenCodmon() + " codSwf: "
					+ sm.getSwfMsgParam().getMenCodswift());
			log.info("S idOper: " + sm.getSwfMsgParam().getMenHash());
			MDC.clear();
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void updDocumentMtTest() {
		try {
			String nfile = "src/test/resources/mts/M01.txt"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);

			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
//			sm.updInstrId("20", "XXXXXXXXXX");
			log.info("***************************");
			log.info(sm.getMenPlano());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void updDocumentLauMtTest() {
		try {
			String nfile = "src/test/resources/mts/M01.txt"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			AuthParameters authParameters = new AuthParameters("secret", "");
			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			sm.addBlockLAU(authParameters);
			log.info("***************************");
			log.info(sm.getMenPlano());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void updDocumentLauMxTest() {
		try {
			String nfile = "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			AuthParameters authParameters = new AuthParameters("secret", "");
			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);

			sm.addBlockLAU(authParameters);
			log.info("***************************");
			log.info(sm.getMenPlano());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

//	@Test
	public void updPruDocumentTest() {
		try {
			String typeMess = "pacs.008.001.08";
			String nfile = "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);

			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			AbstractMX mx = (AbstractMX) sm.getAbsMsg();
			AppHdr headerMx = mx.getAppHdr();
			String xml = mx.document();
			log.info(xml);
			log.info("***************************");
			log.info(mx.message());

			LinkedTreeMap<String, String> outMap = XmlToMap.xmlToProps(xml);
			outMap.forEach((k, v) -> {
				log.info(k + " -> " + v);
			});

			Document doc = DocumentHelper.parseText(xml);
			Element root = doc.getRootElement();

			log.info("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
			MxNode document = MxNode.parse(xml);
			MxNode groupHeader = document != null ? document.findFirstByName("PmtId") : null;
			MxNode reference = groupHeader.findFirst("./InstrId");

			log.info(reference.path() + " *->" + reference.getValue());

			// XPath xpath =
			// DocumentHelper.createXPath("/Doc:Document/Doc:FIToFICstmrCdtTrf/Doc:CdtTrfTxInf/Doc:PmtId/Doc:InstrId");
			XPath xpath = DocumentHelper.createXPath("./PmtId/InstrId");

			Optional<Node> nf = XmlToMap.findFirstByName(doc, "PmtId");
			if (nf.isPresent()) {
				Optional<Node> found = XmlToMap.findFirst(nf.get(), "InstrId");
				log.info("NFF000000 " + nf.isPresent() + " ch " + found.isPresent());
				if (found.isPresent()) {
					log.info("NFF " + found.get().getName() + " " + found.get().getText());
					found.get().setText("ZZZZZZZZZZZZZ");
				}
			}

			AbstractMX mxNew = AbstractMX.parse(doc.asXML());
			mxNew.setAppHdr(headerMx);

			List<Node> nodes = xpath.selectNodes(root);

			log.info("nodes " + nodes.size() + " -> " + xpath.getText());
			nodes.forEach(n -> {
				Element e = (Element) n;
				log.info("	" + n.getName() + " : " + n.getText() + " QN: " + e.getQualifiedName());
			});
			if (nodes.size() > 0)
				nodes.get(0).setText("N123456");

			String nxml = root.getDocument().asXML();
			log.info("***************************");
			log.info(nxml);
			log.info("***************************");
			log.info(mxNew.message());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	//@Test
	public void smaUpdLAUTest() {
		try {
			String nfile = "src/test/resources/sign/pacsaa.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			AuthParameters authParameters = new AuthParameters("Abcd1234abcd1234","Abcd1234abcd1234");
			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			
			log.info("***********Orig****************");
			log.info(sm.getMenPlano());
			
			DataPDU pdu = sm.updMsgForSign().getdPDUWriter().getDataPDU();
			pdu.getHeader().getMessage().getInterfaceInfo().setServiceURI("mp/mx/__mRWkJI2EeuXfsXXXXXX");
			pdu.getHeader().getMessage().getInterfaceInfo().setMessageTypeURI("mp/mx/__mRWkJI2EeuXfsPBlWnVxg/__mSksJI2EeuXfsPBlWnVxg");
			pdu.getHeader().getMessage().getNetworkInfo().setService("swift.finplus");
			pdu.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo().setRequestSubtype("swift.cbprplus.02");

			sm.addBlockLAU(authParameters);
			log.info("+++++++++ with LAU++++++++++");
			log.info(sm.getMenPlano());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	@Test
	public void smaUpdLAUMsgSignedMXTest() {
		try {
			log.info("====== Msg Signed test ==================");
			String nfile = "src/test/resources/sign/pacsigned.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			AuthParameters authParameters = new AuthParameters("Abcd1234abcd1234","Abcd1234abcd1234");
			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			
			log.info("***********Payload****************");
			log.info(sm.getPayLoad());
			log.info("............... without LAU...............");
			log.info(sm.getMenPlano());
			
			sm.updMsgForSign().addBlockLAU(authParameters);
			log.info("-------------Payload----------");
			log.info(sm.getPayLoad());			
			log.info("+++++++++ with LAU++++++++++");
			log.info(sm.getMenPlano());

			LAU lau = new LAU();
			lau.signXmlV2(menplano);
			log.info("sign SignatureValue: " + lau.getSignatureValue());
			org.w3c.dom.Node node = (org.w3c.dom.Element) sm.getdPDUWriter().getDataPDU().getLAU().getContent().get(0);
			
			String s = asXml((org.w3c.dom.Element) node);
			log.info("sssssssssssssss " + s);			
			String sign = JaxBConversionService.valueOfTag(node,"SignatureValue");
			
			log.info("node SignatureValue: " + sign);
			for (int i = 0; i < node.getChildNodes().getLength() ; i++) {
				org.w3c.dom.Node n = node.getChildNodes().item(i);
				log.info("node " + n.getTextContent());
			}
			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
	
	//@Test
	public void smaUpdLAUMsgSignedMTTest() {
		try {
			log.info("====== Msg Signed test ==================");
			String nfile = "src/test/resources/sign/m103signed.dos"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
 
			AuthParameters authParameters = new AuthParameters("CeAfF8FbF5C1f3BB","1c9db3CE7BA9BE4C");
			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			
			log.info("***********Payload****************");
			log.info(sm.getPayLoad());
			sm.updMsgForSign();
			log.info("............... ORIGINAL WITHOUT LAU...............");
			log.info(sm.getMenPlano());
			
			sm.addBlockLAU(authParameters);
			log.info("-------------Payload----------");
			log.info(sm.getPayLoad());			
			log.info("+++++++++ with LAU++++++++++");
			log.info(sm.getMenPlano());

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}	
	public static Optional<XMLStreamReader> findElement(final String xml, final String localName) {
		Objects.requireNonNull(xml, "XML to parse must not be null");
		Validate.notBlank(xml, "XML to parse must not be a blank string");
		Objects.requireNonNull(xml, "localName to find must not be null");

		final XMLInputFactory xif = SafeXmlUtils.inputFactory();
		try {
			final XMLStreamReader reader = xif.createXMLStreamReader(new StringReader(xml));
			while (reader.hasNext()) {
				// log.info("Reader " + reader.getEventType());
				int event = reader.next();
				if (XMLStreamConstants.START_ELEMENT == event) {
					if (reader.getNamespaceCount() > 0) {
						for (int nsIndex = 0; nsIndex < reader.getNamespaceCount(); nsIndex++) {
							final String nsPrefix = StringUtils.trimToNull(reader.getNamespacePrefix(nsIndex));
							final String elementPrefix = StringUtils.trimToNull(reader.getPrefix());

//							log.info("nsPrefix " + nsPrefix + " elementPrefix:" + elementPrefix + " " + reader.getNamespaceURI());
							if (StringUtils.equals(nsPrefix, elementPrefix)) {
								// if prefix match or is not set in both the element and the namespace we return
								// it as found namespace

							}
						}
					}

					if (reader.getLocalName().equals(localName)) {
						// log.info("Found!! " + localName);
						return Optional.of(reader);
					}
				} else if (XMLStreamConstants.CHARACTERS == event) {
//					log.info("Reader ele " + reader.getText());
				} else if (XMLStreamConstants.NAMESPACE == event) {
//					log.info("	Reader nasssssssssssssss ");
				}
			}
		} catch (XMLStreamException e) {
			log.info("Error reading XML", e);
		}
		return Optional.empty();
	}

	public static SAXSource createFilteredSAXSource(final String xml, final String localName) {
		XMLReader documentReader = SafeXmlUtils.reader(true, null);

		NamespaceAndElementFilter documentFilter = new NamespaceAndElementFilter(localName);
		documentFilter.setParent(documentReader);

		InputSource documentInputSource = new InputSource(new StringReader(xml));

		return new SAXSource(documentFilter, documentInputSource);
	}

	public static Object parseSAXSource(final SAXSource source, final Class targetClass, final Class<?>[] classes, final MxReadParams params) {
		Objects.requireNonNull(targetClass, "target class to parse must not be null");
		Objects.requireNonNull(source, "SAXSource to parse must not be null");
		// Objects.requireNonNull(classes, "object model classes array must not be
		// null");
		// Objects.requireNonNull(params, "unmarshalling params cannot be null");

		try {
			JAXBContext context;
			if (params.context != null) {
				context = params.context;
			} else {
				context = JaxbContextLoader.INSTANCE.get(targetClass, classes);
			}
			log.info("context " + context);
			final Unmarshaller unmarshaller = context.createUnmarshaller();

			if (params.adapters != null) {
				for (XmlAdapter adapter : params.adapters.asList()) {
					unmarshaller.setAdapter(adapter);
				}
			}

			JAXBElement element = unmarshaller.unmarshal(source, targetClass);
			if (element != null) {
				return element.getValue();
			}

		} catch (JAXBException | ExecutionException e) {
			throw new RuntimeException(e);
		}
		return null;
	}

	 private static String asXml(org.w3c.dom.Element e) {
	        DOMImplementationLS lsImpl = (DOMImplementationLS) e.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
	        LSSerializer serializer = lsImpl.createLSSerializer();
	        serializer.getDomConfig().setParameter("xml-declaration", false);
	        return serializer.writeToString(e);
	    }
	 
	public static final String document = ""
			+ "<Doc:Document xmlns:Doc=\"urn:swift:xsd:xsys.012.001.01\" xmlns:Sw=\"urn:swift:snl:ns.Sw\" xmlns:SwInt=\"urn:swift:snl:ns.SwInt\" xmlns:SwGbl=\"urn:swift:snl:ns.SwGbl\">"
			+ "	<Doc:xsys.012.001.01>" + "		<Doc:DlvryNtfctn>" + "			<Sw:SnFRef>swi00001-2010-05-04T15:32:59.21582.11198379Z</Sw:SnFRef>"
			+ "			<Sw:SnFRefType>InterAct</Sw:SnFRefType>" + "			<Sw:AcceptStatus>Failed</Sw:AcceptStatus>"
			+ "			<Sw:AckSwiftTime>2010-05-04T15:33:12Z</Sw:AckSwiftTime>"
			+ "			<Sw:AckDescription>Message delivery attempts exceeded system threshold</Sw:AckDescription>"
			+ "			<Sw:AckInfo>SwRejectcode=SwGbl.MaxRetryExceeded</Sw:AckInfo>" + "			<SwInt:RequestHeader>"
			+ "				<SwInt:Requestor>cn=requestor,o=simxbebb,o=swift</SwInt:Requestor>"
			+ "				<SwInt:Responder>cn=responder,o=simxus33,o=swift</SwInt:Responder>" + "				<SwInt:Service>mnop.cop</SwInt:Service>"
			+ "				<SwInt:RequestType>pain.001.002.04</SwInt:RequestType>" + "				<SwInt:Priority>Normal</SwInt:Priority>"
			+ "				<SwInt:RequestRef>Ref-84884</SwInt:RequestRef>" + "			</SwInt:RequestHeader>" + "		</Doc:DlvryNtfctn>"
			+ "	</Doc:xsys.012.001.01>" + "</Doc:Document>";

	public static final String sample_with_wrapper = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
			+ "<SwInt:HandleRequest xmlns:Sw=\"urn:swift:snl:ns.Sw\" xmlns:SwGbl=\"urn:swift:snl:ns.SwGbl\" xmlns:SwSec=\"urn:swift:snl:ns.SwSec\" xmlns:SwInt=\"urn:swift:snl:ns.SwInt\">"
			+ "	<SwInt:RequestHandle>" + "		<SwInt:RequestDescriptor>"
			+ "			<SwInt:SwiftRequestRef>SNL00110-2010-05-04T15:32:59.3912.000004Z</SwInt:SwiftRequestRef>"
			+ "			<SwInt:SwiftRef>swi00001-2010-05-04T15:32:59.21582.11198379Z</SwInt:SwiftRef>" + "			<SwInt:NonRep>"
			+ "				<SwInt:NRType>SVCOPT</SwInt:NRType>" + "			</SwInt:NonRep>" + "			<Sw:SnFOutputInfo>"
			+ "				<Sw:SnFSessionId>simxbebb_generic:p:000047</Sw:SnFSessionId>" + "				<Sw:SnFOutputSeq>2337176</Sw:SnFOutputSeq>"
			+ "				<Sw:DeliveryTime>2010-05-04T15:33:14Z</Sw:DeliveryTime>"
			+ "				<Sw:SnFInputTime>0105:2010-05-04T15:33:12</Sw:SnFInputTime>" + "			</Sw:SnFOutputInfo>" + "			<SwInt:MRRResult>"
			+ "				<SwInt:SNLId>snl00110</SwInt:SNLId>" + "				<SwInt:SNLEP>spark_ap2</SwInt:SNLEP>" + "			</SwInt:MRRResult>"
			+ "		</SwInt:RequestDescriptor>" + "		<SwInt:RequestHeader>" + "			<SwInt:Requestor>cn=system,o=swift,o=swift</SwInt:Requestor>"
			+ "			<SwInt:Responder>cn=requestor,o=simxbebb,o=swift</SwInt:Responder>" + "			<SwInt:Service>swift.snf.system</SwInt:Service>"
			+ "			<SwInt:RequestType>xsys.012.001.01</SwInt:RequestType>" + "			<SwInt:Priority>Normal</SwInt:Priority>"
			+ "		</SwInt:RequestHeader>" + "		<SwInt:RequestPayload>" + "			<Ah:AppHdr xmlns:Ah=\"urn:swift:xsd:$ahV10\">"
			+ "				<Ah:MsgRef>2010-05-04T15:33:12Z</Ah:MsgRef>" + "				<Ah:CrDate>2010-05-04T15:33:12Z</Ah:CrDate>"
			+ "			</Ah:AppHdr>" + document + "		</SwInt:RequestPayload>" + "	</SwInt:RequestHandle>" + "</SwInt:HandleRequest>";

//	 @Test
	public void testParseDocumentOnly() {
		try {
			MxXsys01200101 mx = MxXsys01200101.parse(sample_with_wrapper);
			AbstractMX mxNew = AbstractMX.parse(sample_with_wrapper);

//		JAXBContext context = JAXBContext.newInstance(com.prowidesoftware.swift.model.mx.sys.dic.SwIntHandleRequest.class,
//					com.prowidesoftware.swift.model.mx.BusinessAppHdrV02.class);
			Optional<MxId> id = MxParseUtils.identifyMessage(sample_with_wrapper);
			log.info("rr " + id);
//			Unmarshaller u = context.createUnmarshaller();
//			SwIntHandleRequest r = (SwIntHandleRequest) u.unmarshal(new StringReader(sample_with_wrapper));
//			log.info("rr " + r.getRequestHandle());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

}
