package gob.bcb.iso20022.translate;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.ws.commons.schema.XmlSchema;
import org.apache.ws.commons.schema.XmlSchemaAny;
import org.apache.ws.commons.schema.XmlSchemaAttribute;
import org.apache.ws.commons.schema.XmlSchemaAttributeOrGroupRef;
import org.apache.ws.commons.schema.XmlSchemaChoice;
import org.apache.ws.commons.schema.XmlSchemaChoiceMember;
import org.apache.ws.commons.schema.XmlSchemaCollection;
import org.apache.ws.commons.schema.XmlSchemaComplexType;
import org.apache.ws.commons.schema.XmlSchemaContent;
import org.apache.ws.commons.schema.XmlSchemaContentModel;
import org.apache.ws.commons.schema.XmlSchemaElement;
import org.apache.ws.commons.schema.XmlSchemaParticle;
import org.apache.ws.commons.schema.XmlSchemaSequence;
import org.apache.ws.commons.schema.XmlSchemaSequenceMember;
import org.apache.ws.commons.schema.XmlSchemaSimpleContent;
import org.apache.ws.commons.schema.XmlSchemaSimpleContentExtension;
import org.apache.ws.commons.schema.XmlSchemaSimpleType;
import org.apache.ws.commons.schema.XmlSchemaSimpleTypeRestriction;
import org.apache.ws.commons.schema.XmlSchemaType;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.mx.AbstractMX;

import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.pojo.Node;
import gob.bcb.iso20022.pojo.Tree;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.utils.UtilsFile;

public class ValidationEngineTest {
	private static final Logger log = LoggerFactory.getLogger(ValidationEngineTest.class);

//	@Test
	public void validateMx() {
		try {
			log.info("inicio test=========================");

			ValidationEngine engine = ValidationEngine.getInstance().registerValidators();
//			engine.registerValidator(pacs009xsd, "pacs.009.001.09");
//			engine.registerValidator(pacs008xsd, "pacs.008.001.09");

			String nfile = "src/test/resources/mxs/103valido.txt"; // siodex_103.txt
			String str = UtilsFile.readFileAsString2(nfile);

			engine = ValidationEngine.getInstance();
			List errors = engine.validateMsg(str);
			log.info("TIENE ERRORES DE VALIDACION? " + (errors.size() > 0));

			errors.forEach(s -> {
				log.info("\n 	Detalle Error: " + s);
			});


		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	@Test
	public void validateOrdMx() {
		try {
			
			log.info("inicio test=========================");
			ValidationEngine engine = ValidationEngine.getInstance().registerValidators();
			engine = ValidationEngine.getInstance();			
			String nfile = "src/test/resources/mxs/103valido.txt"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			log.info(menplano);
			log.info("***************************");
			List errors = engine.validateMsg(menplano);
			log.info("TIENE ERRORES DE VALIDACION NO ORDER? " + (errors.size() > 0));

			errors.forEach(s -> {
				log.info("\n 	Detalle Error: " + s);
			});

			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);

			sm.getBlock4().forEach(b -> {
				log.info("tipo " + b.getName() + " -> " + b.getValue());
			});
			
			AbstractMX mx = (AbstractMX) sm.getAbsMsg();
			String nxml = mx.document();
			log.info(nxml);
			errors = engine.validateMsg(nxml);
			log.info("TIENE ERRORES DE VALIDACION ORDER? " + (errors.size() > 0));

			errors.forEach(s -> {
				log.info("\n 	Detalle Error: " + s);
			});

			
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	
//	@Test
	public void validateMxTest() {
		try {
			log.info("inicio test=========================");

			ValidationEngine engine = ValidationEngine.getInstance().registerValidators();
//			engine.registerValidator(pacs009xsd, "pacs.009.001.09");
//			engine.registerValidator(pacs008xsd, "pacs.008.001.09");

			String nfile = "src/test/resources/mxs/mxpacs02.mx"; // siodex_103.txt
			String str = UtilsFile.readFileAsString2(nfile);

			engine = ValidationEngine.getInstance();
			List errors = engine.validateMsg(str);
			log.info("TIENE ERRORES DE VALIDACION? " + (errors.size() > 0));

			errors.forEach(s -> {
				log.info("\n 	Detalle Error: " + s);
			});
			log.info("111111111111*******************");
			engine = ValidationEngine.getInstance();

			nfile = "src/test/resources/mxs/mxpacs02.mx"; // siodex_103.txt
			str = UtilsFile.readFileAsString2(nfile);

			errors = engine.validateMsg(str);
			log.info("TIENE ERRORES DE VALIDACION? " + (errors.size() > 0));
			errors.forEach(s -> {
				log.info("\n 	Detalle Error: " + s);
			});
			log.info("2222222222222*******************");
			nfile = "src/test/resources/mxs/mxpacs03err.mx"; // siodex_103.txt
			str = UtilsFile.readFileAsString2(nfile);
			engine = ValidationEngine.getInstance();
			errors = engine.validateMsg(str);
			log.info("TIENE ERRORES DE VALIDACION? " + (errors.size() > 0) + " " + nfile);

			errors.forEach(s -> {
				log.info("\n 	Detalle Error: " + s);
			});

		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	
	private static XmlSchemaCollection xmlSchemaCollection;
	private static Map<QName, List<XmlSchemaElement>> xsdElements = new HashMap<QName, List<XmlSchemaElement>>();
	private static List<XmlSchemaElement> schemaElements = new ArrayList<XmlSchemaElement>();

//	@Test
	public void parsingXsd() {
		try {
			log.info("inicio test=========================");
			String nfile = "src/main/resources/xsd/head.001.001.03.xsd"; // siodex_103.txt
			File h = new File(nfile);
			XmlSchemaCollection xmlSchemaCollection = new XmlSchemaCollection();
			InputStream xsdAsStream = new FileInputStream(h.getAbsolutePath());
			XmlSchema schema = xmlSchemaCollection.read(new StreamSource(xsdAsStream));
			// Get the root element from XSD
			Map.Entry<QName, XmlSchemaElement> entry = schema.getElements().entrySet().iterator().next();

			// Get all the elements based on the parent element
			XmlSchemaElement childElement = xmlSchemaCollection.getElementByQName(entry.getKey());
			LinkedList<SwfMencampos> r = new LinkedList<SwfMencampos>();
			// Call method to get all the child elements
			Node<SwfMencampos> padre = Node.createNodeDefault("P009", "8");
			SwfMencampos curr = (SwfMencampos) padre.getSwfMencampos();
			curr.setMtfGrpopt(0);
			curr.setMtfNemo("00");
			curr.setMtfTipocampo("ROOT");
			curr.setMtfNivel(0);
			curr.setMtfCodcampo(childElement.getName());
			curr.setMtfXmltag("/" + childElement.getName());
			curr.setMtfFormato(childElement.getName());
			curr.setMtfMinimo("1");
			curr.setMtfCardinal("1");
			curr.setMtfNivel(0);

			getChildElementNames(childElement, "/", 0, 0, r, null, padre);

			r.forEach(sc -> {
				log.info(sc.toStringID() + "\t\t" + sc.getMtfNemo() + "\t\t\t\t :=> " + " " + sc.getMtfMinimo() + ":" + sc.getMtfCardinal() + " "
						+ sc.getMtfTipocampo() + " " + sc.getMtfXmltag() + " :: " + sc.getMtfFormato());
			});
			log.info("EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE");
			padre.print(1);
			
			// Get the elements type based on choice
//			log.info("EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE");
//			xsdElements.forEach((k,v) -> {
//				log.info(k.getPrefix() + " => " + k.getNamespaceURI() + " => " + k.getLocalPart());
//				v.forEach(x -> {
//					log.info("	x: " + x.getName() + " nil: " + x.isNillable());
//				});
//			});
//			List<XmlSchemaElement> childElements = xsdElements.get(new QName("food"));
//			System.out.println(childElements.get(0));
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	// Method to check for the child elements and return list
	private static void getChildElementNames(XmlSchemaElement element, String pathIn, Integer level, Integer nro, LinkedList<SwfMencampos> lc,
			Node<SwfMencampos> padre, Node<SwfMencampos> nodoCurrent) {
		// Get the type of the element
		
		XmlSchemaType elementType = element != null ? element.getSchemaType() : null;
		final String path = pathIn + "/" + element.getName();
		if (level > 5)
			return;
		
		if (!nodoCurrent.hasCurrent()) {
			log.info("PAROOT: " + nodoCurrent.parentID() + " CURR: " + nodoCurrent.nodoID() + " : " + nodoCurrent.currentID() + " :: " + level + ":" + nro
					+ "] elemeny " + path + " : (" + elementType.getName() + ") ");

			SwfMencampos swr = nodoCurrent.getSwfMencampos();
			swr.setMtfNemo("00");
			nodoCurrent.setSwfMencamposCrr(swr);
			getChildElementNames(element, pathIn, level, nro, lc, null, nodoCurrent);
			log.info("saliendo................");
			return;
		}

		if (padre != null) {
			Tree.addChild(padre, nodoCurrent);
			log.info(padre.nodoID() + ":" + padre.getChildArray().size() + " -----> " + nodoCurrent.nodoID() + " " + nodoCurrent.getChildArray().size() );			
		}
		String pa = nodoCurrent.hasCurrent() ? ((SwfMencampos) nodoCurrent.getSwfMencamposCrr()).getMtfNemo() : "SINP";
		String corr = StringUtils.leftPad(nro.toString(), 2, "0");
		String p = nodoCurrent.hasCurrent() && nodoCurrent.hasParent() ? ((SwfMencampos) nodoCurrent.getSwfMencamposCrr()).getMtfNemo() + "." + corr : corr;
		
		if (padre != null)
			p = padre.hasCurrent() ? ((SwfMencampos) padre.getSwfMencampos()).getMtfNemo() + "." + corr : corr;

		log.info("PA: " + (padre != null ? padre.nodoID() : " SIN PADRE") + " CURR: " + nodoCurrent.nodoID() + " : " + level + ":" + nro + "] CU: "
				+ pa + " # PA " + p + " elemeny " + path + " : (" + elementType.getName() + ") ");

		SwfMencampos swf = null ; 
		if (padre != null && padre.getSwfMencampos() != null)
			swf = createSwfcampo(element, path, level, nro, padre.getSwfMencampos());
		else {
			SwfMencampos pAux = new SwfMencampos();
			pAux.setMtfCodmt(nodoCurrent.getSwfMencampos().getMtfCodmt());
			//pAux.setMtfNemo("");
			swf = createSwfcampo(element, path, level, nro, new SwfMencampos());
		}
			
		lc.add(swf);

		if (elementType instanceof XmlSchemaComplexType) {
			XmlSchemaParticle allParticles = ((XmlSchemaComplexType) elementType).getParticle();
			if (allParticles == null) {
				XmlSchemaContentModel st = ((XmlSchemaComplexType) elementType).getContentModel();
				XmlSchemaSimpleContent sc = (XmlSchemaSimpleContent) st;
				XmlSchemaContent cont = sc.getContent();
				XmlSchemaSimpleContentExtension se = (XmlSchemaSimpleContentExtension) cont;

				for(XmlSchemaAttributeOrGroupRef a : se.getAttributes()){
					log.info("atrib " + a.toString());
					swf.setMtfTipocampo("AMT");
					swf.setMtfXmltag(path + " Ccy=''");
				};
				Node<SwfMencampos> curr = new Node<SwfMencampos>(swf);
				curr.setSwfMencamposCrr(swf);
				Tree.addChild(padre, curr);				
			} else {
				if (allParticles instanceof XmlSchemaAny) {

				} else if (allParticles instanceof XmlSchemaElement) {
					log.info("	**Element Schema Element " + element.getName());
				} else if (allParticles instanceof XmlSchemaChoice) {
					//log.info("	**Element Schema Choice " + element.getName());
					XmlSchemaChoice ch = (XmlSchemaChoice) allParticles;
					swf.setMtfTipocampo("CH");
					Integer nroc = 1;
					
					Node<SwfMencampos> padreN = null;
					if (ch.getItems().size() > 0) {
						padreN = new Node<SwfMencampos>(swf);
						padreN.setSwfMencamposCrr(swf);						
					}
					Integer levelCh = level+1;
					for (XmlSchemaChoiceMember c : ch.getItems()) {
						XmlSchemaElement ec = (XmlSchemaElement) c;
						// Node<SwfMencampos> curr = new Node<SwfMencampos>(swf);
						// log.info(" CHOICE: " + element.getName() + "."+ ec.getName());
						SwfMencampos swfCh = createSwfcampo(ec, pathIn, level, nro, nodoCurrent.getSwfMencampos());
						Node<SwfMencampos> currCh = new Node<SwfMencampos>(swfCh);
						currCh.setSwfMencamposCrr(swfCh);
						getChildElementNames(ec, path, levelCh, nro, lc, padreN, currCh);
						nroc++;
					}
					;
				} else if (allParticles instanceof XmlSchemaSequence) {
					swf.setMtfTipocampo("SQ");
					final XmlSchemaSequence xmlSchemaSequence = (XmlSchemaSequence) allParticles;
					// final List<XmlSchemaSequenceMember> items = xmlSchemaSequence.getItems();
					Integer nroc = 1;
					
					Node<SwfMencampos> padreN = null;
					if (xmlSchemaSequence.getItems().size() > 0) {
						padreN = new Node<SwfMencampos>(swf);
						padreN.setSwfMencamposCrr(swf);
						
						Tree.addChild(nodoCurrent, padreN);
						//}
					} 
					String padres0 = padreN.hasParent() && padreN.getParent().getSwfMencampos() != null ? ((SwfMencampos) padreN.getParent().getSwfMencampos()).toStringID() : " SIN PADRE";
					log.info(corr + " " + padres0 + " : " + ((SwfMencampos) padreN.getSwfMencampos()).toStringID() + " : " + padreN.getChildArray().size() + " _> " + ((SwfMencampos) padreN.getSwfMencampos()).getMtfXmltag());							

					for (XmlSchemaSequenceMember item : xmlSchemaSequence.getItems()) {
						if (item instanceof XmlSchemaElement) {
							XmlSchemaElement itemElements = (XmlSchemaElement) item;
							
							SwfMencampos swfCh = createSwfcampo(itemElements, path, level + 1, nroc, padreN.getSwfMencampos());
							Node<SwfMencampos> currCh = new Node<SwfMencampos>(swfCh);
							currCh.setSwfMencamposCrr(swfCh);
							
							addChild(element.getQName(), itemElements, swfCh);
							if (!padreN.nodoID().equals(currCh.nodoID()))
							getChildElementNames(itemElements, path, level + 1, nroc, lc, padreN, currCh);
							String padres = padreN.hasParent() && padreN.getParent().getSwfMencampos() != null ? ((SwfMencampos) padreN.getParent().getSwfMencampos()).toStringID() : " SIN PADRE";
							log.info(corr + " " + padres + " : " + ((SwfMencampos) padreN.getSwfMencampos()).toStringID() + " : " + padreN.getChildArray().size() + " _> " + ((SwfMencampos) padreN.getSwfMencampos()).getMtfXmltag());							
						}
						nroc++;
					}
				}
			}
			
		} else if (elementType instanceof XmlSchemaSimpleType) {
			XmlSchemaSimpleType st = (XmlSchemaSimpleType) elementType;
			XmlSchemaSimpleTypeRestriction sr = (XmlSchemaSimpleTypeRestriction) st.getContent();
			if (sr.getFacets().size() > 0) {
				String tablaPropJoin = sr.getFacets().stream().map(m -> m.getValue().toString()).collect(Collectors.joining(", "));
				swf.setMtfTipocampo(tablaPropJoin);
			}
			
			Node<SwfMencampos> curr = new Node<SwfMencampos>(swf);
			curr.setSwfMencamposCrr(swf);
			Tree.addChild(padre, curr);
		}
		
	}

	// Add child elements based on its parent
	private static void addChild(QName qName, XmlSchemaElement child, SwfMencampos swf) {

		List<XmlSchemaElement> values = xsdElements.get(qName);
		if (values == null) {
			values = new ArrayList<XmlSchemaElement>();
		}
		//log.info("en clid " + qName.getLocalPart() + " " + child.getName() + " " + xsdElements.size() + " -> " + values.size());
		values.add(child);
		xsdElements.put(qName, values);
	}
	
	public static SwfMencampos createSwfcampo(XmlSchemaElement element, String pathIn, Integer level, Integer nro, SwfMencampos padre) {
		XmlSchemaType elementType = element != null ? element.getSchemaType() : null;

		final String path = pathIn + "/" + element.getName();
		String corr = StringUtils.leftPad(nro.toString(), 2, "0");
		String nemoP = !StringUtils.isBlank(padre.getMtfNemo()) ? padre.getMtfNemo() + "." : "";
		SwfMencampos swf = new SwfMencampos();
		swf.setMtfGrpopt(0);
		swf.setMtfNro(nro);
		swf.setMtfCodcampo(element.getName());
		swf.setMtfCodmt(padre.getMtfCodmt());
		swf.setMtfXmltag(path);
		swf.setMtfFormato(elementType.getName());
		swf.setMtfMinimo(String.valueOf(element.getMinOccurs()));
		swf.setMtfCardinal(String.valueOf(element.getMinOccurs()));
		swf.setMtfNivel(level);
		swf.setMtfNemo(nemoP + corr);
		swf.setMtfTipocampo("TEXT");
		return swf;
	}
}
