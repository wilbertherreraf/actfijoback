package gob.bcb.iso20022.rules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jeasy.rules.api.Facts;
import org.junit.jupiter.api.Test;

import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field50A;
import com.prowidesoftware.swift.model.field.Field50F;
import com.prowidesoftware.swift.model.field.Field50K;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.swift.CampoFormUtils;

public class EngineMTTest {
	private final Logger log = LoggerFactory.getLogger(getClass());

	//@Test
	public void testExecuteAllActionsFiring() {
		List<Rule> rules = rulesFactory();

		List<CampoForm> camposFormListFld = new ArrayList<>();
		
		Map<String, Object> facts = new HashMap<String, Object>();
		facts.putAll(genDatosinputFields());
		facts.putAll(genDatosinputObject());
		
		BiConsumer<Rule, CampoForm> afterActionExec = (r, cf) -> {
			cf.setTabla(r.getNamespace());
			cf.setColumn(r.getName());
			cf.setCampoValue(r.getDescription());
			
			camposFormListFld.add(cf);
		};

		AbstractAction<DatosInput, CampoForm> a1 = new AbstractAction<DatosInput, CampoForm>("procActFieldMT", afterActionExec) {

			@Override
			protected CampoForm initializeOutputResult(CompiledRule rule, DatosInput input) {
				// TODO Auto-generated method stub
				return null;
			}


		};

		AbstractAction<DatosInput, CampoForm> a3 = new AbstractAction<DatosInput, CampoForm>("procesarFieldMT", afterActionExec) {

			@Override
			protected CampoForm initializeOutputResult(CompiledRule rule, DatosInput input) {
				// TODO Auto-generated method stub
				return null;
			}
		};
		
		DatosInput input = new DatosInput();
		input.setIdinstr("000");
		input.getMapa().putAll(genDatosinputFields());
		
		try {
			Engine engine = new Engine(rules, true, facts);
			engine.addAction(a1).addAction(a3);
			//engine.executeAllActions(input);
			
			camposFormListFld.forEach(cf -> {
				log.info("cf::> " + cf.getTabla() + "." + cf.getColumn() + " = <" + cf.getCampoValue() + "> [" + cf.getValor() + "]");
			});
		}catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
		
	}

	//@Test
	public void testExecuteAllActionsFacts() {
		
		List<Rule> rules = rulesFactory();

		List<CampoForm> camposFormListFld = new ArrayList<>();
		
		Map<String, Object> facts = new HashMap<String, Object>();
		facts.putAll(genDatosinputFields());
		facts.putAll(genDatosinputObject());
		
		BiConsumer<CampoForm, Object> afterActionRuleC = (cf, o) -> {
			System.out.println("Env after object " + cf.getValor() + " " + String.valueOf(o));
			if (cf.getValor() == null)
				cf.setValor(String.valueOf(o));
		};

		BiConsumer<Rule, CampoForm> afterActionExec = (r, cf) -> {
			System.out.println("Env after IAction " + r.getAction() + " " + r.getName() + " ");
			cf.setTabla(r.getNamespace());
			cf.setColumn(r.getName());
			cf.setCampoValue(r.getDescription());
			
			camposFormListFld.add(cf);
		};

		AbstractAction<DatosInput, CampoForm> a1 = new AbstractAction<DatosInput, CampoForm>("procActFieldMT", afterActionExec) {

			@Override
			protected CampoForm initializeOutputResult(CompiledRule rule, DatosInput input) {
				// TODO Auto-generated method stub
				return null;
			}

		};

		AbstractAction<Facts, CampoForm> a3 = new AbstractAction<Facts, CampoForm>("procesarFieldMT", afterActionExec) {

			@Override
			protected CampoForm initializeOutputResult(CompiledRule rule, Facts input) {
				// TODO Auto-generated method stub
				return null;
			}

		};
		
		DatosInput input = new DatosInput();
		input.setIdinstr("000");
		input.getMapa().putAll(genDatosinputFields());
		
		try {
			Engine engine = new Engine(rules, true, facts);
			engine.addAction(a1).addAction(a3);
			System.out.println("aaaaaaaaaaaaaaaaaaa");			
			//engine.executeAllActions(input);

			camposFormListFld.forEach(cf -> {
				log.info("cf::> " + cf.getTabla() + "." + cf.getColumn() + " = <" + cf.getCampoValue() + "> [" + cf.getValor() + "]");
			});
		}catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
		
	}

	@Test
	public void executeFieldsMTTest() {
		try {
			Instruccion inst = genIntruccion();
			
			List<Rule> rules = rulesFactoryMT();
			List<CampoForm> camposFormListFld = new ArrayList<>();
			
			BiConsumer<CampoForm, Object> afterActionRuleC = (cf, o) -> {
				System.out.println("Env after object " + cf.getValor() + " " + String.valueOf(o));
				if (cf.getValor() == null)
					cf.setValor(String.valueOf(o));
			};

			BiConsumer<Rule, CampoForm> afterActionExec = (r, cf) -> {
				System.out.println("Env after IAction " + r.getAction() + " " + r.getName() + " ");
//				cf.setTabla(r.getNamespace());
//				cf.setColumn(r.getName());
//				cf.setCampoValue(r.getDescription());
				
				camposFormListFld.add(cf);
			};

			AbstractAction<Instruccion, CampoForm> a3 = new AbstractAction<Instruccion, CampoForm>("procesarFieldMT", afterActionExec) {
				@Override
				protected CampoForm initializeOutputResult(CompiledRule rule, Instruccion input) {
					// TODO Auto-generated method stub
					return null;
				}

			};
			
		}catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	
	public List<Rule> rulesFactory() {
		Rule r1 = new Rule("amount", "true", "procesarFieldMT", 1, "f32A", "/root/documento/body/montotrx", "");
		Rule r2 = new Rule("currency", "true", "procActFieldMT", 1, "f32A", "/root/documento/body/currtrx", "");
		Rule r3 = new Rule("account", "true", "procActFieldMT", 1, "f50A", "/root/documento/body/deb/acct", "f50A.account;");		
		Rule r5 = new Rule("bic", "true", "procActFieldMT", 1, "f50A", "/root/documento/body/deb/bic", "f50A.identifierCode;");
		Rule r6 = new Rule("debnombre", "true", "procesarFieldMT", 1, "persona", "/root/documento/body/acreedor/nombre", "output.valor = persona.name;");
		Rule r7 = new Rule("tipodeb", "true", "procActFieldMT", 1, "ktte", "/root/documento/body/acreedor/tipopersona", "'BCCO';");
		Rule r8 = new Rule("tipodeb2", "input.idinstr = '000'", "procActFieldMT", 1, "ktte", "/root/documento/body/acreedor/tipopersona", "'BCCO';");		
		Rule r9 = new Rule("tipodeb2", "input.idinstr = '000'", "procActFieldLN", 1, "ktte", "/Document/CstmrCdtTrfInitn/PmtInf[{n}]/CdtTrfTxInf/RmtInf/Ustrd", "'BCCO';");
		
		Map<String, String> act1 = new HashMap<>();
		act1.put("monto", "32A.amount");
		act1.put("currency", "32A.currency");
		r1.addActions(act1);
		
		Map<String, String> act2 = new HashMap<>();
		act2.put("50F", "output.valor=50F.component4");
		act2.put("50K", "output.valor=50K.nameAndAddress");
		
		r6.addActions(act2);
		
		List<Rule> rules = Arrays.asList(r1, r2, r3, r5, r6 , r7, r8);
		return rules;
	}
	public List<Rule> rulesFactoryMT() {
		Rule r1 = new Rule("amount", "input.getMapFacts().containsKey('F32A')", "procesarFieldMT", 1, "F32A", "/root/documento/body/montotrx", "output.valorObj = input.fact('F32A');");
		r1.addAction("1", "output.valDecimal=F32A.amountAsBigDecimal;");
		r1.addAction("2", "output.column='amountAsBigDecimal';");

		Rule r2 = new Rule("amount", "input.getMapFacts().containsKey('F50K')", "procesarFieldMT", 1, "F50K", "/root/documento/body/montotrx", "output.valorObj = input.fact('F50K');");
		r2.addAction("1", "output.valor=F50K.account;");
		r2.addAction("2", "output.column='account';");

		Rule r3 = new Rule("amount", "input.getMapFacts().containsKey('F50F')", "procesarFieldMT", 1, "F50F", "/root/documento/body/montotrx", "output.valorObj = input.fact('F50F');");
		r3.addAction("1", "output.valor=F50F.component1;");
		r3.addAction("2", "output.column='account';");

		Rule r5 = new Rule("name", "input.getMapFacts().containsKey('F50K')", "procesarFieldMT", 1, "F50K", "/root/documento/body/montotrx", "output.valorObj = input.fact('F50K');");
		r5.addAction("1", "output.valor=F50K.nameAndAddress");
		r5.addAction("2", "output.column='name';");

		Rule r6 = new Rule("name", "input.getMapFacts().containsKey('F50F')", "procesarFieldMT", 1, "F50F", "/root/documento/body/montotrx", "output.valorObj = input.fact('F50F');");
		r6.addAction("1", "output.valor=F50F.component3");
		r6.addAction("2", "output.column='name';");
		
		List<Rule> rules = Arrays.asList(r1,r2,r3,r5,r6);
		return rules;
	}

	public Map<String, Object> genDatosinputFields() {
		Map<String, Object> facts = new HashMap<String, Object>();
		Field32A f32A = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89").setDate(Calendar.getInstance());

		facts.put("f32A.amount", f32A.getAmount());
		facts.put("f32A.currency", f32A.getCurrency());
		
		Field50A f50A = new Field50A().setAccount("12345678901234567890").setIdentifierCode("FOOBANKXXXXX");
		facts.put("f50A", f50A);
		
		Field50F f50F = new Field50F()//
		.setComponent1("ctaNro")//
		.setComponent2("1")//
		.setComponent3("name debtor")//		
		.setComponent4("2")//
		.setComponent5("location")//		
		.setComponent6("3")//
		.setComponent7("plaza");
		
		facts.put("F50F", f50F);
	
		Field50K f50K = new Field50K().setAccount("asdf1234").setNameAndAddress("dir y nomvre");
		facts.put("F50K", f50K);
		
		return facts;
	}

	public Instruccion genIntruccion() {
		Instruccion inst = new Instruccion();
		
		Field32A f32A = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89").setDate(Calendar.getInstance());
		Field50K f50K = new Field50K().setAccount("asdf1234").setNameAndAddress("dir y nomvre");
		Field50F f50F = new Field50F()//
				.setComponent1("ctaNro")//
				.setComponent2("1")//
				.setComponent3("name")//		
				.setComponent4("2")//
				.setComponent5("location")//		
				.setComponent6("3")//
				.setComponent7("plaza");
		
		return inst;
	}
	
	public Map<String, Object> genDatosinputObject() {
		Map<String, Object> facts = new HashMap<String, Object>();
		Person p = new Person("JUAN", 45, "calle 1");
		facts.put("persona", p);
		
		return facts;
	}

	public static final class DatosInput {
		private String idinstr;
		private final Map<String, Object> mapa = new HashMap<String, Object>();
		private final List<CampoForm> propsLista = new ArrayList<>();
		
		public String getIdinstr() {
			return idinstr;
		}
		public void setIdinstr(String idinstr) {
			this.idinstr = idinstr;
		}
		public Map<String, Object> getMapa() {
			return mapa;
		}
		public List<CampoForm> getPropsLista() {
			return propsLista;
		}
		public void put(String key, Object value) {
			mapa.put(key, value);
		}		
	}

	public static final class Person {
		private String name;
		private Integer age;
		private String other;

		public Person() {

		}

		public Person(String name, int age, String other) {
			this.name = name;
			this.age = age;
			this.other = other;

		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Integer getAge() {
			return age;
		}

		public void setAge(Integer age) {
			this.age = age;
		}

		public String getOther() {
			return other;
		}

		public void setOther(String other) {
			this.other = other;
		}
	}

}
