package gob.bcb.iso20022.swift.parser;

import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.utils.UtilsFile;

public class SwiftMessageBcbTest {
	private static final Logger log = LoggerFactory.getLogger(SwiftMessageBcb.class);
	@Test
	public void readMessage() {
		try {
			String nfile = "src/test/resources/mts/M02.txt"; // siodex_103.txt
			String str = UtilsFile.readFileAsString2(nfile);
			
			SwiftMessageAbstract sm = FactoryParser.createParser(str);
			log.info("tipo " + sm.messageType());
			sm.getBlock4().forEach(b -> {
				log.info("tipo " + b.getName() + " -> " + b.getValue());
			});
			
			nfile = "src/test/resources/mxs/mxpacs01.mx"; // siodex_103.txt
			str = UtilsFile.readFileAsString2(nfile);

			sm = FactoryParser.createParser(str);
			
			log.info("tipo " + sm.messageType());
			sm.getBlock4().forEach(b -> {
				log.info("tipo " + b.getName() + " -> " + b.getValue());
			});
			
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	
	
}
