package gob.bcb.iso20022.swift.saa;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlSchema;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.transform.sax.SAXSource;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.prowidesoftware.swift.model.mx.AppHdr;
import com.prowidesoftware.swift.model.mx.BusinessAppHdrV02;
import com.prowidesoftware.swift.model.mx.DefaultEscapeHandler;
import com.prowidesoftware.swift.model.mx.EscapeHandler;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;
import com.prowidesoftware.swift.model.mx.MxPacs00800108;
import com.prowidesoftware.swift.model.mx.MxReadParams;
import com.prowidesoftware.swift.model.mx.MxWriteConfiguration;
import com.prowidesoftware.swift.model.mx.MxWriteImpl;
import com.prowidesoftware.swift.model.mx.MxWriteParams;
import com.prowidesoftware.swift.model.mx.NamespaceAndElementFilter;
import com.prowidesoftware.swift.model.mx.adapters.TypeAdaptersConfiguration;
import com.prowidesoftware.swift.utils.SafeXmlUtils;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

import gob.bcb.iso20022.core.xml.JaxBConversionService;
import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.lau.AuthParameters;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.swift.saa.model.ObjectFactory;
import gob.bcb.iso20022.swift.saa.model.SwAny;
import gob.bcb.iso20022.utils.UtilsFile;

public class SaaServiceTest {
	private static final Logger log = LoggerFactory.getLogger(SaaServiceTest.class);

	static StringBuilder hdr = new StringBuilder();
	static {
		hdr.append("<h:AppHdr xmlns:h=\"urn:iso:std:iso:20022:tech:xsd:head.001.001.02\">");
		hdr.append("    <h:Fr>                                                           ");
		hdr.append("        <h:FIId>                                                     ");
		hdr.append("            <h:FinInstnId>                                           ");
		hdr.append("                <h:BICFI>BCEBBOLPXXX</h:BICFI>                       ");
		hdr.append("            </h:FinInstnId>                                          ");
		hdr.append("        </h:FIId>                                                    ");
		hdr.append("    </h:Fr>                                                          ");
		hdr.append("    <h:To>                                                           ");
		hdr.append("        <h:FIId>                                                     ");
		hdr.append("            <h:FinInstnId>                                           ");
		hdr.append("                <h:BICFI>ESPBESMMRMS</h:BICFI>                       ");
		hdr.append("            </h:FinInstnId>                                          ");
		hdr.append("        </h:FIId>                                                    ");
		hdr.append("    </h:To>                                                          ");
		hdr.append("    <h:BizMsgIdr>PRUEBAWIL7</h:BizMsgIdr>                            ");
		hdr.append("    <h:MsgDefIdr>pacs.008.001.08</h:MsgDefIdr>                       ");
		hdr.append("    <h:BizSvc>swift.cbprplus.02</h:BizSvc>                           ");
		hdr.append("    <h:CreDt>2023-04-25T03:34:14-04:00</h:CreDt>                     ");
		hdr.append("</h:AppHdr>                                                          ");
	}

	// @Test
	public void mapToSaaXMLj() {
		try {
			LinkedHashMap<String, Object> mapSaa = mapPropsSaa();
			String xml = XmlToMap.xmlSaaFromXPath(mapSaa, "");
			log.info(xml);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void mapToXMLToSaaObj() {
		try {
			JaxBConversionService jbs = JaxBConversionService.getInstance().initialize();
			JAXBContext context = JAXBContext.newInstance(ObjectFactory.class);
			Unmarshaller u = context.createUnmarshaller();

			LinkedHashMap<String, Object> mapSaa = mapPropsSaa();
			String xml = XmlToMap.xmlSaaFromXPath(mapSaa, "");
			log.info(xml);
			MxReadParams params = new MxReadParams();
			params.context = context;

			DataPDU dataPDU = (DataPDU) u.unmarshal(new StringReader(xml));
			// SAXSource documentSource = createFilteredSAXSource(xml, "");
			// DataPDU dataPDU = (DataPDU) parseSAXSource(documentSource, DataPDU.class,
			// null, params);
			log.info("NULO? " + (dataPDU == null));
			printDataPdu(dataPDU);

			DataPDU dataPDU2 = jbs.readDocument(xml, DataPDU.class);
			log.info("NULO? " + (dataPDU2 == null));
			printDataPdu(dataPDU2);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void xMLToSaaObj() {
		try {
			JaxBConversionService jbs = JaxBConversionService.getInstance().initialize();
			String nfile = "src/test/resources/mxs/saa.xml"; // siodex_103.txt
			String xml = UtilsFile.readFileAsString2(nfile);
			log.info(xml);

			DataPDU dataPDU2 = jbs.readDocument(xml, DataPDU.class);
			log.info("NULO? " + (dataPDU2 == null));
			printDataPdu(dataPDU2);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void insPacsToSaaObj() {
		try {
			JaxBConversionService jbs = JaxBConversionService.getInstance().initialize();

			String nfilep = "src/test/resources/mxs/mxpacs01.mx"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfilep);

			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			AuthParameters authParameters = new AuthParameters("secret",""); 
			sm.addBlockLAU(authParameters);
			log.info("***********PACS****************");
			String xmlPacs = sm.getMenPlano();
			log.info(xmlPacs);
			log.info("***********FINC PACS****************");

			String nfile = "src/test/resources/mxs/saa.xml"; // siodex_103.txt
			String xml = UtilsFile.readFileAsString2(nfile);
			log.info("***********SAA****************");
			log.info(xml);

			DataPDU dataPDU2 = jbs.readDocument(xml, DataPDU.class);
			printDataPdu(dataPDU2);

			SwAny swAny = new SwAny();
			swAny.getContent().add(xmlPacs);

			dataPDU2.setBody(swAny);
			String xmlSaa = jbs.writeXml(dataPDU2);
			log.info(xmlSaa);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

//	@Test
	public void updDataPDUTest() {
		try {
			log.info("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII");
			String typeMess = "pacs.008.001.08";
			String nfile = "src/test/resources/mxs/saa.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			JAXBContext context = JAXBContext.newInstance(ObjectFactory.class, AbstractMX.class, com.prowidesoftware.swift.model.mx.MxPacs00800108.class,
					com.prowidesoftware.swift.model.mx.BusinessAppHdrV02.class);
			log.info(menplano);
			Unmarshaller u = context.createUnmarshaller();
			DataPDU dataPDU2 = (DataPDU) u.unmarshal(new StringReader(menplano));
			String dataXml = pruXMLEle(dataPDU2);
			log.info("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD\n" + dataXml);
			log.info("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD");

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	@Test
	public void changeSwAnyTest() {
		try {
			log.info("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII");
			String nfile = "src/test/resources/mxs/saa01.txt"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			JAXBContext context = JAXBContext.newInstance(DataPDU.class, MxPacs00800108.class, BusinessAppHdrV02.class);
			//log.info(menplano);
			Unmarshaller u = context.createUnmarshaller();
			DataPDU dataPDU2 = (DataPDU) u.unmarshal(new StringReader(menplano));
			// dataPDU2.getBody().getContent().clear();
			//dataPDU2.setBody(null);
			dataPDU2.getBody().getContent().clear();
			String dataXml = pruXMLEle(dataPDU2);
			log.info("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD" + dataXml);
			log.info("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD");
			AbstractMX mx = (AbstractMX) instDocumentTest();
			log.info(mx.message() +  "\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			AbstractMX document = (AbstractMX) FactoryParser.createParser(mx.document()).getAbsMsg();
			MxWriteParams params = new MxWriteParams(); 
			params.prefix = "h";
			String pwXml = message(mx, context);
			String saaXmlresult = embeddedSaa(dataXml, pwXml);
			
			BusinessAppHdrV02 headerMx = (BusinessAppHdrV02) mx.getAppHdr();
			log.info("HHH>::> \n" + saaXmlresult);
			log.info("**************************************************");
			
//			JAXBElement<BusinessAppHdrV02> element = new JAXBElement(new QName("urn:iso:std:iso:20022:tech:xsd:head.001.001.02", "AppHdr", "h"),
//					BusinessAppHdrV02.class, null, headerMx);
//
//			JAXBElement<AbstractMX> elementB = new JAXBElement(new QName("urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08", "Document", "Doc"), AbstractMX.class, null, document);
//			// XmlEventWriter eventWriter = new XmlEventWriter(sw, params.prefix,
//			// params.includeXMLDeclaration, AppHdr.HEADER_LOCALNAME, params.escapeHandler,
//			// params.indent);
//			SwAny swAny = new SwAny().addContent(element).addContent(elementB);
//			dataPDU2.setBody(swAny);
//
//			JaxBConversionService jbs = JaxBConversionService.getInstance().initialize(DataPDU.class, AbstractMX.class,
//					com.prowidesoftware.swift.model.mx.MxPacs00800108.class, com.prowidesoftware.swift.model.mx.BusinessAppHdrV02.class);
//
//			org.w3c.dom.Document docSaa = jbs.toDocument(headerMx);
//
//			HashSet<Class> set = new HashSet<Class>();
//			set.add(DataPDU.class);
//			for (Object entry : dataPDU2.getBody().getContent()) {
//				log.info("en entry::> " + entry.getClass().getSimpleName());
//				if (entry != null) {
//					set.add(entry.getClass());
//				}
//				if (dataPDU2.getBody().getContent() != null && dataPDU2.getBody().getJAXBObject() != null) {
//					//set.add(dataPDU2.getBody().getJAXBObject().getClass());
//				}				
//			}

//			JAXBContext context2 = JAXBContext.newInstance(set.toArray(new Class[set.size()]));
//
//			Marshaller marshaller = context2.createMarshaller();
//			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
//			marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.FALSE);
//			
//			NamespacePrefixMapper mapper = new NamespacePrefixMapper() {
//				public String getPreferredPrefix(String namespace, String suggestion, boolean requirePrefix) {
//					log.info("en OOOOOOOOOOOOOOOO::> " + namespace + " suggestion: " + suggestion + " " + requirePrefix);
//	                if ("urn:iso:std:iso:20022:tech:xsd:head.001.001.02".equals(namespace)) {
//	                    return "h";
//	                } else if ("urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08".equals(namespace)) {
//	                    return "Doc";
//	                } else if ("urn:swift:saa:xsd:saa.2.0".equals(namespace)) {
//	                    return "Saa";
//	                }
//	                return suggestion;
//				}
//			};
//
//			marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", mapper);
//			final StringWriter sw = new StringWriter();
//			marshaller.marshal(dataPDU2, sw);
//
//			//String xmlSaa = jbs.getStringFromDom(docSaa, false, true);
//			String xmlSaa = sw.toString();
////			String xmlSaa = pruXMLEle(dataPDU2);
//			log.info("XXXXXXXXXXXXXXXXX\n" + xmlSaa);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	public String pruXMLEle(DataPDU dataPDU) {
		try {
			JAXBContext context = JAXBContext.newInstance(DataPDU.class);

			final Marshaller marshaller = context.createMarshaller();
			XmlSchema xmlSchema = DataPDU.class.getPackage().getAnnotation(XmlSchema.class);
			//log.info("NS " + xmlSchema.namespace() + " " + xmlSchema.xmlns().length + " " + xmlSchema.xmlns()[0].prefix());
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.FALSE);
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");

			final StringWriter sw = new StringWriter();
			// JAXBElement<DataPDU> element = new JAXBElement(new QName("", "Saa:DataPDU",
			// "Saa"), DataPDU.class, null, dataPDU);

			marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper() {
				@Override
				public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
					log.info("en EEEEEEEEEEEEEEEE::> " + namespaceUri + " suggestion: " + suggestion + " " + requirePrefix);
					if (xmlSchema.namespace().equals(namespaceUri)) {
						return "Saa";
					}
					return suggestion;
				}
			});

			marshaller.marshal(dataPDU, sw);
			return sw.toString();

		} catch (Exception e) {
			log.error("Error writing :" + e.getMessage(), e);
		}
		return null;
	}

//	@Test
	public AbstractMX instDocumentTest() {
		try {
			log.info("ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ");
			String nfile = "src/test/resources/mxs/saa01.txt"; // "src/test/resources/mxs/pacs.conhdr.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);

			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			AbstractMX mx = (AbstractMX) sm.getAbsMsg();
			AppHdr headerMx = mx.getAppHdr();
			String xml = mx.document();
			xml = mx.message();
			//log.info(headerMx.xml());
			//log.info("***************************");
			// log.info(xml);
			// log.info(mx.message());
			log.info("--------------------");
			return mx;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;
	}

	
    public static String message(AbstractMX mx, JAXBContext context) {
        MxWriteConfiguration usableConf = new MxWriteConfiguration();
        usableConf.includeXMLDeclaration = false;
        MxWriteParams params = createConfig("", false, new DefaultEscapeHandler(), new TypeAdaptersConfiguration(), context, null);

        // handle manually at this method level
        params.includeXMLDeclaration = false;

        //String root = usableConf.rootElement;
        StringBuilder xml = new StringBuilder();
        if (usableConf.includeXMLDeclaration) {
            xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
        }

        params.prefix = usableConf.headerPrefix;
        final String header = header(mx.getAppHdr(),params);
        if (header != null) {
          //  xml.append("<").append(root).append(">\n");
            xml.append(header).append("\n");
        }

        params.prefix = usableConf.documentPrefix;
        xml.append(document(mx, params));
        if (header != null) {
            //xml.append("</").append(root).append(">");
        }
        return xml.toString();
    }
    
    public static String header(AppHdr appHdr, MxWriteParams params) {
    	String xml = appHdr.xml(params);
    	return xml;
    }
    
    public static String document(AbstractMX mx, MxWriteParams params) {
        return MxWriteImpl.write(mx.getNamespace(), mx, mx.getClasses(), params);
    }    

    public static String embeddedSaa(String saaXml, String trxXml) {
    	final String tagToReplace = "<Saa:Body/>";
    	final String tagBody = "Saa:Body";
    	StringBuilder xmlBody = new StringBuilder();
    	
    	xmlBody.append("<").append(tagBody).append(">\n");
    	xmlBody.append(trxXml).append("\n");
    	xmlBody.append("</").append(tagBody).append(">");
    	
    	return saaXml.replace(tagToReplace, xmlBody.toString()).trim();
    }

    
    public static MxWriteParams createConfig(String prefix, boolean includeXMLDeclaration, EscapeHandler escapeHandler, TypeAdaptersConfiguration adapters, JAXBContext context, String indent) {
    	MxWriteParams params = new MxWriteParams(); 
    	params.prefix = null;
    	params.includeXMLDeclaration = includeXMLDeclaration;
    	params.escapeHandler = escapeHandler;
    	params.adapters = adapters;
    	params.context = context;
    	params.indent = indent;
    	
    	return params;
    }
	public static LinkedHashMap<String, Object> mapPropsSaa() {
		LinkedHashMap<String, Object> mapSaa = new LinkedHashMap<String, Object>();
		mapSaa.put("/Saa:DataPDU/Saa:Revision", "2.0.13");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SenderReference", "BCEBBOLPAXXXPRUEBAWIL7");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:MessageIdentifier", "pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Format", "MX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:SubFormat", "Input");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:DN", "ou=bcebbol0xxx,ou=xxx,o=bcebbolp,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Sender/Saa:FullName/Saa:X1", "BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:DN", "ou=bcebbol0xxx,ou=xxx,o=bcebbolp,o=swift");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:Receiver/Saa:FullName/Saa:X1", "BCEBBOLPXXX");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:InterfaceInfo/Saa:UserReference", "PRUEBAWIL7");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:Priority", "Normal");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:Service", "swift.finplus");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestType", "pacs.008.001.08");
		mapSaa.put("/Saa:DataPDU/Saa:Header/Saa:Message/Saa:NetworkInfo/Saa:SWIFTNetNetworkInfo/Saa:RequestSubtype", "swift.cbprplus.02");

		return mapSaa;
	}

	public static SAXSource createFilteredSAXSource(final String xml, final String localName) {
		XMLReader documentReader = SafeXmlUtils.reader(true, null);

		NamespaceAndElementFilter documentFilter = new NamespaceAndElementFilter(localName);
		documentFilter.setParent(documentReader);

		InputSource documentInputSource = new InputSource(new StringReader(xml));
		// new SAXSource(new InputSource(new StringReader(xmlSnippet))),
		return new SAXSource(documentFilter, documentInputSource);
	}

	public static Object parseSAXSource(final SAXSource source, final Class targetClass, final Class<?>[] classes, final MxReadParams params) {
		Objects.requireNonNull(targetClass, "target class to parse must not be null");
		Objects.requireNonNull(source, "SAXSource to parse must not be null");
		// Objects.requireNonNull(classes, "object model classes array must not be
		// null");
		// Objects.requireNonNull(params, "unmarshalling params cannot be null");

		try {
			JAXBContext context;
			if (params.context != null) {
				context = params.context;
			} else {
				context = JaxbContextLoader.INSTANCE.get(targetClass, classes);
			}
			log.info("context " + context);
			final Unmarshaller unmarshaller = context.createUnmarshaller();

			if (params.adapters != null) {
				for (XmlAdapter adapter : params.adapters.asList()) {
					unmarshaller.setAdapter(adapter);
				}
			}

			JAXBElement element = unmarshaller.unmarshal(source, targetClass);
			if (element != null) {
				return element.getValue();
			}

		} catch (JAXBException | ExecutionException e) {
			throw new RuntimeException(e);
		}
		return null;
	}

	public static void printDataPdu(DataPDU dataPDU) {
		log.info("getRevision: " + dataPDU.getRevision());
		log.info("getSenderReference(): " + dataPDU.getHeader().getMessage().getSenderReference());
		log.info("getMessageIdentifier(): " + dataPDU.getHeader().getMessage().getMessageIdentifier());
		log.info("getFormat());: " + dataPDU.getHeader().getMessage().getFormat());
		log.info("getSubFormat());: " + dataPDU.getHeader().getMessage().getSubFormat());
		log.info("getDN());: " + dataPDU.getHeader().getMessage().getSender().getDN());
		log.info("getX1());: " + dataPDU.getHeader().getMessage().getSender().getFullName().getX1());
		log.info("getDN());: " + dataPDU.getHeader().getMessage().getReceiver().getDN());
		log.info("getX1());: " + dataPDU.getHeader().getMessage().getReceiver().getFullName().getX1());
		log.info("getUserReference());: " + dataPDU.getHeader().getMessage().getInterfaceInfo().getUserReference());
		log.info("getPriority(): " + dataPDU.getHeader().getMessage().getNetworkInfo().getPriority());
		log.info("getService(): " + dataPDU.getHeader().getMessage().getNetworkInfo().getService());
		log.info("getRequestType: " + dataPDU.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo().getRequestType());
		log.info("getRequestSubtype: " + dataPDU.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo().getRequestSubtype());
	}

}
