package gob.bcb.iso20022.utils;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang3.ArrayUtils;
import org.junit.jupiter.api.Test;

public class UtilsGenericTest {
	@Test
	public void extracNumberTest() {
		Arrays.asList("","max23text","Max233Teext","Maax233Teext","Max 233 Teext","Max233Text" , "Max233asdText" ).forEach(c -> {
			System.out.println(c + " " + UtilsGeneric.extractNumber(c, "max", "text"));
		});
	}
}
