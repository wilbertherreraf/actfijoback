
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para NRType.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="NRType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="SvcOpt"/&gt;
 *     &lt;enumeration value="SvcMand"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "NRType")
@XmlEnum
public enum NRType {

    @XmlEnumValue("SvcOpt")
    SVC_OPT("SvcOpt"),
    @XmlEnumValue("SvcMand")
    SVC_MAND("SvcMand");
    private final String value;

    NRType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static NRType fromValue(String v) {
        for (NRType c: NRType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
