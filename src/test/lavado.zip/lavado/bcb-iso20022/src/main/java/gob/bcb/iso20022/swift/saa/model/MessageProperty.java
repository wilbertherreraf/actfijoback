
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para MessageProperty complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="MessageProperty"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MessagePropertyName" type="{urn:swift:saa:xsd:saa.2.0}MessagePropertyName"/&gt;
 *         &lt;element name="MessagePropertyValue" type="{urn:swift:saa:xsd:saa.2.0}MessagePropertyValue"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageProperty", propOrder = {
    "messagePropertyName",
    "messagePropertyValue"
})
public class MessageProperty {

    @XmlElement(name = "MessagePropertyName", required = true)
    protected String messagePropertyName;
    @XmlElement(name = "MessagePropertyValue", required = true)
    protected String messagePropertyValue;

    /**
     * Obtiene el valor de la propiedad messagePropertyName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessagePropertyName() {
        return messagePropertyName;
    }

    /**
     * Define el valor de la propiedad messagePropertyName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessagePropertyName(String value) {
        this.messagePropertyName = value;
    }

    /**
     * Obtiene el valor de la propiedad messagePropertyValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessagePropertyValue() {
        return messagePropertyValue;
    }

    /**
     * Define el valor de la propiedad messagePropertyValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessagePropertyValue(String value) {
        this.messagePropertyValue = value;
    }

}
