package gob.bcb.iso20022.excel.core.data;

import gob.bcb.iso20022.excel.enums.FieldTypeEnum;

public class HeaderData {
    private String fieldName;
    private FieldTypeEnum fieldTypeEnum;
    private Integer colPosition;
    private Integer firstRowData = 1;
    
    public HeaderData(String fieldName, FieldTypeEnum fieldTypeEnum, Integer colPosition) {
        this.fieldName = fieldName;
        this.fieldTypeEnum = fieldTypeEnum;
        this.colPosition = colPosition;
    }

    public HeaderData(String fieldName, FieldTypeEnum fieldTypeEnum) {
    	this(fieldName, fieldTypeEnum, null);
    }
    
    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public FieldTypeEnum getFieldTypeEnum() {
        return fieldTypeEnum;
    }

    public void setFieldTypeEnum(FieldTypeEnum fieldTypeEnum) {
        this.fieldTypeEnum = fieldTypeEnum;
    }

	public Integer getColPosition() {
		return colPosition;
	}

	public void setColPosition(Integer colPosition) {
		this.colPosition = colPosition;
	}

	public Integer getFirstRowData() {
		return firstRowData;
	}

	public void setFirstRowData(Integer firstRowData) {
		this.firstRowData = firstRowData;
	}
	
}
