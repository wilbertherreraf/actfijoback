package gob.bcb.iso20022.exceptions;

public class CompileException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public CompileException(String msg){
		super(msg);
	}

}
