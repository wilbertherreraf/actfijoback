package gob.bcb.iso20022.transforms;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.prowidesoftware.swift.model.field.Field;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.rules.AbstractAction;
import gob.bcb.iso20022.rules.Action;
import gob.bcb.iso20022.rules.CompiledRule;
import gob.bcb.iso20022.swift.MappingRule;

/**
 * @author: wherrera
 * 
 */
public class FieldTransform extends AbstractAction<MappingRule, CampoForm> {
	public final static String name = TransformEnum.FLDMX.toString();
	// RECEIVE CAMPOFORM
	public FieldTransform() {
		super(name);
	}

	@Override
	protected CampoForm initializeOutputResult(CompiledRule rule, MappingRule input) {
		return new CampoForm();
	}

	@Override
	public CampoForm execute(CompiledRule rule, MappingRule input, Map<String, Object> facts) {
		input.getMapFacts().forEach((k,v) -> {
			if (!StringUtils.isBlank(k) && v != null)
				facts.putIfAbsent(k, v);
		});
		return null;
	}
	
	@Override
	public void postExecuteAction(CompiledRule rule, MappingRule input, CampoForm output, Map<String, Object> facts) {
		if (output.getValorObj() != null) {
			SwfMencampos swfCampo = input.getSwfCampo();
			
			if (output.getValorObj() instanceof CampoForm) {
				CampoForm outputRes = (CampoForm) output.getValorObj();
				outputRes.setCatalogo(rule.getRule().getPath());
				
				if (swfCampo != null) {
					outputRes.setTabla(swfCampo.getMtfCodmt());
					outputRes.setColumn(swfCampo.getMtfNemo());		
				}				
				input.updCFResult(outputRes);
			} else if (output.getValorObj() instanceof Field) {
				if (swfCampo != null) {
					output.setTabla(swfCampo.getMtfCodmt());
					output.setColumn(swfCampo.getMtfNemo());		
				}
				
				output.setTipoValor("FIELDMT");
				output.setCatalogo(rule.getRule().getPath());
				input.updCFResult(output);
			}
		}
	}

	@Override
	public void postExecuteSubAction(CompiledRule rule, Action sAction, MappingRule input, CampoForm output, Map<String, Object> facts) {
		
		if (output == null)
			return;
		
		output.setTabla(rule.getRule().getNamespace());
		output.setColumn(rule.getRule().getName());		
		output.setCatalogo(rule.getRule().getPath());
		
		if (!StringUtils.isBlank(output.getTabla()) && output.getValorObj() != null) {
			input.setCampoForm(output);
		}
		input.updCFResult(output);
//		if (input.getCampos().size() <= 0) {
//			input.getCampos().add(new CampoForm());
//		}
//		input.getCampos().set(0, output);
	}
}
