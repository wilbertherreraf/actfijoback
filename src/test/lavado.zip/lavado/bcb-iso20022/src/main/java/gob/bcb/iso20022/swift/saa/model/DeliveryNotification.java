
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para DeliveryNotification complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DeliveryNotification"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ReconciliationInfo" type="{urn:swift:saa:xsd:saa.2.0}SenderReference"/&gt;
 *         &lt;element name="ReceiverDeliveryStatus" type="{urn:swift:saa:xsd:saa.2.0}ReceiverDeliveryStatus"/&gt;
 *         &lt;element name="MessageIdentifier" type="{urn:swift:saa:xsd:saa.2.0}MessageIdentifier"/&gt;
 *         &lt;element name="Receiver" type="{urn:swift:saa:xsd:saa.2.0}AddressInfo" minOccurs="0"/&gt;
 *         &lt;element name="InterfaceInfo" type="{urn:swift:saa:xsd:saa.2.0}InterfaceInfo" minOccurs="0"/&gt;
 *         &lt;element name="NetworkInfo" type="{urn:swift:saa:xsd:saa.2.0}NetworkInfo" minOccurs="0"/&gt;
 *         &lt;element name="SecurityInfo" type="{urn:swift:saa:xsd:saa.2.0}SecurityInfo" minOccurs="0"/&gt;
 *         &lt;element name="SAAInfo" type="{urn:swift:saa:xsd:saa.2.0}SAAInfo" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeliveryNotification", propOrder = {
    "reconciliationInfo",
    "receiverDeliveryStatus",
    "messageIdentifier",
    "receiver",
    "interfaceInfo",
    "networkInfo",
    "securityInfo",
    "saaInfo"
})
public class DeliveryNotification {

    @XmlElement(name = "ReconciliationInfo", required = true)
    protected String reconciliationInfo;
    @XmlElement(name = "ReceiverDeliveryStatus", required = true)
    @XmlSchemaType(name = "string")
    protected ReceiverDeliveryStatus receiverDeliveryStatus;
    @XmlElement(name = "MessageIdentifier", required = true)
    protected String messageIdentifier;
    @XmlElement(name = "Receiver")
    protected AddressInfo receiver;
    @XmlElement(name = "InterfaceInfo")
    protected InterfaceInfo interfaceInfo;
    @XmlElement(name = "NetworkInfo")
    protected NetworkInfo networkInfo;
    @XmlElement(name = "SecurityInfo")
    protected SecurityInfo securityInfo;
    @XmlElement(name = "SAAInfo")
    protected SAAInfo saaInfo;

    /**
     * Obtiene el valor de la propiedad reconciliationInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReconciliationInfo() {
        return reconciliationInfo;
    }

    /**
     * Define el valor de la propiedad reconciliationInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReconciliationInfo(String value) {
        this.reconciliationInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad receiverDeliveryStatus.
     * 
     * @return
     *     possible object is
     *     {@link ReceiverDeliveryStatus }
     *     
     */
    public ReceiverDeliveryStatus getReceiverDeliveryStatus() {
        return receiverDeliveryStatus;
    }

    /**
     * Define el valor de la propiedad receiverDeliveryStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link ReceiverDeliveryStatus }
     *     
     */
    public void setReceiverDeliveryStatus(ReceiverDeliveryStatus value) {
        this.receiverDeliveryStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad messageIdentifier.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageIdentifier() {
        return messageIdentifier;
    }

    /**
     * Define el valor de la propiedad messageIdentifier.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageIdentifier(String value) {
        this.messageIdentifier = value;
    }

    /**
     * Obtiene el valor de la propiedad receiver.
     * 
     * @return
     *     possible object is
     *     {@link AddressInfo }
     *     
     */
    public AddressInfo getReceiver() {
        return receiver;
    }

    /**
     * Define el valor de la propiedad receiver.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressInfo }
     *     
     */
    public void setReceiver(AddressInfo value) {
        this.receiver = value;
    }

    /**
     * Obtiene el valor de la propiedad interfaceInfo.
     * 
     * @return
     *     possible object is
     *     {@link InterfaceInfo }
     *     
     */
    public InterfaceInfo getInterfaceInfo() {
        return interfaceInfo;
    }

    /**
     * Define el valor de la propiedad interfaceInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link InterfaceInfo }
     *     
     */
    public void setInterfaceInfo(InterfaceInfo value) {
        this.interfaceInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad networkInfo.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInfo }
     *     
     */
    public NetworkInfo getNetworkInfo() {
        return networkInfo;
    }

    /**
     * Define el valor de la propiedad networkInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInfo }
     *     
     */
    public void setNetworkInfo(NetworkInfo value) {
        this.networkInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad securityInfo.
     * 
     * @return
     *     possible object is
     *     {@link SecurityInfo }
     *     
     */
    public SecurityInfo getSecurityInfo() {
        return securityInfo;
    }

    /**
     * Define el valor de la propiedad securityInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SecurityInfo }
     *     
     */
    public void setSecurityInfo(SecurityInfo value) {
        this.securityInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad saaInfo.
     * 
     * @return
     *     possible object is
     *     {@link SAAInfo }
     *     
     */
    public SAAInfo getSAAInfo() {
        return saaInfo;
    }

    /**
     * Define el valor de la propiedad saaInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SAAInfo }
     *     
     */
    public void setSAAInfo(SAAInfo value) {
        this.saaInfo = value;
    }

}
