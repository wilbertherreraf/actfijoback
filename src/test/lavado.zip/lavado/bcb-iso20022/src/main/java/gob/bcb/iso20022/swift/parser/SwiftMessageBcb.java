package gob.bcb.iso20022.swift.parser;

public interface SwiftMessageBcb {

}
