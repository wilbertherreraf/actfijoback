package gob.bcb.iso20022.lau;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;

import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.StringUtils;

public class AuthParameters {
	private static final int LAU_KEY_MIN_CHARS = 17;
	private static final int LAU_KEY_MAX_CHARS = 32;
	private static final String HMAC_SHA256 = "HmacSHA256";
	
	private final String leftKey;
	private final String rightKey;
	private final Key keyMac;
	
	public AuthParameters(final String leftKey, final String rightKey) {
		this.leftKey = leftKey;
		this.rightKey = rightKey;
		this.keyMac = null;
	}
	
	public AuthParameters(final SecretKeySpec key) {
		this.leftKey = null;
		this.rightKey = null;
		this.keyMac = key;
	}
	
	public SecretKeySpec getKey(){
		if (keyMac != null) {
			return (SecretKeySpec) keyMac;
		}
		
		String pEncodedKey = StringUtils.trimToEmpty(leftKey) + StringUtils.trimToEmpty(rightKey);
		final byte[] key = new byte[LAU_KEY_MAX_CHARS];
		if (pEncodedKey.length() > LAU_KEY_MAX_CHARS || pEncodedKey.length() < LAU_KEY_MIN_CHARS) {
			throw new RuntimeException(String.format("LAU key must be between %d and %d characters in length", LAU_KEY_MIN_CHARS, LAU_KEY_MAX_CHARS));
		} else {
			Arrays.fill(key, (byte) 0);
			System.arraycopy(pEncodedKey.getBytes(StandardCharsets.UTF_8), 0, key, 0, pEncodedKey.getBytes(StandardCharsets.UTF_8).length);
		}
		return new SecretKeySpec(key, HMAC_SHA256);
	}
}
