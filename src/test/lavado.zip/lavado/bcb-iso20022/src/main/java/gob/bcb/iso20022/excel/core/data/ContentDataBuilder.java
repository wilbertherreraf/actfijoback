package gob.bcb.iso20022.excel.core.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;

import gob.bcb.iso20022.excel.component.ExcelProperty;
import gob.bcb.iso20022.excel.utils.ClassUtils;

public class ContentDataBuilder<T> extends ExcelProperty {
    private ContentDataBuilder() {
        if (CollectionUtils.isEmpty(this.contentDataList)) {
            this.contentDataList = new ArrayList<>();
        }
    }

    private ContentDataBuilder(List<HeaderData> headerDataList) {
        if (CollectionUtils.isEmpty(this.contentDataList)) {
            this.contentDataList = new ArrayList<>();
        }

        this.headerDataList = headerDataList;
    }

    public static ContentDataBuilder instance() {
        return new ContentDataBuilder();
    }

    /**
     *
     * @param headerDataList
     * @return
     */
    public static ContentDataBuilder instance(List<HeaderData> headerDataList) {
        return new ContentDataBuilder(headerDataList);
    }

    /**
     * @param content
     * @param isTransform
     * @return
     */
    public ContentDataBuilder fill(List<Object> content, boolean isTransform) {
        return fill(content,isTransform,true);
    }

    public ContentDataBuilder fill(List<Object> content, boolean isTransform,boolean isMultiLine) {
        if (CollectionUtils.isEmpty(content)) {
            throw new IllegalArgumentException("content is null");
        }

        if (isTransform) {
            List<T> transformedContent = content.stream().map(c -> (T) c).collect(Collectors.toList());
            fill(transformedContent);
        } else {
            if (CollectionUtils.isEmpty(contentDataList)) {
                contentDataList = new ArrayList<>();
            }

            if(isMultiLine){
                content.stream().forEach(c->{
                    List<Object> row = new ArrayList<>();
                    row.add(c);
                    contentDataList.add(row);
                });
            }else {
                contentDataList.add(content);
            }
        }
        return this;
    }

    /**
     *
     * @param t
     * @return
     */
    public ContentDataBuilder fill(T t) {

        if (Objects.isNull(t)) {
            throw new IllegalArgumentException("content is null");
        }

        List<Object> content = new ArrayList<>();
        if (CollectionUtils.isEmpty(headerDataList)) {
            throw new IllegalArgumentException("headerDataList is null");
        }

        for (HeaderData headerData : headerDataList) {
            String fieldName = headerData.getFieldName();
            Object val = ClassUtils.getField(t, fieldName);
            content.add(val);
        }
        contentDataList.add(content);
        return this;
    }


    /**
     *
     * @param list
     * @return
     */
    public ContentDataBuilder fill(List<T> list) {
        if (CollectionUtils.isEmpty(list)) {
            throw new IllegalArgumentException("content is null");
        }

        if (CollectionUtils.isEmpty(headerDataList)) {
            throw new IllegalArgumentException("headerDataList is null");
        }

        for (T t : list) {
            List<Object> content = new ArrayList<>();
            for (HeaderData headerData : headerDataList) {
                String fieldName = headerData.getFieldName();
                Object val = ClassUtils.getField(t, fieldName);
                content.add(val);
            }
            contentDataList.add(content);
        }
        return this;
    }


    public List<List<Object>> build() {
        return contentDataList;
    }
}
