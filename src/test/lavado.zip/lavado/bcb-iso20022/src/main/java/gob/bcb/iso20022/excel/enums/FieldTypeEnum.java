package gob.bcb.iso20022.excel.enums;

import org.apache.poi.ss.usermodel.CellType;

public enum FieldTypeEnum {
    INTEGER(0, CellType.NUMERIC),
    LONG(1, CellType.NUMERIC),
    DOUBLE(2, CellType.NUMERIC),
    FLOAT(3, CellType.NUMERIC),
    BOOLEAN(4, CellType.BOOLEAN),
    STRING(5, CellType.STRING),
    FORMULA(6, CellType.FORMULA),
    BLANK(7, CellType.BLANK),
    BIG_DECIMAL(8,CellType.NUMERIC),
    DATE(9,CellType.NUMERIC);

    int type;
    CellType cellType;

    FieldTypeEnum(int type, CellType cellType) {
        this.type = type;
        this.cellType = cellType;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public CellType getCellType() {
        return cellType;
    }

    public void setCellType(CellType cellType) {
        this.cellType = cellType;
    }
}
