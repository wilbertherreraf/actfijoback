
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Header complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Header"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice&gt;
 *         &lt;element name="Message" type="{urn:swift:saa:xsd:saa.2.0}Message"/&gt;
 *         &lt;element name="TransmissionReport" type="{urn:swift:saa:xsd:saa.2.0}TransmissionReport"/&gt;
 *         &lt;element name="DeliveryNotification" type="{urn:swift:saa:xsd:saa.2.0}DeliveryNotification"/&gt;
 *         &lt;element name="DeliveryReport" type="{urn:swift:saa:xsd:saa.2.0}DeliveryReport"/&gt;
 *         &lt;element name="HistoryReport" type="{urn:swift:saa:xsd:saa.2.0}HistoryReport"/&gt;
 *         &lt;element name="MessageStatus" type="{urn:swift:saa:xsd:saa.2.0}MessageStatus"/&gt;
 *         &lt;element name="SessionStatus" type="{urn:swift:saa:xsd:saa.2.0}SessionStatus"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Header", propOrder = {
    "sessionStatus",
    "messageStatus",
    "historyReport",
    "deliveryReport",
    "deliveryNotification",
    "transmissionReport",
    "message"
})
public class Header {

    @XmlElement(name = "SessionStatus")
    protected SessionStatus sessionStatus;
    @XmlElement(name = "MessageStatus")
    protected MessageStatus messageStatus;
    @XmlElement(name = "HistoryReport")
    protected HistoryReport historyReport;
    @XmlElement(name = "DeliveryReport")
    protected DeliveryReport deliveryReport;
    @XmlElement(name = "DeliveryNotification")
    protected DeliveryNotification deliveryNotification;
    @XmlElement(name = "TransmissionReport")
    protected TransmissionReport transmissionReport;
    @XmlElement(name = "Message")
    protected Message message;

    /**
     * Obtiene el valor de la propiedad sessionStatus.
     * 
     * @return
     *     possible object is
     *     {@link SessionStatus }
     *     
     */
    public SessionStatus getSessionStatus() {
        return sessionStatus;
    }

    /**
     * Define el valor de la propiedad sessionStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link SessionStatus }
     *     
     */
    public void setSessionStatus(SessionStatus value) {
        this.sessionStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad messageStatus.
     * 
     * @return
     *     possible object is
     *     {@link MessageStatus }
     *     
     */
    public MessageStatus getMessageStatus() {
        return messageStatus;
    }

    /**
     * Define el valor de la propiedad messageStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageStatus }
     *     
     */
    public void setMessageStatus(MessageStatus value) {
        this.messageStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad historyReport.
     * 
     * @return
     *     possible object is
     *     {@link HistoryReport }
     *     
     */
    public HistoryReport getHistoryReport() {
        return historyReport;
    }

    /**
     * Define el valor de la propiedad historyReport.
     * 
     * @param value
     *     allowed object is
     *     {@link HistoryReport }
     *     
     */
    public void setHistoryReport(HistoryReport value) {
        this.historyReport = value;
    }

    /**
     * Obtiene el valor de la propiedad deliveryReport.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryReport }
     *     
     */
    public DeliveryReport getDeliveryReport() {
        return deliveryReport;
    }

    /**
     * Define el valor de la propiedad deliveryReport.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryReport }
     *     
     */
    public void setDeliveryReport(DeliveryReport value) {
        this.deliveryReport = value;
    }

    /**
     * Obtiene el valor de la propiedad deliveryNotification.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryNotification }
     *     
     */
    public DeliveryNotification getDeliveryNotification() {
        return deliveryNotification;
    }

    /**
     * Define el valor de la propiedad deliveryNotification.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryNotification }
     *     
     */
    public void setDeliveryNotification(DeliveryNotification value) {
        this.deliveryNotification = value;
    }

    /**
     * Obtiene el valor de la propiedad transmissionReport.
     * 
     * @return
     *     possible object is
     *     {@link TransmissionReport }
     *     
     */
    public TransmissionReport getTransmissionReport() {
        return transmissionReport;
    }

    /**
     * Define el valor de la propiedad transmissionReport.
     * 
     * @param value
     *     allowed object is
     *     {@link TransmissionReport }
     *     
     */
    public void setTransmissionReport(TransmissionReport value) {
        this.transmissionReport = value;
    }

    /**
     * Obtiene el valor de la propiedad message.
     * 
     * @return
     *     possible object is
     *     {@link Message }
     *     
     */
    public Message getMessage() {
        return message;
    }

    /**
     * Define el valor de la propiedad message.
     * 
     * @param value
     *     allowed object is
     *     {@link Message }
     *     
     */
    public Header setMessage(Message value) {
        this.message = value;
        return this;
    }

}
