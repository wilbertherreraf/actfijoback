package gob.bcb.iso20022.excel.core.listener;

import java.util.EventListener;

public interface ReadListener<T> extends EventListener {
    void invoke(T data);

    void doAfterRead();
}
