package gob.bcb.iso20022.core.xml;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.StringJoiner;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;

import org.apache.commons.lang3.StringUtils;
import org.apache.xml.security.Init;
import org.apache.xml.security.c14n.Canonicalizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.DocumentTraversal;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.prowidesoftware.swift.model.mx.MxWriteImpl;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

public class JaxBConversionService {
	private static final Logger log = LoggerFactory.getLogger(JaxBConversionService.class);
	static {
		Init.init();
	}

	/**
	 * Exception while serializing/deserializing with jaxb.
	 */
	public class ConversionExeption extends RuntimeException {
		public ConversionExeption(final String message, final Exception cause) {
			super(message, cause);
		}

		public ConversionExeption(final String message) {
			super(message);
		}
	}

	private static JaxBConversionService instance;
	private static final int MAX_LOG_CONTENT = 50;

	// context setup
	private static JAXBContext jaxbContext;

	private JaxBConversionService() {
	}

	public static JaxBConversionService getInstance() {
		if (instance == null) {
			instance = new JaxBConversionService();
		}
		return instance;
	}

	public JAXBContext getJaxbContext() {
		if (jaxbContext == null) {
			initialize();
		}
		return jaxbContext;
	}

	private static <T> QName createQName(final T model) {
		return new QName(model.getClass().getSimpleName().toLowerCase());
	}

	private void checkInputEmpty(final URI xml) {
		if (xml == null) {
			throw new ConversionExeption("Can not unmarshal from empty input");
		}
	}

	private <T> void checkTypeEmpty(final Class<T> type) {
		if (type == null) {
			throw new ConversionExeption("Can not unmarshal without type information. Need to specify a target type");
		}
	}

	/**
	 * Initialisiert den default context; Alle Packages mit {@link XmlRegistry
	 * XmlRegistries}.
	 */
	public JaxBConversionService initialize() {
		final Collection<Package> p = new ArrayList<>();
		// p.add(gob.bcb.iso20022.swift.saa.model.ObjectFactory.class.getPackage());
		// p.add(de.kosit.validationtool.model.scenarios.ObjectFactory.class.getPackage());
		initialize(p);
		return this;
	}

	public JaxBConversionService initialize(final Class<?>[] classes) {
		try {
			jaxbContext = JAXBContext.newInstance(classes);
		} catch (final JAXBException e) {
			throw new IllegalStateException(String.format("Can not create JAXB context for given context %s", e.getMessage()), e);
		}
		return this;
	}

	public JaxBConversionService initialize0(Class... classesToBeBound) {
		try {
			jaxbContext = JAXBContext.newInstance(classesToBeBound);
		} catch (final JAXBException e) {
			throw new IllegalStateException(String.format("Can not create JAXB context for given context"), e);
		}
		return this;
	}

	public JaxBConversionService initialize(final Package... context) {
		initialize(Arrays.asList(context));
		return this;
	}

	/**
	 * Initialisiert den conversion service mit den angegegebenen Packages.
	 *
	 * @param context packages für den JAXB Kontext
	 */
	public JaxBConversionService initialize(final Collection<Package> context) {
		final String[] packages = context != null ? context.stream().map(Package::getName).toArray(String[]::new) : new String[0];
		final StringJoiner joiner = new StringJoiner(":");
		Arrays.stream(packages).forEach(joiner::add);
		initialize(joiner.toString());
		return this;
	}

	/**
	 * Initialsiert den conversion service mit dem angegebenen Kontextpfad
	 *
	 * @param contextPath der Kontextpfad
	 */
	private void initialize(final String contextPath) {
		try {
			jaxbContext = JAXBContext.newInstance(contextPath, JaxBConversionService.class.getClassLoader());
		} catch (final JAXBException e) {
			throw new IllegalStateException(String.format("Can not create JAXB context for given context: %s", contextPath), e);
		}
	}

	/**
	 * Unmarshalls a specific XML model into a defined Java object.
	 *
	 * @param xml  the xml
	 * @param type the expected type created
	 * @param <T>  type information
	 * @return the created object
	 */
	public <T> T readXml(final URI xml, final Class<T> type) {
		return readXml(xml, type, null, null);
	}

	public <T> T readXml(final URI xml, final Class<T> type, final Schema schema) {
		return readXml(xml, type, schema, null);
	}

	public <T> T readXml(final URI xml, final Class<T> type, final Schema schema, final ValidationEventHandler handler) {
		checkInputEmpty(xml);
		checkTypeEmpty(type);
//        CollectingErrorEventHandler defaultHandler = null;
//        ValidationEventHandler handler2Use = handler;
//        if (schema != null && handler == null) {
//            defaultHandler = new CollectingErrorEventHandler();
//            handler2Use = defaultHandler;
//        }
		try {
			final XMLInputFactory inputFactory = XMLInputFactory.newFactory();
			inputFactory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
			inputFactory.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, false);
			inputFactory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
			final XMLStreamReader xsr = inputFactory.createXMLStreamReader(new StreamSource(xml.toASCIIString()));
			final Unmarshaller u = getJaxbContext().createUnmarshaller();
			u.setSchema(schema);

//            u.setEventHandler(handler2Use);
			final T value = u.unmarshal(xsr, type).getValue();
//            if (defaultHandler != null && defaultHandler.hasErrors()) {
//                throw new ConversionExeption(
//                        String.format("Schema errors while reading content from %s: %s", xml, defaultHandler.getErrorDescription()));
//            }

			return value;
		} catch (final JAXBException | XMLStreamException e) {
			throw new ConversionExeption(String.format("Can not unmarshal to type %s from %s", type.getSimpleName(), xml.toString()), e);
		}
	}

	/**
	 * Serializing an object to xml.
	 *
	 * @param model the object
	 * @param <T>   type of the object
	 * @return the serialized form.
	 */
	public <T> String writeXml(final T model) {
		return writeXml(model, null, null);
	}

	public <T> String writeXml(final T model, final Schema schema, final ValidationEventHandler handler) {
		if (model == null) {
			throw new ConversionExeption("Can not serialize null");
		}
		try (final StringWriter w = new StringWriter()) {
			final JAXBIntrospector introspector = getJaxbContext().createJAXBIntrospector();
			final Marshaller marshaller = getJaxbContext().createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			marshaller.setSchema(schema);
			marshaller.setEventHandler(handler);
			final XMLOutputFactory xof = XMLOutputFactory.newFactory();
			final XMLStreamWriter xmlStreamWriter = xof.createXMLStreamWriter(w);
			if (null == introspector.getElementName(model)) {
				final JAXBElement jaxbElement = new JAXBElement(createQName(model), model.getClass(), model);
				marshaller.marshal(jaxbElement, xmlStreamWriter);
			} else {
				marshaller.marshal(model, xmlStreamWriter);
			}
			xmlStreamWriter.flush();
			return w.toString();
		} catch (final JAXBException | IOException | XMLStreamException e) {
			throw new ConversionExeption(String.format("Error serializing Object %s", model.getClass().getName()), e);
		}
	}

	public <T> T readDocument(final Source source, final Class<T> type) {
		try {
			final Unmarshaller u = getJaxbContext().createUnmarshaller();
			JAXBElement<T> e = u.unmarshal(source, type);
			if (e == null) {
				throw new RuntimeException("Error al desparcear xml, unmarshal retorna nulo para " + type.getSimpleName());
			}
			return e.getValue();

		} catch (final JAXBException e) {
			throw new ConversionExeption(
					String.format("Can not unmarshal to type %s: %s", type.getSimpleName(), StringUtils.abbreviate(source.getSystemId(), MAX_LOG_CONTENT)),
					e);
		}
	}

	public <T> T readDocument(String xml, final Class<T> type) {
		try {
			final Source source = new SAXSource(new InputSource(new StringReader(xml)));
			return readDocument(source, type);
		} catch (final Exception e) {
			throw new ConversionExeption(
					String.format("Can not unmarshal to type %s: %s", type.getSimpleName(), StringUtils.abbreviate(xml, MAX_LOG_CONTENT)), e);
		}
	}

	public Document toDocument(Object value) throws JAXBException, ParserConfigurationException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		if (value.getClass().getAnnotation(XmlRootElement.class) != null) {
			JAXBContext context = getJaxbContext(); // getJaxbContext(value);
			Document doc = createDocument();

			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper() {
				@Override
				public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
					if ("urn:iso:std:iso:20022:tech:xsd:head.001.001.02".equals(namespaceUri)) {
						return "h";
					} else if ("urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08".equals(namespaceUri)) {
						return "Doc";
					} else if ("urn:swift:saa:xsd:saa.2.0".equals(namespaceUri)) {
						return "Saa";
					}
					return suggestion;
				}
			});

			final JAXBIntrospector introspector = getJaxbContext().createJAXBIntrospector();
			final XMLOutputFactory xof = XMLOutputFactory.newFactory();
			// final XMLStreamWriter xmlStreamWriter = xof.createXMLStreamWriter(w);
			if (null == introspector.getElementName(value)) {
				final JAXBElement jaxbElement = new JAXBElement(createQName(value), value.getClass(), value);
				marshaller.marshal(jaxbElement, doc);
			} else {
				marshaller.marshal(value, doc);
			}

			// marshaller.marshal(value, doc);
			return doc;
		} else {
			JAXBContext context = getJaxbContext(); // getPackageContext(value);
			// must create a new instance of marshaller as its not thread safe
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper() {
				@Override
				public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
					log.info("en iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii::> " + namespaceUri + " suggestion: " + suggestion + " " + requirePrefix);
					if ("urn:iso:std:iso:20022:tech:xsd:head.001.001.02".equals(namespaceUri)) {
						return "h";
					} else if ("urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08".equals(namespaceUri)) {
						return "Doc";
					} else if ("urn:swift:saa:xsd:saa.2.0".equals(namespaceUri)) {
						return "Saa";
					}
					return suggestion;
				}
			});
			Document doc = createDocument();
			marshaller.marshal(value, doc);
			return doc;
		}

	}

	public static org.w3c.dom.Document createDocument() throws ParserConfigurationException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		DocumentBuilder db = dbf.newDocumentBuilder();

		org.w3c.dom.Document doc = db.newDocument();

		return doc;
	}

	public static String getStringFromDom(Document doc, boolean excludeDeclaration, boolean prettyPrint) throws TransformerException {
		if (null == doc) {
			throw new InvalidParameterException("Objeto Document proporcionado es null.");
		}
		TransformerFactory tf = TransformerFactory.newInstance();
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		Transformer transformer = tf.newTransformer();
		// transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.MEDIA_TYPE, "text/xml");

		if (excludeDeclaration) {
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		}
		if (prettyPrint) {
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
		}

		transformer.transform(domSource, result);
		return writer.toString();
	}

	public static String getStringFromDom(Document doc) {
		try {

			if (null == doc) {
				throw new InvalidParameterException("Objeto Document proporcionado es null.");
			}
			TransformerFactory tf = TransformerFactory.newInstance();
			doc.setXmlStandalone(true);
			DOMSource domSource = new DOMSource(doc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			Transformer transformer = tf.newTransformer();
			// transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.MEDIA_TYPE, "text/xml");
			transformer.transform(domSource, result);
			return writer.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static String getStringFromDom(Document doc, boolean withHeader) {
		try {
			if (null == doc) {
				throw new InvalidParameterException("Objeto Document proporcionado es null.");
			}
			TransformerFactory tf = TransformerFactory.newInstance();
			if (!withHeader) {
				doc.setXmlStandalone(true);
			}
			DOMSource domSource = new DOMSource(doc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			Transformer transformer = tf.newTransformer();
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.MEDIA_TYPE, "text/xml");
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, (!withHeader ? "yes" : "no"));
			transformer.transform(domSource, result);
			return writer.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Document getDomFromString(final String xmlSource) {
		try {
			byte[] dataBytes = xmlSource.getBytes(StandardCharsets.UTF_8);
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();

			return builder.parse(new ByteArrayInputStream(dataBytes));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Document documentBasedOnThe(byte[] xml) {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new ByteArrayInputStream(xml));
			document.normalize();
			return document;

		} catch (Exception e) {
			throw new RuntimeException("Could not create signed Document", e);
		}
	}

	public static byte[] createXmlUsing(Document doc) {
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			StreamResult result = new StreamResult(bos);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer trans = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			trans.setOutputProperty(OutputKeys.INDENT, "no");

			trans.transform(source, result);
			return bos.toByteArray();

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static void outputDocToFile(Document doc, String fileName) throws Exception {
		File encryptionFile = new File(fileName);
		FileOutputStream f = new FileOutputStream(encryptionFile);

		TransformerFactory factory = TransformerFactory.newInstance();
		Transformer transformer = factory.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(f);
		transformer.transform(source, result);

		f.close();
	}

	public static String xmlOfTag(Document doc, String tag) {
		Node node = findTagInDoc(doc, tag);
		return node2XML(node, true, false);
	}

	public static String valueOfTag(Document doc, String tag) {
		try {
			if (doc == null)
				return "";
			Element e = findTagInDoc(doc, tag);
			if (e == null)
				throw new RuntimeException("Inexistente tag: " + tag);
			return e.getTextContent();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static String valueOfTag(Node node, String tag) {
		try {
			if (node == null || StringUtils.isBlank(tag))
				return "";
			Element e = findTagInDoc(node, tag);
			if (e == null)
				return "";
			return e.getTextContent();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	public static String node2XML(Node node, boolean excludeDeclaration, boolean prettyPrint) {
		if (node == null)
			return null;
		try {
			TransformerFactory transFactory = TransformerFactory.newInstance();
			Transformer transformer = transFactory.newTransformer();
			DOMSource dSource = new DOMSource(node);
			StringWriter sw = new StringWriter();
			StreamResult sr = new StreamResult(sw);
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.MEDIA_TYPE, "text/xml");
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

			if (!excludeDeclaration) {
				transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
			}
			if (prettyPrint) {
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			}

			transformer.transform(dSource, sr);
			return sw.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static String node2XML(Node node) {
		return node2XML(node, true, false);
	}

	public static String node2XMLCanno(Node node) {
		if (node == null)
			return null;
		try {
			Canonicalizer c14n = Canonicalizer.getInstance(Canonicalizer.ALGO_ID_C14N11_OMIT_COMMENTS);
			ByteArrayOutputStream bos = new ByteArrayOutputStream();

			TransformerFactory transFactory = TransformerFactory.newInstance();
			Transformer transformer = transFactory.newTransformer();
			DOMSource dSource = new DOMSource(node);
			StringWriter sw = new StringWriter();
			StreamResult sr = new StreamResult(sw);
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.MEDIA_TYPE, "text/xml");
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

			transformer.transform(dSource, sr);

			c14n.canonicalize(sw.toString().getBytes(), bos, false);

			byte[] r = bos.toByteArray();
			String s = new String(r, "UTF-8");
			return s;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Element findTagInDoc(Document doc, String tag) {
		NodeIterator ni = ((DocumentTraversal) doc).createNodeIterator(doc.getDocumentElement(), NodeFilter.SHOW_ELEMENT, null, false);

		for (Node n = ni.nextNode(); n != null; n = ni.nextNode()) {
			if (tag.equals(n.getLocalName())) {
				return (Element) n;
			} else {
				Element e = findTagInDoc(n, tag);
				if (e != null)
					return e;				
			}
		}
		return null;
	}

	public static Element findTagInDoc(Node node, String tag) {
		for (int i = 0; i < node.getChildNodes().getLength(); i++) {
			Node n = node.getChildNodes().item(i);
			if (tag.equals(n.getLocalName())) {
				return (Element) n;
			} else {
				if (n.getChildNodes().getLength() > 0) {
					Element e = findTagInDoc(n, tag);
					if (e != null)
						return e;
				}				
			}
		}
		return null;
	}
//	MxWriteImpl
//	JaxbContextLoader
}
