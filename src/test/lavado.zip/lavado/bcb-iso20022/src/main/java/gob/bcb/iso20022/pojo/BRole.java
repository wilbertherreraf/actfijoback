package gob.bcb.iso20022.pojo;

public class BRole extends Role{
	private Part part;
	private Part finInst;
	private Ssi clrSys;
	
	public Part getPart() {
		return part;
	}
	public void setPart(Part part) {
		this.part = part;
	}
	public Part getFinInst() {
		return finInst;
	}
	public void setFinInst(Part finInst) {
		this.finInst = finInst;
	}
	public Ssi getClrSys() {
		return clrSys;
	}
	public void setClrSys(Ssi clrSys) {
		this.clrSys = clrSys;
	}
}
