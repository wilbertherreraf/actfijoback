package gob.bcb.iso20022.rules;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.mvel2.MVEL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.exceptions.CompileException;
import gob.bcb.iso20022.exceptions.DuplicateNameException;
import gob.bcb.iso20022.exceptions.NoActionFoundException;
import gob.bcb.iso20022.exceptions.NoMatchingRuleFoundException;
import gob.bcb.iso20022.exceptions.ParseException;

/**
 * Clase modificcada del original https://github.com/maxant/rules/releases/new
 * 
 * @author WHerrera
 *
 */
public class Engine {
	private final static Logger log = LoggerFactory.getLogger(Engine.class);

	public static final String DEFAULT_ILLEGAL_WORDS = "java," + // e.g. access to java.io.xyz
			"System," + // e.g. access to System.exit(1);
			"Runtime," + // e.g. access to Runtime.getRuntime.exec("rm -rf")
			"InitialContext," + // e.g. for accessing the CDI Bean Manager or TX Manager or some EJB (Service)
			"new ," + // e.g. to instantiate classes - space afterwards so that its less critical
			"getBean" // e.g. using spring context in order to call a service
	;

	public static final String DEFAULT_INPUT_NAME = "input";
	public static final String DEFAULT_OUTPUT_NAME = "output";
	/**
	 * variables estaticas y metodos iniciales
	 */
	private final Map<String, Object> statics;
	private final Map<String, CompiledRule> rulesMap = new HashMap<>();
	private List<CompiledRule> rules;
	protected final Set<String> uniqueOutcomes = new HashSet<String>();
	protected List<Rule> parsedRules;

	protected final boolean throwExceptionIfCompilationFails;
	protected final String inputName;
	private final List<IAction> actions = new ArrayList<>();

	/**
	 * @param rules                            reglas que definen el sistema
	 * @param throwExceptionIfCompilationFails si es verdadero dispara una excepcion
	 *                                         {@link CompileException} .
	 * @throws DuplicateNameException exception si existe duplicacion en nombre de
	 *                                regla
	 * @throws CompileException       excepcion si existe errores en la compilacion
	 * @throws ParseException
	 */
	public Engine(final Collection<Rule> rules, boolean throwExceptionIfCompilationFails) throws DuplicateNameException, CompileException, ParseException {
		this(rules, DEFAULT_INPUT_NAME, throwExceptionIfCompilationFails);
	}

	public Engine(final Collection<Rule> rules, String inputName, boolean throwExceptionIfCompilationFails)
			throws DuplicateNameException, CompileException, ParseException {
		this(rules, inputName, throwExceptionIfCompilationFails, new HashMap<String, Object>());
	}

	public Engine(final Collection<Rule> rules, boolean throwExceptionIfCompilationFails, Map<String, Object> statics)
			throws DuplicateNameException, CompileException, ParseException {
		this(rules, DEFAULT_INPUT_NAME, throwExceptionIfCompilationFails, statics);
	}

	protected Engine(final Collection<Rule> rules, String inputName, boolean throwExceptionIfCompilationFails, Map<String, Object> statics)
			throws DuplicateNameException, CompileException, ParseException {
		this.inputName = inputName;
		this.throwExceptionIfCompilationFails = throwExceptionIfCompilationFails;
		this.statics = statics;
		init(rules);
	}

	/** handles the initialisation */
	protected void init(Collection<Rule> rules) throws DuplicateNameException, CompileException, ParseException {
		Set<String> illegalWordSet = initIllegalWords();

		this.rules = new ArrayList<CompiledRule>();

		Map<String, Rule> names = new HashMap<String, Rule>();
		for (Rule r : rules) {
			if (StringUtils.isBlank(r.getExpression())) {
				continue;
			}
			verifyLegal(r, illegalWordSet);

			String fullyQualifiedName = r.getFullyQualifiedName();
			if (names.containsKey(fullyQualifiedName)) {
				throw new DuplicateNameException("The name " + fullyQualifiedName + " was found in a different rule.");
			}
			names.put(fullyQualifiedName, r);
			if (r.getOutcome() != null && r.getOutcome().isEmpty())
				uniqueOutcomes.add(r.getOutcome());
		}

		parsedRules = new ArrayList<Rule>();

		// now replace all rule references with the actual rule, contained within
		// brackets
		while (true) {
			boolean foundRuleReference = false;

			for (Rule r : rules) {
				if (StringUtils.isBlank(r.getExpression())) {
					continue;
				}

				int idx1 = r.getExpression().indexOf('#');
				if (idx1 > -1 && names.size() > 1) {
					foundRuleReference = true;

					// search to end of expression for next symbol
					int idx2 = idx1 + 1; // to skip #
					while (true) {
						idx2++;
						if (idx2 >= r.getExpression().length()) {
							break;
						}
						char c = r.getExpression().charAt(idx2);
						if (c == ' ' || c == '&' || //
								c == '|' || c == '.' || //
								c == '(' || c == ')' || //
								c == '[' || c == ']' || //
								c == '{' || c == '}' || //
								c == '+' || c == '-' || //
								c == '/' || c == '*' || //
								c == '=' || c == '!' //
						) {
							// end of token
							break;
						}
					}

					String token = r.getExpression().substring(idx1 + 1, idx2);
					String fullyQualifiedRuleRef = r.getNamespace() + "." + token;
					Rule toAdd = names.get(fullyQualifiedRuleRef);
					if (toAdd == null) {
						throw new ParseException("Error while attempting to add subrule to rule " + r.getFullyQualifiedName() + ".  Unable to replace #"
								+ token + " with subrule " + fullyQualifiedRuleRef + " because no subrule with that fully qualified name was found");
					}
					String newExpression = "";
					if (idx1 > 0) {
						newExpression += r.getExpression().substring(0, idx1);
					}
					newExpression += "(" + toAdd.getExpression() + ")";
					if (idx2 < r.getExpression().length()) {
						newExpression += r.getExpression().substring(idx2);
					}
					if (r instanceof SubRule) {
						parsedRules.add(new SubRule(r.getName(), newExpression, r.getNamespace(), r.getDescription()));
					} else {
//						Rule rn = new Rule(r.getId(),r.getName(), newExpression, r.getOutcome(), r.getPriority(), r.getNamespace(), r.getDescription(), 
//								r.getAction(), r.getPath());
						Rule rn = r.clone();
						rn.setExpression(newExpression);
						parsedRules.add(rn);
					}
				} else {
					parsedRules.add(r);
				}
			}
			if (!foundRuleReference) {
				// seeee , todo bien!!
				break;
			} else {
				// go thru again, because there are still rules which need substituting
				rules = parsedRules;
				parsedRules = new ArrayList<Rule>();
			}
		}
		compile();
	}

	public static Set<String> initIllegalWords() {
		Set<String> illegalWords = new HashSet<String>();
		StringTokenizer st = new StringTokenizer(DEFAULT_ILLEGAL_WORDS, ",");
		while (st.hasMoreTokens()) {
			illegalWords.add(st.nextToken());
		}
		return illegalWords;
	}

	protected void verifyLegal(Rule r, Set<String> illegalWords) {
		for (String illegalWord : illegalWords) {
			if (r.getExpression().contains(illegalWord)) {
				throw new IllegalArgumentException("Rule has an illegal word! None of the following words may be contained in rules: " + illegalWords
						+ ". Alternatively override Engine#initIllegalWords or Engine#verifyLegal.");
			}
		}
	}

	protected void compile() throws CompileException {
		for (Rule r : parsedRules) {
			if (r instanceof SubRule) {
				continue;
			}
			addCompiledRule(throwExceptionIfCompilationFails, r);
		}
	}

	private void addCompiledRule(boolean throwExceptionIfCompilationFails, Rule r) throws CompileException {
		try {
			CompiledRule cr = new CompiledRule(r);
			this.rules.add(cr);

			rulesMap.put(r.getFullyQualifiedName(), cr);
		} catch (org.mvel2.CompileException ex) {
			if (throwExceptionIfCompilationFails) {
				throw new CompileException("Failed to compile " + r.getFullyQualifiedName() + ": " + ex.getMessage());
			}
		}
	}

	public void addCompiledRuleToMap(boolean throwExceptionIfCompilationFails, Rule r) throws CompileException {
		try {
			CompiledRule cr = new CompiledRule(r);

			rulesMap.remove(r.getFullyQualifiedName());
			rulesMap.put(r.getFullyQualifiedName(), cr);
		} catch (org.mvel2.CompileException ex) {
			if (throwExceptionIfCompilationFails) {
				throw new CompileException("Failed to compile " + r.getFullyQualifiedName() + ": " + ex.getMessage());
			}
		}
	}

//	public <Input, Output> Output execu0teBestAction(Input input, Collection<? extends IAction<Input, Output>> actions)
//			throws NoMatchingRuleFoundException, NoActionFoundException, DuplicateNameException {
//		return executeBestAction(null, input, actions);
//	}
//
	public <Input, Output> Output executeBestAction(String nameSpacePattern, Input input, Collection<? extends IAction<Input, Output>> actions)
			throws NoMatchingRuleFoundException, NoActionFoundException, DuplicateNameException {

		Map<String, Object> vars = generateVars(input);
		Optional<Rule> rOpt = getBestOutcome(nameSpacePattern, input, vars);
		
		if (rOpt.isPresent()) {
			Map<String, IAction<Input, Output>> actionsMap = validateActions(actions, uniqueOutcomes, statics);
			Rule r = rOpt.get();
			CompiledRule compiledRule = new CompiledRule(r);

			MVEL.executeExpression(r.getAction(), vars);
			
			if (r.getOutcome() != null && r.getOutcome().trim().length() > 0 && actionsMap.containsKey(r.getOutcome().trim())) {
				IAction<Input, Output> action = actionsMap.get(r.getOutcome());

				return action.execute(compiledRule, input, vars);
			}

		}
		return null;
	}

	private <Input> Optional<Rule> getBestOutcome(String nameSpacePattern, Input input, Map<String, Object> vars) throws NoMatchingRuleFoundException {
		List<Rule> matches = getMatchingRules(nameSpacePattern, vars);

		if (matches == null || matches.isEmpty()) {
			return Optional.empty();
		} else {
			return Optional.of(matches.get(0));
		}
	}

//	public <Input, Output> void executeAllActions0(Input input) throws NoMatchingRuleFoundException, NoActionFoundException, DuplicateNameException {
//		executeAllActions(null, input, (Collection<? extends IAction<Input, Output>>) actions);
//	}

	public <Input, Output> void executeAllActions(Input input, Collection<? extends IAction<Input, Output>> actions)
			throws NoMatchingRuleFoundException, NoActionFoundException, DuplicateNameException {
		executeAllActions(null, input, actions);
	}

	public <Input, Output> void executeAllActions(String nameSpacePattern, Input input, Collection<? extends IAction<Input, Output>> actions)
			throws NoActionFoundException, DuplicateNameException {

		Map<String, Object> vars = generateVars(input);
		List<CompiledRule> matchingRules = getMatchingCompiledRules(nameSpacePattern, vars);

		Map<String, IAction<Input, Output>> actionsMap = validateActions(actions, uniqueOutcomes, statics);
		Set<String> executedOutcomes = new HashSet<String>();

		for (CompiledRule rc : matchingRules) {
			Rule r = rc.getRule();
			if (r.getOutcome() != null && r.getOutcome().trim().length() > 0 && actionsMap.containsKey(r.getOutcome().trim())) {
				IAction<Input, Output> action = actionsMap.get(r.getOutcome());
				action.afterCondition(rc, input, true);
				executedOutcomes.add(r.getOutcome());
			}
		}
	}

	public <Input, Output> boolean executeAction(String nameSpacePattern, Input input, IAction<Input, Output> action, Map<String, Object> varsini)
			throws NoActionFoundException {

		CompiledRule rc = rulesMap.get(nameSpacePattern);
		if (rc != null) {
			Map<String, Object> vars = generateVars(input);
			varsini.forEach((k, v) -> {
				vars.put(k, v);
			});
			
			boolean matchRule = action.evaluateCondition(rc, input, vars);
			if (matchRule) {
				//log.info("Regla cumple Condicion: " + rc.getRule().getFullyQualifiedName() + " Path: " + rc.getRule().getPath());
				Object o = MVEL.executeExpression(rc.getCompiled(), vars);
				if (String.valueOf(o).equals("true")) {
					action.afterCondition(rc, input, true);
				} else {
					//log.info("Regla no cumple Condicion: " + rc.getRule().getFullyQualifiedName() + " Path: " + rc.getRule().getPath()+ " Cond: " + rc.getRule().getExpression());
				}
				
			} else {
				log.info("Regla no cumple Condicion: " + rc.getRule().getFullyQualifiedName() + " Path: " + rc.getRule().getPath());
			}
			return matchRule;
		} else {
			throw new NoActionFoundException("No action has been associated with the nameSpacePattern \"" + nameSpacePattern + "\" rulesMap size: " + rulesMap.size());
		}
	}

	public static <Input, Output> Map<String, IAction<Input, Output>> validateActions(Collection<? extends IAction<Input, Output>> actions,
			Set<String> uniqueOutcomes, Map<String, Object> statics) throws DuplicateNameException, NoActionFoundException {
		// do any actions have duplicate names?
		Map<String, IAction<Input, Output>> actionsMap = new HashMap<String, IAction<Input, Output>>();

		for (IAction<Input, Output> a : actions) {
			if (actionsMap.containsKey(a.getName())) {
				throw new DuplicateNameException("The name " + a.getName() + " was found in a different action.  Action names must be unique.");
			} else {
				// a.addDomainsVars(statics);
				actionsMap.put(a.getName(), a);
			}
		}

		for (String outcome : uniqueOutcomes) {
			if (outcome != null && !outcome.isEmpty() && !actionsMap.containsKey(outcome)) {
				throw new NoActionFoundException("No action has been associated with the outcome \"" + outcome + "\"");
			}
		}

		return actionsMap;
	}

	protected <Input> List<Rule> getMatchingRules(String nameSpacePattern, Map<String, Object> vars) {
		List<Rule> matchingRules = getMatchingCompiledRules(nameSpacePattern, vars).stream().map(r -> r.getRule()).collect(Collectors.toList());
		// order by priority!
		Collections.sort(matchingRules);

		return matchingRules;
	}

	public <Input> List<CompiledRule> executeAllCondicions(String nameSpacePattern, Input input, Map<String, Object> varsini)
			throws NoActionFoundException, DuplicateNameException {

		Map<String, Object> vars = generateVars(input);
		varsini.forEach((k, v) -> {
			vars.putIfAbsent(k, v);
		});

		List<CompiledRule> matchingRules = getMatchingCompiledRules(nameSpacePattern, vars);
		return matchingRules;
	}

	protected List<CompiledRule> getMatchingCompiledRules(String nameSpacePattern, Map<String, Object> vars) {

		Pattern pattern = null;
		if (nameSpacePattern != null) {
			pattern = Pattern.compile(nameSpacePattern);
		}

		List<CompiledRule> matchingRules = new ArrayList<CompiledRule>();
		for (CompiledRule r : rules) {
//			System.out.println("rr " + r.getRule().getFullyQualifiedName());
			if (pattern != null) {
				if (!pattern.matcher(r.getRule().getNamespace()).matches()) {
					continue;
				}
			}

			Object o = MVEL.executeExpression(r.getCompiled(), vars);
			if (String.valueOf(o).equals("true")) {
				matchingRules.add(r);
			}
		}

		return matchingRules;
	}

	public <Input, Output> Map<String, Object> generateVars(Input input) {
		Map<String, Object> vars = new HashMap<String, Object>(statics); // initialise with static stuff
		if (input != null)
			vars.put(inputName, input);
		return vars;
	}

	public Engine addFacts(Map<String, Object> vars) {
		// Map<String, Object> vars = new HashMap<String, Object>(statics); //
		// initialise with static stuff
		vars.forEach((k, v) -> {
			statics.putIfAbsent(k, v);
		});
		return this;
	}

	public Engine addMethod(Class clazz) {
		for (Method method : clazz.getDeclaredMethods()) {
			addMethod(method.getName(), method);
		}
		return this;
	}

	public Engine addMethod(String nameMethod, Method method) {
		if (!method.getName().contains("$")) {
			statics.putIfAbsent(nameMethod, method);
		}
		return this;
	}

	public Engine addAction(IAction action) {
		Optional<IAction> found = actions.stream().filter(m -> m.getName().equalsIgnoreCase(action.getName())).findFirst();
		if (!found.isPresent())
			actions.add(action);
		return this;
	}

	public Map<String, Object> getStatics() {
		return statics;
	}

	public Map<String, CompiledRule> getRulesMap() {
		return rulesMap;
	}
}
