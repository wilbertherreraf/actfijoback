package gob.bcb.iso20022.swift.parser;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.prowidesoftware.deprecation.DeprecationUtils;
import com.prowidesoftware.deprecation.DeprecationUtils.EnvironmentVariableKey;
import com.prowidesoftware.swift.model.AbstractMessage;
import com.prowidesoftware.swift.model.AbstractSwiftMessage;

import gob.bcb.iso20022.dao.SwfMencamposIsoDao;
import gob.bcb.iso20022.lau.AuthParameters;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.Block4;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.saa.DataPDUWriter;

public abstract class SwiftMessageAbstract implements SwiftMessageBcb {
	public static final String IDMSG_MX = "./PmtId/InstrId";
	public static final String IDMSG_HDR_MX = "./GrpHdr/MsgId";

	private String menPlano;
	private String payLoad;	
	private final String menPlanoOrig;	
	private String typeMessage;
	private DataPDUWriter dPDUWriter = new DataPDUWriter();
	private AbstractSwiftMessage msg;
	private AbstractMessage absMsg;
	private FileFormat fileFormat;
	private final List<Block4> block4 = new ArrayList<>();
	private final SwfMsgParam swfMsgParam = new SwfMsgParam();
	private SwfMencamposIsoDao swfMencamposDao;
	
	public SwiftMessageAbstract() {
		this.menPlanoOrig = null;
	}
	
//	public SwiftMessageAbstract(String typeMessage, FileFormat fileFormat) {
//		this.typeMessage = typeMessage;
//		this.fileFormat = fileFormat;
//	}
//
	public SwiftMessageAbstract(final String swiftPlano) {
		this.menPlanoOrig = swiftPlano;
	}

	public String fromMsg() {
		return absMsg != null ? absMsg.message() : null;
	}

	public String getIdentifier() {
		return msg != null ? msg.getIdentifier() : null;
	}

	public String getSender() {
		return msg != null ? msg.getSender() : null;
	}

	public String getReceiver() {
		return msg != null ? msg.getReceiver() : null;
	}

	public String getReference() {
		return msg != null ? msg.getReference() : null;
	}

	public Boolean isOutgoing() {
		return msg != null ? msg.isOutgoing() : null;
	}

	public String messageType() {
		return msg != null ? msg.getMessageType() : null;
	}

	public boolean isMx() {
		return absMsg != null && absMsg.isMX();
	}

	public boolean isMt() {
		return absMsg != null && absMsg.isMT();
	}

	public FileFormat messageStandardType() {
		if (isMx()) {
			return FileFormat.MX;
		} else if (isMt()) {
			return FileFormat.MT;
		}
		return null;
	}

	public String getProperty(String key) {
		return msg != null ? msg.getProperty(key) : null;
	}

	public List<Block4> getBlock4() {
		return block4;
	}

	public String getMenPlano() {
		return menPlano;
	}

	public SwiftMessageAbstract updInstrId(String key, String value) {
		if (StringUtils.isBlank(value)) {
			throw new RuntimeException("Valor a actualizar IDMSG nulo");
		}

		if (isMt()) {
			updInstrId2(key, value);
		} else if (isMx()) {
			updInstrId2(IDMSG_MX, value);
			updInstrId2(IDMSG_HDR_MX, value);
		}
		return this;
	}
	
	public SwiftMessageAbstract extractMetadata() {
		extractMetadataHdr();
		return this;
	};

	public abstract String checkSum();

	public abstract SwiftMessageAbstract createBlock4();
	public abstract SwiftMessageAbstract createBlock4Long();
	public abstract void addBlockLAU(AuthParameters authParameters);
	public abstract String getTagCodeLau();
	public abstract SwiftMessageAbstract updMsgForSign();
//	public abstract AbstractMessage abstractMessage();
	public abstract SwiftMessageAbstract createMsg();
	public abstract SwiftMessageAbstract updInstrId2(String key, String value);
	public abstract SwiftMessageAbstract extractMetadataHdr();
	public abstract SwiftMessageAbstract extractMetadataBody();
	public abstract boolean isValidMsg(boolean genError);
	public abstract List<String> validateSyntax() throws Exception;
	public abstract String valueSignatureLau();
	public void settConfig() {
		DeprecationUtils.setEnv(EnvironmentVariableKey.NODELAY);
		DeprecationUtils.setEnv(EnvironmentVariableKey.NOLOG);
		DeprecationUtils.setEnv(EnvironmentVariableKey.NOEXCEPTION);
	}

	public String getTypeMessage() {
		return typeMessage;
	}

	public SwiftMessageAbstract typeMessage(String typeMessage) {
		this.typeMessage = typeMessage;
		return this;
	}

	public void setTypeMessage(String typeMessage) {
		this.typeMessage = typeMessage;
	}

	public AbstractMessage getAbsMsg() {
		return absMsg;
	}

	public void setAbsMsg(AbstractMessage absMsg) {
		this.absMsg = absMsg;
	}

	public AbstractSwiftMessage getMsg() {
		return msg;
	}

	public void setMsg(AbstractSwiftMessage msg) {
		this.msg = msg;
	}

	public FileFormat getFileFormat() {
		return fileFormat;
	}

	public SwiftMessageAbstract fileFormat(FileFormat fileFormat) {
		this.fileFormat = fileFormat;
		return this;
	}

	public SwfMsgParam getSwfMsgParam() {
		return swfMsgParam;
	}

	public void setMenPlano(String menPlano) {
		this.menPlano = menPlano;
	}

	public String getMenPlanoOrig() {
		return menPlanoOrig;
	}

//	public void setMenPlanoOrig(final String menPlanoOrig) {
//		this.menPlanoOrig = menPlanoOrig;
//	}
//
	public DataPDUWriter getdPDUWriter() {
		return dPDUWriter;
	}

	public void setdPDUWriter(DataPDUWriter dPDUWriter) {
		this.dPDUWriter = dPDUWriter;
	}

	public String getPayLoad() {
		return payLoad;
	}

	public void setPayLoad(String payLoad) {
		this.payLoad = payLoad;
	}

	public SwfMencamposIsoDao getSwfMencamposDao() {
		return swfMencamposDao;
	}

	public void setSwfMencamposDao(SwfMencamposIsoDao swfMencamposDao) {
		this.swfMencamposDao = swfMencamposDao;
	}
}
