package gob.bcb.iso20022.excel.utils;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

public class CommonFileUtils {

    /**
     *
     * @param path
     * @return
     */
    public static FileOutputStream getFileOutputStream(String path) {
        if (checkPath(path)) {
            throw new IllegalArgumentException(String.format("file path %s is not legal", path));
        }

        try {
            File file = new File(path);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            return fileOutputStream;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    /**
     *
     * @param path
     * @return
     */
    public static FileInputStream getFileInputStream(String path) {
        if (checkPath(path)) {
            throw new IllegalArgumentException(String.format("file path %s is not legal", path));
        }
        FileInputStream fileInputStream = null;

        try {
            fileInputStream = new FileInputStream(path);
            return fileInputStream;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }


    /**
     *
     * @param path
     * @return
     */
    public static Reader getFileReader(String path) {
        if (checkPath(path)) {
            throw new IllegalArgumentException(String.format("file path %s is not legal", path));
        }
        Reader reader = null;
        try {
            reader = new FileReader(path);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException(e);            
        }

        return reader;
    }

    public static Reader getFileReader(InputStream initialStream) {
        if (initialStream == null) {
            throw new IllegalArgumentException(String.format("initialStream is not legal"));
        }
        Reader reader = new InputStreamReader(initialStream);

        return reader;
    }    
    /**
     *
     * @param inputStream
     */
    public static void closeInputStream(InputStream inputStream) {
        if (!Objects.isNull(inputStream)) {
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     *
     * @param outputStream
     */
    public static void closeOutputStream(OutputStream outputStream) {
        if (!Objects.isNull(outputStream)) {
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param Reader
     */
    public static void closeReader(Reader reader) {
        if (!Objects.isNull(reader)) {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    private static boolean checkPath(String path) {
        return StringUtils.isEmpty(path);
    }
}
