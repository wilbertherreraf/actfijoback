
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para IntvCategory.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="IntvCategory"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="TransmissionReport"/&gt;
 *     &lt;enumeration value="DeliveryReport"/&gt;
 *     &lt;enumeration value="TransmissionResponse"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "IntvCategory")
@XmlEnum
public enum IntvCategory {

    @XmlEnumValue("TransmissionReport")
    TRANSMISSION_REPORT("TransmissionReport"),
    @XmlEnumValue("DeliveryReport")
    DELIVERY_REPORT("DeliveryReport"),
    @XmlEnumValue("TransmissionResponse")
    TRANSMISSION_RESPONSE("TransmissionResponse");
    private final String value;

    IntvCategory(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static IntvCategory fromValue(String v) {
        for (IntvCategory c: IntvCategory.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
