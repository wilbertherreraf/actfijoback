package gob.bcb.iso20022.excel.exception;

/**
 * @description excel manipulation exception
 */
public class ExcelManipulationException extends RuntimeException{
    public ExcelManipulationException() {
        super();
    }

    public ExcelManipulationException(String message) {
        super(message);
    }

    public ExcelManipulationException(String message, Throwable cause) {
        super(message, cause);
    }
}
