package gob.bcb.iso20022.swift.parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.mt.AbstractMT;

import gob.bcb.iso20022.exceptions.DataValidationSwitfException;
import gob.bcb.iso20022.lau.AuthParameters;
import gob.bcb.iso20022.lau.LAU;
import gob.bcb.iso20022.pojo.Block4;
import gob.bcb.iso20022.swift.FileFormat;

public class SwiftMessageMT extends SwiftMessageAbstract {
	private final static Logger log = LoggerFactory.getLogger(SwiftMessageMT.class);

	public static final String SWIFT_EOL = "\r\n";
	static final Locale locale = new Locale("es");
	private MtSwiftMessage swiftMessage;

	public SwiftMessageMT() {
	}

	public SwiftMessageMT(String swiftPlano) {
		super(swiftPlano);
	}

	public SwiftMessageAbstract createMsg() {
		if (StringUtils.isBlank(getMenPlanoOrig())) {
			throw new DataValidationSwitfException("Mensaje origen nulo, requerido para generar MT");
		}
		
		try {
			AbstractMT mt = AbstractMT.parse(getMenPlanoOrig());
			setAbsMsg(mt);
			swiftMessage = new MtSwiftMessage(mt);
			setMsg(swiftMessage);
			setTypeMessage(mt.getMessageType());
			getSwfMsgParam().setMenFormato(FileFormat.MT.toString());
			setMenPlano(mt.message());
			setPayLoad(getMenPlano());
			getSwfMsgParam().setMenHash(mt.getSignature());
			
			if (StringUtils.isBlank(getMenPlano())) {
				throw new DataValidationSwitfException("No se pudo crear mensaje Swift MT ");
			}
			//log.info("Mensaje con LAU " + getSwfMsgParam().getMenHash());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return this;
	}

	public SwiftMessageAbstract createBlock4() {
		createBlock4Long(false);
		return this;
	}

	public SwiftMessageAbstract createBlock4Long(boolean addAdics) {
		List<Block4> block4Lista = new ArrayList<>();
		AbstractMT mt = (AbstractMT) getAbsMsg();
		if (mt == null) {
			return this;
		}

		SwiftBlock4 b4 = mt.getSwiftMessage().getBlock4();

		if (b4 != null && !b4.isEmpty()) {
			for (Tag t : b4.getTags()) {
				final Field field = t.asField();
				Block4 block4 = new Block4();
				block4.setName(field.getName());
				block4.setValue(t.getValue());
				if (addAdics) {
					block4.setNameShort(field.getName());
					//String v = getDescripField(field);
					block4.setValueDescrip(field.getValueDisplay());
					block4.setReference(Field.getLabel(field.getName(), mt.getMessageType(), null));
				}
				block4Lista.add(block4);
			}
		}

		getBlock4().clear();
		getBlock4().addAll(block4Lista);
		return this;
	}

	public SwiftMessageAbstract extractMetadataHdr() {
		AbstractMT mt = (AbstractMT) getAbsMsg();
		if (mt == null) {
			return this;
		}
		SwiftMessage swiftMessage = mt.getSwiftMessage();

		getSwfMsgParam().setMenEmisor(swiftMessage.getSender());
		getSwfMsgParam().setMenReceiver(swiftMessage.getReceiver());
		getSwfMsgParam().setMenTypemessage(mt.getMessageType());
		getSwfMsgParam().setMenIdTMessageTx(mt.getMessageType());

		extractMetadataBody();
		return this;
	}

	public SwiftMessageAbstract extractMetadataBody() {
		AbstractMT mt = (AbstractMT) getAbsMsg();
		if (mt == null) {
			return this;
		}

		SwiftBlock4 b4 = mt.getSwiftMessage().getBlock4();
		int ftags = 0;
		if (b4 != null && !b4.isEmpty()) {
			for (Tag t : b4.getTags()) {
				final Field field = t.asField();
				if (field.getName().startsWith("20")) {
					getSwfMsgParam().setMenCodswift(field.getValue());
					ftags++;
				} else if (field.getName().equals("32A")) {
					Field32A f = new Field32A(t);
					getSwfMsgParam().setMenCodmon(f.getCurrency());
					ftags++;
				}
				if (ftags >= 2)
					break;
			}
		}

		return this;
	}

	public SwiftMessageAbstract updMsgForSign() {
		if (StringUtils.isBlank(getMenPlanoOrig())) {
			throw new RuntimeException("Pre tarea de firma mensaje MT nulo");
		}
		AbstractMT mt = (AbstractMT) getAbsMsg();
		SwiftMessage swiftMsg = mt.getSwiftMessage();

		SwiftMessage copy = new SwiftMessage();
		copy.setBlock1(swiftMsg.getBlock1());
		copy.setBlock2(swiftMsg.getBlock2());
		copy.setBlock3(swiftMsg.getBlock3());
		copy.setBlock4(swiftMsg.getBlock4());
		
		AbstractMT mtNew = copy.toMT();
		setAbsMsg(mtNew);
		setMenPlano(mtNew.message());
		setPayLoad(getMenPlano());
		return this;
	}

	public void addBlockLAU(AuthParameters authParameters) {
		LAU signer = new LAU();
		signer.setSecretKey(authParameters.getKey());
		String codeLau = signer.sign(getPayLoad());
		AbstractMT mtNew = (AbstractMT) getAbsMsg();
		mtNew.setSignature(codeLau);
		setAbsMsg(mtNew);
		setMenPlano(mtNew.message());
		getSwfMsgParam().setMenHash(codeLau);
		log.info("MX actualizado con firma ... hecho!! con mac: " + codeLau);
	}

	public String valueSignatureLau() {
		String lau = getTagCodeLau();
		return lau;
	}
	public String getTagCodeLau() {
		if (getAbsMsg() != null) {
			AbstractMT mtNew = (AbstractMT) getAbsMsg();
			return mtNew.getSwiftMessage() != null ? mtNew.getSwiftMessage().getSignature() : null;
		}
		return null;
	}

	public String checkSum() {
		return getMsg().getChecksum();
	}

	public static final int MINIMAL_TAGS = 3;

	public SwiftMessageAbstract updInstrId2(String key, String value) {
		if (StringUtils.isBlank(key) || StringUtils.isBlank(value)) {
			throw new RuntimeException("Actualizar campo [" + key + "] o valor nulo " + value);
		}
		if (getAbsMsg() == null) {
			throw new RuntimeException("Actualizar campo[" + key + "] : Objeto mensaje nulo");
		}

		AbstractMT mt;
		try {
			mt = AbstractMT.parse(getMenPlano());
		} catch (IOException e) {
			throw new RuntimeException("Actualizar campo: " + e.getMessage(), e);
		}

		SwiftMessage swiftMsg = mt.getSwiftMessage();
		SwiftBlock4 b4 = swiftMsg.getBlock4();

		Tag t = b4.getTagByName(key);
		if (t != null) {
			b4.getTagByName(key).setValue(value);
		} else {
			Tag tn = new Tag();
			tn.setName(key);
			tn.setValue(value);
			b4.append(tn);

		}

		AbstractMT mtNew = swiftMsg.toMT();
		setMenPlano(mtNew.message());
		setAbsMsg(mtNew);
		return this;
	}

	public boolean isValidMsg(boolean genError) {
		boolean valid = true;
		if (StringUtils.isBlank(getMenPlano())) {
			if (genError)
				throw new DataValidationSwitfException("Mensaje plano nulo");
			return false;
		}

		try {
			AbstractMT mt = AbstractMT.parse(getMenPlano());

			SwiftMessage swiftMessage = mt.getSwiftMessage();
			int nBlocks = swiftMessage.getBlockCount(false);

			if (nBlocks <= 3) {
				if (genError)
					throw new DataValidationSwitfException("Numero de Bloques MT insuficiente");
				return false;
			}

			if (swiftMessage.getBlock4() == null || swiftMessage.getBlock4().isEmpty() || swiftMessage.getBlock4().countAll() < MINIMAL_TAGS) {
				if (genError)
					throw new DataValidationSwitfException("Bloque 4 invalido, sin elementos minimos requeridos " + MINIMAL_TAGS);
				return false;
			}

		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return valid;
	}

	public List<String> validateSyntax() throws Exception {
		return new ArrayList<>();
	}

	public SwiftMessageAbstract createBlock4Long() {
		return createBlock4Long(true);
	}
}
