
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para FINNetworkInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="FINNetworkInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UserPriority" type="{urn:swift:saa:xsd:saa.2.0}UserPriority" minOccurs="0"/&gt;
 *         &lt;element name="CopyService" type="{urn:swift:saa:xsd:saa.2.0}CopyService" minOccurs="0"/&gt;
 *         &lt;element name="CopyCID" type="{urn:swift:saa:xsd:saa.2.0}BIC8" minOccurs="0"/&gt;
 *         &lt;element name="MessageSyntaxVersion" type="{urn:swift:saa:xsd:saa.2.0}MessageSyntaxVersion" minOccurs="0"/&gt;
 *         &lt;element name="IsRetrieved" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="ReleaseInfo" type="{urn:swift:saa:xsd:saa.2.0}ReleaseInfo" minOccurs="0"/&gt;
 *         &lt;element name="ValidationIdentifier" type="{urn:swift:saa:xsd:saa.2.0}ValidationIdentifier" minOccurs="0"/&gt;
 *         &lt;element name="CorrespondentInputReference" type="{urn:swift:saa:xsd:saa.2.0}CorrespondentInputReference" minOccurs="0"/&gt;
 *         &lt;element name="CorrespondentInputTime" type="{urn:swift:saa:xsd:saa.2.0}TimeString" minOccurs="0"/&gt;
 *         &lt;element name="LocalOutputTime" type="{urn:swift:saa:xsd:saa.2.0}TimeString" minOccurs="0"/&gt;
 *         &lt;element name="SystemOriginated" type="{urn:swift:saa:xsd:saa.2.0}FINTrailer" minOccurs="0"/&gt;
 *         &lt;element name="DelayedMessage" type="{urn:swift:saa:xsd:saa.2.0}FINTrailer" minOccurs="0"/&gt;
 *         &lt;element name="FINUserHeader" type="{urn:swift:saa:xsd:saa.2.0}FINUserHeader" minOccurs="0"/&gt;
 *         &lt;element name="ServiceLevelAgreement" type="{urn:swift:saa:xsd:saa.2.0}ServiceLevelAgreement" minOccurs="0"/&gt;
 *         &lt;element name="E2ETransactionReference" type="{urn:swift:saa:xsd:saa.2.0}E2ETransactionReference" minOccurs="0"/&gt;
 *         &lt;element name="FinInformReleaseInfo" type="{urn:swift:saa:xsd:saa.2.0}FinInformReleaseInfo" minOccurs="0"/&gt;
 *         &lt;element name="PCInfoForReceiver" type="{urn:swift:saa:xsd:saa.2.0}PCInfoForReceiver" minOccurs="0"/&gt;
 *         &lt;element name="TranslatedResult" type="{urn:swift:saa:xsd:saa.2.0}TranslatedResult" minOccurs="0"/&gt;
 *         &lt;element name="TranslationResultDetails" type="{urn:swift:saa:xsd:saa.2.0}TranslationResultDetails" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FINNetworkInfo", propOrder = {
    "userPriority",
    "copyService",
    "copyCID",
    "messageSyntaxVersion",
    "isRetrieved",
    "releaseInfo",
    "validationIdentifier",
    "correspondentInputReference",
    "correspondentInputTime",
    "localOutputTime",
    "systemOriginated",
    "delayedMessage",
    "finUserHeader",
    "serviceLevelAgreement",
    "e2ETransactionReference",
    "finInformReleaseInfo",
    "pcInfoForReceiver",
    "translatedResult",
    "translationResultDetails"
})
public class FINNetworkInfo {

    @XmlElement(name = "UserPriority")
    protected String userPriority;
    @XmlElement(name = "CopyService")
    protected String copyService;
    @XmlElement(name = "CopyCID")
    protected String copyCID;
    @XmlElement(name = "MessageSyntaxVersion")
    protected String messageSyntaxVersion;
    @XmlElement(name = "IsRetrieved")
    protected Boolean isRetrieved;
    @XmlElement(name = "ReleaseInfo")
    protected String releaseInfo;
    @XmlElement(name = "ValidationIdentifier")
    protected String validationIdentifier;
    @XmlElement(name = "CorrespondentInputReference")
    protected String correspondentInputReference;
    @XmlElement(name = "CorrespondentInputTime")
    protected String correspondentInputTime;
    @XmlElement(name = "LocalOutputTime")
    protected String localOutputTime;
    @XmlElement(name = "SystemOriginated")
    protected String systemOriginated;
    @XmlElement(name = "DelayedMessage")
    protected String delayedMessage;
    @XmlElement(name = "FINUserHeader")
    protected String finUserHeader;
    @XmlElement(name = "ServiceLevelAgreement")
    protected String serviceLevelAgreement;
    @XmlElement(name = "E2ETransactionReference")
    protected String e2ETransactionReference;
    @XmlElement(name = "FinInformReleaseInfo")
    protected String finInformReleaseInfo;
    @XmlElement(name = "PCInfoForReceiver")
    protected String pcInfoForReceiver;
    @XmlElement(name = "TranslatedResult")
    @XmlSchemaType(name = "string")
    protected TranslatedResult translatedResult;
    @XmlElement(name = "TranslationResultDetails")
    protected String translationResultDetails;

    /**
     * Obtiene el valor de la propiedad userPriority.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserPriority() {
        return userPriority;
    }

    /**
     * Define el valor de la propiedad userPriority.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserPriority(String value) {
        this.userPriority = value;
    }

    /**
     * Obtiene el valor de la propiedad copyService.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCopyService() {
        return copyService;
    }

    /**
     * Define el valor de la propiedad copyService.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCopyService(String value) {
        this.copyService = value;
    }

    /**
     * Obtiene el valor de la propiedad copyCID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCopyCID() {
        return copyCID;
    }

    /**
     * Define el valor de la propiedad copyCID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCopyCID(String value) {
        this.copyCID = value;
    }

    /**
     * Obtiene el valor de la propiedad messageSyntaxVersion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageSyntaxVersion() {
        return messageSyntaxVersion;
    }

    /**
     * Define el valor de la propiedad messageSyntaxVersion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageSyntaxVersion(String value) {
        this.messageSyntaxVersion = value;
    }

    /**
     * Obtiene el valor de la propiedad isRetrieved.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsRetrieved() {
        return isRetrieved;
    }

    /**
     * Define el valor de la propiedad isRetrieved.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsRetrieved(Boolean value) {
        this.isRetrieved = value;
    }

    /**
     * Obtiene el valor de la propiedad releaseInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReleaseInfo() {
        return releaseInfo;
    }

    /**
     * Define el valor de la propiedad releaseInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReleaseInfo(String value) {
        this.releaseInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad validationIdentifier.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidationIdentifier() {
        return validationIdentifier;
    }

    /**
     * Define el valor de la propiedad validationIdentifier.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidationIdentifier(String value) {
        this.validationIdentifier = value;
    }

    /**
     * Obtiene el valor de la propiedad correspondentInputReference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrespondentInputReference() {
        return correspondentInputReference;
    }

    /**
     * Define el valor de la propiedad correspondentInputReference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrespondentInputReference(String value) {
        this.correspondentInputReference = value;
    }

    /**
     * Obtiene el valor de la propiedad correspondentInputTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrespondentInputTime() {
        return correspondentInputTime;
    }

    /**
     * Define el valor de la propiedad correspondentInputTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrespondentInputTime(String value) {
        this.correspondentInputTime = value;
    }

    /**
     * Obtiene el valor de la propiedad localOutputTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalOutputTime() {
        return localOutputTime;
    }

    /**
     * Define el valor de la propiedad localOutputTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalOutputTime(String value) {
        this.localOutputTime = value;
    }

    /**
     * Obtiene el valor de la propiedad systemOriginated.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemOriginated() {
        return systemOriginated;
    }

    /**
     * Define el valor de la propiedad systemOriginated.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemOriginated(String value) {
        this.systemOriginated = value;
    }

    /**
     * Obtiene el valor de la propiedad delayedMessage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelayedMessage() {
        return delayedMessage;
    }

    /**
     * Define el valor de la propiedad delayedMessage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelayedMessage(String value) {
        this.delayedMessage = value;
    }

    /**
     * Obtiene el valor de la propiedad finUserHeader.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFINUserHeader() {
        return finUserHeader;
    }

    /**
     * Define el valor de la propiedad finUserHeader.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFINUserHeader(String value) {
        this.finUserHeader = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceLevelAgreement.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceLevelAgreement() {
        return serviceLevelAgreement;
    }

    /**
     * Define el valor de la propiedad serviceLevelAgreement.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceLevelAgreement(String value) {
        this.serviceLevelAgreement = value;
    }

    /**
     * Obtiene el valor de la propiedad e2ETransactionReference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getE2ETransactionReference() {
        return e2ETransactionReference;
    }

    /**
     * Define el valor de la propiedad e2ETransactionReference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setE2ETransactionReference(String value) {
        this.e2ETransactionReference = value;
    }

    /**
     * Obtiene el valor de la propiedad finInformReleaseInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinInformReleaseInfo() {
        return finInformReleaseInfo;
    }

    /**
     * Define el valor de la propiedad finInformReleaseInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinInformReleaseInfo(String value) {
        this.finInformReleaseInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad pcInfoForReceiver.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPCInfoForReceiver() {
        return pcInfoForReceiver;
    }

    /**
     * Define el valor de la propiedad pcInfoForReceiver.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPCInfoForReceiver(String value) {
        this.pcInfoForReceiver = value;
    }

    /**
     * Obtiene el valor de la propiedad translatedResult.
     * 
     * @return
     *     possible object is
     *     {@link TranslatedResult }
     *     
     */
    public TranslatedResult getTranslatedResult() {
        return translatedResult;
    }

    /**
     * Define el valor de la propiedad translatedResult.
     * 
     * @param value
     *     allowed object is
     *     {@link TranslatedResult }
     *     
     */
    public void setTranslatedResult(TranslatedResult value) {
        this.translatedResult = value;
    }

    /**
     * Obtiene el valor de la propiedad translationResultDetails.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranslationResultDetails() {
        return translationResultDetails;
    }

    /**
     * Define el valor de la propiedad translationResultDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranslationResultDetails(String value) {
        this.translationResultDetails = value;
    }

}
