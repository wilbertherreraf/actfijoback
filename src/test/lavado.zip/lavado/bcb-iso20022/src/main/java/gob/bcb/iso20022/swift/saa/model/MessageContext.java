
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para MessageContext.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="MessageContext"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Original"/&gt;
 *     &lt;enumeration value="Copy"/&gt;
 *     &lt;enumeration value="Report"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "MessageContext")
@XmlEnum
public enum MessageContext {

    @XmlEnumValue("Original")
    ORIGINAL("Original"),
    @XmlEnumValue("Copy")
    COPY("Copy"),
    @XmlEnumValue("Report")
    REPORT("Report");
    private final String value;

    MessageContext(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MessageContext fromValue(String v) {
        for (MessageContext c: MessageContext.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
