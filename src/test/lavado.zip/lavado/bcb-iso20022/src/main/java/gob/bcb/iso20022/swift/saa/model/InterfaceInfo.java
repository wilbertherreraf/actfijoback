
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para InterfaceInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="InterfaceInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UserReference" type="{urn:swift:saa:xsd:saa.2.0}UserReference" minOccurs="0"/&gt;
 *         &lt;element name="RoutingCode" type="{urn:swift:saa:xsd:saa.2.0}RoutingCode" minOccurs="0"/&gt;
 *         &lt;element name="ValidationLevel" type="{urn:swift:saa:xsd:saa.2.0}ValidationLevel" minOccurs="0"/&gt;
 *         &lt;element name="IsModificationAllowed" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RoutingInstruction" type="{urn:swift:saa:xsd:saa.2.0}RoutingInstruction" minOccurs="0"/&gt;
 *         &lt;element name="MessageCreator" type="{urn:swift:saa:xsd:saa.2.0}MessageCreator" minOccurs="0"/&gt;
 *         &lt;element name="MessageContext" type="{urn:swift:saa:xsd:saa.2.0}MessageContext" minOccurs="0"/&gt;
 *         &lt;element name="MessageNature" type="{urn:swift:saa:xsd:saa.2.0}MessageNature" minOccurs="0"/&gt;
 *         &lt;element name="ProductInfo" type="{urn:swift:saa:xsd:saa.2.0}ProductList" minOccurs="0"/&gt;
 *         &lt;element name="CustomDigestValue" type="{urn:swift:saa:xsd:saa.2.0}CustomDigestValue" minOccurs="0"/&gt;
 *         &lt;element name="Sumid" type="{urn:swift:saa:xsd:saa.2.0}Sumid" minOccurs="0"/&gt;
 *         &lt;element name="ServiceURI" type="{urn:swift:saa:xsd:saa.2.0}MessageURI" minOccurs="0"/&gt;
 *         &lt;element name="MessageTypeURI" type="{urn:swift:saa:xsd:saa.2.0}MessageURI" minOccurs="0"/&gt;
 *         &lt;element name="MessageProperties" type="{urn:swift:saa:xsd:saa.2.0}MessagePropertyList" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InterfaceInfo", propOrder = {
    "userReference",
    "routingCode",
    "validationLevel",
    "isModificationAllowed",
    "routingInstruction",
    "messageCreator",
    "messageContext",
    "messageNature",
    "productInfo",
    "customDigestValue",
    "sumid",
    "serviceURI",
    "messageTypeURI",
    "messageProperties"
})
public class InterfaceInfo {

    @XmlElement(name = "UserReference")
    protected String userReference;
    @XmlElement(name = "RoutingCode")
    protected String routingCode;
    @XmlElement(name = "ValidationLevel")
    @XmlSchemaType(name = "string")
    protected ValidationLevel validationLevel;
    @XmlElement(name = "IsModificationAllowed")
    protected Boolean isModificationAllowed;
    @XmlElement(name = "RoutingInstruction")
    protected RoutingInstruction routingInstruction;
    @XmlElement(name = "MessageCreator")
    @XmlSchemaType(name = "string")
    protected MessageCreator messageCreator;
    @XmlElement(name = "MessageContext")
    @XmlSchemaType(name = "string")
    protected MessageContext messageContext;
    @XmlElement(name = "MessageNature")
    @XmlSchemaType(name = "string")
    protected MessageNature messageNature;
    @XmlElement(name = "ProductInfo")
    protected ProductList productInfo;
    @XmlElement(name = "CustomDigestValue")
    protected String customDigestValue;
    @XmlElement(name = "Sumid")
    protected String sumid;
    @XmlElement(name = "ServiceURI")
    protected String serviceURI;
    @XmlElement(name = "MessageTypeURI")
    protected String messageTypeURI;
    @XmlElement(name = "MessageProperties")
    protected MessagePropertyList messageProperties;

    /**
     * Obtiene el valor de la propiedad userReference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserReference() {
        return userReference;
    }

    /**
     * Define el valor de la propiedad userReference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserReference(String value) {
        this.userReference = value;
    }

    /**
     * Obtiene el valor de la propiedad routingCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoutingCode() {
        return routingCode;
    }

    /**
     * Define el valor de la propiedad routingCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoutingCode(String value) {
        this.routingCode = value;
    }

    /**
     * Obtiene el valor de la propiedad validationLevel.
     * 
     * @return
     *     possible object is
     *     {@link ValidationLevel }
     *     
     */
    public ValidationLevel getValidationLevel() {
        return validationLevel;
    }

    /**
     * Define el valor de la propiedad validationLevel.
     * 
     * @param value
     *     allowed object is
     *     {@link ValidationLevel }
     *     
     */
    public void setValidationLevel(ValidationLevel value) {
        this.validationLevel = value;
    }

    /**
     * Obtiene el valor de la propiedad isModificationAllowed.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsModificationAllowed() {
        return isModificationAllowed;
    }

    /**
     * Define el valor de la propiedad isModificationAllowed.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsModificationAllowed(Boolean value) {
        this.isModificationAllowed = value;
    }

    /**
     * Obtiene el valor de la propiedad routingInstruction.
     * 
     * @return
     *     possible object is
     *     {@link RoutingInstruction }
     *     
     */
    public RoutingInstruction getRoutingInstruction() {
        return routingInstruction;
    }

    /**
     * Define el valor de la propiedad routingInstruction.
     * 
     * @param value
     *     allowed object is
     *     {@link RoutingInstruction }
     *     
     */
    public void setRoutingInstruction(RoutingInstruction value) {
        this.routingInstruction = value;
    }

    /**
     * Obtiene el valor de la propiedad messageCreator.
     * 
     * @return
     *     possible object is
     *     {@link MessageCreator }
     *     
     */
    public MessageCreator getMessageCreator() {
        return messageCreator;
    }

    /**
     * Define el valor de la propiedad messageCreator.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageCreator }
     *     
     */
    public void setMessageCreator(MessageCreator value) {
        this.messageCreator = value;
    }

    /**
     * Obtiene el valor de la propiedad messageContext.
     * 
     * @return
     *     possible object is
     *     {@link MessageContext }
     *     
     */
    public MessageContext getMessageContext() {
        return messageContext;
    }

    /**
     * Define el valor de la propiedad messageContext.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageContext }
     *     
     */
    public void setMessageContext(MessageContext value) {
        this.messageContext = value;
    }

    /**
     * Obtiene el valor de la propiedad messageNature.
     * 
     * @return
     *     possible object is
     *     {@link MessageNature }
     *     
     */
    public MessageNature getMessageNature() {
        return messageNature;
    }

    /**
     * Define el valor de la propiedad messageNature.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageNature }
     *     
     */
    public void setMessageNature(MessageNature value) {
        this.messageNature = value;
    }

    /**
     * Obtiene el valor de la propiedad productInfo.
     * 
     * @return
     *     possible object is
     *     {@link ProductList }
     *     
     */
    public ProductList getProductInfo() {
        return productInfo;
    }

    /**
     * Define el valor de la propiedad productInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductList }
     *     
     */
    public void setProductInfo(ProductList value) {
        this.productInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad customDigestValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomDigestValue() {
        return customDigestValue;
    }

    /**
     * Define el valor de la propiedad customDigestValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomDigestValue(String value) {
        this.customDigestValue = value;
    }

    /**
     * Obtiene el valor de la propiedad sumid.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSumid() {
        return sumid;
    }

    /**
     * Define el valor de la propiedad sumid.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSumid(String value) {
        this.sumid = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceURI.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceURI() {
        return serviceURI;
    }

    /**
     * Define el valor de la propiedad serviceURI.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceURI(String value) {
        this.serviceURI = value;
    }

    /**
     * Obtiene el valor de la propiedad messageTypeURI.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageTypeURI() {
        return messageTypeURI;
    }

    /**
     * Define el valor de la propiedad messageTypeURI.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageTypeURI(String value) {
        this.messageTypeURI = value;
    }

    /**
     * Obtiene el valor de la propiedad messageProperties.
     * 
     * @return
     *     possible object is
     *     {@link MessagePropertyList }
     *     
     */
    public MessagePropertyList getMessageProperties() {
        return messageProperties;
    }

    /**
     * Define el valor de la propiedad messageProperties.
     * 
     * @param value
     *     allowed object is
     *     {@link MessagePropertyList }
     *     
     */
    public void setMessageProperties(MessagePropertyList value) {
        this.messageProperties = value;
    }

}
