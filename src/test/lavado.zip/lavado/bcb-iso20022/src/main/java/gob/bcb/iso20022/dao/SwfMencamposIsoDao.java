package gob.bcb.iso20022.dao;

import java.util.List;

import java.util.Optional;

import gob.bcb.iso20022.model.SwfMencampos;

public interface SwfMencamposIsoDao {
	List<SwfMencampos> opcionesDeCampo(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) ;

	Optional<SwfMencampos> nextGrpoptSwfMencampos(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfCodcampo, String mtfBloque) ;

	Optional<SwfMencampos> nextNroSwfMencampos(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) ;

	Optional<SwfMencampos> nextNroSwfMencampos(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque, Integer mtfNivel);
	
	List<SwfMencampos> findByMT(String mtfCodmt, String mtfBloque);
	List<SwfMencampos> findById(Integer mtfId);
	List<SwfMencampos> findByCodigoBlk(String mtfCodmt, String mtfCodcampo, Integer mtfNro, Integer mtfGrpopt, String mtfBloque);
	List<SwfMencampos> findByMtCampo(String mtfCodmt, String mtfCodcampo);
}
