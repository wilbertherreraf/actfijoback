package gob.bcb.iso20022.excel.component;

/**
 * common component interface
 */
public interface ExcelComponent<T, P> {
    T create(P p);
}
