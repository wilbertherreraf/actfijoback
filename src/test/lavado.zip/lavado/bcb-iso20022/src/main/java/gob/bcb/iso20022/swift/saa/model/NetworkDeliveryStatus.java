
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para NetworkDeliveryStatus.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="NetworkDeliveryStatus"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="NetworkAcked"/&gt;
 *     &lt;enumeration value="NetworkNacked"/&gt;
 *     &lt;enumeration value="NetworkRejectedLocally"/&gt;
 *     &lt;enumeration value="NetworkAborted"/&gt;
 *     &lt;enumeration value="NetworkTimedOut"/&gt;
 *     &lt;enumeration value="NetworkWaitingAck"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "NetworkDeliveryStatus")
@XmlEnum
public enum NetworkDeliveryStatus {

    @XmlEnumValue("NetworkAcked")
    NETWORK_ACKED("NetworkAcked"),
    @XmlEnumValue("NetworkNacked")
    NETWORK_NACKED("NetworkNacked"),
    @XmlEnumValue("NetworkRejectedLocally")
    NETWORK_REJECTED_LOCALLY("NetworkRejectedLocally"),
    @XmlEnumValue("NetworkAborted")
    NETWORK_ABORTED("NetworkAborted"),
    @XmlEnumValue("NetworkTimedOut")
    NETWORK_TIMED_OUT("NetworkTimedOut"),
    @XmlEnumValue("NetworkWaitingAck")
    NETWORK_WAITING_ACK("NetworkWaitingAck");
    private final String value;

    NetworkDeliveryStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static NetworkDeliveryStatus fromValue(String v) {
        for (NetworkDeliveryStatus c: NetworkDeliveryStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
