package gob.bcb.iso20022.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import gob.bcb.iso20022.swift.FileFormat;

/**
 * The persistent class for the swf_mensaje database table.
 * 
 */
public class SwfMsgParam  implements Serializable {
	private Integer menCodmen;
	private String menCodmenOrig;
	private String menIdoperacion;
	private Integer menNrocorr;
	private String menTypemessage;
	private String menIdTMessageTx;
	private FileFormat fileFormat;
	private String menNroswift;
	private String menPlano;
	private String menCodswift;
	private Integer menNrolote;
	private String menEmisor;
	private String emisorDescrip;
	private String menReceiver;
	private String receiverDescrip;
	private String menCodmon;
	private Integer menGestion;
	private String menCodmenrefer;
	private String menInout;
	private String menDestinatario;
	private String menCodusrswf;
	private Date menFecauto;
	private Date menFecreg;
	private Date menFecvalor;	
	private String menEstmensaje;
	private String menEstverifica;
	private String menEstautoriza;
	private String menUsrlvdverifica;
	private String menHash;
	private String menCodapp;
	private String menFirmaorigen;
	private String swiftfPlano;
	private String menFormato;
	private String menBic;
	private String menBiccodctrl;
	private String menBicbranch;
	private String menHdrversion;
	
	private String menFechoralit;	
	private String menCodusr;
	private String menPriority;
	private String userBlock;
	private String footer;
	private String auditwst;	
	private String auditusr;	
	private String auditfho;	
	private Boolean verifica = false;
	public SwfMsgParam() {
	}

	public Integer getMenCodmen() {
		return this.menCodmen;
	}

	public void setMenCodmen(Integer menCodmen) {
		this.menCodmen = menCodmen;
	}

	public String getMenNroswift() {
		return this.menNroswift;
	}

	public void setMenNroswift(String menNroswift) {
		this.menNroswift = menNroswift;
	}

	public String getMenPlano() {
		return this.menPlano;
	}

	public void setMenPlano(String menPlano) {
		this.menPlano = menPlano;
	}

	public String getMenCodswift() {
		return menCodswift;
	}

	public void setMenCodswift(String menCodswift) {
		this.menCodswift = menCodswift;
	}

	public Integer getMenNrolote() {
		return menNrolote;
	}

	public void setMenNrolote(Integer menNrolote) {
		this.menNrolote = menNrolote;
	}

	public String getMenEmisor() {
		return menEmisor;
	}

	public void setMenEmisor(String menEmisor) {
		this.menEmisor = menEmisor;
	}

	public String getMenCodmon() {
		return menCodmon;
	}

	public void setMenCodmon(String menCodmon) {
		this.menCodmon = menCodmon;
	}

	public String getMenDestinatario() {
		return menDestinatario;
	}

	public void setMenDestinatario(String menDestinatario) {
		this.menDestinatario = menDestinatario;
	}

	public Date getMenFecreg() {
		return menFecreg;
	}

	public void setMenFecreg(Date menFecreg) {
		this.menFecreg = menFecreg;
	}

	public Integer getMenNrocorr() {
		return menNrocorr;
	}

	public void setMenNrocorr(Integer menNrocorr) {
		this.menNrocorr = menNrocorr;
	}

	public Integer getMenGestion() {
		return menGestion;
	}

	public void setMenGestion(Integer menGestion) {
		this.menGestion = menGestion;
	}

	public String getMenBic() {
		return menBic;
	}

	public void setMenBic(String menBic) {
		this.menBic = menBic;
	}

	public String getMenBiccodctrl() {
		return menBiccodctrl;
	}

	public void setMenBiccodctrl(String menBiccodctrl) {
		this.menBiccodctrl = menBiccodctrl;
	}

	public String getMenBicbranch() {
		return menBicbranch;
	}

	public void setMenBicbranch(String menBicbranch) {
		this.menBicbranch = menBicbranch;
	}

//	public Set<SwfDetmensaje> getSwfDetmensaje() {
//		return swfDetmensaje;
//	}
//
//	public void setSwfDetmensaje(Set<SwfDetmensaje> swfDetmensaje) {
//		this.swfDetmensaje = swfDetmensaje;
//	}

	public String getMenInout() {
		return menInout;
	}

	public void setMenInout(String menInout) {
		this.menInout = menInout;
	}

	public String getMenUsrlvdverifica() {
		return menUsrlvdverifica;
	}

	public void setMenUsrlvdverifica(String menUsrlvdverifica) {
		this.menUsrlvdverifica = menUsrlvdverifica;
	}

	public String getMenHash() {
		return menHash;
	}

	public void setMenHash(String menHash) {
		this.menHash = menHash;
	}

	public String getMenCodapp() {
		return menCodapp;
	}

	public void setMenCodapp(String menCodapp) {
		this.menCodapp = menCodapp;
	}

	public String getMenFirmaorigen() {
		return menFirmaorigen;
	}

	public void setMenFirmaorigen(String menFirmaorigen) {
		this.menFirmaorigen = menFirmaorigen;
	}

	public String getMenCodusrswf() {
		return menCodusrswf;
	}

	public void setMenCodusrswf(String menCodusrswf) {
		this.menCodusrswf = menCodusrswf;
	}

	public Date getMenFecauto() {
		return menFecauto;
	}

	public void setMenFecauto(Date menFecauto) {
		this.menFecauto = menFecauto;
	}

	public String getMenReceiver() {
		return menReceiver;
	}

	public void setMenReceiver(String menReceiver) {
		this.menReceiver = menReceiver;
	}

	public String getSwiftfPlano() {
		return swiftfPlano;
	}

	public void setSwiftfPlano(String swiftfPlano) {
		this.swiftfPlano = swiftfPlano;
	}

	public String getMenCodmenrefer() {
		return menCodmenrefer;
	}

	public void setMenCodmenrefer(String menCodmenrefer) {
		this.menCodmenrefer = menCodmenrefer;
	}

	public String getMenEstverifica() {
		return menEstverifica;
	}

	public void setMenEstverifica(String menEstverifica) {
		this.menEstverifica = menEstverifica;
	}

	public String getMenEstmensaje() {
		return menEstmensaje;
	}

	public void setMenEstmensaje(String menEstmensaje) {
		this.menEstmensaje = menEstmensaje;
	}

	public String getMenEstautoriza() {
		return menEstautoriza;
	}

	public void setMenEstautoriza(String menEstautoriza) {
		this.menEstautoriza = menEstautoriza;
	}

	public String getMenIdoperacion() {
		return menIdoperacion;
	}

	public void setMenIdoperacion(String menIdoperacion) {
		this.menIdoperacion = menIdoperacion;
	}

	public String getMenTypemessage() {
		return menTypemessage;
	}

	public void setMenTypemessage(String menTypemessage) {
		this.menTypemessage = menTypemessage;
	}

	public String getMenIdTMessageTx() {
		return menIdTMessageTx;
	}

	public void setMenIdTMessageTx(String menIdTMessageTx) {
		this.menIdTMessageTx = menIdTMessageTx;
	}

	public FileFormat getFileFormat() {
		return FileFormat.valueOf(menFormato);
	}

	public String getMenFormato() {
		return menFormato;
	}

	public void setMenFormato(String menFormato) {
		if (!StringUtils.isBlank(menFormato)) {
			this.fileFormat = FileFormat.valueOf(menFormato);
		}
		this.menFormato = menFormato;
	}

	public String getMenHdrversion() {
		return menHdrversion;
	}

	public void setMenHdrversion(String menHdrversion) {
		this.menHdrversion = menHdrversion;
	}

	public String getMenCodmenOrig() {
		return menCodmenOrig;
	}

	public void setMenCodmenOrig(String menCodmenOrig) {
		this.menCodmenOrig = menCodmenOrig;
	}

	public String toStringBas() {
		return menIdTMessageTx + "(" + menTypemessage + ") Tp: " + (fileFormat != null ? fileFormat.toString() : "NN") + ", From: " + menEmisor + " To: "
				+ menReceiver + " Usr: " + menCodusrswf;
	}

	public String getMenFechoralit() {
		return menFechoralit;
	}

	public void setMenFechoralit(String menFechoralit) {
		this.menFechoralit = menFechoralit;
	}

	public String getMenCodusr() {
		return menCodusr;
	}

	public void setMenCodusr(String menCodusr) {
		this.menCodusr = menCodusr;
	}

	public String getMenPriority() {
		return menPriority;
	}

	public void setMenPriority(String menPriority) {
		this.menPriority = menPriority;
	}

	public String getUserBlock() {
		return userBlock;
	}

	public void setUserBlock(String userBlock) {
		this.userBlock = userBlock;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	public String getEmisorDescrip() {
		return emisorDescrip;
	}

	public void setEmisorDescrip(String emisorDescrip) {
		this.emisorDescrip = emisorDescrip;
	}

	public String getReceiverDescrip() {
		return receiverDescrip;
	}

	public void setReceiverDescrip(String receiverDescrip) {
		this.receiverDescrip = receiverDescrip;
	}

	public Boolean getVerifica() {
		return verifica;
	}

	public void setVerifica(Boolean verifica) {
		this.verifica = verifica;
	}

	public Date getMenFecvalor() {
		return menFecvalor;
	}

	public void setMenFecvalor(Date menFecvalor) {
		this.menFecvalor = menFecvalor;
	}

	public String getAuditwst() {
		return auditwst;
	}

	public void setAuditwst(String auditwst) {
		this.auditwst = auditwst;
	}

	public String getAuditusr() {
		return auditusr;
	}

	public void setAuditusr(String auditusr) {
		this.auditusr = auditusr;
	}

	public String getAuditfho() {
		return auditfho;
	}

	public void setAuditfho(String auditfho) {
		this.auditfho = auditfho;
	}

}
