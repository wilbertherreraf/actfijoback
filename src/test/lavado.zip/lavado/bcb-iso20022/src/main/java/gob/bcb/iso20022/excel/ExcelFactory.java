package gob.bcb.iso20022.excel;

import java.io.InputStream;
import java.util.List;

import gob.bcb.iso20022.excel.component.ExcelProperty;
import gob.bcb.iso20022.excel.core.GenericReader;
import gob.bcb.iso20022.excel.core.GenericWriter;
import gob.bcb.iso20022.excel.core.data.HeaderData;
import gob.bcb.iso20022.excel.core.listener.DataReadListener;

public class ExcelFactory extends ExcelProperty {

    private GenericReader reader;
    private GenericWriter writer;

    private ExcelFactory() {
    }

    private static class ExcelInstance {
        private static final ExcelFactory instance = new ExcelFactory();
    }

    public static ExcelFactory build() {
        return ExcelInstance.instance;
    }

    public ExcelFactory readInstance(String path, Class type, List<HeaderData> headerDataList) {
        GenericReader genericReader = new GenericReader(path, type);
        genericReader.setHeaderDataList(headerDataList);
        this.reader = genericReader;
        return this;
    }

    public ExcelFactory readInstance(String path, Class type, List<HeaderData> headerDataList, String sheetName) {
        GenericReader genericReader = new GenericReader(path, type, sheetName);
        genericReader.setHeaderDataList(headerDataList);
        this.reader = genericReader;
        return this;
    }

    public ExcelFactory readInstance(InputStream is, Class type, List<HeaderData> headerDataList, String sheetName) {
    	GenericReader genericReader = new GenericReader(is, type, sheetName);
    	genericReader.setHeaderDataList(headerDataList);
        this.reader = genericReader;
        return this;
    }
    
    public void read(DataReadListener listener) {
    	reader.setFileTypeEnum(fileTypeEnum);
    	reader.setcSVFormat(cSVFormat);
        reader.read(listener);
    }


    public ExcelFactory writeInstance(String path, List<HeaderData> headerDataList, List<List<Object>> contentDataList) {
        GenericWriter genericWriter = new GenericWriter(path);
        genericWriter.setHeaderDataList(headerDataList);
        genericWriter.setContentDataList(contentDataList);
        this.writer = genericWriter;
        return this;
    }


    public void write() {
        writer.write();
    }
}
