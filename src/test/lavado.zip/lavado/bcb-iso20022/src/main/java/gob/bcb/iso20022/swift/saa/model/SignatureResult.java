
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para SignatureResult.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="SignatureResult"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Success"/&gt;
 *     &lt;enumeration value="Bypassed"/&gt;
 *     &lt;enumeration value="Failed"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "SignatureResult")
@XmlEnum
public enum SignatureResult {

    @XmlEnumValue("Success")
    SUCCESS("Success"),
    @XmlEnumValue("Bypassed")
    BYPASSED("Bypassed"),
    @XmlEnumValue("Failed")
    FAILED("Failed");
    private final String value;

    SignatureResult(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SignatureResult fromValue(String v) {
        for (SignatureResult c: SignatureResult.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
