package gob.bcb.iso20022.core.xml;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import javax.annotation.Nonnull;
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Valida una cadena, archivo XML contra un esquema XSD, el XML sera valido si
 * no tiene ningun error de nivel WARN, ERROR o FATAL
 * 
 * @author WHerrera
 *
 */
public class ValidarConXsd {
	private static final Logger log = LoggerFactory.getLogger(ValidarConXsd.class);
	private ArrayList<SAXException> fileValidationErrorList = new ArrayList<>();
	private final AtomicReference<Schema> schemaRef = new AtomicReference<>();

	public List validate(String mxXml, String pathToXsd) throws Exception {
		fileValidationErrorList = new ArrayList<>();

		Validator validator = createXsdValidator(pathToXsd);
		checkIsValidFile(validator, mxXml.getBytes());
		List<String> errors = problemsList(); //fileValidationErrorList.stream().map(e -> e.getMessage()).collect(Collectors.toList());

		return errors;
	}

	public List validate(String mxXml, final Schema schema) throws Exception {
		fileValidationErrorList = new ArrayList<>();

		Validator validator = createXsdValidator(schema);
		checkIsValidFile(validator, mxXml.getBytes());
		List<String> errors = problemsList(); //fileValidationErrorList.stream().map(e -> e.getMessage()).collect(Collectors.toList());

		return errors;
	}

	public Validator createXsdValidator(final Schema schema) throws SAXException, FileNotFoundException {
		Validator validator = schema.newValidator();

		validator.setErrorHandler(new ErrorHandler() {
			@Override
			public void warning(SAXParseException exception) {
				saveErrors(exception);
			}

			@Override
			public void fatalError(SAXParseException exception) {
				saveErrors(exception);
			}

			@Override
			public void error(SAXParseException exception) {
				saveErrors(exception);
			}
		});

		return validator;
	}

	public Validator createXsdValidator(String pathToXsd) throws SAXException, FileNotFoundException {
//		fileValidationErrorList = new ArrayList<>();
//		groupedByErrorMap = new HashMap<>();
		final Schema schema = schemaRef.get();
		Validator validator = null;
		if (schema == null) {
			final InputStream xsdAsStream = new FileInputStream(pathToXsd);

			final SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			final Schema schemaN = factory.newSchema(new StreamSource(xsdAsStream));

			schemaRef.set(schemaN);

			validator = schemaN.newValidator();
		} else {
			validator = schema.newValidator();
		}

		validator.setErrorHandler(new ErrorHandler() {
			@Override
			public void warning(SAXParseException exception) {
				saveErrors(exception);
			}

			@Override
			public void fatalError(SAXParseException exception) {
				saveErrors(exception);
			}

			@Override
			public void error(SAXParseException exception) {
				saveErrors(exception);
			}
		});

		return validator;
	}

	public boolean checkIsValidFile(Validator validator, byte[] xmlAsBytes) throws IOException {
		try {
			ByteArrayInputStream xmlAsStream = new ByteArrayInputStream(xmlAsBytes);
			validator.validate(new StreamSource(xmlAsStream));
			return true;
		} catch (SAXException ex) {
			fileValidationErrorList = new ArrayList<>();
			return false;
		}
	}

	private void saveErrors(SAXParseException exception) {
		fileValidationErrorList.add(exception);
	}

	public List<String> problemsList() {
		List<String> errors = fileValidationErrorList.stream().map(e -> {
			String message = e.getMessage();
			int ind = message.indexOf(':');
			if (ind > 0)
				message = message.substring(ind + 1);

			return message;
		}).collect(Collectors.toList());
		return errors;
	}

	public static boolean isMatchingXsdSchema(byte[] xmlAsBytes, @Nonnull String pathToXsd) {

		try (ByteArrayInputStream xmlAsStream = new ByteArrayInputStream(xmlAsBytes);
				InputStream xsdAsStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(pathToXsd)) {

			SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = factory.newSchema(new StreamSource(xsdAsStream));

			Validator validator = schema.newValidator();
			validator.validate(new StreamSource(xmlAsStream));

			return true;
		} catch (IOException e) {
			throw new RuntimeException("IO Exception while validating xml file with xsd schema", e);
		} catch (SAXException ignore) {
			return false;
		}
	}
}
