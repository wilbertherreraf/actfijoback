package gob.bcb.iso20022.swift;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Currency;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.mvel2.MVEL;
import org.mvel2.ParserConfiguration;
import org.mvel2.ParserContext;
import org.mvel2.compiler.AbstractParser;
import org.mvel2.compiler.CompiledExpression;
import org.mvel2.compiler.ExpressionCompiler;
import org.mvel2.integration.VariableResolverFactory;
import org.mvel2.integration.impl.MapVariableResolverFactory;
import org.mvel2.util.ReflectionUtil;

import com.prowidesoftware.deprecation.DeprecationUtils;
import com.prowidesoftware.deprecation.DeprecationUtils.EnvironmentVariableKey;

import gob.bcb.iso20022.commons.Constants;
import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.utils.ValidatorCodes;

public class CampoFormUtils {
	public static enum Type {
		PRIMITIVE, CHAR, STRING, DATE, CALENDAR, BIG_INTEGER, BIG_DECIMAL, CURRENCY, BOOLEAN, ARRAY, MAP, COLLECTION, OBJECT;
	}

	public final static List<String> WORDS_EXCLUDE = Arrays.asList("hashCode", "toString", "toJson", "hashCode");
	
	public static List<CampoForm> objToPropertiesCf(Object o) {
		DeprecationUtils.setEnv(EnvironmentVariableKey.NODELAY); // , EnvironmentVariableKey.NOLOG for PW
//		DeprecationUtils.setEnv(EnvironmentVariableKey.NOLOG);
//		DeprecationUtils.setEnv(EnvironmentVariableKey.NOEXCEPTION);
		List<CampoForm> campoFormList = new ArrayList<>();
		if (o == null)
			return campoFormList;
		ParserContext ctx = new ParserContext();
		ctx.setStrongTyping(true);
		ctx.addInput("this", o.getClass());
		ctx.addInput("field", o.getClass());
		ctx.initializeTables();

		Map<String, Object> vars = new HashMap<String, Object>();
		vars.put("field", o);

		VariableResolverFactory varsResolver = new MapVariableResolverFactory(vars);

		List<String> propsL = ctx.getVariableScope().stream().map(s -> {
			return StringUtils.uncapitalize(s);
		}).distinct().collect(Collectors.toList());

		for (String s : propsL) {
			if ("class".equals(s) || "Class".equals(s) || WORDS_EXCLUDE.contains(s)) {
				continue;
			}

			ExpressionCompiler expC = new ExpressionCompiler("field." + s, ctx);
			CompiledExpression compiledExpression = null;
			String error = "";
			try {
				compiledExpression = expC.compile();
			} catch (Exception e) {
				error = e.getMessage();
			}

			if (compiledExpression != null && compiledExpression.getKnownEgressType() != Void.TYPE) {
				try {
					Type type = getTypeAsignable(compiledExpression.getKnownEgressType());
					if (type == null)
						continue;

					Object oVal = MVEL.executeExpression(compiledExpression, varsResolver);
					if (oVal == null) {
						continue;
					}
					Optional<String> valStrOpt = Optional.ofNullable(Objects.toString(oVal));
					String cad = valStrOpt.orElse(null);
					if (StringUtils.isBlank(cad))
						continue;

					CampoForm campoForm = new CampoForm();
					campoForm.setTabla(o.getClass().getSimpleName());
					campoForm.setColumn(s);
					campoForm.setTipoValor(type.toString());
					campoForm.setValorObj(oVal);

					asigValor(campoForm, oVal, type);

					campoFormList.add(campoForm);

				} catch (Exception e) {
					//System.out.println("Error " + e.getMessage() );
					error = e.getMessage();
				}
			}
		}
		;

		return campoFormList;
	}

	public static List<CampoForm> objToPropertiesCF(Object o) {
		String tabla = StringUtils.uncapitalize(o.getClass().getSimpleName().replaceAll(Constants.JB_TABLANAME_SEPARATOR, ""));
		Map<String, Object> facts = new HashMap<>();
		facts.put(tabla, o);

		List<CampoForm> list = classPropertiesCF(o.getClass());
		for (CampoForm campoForm : list) {
			String expression = campoForm.getTabla() + "." + campoForm.getColumn();
			Serializable expCompiled = MVEL.compileExpression(expression);
			Object oVal = MVEL.executeExpression(expCompiled, facts);
			if (oVal == null) {
				continue;
			}
			Optional<String> valStrOpt = Optional.ofNullable(Objects.toString(oVal));
			campoForm.setValor(valStrOpt.orElse(null));

			if (oVal instanceof Date) {
				campoForm.setFecha((Date) oVal);
			} else if (oVal instanceof Calendar) {
				campoForm.setFecha(((Calendar) oVal).getTime());
			} else if (oVal instanceof BigDecimal) {
				campoForm.setValDecimal((BigDecimal) oVal);
			} else if (oVal instanceof Double) {
				campoForm.setValDecimal(BigDecimal.valueOf((Double) oVal));
			} else if (oVal instanceof Integer) {
				campoForm.setValEntero((Integer) oVal);
			} else if (oVal instanceof Boolean) {
				campoForm.setValBool((Boolean) oVal);
			}
		}
		return list;
	}

	public static List<CampoForm> classPropertiesCF(Class<?> cls) {
		List<CampoForm> campoFormList = new ArrayList<>();
		BeanInfo beanInfo = null;

		try {
			beanInfo = Introspector.getBeanInfo(cls, Object.class);
		} catch (IntrospectionException e) {
			throw new RuntimeException(e);
		}

		PropertyDescriptor[] props = beanInfo.getPropertyDescriptors();

		String tabla = StringUtils.uncapitalize(cls.getSimpleName().replaceAll(Constants.JB_TABLANAME_SEPARATOR, ""));

		for (int i = 0, length = props.length; i < length; i++) {
			PropertyDescriptor prop = props[i];
			Method me = prop.getReadMethod();
			if (me == null)
				continue;
			if ("class".equals(prop.getName())) {
				continue;
			}

			if (prop.getPropertyType() == null) {
				continue;
			}
			CampoForm campoForm = new CampoForm();
			campoForm.setTabla(tabla);
			campoForm.setColumn(prop.getName());
			campoForm.setTipoValor(getType(prop.getPropertyType()).toString());

			campoFormList.add(campoForm);
		}
		return campoFormList;
	}

	public static void asigValor(CampoForm campoForm, Object oVal, Type type) {
		if (oVal == null) {
			return;
		}
		
		Type t = getType(oVal.getClass());
		if (type == Type.DATE) {
			campoForm.setFecha((Date) oVal);
		} else if (type == Type.STRING || type == Type.CHAR) {
			Optional<String> valStrOpt = Optional.ofNullable(Objects.toString(oVal));
			String cad = valStrOpt.orElse(null);
			campoForm.setValor(cad);
		} else if (type == Type.CALENDAR) {
			campoForm.setFecha(((Calendar) oVal).getTime());
		} else if (type == Type.BIG_DECIMAL) {
			campoForm.setValDecimal((BigDecimal) oVal);
		} else if (oVal instanceof Double) {
			campoForm.setValDecimal(BigDecimal.valueOf((Double) oVal));
		} else if (oVal instanceof Float) {
			campoForm.setValDecimal(BigDecimal.valueOf((Float) oVal));
		} else if (type == Type.BOOLEAN) {
			campoForm.setValBool((Boolean) oVal);
		} else if (type == Type.PRIMITIVE) {
			campoForm.setValEntero((Integer) oVal);
		}
	}

	public static Type getType(Class cls) {
		if (cls == null) {
			return null;
		}

		Type type = null;
		if (Character.class.isAssignableFrom(cls)) {
			type = Type.CHAR;
		} else if (String.class.isAssignableFrom(cls)) {
			type = Type.STRING;
		} else if (Date.class.isAssignableFrom(cls)) {
			type = Type.DATE;
		} else if (Calendar.class.isAssignableFrom(cls)) {
			type = Type.CALENDAR;
		} else if (BigInteger.class.isAssignableFrom(cls)) {
			type = Type.BIG_INTEGER;
		} else if (BigDecimal.class.isAssignableFrom(cls)) {
			type = Type.BIG_DECIMAL;
		} else if (Currency.class.isAssignableFrom(cls)) {
			type = Type.CURRENCY;
		} else if (Boolean.class.isAssignableFrom(cls)) {
			type = Type.BOOLEAN;
		} else if (cls.isArray()) {
			type = Type.ARRAY;
		} else if (Map.class.isAssignableFrom(cls)) {
			type = Type.MAP;
		} else if (Collection.class.isAssignableFrom(cls)) {
			type = Type.COLLECTION;
		} else if (cls.isPrimitive() || Number.class.isAssignableFrom(cls)) {
			type = Type.PRIMITIVE;
		} else {
			type = Type.OBJECT;
		}
		return type;
	}

	public static Type getTypeAsignable(Class cls) {
		if (cls == null) {
			return null;
		}

		Type type = null;
		if (Character.class.isAssignableFrom(cls)) {
			type = Type.CHAR;
		} else if (String.class.isAssignableFrom(cls)) {
			type = Type.STRING;
		} else if (Date.class.isAssignableFrom(cls)) {
			type = Type.DATE;
		} else if (Calendar.class.isAssignableFrom(cls)) {
			type = Type.CALENDAR;
		} else if (BigInteger.class.isAssignableFrom(cls)) {
			type = Type.BIG_INTEGER;
		} else if (BigDecimal.class.isAssignableFrom(cls)) {
			type = Type.BIG_DECIMAL;
		} else if (Currency.class.isAssignableFrom(cls)) {
			type = Type.CURRENCY;
		} else if (Boolean.class.isAssignableFrom(cls)) {
			type = Type.BOOLEAN;
		} else if (cls.isArray()) {
			type = null;
		} else if (Map.class.isAssignableFrom(cls)) {
			type = null;
		} else if (Collection.class.isAssignableFrom(cls)) {
			type = null;
		} else if (cls.isPrimitive() || Number.class.isAssignableFrom(cls)) {
			type = Type.PRIMITIVE;
		} else {
			type = Type.OBJECT;
			type = null;
		}
		return type;
	}

	public static BiConsumer<CampoForm, CampoForm> updCampoForm() {
		return (campoForm, campo) -> {
			campoForm.setTabla(campo.getTabla());
			campoForm.setColumn(campo.getColumn());
			campoForm.setIdDetallePlantilla(campo.getIdDetallePlantilla());
			campoForm.setDescripcion(campo.getDescripcion());
			campoForm.setTablaRel(campo.getTablaRel());
			campoForm.setAction(campo.getAction());
			campoForm.setCatalogo(campo.getCatalogo());
			campoForm.setCampoKey(campo.getCampoKey());
			campoForm.setCampoValue(campo.getCampoValue());
			campoForm.setValor(campo.getValor());
			campoForm.setFecha(campo.getFecha());
			campoForm.setValDecimal(campo.getValDecimal());
			campoForm.setValEntero(campo.getValEntero());
			campoForm.setTipoValor(campo.getTipoValor());
			campoForm.setTipoCampo(campo.getTipoCampo());
			campoForm.setValBool(campo.getValBool());

		};
	}

	public static BiConsumer<CampoForm, List<CampoForm>> mergeCampoForm() {
		return (campoFormIn, campoFormList) -> {
			Optional<CampoForm> campoFormOpt = findValorDeTablaTC(campoFormList).apply(campoFormIn.getTabla()).apply(campoFormIn.getColumn());

			if (campoFormOpt.isPresent()) {
				updCampoForm().accept(campoFormOpt.get(), campoFormIn);
			} else {
				campoFormList.add(campoFormIn);
			}

		};
	}

	public static Consumer<List<CampoForm>> mergeCampoFormList(List<CampoForm> campoFormListRoot) {
		return campoFormList -> {
			campoFormList.forEach(cf -> mergeCampoForm().accept(cf, campoFormListRoot));
		};
	}

	public static Function<String, Function<String, Optional<CampoForm>>> findValorDeTablaTC(List<CampoForm> campoFormList) {
		return tabla -> {

			List<CampoForm> cfList = valoresCFDeTabla(campoFormList).apply(tabla);
			return columna -> {
				if (columna == null) {
					return Optional.empty();
				}
				return cfList.stream().filter(campoForm -> campoForm.getColumn() != null && campoForm.getColumn().equalsIgnoreCase(columna)).findFirst();
			};
		};
	}

	public static Function<String, Optional<CampoForm>> findValorDeTabla(List<CampoForm> campoFormList) {
		return nombreTablaColumna -> {
			// la variable nombreTablaColumna debe ser en formato tabla_columna
			if (nombreTablaColumna == null || campoFormList == null) {
				return Optional.empty();
			}
			String[] tabColumna = nombreTablaColumna.split(Constants.CAMPOFORM_TABLANAME_SEPARATOR);
			if (tabColumna.length != 2) {
				// log.debug("el parametro nombreTablaColumna no cumple el
				// formato tabla_columna: " + nombreTablaColumna);
				return Optional.empty();
			}

			String tabla = tabColumna.length > 0 ? tabColumna[0] : "";
			String columna = tabColumna.length > 1 ? tabColumna[1] : "";

			return findValorDeTablaTC(campoFormList).apply(tabla).apply(columna);
		};
	}

	public static Function<String, List<CampoForm>> valoresCFDeTabla(List<CampoForm> campoFormList) {
		return tabla -> {
			// la variable nombreTablaColumna debe ser en formato tabla_columna
			if (tabla == null || campoFormList == null) {
				return new ArrayList<>();
			}

			return campoFormList.stream().filter(campoForm -> campoForm.getTabla() != null && campoForm.getTabla().equalsIgnoreCase(tabla))
					.collect(Collectors.toList());
		};
	}

	public static BiConsumer<CampoForm, List<CampoForm>> addIfNotExistCF() {
		return (campoFormIn, campoFormList) -> {
			Optional<CampoForm> cfFound = findValorDeTablaTC(campoFormList).apply(campoFormIn.getTabla()).apply(campoFormIn.getColumn());
			if (!cfFound.isPresent()) {
				campoFormList.add(campoFormIn);
			}
		};
	}

	public static Function<CampoForm, CampoForm> cloneCampoForm() {
		return campo -> {
			CampoForm campoForm = new CampoForm();

			updCampoForm().accept(campoForm, campo);
			return campoForm;
		};
	}

	public static Predicate<CampoForm> campoFormBlank = cf -> {
		return ValidatorCodes.isBlank.test(cf.getValor()) && cf.getValDecimal() == null && cf.getFecha() == null;
	};

	public static Predicate<CampoForm> campoFormValid = cf -> {
		return !ValidatorCodes.isBlank.test(cf.getTabla()) && !ValidatorCodes.isBlank.test(cf.getColumn()) && !campoFormBlank.test(cf);
	};

	public static List<CampoForm> generateBeanProperties0(Object obj, Function<Date, String> dateToStringF,
			Function<BigDecimal, String> bigDecimalToStringF) {
		List<Object> beans = new ArrayList<>();
		if (obj != null)
			beans = Arrays.asList(obj);

		List<CampoForm> campoFormList = beans.stream().map(objBean -> {

			return new HashMap<String, Object>();
		}).flatMap(mapProps -> {
			return mapProps.entrySet().stream();
		}).map(entry -> {
			// log.debug("nombre campo : " + entry.getKey());
			int pos = entry.getKey().indexOf(Constants.JB_TABLACOLUMN_SEPARATOR);
			String tabla = pos > 0 ? entry.getKey().substring(0, pos) : "";
			String column = pos > 0 ? entry.getKey().substring(pos + 1) : "";
			// log.info("XXX: tablita "+ tabla + "." + column + " => " +
			// entry.getValue());
			CampoForm campoForm = new CampoForm();
			campoForm.setTabla(tabla);
			campoForm.setColumn(column);
			Optional<String> valStrOpt = Optional.ofNullable(ReflectionToStringBuilder.toString(entry.getValue()));
			// Optional<String> valStrOpt = JavaBeansUtils.ojectToString(dateToStringF,
			// bigDecimalToStringF).apply(entry.getValue());
			// if (valStrOpt.isPresent())
			// if (entry.getValue() != null) {
			// log.info("XXX: tablita "+ tabla + "." + column + " => : " +
			// entry.getValue().getClass().getSimpleName());
			// }
			campoForm.setTipoValor("S");
			campoForm.setValor(valStrOpt.orElse(null));
			if (entry.getValue() != null) {
				if (entry.getValue() instanceof Date) {
					campoForm.setFecha((Date) entry.getValue());
					campoForm.setTipoValor("D");
				} else if (entry.getValue() instanceof Calendar) {
					campoForm.setFecha(((Calendar) entry.getValue()).getTime());
					campoForm.setTipoValor("D");
				} else if (entry.getValue() instanceof BigDecimal) {
					campoForm.setValDecimal((BigDecimal) entry.getValue());
					campoForm.setTipoValor("B");
				} else if (entry.getValue() instanceof Double) {
					campoForm.setValDecimal(BigDecimal.valueOf((Double) entry.getValue()));
					campoForm.setTipoValor("B");
				} else if (entry.getValue() instanceof Integer) {
					campoForm.setValEntero((Integer) entry.getValue());
					campoForm.setTipoValor("I");
				} else if (entry.getValue() instanceof Boolean) {
					campoForm.setValBool((Boolean) entry.getValue());
					campoForm.setTipoValor("b");
				}
			}

			return campoForm;
		})
				// .filter(campoForm -> campoForm.getValor() != null)
				.collect(Collectors.toList());

		return campoFormList;
	}

	public static Function<Object, List<CampoForm>> generateCampoFormList(Function<Date, String> dateToStringF,
			Function<BigDecimal, String> bigDecimalToStringF) {
		return objBean -> objToPropertiesCF(objBean);
		// return objBean -> generateBeanProperties(objBean, dateToStringF,
		// bigDecimalToStringF);
	}

	public static boolean checkForDynamicImport(String className) {
		if (!Character.isJavaIdentifierStart(className.charAt(0)))
			return false;
		return false;
	}
}
