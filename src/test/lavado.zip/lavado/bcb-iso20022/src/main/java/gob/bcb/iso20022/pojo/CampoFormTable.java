
package gob.bcb.iso20022.pojo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.swift.CampoFormUtils;
import gob.bcb.iso20022.swift.CampoFormUtils.Type;

public class CampoFormTable {
	private String tabla;
	private Object obj;
	private Map<String, CampoForm> atrib = new HashMap<String, CampoForm>();
	private final Map<String, POJO> subEnt = new HashMap<String, POJO>();
	
	public CampoFormTable() {

	}
	
	public CampoFormTable(String tabla, Object o) {
		this.tabla = tabla;
		this.obj = o;
	}

	public CampoFormTable recProps() {
		List<CampoForm> campoFormList = CampoFormUtils.objToPropertiesCf(obj);
		campoFormList.forEach(cf -> {
			cf.setTabla(tabla);
			atrib.put(cf.getColumn(), cf);
		});
		return this;
	}
	
	public String atrS(String atribN) {
		if (atrib.containsKey(atribN))
			return atrib.get(atribN).getValorObj().toString();
		else
			return "";
	}

	public BigDecimal atrD(String atribN) {
		if (atrib.containsKey(atribN))
			return atrib.get(atribN).getValDecimal();
		else
			return BigDecimal.ONE.negate();
	}

	public Date atrDt(String atribN) {
		if (atrib.containsKey(atribN))
			return atrib.get(atribN).getFecha();
		else
			return null;
	}

	public Object atrO(String atribN) {
		if (atrib.containsKey(atribN))
			return atrib.get(atribN).getValorObj();
		else
			return null;
	}	
	
	public CampoForm atrCF(String atribN) {
		if (atrib.containsKey(atribN))
			return atrib.get(atribN);
		else
			return null;
	}	
	public POJO sEnt(String field) {
		return subEnt.getOrDefault(field, new POJO());
	}

	public POJO newSEnt(String field) {
		POJO p = new POJO(field);
		subEnt.put(field, p);
		return p;
	}

	public CampoFormTable newSEnt(String field, Map<String, Object> mapAtribs) {
		if (StringUtils.isBlank(field) || mapAtribs == null || mapAtribs.size() == 0) {
			return this;
		}
		POJO p = new POJO(field);
		p.setMap(mapAtribs);
		
		subEnt.put(field, p);
		return this;
	}
	
	public Map<String, POJO> getSubEnt() {
		return subEnt;
	}


	public Map<String, CampoForm> getAtrib() {
		return atrib;
	}
	
	public CampoFormTable newEnt(String tabla, Map<String, Object> map) {
		this.tabla = tabla;
		for(Entry<String, Object> entry : map.entrySet()) {
			if (entry.getValue() != null) {
				putAtr(entry.getKey(), entry.getValue());
			}
		}
		return this;
	}

	public CampoFormTable newEntCF(String tabla, Map<String, CampoForm> map) {
		this.tabla = tabla;
		for(Entry<String, CampoForm> entry : map.entrySet()) {
			if (entry.getValue() != null) {
				atrib.put(entry.getKey(), entry.getValue());
			}
		}
		return this;
	}
	
	public void putAtr(String key, Object o) {
		if (o == null) {
			return;
		}
		
		Type type = CampoFormUtils.getTypeAsignable(o.getClass());
		if (type == null)
			return;
		
		CampoForm campoForm = new CampoForm();
		campoForm.setTabla(o.getClass().getSimpleName());
		campoForm.setColumn(key);
		campoForm.setTipoValor(type.toString());
		campoForm.setValorObj(o);

		CampoFormUtils.asigValor(campoForm, o, type);
		atrib.put(key, campoForm);
	}
	
	public void setAtrib(Map<String, CampoForm> atrib) {
		this.atrib = atrib;
	}

	public String getTabla() {
		return tabla;
	}

	public void setTabla(String tabla) {
		this.tabla = tabla;
	}

	public class POJO {
		private String name;
		private Map<String, Object> map = new HashMap<String, Object>();
		private Map<String, CampoForm> mapCF = new HashMap<String, CampoForm>();
		
		public POJO() {
		}
		public POJO(String name) {
			this.name = name;
		}
		public String function(long num) {
			return String.valueOf(num);
		}

		public String aMethod(long num) {
			return String.valueOf(num);
		}

		public String fld(String key) {
			if (map.containsKey(key)) {
				return String.valueOf(map.get(key));
			}
			return "";
		}

		public BigDecimal fldD(String key) {
			if (mapCF.containsKey(key)) {
				BigDecimal res = mapCF.get(key).getValDecimal();
				return res == null ? BigDecimal.ZERO : res;
			}
			return BigDecimal.ZERO;
		}
		
		public Map<String, Object> getMap() {
			return map;
		}

		public void setMap(Map<String, Object> map) {
			for(Entry<String, Object> entry : map.entrySet()) {
				if (entry.getValue() != null) {
					putAtr(entry.getKey(), entry.getValue());
				}
			}
		}

		public POJO putAtr(String key, Object o) {
			if (o == null) {
				return this;
			}
			map.put(key, o);
			
			Type type = CampoFormUtils.getTypeAsignable(o.getClass());
			if (type == null)
				return this;
			
			CampoForm campoForm = new CampoForm();
			campoForm.setTabla(o.getClass().getSimpleName());
			campoForm.setColumn(key);
			campoForm.setTipoValor(type.toString());
			campoForm.setValorObj(o);

			CampoFormUtils.asigValor(campoForm, o, type);
			mapCF.put(key, campoForm);
			
			return this;
		}

		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
	}	
}
