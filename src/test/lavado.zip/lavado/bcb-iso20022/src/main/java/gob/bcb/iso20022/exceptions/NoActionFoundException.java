package gob.bcb.iso20022.exceptions;

public class NoActionFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public NoActionFoundException(String msg) {
		super(msg);
	}
}
