package gob.bcb.iso20022.model;

public class SwfTipomensaje{

	private String timCodmt;
	private Integer timMt;
	private String timDescrip;
	private String timCondicion;
	private String timExpresion;
	private String timReglaswf;
	private String timTipomt;
	private String timInfo;
	private Integer timTipmensa;

	public SwfTipomensaje() {
	}

	public String getTimCodmt() {
		return this.timCodmt;
	}

	public void setTimCodmt(String timCodmt) {
		this.timCodmt = timCodmt;
	}

	public String getTimDescrip() {
		return this.timDescrip;
	}

	public void setTimDescrip(String timDescrip) {
		this.timDescrip = timDescrip;
	}

	public String getTimInfo() {
		return this.timInfo;
	}

	public void setTimInfo(String timInfo) {
		this.timInfo = timInfo;
	}

	public Integer getTimTipmensa() {
		return this.timTipmensa;
	}

	public void setTimTipmensa(Integer timTipmensa) {
		this.timTipmensa = timTipmensa;
	}

	public String getTimCondicion() {
		return timCondicion;
	}

	public void setTimCondicion(String timCondicion) {
		this.timCondicion = timCondicion;
	}

	public String getTimExpresion() {
		return timExpresion;
	}

	public void setTimExpresion(String timExpresion) {
		this.timExpresion = timExpresion;
	}

	public String getTimReglaswf() {
		return timReglaswf;
	}

	public void setTimReglaswf(String timReglaswf) {
		this.timReglaswf = timReglaswf;
	}

	public Integer getTimMt() {
		return timMt;
	}

	public void setTimMt(Integer timMt) {
		this.timMt = timMt;
	}

}