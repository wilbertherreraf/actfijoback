package gob.bcb.iso20022.translate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.core.xml.ValidarConXsd;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.utils.UtilsFile;

public class ValidationEngine {
	private final static Logger log = LoggerFactory.getLogger(ValidationEngine.class);
	public final static String PATH_LOCAL_XSD = "xsd/camt.054.001.09.xsd";
	private final Map<String, Schema> schemas = new ConcurrentHashMap<String, Schema>();
	private boolean registerSch = false;

	private static class ValidationEngineHolder {
		public static final ValidationEngine instance = new ValidationEngine();
	}

	private ValidationEngine() {
		log.info("Creando validtior...");
	}

	public static ValidationEngine getInstance() {
		return ValidationEngineHolder.instance;
	}

	public ValidationEngine registerValidators() throws IOException, URISyntaxException {
//		if (registerSch)
//			return this;
		try {
			InputStream urlResources0 = ValidationEngine.class.getClassLoader().getResourceAsStream(PATH_LOCAL_XSD);
			
			URL urlResources = ValidationEngine.class.getClassLoader().getResource(PATH_LOCAL_XSD);
			log.info("Path loader schemas -> " + urlResources.getPath());
			String path = FilenameUtils.getFullPath(urlResources.getPath());
			File dir = new File(path);
			File[] files = dir.listFiles();

			
			if (files.length == 0) {
				log.error("No existen ningun archivo XSD en " + PATH_LOCAL_XSD);
			}

			for (File f : files) {
				if (!f.getName().endsWith("xsd")) {
					continue;
				}
				InputStream is = new FileInputStream(f);

				int idx = f.getName().indexOf(".xsd");
				String typeMessage = f.getName().substring(0, idx);
				log.info("Registrando Xsd: " + typeMessage + " path: " + f.getAbsolutePath());
				registerValidator(is, typeMessage);
			}

			registerSch = (files.length == schemas.size());
			if (schemas.size() == 0) {
				log.error("Esquemas XSD sin elementos");
			}
			return this;
		} catch (Exception e) {
			log.error("Error al cargar schemas " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public void registerValidator(String pathToXsd, String typeMessage) throws FileNotFoundException {
		log.info("Registrando Xsd: " + typeMessage + ", path: " + pathToXsd);
		final InputStream xsdAsStream = new FileInputStream(pathToXsd);
		registerValidator(xsdAsStream, typeMessage);
	}

	public void registerValidator(final InputStream xsdAsStream, String typeMessage) {
		try {
			log.info("Registrando Xsd: " + typeMessage);
			final SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			final Schema schema = factory.newSchema(new StreamSource(xsdAsStream));
			schemas.put(typeMessage, schema);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public List<String> validateMsg(String msg) throws Exception {
		SwiftMessageAbstract sma = FactoryParser.createParser(msg);

		if (sma.isMx()) {
			String typeM = sma.getTypeMessage();
			return validateMsg(msg, typeM);
		}
		log.warn("Validacion no implmentada");
		// return new ArrayList<>();
		throw new RuntimeException("Validator no registrado ");
	}

	public List<String> validateMsg(String msg, String typeM) throws Exception {
		if (StringUtils.isBlank(typeM)) {
			throw new RuntimeException("Validacion de MX: Tipo de schema nulo");
		}
		if (StringUtils.isBlank(msg)) {
			throw new RuntimeException("Validacion de MX: Mensaje nulo");
		}
		log.info("Validate with type: " + typeM);

		ValidarConXsd validatorSch = new ValidarConXsd();
		Schema schema = schemas.get(typeM);
		if (schema == null) {
			InputStream xsdAsStream = UtilsFile.inputStreamResource("xsd/" + typeM + ".xsd", getClass());
			if (xsdAsStream != null) {
				registerValidator(xsdAsStream, typeM);
			} 
			schema = schemas.get(typeM);
		}
		if (schema == null) {
			throw new RuntimeException("Schema Xsd no registrado " + typeM);
		}
		List<String> errors = validatorSch.validate(msg, schema);
		return errors;
	}

}
