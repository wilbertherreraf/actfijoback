
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para SessionDirection.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="SessionDirection"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="ToMessagePartner"/&gt;
 *     &lt;enumeration value="FromMessagePartner"/&gt;
 *     &lt;enumeration value="ToAndFromMessagePartner"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "SessionDirection")
@XmlEnum
public enum SessionDirection {

    @XmlEnumValue("ToMessagePartner")
    TO_MESSAGE_PARTNER("ToMessagePartner"),
    @XmlEnumValue("FromMessagePartner")
    FROM_MESSAGE_PARTNER("FromMessagePartner"),
    @XmlEnumValue("ToAndFromMessagePartner")
    TO_AND_FROM_MESSAGE_PARTNER("ToAndFromMessagePartner");
    private final String value;

    SessionDirection(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SessionDirection fromValue(String v) {
        for (SessionDirection c: SessionDirection.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
