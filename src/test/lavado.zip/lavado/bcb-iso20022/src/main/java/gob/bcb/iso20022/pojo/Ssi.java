package gob.bcb.iso20022.pojo;

public class Ssi extends Mkt {
	private String code = "";
	private String mmbId = "";
	private Acc accSttl = new Acc();
	private Part finInst = new Part();
	// Debtor agent Creditor Agent Forwarding Agent, Account Servicer, "Payment
	// Clearing Agent (Instructing Agent)", "Payment Settlement Agent (Instructed
	// Agent)", Intermediary Agent

	public Acc getAccSttl() {
		return accSttl;
	}

	public void setAccSttl(Acc acc) {
		this.accSttl = acc;
	}

	public String getMmbId() {
		return mmbId;
	}

	public void setMmbId(String mmbId) {
		this.mmbId = mmbId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Part getFinInst() {
		return finInst;
	}

	public void setFinInst(Part finInst) {
		this.finInst = finInst;
	}

	@Override
	public String toString() {
		return "(" + getCurrency() + "-" + getCountry() + "-" + getSecurity() + "-" + getMethodtype() + ")[" + code + "," + mmbId + "," + accSttl.getIdacc() + "]";
	}
	public String strLine() {
		return getCurrency() + "|" + getCountry() + "-" + getSecurity() + "-" + getMethodtype();
	}
}
