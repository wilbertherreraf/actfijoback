/*
 * To change this template, choose Tools | Templates

 * and open the template in the editor.
 */
package gob.bcb.iso20022.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

public class ArchivoUtil {
	public static String obtenerExtension(String nombre) {
		String extension = "";
		if (nombre == null) {
			return extension;
		}
		int ultimoPunto = nombre.lastIndexOf('.');
		if (ultimoPunto > 0) {
			extension = nombre.substring(ultimoPunto + 1);
		}
		return extension;
	}

	/**
	 * Metodo que retorna el tipo de mime de un archivo a partir de su extension
	 * 
	 * @param nombre
	 *            Nombre del archivo
	 * @return El tipo mime para el archivo
	 */
	public static String obtenerMime(String nombre) {
		String mime = null;
		String extension = obtenerExtension(nombre);
		if (extension != null && extension.trim().length() > 0) {
			mime = getMimeFromExt(extension);
		} else {
			mime = "application/x-binary";
		}
		return mime;
	}

	public static String getMimeFromExt(String extension) {
		String mime = null;
		if (extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx")) {
			mime = "application/msword";
		} else if (extension.equalsIgnoreCase("pdf")) {
			mime = "application/pdf";
		} else if (extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx")) {
			mime = "application/mspowerpoint";
		} else if (extension.equalsIgnoreCase("text")) {
			mime = "text/plain";
		} else if (extension.equalsIgnoreCase("txt")) {
			mime = "text/plain";
		} else if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx")) {
			mime = "application/vnd.ms-excel";
		} else if (extension.equalsIgnoreCase("xml")) {
			mime = "text/xml";
		} else {
			mime = "application/x-binary";
		}
		return mime;
	}

	public static String checkSumFile(String pathFile) throws Exception {
		if (StringUtils.isBlank(pathFile)) {
			return null;
		}
		FileInputStream fis = new FileInputStream(pathFile);

		return checkSumFile(fis);
	}

	public static String checkSumFile(InputStream fis) throws Exception {
		// FileInputStream fis = new FileInputStream(new File(pathFile));
		MessageDigest messageDigest = MessageDigest.getInstance("SHA1");
		byte[] dataBytes = new byte[1024];
		int nread = 0;

		while ((nread = fis.read(dataBytes)) != -1) {
			messageDigest.update(dataBytes, 0, nread);
		}
		byte[] mdbytes = messageDigest.digest();

		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < mdbytes.length; i++) {
			sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
		}

		return sb.toString();
	}

	public static String checkSumString(String[] fis) throws Exception {
		// FileInputStream fis = new FileInputStream(new File(pathFile));
		if (fis == null || fis.length == 0){
			return "";
		}
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");

		for (String s : fis) {
		
			messageDigest.update(s.getBytes());
		}
		byte[] mdbytes = messageDigest.digest();

		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < mdbytes.length; i++) {
			sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
		}

		return sb.toString();
	}
	public static String getOriginalFilename(String pathFile) {
		// check for Unix-style path
		int pos = pathFile.lastIndexOf("/");
		if (pos == -1) {
			// check for Windows-style path
			pos = pathFile.lastIndexOf("\\");
		}
		if (pos != -1) {
			// any sort of path separator found
			return pathFile.substring(pos + 1);
		} else {
			// plain name
			return pathFile;
		}
	}

	public static File checkFile(String pathFile) {
		if (StringUtils.isBlank(pathFile)) {
			throw new RuntimeException("Ruta archivo nulo");
		}

		File h = new File(pathFile);
		if (!h.exists() || h.isDirectory()) {
			throw new RuntimeException("Archivo inexistente " + pathFile);
		}
		return h;
	}

	public static String hashString(String stringToEncrypt){
		return DigestUtils.md5Hex(stringToEncrypt);		
	}
	
}
