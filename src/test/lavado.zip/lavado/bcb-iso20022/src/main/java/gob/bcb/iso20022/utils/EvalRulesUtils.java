package gob.bcb.iso20022.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import gob.bcb.iso20022.utilsBank.secID.SecurityIdentifier;

public class EvalRulesUtils {
	// public static final String PATTERN_DATE_DDMMYYYY = "dd/MM/yyyy";
	public static final String CODEFUTURE_4_5 = "[A-Z]{1,1}[0-9A-Z]{1,1}[FGHJKMNQUVXZ][0-9]{1,2}";
	public static final String CODEFUTURE_3 = "[A-Z]{1,1}[FGHJKMNQUVXZ][0-9]{1,1}";
	public static final String CODE_FOREX = "[A-Z]{3,3}/[A-Z]{3,3}[0-9]{0,1}";
	public static final String CODE_CURRENCY = "[A-Z]{3,3}";
	public static final String LOCCODE_CRTY = "CTRY";
	public static final String DATE_FORMAT_ABC = "MM/dd/yy";

	public static boolean isCurrency(String command) {
		return !isBlank.test(command) && Pattern.matches(CODE_CURRENCY, command.trim().toUpperCase());
	}

	////////////////////////////////////////////

	public static Predicate<String> isBlank = text -> text == null || text.trim().length() == 0;

	public static String amtABC(final BigDecimal bigDecimal, Integer n) {
		if (bigDecimal != null) {
			BigDecimal amt = bigDecimal.setScale(n, BigDecimal.ROUND_HALF_UP);
			final DecimalFormatSymbols symbols = new DecimalFormatSymbols();
			symbols.setDecimalSeparator('.');
			final DecimalFormat df = new DecimalFormat("0.0" + StringUtils.rightPad("", n-1, '#'), symbols);
			df.setParseBigDecimal(true);
			df.setDecimalSeparatorAlwaysShown(true);
			final String formatted = df.format(amt);
			return StringUtils.replaceChars(formatted, ',', '.');
		}
		return "";
	}
	
	public static String princIDSec(String isin, String cusip) {
		isin = StringUtils.trimToEmpty(isin).toUpperCase();
		cusip = StringUtils.trimToEmpty(cusip).toUpperCase();
		
		String idSec = SecurityIdentifier.returnCodeSecurity().apply(isin, cusip).orElse("");
		if (StringUtils.isBlank(idSec))
			return "";
		
		String idSecOtro = SecurityIdentifier.returnCodeSecurity().apply(cusip, idSec).orElse("");
		idSecOtro = !idSec.equals(idSecOtro) ? idSecOtro : "";
		
		if (StringUtils.isBlank(idSecOtro)) {
			return idSec;
		}
		if (SecurityIdentifier.isIsin(idSecOtro)) {
			return idSecOtro;	
		}
		return idSec;
	}
	
	public static String otroIDSec(String codeSecurity, String isin, String cusip) {
		codeSecurity = StringUtils.trimToEmpty(codeSecurity).toUpperCase();
		isin = StringUtils.trimToEmpty(isin).toUpperCase();
		cusip = StringUtils.trimToEmpty(cusip).toUpperCase();
		return StringUtils.equals(codeSecurity, isin) ? cusip : isin;
	}
	
	public static String isinABC(String isin, String cusip) {
		String idSec = princIDSec(isin, cusip);
		String otroIDSec = otroIDSec(idSec, isin, cusip);
		
		if (SecurityIdentifier.isIsin11(idSec)) {
			return idSec;
		}
		
		if (SecurityIdentifier.isIsin11(otroIDSec)) {
			return otroIDSec;
		}
		if (!StringUtils.isBlank(otroIDSec)) {
			return idSec;
		}
		return "";
	}
	
	public static String cusipABC(String isin, String cusip) {
		isin = StringUtils.trimToEmpty(isin).toUpperCase();
		cusip = StringUtils.trimToEmpty(cusip).toUpperCase();

		String idSec = isinABC(isin, cusip);
		if (!StringUtils.isBlank(idSec)) {
			return idSec.equals(isin) ? cusip : isin;
		}
		if (!StringUtils.isBlank(isin)) {
			return isin;
		}
		return  cusip;
	}	

}
