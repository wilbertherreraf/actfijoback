
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para SWIFTNetNetworkInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="SWIFTNetNetworkInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RequestType" type="{urn:swift:saa:xsd:saa.2.0}RequestType" minOccurs="0"/&gt;
 *         &lt;element name="RequestSubtype" type="{urn:swift:saa:xsd:saa.2.0}RequestSubtype" minOccurs="0"/&gt;
 *         &lt;element name="SWIFTRef" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetReference" minOccurs="0"/&gt;
 *         &lt;element name="SNLRef" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetReference" minOccurs="0"/&gt;
 *         &lt;element name="Reference" type="{urn:swift:saa:xsd:saa.2.0}CBTReference" minOccurs="0"/&gt;
 *         &lt;element name="SNLEndPoint" type="{urn:swift:saa:xsd:saa.2.0}SNLEndPoint" minOccurs="0"/&gt;
 *         &lt;element name="SnFQueueName" type="{urn:swift:saa:xsd:saa.2.0}SnFQueueName" minOccurs="0"/&gt;
 *         &lt;element name="SnFChannelName" type="{urn:swift:saa:xsd:saa.2.0}SnFChannelName" minOccurs="0"/&gt;
 *         &lt;element name="SnFInputTime" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetTime" minOccurs="0"/&gt;
 *         &lt;element name="SnFDeliveryTime" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetTime" minOccurs="0"/&gt;
 *         &lt;element name="CreationTime" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetTime" minOccurs="0"/&gt;
 *         &lt;element name="ValidationDescriptor" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="ResponseResponderDN" type="{urn:swift:saa:xsd:saa.2.0}DN" minOccurs="0"/&gt;
 *         &lt;element name="ResponseSWIFTRef" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetReference" minOccurs="0"/&gt;
 *         &lt;element name="ResponseSNLRef" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetReference" minOccurs="0"/&gt;
 *         &lt;element name="ResponseReference" type="{urn:swift:saa:xsd:saa.2.0}CBTReference" minOccurs="0"/&gt;
 *         &lt;element name="IsPossibleDuplicateResponse" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="ResponseValidationDescriptor" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="PayloadAttributes" type="{urn:swift:saa:xsd:saa.2.0}PayloadAttributeList" minOccurs="0"/&gt;
 *         &lt;element name="ResponsePayloadAttributes" type="{urn:swift:saa:xsd:saa.2.0}PayloadAttributeList" minOccurs="0"/&gt;
 *         &lt;element name="IsCopyRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="IsAuthNotificationRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="CopyInfo" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="TransferRef" type="{urn:swift:saa:xsd:saa.2.0}TransferRef" minOccurs="0"/&gt;
 *         &lt;element name="StoredTransferRef" type="{urn:swift:saa:xsd:saa.2.0}TransferRef" minOccurs="0"/&gt;
 *         &lt;element name="OrigSnfRef" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetReference" minOccurs="0"/&gt;
 *         &lt;element name="TransferDescription" type="{urn:swift:saa:xsd:saa.2.0}FileInfoDescription" minOccurs="0"/&gt;
 *         &lt;element name="TransferInfo" type="{urn:swift:saa:xsd:saa.2.0}FileInfoDescription" minOccurs="0"/&gt;
 *         &lt;element name="FileDescription" type="{urn:swift:saa:xsd:saa.2.0}FileInfoDescription" minOccurs="0"/&gt;
 *         &lt;element name="FileInfo" type="{urn:swift:saa:xsd:saa.2.0}FileInfoDescription" minOccurs="0"/&gt;
 *         &lt;element name="HeaderInfo" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="NotificationResponderDN" type="{urn:swift:saa:xsd:saa.2.0}DN" minOccurs="0"/&gt;
 *         &lt;element name="NotificationRequestType" type="{urn:swift:saa:xsd:saa.2.0}RequestType" minOccurs="0"/&gt;
 *         &lt;element name="FileStartTime" type="{urn:swift:saa:xsd:saa.2.0}TimeString" minOccurs="0"/&gt;
 *         &lt;element name="FileEndTime" type="{urn:swift:saa:xsd:saa.2.0}TimeString" minOccurs="0"/&gt;
 *         &lt;element name="OverdueWarningTime" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetTime" minOccurs="0"/&gt;
 *         &lt;element name="OverdueWarningDelay" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="RecipientList" type="{urn:swift:saa:xsd:saa.2.0}RecipientListType" minOccurs="0"/&gt;
 *         &lt;element name="ThirdPartyList" type="{urn:swift:saa:xsd:saa.2.0}ThirdPartyListType" minOccurs="0"/&gt;
 *         &lt;element name="IsRecipientListPublic" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="DistributionInfo" type="{urn:swift:saa:xsd:saa.2.0}DistributionInfo" minOccurs="0"/&gt;
 *         &lt;element name="RetrievalInfo" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="RequestE2EControl" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="RetrievalDescriptor" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="TSInfoForReceiver" type="{urn:swift:saa:xsd:saa.2.0}PCInfoForReceiver" minOccurs="0"/&gt;
 *         &lt;element name="OrigTransferRef" type="{urn:swift:saa:xsd:saa.2.0}TransferRef" minOccurs="0"/&gt;
 *         &lt;element name="InformCopyInfo" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SWIFTNetNetworkInfo", propOrder = {
    "requestType",
    "requestSubtype",
    "swiftRef",
    "snlRef",
    "reference",
    "snlEndPoint",
    "snFQueueName",
    "snFChannelName",
    "snFInputTime",
    "snFDeliveryTime",
    "creationTime",
    "validationDescriptor",
    "responseResponderDN",
    "responseSWIFTRef",
    "responseSNLRef",
    "responseReference",
    "isPossibleDuplicateResponse",
    "responseValidationDescriptor",
    "payloadAttributes",
    "responsePayloadAttributes",
    "isCopyRequested",
    "isAuthNotificationRequested",
    "copyInfo",
    "transferRef",
    "storedTransferRef",
    "origSnfRef",
    "transferDescription",
    "transferInfo",
    "fileDescription",
    "fileInfo",
    "headerInfo",
    "notificationResponderDN",
    "notificationRequestType",
    "fileStartTime",
    "fileEndTime",
    "overdueWarningTime",
    "overdueWarningDelay",
    "recipientList",
    "thirdPartyList",
    "isRecipientListPublic",
    "distributionInfo",
    "retrievalInfo",
    "requestE2EControl",
    "retrievalDescriptor",
    "tsInfoForReceiver",
    "origTransferRef",
    "informCopyInfo"
})
public class SWIFTNetNetworkInfo {

    @XmlElement(name = "RequestType")
    protected String requestType;
    @XmlElement(name = "RequestSubtype")
    protected String requestSubtype;
    @XmlElement(name = "SWIFTRef")
    protected String swiftRef;
    @XmlElement(name = "SNLRef")
    protected String snlRef;
    @XmlElement(name = "Reference")
    protected String reference;
    @XmlElement(name = "SNLEndPoint")
    protected String snlEndPoint;
    @XmlElement(name = "SnFQueueName")
    protected String snFQueueName;
    @XmlElement(name = "SnFChannelName")
    protected String snFChannelName;
    @XmlElement(name = "SnFInputTime")
    protected String snFInputTime;
    @XmlElement(name = "SnFDeliveryTime")
    protected String snFDeliveryTime;
    @XmlElement(name = "CreationTime")
    protected String creationTime;
    @XmlElement(name = "ValidationDescriptor")
    protected SwAny validationDescriptor;
    @XmlElement(name = "ResponseResponderDN")
    protected String responseResponderDN;
    @XmlElement(name = "ResponseSWIFTRef")
    protected String responseSWIFTRef;
    @XmlElement(name = "ResponseSNLRef")
    protected String responseSNLRef;
    @XmlElement(name = "ResponseReference")
    protected String responseReference;
    @XmlElement(name = "IsPossibleDuplicateResponse")
    protected Boolean isPossibleDuplicateResponse;
    @XmlElement(name = "ResponseValidationDescriptor")
    protected SwAny responseValidationDescriptor;
    @XmlElement(name = "PayloadAttributes")
    protected PayloadAttributeList payloadAttributes;
    @XmlElement(name = "ResponsePayloadAttributes")
    protected PayloadAttributeList responsePayloadAttributes;
    @XmlElement(name = "IsCopyRequested")
    protected Boolean isCopyRequested;
    @XmlElement(name = "IsAuthNotificationRequested")
    protected Boolean isAuthNotificationRequested;
    @XmlElement(name = "CopyInfo")
    protected SwAny copyInfo;
    @XmlElement(name = "TransferRef")
    protected String transferRef;
    @XmlElement(name = "StoredTransferRef")
    protected String storedTransferRef;
    @XmlElement(name = "OrigSnfRef")
    protected String origSnfRef;
    @XmlElement(name = "TransferDescription")
    protected String transferDescription;
    @XmlElement(name = "TransferInfo")
    protected String transferInfo;
    @XmlElement(name = "FileDescription")
    protected String fileDescription;
    @XmlElement(name = "FileInfo")
    protected String fileInfo;
    @XmlElement(name = "HeaderInfo")
    protected SwAny headerInfo;
    @XmlElement(name = "NotificationResponderDN")
    protected String notificationResponderDN;
    @XmlElement(name = "NotificationRequestType")
    protected String notificationRequestType;
    @XmlElement(name = "FileStartTime")
    protected String fileStartTime;
    @XmlElement(name = "FileEndTime")
    protected String fileEndTime;
    @XmlElement(name = "OverdueWarningTime")
    protected String overdueWarningTime;
    @XmlElement(name = "OverdueWarningDelay")
    protected Integer overdueWarningDelay;
    @XmlElement(name = "RecipientList")
    protected RecipientListType recipientList;
    @XmlElement(name = "ThirdPartyList")
    protected ThirdPartyListType thirdPartyList;
    @XmlElement(name = "IsRecipientListPublic")
    protected Boolean isRecipientListPublic;
    @XmlElement(name = "DistributionInfo")
    protected DistributionInfo distributionInfo;
    @XmlElement(name = "RetrievalInfo")
    protected SwAny retrievalInfo;
    @XmlElement(name = "RequestE2EControl")
    protected SwAny requestE2EControl;
    @XmlElement(name = "RetrievalDescriptor")
    protected SwAny retrievalDescriptor;
    @XmlElement(name = "TSInfoForReceiver")
    protected String tsInfoForReceiver;
    @XmlElement(name = "OrigTransferRef")
    protected String origTransferRef;
    @XmlElement(name = "InformCopyInfo")
    protected SwAny informCopyInfo;

    /**
     * Obtiene el valor de la propiedad requestType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Define el valor de la propiedad requestType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestType(String value) {
        this.requestType = value;
    }

    /**
     * Obtiene el valor de la propiedad requestSubtype.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestSubtype() {
        return requestSubtype;
    }

    /**
     * Define el valor de la propiedad requestSubtype.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestSubtype(String value) {
        this.requestSubtype = value;
    }

    /**
     * Obtiene el valor de la propiedad swiftRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSWIFTRef() {
        return swiftRef;
    }

    /**
     * Define el valor de la propiedad swiftRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSWIFTRef(String value) {
        this.swiftRef = value;
    }

    /**
     * Obtiene el valor de la propiedad snlRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSNLRef() {
        return snlRef;
    }

    /**
     * Define el valor de la propiedad snlRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSNLRef(String value) {
        this.snlRef = value;
    }

    /**
     * Obtiene el valor de la propiedad reference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReference() {
        return reference;
    }

    /**
     * Define el valor de la propiedad reference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReference(String value) {
        this.reference = value;
    }

    /**
     * Obtiene el valor de la propiedad snlEndPoint.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSNLEndPoint() {
        return snlEndPoint;
    }

    /**
     * Define el valor de la propiedad snlEndPoint.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSNLEndPoint(String value) {
        this.snlEndPoint = value;
    }

    /**
     * Obtiene el valor de la propiedad snFQueueName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSnFQueueName() {
        return snFQueueName;
    }

    /**
     * Define el valor de la propiedad snFQueueName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSnFQueueName(String value) {
        this.snFQueueName = value;
    }

    /**
     * Obtiene el valor de la propiedad snFChannelName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSnFChannelName() {
        return snFChannelName;
    }

    /**
     * Define el valor de la propiedad snFChannelName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSnFChannelName(String value) {
        this.snFChannelName = value;
    }

    /**
     * Obtiene el valor de la propiedad snFInputTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSnFInputTime() {
        return snFInputTime;
    }

    /**
     * Define el valor de la propiedad snFInputTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSnFInputTime(String value) {
        this.snFInputTime = value;
    }

    /**
     * Obtiene el valor de la propiedad snFDeliveryTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSnFDeliveryTime() {
        return snFDeliveryTime;
    }

    /**
     * Define el valor de la propiedad snFDeliveryTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSnFDeliveryTime(String value) {
        this.snFDeliveryTime = value;
    }

    /**
     * Obtiene el valor de la propiedad creationTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreationTime() {
        return creationTime;
    }

    /**
     * Define el valor de la propiedad creationTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreationTime(String value) {
        this.creationTime = value;
    }

    /**
     * Obtiene el valor de la propiedad validationDescriptor.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getValidationDescriptor() {
        return validationDescriptor;
    }

    /**
     * Define el valor de la propiedad validationDescriptor.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setValidationDescriptor(SwAny value) {
        this.validationDescriptor = value;
    }

    /**
     * Obtiene el valor de la propiedad responseResponderDN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseResponderDN() {
        return responseResponderDN;
    }

    /**
     * Define el valor de la propiedad responseResponderDN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseResponderDN(String value) {
        this.responseResponderDN = value;
    }

    /**
     * Obtiene el valor de la propiedad responseSWIFTRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseSWIFTRef() {
        return responseSWIFTRef;
    }

    /**
     * Define el valor de la propiedad responseSWIFTRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseSWIFTRef(String value) {
        this.responseSWIFTRef = value;
    }

    /**
     * Obtiene el valor de la propiedad responseSNLRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseSNLRef() {
        return responseSNLRef;
    }

    /**
     * Define el valor de la propiedad responseSNLRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseSNLRef(String value) {
        this.responseSNLRef = value;
    }

    /**
     * Obtiene el valor de la propiedad responseReference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseReference() {
        return responseReference;
    }

    /**
     * Define el valor de la propiedad responseReference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseReference(String value) {
        this.responseReference = value;
    }

    /**
     * Obtiene el valor de la propiedad isPossibleDuplicateResponse.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsPossibleDuplicateResponse() {
        return isPossibleDuplicateResponse;
    }

    /**
     * Define el valor de la propiedad isPossibleDuplicateResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsPossibleDuplicateResponse(Boolean value) {
        this.isPossibleDuplicateResponse = value;
    }

    /**
     * Obtiene el valor de la propiedad responseValidationDescriptor.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getResponseValidationDescriptor() {
        return responseValidationDescriptor;
    }

    /**
     * Define el valor de la propiedad responseValidationDescriptor.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setResponseValidationDescriptor(SwAny value) {
        this.responseValidationDescriptor = value;
    }

    /**
     * Obtiene el valor de la propiedad payloadAttributes.
     * 
     * @return
     *     possible object is
     *     {@link PayloadAttributeList }
     *     
     */
    public PayloadAttributeList getPayloadAttributes() {
        return payloadAttributes;
    }

    /**
     * Define el valor de la propiedad payloadAttributes.
     * 
     * @param value
     *     allowed object is
     *     {@link PayloadAttributeList }
     *     
     */
    public void setPayloadAttributes(PayloadAttributeList value) {
        this.payloadAttributes = value;
    }

    /**
     * Obtiene el valor de la propiedad responsePayloadAttributes.
     * 
     * @return
     *     possible object is
     *     {@link PayloadAttributeList }
     *     
     */
    public PayloadAttributeList getResponsePayloadAttributes() {
        return responsePayloadAttributes;
    }

    /**
     * Define el valor de la propiedad responsePayloadAttributes.
     * 
     * @param value
     *     allowed object is
     *     {@link PayloadAttributeList }
     *     
     */
    public void setResponsePayloadAttributes(PayloadAttributeList value) {
        this.responsePayloadAttributes = value;
    }

    /**
     * Obtiene el valor de la propiedad isCopyRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsCopyRequested() {
        return isCopyRequested;
    }

    /**
     * Define el valor de la propiedad isCopyRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsCopyRequested(Boolean value) {
        this.isCopyRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad isAuthNotificationRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsAuthNotificationRequested() {
        return isAuthNotificationRequested;
    }

    /**
     * Define el valor de la propiedad isAuthNotificationRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsAuthNotificationRequested(Boolean value) {
        this.isAuthNotificationRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad copyInfo.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getCopyInfo() {
        return copyInfo;
    }

    /**
     * Define el valor de la propiedad copyInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setCopyInfo(SwAny value) {
        this.copyInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad transferRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransferRef() {
        return transferRef;
    }

    /**
     * Define el valor de la propiedad transferRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransferRef(String value) {
        this.transferRef = value;
    }

    /**
     * Obtiene el valor de la propiedad storedTransferRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStoredTransferRef() {
        return storedTransferRef;
    }

    /**
     * Define el valor de la propiedad storedTransferRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStoredTransferRef(String value) {
        this.storedTransferRef = value;
    }

    /**
     * Obtiene el valor de la propiedad origSnfRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigSnfRef() {
        return origSnfRef;
    }

    /**
     * Define el valor de la propiedad origSnfRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigSnfRef(String value) {
        this.origSnfRef = value;
    }

    /**
     * Obtiene el valor de la propiedad transferDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransferDescription() {
        return transferDescription;
    }

    /**
     * Define el valor de la propiedad transferDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransferDescription(String value) {
        this.transferDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad transferInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransferInfo() {
        return transferInfo;
    }

    /**
     * Define el valor de la propiedad transferInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransferInfo(String value) {
        this.transferInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad fileDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileDescription() {
        return fileDescription;
    }

    /**
     * Define el valor de la propiedad fileDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileDescription(String value) {
        this.fileDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad fileInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileInfo() {
        return fileInfo;
    }

    /**
     * Define el valor de la propiedad fileInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileInfo(String value) {
        this.fileInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad headerInfo.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getHeaderInfo() {
        return headerInfo;
    }

    /**
     * Define el valor de la propiedad headerInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setHeaderInfo(SwAny value) {
        this.headerInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad notificationResponderDN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotificationResponderDN() {
        return notificationResponderDN;
    }

    /**
     * Define el valor de la propiedad notificationResponderDN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotificationResponderDN(String value) {
        this.notificationResponderDN = value;
    }

    /**
     * Obtiene el valor de la propiedad notificationRequestType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotificationRequestType() {
        return notificationRequestType;
    }

    /**
     * Define el valor de la propiedad notificationRequestType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotificationRequestType(String value) {
        this.notificationRequestType = value;
    }

    /**
     * Obtiene el valor de la propiedad fileStartTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileStartTime() {
        return fileStartTime;
    }

    /**
     * Define el valor de la propiedad fileStartTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileStartTime(String value) {
        this.fileStartTime = value;
    }

    /**
     * Obtiene el valor de la propiedad fileEndTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileEndTime() {
        return fileEndTime;
    }

    /**
     * Define el valor de la propiedad fileEndTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileEndTime(String value) {
        this.fileEndTime = value;
    }

    /**
     * Obtiene el valor de la propiedad overdueWarningTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOverdueWarningTime() {
        return overdueWarningTime;
    }

    /**
     * Define el valor de la propiedad overdueWarningTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOverdueWarningTime(String value) {
        this.overdueWarningTime = value;
    }

    /**
     * Obtiene el valor de la propiedad overdueWarningDelay.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getOverdueWarningDelay() {
        return overdueWarningDelay;
    }

    /**
     * Define el valor de la propiedad overdueWarningDelay.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setOverdueWarningDelay(Integer value) {
        this.overdueWarningDelay = value;
    }

    /**
     * Obtiene el valor de la propiedad recipientList.
     * 
     * @return
     *     possible object is
     *     {@link RecipientListType }
     *     
     */
    public RecipientListType getRecipientList() {
        return recipientList;
    }

    /**
     * Define el valor de la propiedad recipientList.
     * 
     * @param value
     *     allowed object is
     *     {@link RecipientListType }
     *     
     */
    public void setRecipientList(RecipientListType value) {
        this.recipientList = value;
    }

    /**
     * Obtiene el valor de la propiedad thirdPartyList.
     * 
     * @return
     *     possible object is
     *     {@link ThirdPartyListType }
     *     
     */
    public ThirdPartyListType getThirdPartyList() {
        return thirdPartyList;
    }

    /**
     * Define el valor de la propiedad thirdPartyList.
     * 
     * @param value
     *     allowed object is
     *     {@link ThirdPartyListType }
     *     
     */
    public void setThirdPartyList(ThirdPartyListType value) {
        this.thirdPartyList = value;
    }

    /**
     * Obtiene el valor de la propiedad isRecipientListPublic.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsRecipientListPublic() {
        return isRecipientListPublic;
    }

    /**
     * Define el valor de la propiedad isRecipientListPublic.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsRecipientListPublic(Boolean value) {
        this.isRecipientListPublic = value;
    }

    /**
     * Obtiene el valor de la propiedad distributionInfo.
     * 
     * @return
     *     possible object is
     *     {@link DistributionInfo }
     *     
     */
    public DistributionInfo getDistributionInfo() {
        return distributionInfo;
    }

    /**
     * Define el valor de la propiedad distributionInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link DistributionInfo }
     *     
     */
    public void setDistributionInfo(DistributionInfo value) {
        this.distributionInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad retrievalInfo.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getRetrievalInfo() {
        return retrievalInfo;
    }

    /**
     * Define el valor de la propiedad retrievalInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setRetrievalInfo(SwAny value) {
        this.retrievalInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad requestE2EControl.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getRequestE2EControl() {
        return requestE2EControl;
    }

    /**
     * Define el valor de la propiedad requestE2EControl.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setRequestE2EControl(SwAny value) {
        this.requestE2EControl = value;
    }

    /**
     * Obtiene el valor de la propiedad retrievalDescriptor.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getRetrievalDescriptor() {
        return retrievalDescriptor;
    }

    /**
     * Define el valor de la propiedad retrievalDescriptor.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setRetrievalDescriptor(SwAny value) {
        this.retrievalDescriptor = value;
    }

    /**
     * Obtiene el valor de la propiedad tsInfoForReceiver.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTSInfoForReceiver() {
        return tsInfoForReceiver;
    }

    /**
     * Define el valor de la propiedad tsInfoForReceiver.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTSInfoForReceiver(String value) {
        this.tsInfoForReceiver = value;
    }

    /**
     * Obtiene el valor de la propiedad origTransferRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigTransferRef() {
        return origTransferRef;
    }

    /**
     * Define el valor de la propiedad origTransferRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigTransferRef(String value) {
        this.origTransferRef = value;
    }

    /**
     * Obtiene el valor de la propiedad informCopyInfo.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getInformCopyInfo() {
        return informCopyInfo;
    }

    /**
     * Define el valor de la propiedad informCopyInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setInformCopyInfo(SwAny value) {
        this.informCopyInfo = value;
    }

}
