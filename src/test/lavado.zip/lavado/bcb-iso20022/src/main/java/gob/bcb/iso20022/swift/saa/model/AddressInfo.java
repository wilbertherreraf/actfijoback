
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para AddressInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="AddressInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="BIC12" type="{urn:swift:saa:xsd:saa.2.0}BIC12"/&gt;
 *           &lt;element name="DN" type="{urn:swift:saa:xsd:saa.2.0}DN"/&gt;
 *           &lt;element name="Nickname" type="{urn:swift:saa:xsd:saa.2.0}Nickname"/&gt;
 *         &lt;/choice&gt;
 *         &lt;element name="FullName" type="{urn:swift:saa:xsd:saa.2.0}AddressFullName" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddressInfo", propOrder = {
    "nickname",
    "dn",
    "bic12",
    "fullName"
})
public class AddressInfo {

    @XmlElement(name = "Nickname")
    protected String nickname;
    @XmlElement(name = "DN")
    protected String dn;
    @XmlElement(name = "BIC12")
    protected String bic12;
    @XmlElement(name = "FullName")
    protected AddressFullName fullName;

    /**
     * Obtiene el valor de la propiedad nickname.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * Define el valor de la propiedad nickname.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNickname(String value) {
        this.nickname = value;
    }

    /**
     * Obtiene el valor de la propiedad dn.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDN() {
        return dn;
    }

    /**
     * Define el valor de la propiedad dn.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDN(String value) {
        this.dn = value;
    }

    /**
     * Obtiene el valor de la propiedad bic12.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBIC12() {
        return bic12;
    }

    /**
     * Define el valor de la propiedad bic12.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBIC12(String value) {
        this.bic12 = value;
    }

    /**
     * Obtiene el valor de la propiedad fullName.
     * 
     * @return
     *     possible object is
     *     {@link AddressFullName }
     *     
     */
    public AddressFullName getFullName() {
        return fullName;
    }

    /**
     * Define el valor de la propiedad fullName.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressFullName }
     *     
     */
    public AddressInfo setFullName(AddressFullName value) {
        this.fullName = value;
        return this;
    }

}
