
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para NetworkInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="NetworkInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Priority" type="{urn:swift:saa:xsd:saa.2.0}Priority" minOccurs="0"/&gt;
 *         &lt;element name="IsPossibleDuplicate" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="DuplicateHistory" type="{urn:swift:saa:xsd:saa.2.0}PDEPDM" minOccurs="0"/&gt;
 *         &lt;element name="IsNotificationRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="Service" type="{urn:swift:saa:xsd:saa.2.0}Service" minOccurs="0"/&gt;
 *         &lt;element name="Network" type="{urn:swift:saa:xsd:saa.2.0}Network" minOccurs="0"/&gt;
 *         &lt;element name="SessionNr" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="SeqNr" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="TransactionData" type="{urn:swift:saa:xsd:saa.2.0}TransactionData" minOccurs="0"/&gt;
 *         &lt;element name="TranslatedResult" type="{urn:swift:saa:xsd:saa.2.0}TranslatedResult" minOccurs="0"/&gt;
 *         &lt;element name="TranslationResultDetails" type="{urn:swift:saa:xsd:saa.2.0}TranslationResultDetails" minOccurs="0"/&gt;
 *         &lt;element name="E2ESenderInfo" type="{urn:swift:saa:xsd:saa.2.0}E2ESenderInfo" minOccurs="0"/&gt;
 *         &lt;choice minOccurs="0"&gt;
 *           &lt;element name="FINNetworkInfo" type="{urn:swift:saa:xsd:saa.2.0}FINNetworkInfo"/&gt;
 *           &lt;element name="SWIFTNetNetworkInfo" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetNetworkInfo"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkInfo", propOrder = {
    "priority",
    "isPossibleDuplicate",
    "duplicateHistory",
    "isNotificationRequested",
    "service",
    "network",
    "sessionNr",
    "seqNr",
    "transactionData",
    "translatedResult",
    "translationResultDetails",
    "e2ESenderInfo",
    "swiftNetNetworkInfo",
    "finNetworkInfo"
})
public class NetworkInfo {

    @XmlElement(name = "Priority")
    @XmlSchemaType(name = "string")
    protected Priority priority;
    @XmlElement(name = "IsPossibleDuplicate")
    protected Boolean isPossibleDuplicate;
    @XmlElement(name = "DuplicateHistory")
    protected PDEPDM duplicateHistory;
    @XmlElement(name = "IsNotificationRequested")
    protected Boolean isNotificationRequested;
    @XmlElement(name = "Service")
    protected String service;
    @XmlElement(name = "Network")
    @XmlSchemaType(name = "string")
    protected Network network;
    @XmlElement(name = "SessionNr")
    protected Integer sessionNr;
    @XmlElement(name = "SeqNr")
    protected Integer seqNr;
    @XmlElement(name = "TransactionData")
    protected TransactionData transactionData;
    @XmlElement(name = "TranslatedResult")
    @XmlSchemaType(name = "string")
    protected TranslatedResult translatedResult;
    @XmlElement(name = "TranslationResultDetails")
    protected String translationResultDetails;
    @XmlElement(name = "E2ESenderInfo")
    protected String e2ESenderInfo;
    @XmlElement(name = "SWIFTNetNetworkInfo")
    protected SWIFTNetNetworkInfo swiftNetNetworkInfo;
    @XmlElement(name = "FINNetworkInfo")
    protected FINNetworkInfo finNetworkInfo;

    /**
     * Obtiene el valor de la propiedad priority.
     * 
     * @return
     *     possible object is
     *     {@link Priority }
     *     
     */
    public Priority getPriority() {
        return priority;
    }

    /**
     * Define el valor de la propiedad priority.
     * 
     * @param value
     *     allowed object is
     *     {@link Priority }
     *     
     */
    public void setPriority(Priority value) {
        this.priority = value;
    }

    /**
     * Obtiene el valor de la propiedad isPossibleDuplicate.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsPossibleDuplicate() {
        return isPossibleDuplicate;
    }

    /**
     * Define el valor de la propiedad isPossibleDuplicate.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsPossibleDuplicate(Boolean value) {
        this.isPossibleDuplicate = value;
    }

    /**
     * Obtiene el valor de la propiedad duplicateHistory.
     * 
     * @return
     *     possible object is
     *     {@link PDEPDM }
     *     
     */
    public PDEPDM getDuplicateHistory() {
        return duplicateHistory;
    }

    /**
     * Define el valor de la propiedad duplicateHistory.
     * 
     * @param value
     *     allowed object is
     *     {@link PDEPDM }
     *     
     */
    public void setDuplicateHistory(PDEPDM value) {
        this.duplicateHistory = value;
    }

    /**
     * Obtiene el valor de la propiedad isNotificationRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsNotificationRequested() {
        return isNotificationRequested;
    }

    /**
     * Define el valor de la propiedad isNotificationRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsNotificationRequested(Boolean value) {
        this.isNotificationRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad service.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getService() {
        return service;
    }

    /**
     * Define el valor de la propiedad service.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setService(String value) {
        this.service = value;
    }

    /**
     * Obtiene el valor de la propiedad network.
     * 
     * @return
     *     possible object is
     *     {@link Network }
     *     
     */
    public Network getNetwork() {
        return network;
    }

    /**
     * Define el valor de la propiedad network.
     * 
     * @param value
     *     allowed object is
     *     {@link Network }
     *     
     */
    public void setNetwork(Network value) {
        this.network = value;
    }

    /**
     * Obtiene el valor de la propiedad sessionNr.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSessionNr() {
        return sessionNr;
    }

    /**
     * Define el valor de la propiedad sessionNr.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSessionNr(Integer value) {
        this.sessionNr = value;
    }

    /**
     * Obtiene el valor de la propiedad seqNr.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSeqNr() {
        return seqNr;
    }

    /**
     * Define el valor de la propiedad seqNr.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSeqNr(Integer value) {
        this.seqNr = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionData.
     * 
     * @return
     *     possible object is
     *     {@link TransactionData }
     *     
     */
    public TransactionData getTransactionData() {
        return transactionData;
    }

    /**
     * Define el valor de la propiedad transactionData.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionData }
     *     
     */
    public void setTransactionData(TransactionData value) {
        this.transactionData = value;
    }

    /**
     * Obtiene el valor de la propiedad translatedResult.
     * 
     * @return
     *     possible object is
     *     {@link TranslatedResult }
     *     
     */
    public TranslatedResult getTranslatedResult() {
        return translatedResult;
    }

    /**
     * Define el valor de la propiedad translatedResult.
     * 
     * @param value
     *     allowed object is
     *     {@link TranslatedResult }
     *     
     */
    public void setTranslatedResult(TranslatedResult value) {
        this.translatedResult = value;
    }

    /**
     * Obtiene el valor de la propiedad translationResultDetails.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranslationResultDetails() {
        return translationResultDetails;
    }

    /**
     * Define el valor de la propiedad translationResultDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranslationResultDetails(String value) {
        this.translationResultDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad e2ESenderInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getE2ESenderInfo() {
        return e2ESenderInfo;
    }

    /**
     * Define el valor de la propiedad e2ESenderInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setE2ESenderInfo(String value) {
        this.e2ESenderInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad swiftNetNetworkInfo.
     * 
     * @return
     *     possible object is
     *     {@link SWIFTNetNetworkInfo }
     *     
     */
    public SWIFTNetNetworkInfo getSWIFTNetNetworkInfo() {
        return swiftNetNetworkInfo;
    }

    /**
     * Define el valor de la propiedad swiftNetNetworkInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SWIFTNetNetworkInfo }
     *     
     */
    public NetworkInfo setSWIFTNetNetworkInfo(SWIFTNetNetworkInfo value) {
        this.swiftNetNetworkInfo = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad finNetworkInfo.
     * 
     * @return
     *     possible object is
     *     {@link FINNetworkInfo }
     *     
     */
    public FINNetworkInfo getFINNetworkInfo() {
        return finNetworkInfo;
    }

    /**
     * Define el valor de la propiedad finNetworkInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link FINNetworkInfo }
     *     
     */
    public void setFINNetworkInfo(FINNetworkInfo value) {
        this.finNetworkInfo = value;
    }

}
