
package gob.bcb.iso20022.swift.saa.model;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para DigestList complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DigestList"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Digest" type="{urn:swift:saa:xsd:saa.2.0}Digest" maxOccurs="8"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DigestList", propOrder = {
    "digests"
})
public class DigestList {

    @XmlElement(name = "Digest", required = true)
    protected List<Digest> digests;

    /**
     * Gets the value of the digests property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the digests property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDigests().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Digest }
     * 
     * 
     */
    public List<Digest> getDigests() {
        if (digests == null) {
            digests = new ArrayList<Digest>();
        }
        return this.digests;
    }

}
