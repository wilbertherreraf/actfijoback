
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Digest complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Digest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DigestRef" type="{urn:swift:saa:xsd:saa.2.0}DigestRef"/&gt;
 *         &lt;element name="DigestValue" type="{urn:swift:saa:xsd:saa.2.0}DigestValue" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Digest", propOrder = {
    "digestRef",
    "digestValue"
})
public class Digest {

    @XmlElement(name = "DigestRef", required = true)
    protected String digestRef;
    @XmlElement(name = "DigestValue")
    protected String digestValue;

    /**
     * Obtiene el valor de la propiedad digestRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDigestRef() {
        return digestRef;
    }

    /**
     * Define el valor de la propiedad digestRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDigestRef(String value) {
        this.digestRef = value;
    }

    /**
     * Obtiene el valor de la propiedad digestValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDigestValue() {
        return digestValue;
    }

    /**
     * Define el valor de la propiedad digestValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDigestValue(String value) {
        this.digestValue = value;
    }

}
