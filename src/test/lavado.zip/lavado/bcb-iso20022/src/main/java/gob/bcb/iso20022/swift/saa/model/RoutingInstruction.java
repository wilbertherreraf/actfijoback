
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para RoutingInstruction complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RoutingInstruction"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RoutingFunction" type="{urn:swift:saa:xsd:saa.2.0}RoutingFunction"/&gt;
 *         &lt;element name="RoutingPoint" type="{urn:swift:saa:xsd:saa.2.0}RoutingPoint" minOccurs="0"/&gt;
 *         &lt;element name="RoutingStep" type="{urn:swift:saa:xsd:saa.2.0}RoutingStep" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RoutingInstruction", propOrder = {
    "routingFunction",
    "routingPoint",
    "routingStep"
})
public class RoutingInstruction {

    @XmlElement(name = "RoutingFunction", required = true)
    @XmlSchemaType(name = "string")
    protected RoutingFunction routingFunction;
    @XmlElement(name = "RoutingPoint")
    protected String routingPoint;
    @XmlElement(name = "RoutingStep")
    @XmlSchemaType(name = "string")
    protected RoutingStep routingStep;

    /**
     * Obtiene el valor de la propiedad routingFunction.
     * 
     * @return
     *     possible object is
     *     {@link RoutingFunction }
     *     
     */
    public RoutingFunction getRoutingFunction() {
        return routingFunction;
    }

    /**
     * Define el valor de la propiedad routingFunction.
     * 
     * @param value
     *     allowed object is
     *     {@link RoutingFunction }
     *     
     */
    public void setRoutingFunction(RoutingFunction value) {
        this.routingFunction = value;
    }

    /**
     * Obtiene el valor de la propiedad routingPoint.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoutingPoint() {
        return routingPoint;
    }

    /**
     * Define el valor de la propiedad routingPoint.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoutingPoint(String value) {
        this.routingPoint = value;
    }

    /**
     * Obtiene el valor de la propiedad routingStep.
     * 
     * @return
     *     possible object is
     *     {@link RoutingStep }
     *     
     */
    public RoutingStep getRoutingStep() {
        return routingStep;
    }

    /**
     * Define el valor de la propiedad routingStep.
     * 
     * @param value
     *     allowed object is
     *     {@link RoutingStep }
     *     
     */
    public void setRoutingStep(RoutingStep value) {
        this.routingStep = value;
    }

}
