package gob.bcb.iso20022.transforms;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.rules.AbstractAction;
import gob.bcb.iso20022.rules.Action;
import gob.bcb.iso20022.rules.CompiledRule;
import gob.bcb.iso20022.swift.MappingRule;

/**
 * @author: wherrera
 * 
 */
public class GenListRulesTransform extends AbstractAction<MappingRule, CampoForm> {
	private final Logger log = LoggerFactory.getLogger(getClass());
	public final static String name = TransformEnum.GENLIST.toString();;

	public GenListRulesTransform() {
		super(name);		
	}
	
	@Override
	protected CampoForm initializeOutputResult(CompiledRule rule, MappingRule input) {
		CampoForm cf = new CampoForm();
		return cf;
	}

	@Override
	public CampoForm execute(CompiledRule rule, MappingRule input, Map<String, Object> facts) {
		input.getMapFacts().forEach((k,v) -> {
			if (!StringUtils.isBlank(k) && v != null)
				facts.putIfAbsent(k, v);
		});
		
		return null;
	}
	
	@Override
	public void postExecuteAction(CompiledRule rule, MappingRule input, CampoForm output, Map<String, Object> facts) {
		if (output != null && output.getValorObj() != null) {
			if (output.getValorObj() instanceof CampoForm) {
				SwfMencampos swfCampo = input.getSwfCampo();

				CampoForm cfo = (CampoForm) output.getValorObj();
				cfo.setTabla(rule.getRule().getNamespace());
				cfo.setColumn(rule.getRule().getName());
				cfo.setCatalogo(swfCampo.getMtfXmltag());

				Integer idx = swfCampo != null && swfCampo.getMtfGrpopt() != null ? swfCampo.getMtfGrpopt() :(input.getCampos().size() + 1);
				
				idx = idx.compareTo( 0) <= 0 ? 1 : idx;
				
				cfo.setCatalogo(swfCampo.getMtfXmltag().trim() + "[" + idx +"]");
//				log.info("list " + rule.getRule().getFullyQualifiedName() + " " + cfo.getValor() + " " + cfo.getCatalogo());
				input.addCampo(cfo);
			}
		}		
		
	}

	@Override
	public void postExecuteSubAction(CompiledRule rule, Action sAction, MappingRule input, CampoForm output, Map<String, Object> facts) {
		CampoForm cfo = new CampoForm();
		cfo.setTabla(rule.getRule().getNamespace());
		cfo.setColumn(rule.getRule().getName());
		cfo.setCatalogo(rule.getRule().getPath() + "[" + (input.getCampos().size() + 1) +"]");
		cfo.setValor(output.getValor());

		input.addCampo(cfo);
	}

}
