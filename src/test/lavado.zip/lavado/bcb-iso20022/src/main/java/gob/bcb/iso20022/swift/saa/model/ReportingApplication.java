
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ReportingApplication.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="ReportingApplication"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="ApplicationInterface"/&gt;
 *     &lt;enumeration value="SWIFTNetInterface"/&gt;
 *     &lt;enumeration value="FINInterface"/&gt;
 *     &lt;enumeration value="TrafficReconciliation"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ReportingApplication")
@XmlEnum
public enum ReportingApplication {

    @XmlEnumValue("ApplicationInterface")
    APPLICATION_INTERFACE("ApplicationInterface"),
    @XmlEnumValue("SWIFTNetInterface")
    SWIFT_NET_INTERFACE("SWIFTNetInterface"),
    @XmlEnumValue("FINInterface")
    FIN_INTERFACE("FINInterface"),
    @XmlEnumValue("TrafficReconciliation")
    TRAFFIC_RECONCILIATION("TrafficReconciliation"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    ReportingApplication(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ReportingApplication fromValue(String v) {
        for (ReportingApplication c: ReportingApplication.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
