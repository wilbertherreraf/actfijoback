package gob.bcb.iso20022.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class UtilsFile {
	private static final Logger log = LoggerFactory.getLogger(UtilsFile.class);
	public static String readFileAsString(String filePath) throws java.io.IOException {
		String result = null;
		BufferedReader reader = null;
		try {
			StringBuffer fileData = new StringBuffer(1000);
			reader = new BufferedReader(new FileReader(filePath));
			char[] buf = new char[1024];
			int numRead = 0;
			while ((numRead = reader.read(buf)) != -1) {
				fileData.append(buf, 0, numRead);
			}
			reader.close();
			result = fileData.toString();
		} finally {
			try {
				reader.close();
			} catch (Exception e) {
				// no hacer nada
			}
		}
		return result;
	}

	public static String readFileAsString2(String filePath) {
		String result = null;
		File h = new File(filePath);
		if (!h.exists()) {
			throw new RuntimeException("Archivo inexistente " + filePath);
		}
		try {
			InputStream is = new FileInputStream(h);
			result = IOUtils.toString(is, "ISO-8859-1");
			is.close();
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Archivo inexistente " + filePath);
		} catch (IOException e) {
			throw new RuntimeException("Error al leer " + filePath);
		}
		return result;
	}

	public static String copy(String filePath, String filePathO) throws IOException {
		FileReader fr = new FileReader(filePath);
		FileOutputStream archResp = new FileOutputStream(filePathO);
		IOUtils.copy(fr, archResp);
		fr.close();
		archResp.close();

		fr = new FileReader(filePath);
		FileReader fr2 = new FileReader(filePathO);
		boolean b = IOUtils.contentEquals(fr, fr2);

		fr.close();
		archResp.close();

		InputStream is = new FileInputStream(new File(filePath));
		InputStream iso = new FileInputStream(new File(filePathO));
		b = IOUtils.contentEquals(is, iso);

		is.close();
		iso.close();

		is = new FileInputStream(new File(filePath));

		OutputStream os = new FileOutputStream(new File(filePathO));
		IOUtils.copy(is, os);

		is.close();
		os.close();

		is = new FileInputStream(new File(filePath));
		iso = new FileInputStream(new File(filePathO));
		b = IOUtils.contentEquals(is, iso);

		is.close();
		iso.close();

		return null;
	}

	public static String copiarArchivo(String fileSource, String fileTarget, boolean compareFiles) throws IOException {
		InputStream is = new FileInputStream(new File(fileSource));
		OutputStream os = new FileOutputStream(new File(fileTarget));
		try {
			int resp = IOUtils.copy(is, os);
		} finally {

			os.close();
			is.close();
		}

		if (compareFiles) {
			InputStream isin = new FileInputStream(new File(fileSource));
			InputStream iso = new FileInputStream(new File(fileTarget));
			boolean b = IOUtils.contentEquals(isin, iso);

			isin.close();
			iso.close();
		}

		return fileTarget;
		// } catch (Exception e) {
		// log.error("Exception al salvar archivo " + fileSource, e);
		// throw new RuntimeException(e.getMessage(), e);
		// }
	}

	public static String grabaEnArchivo(String mensaje, String path) throws RuntimeException {
		log.info("grabaEnArchivo: path " + path);
		FileOutputStream archResp = null;
		try {
			File d = new File(path);
			String directory = d.getParent();
			d = new File(directory);
			d.mkdirs();

			archResp = new FileOutputStream(path);
			byte buffer[] = mensaje.getBytes("ISO-8859-1");
			archResp.write(buffer);
			archResp.close();

			File h = new File(path);
			if (!h.exists() || h.isDirectory()) {
				throw new RuntimeException("Archivo no fue creado " + path);
			}
			log.debug("Archivo salvado " + h.getAbsolutePath());
			return h.getCanonicalPath();
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}

	}

	public static void grabaEnArchivo2(final String mensaje, String path) {
		byte[] pContent = mensaje.getBytes();
		try (FileOutputStream out = new FileOutputStream(path)) {
			out.write(pContent);
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}
	
	public static String grabaStringEnArchivo(String mensaje, String path) {
		log.info("Guardando cadena en archivo " + path);
		InputStream is = IOUtils.toInputStream(mensaje);
		String pathNew = grabaEnArchivo(is, path);
		return pathNew;
	}

	public static String grabaEnArchivo(List<String> lineas, String path) throws IOException {
		File d = new File(path);
		String directory = d.getParent();
		d = new File(directory);
		d.mkdirs();
		File h = new File(path);
		
		try (final FileWriter writer = new FileWriter(path)) {
			for(String l : lineas){
				//byte buffer[] = l.getBytes("ISO-8859-1");
				writer.append(l + System.lineSeparator());				
			}
		}
		return h.getCanonicalPath();
	}

	public static String grabaEnArchivo(InputStream is, String path) throws RuntimeException {
		FileOutputStream archResp = null;
		try {
			log.info("Salvando archivo " + path);
			File d = new File(path);
			String directory = d.getParent();
			d = new File(directory);
			d.mkdirs();

			archResp = new FileOutputStream(path);
			int resp = IOUtils.copy(is, archResp);
			File h = new File(path);
			if (!h.exists() || h.isDirectory()) {
				throw new RuntimeException("Archivo no fue creado " + path);
			}
			return path;
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Archivo no encontrado " + path, e);
		} catch (IOException e) {
			throw new RuntimeException("Archivo no fue creado " + path, e);
		} catch (Exception e) {
			throw new RuntimeException("Archivo no fue creado " + path, e);
		} finally {
			if (archResp != null) {
				try {
					archResp.close();
				} catch (IOException e) {
					log.warn("Error al cerrar stream " + e.getMessage());
				}
			}
		}

	}

	public static String getBasedir() {
		String basedirPath = System.getProperty("basedir");
		if (basedirPath == null) {
			basedirPath = new File("").getAbsolutePath();
		}

		return basedirPath;
	}

	public static List<String> listFilesForFolder(final File folder) {
		List<String> files = new ArrayList<String>();
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				log.debug(fileEntry.getName());
				files.add(fileEntry.getAbsolutePath());
			}
		}
		return files;
	}

	public static List<File> listFilesForFolders(List<String> folders) {

		List<File> files = folders.stream().map(folder -> folder).map(folder -> new File(folder).listFiles()).filter(list -> list != null)//
				.flatMap(fils -> Stream.of(fils)).map(f -> f).filter(file -> file.isFile()).collect(Collectors.toList());
		return files;

	}

	public static String mover(String origen, String destino) {

		Path pathOrigen = Paths.get(origen);
		Path pathDestino = Paths.get(destino);
		
		File d = new File(destino);
		String directory = d.getParent();
		d = new File(directory);
		d.mkdirs();

		try {
			Path target = Files.move(pathOrigen, pathDestino, StandardCopyOption.REPLACE_EXISTING);
			log.info("Archivo movido: " + origen + " -> " + destino);
			return target.toFile().getAbsolutePath();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static List<File> filesDir(String dirBloo) {
		if (dirBloo == null || dirBloo.isEmpty()) {
			return new ArrayList<File>();
		}
		File ff = new File(dirBloo);

		if (!ff.isDirectory() || !ff.exists()) {
			return new ArrayList<File>(); 
			// throw new RuntimeException("Directorio " + dirBloo +" inexistente.");
		}
		String dirBlooAux = ff.getAbsolutePath();

		List<File> files = listFilesForFolders(Arrays.asList(dirBlooAux));
		return files;
	}	
	public static byte[] copyToByteArray(String pathFile) throws IOException {
		InputStream is = new FileInputStream(new File(pathFile));
		return copyToByteArray(is);
	}

	public static byte[] copyToByteArray(InputStream is) throws IOException {
		byte[] data = IOUtils.toByteArray(is);// FileCopyUtils.copyToByteArray(f);
		return data;
	}

	public static void copiarArchivos(File origen, File destino) throws FileNotFoundException, IOException {
		InputStream in = new FileInputStream(origen);
		OutputStream out = new FileOutputStream(destino);

		byte[] buf = new byte[1024];
		int len;
		while ((len = in.read(buf)) > 0) {
			out.write(buf, 0, len);
		}
		in.close();
		out.close();
	}

    public static InputStream inputStreamResource(final String resource, Class<?> clazz) throws Exception {
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(resource);
        if (is == null && clazz != null) {
            // if not found we fallback with this loading object classloader
            is = clazz.getClassLoader().getResourceAsStream(resource);
        }
        return is;
    }	
	public static void main(String[] args) throws IOException {
		List<File> files0 = listFilesForFolders(Arrays.asList("e:/opt/aplicaciones/iacos/archivos", "e:/opt/aplicaciones/iacos/archivos_trades"));
		files0.stream().forEach(f -> {
			System.out.println(f.getAbsolutePath());
		});

	}
}
