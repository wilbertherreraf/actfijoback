package gob.bcb.iso20022.swift;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.AbstractMessage;
import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.LogicalTerminalAddress;
import com.prowidesoftware.swift.model.SwiftBlock1;
import com.prowidesoftware.swift.model.SwiftBlock2Input;
import com.prowidesoftware.swift.model.SwiftBlock3;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.SwiftMessageUtils;
import com.prowidesoftware.swift.model.SwiftTagListBlock;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field16S;
import com.prowidesoftware.swift.model.mt.AbstractMT;

import gob.bcb.iso20022.commons.Constants;
import gob.bcb.iso20022.exceptions.DataValidationSwitfException;
import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.CodNemoCompo;
import gob.bcb.iso20022.pojo.Node;
import gob.bcb.iso20022.pojo.Tree;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.parser.SwiftMessageMT;
import gob.bcb.iso20022.translate.FormatEngine;
import gob.bcb.iso20022.utils.ValidatorCodes;

/**
 * @author: wherrera
 * 
 */
public abstract class FieldSwfMt extends FieldSwf {
	private static final Logger log = LoggerFactory.getLogger(FieldSwfMt.class);
	Node<SwfMencampos> nodesTree;
	private static final Pattern pattern = Pattern.compile("[0-9]{3}");

	Function<SwfMencampos, Optional<Function<SwfMencampos, Optional<Field>>>> getFuncCreateField = TemplateGenFSwf
			.getFuncCreateField(FieldsCommand.mapFieldFunc);

	Function<SwfMencampos, Optional<Function<SwfMencampos, Optional<Function<SwiftTagListBlock, SwiftTagListBlock>>>>> getCreateFuncSeq = swfMencampos -> Optional
			.ofNullable(FieldsCommand.mapSequenceFunc.get(swfMencampos.getMtfCodcampo()));

	@Override
	public String generateMsg() {
		SwiftBlock4 rootMT = instruccion.getBlock4();

		if (rootMT.getTags() == null || rootMT.getTags().size() == 0) {
			throw new DataValidationSwitfException("Generando MT: Bloque 4 MT sin datos para " + instruccion.getSwfMsgParam().getMenIdTMessageTx());
		}

		SwfMsgParam swfMsgParam = instruccion.getSwfMsgParam();

		log.info("===oooOO CREANDO MT[" + swfMsgParam.getMenIdTMessageTx() + "] OOooo=== ");
		AbstractMT mt = AbstractMT.create(Integer.valueOf(swfMsgParam.getMenTypemessage()), swfMsgParam.getMenEmisor(), swfMsgParam.getMenReceiver());
		settingHdr(mt);
		
		SwiftMessage swiftMessage = new SwiftMessage(true);
		swiftMessage.setBlock1(mt.getSwiftMessage().getBlock1());
		swiftMessage.setBlock2(mt.getSwiftMessage().getBlock2());
		swiftMessage.setBlock3(mt.getSwiftMessage().getBlock3());
		swiftMessage.setBlock4(rootMT);
		
		mt = swiftMessage.toMT();
		String msgPlano = mt.message();

		SwiftMessageAbstract sma = new SwiftMessageMT(msgPlano);
		sma.setTypeMessage(instruccion.getSwfMsgParam().getMenTypemessage());
		sma.createMsg();

		instruccion.setMessageHolder(sma);
		
		if (StringUtils.isBlank(sma.getMenPlano())) {
			throw new DataValidationSwitfException("No se pudo crear mensaje Swift MT ");
		}		
		log.info("MT generado " + instruccion.getSwfMsgParam().getMenIdTMessageTx());
		return sma.getMenPlano();
	}
	
	public void registerFactsDef() {
		FieldsCommand.mapFuncs().forEach((k, v) -> {
			instruccion.getMappingTable().putFact(k, v);
		});		
	}
	
	public void translate() {
		if (nodesTree != null && nodesTree.getChildArray().size() > 0) {
			log.info("Datos campos) Facts:\n" + instruccion.getMsi().hdrs()+ "\n" +instruccion.getMsi().toStringSH());
			SwiftTagListBlock stbResult = calculateFields(instruccion, nodesTree);
			// printTagsSTB(stbResult);
			stbResult.getTags().forEach(tag -> {
				instruccion.getBlock4().append(tag);
			});
		}
	}
	
	public void translatePost() {
		if (instruccion.getMapTableResult().noExecs().size() > 0) {
			log.warn("No calculados: ", instruccion.getMapTableResult().noExecs().size());
			instruccion.getMapTableResult().noExecs().forEach(r -> {
				log.info(r.getFullyQualifiedName() + " " + r.getPath() + " " + r.getAction());
			});
		}
	}
	
	public void generaHeaderMsg() {

	}

	public void recuperarSwfCampos(String typeMessage, String bloque) {
		log.info("===oooOO CREANDO MX[" + typeMessage + ":"+bloque+" ] OOooo=== ");
		nodesTree = genTreeNodes(typeMessage, bloque);

		if (nodesTree.getChildArray().size() == 0) {
			log.warn("Consulta de campos swift no retorna registros para MT: " + typeMessage + " bloque: " + bloque);
			return;
		}
		LinkedHashMap<Integer, SwfMencampos> treeCampos = new LinkedHashMap<Integer, SwfMencampos>();

		recTreeCampos(nodesTree, treeCampos);
		log.info("Campos recuperados {} - {} regs. {}", typeMessage, bloque, treeCampos.size());

		instruccion.setTreeMencampos(treeCampos);
	}

	public void settingHdr(AbstractMessage mta) {
		AbstractMT mt = (AbstractMT) mta;
		SwfMsgParam swfMsgParam = instruccion.getSwfMsgParam();

		String mttCodttransfer = swfMsgParam.getMenIdTMessageTx();
		String bicsender = swfMsgParam.getMenEmisor();
		String bicReceiver = swfMsgParam.getMenReceiver();

		log.info("Inicio llenar Block1 y 2 " + mttCodttransfer + " bicReceiver : " + bicReceiver);
		String codmt = instruccion.getSwfMsgParam().getMenTypemessage();

		String applicationId = getParam(mttCodttransfer, Constants.CODCAMPO_IDAPP, null, 0, "1");
		String serviceId = getParam(mttCodttransfer, Constants.CODCAMPO_SERVID, null, 0, "1");

		String logicalTerminal = getLogicalTerminal(mttCodttransfer);

		String sessionNumber = getParam(mttCodttransfer, Constants.CODCAMPO_SESSNUM, null, 0, "1");
		String sequenceNumber = getParam(mttCodttransfer, Constants.CODCAMPO_SEQNUM, null, 0, "1");

		log.info("Preparando mensaje mt " + applicationId + "-" + serviceId + "-" + logicalTerminal + "-" + sessionNumber + "-" + sequenceNumber);

		String messagePriority = getParam(mttCodttransfer, Constants.CODCAMPO_PRIORITY, null, 0, "2");

		SwiftMessage sm = createBlock1(codmt, applicationId, serviceId, logicalTerminal, sessionNumber, sequenceNumber, bicsender, bicReceiver,
				messagePriority);

		List<SwfMencampos> campos = getSwfMencamposIsoDao().findByMT(mttCodttransfer, "3");
		campos.stream().filter(c -> !StringUtils.isBlank(c.getMtfDefault())).forEach(c -> {
			Tag tag = new Tag(c.getMtfCodcampo(), c.getMtfDefault());
			sm.getBlock3().append(tag);
		});

		mt.setSwiftMessage(sm);
	}

	private String getLogicalTerminal(String dttCodttransfer) {
//		log.info("Obteniendo LogicalTerminal dttCodttransfer: " + dttCodttransfer);

		String lTIdentifier = getParam(dttCodttransfer, Constants.CODCAMPO_LTERMINAL, null, 0, "1");

		LogicalTerminalAddress logicalTerminalAddress = new LogicalTerminalAddress(instruccion.getSwfMsgParam().getMenEmisor());
		logicalTerminalAddress.setLTIdentifier(lTIdentifier.charAt(0));
		return logicalTerminalAddress.getSenderLogicalTerminalAddress();
	}

	private String getParam(String mtfCodmt, String mtfCodcampo, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		List<SwfMencampos> campos = getSwfMencamposIsoDao().findByCodigoBlk(mtfCodmt, mtfCodcampo, mtfNro, mtfGrpopt, mtfBloque);
		if (campos.size() == 0) {
			throw new DataValidationSwitfException("Parámetro " + mtfCodmt + " : " + mtfCodcampo + " : " + mtfBloque + " no registrado en swfCampos.");
		}
		String valor = campos.get(0).getMtfDefault().trim();
		if (StringUtils.isBlank(valor))
			throw new DataValidationSwitfException(
					"Parámetro " + mtfCodmt + " : " + mtfCodcampo + " : " + mtfBloque + " con valor por defecto nulo en swfCampos.");
		return valor;
	}

	public void dataValidation() {
		super.dataValidation();

		SwfMsgParam swfMsgParam = instruccion.getSwfMsgParam();

		if (FileFormat.valueOf(swfMsgParam.getMenFormato()) != FileFormat.MT)
			throw new DataValidationSwitfException("Formato debe ser " + FileFormat.MT.toString());

		final Matcher matcher = pattern.matcher(swfMsgParam.getMenTypemessage());
		if (!matcher.matches())
			throw new DataValidationSwitfException("TypeMessage MT no cumple el formato base establecido " + swfMsgParam.getMenTypemessage());
	}

	public SwiftTagListBlock calculateFields(Instruccion instruccion, Node<SwfMencampos> nodeSwfCampo) {
		SwiftTagListBlock stbResult = new SwiftTagListBlock();
		SwfMencampos swfMencampos = nodeSwfCampo.getSwfMencampos();
		
		if (!nodeSwfCampo.hasParent()) {
			log.info("ROOT: " + swfMencampos.toStringID() + " " + swfMencampos.getMtfNemo() + " childs " + nodeSwfCampo.getChildArray().size());
			for (Node<SwfMencampos> child : nodeSwfCampo.getChildArray()) {
				SwiftTagListBlock stbRes = calculateFields(instruccion, child);
				stbResult.append(stbRes);
			}
			log.info("======== ROOT " + swfMencampos.toStringID() + " ==========");
			printTagsSTB(stbResult);
		} else {
			log.info("**>>>Evaluando: " + swfMencampos.toStringID() + " : " + swfMencampos.getMtfNemo() + ", childs " + nodeSwfCampo.getChildArray().size());

			if (iniSequence().test(swfMencampos)) {
				Optional<Function<SwfMencampos, Optional<Function<SwiftTagListBlock, SwiftTagListBlock>>>> createSeqFOpt = getCreateFuncSeq
						.apply(swfMencampos);

				if (!createSeqFOpt.isPresent()) {
					throw new RuntimeException(
							"Funcion no declarada en getCreateFuncSeq de sequencias para " + swfMencampos.toStringID() + " : " + swfMencampos.getMtfNemo());
				}

				Optional<Function<SwiftTagListBlock, SwiftTagListBlock>> createSequenceOpt = createSeqFOpt.get().apply(swfMencampos);
				if (!createSequenceOpt.isPresent()) {
					throw new RuntimeException(
							"Funcion no registrada en mapa Secuencias para " + swfMencampos.toStringID() + " : " + swfMencampos.getMtfNemo());
				}

				SwiftTagListBlock stbResultSeq = new SwiftTagListBlock();

				for (Node<SwfMencampos> child : nodeSwfCampo.getChildArray()) {
					SwiftTagListBlock stbRes = calculateFields(instruccion, child);
					stbResultSeq.append(stbRes);
				}
				SwiftTagListBlock swfTLB = createSequenceOpt.get().apply(stbResultSeq);

				if (stbResultSeq.size() == 0) {
					if (mandatoryCampoYPadre().test(nodeSwfCampo)) {
						log.error("SECUENCIA SIN VALORES: " + swfMencampos.toStringID() + ": " + swfMencampos.getMtfNemo() + " "
								+ (nodeSwfCampo.hasParent() ? ((SwfMencampos) nodeSwfCampo.getParent().getSwfMencampos()).toStringID() : "")
								+ " subcomponentes no produjeron ningun valor.");
					}
					return stbResultSeq;
				}
				stbResult.append(swfTLB);
			} else if (finSequence().test(swfMencampos)) {
				return stbResult;
			} else {
				if (nodeSwfCampo.getChildArray().size() > 0) {
					throw new RuntimeException("Error en la recuperacions de nodos campos, Funcion para " + swfMencampos.toStringID() + " : "
							+ swfMencampos.getMtfNemo() + " no debe tener hijos.");
				}

				List<SwfMencampos> grupoOpcionRepeList = opcionCmpValida().apply(swfMencampos);

				if (grupoOpcionRepeList.size() == 0) {
					if (mandatoryCampoYPadre().test(nodeSwfCampo)) {
						log.error("Campo obligatorio sin opcion seleccionada " + swfMencampos.toStringID() + " PADRE: "
								+ ((SwfMencampos) nodeSwfCampo.getParent().getSwfMencampos()).toStringID());
					}
					log.warn("Lista de campos " + swfMencampos.toStringID() + " SIN REGISTROS.");
					return stbResult;
				}

				FormatEngine fEngine = FormatEngine.getInstance().readRulesExt(instruccion.getSwfMsgParam().getMenTypemessage(), grupoOpcionRepeList,
						instruccion.getSwfMsgParam().getMenFormato());
				try {
					instruccion.getMappingTable().putFact(FACT_SWFCMP, swfMencampos);
					fEngine.initEngineRules();
					MappingTable mpptab = fEngine.translate(instruccion.getMappingTable(), true);

					for (MappingRule m : mpptab.getMappingRuleList()) {
						instruccion.getMapTableResult().getMappingRuleList().add(m);
						for (CampoForm mr : m.getCampos()) {
							if (mr.getValorObj() != null && mr.getValorObj() instanceof Field) {
								Field f = (Field) mr.getValorObj();
								stbResult.append(f);
							}
						}
					}
				} catch (Exception e) {
					log.error("Error al evaluar reglas " + e.getMessage());
					throw new RuntimeException(e);
				}

				if (stbResult.size() == 0) {
					if (mandatoryCampoYPadre().test(nodeSwfCampo)) {
						CodNemoCompo codNemoCompo = TemplateGenFSwf.builtFromNemoCodCmpF.apply(grupoOpcionRepeList.get(0).getMtfNemo(), null);

						String label = grupoOpcionRepeList.get(0).getMtfDescrip();
						String errorMsg = "ERROR: Campo(s) requerido: " + grupoOpcionRepeList.get(0).toStringID() + ", Nemo: "
								+ grupoOpcionRepeList.get(0).getMtfNemo() + " "
								+ (nodeSwfCampo.hasParent() ? ", PADRE: " + ((SwfMencampos) nodeSwfCampo.getParent().getSwfMencampos()).toStringID() : "")
								+ " Campo: [" + codNemoCompo.getCodCampoNL() + "] " + label + ", revise los datos o avise al administrador.";
						log.error(errorMsg);
						throw new RuntimeException(errorMsg);
					}
				}
				//stbResult.append(stbRes);
			}
		}

		return stbResult;
	}

	public Node<SwfMencampos> genTreeNodes(String typeMsgTx, String bloque) {
		Node<SwfMencampos> padre = Node.createNodeDefault(typeMsgTx, bloque);

		Function<SwfMencampos, Optional<Supplier<Node>>> nextSwfMencamposF = nextSwfMencampos(null, padre);
		Node<SwfMencampos> nodeResult = generateTreeSwfCampos(null, nextSwfMencamposF);

		if (nodeResult.getChildArray().size() == 0) {
			log.warn("Aviso campos MT recuperados CERO {} blk: {}", typeMsgTx, bloque);
			return nodeResult;
		}

//		log.info("============{} blk: {} size: {} ===============", typeMsgTx, bloque, nodeResult.getChildArray().size());
//		nodeResult.print(0);
//		log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		return nodeResult;
	}

	public Node<SwfMencampos> generateTreeSwfCampos(SwfMencampos swfMencamposIn, Function<SwfMencampos, Optional<Supplier<Node>>> nextSwfMencamposF) {
		Boolean existNext = true;
		Node<SwfMencampos> node = null;
		while (existNext) {
			Optional<Supplier<Node>> swfMencamposNext = nextSwfMencamposF.apply(null);
			existNext = swfMencamposNext.isPresent();

			if (!existNext)
				break;

			Supplier<Node> swfMencamposOpt = swfMencamposNext.get();
			node = swfMencamposOpt.get();
			SwfMencampos swfMencampos = node.getSwfMencamposCrr();
			if (node.hasNext()) {
				swfMencampos = node.getSwfMencamposNxt();
			}
			if (swfMencampos == null)
				break;
			// log.info("XXX: EN WHILE PADRE: "+ node.getSwfMencampos().toStringID()+ "
			// CUUR: " + swfMencampos.toStringID());

			if (iniSequence().test(swfMencampos)) {
				SwfMencampos swfMencmpPadre = SwfMencampos.cloneSwfMencampos(swfMencampos).get();

				Node<SwfMencampos> padre = new Node(swfMencmpPadre);
				padre.setSwfMencamposCrr(swfMencmpPadre);

				Function<SwfMencampos, Optional<Supplier<Node>>> nextSwfMencamposSeqF = nextSwfMencampos(node, padre);
				generateTreeSwfCampos(swfMencmpPadre, nextSwfMencamposSeqF);
			}
		}

		if (node == null) {
			node = new Node();
		}
		return node;
	}

	public Function<SwfMencampos, Optional<Supplier<Node>>> nextSwfMencampos(Node<SwfMencampos> padre, Node<SwfMencampos> nodoCurrent) {
		if (padre != null)
			Tree.addChild(padre, nodoCurrent);

		return swfMencamposCurr -> {
			if (!nodoCurrent.hasCurrent()) {
				// no hay root
				Optional<SwfMencampos> nroSwfMencamposOpt = getSwfMencamposIsoDao().nextNroSwfMencampos(nodoCurrent.getSwfMencampos().getMtfCodmt(),
						nodoCurrent.getSwfMencampos().getMtfNro(), nodoCurrent.getSwfMencampos().getMtfGrpopt(), nodoCurrent.getSwfMencampos().getMtfBloque(),
						nodoCurrent.getSwfMencampos().getMtfNivel());

				if (nroSwfMencamposOpt.isPresent()) {
					return Optional.of(() -> {
						nodoCurrent.setSwfMencamposCrr(nroSwfMencamposOpt.get());

						log.info("INCIO NODO: " + nodoCurrent.getSwfMencampos().toStringID() + " CURRENT: " + nodoCurrent.getSwfMencamposCrr().toStringID());
						return nodoCurrent;
					});
				} else {
					return Optional.empty();
				}
			}

			SwfMencampos swfMencampos = nodoCurrent.hasNext() ? nodoCurrent.getSwfMencamposNxt() : nodoCurrent.getSwfMencamposCrr();

			nodoCurrent.setSwfMencamposNxt(null);
			if (iniSequence().test(swfMencampos)) {
				if (!swfMencampos.toStringID().equals(nodoCurrent.getSwfMencampos().toStringID())) {
					String idCurr = swfMencampos.toStringID();
					Boolean nodoRegister = nodoCurrent.getChildArray().stream().anyMatch(nodo -> {
						return ((SwfMencampos) nodo.getSwfMencampos()).toStringID().equals(idCurr);
					});

					if (!nodoRegister) {
						nodoCurrent.setSwfMencamposNxt(swfMencampos);
						nodoCurrent.setSwfMencamposCrr(swfMencampos);
					}
				} else {
					// es inicio de sequence
					getSwfMencamposIsoDao()
							.nextNroSwfMencampos(swfMencampos.getMtfCodmt(), swfMencampos.getMtfNro(), swfMencampos.getMtfGrpopt(),
									swfMencampos.getMtfBloque(), swfMencampos.getMtfNivel())//
							.ifPresent(swfCampo -> {
								nodoCurrent.setSwfMencamposNxt(swfCampo);
							});
				}
			} else if (finSequence().test(swfMencampos)) {
				// fin de bloqie
				Node<SwfMencampos> child = new Node(swfMencampos);
				Tree.addChild(nodoCurrent, child);

				nodoCurrent.setSwfMencamposCrr(swfMencampos);

				Optional<SwfMencampos> grpSwfMencamposOpt = getSwfMencamposIsoDao().nextGrpoptSwfMencampos(nodoCurrent.getSwfMencampos().getMtfCodmt(),
						nodoCurrent.getSwfMencampos().getMtfNro(), nodoCurrent.getSwfMencampos().getMtfGrpopt(),
						nodoCurrent.getSwfMencampos().getMtfCodcampo(), nodoCurrent.getSwfMencampos().getMtfBloque());

				if (grpSwfMencamposOpt.isPresent()) {
					// siguiente grupo del padre
					// log.info("CON GRUPO PADRE: " + padre.getSwfMencampos().getId() + " CURR: " +
					// swfMencampos.toStringID() + "
					// NEXT: "
					// + grpSwfMencamposOpt.get().getId().toString());
					if (nodoCurrent.hasParent()) {
						nodoCurrent.getParent().setSwfMencamposCrr(grpSwfMencamposOpt.get());
						nodoCurrent.getParent().setSwfMencamposNxt(null);
					}
				} else {
					// siguiente nro del current
					// buscamos el siguiente con el grupo del padre del padre
					Integer grupoPadre = 0;
					if (nodoCurrent.hasParent()) {
						grupoPadre = ((SwfMencampos) nodoCurrent.getParent().getSwfMencampos()).getMtfGrpopt();
					}
					Optional<SwfMencampos> nroSwfMencamposOpt = getSwfMencamposIsoDao().nextNroSwfMencampos(swfMencampos.getMtfCodmt(),
							swfMencampos.getMtfNro(), grupoPadre, swfMencampos.getMtfBloque(), swfMencampos.getMtfNivel());

					if (nroSwfMencamposOpt.isPresent()) {
						if (nodoCurrent.hasParent()) {
							nodoCurrent.getParent().setSwfMencamposCrr(nroSwfMencamposOpt.get());
							nodoCurrent.getParent().setSwfMencamposNxt(null);
						}
					}
				}
			} else {
				Node<SwfMencampos> child = new Node(swfMencampos);
				Tree.addChild(nodoCurrent, child);
				nodoCurrent.setSwfMencamposCrr(swfMencampos);
				Integer mtfGrpopt = null;

				if (nodoCurrent.hasParent())
					// tiene padre, el nodo padre es subrutina
					mtfGrpopt = nodoCurrent.getSwfMencampos().getMtfGrpopt();
				else
					// NO tiene padre, el nodo padre es el root
					mtfGrpopt = nodoCurrent.getSwfMencamposCrr().getMtfGrpopt();

				if (mtfGrpopt != null && mtfGrpopt.compareTo(0) >= 0) {
					getSwfMencamposIsoDao()
							.nextNroSwfMencampos(swfMencampos.getMtfCodmt(), swfMencampos.getMtfNro(), mtfGrpopt, swfMencampos.getMtfBloque(),
									swfMencampos.getMtfNivel())//
							.ifPresent(swfCampo -> {
								nodoCurrent.setSwfMencamposNxt(swfCampo);
							});
				}

				if (nodoCurrent.hasNext() && nodoCurrent.getSwfMencamposNxt().getMtfCodcampo().startsWith("15")) {
					Boolean finSeq15 = nodoCurrent.getSwfMencampos().getMtfCodcampo() != null
							&& nodoCurrent.getSwfMencampos().getMtfCodcampo().startsWith("15");

					Boolean seq15Dif = nodoCurrent.getSwfMencampos().getMtfCodcampo() != null && nodoCurrent.getSwfMencamposNxt().getMtfCodcampo() != null
							&& !nodoCurrent.getSwfMencampos().getMtfCodcampo().equals(nodoCurrent.getSwfMencamposNxt().getMtfCodcampo());

					if (finSeq15 && seq15Dif) {
						if (nodoCurrent.hasParent()) {
							nodoCurrent.getParent().setSwfMencamposCrr(nodoCurrent.getSwfMencamposNxt());
							nodoCurrent.getParent().setSwfMencamposNxt(null);
						}
						nodoCurrent.setSwfMencamposNxt(null);
					}
				}
			}
			String idpadre = nodoCurrent.getSwfMencampos().toStringID();
			String idpadrepadre = nodoCurrent.hasParent() ? ((SwfMencampos) nodoCurrent.getParent().getSwfMencampos()).toStringID() : " SIN ABUELO, ";
			String idcurr = nodoCurrent.hasCurrent() ? nodoCurrent.getSwfMencamposCrr().toStringID() : " SIN CURRENT, ";
			String idnext = nodoCurrent.getSwfMencamposNxt() != null ? nodoCurrent.getSwfMencamposNxt().toStringID() : " NO HAY, ";
			String abueloNext = nodoCurrent.hasParent() && nodoCurrent.getParent().getSwfMencamposNxt() != null
					? ((SwfMencampos) nodoCurrent.getParent().getSwfMencamposNxt()).toStringID()
					: " ABUELO SIN NEXT, ";
			String abueloCurr = nodoCurrent.hasParent() && nodoCurrent.getParent().getSwfMencamposCrr() != null
					? ((SwfMencampos) nodoCurrent.getParent().getSwfMencamposCrr()).toStringID()
					: " ABUELO SIN CURR, ";

//			 log.info("FIIN:::>>>> PADRE: " + idpadre + " CURRENT: " + idcurr + " NEXT: "
//			 + idnext + " ABUELO: "
//			 + idpadrepadre + " ABUNCURR: " + abueloCurr + " ABUNEXT: " + abueloNext);

			return nodoCurrent.hasNext() ? Optional.of(() -> {
				return nodoCurrent;
			}) : Optional.empty();
		};
	}

	/**
	 * Actualiza el objeto MT recalculando la funcion definida en el parametro
	 * 
	 * @param mt
	 * @return
	 */
	public Consumer<SwfMencampos> actMTConSwfMencampos(AbstractMT mt) {
		return swfMencampos -> {
			// log.info("Actualizando campo " + swfMencampos.toStringID());
			Optional<Field> fldOpt = createField(swfMencampos, null);
			if (fldOpt.isPresent()) {
				SwiftBlock4 b4 = mt.getSwiftMessage().getBlock4();

				Field field = b4.getFieldByName(fldOpt.get().getName());

				if (field != null) {
					log.info("Actualizando campo " + field.getName() + " Old: " + field.getValue() + " New: " + fldOpt.get().getValue());
					// agregamos los datos del campo calculado
					b4.getTagByName(fldOpt.get().getName()).setValue(fldOpt.get().getValue());
				} else {
					throw new RuntimeException("Campo [" + fldOpt.get().getName() + "] inexistente en objejto MT, campo: " + swfMencampos.toStringID()
							+ ", nemo: " + swfMencampos.getMtfNemo());
				}

			} else {
				throw new RuntimeException(
						"Error al actualizar Campo " + swfMencampos.toStringID() + ", nemo: " + swfMencampos.getMtfNemo() + " no pudo crear campo Swift.");
			}
		};
	}

	public Optional<Field> createField(SwfMencampos swfMencampos, Node<SwfMencampos> nodeSwfCampo) {
		// obtenemos la funcion para crear el objeto Field
		Optional<Function<SwfMencampos, Optional<Field>>> funcCreateField = getFuncCreateField.apply(swfMencampos);
		log.info(
				"antes de create field " + swfMencampos.toStringID() + " " + nodeSwfCampo.getSwfMencampos().toStringID() + " " + funcCreateField.isPresent());

		if (!funcCreateField.isPresent())
			return Optional.empty();

		Optional<Field> fldOpt = funcCreateField.get().apply(swfMencampos);
		if (!fldOpt.isPresent()) {
			if (nodeSwfCampo != null && mandatoryCampoYPadre().test(nodeSwfCampo)) {
				// puede existir campos que el resultado vienen en el siguietne
				log.error("CAMPO VACIO!! : Campo requerido: " + swfMencampos.toStringID() + ": " + swfMencampos.getMtfNemo() + " "
						+ (nodeSwfCampo.hasParent() ? ((SwfMencampos) nodeSwfCampo.getParent().getSwfMencampos()).toStringID() : "")
						+ ", avise al administrador.");
			}

			// verificamos si el campo no esta registrado con el campo value, esto en
			// operaciones de cancelacion o modificacion
			CodNemoCompo codNemoCompo = TemplateGenFSwf.builtFromNemoCodCmpF.apply(swfMencampos.getMtfNemo(), null);
			log.info("campo nemo " + codNemoCompo.getCodCampoNL());
			Optional<CampoForm> cmpFOpt = TemplateGenFSwf.findEntPropOperInstr(instruccion).apply(swfMencampos.getMtfNemo(), "VALUE");
			if (cmpFOpt.isPresent()) {
				log.info("Field VALUE registrdo encontrado " + swfMencampos.toStringID() + " " + codNemoCompo.getCodCampoNL() + " "
						+ cmpFOpt.get().getValor());
				Field field = Field.getField(codNemoCompo.getCodCampoNL(), cmpFOpt.get().getValor());

				return Optional.ofNullable(field);
			}
		}
		return fldOpt;
	}

	public BiConsumer<String, String> actMTConValor(AbstractMT mt) {
		return (campo, valor) -> {
			SwiftBlock4 b4 = mt.getSwiftMessage().getBlock4();

			Field field = b4.getFieldByName(campo);

			if (field != null) {
				log.info("Actualizando campo " + field.getName() + " Old: " + field.getValue() + " New Valor: " + valor);
				b4.getTagByName(campo).setValue(valor);
			} else {
				throw new RuntimeException("Campo [" + campo + "] inexistente en objejto MT");
			}
		};
	}

	/**
	 * Desparcea un mensaje en formato RJE y actualiza el codnemo registrado en la
	 * base de datos swf_mencampos
	 * 
	 * @return
	 */
	public BiFunction<String, String, List<CampoForm>> msgRJEToCampoForm(Consumer<AbstractMT> mtAbtractC) {
		return (codMT, menPlano) -> {
			if (ValidatorCodes.isBlank.test(menPlano)) {
				throw new RuntimeException("Mensaj RJE nulo o vacío");
			}
			Node<SwfMencampos> padre = Node.createNodeDefault(codMT, TemplateGenFSwf.SWF_BLOQUE_4);
			Node<SwfMencampos> nodeResult = generateTreeSwfCampos(null, nextSwfMencampos(null, padre));

			log.info("=========== MENSAJE RJE A CAMPOS FORM [" + codMT + "]===================");
			log.info("===> menPlano :" + menPlano);

			AbstractMT mt = TemplateGenFSwf.createMTFromFIN().apply(menPlano);
			final SwiftBlock4 b4 = mt.getSwiftMessage().getBlock4();

			Map<Integer, SwfMencampos> ctrlFlds = new LinkedHashMap<Integer, SwfMencampos>();

			BiFunction<Field, SwfMencampos, Boolean> ctrlSwiftTagListC = (field, swfMencampos) -> {
				int hash = Objects.hash(field.getName(), field.getValue());
				if (!ctrlFlds.containsKey(hash)) {
					ctrlFlds.put(hash, swfMencampos);
					return true;
				}
				return false;
			};

			List<CampoForm> camposFormListFld = actNemoMT(nodeResult, b4, ctrlSwiftTagListC);

			if (mtAbtractC != null) {
				mtAbtractC.accept(mt);
			}

			return camposFormListFld;
		};
	}

	/**
	 * Actualiza los campos del MT con el codigo nemo regisrado en la base de datos
	 * de campos swift
	 * 
	 * @param nodeSwfCampo
	 * @param stbMT
	 * @param ctrlSwiftTagListC
	 * @return
	 */
	public List<CampoForm> actNemoMT(Node<SwfMencampos> nodeSwfCampo, SwiftTagListBlock stbMT, BiFunction<Field, SwfMencampos, Boolean> ctrlSwiftTagListC) {
		List<CampoForm> camposFormListFld = new ArrayList<>();
		SwfMencampos swfMencampos = nodeSwfCampo.getSwfMencampos();

		if (!nodeSwfCampo.hasParent()) {
			for (Node<SwfMencampos> child : nodeSwfCampo.getChildArray()) {
				List<CampoForm> stbRes = actNemoMT(child, stbMT, ctrlSwiftTagListC);
				camposFormListFld.addAll(stbRes);
			}
		} else {
			// log.info("Evaluando: " + swfMencampos.toStringID() + " : " +
			// swfMencampos.getMtfNemo() + ", childs " +
			// nodeSwfCampo.getChildArray().size()
			// + " stbMT: " + stbMT.size());
			if (iniSequence().test(swfMencampos)) {
				Optional<Function<SwfMencampos, Optional<Function<SwiftTagListBlock, SwiftTagListBlock>>>> createSeqFOpt = getCreateFuncSeq
						.apply(swfMencampos);

				if (!createSeqFOpt.isPresent()) {
					throw new RuntimeException(
							"Funcion no declarada en getCreateFuncSeq de sequencias para " + swfMencampos.toStringID() + " : " + swfMencampos.getMtfNemo());
				}

				Optional<Function<SwiftTagListBlock, SwiftTagListBlock>> createSequenceOpt = createSeqFOpt.get().apply(swfMencampos);
				if (!createSequenceOpt.isPresent()) {
					throw new RuntimeException(
							"Funcion no registrada en mapa Secuencias para " + swfMencampos.toStringID() + " : " + swfMencampos.getMtfNemo());
				}

				SwiftTagListBlock swfTLB = createSequenceOpt.get().apply(new SwiftTagListBlock());
				Field field = swfTLB.getField(0);

				CodNemoCompo codNemoCompo = TemplateGenFSwf.builtFromNemoCodCmpF.apply(swfMencampos.getMtfNemo(), null);

				Map<String, SwiftTagListBlock> map = SwiftMessageUtils.splitByField15(stbMT);

				// extraemos bloque 15
				SwiftTagListBlock stbSubBlk15List = map.get(codNemoCompo.getCodCampoLit());
				if (map.size() > 0 && stbSubBlk15List != null) {

					ctrlSwiftTagListC.apply(field, swfMencampos);

					List<CampoForm> camposFormList = TemplateGenFSwf.convertToCampoForm().apply(swfMencampos, field);
					camposFormListFld.addAll(camposFormList);

					SwiftTagListBlock sbFields = stbSubBlk15List.getSubBlock(1, stbSubBlk15List.size());
					for (Node<SwfMencampos> child : nodeSwfCampo.getChildArray()) {
						List<CampoForm> stbSeqResult = actNemoMT(child, sbFields, ctrlSwiftTagListC);
						camposFormListFld.addAll(stbSeqResult);
					}

					return camposFormListFld;
				}
				List<SwiftTagListBlock> stbSubBlkList = stbMT.getSubBlocks(field.getValue());

				if (stbSubBlkList.size() == 0) {
					// no exite el campo para la secuencia
					return camposFormListFld;
				} else {
					ctrlSwiftTagListC.apply(field, swfMencampos);

					List<CampoForm> camposFormList = TemplateGenFSwf.convertToCampoForm().apply(swfMencampos, field);
					camposFormListFld.addAll(camposFormList);
				}
				// ### EVALUAMOS LOS CAMPOS DEL BLOQUE ###
				List<CampoForm> camposFormSB = new ArrayList<>();

				Integer grupo = ValidatorCodes.isBlank.test(codNemoCompo.getGrpOpt()) ? 0 : Integer.valueOf(codNemoCompo.getGrpOpt());

				for (Node<SwfMencampos> child : nodeSwfCampo.getChildArray()) {
					SwiftTagListBlock sbFieldsL = stbSubBlkList.get(grupo);
					if (sbFieldsL != null) {
						SwiftTagListBlock sbFields = sbFieldsL.getSubBlock(1, sbFieldsL.size() - 1);

						List<CampoForm> stbSeqResult = actNemoMT(child, sbFields, ctrlSwiftTagListC);
						camposFormSB.addAll(stbSeqResult);
					}
				}

				Function<String, Function<String, Optional<CampoForm>>> findValorDeTablaTCF = CampoFormUtils.findValorDeTablaTC(camposFormListFld);

				camposFormSB.stream().forEach(cf -> {
					Optional<CampoForm> cfOpt = findValorDeTablaTCF.apply(cf.getTabla()).apply(cf.getColumn());
					if (!cfOpt.isPresent()) {
						camposFormListFld.add(cf);
					} else {
						if (!cfOpt.get().getValor().equals(cf.getValor())) {
							camposFormListFld.add(cf);
						}
					}
				});

			} else if (finSequence().test(swfMencampos)) {
				Field field = new Field16S();
				ctrlSwiftTagListC.apply(field, swfMencampos);

				List<CampoForm> camposFormList = TemplateGenFSwf.convertToCampoForm().apply(swfMencampos, field);
				camposFormListFld.addAll(camposFormList);

				return camposFormListFld;
			} else {
				if (nodeSwfCampo.getChildArray().size() > 0) {
					throw new RuntimeException("Error en la recuperacions de nodos campos, Funcion para " + swfMencampos.toStringID() + " : "
							+ swfMencampos.getMtfNemo() + " no debe tener hijos.");
				}

				List<SwfMencampos> swfMencamposList = getSwfMencamposIsoDao().opcionesDeCampo(swfMencampos.getMtfCodmt(), swfMencampos.getMtfNro(),
						swfMencampos.getMtfGrpopt(), swfMencampos.getMtfBloque());

				Map<String, List<SwfMencampos>> grpCampoNumerico = swfMencamposList.stream().collect(Collectors.groupingBy((SwfMencampos t) -> {
					CodNemoCompo codNemoCompo = TemplateGenFSwf.builtFromNemoCodCmpF.apply(t.getMtfNemo(), null);
					return codNemoCompo.format("SlSnGFnFl");
				}));

				grpCampoNumerico.entrySet().stream().forEach(entry -> {
					Boolean uniqCampo = entry.getValue().size() == 1;

					CodNemoCompo codNemoCompo0 = TemplateGenFSwf.builtFromNemoCodCmpF.apply(entry.getKey(), null);
					String codCampo0 = codNemoCompo0.format("FnFl");

					Field[] fields0 = stbMT.getFieldsByName(codCampo0);
					if (fields0.length > 0) {
						if (uniqCampo) {
							// sin order
							if (fields0.length == 1) {
								ctrlSwiftTagListC.apply(fields0[0], swfMencampos);

								List<CampoForm> camposFormList = TemplateGenFSwf.convertToCampoForm().apply(swfMencampos, fields0[0]);
								camposFormListFld.addAll(camposFormList);

							} else {
								// el campo esta presente en bloque mas de una vez, pero en la base solo se
								// tiene un registro ej: mt300
								// SB1.57 SB2.57
								for (Field f : fields0) {
									Boolean registrar = ctrlSwiftTagListC.apply(f, swfMencampos);
									if (registrar) {
										List<CampoForm> camposFormList = TemplateGenFSwf.convertToCampoForm().apply(swfMencampos, f);
										camposFormListFld.addAll(camposFormList);
										// salimos del ciclo solo debemos registrar una sola vez
										break;
									}
								}
							}
						} else {
							Integer pos = 0;
							Integer size = entry.getValue().size();

							for (Field f : fields0) {
								SwfMencampos swfMencamposGrpOpt = pos < size ? entry.getValue().get(pos) : entry.getValue().get(0);

								Boolean registrar = ctrlSwiftTagListC.apply(f, swfMencamposGrpOpt);
								if (registrar) {
									List<CampoForm> camposFormList = TemplateGenFSwf.convertToCampoForm().apply(swfMencamposGrpOpt, f);
									camposFormListFld.addAll(camposFormList);
								}
								pos++;
							}
						}
					}
				});
			}
		}
		return camposFormListFld;
	}

	public static Predicate<SwfMencampos> iniSequence() {
		return swfMencampos -> (swfMencampos.getMtfCodcampo() != null
				&& (swfMencampos.getMtfCodcampo().trim().equals("16R") || swfMencampos.getMtfCodcampo().trim().startsWith("15")));
	}

	public static Predicate<SwfMencampos> finSequence() {
		return swfMencampos -> swfMencampos.getMtfCodcampo() != null && swfMencampos.getMtfCodcampo().trim().equals("16S");
	}

	public static void printTagsSTB(SwiftTagListBlock swfTLB) {
		swfTLB.getTags().forEach(tag -> {
			log.info("TAG: " + tag.getName() + " " + tag.getValue());
		});
	}

	private static SwiftMessage createBlock1(String messageType, String applicationId, String serviceId, String logicalTerminal, String sessionNumber,
			String sequenceNumber, String bicsender, String bicreceiver, String messagePriority) {

		final SwiftMessage sm = new SwiftMessage(true);

		SwiftBlock1 block1 = new SwiftBlock1();

		block1.setApplicationId(applicationId);
		block1.setServiceId(StringUtils.leftPad(serviceId, 2, "0"));
		// block1.setLogicalTerminal(StringUtils.rightPad(logicalTerminal, 12, "X"));
		block1.setSessionNumber(StringUtils.rightPad(sessionNumber, 4, "0"));
		block1.setSequenceNumber(StringUtils.rightPad(sequenceNumber, 6, "0"));
		block1.setSender(bicsender);

		sm.setBlock1(block1);

		createBlock2(sm, messageType, bicreceiver, messagePriority);
		return sm;
	}

	public static void createBlock2(SwiftMessage sm, String messageType, String bicReceiver, String messagePriority) {
		SwiftBlock2Input swiftBlock2Input = new SwiftBlock2Input();
		swiftBlock2Input.setMessageType(messageType);

		BIC bicswf = new BIC(bicReceiver);
		messagePriority = StringUtils.isBlank(messagePriority) ? "N" : messagePriority.substring(0, 1);
		swiftBlock2Input.setReceiver(bicswf);
		swiftBlock2Input.setMessagePriority(messagePriority);

		sm.setBlock2(swiftBlock2Input);
	}

	public static void createBlock3(SwiftMessage sm, String tagname, String value) {
		SwiftBlock3 block3 = sm.getBlock3();
		if (block3 == null) {
			sm.setBlock3(new SwiftBlock3());
		}

		block3 = sm.getBlock3();

		value = value.trim();
		tagname = tagname.trim();
		Tag tag = new Tag(tagname, value);

		block3.getTags().add(tag);
	}

	
}
