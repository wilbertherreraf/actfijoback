package gob.bcb.iso20022.rules;

import java.util.Map;

/**
 * A functional interface, so that we can write actions using java 8 lambdas.
 */

public interface ExecutableAction<Input, Output> {
	ExecutableAction NO_OP = new ExecutableAction() {};
	
	default boolean evaluateCondition(CompiledRule rule, Input input, Map<String, Object> facts) {
		return true;
	}

	default Output execute(CompiledRule rule, Input input, Map<String, Object> facts) {
		return null;
	}

	default void afterCondition(CompiledRule rule, Input input, boolean accepted) {
	}
	
	default void postExecuteAction(CompiledRule rule, Input input, Output output, Map<String, Object> facts) {
		
	}
	default void postExecuteSubAction(CompiledRule rule, Action subActin, Input input, Output output, Map<String, Object> facts) {
		
	}	
}
