package gob.bcb.iso20022.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import gob.bcb.iso20022.pojo.ArchivoSinple;
import gob.bcb.iso20022.utils.ArchivoUtil;
import gob.bcb.iso20022.utils.UtilsFile;
/**
 * @author: wherrera
 * 
 */
public class ArchivoSinpleImpl {

	public static ArchivoSinple fromPathfile(String pathFile, String nameFileOriginal) {
		ArchivoSinple archivoSinple = new ArchivoSinple();
		archivoSinple.setNameOriginal(nameFileOriginal);

		File f = checkFile(pathFile);

		archivoSinple.setDirectory(f.getParent());
		archivoSinple.setName(f.getName());

		putPathFile(archivoSinple);

		try {
			byte[] data = UtilsFile.copyToByteArray(pathFile);
			archivoSinple.setSize(data.length);
			archivoSinple.setData(data);

			return archivoSinple;
		} catch (IOException e) {
			throw new RuntimeException("Error al copiar data " + e.getMessage(), e);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public static ArchivoSinple fileUpload(InputStream stream, String nameFileOriginal) {
		ArchivoSinple archivoSinple = new ArchivoSinple();
		archivoSinple.setNameOriginal(nameFileOriginal);

		try {
			byte[] data = UtilsFile.copyToByteArray(stream);
			archivoSinple.setSize(data.length);
			archivoSinple.setData(data);

			archivoSinple.setName(archivoSinple.getHash() + "." + ArchivoUtil.obtenerExtension(nameFileOriginal));

			return archivoSinple;
		} catch (IOException e) {
			throw new RuntimeException("Error al copiar data " + e.getMessage(), e);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public static ArchivoSinple newFromOutputStream(ByteArrayOutputStream baos, String nameFile) {
		ArchivoSinple archivoSinple = new ArchivoSinple();
		archivoSinple.setNameOriginal(nameFile);
		archivoSinple.setContentType(ArchivoUtil.obtenerMime(nameFile));
		
		byte[] data = baos.toByteArray();
		archivoSinple.setSize(data.length);
		archivoSinple.setData(data);

		return archivoSinple;
	}

	/**
	 * Setea el nombre del archivo y directorio
	 * 
	 * @param directory
	 * @param nameFile
	 * @param nameFileOriginal
	 *            nombre de archivo que se diferencia con name ya que name
	 *            contiene hash y nameOriginal es uno leible
	 */
	public static void settingPathFile(ArchivoSinple archivoSinple, String directory, String nameFile, String nameFileOriginal) {
		archivoSinple.setDirectory(directory);
		archivoSinple.setNameOriginal(nameFileOriginal);
		String ext = ArchivoUtil.obtenerExtension(nameFileOriginal);
		if (ext == null || ext.length() == 0) {
			ext = "";
		} else {
			ext = "." + ext;
		}
		archivoSinple.setName(nameFile + ext);
		putPathFile(archivoSinple);
	}

	public static void putPathFile(ArchivoSinple archivoSinple) {
		File h = new File(archivoSinple.getDirectory(), archivoSinple.getName());
		archivoSinple.setPathFile(h.getAbsolutePath());
		archivoSinple.setContentType(ArchivoUtil.obtenerMime(h.getAbsolutePath()));
	}

	private static File checkFile(String pathFile) {
		if (StringUtils.isBlank(pathFile)) {
			throw new RuntimeException("Ruta archivo nulo");
		}

		File h = new File(pathFile);
		if (!h.exists() || h.isDirectory()) {
			throw new RuntimeException("Archivo inexistente " + pathFile);
		}
		return h;
	}
}
