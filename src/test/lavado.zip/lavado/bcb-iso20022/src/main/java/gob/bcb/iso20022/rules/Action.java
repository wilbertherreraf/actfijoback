package gob.bcb.iso20022.rules;

import java.util.HashMap;
import java.util.Map;

/**
 * An Action that should be performed given a fact has met the condition specified in a Rule.
 * The type of action is dictated by the type field and attributes are used as parameters to configure
 * the Action's executor/handler
 */
public class Action implements Cloneable{
	private String id;
    private String type;
    private String attribute;
    private String value;
    private Map<String,String> attributes;

    public Action() {
    }

    public Action(String type, Map<String, String> attributes) {
        this.type = type;
        this.attributes = attributes;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }

    public Action clone(){
        Action action = new Action();
        action.setType(type);
        Map<String, String> attributeMap = new HashMap<>(attributes);
        action.setAttributes(attributeMap);
        return action;
    }

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
