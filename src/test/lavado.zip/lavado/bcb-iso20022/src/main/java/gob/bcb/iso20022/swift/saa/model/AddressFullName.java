
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para AddressFullName complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="AddressFullName"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="X1" type="{urn:swift:saa:xsd:saa.2.0}X1"/&gt;
 *         &lt;element name="X2" type="{urn:swift:saa:xsd:saa.2.0}X2" minOccurs="0"/&gt;
 *         &lt;element name="X3" type="{urn:swift:saa:xsd:saa.2.0}X3" minOccurs="0"/&gt;
 *         &lt;element name="X4" type="{urn:swift:saa:xsd:saa.2.0}X4" minOccurs="0"/&gt;
 *         &lt;element name="FinancialInstitution" type="{urn:swift:saa:xsd:saa.2.0}FinancialInstitution" minOccurs="0"/&gt;
 *         &lt;element name="BranchInformation" type="{urn:swift:saa:xsd:saa.2.0}BranchInformation" minOccurs="0"/&gt;
 *         &lt;element name="CityName" type="{urn:swift:saa:xsd:saa.2.0}CityName" minOccurs="0"/&gt;
 *         &lt;element name="Location" type="{urn:swift:saa:xsd:saa.2.0}Location" minOccurs="0"/&gt;
 *         &lt;element name="CountryCode" type="{urn:swift:saa:xsd:saa.2.0}Countrycode" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddressFullName", propOrder = {
    "x1",
    "x2",
    "x3",
    "x4",
    "financialInstitution",
    "branchInformation",
    "cityName",
    "location",
    "countryCode"
})
public class AddressFullName {

    @XmlElement(name = "X1", required = true)
    protected String x1;
    @XmlElement(name = "X2")
    protected String x2;
    @XmlElement(name = "X3")
    protected String x3;
    @XmlElement(name = "X4")
    protected String x4;
    @XmlElement(name = "FinancialInstitution")
    protected String financialInstitution;
    @XmlElement(name = "BranchInformation")
    protected String branchInformation;
    @XmlElement(name = "CityName")
    protected String cityName;
    @XmlElement(name = "Location")
    protected String location;
    @XmlElement(name = "CountryCode")
    protected String countryCode;

    /**
     * Obtiene el valor de la propiedad x1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX1() {
        return x1;
    }

    /**
     * Define el valor de la propiedad x1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX1(String value) {
        this.x1 = value;
    }

    /**
     * Obtiene el valor de la propiedad x2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX2() {
        return x2;
    }

    /**
     * Define el valor de la propiedad x2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX2(String value) {
        this.x2 = value;
    }

    /**
     * Obtiene el valor de la propiedad x3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX3() {
        return x3;
    }

    /**
     * Define el valor de la propiedad x3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX3(String value) {
        this.x3 = value;
    }

    /**
     * Obtiene el valor de la propiedad x4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX4() {
        return x4;
    }

    /**
     * Define el valor de la propiedad x4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX4(String value) {
        this.x4 = value;
    }

    /**
     * Obtiene el valor de la propiedad financialInstitution.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialInstitution() {
        return financialInstitution;
    }

    /**
     * Define el valor de la propiedad financialInstitution.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialInstitution(String value) {
        this.financialInstitution = value;
    }

    /**
     * Obtiene el valor de la propiedad branchInformation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchInformation() {
        return branchInformation;
    }

    /**
     * Define el valor de la propiedad branchInformation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchInformation(String value) {
        this.branchInformation = value;
    }

    /**
     * Obtiene el valor de la propiedad cityName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * Define el valor de la propiedad cityName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityName(String value) {
        this.cityName = value;
    }

    /**
     * Obtiene el valor de la propiedad location.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocation() {
        return location;
    }

    /**
     * Define el valor de la propiedad location.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocation(String value) {
        this.location = value;
    }

    /**
     * Obtiene el valor de la propiedad countryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Define el valor de la propiedad countryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

}
