package gob.bcb.iso20022.core.xml;

import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;

public class SaaNamespaceContext implements NamespaceContext, Serializable {
	private static final long serialVersionUID = 1L;

	public SaaNamespaceContext() {
	}

	@Override
	public String getNamespaceURI(String prefix) {
		if (null == prefix) {
			throw new IllegalArgumentException("prefix");
		} else if (XMLConstants.XMLNS_ATTRIBUTE.equals(prefix)) {
			return XMLConstants.XMLNS_ATTRIBUTE_NS_URI;
		} else if (XMLConstants.XML_NS_PREFIX.equals(prefix)) {
			return XMLConstants.XML_NS_URI;
		} else if ("Saa".equals(prefix)) {
			return "urn:swift:saa:xsd:saa.2.0";
		} else {
			return XMLConstants.NULL_NS_URI;
		}
	}

	@Override
	public String getPrefix(String namespaceUri) {

		if (null == namespaceUri) {
			throw new IllegalArgumentException("namespaceURI");
		} else if (XMLConstants.XMLNS_ATTRIBUTE_NS_URI.equals(namespaceUri)) {
			return XMLConstants.XMLNS_ATTRIBUTE;
		} else if (XMLConstants.XML_NS_URI.equals(namespaceUri)) {
			return XMLConstants.XML_NS_PREFIX;
		} else if ("urn:swift:saa:xsd:saa.2.0".equals(namespaceUri)) {
			return "Saa";
		} else {
			return XMLConstants.DEFAULT_NS_PREFIX;
		}
	}

	@Override
	public Iterator<String> getPrefixes(String namespaceUri) {
		System.out.println("NS Prefixes: " + namespaceUri);
		if (null == namespaceUri) {
			throw new IllegalArgumentException("namespaceURI");
		} else if (XMLConstants.XMLNS_ATTRIBUTE_NS_URI.equals(namespaceUri)) {
			return Collections.singletonList(XMLConstants.XMLNS_ATTRIBUTE).iterator();
		} else if (XMLConstants.XML_NS_URI.equals(namespaceUri)) {
			return Collections.singletonList(XMLConstants.XML_NS_PREFIX).iterator();
		} else if ("urn:swift:saa:xsd:saa.2.0".equals(namespaceUri)) {
			return Collections.singletonList("Saa").iterator();
		} else {
			return Collections.emptyIterator();
		}
	}

	@Override
	public String toString() {
		return "{my -> urn:swift:saa:xsd:saa.2.0}";
	}
}


//private static class NamespaceContextImpl implements NamespaceContext {
//    private final Map<String, String> urisByPrefix = new HashMap<>();
//
//    private final Map<String, Set<String>> prefixesByURI = new HashMap<>();
//
//    public NamespaceContextImpl() {
//      addNamespace(XMLConstants.XML_NS_PREFIX, XMLConstants.XML_NS_URI);
//      addNamespace(XMLConstants.XMLNS_ATTRIBUTE, XMLConstants.XMLNS_ATTRIBUTE_NS_URI);
//    }
//
//    public NamespaceContextImpl(String prefix, String uri) {
//      this();
//      addNamespace(prefix, uri);
//    }
//
//    private void addNamespace(String prefix, String namespaceURI) {
//      urisByPrefix.put(prefix, namespaceURI);
//      if (prefixesByURI.containsKey(namespaceURI)) {
//        (prefixesByURI.get(namespaceURI)).add(prefix);
//      } else {
//        Set<String> set = new HashSet<>();
//        set.add(prefix);
//        prefixesByURI.put(namespaceURI, set);
//      }
//    }
//
//    @Override
//    public String getNamespaceURI(String prefix) {
//      if (prefix == null)
//        throw new IllegalArgumentException("prefix cannot be null");
//      return urisByPrefix.getOrDefault(prefix, XMLConstants.NULL_NS_URI);
//    }
//
//    @Override
//    public String getPrefix(String namespaceURI) {
//      return getPrefixes(namespaceURI).next();
//    }
//
//    @Override
//    public Iterator<String> getPrefixes(String namespaceURI) {
//      if (namespaceURI == null)
//        throw new IllegalArgumentException("namespaceURI cannot be null");
//      if (prefixesByURI.containsKey(namespaceURI)) {
//        return (prefixesByURI.get(namespaceURI)).iterator();
//      } else {
//        return Collections.emptyIterator();
//      }
//    }
//  }