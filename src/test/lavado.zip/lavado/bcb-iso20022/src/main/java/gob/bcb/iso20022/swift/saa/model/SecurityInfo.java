
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para SecurityInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="SecurityInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IsSigningRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="RMAResult" type="{urn:swift:saa:xsd:saa.2.0}RMAResult" minOccurs="0"/&gt;
 *         &lt;element name="RMAChecked" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="TransactionDataSecurityResult" type="{urn:swift:saa:xsd:saa.2.0}TransactionDataSecurityResult" minOccurs="0"/&gt;
 *         &lt;choice minOccurs="0"&gt;
 *           &lt;element name="FINSecurityInfo" type="{urn:swift:saa:xsd:saa.2.0}FINSecurityInfo"/&gt;
 *           &lt;element name="SWIFTNetSecurityInfo" type="{urn:swift:saa:xsd:saa.2.0}SWIFTNetSecurityInfo"/&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SecurityInfo", propOrder = {
    "isSigningRequested",
    "rmaResult",
    "rmaChecked",
    "transactionDataSecurityResult",
    "swiftNetSecurityInfo",
    "finSecurityInfo"
})
public class SecurityInfo {

    @XmlElement(name = "IsSigningRequested")
    protected Boolean isSigningRequested;
    @XmlElement(name = "RMAResult")
    @XmlSchemaType(name = "string")
    protected RMAResult rmaResult;
    @XmlElement(name = "RMAChecked")
    protected Boolean rmaChecked;
    @XmlElement(name = "TransactionDataSecurityResult")
    @XmlSchemaType(name = "string")
    protected TransactionDataSecurityResult transactionDataSecurityResult;
    @XmlElement(name = "SWIFTNetSecurityInfo")
    protected SWIFTNetSecurityInfo swiftNetSecurityInfo;
    @XmlElement(name = "FINSecurityInfo")
    protected FINSecurityInfo finSecurityInfo;

    /**
     * Obtiene el valor de la propiedad isSigningRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsSigningRequested() {
        return isSigningRequested;
    }

    /**
     * Define el valor de la propiedad isSigningRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsSigningRequested(Boolean value) {
        this.isSigningRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad rmaResult.
     * 
     * @return
     *     possible object is
     *     {@link RMAResult }
     *     
     */
    public RMAResult getRMAResult() {
        return rmaResult;
    }

    /**
     * Define el valor de la propiedad rmaResult.
     * 
     * @param value
     *     allowed object is
     *     {@link RMAResult }
     *     
     */
    public void setRMAResult(RMAResult value) {
        this.rmaResult = value;
    }

    /**
     * Obtiene el valor de la propiedad rmaChecked.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRMAChecked() {
        return rmaChecked;
    }

    /**
     * Define el valor de la propiedad rmaChecked.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRMAChecked(Boolean value) {
        this.rmaChecked = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionDataSecurityResult.
     * 
     * @return
     *     possible object is
     *     {@link TransactionDataSecurityResult }
     *     
     */
    public TransactionDataSecurityResult getTransactionDataSecurityResult() {
        return transactionDataSecurityResult;
    }

    /**
     * Define el valor de la propiedad transactionDataSecurityResult.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionDataSecurityResult }
     *     
     */
    public void setTransactionDataSecurityResult(TransactionDataSecurityResult value) {
        this.transactionDataSecurityResult = value;
    }

    /**
     * Obtiene el valor de la propiedad swiftNetSecurityInfo.
     * 
     * @return
     *     possible object is
     *     {@link SWIFTNetSecurityInfo }
     *     
     */
    public SWIFTNetSecurityInfo getSWIFTNetSecurityInfo() {
        return swiftNetSecurityInfo;
    }

    /**
     * Define el valor de la propiedad swiftNetSecurityInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SWIFTNetSecurityInfo }
     *     
     */
    public void setSWIFTNetSecurityInfo(SWIFTNetSecurityInfo value) {
        this.swiftNetSecurityInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad finSecurityInfo.
     * 
     * @return
     *     possible object is
     *     {@link FINSecurityInfo }
     *     
     */
    public FINSecurityInfo getFINSecurityInfo() {
        return finSecurityInfo;
    }

    /**
     * Define el valor de la propiedad finSecurityInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link FINSecurityInfo }
     *     
     */
    public void setFINSecurityInfo(FINSecurityInfo value) {
        this.finSecurityInfo = value;
    }

}
