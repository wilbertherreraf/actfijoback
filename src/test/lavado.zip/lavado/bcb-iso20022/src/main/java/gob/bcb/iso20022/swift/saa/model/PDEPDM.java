
package gob.bcb.iso20022.swift.saa.model;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para PDEPDM complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PDEPDM"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;choice maxOccurs="unbounded"&gt;
 *         &lt;element name="PDE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="PDM" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/choice&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PDEPDM", propOrder = {
    "pdesAndPDMS"
})
public class PDEPDM {

    @XmlElementRefs({
        @XmlElementRef(name = "PDE", namespace = "urn:swift:saa:xsd:saa.2.0", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "PDM", namespace = "urn:swift:saa:xsd:saa.2.0", type = JAXBElement.class, required = false)
    })
    protected List<JAXBElement<String>> pdesAndPDMS;

    /**
     * Gets the value of the pdesAndPDMS property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pdesAndPDMS property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPDESAndPDMS().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * 
     */
    public List<JAXBElement<String>> getPDESAndPDMS() {
        if (pdesAndPDMS == null) {
            pdesAndPDMS = new ArrayList<JAXBElement<String>>();
        }
        return this.pdesAndPDMS;
    }

}
