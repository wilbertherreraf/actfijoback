package gob.bcb.iso20022.pojo;

public class Base {
	private Integer idnum = 0;
	private String codmdl = "";
	private String tipo = "";
	private String tbl = "";
	private String fld = "";
	private String tblori = "";
	private String fldori = "";
	private String tipoVl = "";
	public Base() {

	}
	public Integer getIdnum() {
		return idnum;
	}
	public void setIdnum(Integer idnum) {
		this.idnum = idnum;
	}
	public String getCodmdl() {
		return codmdl;
	}
	public void setCodmdl(String codmdl) {
		this.codmdl = codmdl;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getTbl() {
		return tbl;
	}
	public void setTbl(String tbl) {
		this.tbl = tbl;
	}
	public String getFld() {
		return fld;
	}
	public void setFld(String fld) {
		this.fld = fld;
	}
	public String getTblori() {
		return tblori;
	}
	public void setTblori(String tblori) {
		this.tblori = tblori;
	}
	public String getFldori() {
		return fldori;
	}
	public void setFldori(String fldori) {
		this.fldori = fldori;
	}
	public String getTipoVl() {
		return tipoVl;
	}
	public void setTipoVl(String tipoVl) {
		this.tipoVl = tipoVl;
	}
	
}
