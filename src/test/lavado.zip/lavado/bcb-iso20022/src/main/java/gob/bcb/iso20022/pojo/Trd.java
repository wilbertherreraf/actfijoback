package gob.bcb.iso20022.pojo;

public class Trd {
	private String tpTrd=""; // Fx, pay, sec trd , comm trd...

	public Trd() {
	}
	public String getTpTrd() {
		return tpTrd;
	}

	public void setTpTrd(String tpTrd) {
		this.tpTrd = tpTrd;
	}
	
	
}
