package gob.bcb.iso20022.model;

public class IsoDiccionario {
	private Integer dicId;
	private String dicIndexiso;
	private Integer dicNivel;
	private String dicIsonemo;
	private String dicNombre;
	private String dicXmltag;
	private String dicCardinal;
	/**
	 * tipo de dato
	 */
	private String dicFormato;
	private String dicRestriccion;
	private String dicRestriccionadic;
	private String dicDetalledesc;
	private String dicCambiavalor;
	private String dicMinimo;
	private String dicValidacionerror;
	private String dicPath;
	private String dicDefinicion;
	private String dicCambiatipousr;
	private String dicCardinalmult;
	private String dicValordefecto;
	private String dicComentario;
	private String dicRegla;
	private String dicSinonimos;
	private String dicConvalornoreq;
	private String dicEsopcional;
	private String dicEsadicional;

	public Integer getDicId() {
		return dicId;
	}

	public void setDicId(Integer dicId) {
		this.dicId = dicId;
	}

	public String getDicIndexiso() {
		return dicIndexiso;
	}

	public void setDicIndexiso(String dicIndexiso) {
		this.dicIndexiso = dicIndexiso;
	}

	public Integer getDicNivel() {
		return dicNivel;
	}

	public void setDicNivel(Integer dicNivel) {
		this.dicNivel = dicNivel;
	}

	public String getDicIsonemo() {
		return dicIsonemo;
	}

	public void setDicIsonemo(String dicIsonemo) {
		this.dicIsonemo = dicIsonemo;
	}

	public String getDicNombre() {
		return dicNombre;
	}

	public void setDicNombre(String dicNombre) {
		this.dicNombre = dicNombre;
	}

	public String getDicXmltag() {
		return dicXmltag;
	}

	public void setDicXmltag(String dicXmltag) {
		this.dicXmltag = dicXmltag;
	}

	public String getDicCardinal() {
		return dicCardinal;
	}

	public void setDicCardinal(String dicCardinal) {
		this.dicCardinal = dicCardinal;
	}

	public String getDicFormato() {
		return dicFormato;
	}

	public void setDicFormato(String dicFormato) {
		this.dicFormato = dicFormato;
	}

	public String getDicRestriccion() {
		return dicRestriccion;
	}

	public void setDicRestriccion(String dicRestriccion) {
		this.dicRestriccion = dicRestriccion;
	}

	public String getDicRestriccionadic() {
		return dicRestriccionadic;
	}

	public void setDicRestriccionadic(String dicRestriccionadic) {
		this.dicRestriccionadic = dicRestriccionadic;
	}

	public String getDicDetalledesc() {
		return dicDetalledesc;
	}

	public void setDicDetalledesc(String dicDetalledesc) {
		this.dicDetalledesc = dicDetalledesc;
	}

	public String getDicCambiavalor() {
		return dicCambiavalor;
	}

	public void setDicCambiavalor(String dicCambiavalor) {
		this.dicCambiavalor = dicCambiavalor;
	}

	public String getDicMinimo() {
		return dicMinimo;
	}

	public void setDicMinimo(String dicMinimo) {
		this.dicMinimo = dicMinimo;
	}

	public String getDicValidacionerror() {
		return dicValidacionerror;
	}

	public void setDicValidacionerror(String dicValidacionerror) {
		this.dicValidacionerror = dicValidacionerror;
	}

	public String getDicPath() {
		return dicPath;
	}

	public void setDicPath(String dicPath) {
		this.dicPath = dicPath;
	}

	public String getDicDefinicion() {
		return dicDefinicion;
	}

	public void setDicDefinicion(String dicDefinicion) {
		this.dicDefinicion = dicDefinicion;
	}

	public String getDicCambiatipousr() {
		return dicCambiatipousr;
	}

	public void setDicCambiatipousr(String dicCambiatipousr) {
		this.dicCambiatipousr = dicCambiatipousr;
	}

	public String getDicCardinalmult() {
		return dicCardinalmult;
	}

	public void setDicCardinalmult(String dicCardinalmult) {
		this.dicCardinalmult = dicCardinalmult;
	}

	public String getDicValordefecto() {
		return dicValordefecto;
	}

	public void setDicValordefecto(String dicValordefecto) {
		this.dicValordefecto = dicValordefecto;
	}

	public String getDicComentario() {
		return dicComentario;
	}

	public void setDicComentario(String dicComentario) {
		this.dicComentario = dicComentario;
	}

	public String getDicRegla() {
		return dicRegla;
	}

	public void setDicRegla(String dicRegla) {
		this.dicRegla = dicRegla;
	}

	public String getDicSinonimos() {
		return dicSinonimos;
	}

	public void setDicSinonimos(String dicSinonimos) {
		this.dicSinonimos = dicSinonimos;
	}

	public String getDicConvalornoreq() {
		return dicConvalornoreq;
	}

	public void setDicConvalornoreq(String dicConvalornoreq) {
		this.dicConvalornoreq = dicConvalornoreq;
	}

	public String getDicEsopcional() {
		return dicEsopcional;
	}

	public void setDicEsopcional(String dicEsopcional) {
		this.dicEsopcional = dicEsopcional;
	}

	public String getDicEsadicional() {
		return dicEsadicional;
	}

	public void setDicEsadicional(String dicEsadicional) {
		this.dicEsadicional = dicEsadicional;
	}

}
