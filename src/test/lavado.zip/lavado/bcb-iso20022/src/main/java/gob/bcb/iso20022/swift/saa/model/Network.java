
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Network.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="Network"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Application"/&gt;
 *     &lt;enumeration value="SWIFTNet"/&gt;
 *     &lt;enumeration value="FIN"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "Network")
@XmlEnum
public enum Network {

    @XmlEnumValue("Application")
    APPLICATION("Application"),
    @XmlEnumValue("SWIFTNet")
    SWIFT_NET("SWIFTNet"),
    FIN("FIN"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    Network(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static Network fromValue(String v) {
        for (Network c: Network.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
