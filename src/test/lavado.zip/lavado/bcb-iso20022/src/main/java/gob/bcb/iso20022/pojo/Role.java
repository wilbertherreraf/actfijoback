package gob.bcb.iso20022.pojo;

public class Role {
	private String idrole="";
	private String role=""; //  Financial Institution, Central Securities Depository, part
	private String tpRole="";//P : Part, S: SSI
	private String domi="";
	public Role() {

	}
	public String getIdrole() {
		return idrole;
	}
	public void setIdrole(String idrole) {
		this.idrole = idrole;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getDomi() {
		return domi;
	}
	public void setDomi(String domi) {
		this.domi = domi;
	}
	public String getTpRole() {
		return tpRole;
	}
	public void setTpRole(String tpRole) {
		this.tpRole = tpRole;
	}
	
}
