package gob.bcb.iso20022.model;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.prowidesoftware.swift.model.SwiftBlock4;

import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.MappingTable;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;


public class Instruccion implements IOperacionDatos{
	private String codInstruccion;
	private LinkedHashMap<Integer, SwfMencampos> treeMencampos = new LinkedHashMap<Integer, SwfMencampos>();	
	private SwfMsgParam swfMsgParam;
	private final Map<String, CampoForm> infAdic = new HashMap<>();
	private MappingTable mappingTable;
	private MappingTable mapTableResult = new MappingTable();	
	private SwiftBlock4 block4;
	private SwiftMessageAbstract messageHolder;
	private final SwfReglasmerc msi = new SwfReglasmerc(); 
	private final SwfReglasmerc msiA = new SwfReglasmerc();	
	private final SwfReglasheader reglasheader = new SwfReglasheader();

	public String getCodInstruccion() {
		return codInstruccion;
	}

	public void setCodInstruccion(String codInstruccion) {
		this.codInstruccion = codInstruccion;
	}

	public SwfMsgParam getSwfMsgParam() {
		return swfMsgParam;
	}

	public void setSwfMsgParam(SwfMsgParam swfMsgParam) {
		this.swfMsgParam = swfMsgParam;
	}

	public MappingTable getMappingTable() {
		return mappingTable;
	}

	public void setMappingTable(MappingTable mappingTable) {
		this.mappingTable = mappingTable;
	}

	public LinkedHashMap<Integer, SwfMencampos> getTreeMencampos() {
		return treeMencampos;
	}

	public void setTreeMencampos(LinkedHashMap<Integer, SwfMencampos> treeMencampos) {
		this.treeMencampos = treeMencampos;
	}
	
	public List<SwfMencampos> swfMencamposList() {
		return treeMencampos.values().stream().collect(Collectors.toList());
	}
	
	public boolean isMt() {
		return swfMsgParam != null && swfMsgParam.getFileFormat() != null && swfMsgParam.getFileFormat() == FileFormat.MT;
	}
	
	public boolean isMx() {
		return swfMsgParam != null && swfMsgParam.getFileFormat() != null && swfMsgParam.getFileFormat() == FileFormat.MX;
	}

	public SwiftBlock4 getBlock4() {
		if (this.block4 == null)
			this.block4 = new SwiftBlock4();
		return block4;
	}

	public void setBlock4(SwiftBlock4 block4) {
		this.block4 = block4;
	}

	public SwiftMessageAbstract getMessageHolder() {
		return messageHolder;
	}

	public void setMessageHolder(SwiftMessageAbstract messageHolder) {
		this.messageHolder = messageHolder;
	}

	public MappingTable getMapTableResult() {
		return mapTableResult;
	}

	public void setMapTableResult(MappingTable mapTableResult) {
		this.mapTableResult = mapTableResult;
	}

	public SwfReglasheader getReglasheader() {
		return reglasheader;
	}

	public SwfReglasmerc getMsi() {
		return msi;
	}

	public SwfReglasmerc getMsiA() {
		return msiA;
	}

	public Map<String, CampoForm> getInfAdic() {
		return infAdic;
	}	
}
