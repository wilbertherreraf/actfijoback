package gob.bcb.iso20022.excel.core.listener;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

public class DataReadListener<T> implements ReadListener<T> {

    private List<T> contentDataList;
    private final Consumer<List<T>> consumer;

    public DataReadListener(Consumer<List<T>> consumer) {
        this.contentDataList = new ArrayList<>();
        this.consumer = consumer;
    }
    @Override
    public void invoke(T data) {
        if (!Objects.isNull(data)) {
            contentDataList.add(data);
        }
    }

    @Override
    public void doAfterRead() {
        if (contentDataList.size() > 0) {
            consumer.accept(contentDataList);
        }
    }
}
