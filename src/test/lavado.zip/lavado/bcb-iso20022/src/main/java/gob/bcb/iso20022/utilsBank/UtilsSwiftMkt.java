package gob.bcb.iso20022.utilsBank;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

public class UtilsSwiftMkt {
	public static String retCSMCtry(String ctry, String curr) {
		if (IsoCountry.fromAlpha2Code(ctry).isPresent()) {
			ctry = StringUtils.trimToEmpty(ctry).toUpperCase();
			curr = StringUtils.trimToEmpty(curr).toUpperCase();
			IsoCountry isoCtry = IsoCountry.fromAlpha2Code(ctry).get();
			boolean isEU = isoCtry.isParticipatingTo(Agreement.EUROPEAN_ECONOMIC_AREA);

			Optional<IsoCurrency> currOpt = IsoCurrency.fromAlphabeticCode(curr);
			boolean isCurrEUR = currOpt.isPresent() ? currOpt.get().getCountries().contains(isoCtry) : false;
			isCurrEUR = IsoCurrency.EUR.getCountries().contains(isoCtry);
			
			if (curr.equalsIgnoreCase("USD") || ctry.equalsIgnoreCase("CA")) {
				return "US";
			} else if (isEU || isCurrEUR) {
				return "EU";
			}
		}
		return ctry;
	}
}
