
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Message complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Message"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SenderReference" type="{urn:swift:saa:xsd:saa.2.0}SenderReference"/&gt;
 *         &lt;element name="MessageIdentifier" type="{urn:swift:saa:xsd:saa.2.0}MessageIdentifier"/&gt;
 *         &lt;element name="Format" type="{urn:swift:saa:xsd:saa.2.0}Format"/&gt;
 *         &lt;element name="SubFormat" type="{urn:swift:saa:xsd:saa.2.0}SubFormat" minOccurs="0"/&gt;
 *         &lt;element name="Sender" type="{urn:swift:saa:xsd:saa.2.0}AddressInfo"/&gt;
 *         &lt;element name="Receiver" type="{urn:swift:saa:xsd:saa.2.0}AddressInfo"/&gt;
 *         &lt;element name="InterfaceInfo" type="{urn:swift:saa:xsd:saa.2.0}InterfaceInfo" minOccurs="0"/&gt;
 *         &lt;element name="NetworkInfo" type="{urn:swift:saa:xsd:saa.2.0}NetworkInfo" minOccurs="0"/&gt;
 *         &lt;element name="SecurityInfo" type="{urn:swift:saa:xsd:saa.2.0}SecurityInfo" minOccurs="0"/&gt;
 *         &lt;element name="SAAInfo" type="{urn:swift:saa:xsd:saa.2.0}SAAInfo" minOccurs="0"/&gt;
 *         &lt;element name="FileLogicalName" type="{urn:swift:saa:xsd:saa.2.0}FileLogicalName" minOccurs="0"/&gt;
 *         &lt;element name="ExpiryDateTime" type="{urn:swift:saa:xsd:saa.2.0}InputTimeString" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Message", propOrder = {
    "senderReference",
    "messageIdentifier",
    "format",
    "subFormat",
    "sender",
    "receiver",
    "interfaceInfo",
    "networkInfo",
    "securityInfo",
    "saaInfo",
    "fileLogicalName",
    "expiryDateTime"
})
public class Message {

    @XmlElement(name = "SenderReference", required = true)
    protected String senderReference;
    @XmlElement(name = "MessageIdentifier", required = true)
    protected String messageIdentifier;
    @XmlElement(name = "Format", required = true)
    protected String format;
    @XmlElement(name = "SubFormat")
    @XmlSchemaType(name = "string")
    protected SubFormat subFormat;
    @XmlElement(name = "Sender", required = true)
    protected AddressInfo sender;
    @XmlElement(name = "Receiver", required = true)
    protected AddressInfo receiver;
    @XmlElement(name = "InterfaceInfo")
    protected InterfaceInfo interfaceInfo;
    @XmlElement(name = "NetworkInfo")
    protected NetworkInfo networkInfo;
    @XmlElement(name = "SecurityInfo")
    protected SecurityInfo securityInfo;
    @XmlElement(name = "SAAInfo")
    protected SAAInfo saaInfo;
    @XmlElement(name = "FileLogicalName")
    protected String fileLogicalName;
    @XmlElement(name = "ExpiryDateTime")
    protected String expiryDateTime;

    /**
     * Obtiene el valor de la propiedad senderReference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenderReference() {
        return senderReference;
    }

    /**
     * Define el valor de la propiedad senderReference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public Message setSenderReference(String value) {
        this.senderReference = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad messageIdentifier.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageIdentifier() {
        return messageIdentifier;
    }

    /**
     * Define el valor de la propiedad messageIdentifier.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public Message setMessageIdentifier(String value) {
        this.messageIdentifier = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad format.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormat() {
        return format;
    }

    /**
     * Define el valor de la propiedad format.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public Message setFormat(String value) {
        this.format = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad subFormat.
     * 
     * @return
     *     possible object is
     *     {@link SubFormat }
     *     
     */
    public SubFormat getSubFormat() {
        return subFormat;
    }

    /**
     * Define el valor de la propiedad subFormat.
     * 
     * @param value
     *     allowed object is
     *     {@link SubFormat }
     *     
     */
    public Message setSubFormat(SubFormat value) {
        this.subFormat = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad sender.
     * 
     * @return
     *     possible object is
     *     {@link AddressInfo }
     *     
     */
    public AddressInfo getSender() {
        return sender;
    }

    /**
     * Define el valor de la propiedad sender.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressInfo }
     *     
     */
    public Message setSender(AddressInfo value) {
        this.sender = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad receiver.
     * 
     * @return
     *     possible object is
     *     {@link AddressInfo }
     *     
     */
    public AddressInfo getReceiver() {
        return receiver;
    }

    /**
     * Define el valor de la propiedad receiver.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressInfo }
     *     
     */
    public Message setReceiver(AddressInfo value) {
        this.receiver = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad interfaceInfo.
     * 
     * @return
     *     possible object is
     *     {@link InterfaceInfo }
     *     
     */
    public InterfaceInfo getInterfaceInfo() {
        return interfaceInfo;
    }

    /**
     * Define el valor de la propiedad interfaceInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link InterfaceInfo }
     *     
     */
    public Message setInterfaceInfo(InterfaceInfo value) {
        this.interfaceInfo = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad networkInfo.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInfo }
     *     
     */
    public NetworkInfo getNetworkInfo() {
        return networkInfo;
    }

    /**
     * Define el valor de la propiedad networkInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInfo }
     *     
     */
    public Message setNetworkInfo(NetworkInfo value) {
        this.networkInfo = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad securityInfo.
     * 
     * @return
     *     possible object is
     *     {@link SecurityInfo }
     *     
     */
    public SecurityInfo getSecurityInfo() {
        return securityInfo;
    }

    /**
     * Define el valor de la propiedad securityInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SecurityInfo }
     *     
     */
    public Message setSecurityInfo(SecurityInfo value) {
        this.securityInfo = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad saaInfo.
     * 
     * @return
     *     possible object is
     *     {@link SAAInfo }
     *     
     */
    public SAAInfo getSAAInfo() {
        return saaInfo;
    }

    /**
     * Define el valor de la propiedad saaInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SAAInfo }
     *     
     */
    public Message setSAAInfo(SAAInfo value) {
        this.saaInfo = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad fileLogicalName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileLogicalName() {
        return fileLogicalName;
    }

    /**
     * Define el valor de la propiedad fileLogicalName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileLogicalName(String value) {
        this.fileLogicalName = value;
    }

    /**
     * Obtiene el valor de la propiedad expiryDateTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpiryDateTime() {
        return expiryDateTime;
    }

    /**
     * Define el valor de la propiedad expiryDateTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpiryDateTime(String value) {
        this.expiryDateTime = value;
    }

}
