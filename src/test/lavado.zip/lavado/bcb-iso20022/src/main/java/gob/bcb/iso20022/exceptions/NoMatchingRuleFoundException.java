package gob.bcb.iso20022.exceptions;

import gob.bcb.iso20022.rules.Engine;

public class NoMatchingRuleFoundException extends Exception {

	private static final long serialVersionUID = 1L;

}
