package gob.bcb.iso20022.translate;

public class PropsTranslate {
	private String codApp;
	private String pathXsd;
	
	public String getCodApp() {
		return codApp;
	}
	public void setCodApp(String codApp) {
		this.codApp = codApp;
	}
	public String getPathXsd() {
		return pathXsd;
	}
	public void setPathXsd(String pathXsd) {
		this.pathXsd = pathXsd;
	}
}
