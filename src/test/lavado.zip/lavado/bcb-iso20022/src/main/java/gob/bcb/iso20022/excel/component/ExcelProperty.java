package gob.bcb.iso20022.excel.component;

import java.io.InputStream;
import java.util.List;

import org.apache.commons.csv.CSVFormat;

import gob.bcb.iso20022.excel.core.data.HeaderData;
import gob.bcb.iso20022.excel.enums.FileTypeEnum;

public class ExcelProperty {

    protected List<HeaderData> headerDataList;

    protected String path;
    protected InputStream inputStream;

    protected FileTypeEnum fileTypeEnum;

    protected List<List<Object>> contentDataList;

    protected String sheetName = "Sheet1";
    protected String delimiter = ",";
    protected CSVFormat cSVFormat;
    
    public List<HeaderData> getHeaderDataList() {
        return headerDataList;
    }

    public void setHeaderDataList(List<HeaderData> headerDataList) {
        this.headerDataList = headerDataList;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public FileTypeEnum getFileTypeEnum() {
        return fileTypeEnum;
    }

    public void setFileTypeEnum(FileTypeEnum fileTypeEnum) {
        this.fileTypeEnum = fileTypeEnum;
    }

    public String getSheetName() {
        return sheetName;
    }

    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    public List<List<Object>> getContentDataList() {
        return contentDataList;
    }

    public void setContentDataList(List<List<Object>> contentDataList) {
        this.contentDataList = contentDataList;
    }

	public InputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	public CSVFormat getcSVFormat() {
		return cSVFormat;
	}

	public void setcSVFormat(CSVFormat cSVFormat) {
		this.cSVFormat = cSVFormat;
	}
	
	public void createCsvFormat(Character delimiter, Character quoteChar ) {
		cSVFormat = CSVFormat.Builder.create().setDelimiter(delimiter).setQuote(quoteChar).build();
	}
}
