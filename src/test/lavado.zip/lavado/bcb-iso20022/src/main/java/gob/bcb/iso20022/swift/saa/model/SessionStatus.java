
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para SessionStatus complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="SessionStatus"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MessagePartner" type="{urn:swift:saa:xsd:saa.2.0}MessagePartner"/&gt;
 *         &lt;element name="CreationTime" type="{urn:swift:saa:xsd:saa.2.0}TimeString"/&gt;
 *         &lt;element name="SessionNr" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="InputFile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IsSuccess" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="ErrorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ErrorText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SessionDirection" type="{urn:swift:saa:xsd:saa.2.0}SessionDirection" minOccurs="0"/&gt;
 *         &lt;element name="Accepted" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="Rejected" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="AcceptedFromMessagePartner" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="RejectedFromMessagePartner" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="AcceptedToMessagePartner" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="RejectedToMessagePartner" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SessionStatus", propOrder = {
    "messagePartner",
    "creationTime",
    "sessionNr",
    "inputFile",
    "isSuccess",
    "errorCode",
    "errorText",
    "sessionDirection",
    "accepted",
    "rejected",
    "acceptedFromMessagePartner",
    "rejectedFromMessagePartner",
    "acceptedToMessagePartner",
    "rejectedToMessagePartner"
})
public class SessionStatus {

    @XmlElement(name = "MessagePartner", required = true)
    protected String messagePartner;
    @XmlElement(name = "CreationTime", required = true)
    protected String creationTime;
    @XmlElement(name = "SessionNr")
    protected int sessionNr;
    @XmlElement(name = "InputFile")
    protected String inputFile;
    @XmlElement(name = "IsSuccess")
    protected boolean isSuccess;
    @XmlElement(name = "ErrorCode")
    protected String errorCode;
    @XmlElement(name = "ErrorText")
    protected String errorText;
    @XmlElement(name = "SessionDirection")
    @XmlSchemaType(name = "string")
    protected SessionDirection sessionDirection;
    @XmlElement(name = "Accepted")
    protected Integer accepted;
    @XmlElement(name = "Rejected")
    protected Integer rejected;
    @XmlElement(name = "AcceptedFromMessagePartner")
    protected Integer acceptedFromMessagePartner;
    @XmlElement(name = "RejectedFromMessagePartner")
    protected Integer rejectedFromMessagePartner;
    @XmlElement(name = "AcceptedToMessagePartner")
    protected Integer acceptedToMessagePartner;
    @XmlElement(name = "RejectedToMessagePartner")
    protected Integer rejectedToMessagePartner;

    /**
     * Obtiene el valor de la propiedad messagePartner.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessagePartner() {
        return messagePartner;
    }

    /**
     * Define el valor de la propiedad messagePartner.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessagePartner(String value) {
        this.messagePartner = value;
    }

    /**
     * Obtiene el valor de la propiedad creationTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreationTime() {
        return creationTime;
    }

    /**
     * Define el valor de la propiedad creationTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreationTime(String value) {
        this.creationTime = value;
    }

    /**
     * Obtiene el valor de la propiedad sessionNr.
     * 
     */
    public int getSessionNr() {
        return sessionNr;
    }

    /**
     * Define el valor de la propiedad sessionNr.
     * 
     */
    public void setSessionNr(int value) {
        this.sessionNr = value;
    }

    /**
     * Obtiene el valor de la propiedad inputFile.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInputFile() {
        return inputFile;
    }

    /**
     * Define el valor de la propiedad inputFile.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInputFile(String value) {
        this.inputFile = value;
    }

    /**
     * Obtiene el valor de la propiedad isSuccess.
     * 
     */
    public boolean isIsSuccess() {
        return isSuccess;
    }

    /**
     * Define el valor de la propiedad isSuccess.
     * 
     */
    public void setIsSuccess(boolean value) {
        this.isSuccess = value;
    }

    /**
     * Obtiene el valor de la propiedad errorCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Define el valor de la propiedad errorCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorCode(String value) {
        this.errorCode = value;
    }

    /**
     * Obtiene el valor de la propiedad errorText.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorText() {
        return errorText;
    }

    /**
     * Define el valor de la propiedad errorText.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorText(String value) {
        this.errorText = value;
    }

    /**
     * Obtiene el valor de la propiedad sessionDirection.
     * 
     * @return
     *     possible object is
     *     {@link SessionDirection }
     *     
     */
    public SessionDirection getSessionDirection() {
        return sessionDirection;
    }

    /**
     * Define el valor de la propiedad sessionDirection.
     * 
     * @param value
     *     allowed object is
     *     {@link SessionDirection }
     *     
     */
    public void setSessionDirection(SessionDirection value) {
        this.sessionDirection = value;
    }

    /**
     * Obtiene el valor de la propiedad accepted.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAccepted() {
        return accepted;
    }

    /**
     * Define el valor de la propiedad accepted.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAccepted(Integer value) {
        this.accepted = value;
    }

    /**
     * Obtiene el valor de la propiedad rejected.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRejected() {
        return rejected;
    }

    /**
     * Define el valor de la propiedad rejected.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRejected(Integer value) {
        this.rejected = value;
    }

    /**
     * Obtiene el valor de la propiedad acceptedFromMessagePartner.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAcceptedFromMessagePartner() {
        return acceptedFromMessagePartner;
    }

    /**
     * Define el valor de la propiedad acceptedFromMessagePartner.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAcceptedFromMessagePartner(Integer value) {
        this.acceptedFromMessagePartner = value;
    }

    /**
     * Obtiene el valor de la propiedad rejectedFromMessagePartner.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRejectedFromMessagePartner() {
        return rejectedFromMessagePartner;
    }

    /**
     * Define el valor de la propiedad rejectedFromMessagePartner.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRejectedFromMessagePartner(Integer value) {
        this.rejectedFromMessagePartner = value;
    }

    /**
     * Obtiene el valor de la propiedad acceptedToMessagePartner.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAcceptedToMessagePartner() {
        return acceptedToMessagePartner;
    }

    /**
     * Define el valor de la propiedad acceptedToMessagePartner.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAcceptedToMessagePartner(Integer value) {
        this.acceptedToMessagePartner = value;
    }

    /**
     * Obtiene el valor de la propiedad rejectedToMessagePartner.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRejectedToMessagePartner() {
        return rejectedToMessagePartner;
    }

    /**
     * Define el valor de la propiedad rejectedToMessagePartner.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRejectedToMessagePartner(Integer value) {
        this.rejectedToMessagePartner = value;
    }

}
