
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Intervention complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Intervention"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IntvCategory" type="{urn:swift:saa:xsd:saa.2.0}IntvCategory"/&gt;
 *         &lt;element name="CreationTime" type="{urn:swift:saa:xsd:saa.2.0}TimeString"/&gt;
 *         &lt;element name="OperatorOrigin" type="{urn:swift:saa:xsd:saa.2.0}Operator"/&gt;
 *         &lt;element name="Contents" type="{urn:swift:saa:xsd:saa.2.0}SwAny"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Intervention", propOrder = {
    "intvCategory",
    "creationTime",
    "operatorOrigin",
    "contents"
})
public class Intervention {

    @XmlElement(name = "IntvCategory", required = true)
    @XmlSchemaType(name = "string")
    protected IntvCategory intvCategory;
    @XmlElement(name = "CreationTime", required = true)
    protected String creationTime;
    @XmlElement(name = "OperatorOrigin", required = true)
    protected String operatorOrigin;
    @XmlElement(name = "Contents", required = true)
    protected SwAny contents;

    /**
     * Obtiene el valor de la propiedad intvCategory.
     * 
     * @return
     *     possible object is
     *     {@link IntvCategory }
     *     
     */
    public IntvCategory getIntvCategory() {
        return intvCategory;
    }

    /**
     * Define el valor de la propiedad intvCategory.
     * 
     * @param value
     *     allowed object is
     *     {@link IntvCategory }
     *     
     */
    public void setIntvCategory(IntvCategory value) {
        this.intvCategory = value;
    }

    /**
     * Obtiene el valor de la propiedad creationTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreationTime() {
        return creationTime;
    }

    /**
     * Define el valor de la propiedad creationTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreationTime(String value) {
        this.creationTime = value;
    }

    /**
     * Obtiene el valor de la propiedad operatorOrigin.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatorOrigin() {
        return operatorOrigin;
    }

    /**
     * Define el valor de la propiedad operatorOrigin.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorOrigin(String value) {
        this.operatorOrigin = value;
    }

    /**
     * Obtiene el valor de la propiedad contents.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getContents() {
        return contents;
    }

    /**
     * Define el valor de la propiedad contents.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setContents(SwAny value) {
        this.contents = value;
    }

}
