
package gob.bcb.iso20022.swift.saa.model;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Interventions complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Interventions"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Intervention" type="{urn:swift:saa:xsd:saa.2.0}Intervention" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Interventions", propOrder = {
    "interventions"
})
public class Interventions {

    @XmlElement(name = "Intervention", required = true)
    protected List<Intervention> interventions;

    /**
     * Gets the value of the interventions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the interventions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInterventions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Intervention }
     * 
     * 
     */
    public List<Intervention> getInterventions() {
        if (interventions == null) {
            interventions = new ArrayList<Intervention>();
        }
        return this.interventions;
    }

}
