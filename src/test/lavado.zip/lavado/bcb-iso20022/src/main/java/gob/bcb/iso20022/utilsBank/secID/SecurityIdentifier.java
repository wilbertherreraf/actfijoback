package gob.bcb.iso20022.utilsBank.secID;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.IntegerValidator;
import org.apache.commons.validator.routines.checkdigit.CUSIPCheckDigit;
import org.apache.commons.validator.routines.checkdigit.CheckDigitException;
import org.apache.commons.validator.routines.checkdigit.ISINCheckDigit;
import org.apache.commons.validator.routines.checkdigit.SedolCheckDigit;

import gob.bcb.iso20022.utilsBank.Agreement;
import gob.bcb.iso20022.utilsBank.IsoCountry;
import gob.bcb.iso20022.utilsBank.IsoCurrency;

public class SecurityIdentifier {
	public static final Locale LOCALE_EN_US = new Locale("en", "US");
	public static final String PATTERN_ISIN11 = "[A-Z]{2,2}[0-9]{1,1}[A-Z0-9]{8,8}[0-9]{0,1}";
	public static final String PATTERN_CUSIP8 = "[A-Z0-9]{8,8}";
	public static final String CODE_FOREX = "[A-Z]{3,3}/[A-Z]{3,3}[0-9]{0,1}";
	public static final String CODEFUTURE_4_5 = "[A-Z]{1,1}[0-9A-Z]{1,1}[FGHJKMNQUVXZ][0-9]{1,2}";
	public static final String CODEFUTURE_3 = "[A-Z]{1,1}[FGHJKMNQUVXZ][0-9]{1,1}";

	public static Boolean isCusip(String value) {
		value = StringUtils.trimToEmpty(value);
		return (CUSIPCheckDigit.CUSIP_CHECK_DIGIT.isValid(value) && (value.length() == 9));
	}

	public static Boolean isIsin(String value) {
		return value != null && (ISINCheckDigit.ISIN_CHECK_DIGIT.isValid(value.trim()) && (value.trim().length() == 12));
	}

	public static Boolean isSedol(String value) {
		// log.info("OOO> Validator CUSIP " + value);
		return (value != null) && (SedolCheckDigit.SEDOL_CHECK_DIGIT.isValid(value) && (value.trim().length() == 7));
	}

	public static Boolean isIsin11(String value) {
		return value != null && (isIsinWithFormat(value) && ((value.trim().length() == 11) || ISINCheckDigit.ISIN_CHECK_DIGIT.isValid(value.trim())));
	}

	/*
	 * verifica si el codigo matchea con el formato isin
	 */
	public static Boolean isIsinWithFormat(String value) {
		return value != null && Pattern.matches(PATTERN_ISIN11, value);
	}

	public static Boolean isCusip8(String value) {
		value = StringUtils.trimToEmpty(value);
		return CUSIPCheckDigit.CUSIP_CHECK_DIGIT.isValid(value) || (!checkDigit(value).isEmpty() && value.length() == 8); // &&
	}

	public static String checkDigit(String value) {
		try {
			value = StringUtils.trimToEmpty(value);
			String checkD = "";
			if (value.length() == 7 || value.length() == 9 || value.length() == 12) {
				checkD = StringUtils.substring(value, -1);
				if (IntegerValidator.getInstance().isValid(checkD))
					return StringUtils.substring(value, -1);
			}
			if (value.length() == 6)
				return SedolCheckDigit.SEDOL_CHECK_DIGIT.calculate(value);
			if (value.length() == 8)
				return CUSIPCheckDigit.CUSIP_CHECK_DIGIT.calculate(value);
			if (value.length() == 11)
				return ISINCheckDigit.ISIN_CHECK_DIGIT.calculate(value);
			return "";
		} catch (CheckDigitException e) {
			return "";
		}
	}

	public static String getCusipIsinWithDigit(String valuePar) {
		String value = StringUtils.trimToEmpty(valuePar);
		if (StringUtils.isBlank(value))
			return "";
		String cd = checkDigit(value);
		if (StringUtils.isBlank(cd)) {
			return value;
		}

		String secID = getCusipIsinWithoutDigit(value);
		return secID + cd;
	}

	public static String getCusipIsinWithoutDigit(String valuePar) {
		String value = StringUtils.trimToEmpty(valuePar);
		if (StringUtils.isBlank(value))
			return "";
		String cd = checkDigit(value);
		if (StringUtils.isBlank(cd)) {
			return value;
		}

		return value.substring(0, value.length() - 1);
	}

	public static String extractCusip(String value) {
		value = StringUtils.trimToEmpty(value).toUpperCase();
		if (StringUtils.isBlank(value) || value.length() < 5)
			return null;

		String body = bodySecID(value);
		return isCusip(body) ? body : "";
	}

	public static String bodySecID(String value) {
		value = StringUtils.trimToEmpty(value).toUpperCase();
		if (StringUtils.isBlank(value) || value.length() < 5)
			return value;

		String isinCu = getCusipIsinWithoutDigit(value);
		if (isinCu.length() < 2)
			return "";
		Optional<IsoCountry> ic = IsoCountry.fromAlpha2Code(isinCu.substring(0, 2));
		String countryCode = ic.isPresent() && value.length() > 9 ? value.substring(0, 2).toUpperCase() : "";

		String checkDigit = checkDigit(value);
		String body = value.substring(countryCode.length(), value.length() - checkDigit.length());
		return body;
	}

	public static Boolean isCodeSecValidOpt(String value) {
		return isIsin11(value) || isCusip8(value);
	}

	public static Boolean isCodeSecValid(String value) {
		return isIsin(value) || isCusip(value) || isSedol(value);
	}

	public static Predicate<String> isFrxFuture() {
		return codeSecutiry -> isForexFuture(codeSecutiry);
	}

	public static Boolean isForexFuture(String codeSecutiry) {
		return isForexCode(codeSecutiry) || isFutureSymbol(codeSecutiry);
	}
	public static Boolean isForexFuture(String isin, String cusip) {
		return isForexFuture(isin) || isForexFuture(cusip); 
	}
	public static boolean isForexCode(String command) {
		if (StringUtils.isBlank(command))
			return false;
		return Pattern.matches(CODE_FOREX, command.trim().toUpperCase());
	}
	public static boolean isForexCode(String isin, String cusip) {
		return isForexCode(isin) || isForexCode(cusip);
	}
	public static boolean isFutureSymbol(String command) {
		if (command == null)
			return false;

		boolean isMatch = Pattern.matches(CODEFUTURE_4_5, command.trim());
		if (!isMatch && command.trim().length() == 3) {
			isMatch = Pattern.matches(CODEFUTURE_3, command.trim());
		}

		return isMatch;
	}

	public static boolean isForexCode(String command, List<String> monedasList) {
		return isForexCode(command) && //
				monedasList != null && //
				Arrays.asList(command.trim().split("/")).stream()//
						.map(s -> s.substring(0, 3).toUpperCase()).allMatch(s -> monedasList.contains(s));
	}

	public static BiFunction<String, String, Optional<String>> returnCodeSecurity() {
		return (isin, cusip) -> {
			String idSecPrinc = StringUtils.trimToEmpty(isin).toUpperCase();
			String idSecOtro = StringUtils.trimToEmpty(cusip).toUpperCase();

			if (StringUtils.isBlank(idSecPrinc) && StringUtils.isBlank(idSecOtro)) {
				return Optional.empty();
			}

			if (idSecPrinc.equals(idSecOtro)) {
				idSecOtro = "";
			}
			if (isForexFuture(idSecPrinc,idSecOtro)) {
				return Optional.empty();
			}

			if (StringUtils.isBlank(idSecPrinc) || StringUtils.isBlank(idSecOtro)) {
				if (StringUtils.isBlank(idSecPrinc)) {
					idSecPrinc = idSecOtro;
					idSecOtro = "";
				}
			}
			
			return !StringUtils.isBlank(idSecPrinc) ? Optional.of(idSecPrinc) : Optional.empty();
		};
	}

	/**
	 * determina si un codigo de sec es intercambiable
	 * 
	 * @param isincusptipo
	 * @param isincuspsfx
	 * @return
	 */
	public static boolean isIsinCuInter(String isincusptipo, String isincuspsfx) {
		if (StringUtils.isBlank(isincusptipo) || StringUtils.isBlank(isincuspsfx)) {
			return false;
		}

		Boolean isIsi = isincusptipo.equalsIgnoreCase("ISIN") && isincuspsfx.trim().length() == 2;
		Boolean isCuUS = isincusptipo.equalsIgnoreCase("CUSP") && isincuspsfx.equalsIgnoreCase("US");
		return isIsi || isCuUS;
	}

	public static String ctrySecID(String valueIn) {
		String value = StringUtils.trimToEmpty(valueIn).toUpperCase();
		if (StringUtils.isBlank(value) || value.length() < 2)
			return value;
		Boolean matche = Pattern.matches("[A-Z]{2,2}[0-9]{1,1}[A-Z0-9]{1,}", value);
		Optional<IsoCountry> ic = IsoCountry.fromAlpha2Code(value.substring(0, 2));

		return (ic.isPresent() && (matche || value.length() == 2)) ? ic.get().getAlpha2Code() : "";
	}

	public static String codePart(String codeSecurity, String tipoSec) {
		if (StringUtils.isBlank(codeSecurity))
			return "";

		tipoSec = StringUtils.trimToEmpty(tipoSec).toUpperCase();
		codeSecurity = StringUtils.trimToEmpty(codeSecurity).toUpperCase();
		String ctryIDSec = ctrySecID(codeSecurity);

		if (StringUtils.isBlank(ctryIDSec)) {
			if (codeSecurity.startsWith("XS") && (isIsin(codeSecurity) || isIsin11(codeSecurity))) {
				return "EU";
			}
			if (StringUtils.isBlank(tipoSec))
				return "";
		}
		
		Optional<IsoCountry> isoCtryOpt = IsoCountry.fromAlpha2Code(ctryIDSec);
		if (isoCtryOpt.isPresent()) {
			IsoCountry isoCtry = isoCtryOpt.get();
			boolean isEU = isoCtry.isParticipatingTo(Agreement.SINGLE_EURO_PAYMENTS_AREA);
			if (isEU)
				return "EU";
		}
		
		if (ctryIDSec.equals("US") || ctryIDSec.equals("CA"))
			return "US";

		if (tipoSec.equals("CUSP")) {
			Boolean matcheCu = Pattern.matches("[A-Z]{1,1}[A-Z0-9]{1,}", codeSecurity.trim());
			if (!matcheCu) {
				return "US";
			}

			if (codeSecurity.startsWith("PP")) {
				return "PP";
			} else {
				return "YY";
			}
		} else if (tipoSec.equals("SEDL")) {
			return "GB";
		} else {
			if (!StringUtils.isBlank(tipoSec)) {
				return "CUST";
			}
		}

		return ctryIDSec;
	}

	public static BiFunction<String, String, String> tipoCodeSecurity(Consumer<String> proprietaryC) {
		return (isin, cusip) -> {
			String codeSecurity = returnCodeSecurity().apply(isin, cusip).orElse("");
			if (StringUtils.isBlank(codeSecurity)) {
				return null;
			}

			String tipoSec = "";

			if (isIsin(codeSecurity) || isIsin11(codeSecurity)) {
				tipoSec = "ISIN";
			} else if (isCusip(codeSecurity)) {
				tipoSec = "CUSP";

			} else if (isSedol(codeSecurity)) {
				tipoSec = "SEDL";
			} else {
				tipoSec = "TIKR";
			}

			String proprietarySch0 = codePart(codeSecurity, tipoSec);
			if (proprietaryC != null) {
				proprietaryC.accept(proprietarySch0);
			}

			return tipoSec;
		};
	}

}
