package gob.bcb.iso20022.swift;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.SwiftTagListBlock;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field14D;
import com.prowidesoftware.swift.model.field.Field17R;
import com.prowidesoftware.swift.model.field.Field19A;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field20C;
import com.prowidesoftware.swift.model.field.Field21;
import com.prowidesoftware.swift.model.field.Field22A;
import com.prowidesoftware.swift.model.field.Field22B;
import com.prowidesoftware.swift.model.field.Field22C;
import com.prowidesoftware.swift.model.field.Field22F;
import com.prowidesoftware.swift.model.field.Field23;
import com.prowidesoftware.swift.model.field.Field23B;
import com.prowidesoftware.swift.model.field.Field23G;
import com.prowidesoftware.swift.model.field.Field25;
import com.prowidesoftware.swift.model.field.Field26C;
import com.prowidesoftware.swift.model.field.Field30;
import com.prowidesoftware.swift.model.field.Field30P;
import com.prowidesoftware.swift.model.field.Field30T;
import com.prowidesoftware.swift.model.field.Field30V;
import com.prowidesoftware.swift.model.field.Field30X;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field32B;
import com.prowidesoftware.swift.model.field.Field32F;
import com.prowidesoftware.swift.model.field.Field33B;
import com.prowidesoftware.swift.model.field.Field34E;
import com.prowidesoftware.swift.model.field.Field35B;
import com.prowidesoftware.swift.model.field.Field36;
import com.prowidesoftware.swift.model.field.Field36B;
import com.prowidesoftware.swift.model.field.Field37G;
import com.prowidesoftware.swift.model.field.Field50A;
import com.prowidesoftware.swift.model.field.Field50F;
import com.prowidesoftware.swift.model.field.Field50K;
import com.prowidesoftware.swift.model.field.Field52A;
import com.prowidesoftware.swift.model.field.Field52D;
import com.prowidesoftware.swift.model.field.Field53A;
import com.prowidesoftware.swift.model.field.Field53B;
import com.prowidesoftware.swift.model.field.Field53D;
import com.prowidesoftware.swift.model.field.Field54A;
import com.prowidesoftware.swift.model.field.Field54B;
import com.prowidesoftware.swift.model.field.Field54D;
import com.prowidesoftware.swift.model.field.Field56A;
import com.prowidesoftware.swift.model.field.Field56D;
import com.prowidesoftware.swift.model.field.Field57A;
import com.prowidesoftware.swift.model.field.Field57B;
import com.prowidesoftware.swift.model.field.Field57D;
import com.prowidesoftware.swift.model.field.Field58A;
import com.prowidesoftware.swift.model.field.Field58D;
import com.prowidesoftware.swift.model.field.Field59;
import com.prowidesoftware.swift.model.field.Field59A;
import com.prowidesoftware.swift.model.field.Field59F;
import com.prowidesoftware.swift.model.field.Field70;
import com.prowidesoftware.swift.model.field.Field71A;
import com.prowidesoftware.swift.model.field.Field71F;
import com.prowidesoftware.swift.model.field.Field72;
import com.prowidesoftware.swift.model.field.Field79;
import com.prowidesoftware.swift.model.field.Field82A;
import com.prowidesoftware.swift.model.field.Field87A;
import com.prowidesoftware.swift.model.field.Field88A;
import com.prowidesoftware.swift.model.field.Field90A;
import com.prowidesoftware.swift.model.field.Field94A;
import com.prowidesoftware.swift.model.field.Field95P;
import com.prowidesoftware.swift.model.field.Field95R;
import com.prowidesoftware.swift.model.field.Field97A;
import com.prowidesoftware.swift.model.field.Field98A;
import com.prowidesoftware.swift.model.field.Narrative;
import com.prowidesoftware.swift.model.field.Narrative.Builder;
import com.prowidesoftware.swift.model.field.SwiftParseUtils;
import com.prowidesoftware.swift.model.mt.mt3xx.MT300;
import com.prowidesoftware.swift.model.mt.mt3xx.MT320;
import com.prowidesoftware.swift.model.mt.mt5xx.MT541;
import com.prowidesoftware.swift.utils.LineWrapper;

import gob.bcb.iso20022.commons.Constants;
import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.utils.MxDataTypesConversor;
import gob.bcb.iso20022.utils.UtilsGeneric;

/**
 * @author: wherrera
 * 
 */
public class FieldsCommand {
	private static final Logger log = LoggerFactory.getLogger(FieldsCommand.class);
	final static String VALUE = "VALUE";

	public static final Map<String, Function<SwfMencampos, Optional<Field>>> mapFieldFunc = new HashMap<>();
	public static final Map<String, Function<SwfMencampos, Optional<Function<SwiftTagListBlock, SwiftTagListBlock>>>> mapSequenceFunc = new HashMap<>();

	public static final Map<String, Function<SwiftTagListBlock, SwiftTagListBlock>> codMTNemoSeqCreate = new HashMap<>();
	public static final Map<String, String> relPatternsAllows = new HashMap<>();

	public static final Map<String, Function<String, Supplier<Optional<CampoForm>>>> funcConvertCompo = new HashMap<>();

	public static final String SWF_FLD_CMP_NAMEADDRESS = "NAMEADDRESS";
	public static final String SWF_FLD_CMP_NAME = "NAME";
	public static final String SWF_FLD_CMP_ADDRESS = "ADDRESS";
	public static final String SWF_FLD_CMP_ACCOUNT = "ACCOUNT";
	public static final String SWF_FLD_CMP_BIC = "BIC";
	public static final String SWF_FLD_CMP_QUALIFIER = "QUALIFIER";
	public static final String SWF_FLD_CMP_AMOUNT = "AMOUNT";
	public static final String SWF_FLD_CMP_CURRENCY = "CURRENCY";
	public static final String SWF_FLD_CMP_DATE = "DATE";
	public static final String SWF_FLD_CMP_REFERENCE = "REFERENCE";
	public static final String SWF_FLD_CMP_DATASOURCESCHEME = "DATASOURCESCHEME";
	public static final String SWF_FLD_CMP_TYPE = "TYPE";
	public static final String SWF_FLD_CMP_INDICATOR = "INDICATOR";
	public static final String SWF_FLD_CMP_ISIN = "ISIN";
	public static final String SWF_FLD_CMP_NARRATIVE = "NARRATIVE";

	public static final Map<String, Object> fctNtve = new HashMap<String, Object>();
	static {
		try {
			fctNtve.put("ntveAmt", FieldsCommand.class.getMethod("ntveAmt", String.class, String.class, BigDecimal.class));
			fctNtve.put("dateBO", MxDataTypesConversor.class.getMethod("dateBO", Date.class));
			fctNtve.put("amtFmt", MxDataTypesConversor.class.getMethod("amtFmt", BigDecimal.class));
		} catch (Exception e) {
			log.error("error al registrar metodos " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public FieldsCommand() {
		initSeqFuncMap();
	}

	public static void initSeqFuncMap() {
		codMTNemoSeqCreate.put("541.SA", swfTagListBlk -> MT541.SequenceA.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SA1", swfTagListBlk -> MT541.SequenceA1.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SB", swfTagListBlk -> MT541.SequenceB.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SB1", swfTagListBlk -> MT541.SequenceB1.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SC", swfTagListBlk -> MT541.SequenceC.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SC1", swfTagListBlk -> MT541.SequenceC1.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SD", swfTagListBlk -> MT541.SequenceD.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SE", swfTagListBlk -> MT541.SequenceE.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SE1", swfTagListBlk -> MT541.SequenceE1.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SE2", swfTagListBlk -> MT541.SequenceE2.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SE3", swfTagListBlk -> MT541.SequenceE3.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("541.SF", swfTagListBlk -> MT541.SequenceF.newInstance(swfTagListBlk));

		codMTNemoSeqCreate.put("300.SA", swfTagListBlk -> MT300.SequenceA.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("300.SB", swfTagListBlk -> MT300.SequenceB.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("300.SB1", swfTagListBlk -> MT300.SequenceB1.newInstance(new Tag[swfTagListBlk.getTags().size()]));
		codMTNemoSeqCreate.put("300.SB2", swfTagListBlk -> MT300.SequenceB2.newInstance(new Tag[swfTagListBlk.getTags().size()]));
		codMTNemoSeqCreate.put("300.SC", swfTagListBlk -> MT300.SequenceC.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("300.SD", swfTagListBlk -> MT300.SequenceD.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("300.SE", swfTagListBlk -> MT300.SequenceE.newInstance(swfTagListBlk));
		// codMTNemoSeqCreate.put("300.SE1", swfTagListBlk ->
		// MT300.SequenceE.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("300.SE2", swfTagListBlk -> MT300.SequenceE1a.newInstance(new Tag[swfTagListBlk.getTags().size()]));
		codMTNemoSeqCreate.put("300.SE3", swfTagListBlk -> MT300.SequenceE1a1.newInstance(swfTagListBlk.asTagArray()));

		codMTNemoSeqCreate.put("320.SA", swfTagListBlk -> MT320.SequenceA.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("320.SB", swfTagListBlk -> MT320.SequenceB.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("320.SC", swfTagListBlk -> MT320.SequenceC.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("320.SD", swfTagListBlk -> MT320.SequenceD.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("320.SE", swfTagListBlk -> MT320.SequenceE.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("320.SF", swfTagListBlk -> MT320.SequenceF.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("320.SG", swfTagListBlk -> MT320.SequenceG.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("320.SH", swfTagListBlk -> MT320.SequenceH.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("320.SI", swfTagListBlk -> MT320.SequenceI.newInstance(swfTagListBlk));
		codMTNemoSeqCreate.put("320.SI1", swfTagListBlk -> MT320.SequenceI.newInstance(swfTagListBlk.asTagArray()));

		// registramos los patrones del campo nemo relacionado con la creacion de la
		// sequence o bloque
		// key: patron nemo , value: patron en codMTNemoSeqCreate
		relPatternsAllows.put(Constants.SWF_PATT_SEQ + "[0]" + Constants.SWF_PATT_SEPUNIQ, "S[A-Z]");
		relPatternsAllows.put(Constants.SWF_PATT_SEQ + Constants.SWF_PATT_SEPUNIQ, "S[A-Z]");
		relPatternsAllows.put(Constants.SWF_PATT_SEQ + "[1-9]" + Constants.SWF_PATT_SEPUNIQ, "S[A-Z][1-9]");

	}

	public static Function<SwfMencampos, Optional<Function<SwiftTagListBlock, SwiftTagListBlock>>> findFctFromMap() {
		return swfMencampos -> {
			String cadSeq = UtilsGeneric.extractStrForPatt(relPatternsAllows).apply(swfMencampos.getMtfNemo()).orElse("");
			String codSeqFind = swfMencampos.getMtfCodmt() + Constants.SWF_PATT_SEP + cadSeq;

			Function<SwiftTagListBlock, SwiftTagListBlock> fseq = codMTNemoSeqCreate.get(codSeqFind);

			return Optional.ofNullable(fseq);
		};
	}

	public static Function<SwfMencampos, Optional<Function<SwiftTagListBlock, SwiftTagListBlock>>> create16R(
			Function<SwfMencampos, Function<String, Optional<CampoForm>>> findCalCFE) {
		return swfMencampos -> {
			return findFctFromMap().apply(swfMencampos);
		};
	}

	public static Field fld50F(String ctaNro, String name, String address, String ctry, String city) {
		ctaNro = StringUtils.trimToEmpty(ctaNro);
		Field50F f = new Field50F();
		if (ctaNro.startsWith("/")) {
			f.setComponent1(ctaNro);
		} else {
			f.setComponent1("/" + ctaNro);
		}
		name = StringUtils.trimToEmpty(name);
		address = StringUtils.trimToEmpty(address);
		List<String> lname = UtilsGeneric.splitInLines(33, name, 2, " ", "", 0);
		List<String> laddress = UtilsGeneric.splitInLines(33, address, 2, " ", "", 0);

		f.setComponent2("1").setComponent3(lname.get(0));
		if (lname.size() > 1) {
			f.setComponent4("1").setComponent5(lname.get(1));
			f.setComponent6("2").setComponent7(laddress.get(0));
		}

		if (lname.size() == 1 && laddress.size() >= 1) {
			f.setComponent4("2").setComponent5(laddress.get(0));
			if (laddress.size() > 1)
				f.setComponent6("2").setComponent7(laddress.get(1));
		}
		if (!StringUtils.isAnyBlank(ctry, city)) {
			boolean isMatch = Pattern.matches("[A-Z]{2,2}", ctry);
			if (isMatch)
				f.setComponent8("3").setComponent9(ctry + "/" + city);
		}
		return f;
	}

	public static Field fld59F(String ctaNro, String name, String address, String ctry, String city) {
		log.info("ctaNro {}, name {}, address {}, ctry {}, city {}", ctaNro, name, address, ctry, city);
		ctaNro = StringUtils.trimToEmpty(ctaNro);
		Field59F f = new Field59F();
		f.setComponent1(ctaNro);

		name = StringUtils.trimToEmpty(name);
		address = StringUtils.trimToEmpty(address);
		List<String> lname = UtilsGeneric.splitInLines(33, name, 2, " ", "", 0);
		List<String> laddress = UtilsGeneric.splitInLines(33, address, 2, " ", "", 0);

		int i = 2;
		f.setComponent(i++, "1");
		f.setComponent(i++, lname.get(0));//3
		if (lname.size() > 1){
			f.setComponent(i++, "1");//4
			f.setComponent(i++, lname.get(1));//5
		}
		
		f.setComponent(i++, "2");// 4 6
		f.setComponent(i++, laddress.get(0)); // 5 7
		
		if (laddress.size() > 1 && i <= 6){
			f.setComponent(i++, "2"); //  
			f.setComponent(i++, laddress.get(1));
		}
		if (!StringUtils.isAnyBlank(ctry, city) && Pattern.matches("[A-Z]{2,2}", ctry)) {
			f.setComponent(i++, "3");
			f.setComponent(i++, ctry + "/" + city);
		}

		return f;
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f21(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}

			Field21 f = new Field21();
			f.setReference(valor);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, valor);
			cf.setValorObj(f);
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f23B(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}

			Field23B f = new Field23B().setType(valor);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, valor);
			cf.setValorObj(f);
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f25(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}

			Field25 f = new Field25().setAccount(valor);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, valor);
			cf.setValorObj(f);
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f32A(CampoForm cfI) {
		return swf -> {
			if (cfI == null) {
				return Optional.empty();
			}
			if (StringUtils.isBlank(cfI.getValorAdic())) {
				return Optional.empty();
			}
			log.info("En 32A {} {} {}", cfI.getFecha(), cfI.getValorAdic(), cfI.getValDecimal());
			Calendar c = GregorianCalendar.getInstance();
			c.setTime(cfI.getFecha());

			Field32A f = new Field32A().setDate(c).setCurrency(Currency.getInstance(cfI.getValorAdic())).setAmount(cfI.getValDecimal());

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f33B(String codMoneda, BigDecimal monto) {
		return swf -> {
			if (StringUtils.isBlank(codMoneda)) {
				return Optional.empty();
			}

			Currency currency = Currency.getInstance(codMoneda);

			Field33B f = new Field33B().setCurrency(currency.getCurrencyCode()).setAmount(monto);

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f50A(String bic) {
		return swf -> {
			if (StringUtils.isBlank(bic)) {
				return Optional.empty();
			}
			Field50A f = new Field50A();
			BIC bicswf = new BIC(bic);
			f.setComponent2(bicswf);

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f50F(String ctaNro, String name, String address, String ctry, String city) {
		return swf -> {
			String cta = StringUtils.removeStart(ctaNro, "IBAN/");
			Field50F f = (Field50F) fld50F(cta, name, address, ctry, city);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f50K(Instruccion instrucion, String ctaNroIn, String locationIn) {
		return swf -> {
			String ctaNro = StringUtils.trimToEmpty(ctaNroIn);
			ctaNro = StringUtils.removeStart(ctaNro, "IBAN/");
			String location = StringUtils.trimToEmpty(locationIn);

			Field50K f = new Field50K().setAccount(ctaNro);

			List<String> lines = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS, location, 4, " ", "", 0);
			SwiftParseUtils.setComponentsFromLines(f, 2, 4, 0, lines);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, f.getValue());
			cf.setValorObj(f);
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f50K(String ctaNro, String nameI, String locationI) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				return Optional.empty();
			}

			String name = StringUtils.trimToEmpty(nameI);
			String location = StringUtils.trimToEmpty(locationI);

			Field50K f = new Field50K();
			f.setAccount(ctaNro);
			String nameandlocation = name + " " + location;
			f.setNameAndAddressLine1(nameandlocation);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f52A(String ctaNro, String bic) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				//return Optional.empty();
			}
			if (StringUtils.isBlank(bic)) {
				return Optional.empty();
			}

			Field52A f = new Field52A();
			if (!StringUtils.isBlank(ctaNro)) 
				f.setAccount(ctaNro);
			BIC bicswf = new BIC(bic);
			f.setIdentifierCode(bicswf);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f52D(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}

			Field52D f = new Field52D();
			f.setAccount(valor);
			f.setNameAndAddress(valor);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f53A(String ctaNro, String bic) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				return Optional.empty();
			}
			if (StringUtils.isBlank(bic)) {
				return Optional.empty();
			}

			Field53A f = new Field53A();
			f.setAccount(ctaNro);
			BIC bicswf = new BIC(bic);
			f.setIdentifierCode(bicswf);

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f53B(String ctaNro, String location) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				return Optional.empty();
			}
			if (StringUtils.isBlank(location)) {
				//return Optional.empty();
			}
			String cta = StringUtils.removeStart(ctaNro, "IBAN/");
			Field53B f = new Field53B();
			f.setAccount(cta);
			if (!StringUtils.isBlank(location)) {
				f.setLocation(location);
	
				SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 35, location);
			}
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f53D(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}

			Field53D f = new Field53D();
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, valor);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f54A(String ctaNro, String bic) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				//return Optional.empty();
			}
			if (StringUtils.isBlank(bic)) {
				return Optional.empty();
			}

			Field54A f = new Field54A();
			if (!StringUtils.isBlank(ctaNro)) 
				f.setAccount(ctaNro);
			BIC bicswf = new BIC(bic);
			f.setIdentifierCode(bicswf);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f54B(String ctaNro, String location) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				return Optional.empty();
			}
			if (StringUtils.isBlank(location)) {
				return Optional.empty();
			}

			Field54B f = new Field54B();
			f.setAccount(ctaNro);
			f.setLocation(location);
			SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 35, location);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f54D(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}
			Field54D f = new Field54D();
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f56A(String ctaNro, String bic) {
		return swf -> {
			if (StringUtils.isBlank(bic)) {
				return Optional.empty();
			}

			Field56A f = new Field56A();
			if (!StringUtils.isBlank(ctaNro))
				f.setAccount(ctaNro);

			BIC bicswf = new BIC(bic);
			f.setIdentifierCode(bicswf);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f56D(String ctaNro, String valor) {
		return swf -> {
			Field56D f = new Field56D(valor).setNameAndAddress(valor).setAccount(ctaNro);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f57A(String ctaNro, String bic) {
		return swf -> {
			if (StringUtils.isBlank(bic)) {
				return Optional.empty();
			}
			Field57A f = new Field57A();
			if (!StringUtils.isBlank(ctaNro))
				f.setAccount(ctaNro);

			BIC bicswf = new BIC(bic);
			f.setIdentifierCode(bicswf);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f57B(String ctaNro, String location) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				return Optional.empty();
			}
			if (StringUtils.isBlank(location)) {
				return Optional.empty();
			}

			Field57B f = new Field57B();
			f.setAccount(ctaNro);
			f.setLocation(location);
			SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 35, location);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f57D(String ctaNroI, String nameI, String location) {
		return swf -> {
			if (StringUtils.isBlank(ctaNroI)) {
				return Optional.empty();
			}
			String ctaNro = StringUtils.trimToEmpty(ctaNroI).toUpperCase();
			if (ctaNro.startsWith("FW")) {
				ctaNro = "/".concat(ctaNro);
			}

			Field57D f = new Field57D();
			f.setAccount(ctaNro);

			List<String> lines = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS, nameI, 4, " ", "", 0);
			if (!StringUtils.isBlank(location)) 
				lines.add(location);
			// System.out.println("location " + ArrayUtils.toString(lines));
			SwiftParseUtils.setComponentsFromLines(f, 3, 4, 0, lines);

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f58A(String ctaNro, String bic) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				//return Optional.empty();
			}
			if (StringUtils.isBlank(bic)) {
				return Optional.empty();
			}

			Field58A f = new Field58A();
			if (!StringUtils.isBlank(ctaNro)) 
				f.setAccount(ctaNro);
			BIC bicswf = new BIC(bic);
			f.setIdentifierCode(bicswf);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f58D(String ctaNroI, String location) {
		return swf -> {
			if (StringUtils.isBlank(ctaNroI)) {
				return Optional.empty();
			}
			if (StringUtils.isBlank(location)) {
				return Optional.empty();
			}
			String ctaNro = ctaNroI;
			if (ctaNro.startsWith("FW")) {
				ctaNro = "/".concat(ctaNro);
			}

			Field58D f = new Field58D();
			f.setAccount(ctaNro);
			SwiftParseUtils.setComponentsFromTokens(f, 3, 5, 35, location);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f58D(String ctaNro, String name, String location) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				return Optional.empty();
			}
			if (StringUtils.isBlank(name)) {
				return Optional.empty();
			}

			List<String> lines0 = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS, name, 2, " ", "", 0);
			List<String> lines1 = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS, location, 2, " ", "", 0);

			List<String> lines = new ArrayList<String>();
			lines.addAll(lines0);
			lines.addAll(lines1);

			Field58D f = new Field58D();
			f.setAccount(ctaNro);
			SwiftParseUtils.setComponentsFromLines(f, 2, 4, 0, lines);			
//			String nameandlocation = name + " " + location;
//			f.setNameAndAddressLine1(nameandlocation);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f59(String ctaNro, String name, String location) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				return Optional.empty();
			}
			if (StringUtils.isBlank(name)) {
				return Optional.empty();
			}

			// location = name + "\n\r" + location;
			Field59 f = new Field59();
			f.setAccount(ctaNro);

			List<String> lines0 = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS, name, 2, " ", "", 0);
			List<String> lines1 = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS, location, 2, " ", "", 0);

			List<String> lines = new ArrayList<String>();
			lines.addAll(lines0);
			lines.addAll(lines1);
			SwiftParseUtils.setComponentsFromLines(f, 2, 4, 0, lines);

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f59A(String ctaNro, String bic) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				//return Optional.empty();
			}
			if (StringUtils.isBlank(bic)) {
				return Optional.empty();
			}

			Field59A f = new Field59A();
			if (!StringUtils.isBlank(ctaNro))
				f.setAccount(ctaNro);
			BIC bicswf = new BIC(bic);
			f.setIdentifierCode(bicswf);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f59F(String ctaNro, String name, String address, String ctry, String city) {
		return swf -> {
			if (StringUtils.isBlank(ctaNro)) {
				return Optional.empty();
			}

			if (StringUtils.isBlank(name)) {
				return Optional.empty();
			}
			
			String cta = StringUtils.removeStart(ctaNro, "IBAN/");
			Field59F f = (Field59F) fld59F(cta, name, address, ctry, city);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f70(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}
			String valorA = StringUtils.trimToEmpty(valor);
			List<String> lines = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS - 1, valorA, 4, "", null, 0);
			int i = 1;
			StringBuilder sb = new StringBuilder();
			for (String l : lines) {
				if (lines.size() > i)
					sb.append(l).append("\r\n");
				else
					sb.append(l);
				i++;
			}
			;
			Field70 f = new Field70(sb.toString());
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f70Ntve(CampoForm cfIn) {
		return swf -> {

			if (cfIn == null || cfIn.getValorObj() == null) {
				return Optional.empty();
			}
			StringBuilder sb = new StringBuilder();
			Map<String, String> codesmap = (Map<String, String>) cfIn.getValorObj();
			int i = 1;
			for (Entry<String, String> entry : codesmap.entrySet()) {
				String txt = entry.getValue();
				String nrrtve = ntveUnStr(entry.getKey(), txt);
				sb.append(nrrtve).append(i++ < codesmap.size() ? "\r\n" : "");
			}
			if (StringUtils.isBlank(sb.toString())) {
				return Optional.empty();
			}
			
			Field70 f = new Field70(sb.toString());
			CampoForm cf = new CampoForm("70", VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}
	
	public static Function<SwfMencampos, Optional<CampoForm>> f70CF(CampoForm cfIn) {
		return swf -> {
			if (cfIn == null) {
				return Optional.empty();
			}

			String valor = cfIn.getValor();
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}
			String valorA = StringUtils.trimToEmpty(valor);
			List<String> lines = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS - 1, valorA, 4, "", null, 0);
			int i = 1;
			StringBuilder sb = new StringBuilder();
			for (String l : lines) {
				if (lines.size() > i)
					sb.append(l).append("\r\n");
				else
					sb.append(l);
				i++;
			}
			;
			Field70 f = new Field70(sb.toString());
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f71A(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}

			Field71A f = new Field71A(valor);

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f71F(String codMoneda, BigDecimal monto) {
		return swf -> {
			if (StringUtils.isBlank(codMoneda)) {
				return Optional.empty();
			}
			if (monto == null) {
				return Optional.empty();
			}

			Field71F f = new Field71F();
			Currency currency = Currency.getInstance(codMoneda);
			f.setCurrency(currency);
			f.setAmount(monto);

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> f72(String valorI) {
		return swf -> {
			if (StringUtils.isBlank(valorI)) {
				return Optional.empty();
			}

			String valorA = StringUtils.trimToEmpty(valorI);
			List<String> lines = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS - 1, valorA, 6, "", "//", 1);
			int i = 1;
			StringBuilder sb = new StringBuilder();
			for (String l : lines) {
				if (lines.size() > i)
					sb.append(l).append("\r\n");
				else
					sb.append(l);
				i++;
			}
			;
			Field72 f = new Field72(sb.toString());
			CampoForm cf = new CampoForm("72", VALUE, valorA);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 

	}

	public static Function<SwfMencampos, Optional<CampoForm>> f72CF(CampoForm cfIn) {
		return swf -> {
			if (cfIn == null) {
				return Optional.empty();
			}
			String valorI = cfIn.getValor();
			if (StringUtils.isBlank(valorI)) {
				return Optional.empty();
			}

			String valorA = StringUtils.trimToEmpty(valorI);
			List<String> lines = UtilsGeneric.splitInLines(UtilsGeneric.MAX_LINE_CHARS - 1, valorA, 6, "", "//", 1);
			int i = 1;
			StringBuilder sb = new StringBuilder();
			for (String l : lines) {
				if (lines.size() > i)
					sb.append(l).append("\r\n");
				else
					sb.append(l);
				i++;
			}
			;
			Field72 f = new Field72(sb.toString());

			CampoForm cf = new CampoForm("72", VALUE, valorA);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 

	}

	public static Function<SwfMencampos, Optional<CampoForm>> f72Ntve(CampoForm cfIn) {
		return swf -> {

			if (cfIn == null || cfIn.getValorObj() == null) {
				return Optional.empty();
			}
			StringBuilder sb = new StringBuilder();
			Map<String, String> codesmap = (Map<String, String>) cfIn.getValorObj();
			int i = 1;
			for (Entry<String, String> entry : codesmap.entrySet()) {
				String txt = entry.getValue();
				String nrrtve = ntveUnStr(entry.getKey(), txt);
				sb.append(nrrtve).append(i++ < codesmap.size() ? "\r\n" : "");
			}
			if (StringUtils.isBlank(sb.toString())) {
				return Optional.empty();
			}
			
			Field72 f = new Field72(sb.toString());
			CampoForm cf = new CampoForm("72", VALUE, null);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 

	}

	public static Function<SwfMencampos, Optional<CampoForm>> f72SinModificar(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor)) {
				return Optional.empty();
			}

			Field72 f = new Field72(valor);
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, valor);
			cf.setValorObj(f);
			return Optional.of(cf);
		}; 
	}

	public static Map<String, String> mapNarrative(String narr, Map<String, Object> mapf) {
		mapf.putAll(fctNtve);
		Map<String, String> cdmpRes = FieldsCommandMx.mapNarrative(narr, mapf);
		return cdmpRes;
	}

	public static String ntveAmt(String codeword, String curr, BigDecimal amt) {
//		Builder bN = Narrative.builder(35);
//		bN.addCodewordWithAmount(codeword, curr, amt, null);
//		Narrative nrrtve = bN.build();
		String prefix = "/" + StringUtils.trimToEmpty(codeword) + "/" + StringUtils.trimToEmpty(curr) + MxDataTypesConversor.amtFmt(amt);
		return prefix;
	}

	public static String ntveStr(String codeword, String narrative) {
		Builder bN = Narrative.builder(35);
		bN.addCodeword(codeword, narrative);
		Narrative nrrtve = bN.build();
		return nrrtve.getUnstructured();
	}

	public static String ntveUnStr(String codeword, String narrative) {
		Builder bN = Narrative.builder(UtilsGeneric.MAX_LINE_CHARS);
		String cdSep = "//";
		List<String> result = SwiftParseUtils.splitComponents(narrative, "", cdSep);
		int start = 0;
		if (!StringUtils.isBlank(codeword)) {
			String txt = StringUtils.remove(result.get(0), '\\');
			bN.addCodeword(codeword, txt);
			start = 1;
		} else {
			cdSep = "";
		}

		for (int i = start; i < result.size(); i++) {
			List<String> lines = LineWrapper.wrapIntoList(result.get(i), UtilsGeneric.MAX_LINE_CHARS - 2);
			for (String s : lines) {
				String txt = StringUtils.remove(s, '\\');
				bN.addUnstructured(cdSep + txt);
			}
		}

		Narrative nrrtve = bN.build();
		return nrrtve.getValue();
	}

	public static CampoForm fGen(SwfMencampos swfMencampos, String name, String option, String qualifier, String codeset,
			Function<SwfMencampos, Optional<CampoForm>> contentsF) {
		log.info("-> ingresando {} - {} - {} = {} :: {}", name, qualifier, codeset, swfMencampos.getMtfNemo(), swfMencampos.getMtfId());
		Optional<CampoForm> cfOpt = Optional.empty();

		if (contentsF != null) {
			cfOpt = contentsF.apply(swfMencampos);
			if (!cfOpt.isPresent()) {
				return null;
			}
		}

		CampoForm cf = cfOpt.orElse(new CampoForm());
		if (cf.getValorObj() != null) {
			if (cf.getValorObj() instanceof Field) {
				return cf;
			}
		}

		option = StringUtils.trimToEmpty(option);
		codeset = StringUtils.trimToEmpty(codeset);

		String valor = cf.getValor();
		Field field = null;

		if (option.equalsIgnoreCase("code")) {
			cf.setValor(codeset);
			field = fgen(swfMencampos, name, option, qualifier, codeset, cf);
		} else if (option.equalsIgnoreCase("amtcurr")) {
			if (name.equals("32A")) {
				return f32A(cf).apply(swfMencampos).get();
			}
		} else {
			field = fgen(swfMencampos, name, option, qualifier, codeset, cf);
		}

		cf.setValorObj(field);

		return cf;
	}

	public static Field fgen(SwfMencampos swfMencampos, String name, String option, String qualifier, String codeset, CampoForm cf) {
		String idsc = swfMencampos != null ? swfMencampos.toStringID() : "";
		//log.info("ingresando {} - {} - {} = {}", name, qualifier, codeset, idsc);

		if (cf.getValorObj() != null) {
			if (cf.getValorObj() instanceof Field) {
				Field f = (Field) cf.getValorObj();
				return f;
			}
		}

		String contents = cf.getValor();
		Field field = null;
		boolean contentsBlank = StringUtils.isBlank(contents);

		if (name.equals("14D")) {
			if (contentsBlank)
				return null;
			field = new Field14D().setDayCountFraction(contents);
		} else if (name.equals("17R")) {
			field = new Field17R().setIndicator(codeset);
		} else if (name.equals("19A")) {
			if (contentsBlank)
				return null;
			field = new Field19A(contents);
		} else if (name.equals("20")) {
			if (contentsBlank)
				return null;
			field = new Field20().setReference(contents);
		} else if (name.equals("20C")) {
			if (contentsBlank)
				return null;
			field = new Field20C().setQualifier(qualifier).setReference(contents);

		} else if (name.equals("21")) {
			if (contentsBlank)
				return null;
			field = new Field21().setReference(contents);
		} else if (name.equals("22A")) {
			field = new Field22A().setType(codeset);
		} else if (name.equals("22B")) {
			field = new Field22B().setType(codeset);
		} else if (name.equals("22C")) {
			if (contentsBlank)
				return null;
			field = new Field22C().setComponent1(contents);
		} else if (name.equals("22F")) {
			field = new Field22F().setQualifier(qualifier).setIndicator(codeset);
		} else if (name.equals("23")) {
			field = new Field23().setBuySellIndicator(codeset);
		} else if (name.equals("23B")) {
			field = new Field23B().setType(codeset);
		} else if (name.equals("25")) {
			if (contentsBlank)
				return null;
			field = new Field25().setAccount(contents);
		} else if (name.equals("23G")) {
			field = new Field23G().setFunction(qualifier).setSubfunction(codeset);
		} else if (name.equals("26C")) {
			field = new Field26C().setAllocation(qualifier).setDeliveryLocation(codeset);
		} else if (name.equals("30")) {
			field = new Field30().setDate(cf.getFechaAsCalendar());
		} else if (name.equals("30P")) {
			field = new Field30P().setDate(cf.getFechaAsCalendar());
		} else if (name.equals("30T")) {
			field = new Field30T().setDate(cf.getFechaAsCalendar());
		} else if (name.equals("30V")) {
			field = new Field30V().setDate(cf.getFechaAsCalendar());
		} else if (name.equals("30X")) {
			field = new Field30X().setDate(cf.getFechaAsCalendar());
		} else if (name.equals("32A")) {
			field = new Field32A().setAmount(cf.getValDecimal()).setCurrency(contents).setDate(cf.getFechaAsCalendar());
		} else if (name.equals("32B")) {
			field = new Field32B().setAmount(cf.getValDecimal()).setCurrency(contents);
		} else if (name.equals("32F")) {
			field = new Field32F().setUnit(codeset).setAmount(cf.getValDecimal());
		} else if (name.equals("33B")) {
			field = new Field33B().setAmount(cf.getValDecimal()).setCurrency(contents);
			// field = new Field33B(contents);
		} else if (name.equals("34E")) {
			field = new Field34E().setAmount(cf.getValDecimal()).setCurrency(contents);
			// field = new Field34E(contents);
		} else if (name.equals("35B")) {
			if (contentsBlank)
				return null;
			field = new Field35B().setIdentificationOfSecurity(qualifier).setISIN(contents).setDescription(cf.getDescripcion());
		} else if (name.equals("36")) {
			field = new Field36().setRate(cf.getValDecimal());
		} else if (name.equals("36B")) {
			field = new Field36B().setQualifier(qualifier).setQuantityTypeCode(codeset).setQuantity(cf.getValDecimal());
		} else if (name.equals("37G")) {
			if (contentsBlank)
				return null;
			field = new Field37G(contents);
		} else if (name.equals("50A")) {
			CampoForm cfOut = f50A(contents).apply(swfMencampos).get();
			field = (Field) cfOut.getValorObj();
		} else if (name.equals("50F")) {
			field = new Field50F(contents);
		} else if (name.equals("52A")) {
			if (contentsBlank)
				return null;
			field = new Field52A(contents);
		} else if (name.equals("53B")) {
			if (contentsBlank)
				return null;
			field = new Field53B(contents);
		} else if (name.equals("56A")) {
			field = new Field56A();
		} else if (name.equals("56D")) {
			field = new Field56D();
		} else if (name.equals("57A")) {
			field = new Field57A();
		} else if (name.equals("57D")) {
			field = new Field57D();
		} else if (name.equals("58A")) {
			field = new Field58A();
		} else if (name.equals("58D")) {
			field = new Field58D();
		} else if (name.equals("71A")) {
			field = new Field71A().setCode(codeset);
		} else if (name.equals("72")) {
			field = new Field72(contents);
		} else if (name.equals("79")) {
			field = new Field79();
		} else if (name.equals("82A")) {
			field = new Field82A();
		} else if (name.equals("87A")) {
			field = new Field87A();
		} else if (name.equals("88A")) {
			field = new Field88A();
		} else if (name.equals("90A")) {
			field = new Field90A();
		} else if (name.equals("94A")) {
			field = new Field94A();
		} else if (name.equals("95P")) {
			field = new Field95P();
		} else if (name.equals("95R")) {
			field = new Field95R();
		} else if (name.equals("97A")) {
			field = new Field97A();
		} else if (name.equals("98A")) {
			field = new Field98A();
		}

		return field;
	}

	public static Map<String, Object> mapFuncs() {
		Map<String, Object> vars = new HashMap<String, Object>();
		try {
			vars.put("fEmpty", FieldsCommandMx.class.getMethod("empty"));
			vars.put("fVlrCF", FieldsCommandMx.class.getMethod("vlrCF", CampoForm.class));
			vars.put("fMsgId", FieldsCommandMx.class.getMethod("msgId", Date.class, Integer.class, String.class));
			vars.put("fVlr", FieldsCommandMx.class.getMethod("fValTxt", String.class));
			vars.put("fIban", FieldsCommandMx.class.getMethod("iban", String.class));
			vars.put("fAba", FieldsCommandMx.class.getMethod("aba", String.class));
			vars.put("fAmtCurr", FieldsCommandMx.class.getMethod("amtCurr", String.class, BigDecimal.class));

//			vars.put("f20", FieldsCommand.class.getMethod("f20", String.class, Integer.class, Date.class));
			vars.put("f21", FieldsCommand.class.getMethod("f21", String.class));
			vars.put("f23B", FieldsCommand.class.getMethod("f23B", String.class));
			vars.put("f25", FieldsCommand.class.getMethod("f25", String.class));
			vars.put("f32A", FieldsCommand.class.getMethod("f32A", CampoForm.class));
			vars.put("f33B", FieldsCommand.class.getMethod("f33B", String.class, BigDecimal.class));
			vars.put("f50A", FieldsCommand.class.getMethod("f50A", String.class));
			vars.put("f50F", FieldsCommand.class.getMethod("f50F", String.class, String.class, String.class, String.class, String.class));
			vars.put("f50K", FieldsCommand.class.getMethod("f50K", Instruccion.class, String.class, String.class));
			vars.put("f50K", FieldsCommand.class.getMethod("f50K", String.class, String.class, String.class));
			vars.put("f52A", FieldsCommand.class.getMethod("f52A", String.class, String.class));
			vars.put("f52D", FieldsCommand.class.getMethod("f52D", String.class));
			vars.put("f53A", FieldsCommand.class.getMethod("f53A", String.class, String.class));
			vars.put("f53B", FieldsCommand.class.getMethod("f53B", String.class, String.class));
			vars.put("f53D", FieldsCommand.class.getMethod("f53D", String.class));
			vars.put("f54A", FieldsCommand.class.getMethod("f54A", String.class, String.class));
			vars.put("f54B", FieldsCommand.class.getMethod("f54B", String.class, String.class));
			vars.put("f54D", FieldsCommand.class.getMethod("f54D", String.class));
			vars.put("f56A", FieldsCommand.class.getMethod("f56A", String.class, String.class));
			vars.put("f56D", FieldsCommand.class.getMethod("f56D", String.class, String.class));
			vars.put("f57A", FieldsCommand.class.getMethod("f57A", String.class, String.class));
			vars.put("f57B", FieldsCommand.class.getMethod("f57B", String.class, String.class));
			vars.put("f57D", FieldsCommand.class.getMethod("f57D", String.class, String.class, String.class));
			vars.put("f58A", FieldsCommand.class.getMethod("f58A", String.class, String.class));
			vars.put("f58D", FieldsCommand.class.getMethod("f58D", String.class, String.class));
			vars.put("f58D", FieldsCommand.class.getMethod("f58D", String.class, String.class, String.class));
			vars.put("f59", FieldsCommand.class.getMethod("f59", String.class, String.class, String.class));
			vars.put("f59A", FieldsCommand.class.getMethod("f59A", String.class, String.class));
			vars.put("f59F", FieldsCommand.class.getMethod("f59F", String.class, String.class, String.class, String.class, String.class));
			vars.put("f70Ntve", FieldsCommand.class.getMethod("f70Ntve", CampoForm.class));			
			vars.put("f70", FieldsCommand.class.getMethod("f70", String.class));
			vars.put("f70CF", FieldsCommand.class.getMethod("f70CF", CampoForm.class));
			vars.put("f71A", FieldsCommand.class.getMethod("f71A", String.class));
			vars.put("f71F", FieldsCommand.class.getMethod("f71F", String.class, BigDecimal.class));
			vars.put("f72", FieldsCommand.class.getMethod("f72", String.class));
			vars.put("f72CF", FieldsCommand.class.getMethod("f72CF", CampoForm.class));
			vars.put("f72Ntve", FieldsCommand.class.getMethod("f72Ntve", CampoForm.class));
			vars.put("fGen",
					FieldsCommand.class.getMethod("fGen", SwfMencampos.class, String.class, String.class, String.class, String.class, Function.class));

		} catch (Exception e) {
			log.error("error al registrar metodos " + e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return vars;
	}
	
/***************************************************************************/	
	public static void initializeMapFunc(Instruccion instruccion, Function<SwfMencampos, List<CampoForm>> evalMenCampos) {
		mapSequenceFunc.put("16R", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15A", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15B", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15C", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15D", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15E", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15F", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15G", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15H", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15I", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15J", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15K", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15L", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15M", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15N", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
		mapSequenceFunc.put("15O", create16R(TemplateGenFSwf.evalAndFindVarForMenCampo(instruccion, evalMenCampos)));
	}

	
}
