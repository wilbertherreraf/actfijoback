
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para MessageFields.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="MessageFields"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="NoOriginal"/&gt;
 *     &lt;enumeration value="MinimumInfo"/&gt;
 *     &lt;enumeration value="HeaderOnly"/&gt;
 *     &lt;enumeration value="HeaderAndBody"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "MessageFields")
@XmlEnum
public enum MessageFields {

    @XmlEnumValue("NoOriginal")
    NO_ORIGINAL("NoOriginal"),
    @XmlEnumValue("MinimumInfo")
    MINIMUM_INFO("MinimumInfo"),
    @XmlEnumValue("HeaderOnly")
    HEADER_ONLY("HeaderOnly"),
    @XmlEnumValue("HeaderAndBody")
    HEADER_AND_BODY("HeaderAndBody");
    private final String value;

    MessageFields(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MessageFields fromValue(String v) {
        for (MessageFields c: MessageFields.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
