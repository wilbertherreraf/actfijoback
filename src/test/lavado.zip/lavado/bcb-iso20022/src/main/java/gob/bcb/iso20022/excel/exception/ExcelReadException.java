package gob.bcb.iso20022.excel.exception;

public class ExcelReadException extends RuntimeException{
    public ExcelReadException() {
        super();
    }

    public ExcelReadException(String message) {
        super(message);
    }
}
