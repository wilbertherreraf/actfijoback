package gob.bcb.iso20022.rules;

public class SamAction<I, O> extends AbstractAction<I, O> {

	private final ExecutableAction<I, O> action;

	public SamAction(String name, ExecutableAction<I, O> action) {
		super(name);
		this.action = action;
	}


	@Override
	protected O initializeOutputResult(CompiledRule rule, I input) {
		return null;
	}
}
