package gob.bcb.iso20022.excel.core;

import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;

import gob.bcb.iso20022.excel.component.ExcelProperty;
import gob.bcb.iso20022.excel.core.listener.ReadListener;
import gob.bcb.iso20022.excel.enums.FileTypeEnum;


public abstract class AbstractReader<T> extends ExcelProperty {
    ReadListener<T> readListener;
    Class type;

    public AbstractReader(String path, Class type, String sheetName) {
        this.path = path;
        this.sheetName = sheetName;
        this.type = type;
    }
    public AbstractReader(InputStream inputStream, Class type, String sheetName) {
    	this.inputStream = inputStream; 
        this.sheetName = sheetName;
        this.type = type;
    }
    public void read(ReadListener<T> readListener) {
        initListener(readListener);
        //String suffix = FileUtils.suffix(path);
        boolean isCsv = (fileTypeEnum != null && fileTypeEnum == FileTypeEnum.CSV) || !StringUtils.isBlank(path) && path.toLowerCase().endsWith(FileTypeEnum.CSV.getFileType());
        
        if (isCsv) {
            doCsvRead();
        } else {
            doExcelRead();
        }
    }

    abstract protected void doExcelRead();

    abstract protected void doCsvRead();


    private void initListener(ReadListener<T> readListener) {
        this.readListener = readListener;
    }

}
