
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para MessageNature.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="MessageNature"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Financial"/&gt;
 *     &lt;enumeration value="Text"/&gt;
 *     &lt;enumeration value="Network"/&gt;
 *     &lt;enumeration value="Security"/&gt;
 *     &lt;enumeration value="Service"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "MessageNature")
@XmlEnum
public enum MessageNature {

    @XmlEnumValue("Financial")
    FINANCIAL("Financial"),
    @XmlEnumValue("Text")
    TEXT("Text"),
    @XmlEnumValue("Network")
    NETWORK("Network"),
    @XmlEnumValue("Security")
    SECURITY("Security"),
    @XmlEnumValue("Service")
    SERVICE("Service");
    private final String value;

    MessageNature(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MessageNature fromValue(String v) {
        for (MessageNature c: MessageNature.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
