package gob.bcb.iso20022.swift;

public enum FileFormat {
	MT,
	XLS,
	CSV,
	MX
	
	
}
