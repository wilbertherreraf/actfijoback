package gob.bcb.iso20022.excel.utils;

import org.apache.poi.ss.usermodel.Workbook;

import java.io.IOException;

public class ExcelUtils {

    /**
     * @param workbook
     */
    public static void closeWorkbook(Workbook workbook) {
        try {
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
