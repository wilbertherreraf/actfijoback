package gob.bcb.iso20022.utils;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang3.StringUtils;
// import org.reflections.Reflections;
// import org.reflections.scanners.SubTypesScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import com.prowidesoftware.swift.model.AbstractMessage;
import com.prowidesoftware.swift.model.AbstractSwiftMessage;
import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.MxSwiftMessage;
import com.prowidesoftware.swift.model.mt.AbstractMT;
import com.prowidesoftware.swift.model.mx.AbstractMX;

import gob.bcb.iso20022.commons.Constants;
import gob.bcb.iso20022.swift.FileFormat;

public class ParserSwiftMessage {
	public static String[] splitSwift(String str) {
		ArrayList<Object> splitLista = new ArrayList<>();
		if (StringUtils.isBlank(str)) {
			throw new RuntimeException("Error al dividir lote de mensajes swift Parametro nulo");
		}

		str = str.concat("{1:}");
		str = str.replace("\r\n", "#|");

		String strIni = "\\{1:";
		String strFin = "\\{1:";

		Pattern pattern = Pattern.compile("" + strIni + "(.*?)(?=" + strFin + ")");
		Matcher matcher = pattern.matcher(str);

		while (matcher.find()) {
			String swiftPlano = matcher.group();
			swiftPlano = swiftPlano.replace("#|", "\r\n");
			splitLista.add(swiftPlano);
		}

		String[] res = new String[splitLista.size()];
		return splitLista.toArray(res);
	}

	public static boolean isFormatSwift(String plano) {
		if (StringUtils.isBlank(plano)) {
			return false;
		}
		String strIni = "\\{1:";
		String strFin = "\\}";
		Pattern pattern = Pattern.compile("" + strIni + "(.*?)(?=" + strFin + ")");
		Matcher matcher = pattern.matcher(plano);
		return matcher.find();
	}

	public static AbstractSwiftMessage swiftMsgBase(FileFormat standard, String swiftPlano) {
		AbstractSwiftMessage msg = null;
		if (FileFormat.MT == standard) {
			msg = MtSwiftMessage.parse(swiftPlano);
		} else if (FileFormat.MX == standard) {
			msg = MxSwiftMessage.parse(swiftPlano);
		}
		return msg;
	}

	public static AbstractSwiftMessage swiftMsgBase(String swiftPlano) {
		if (isFormatSwift(swiftPlano)) {
			return swiftMsgBase(FileFormat.MT, swiftPlano);
		} else {
			return swiftMsgBase(FileFormat.MX, swiftPlano);
		}
	}

	public static AbstractMessage swiftMessageBase(String menPlano) {
		if (org.apache.commons.lang3.StringUtils.isBlank(menPlano)) {
			throw new RuntimeException("Error al crear base swift, parametro mensaje nulo");			
		}
		
		if (isFormatSwift(menPlano)) {
			return AbstractMX.parse(menPlano);
		} else {
			try {
				return AbstractMT.parse(menPlano);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	 public static boolean isFormatSwiftMx(String cadena) {
        if (cadena == null || cadena.trim().isEmpty()) {
            return false;
        }
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            DocumentBuilder builder = factory.newDocumentBuilder();

            Document doc = builder.parse(new InputSource(new StringReader(cadena)));
            Element raiz = doc.getDocumentElement();

            String namespace = raiz.getNamespaceURI();

            return namespace != null && namespace.startsWith("urn:iso:std:iso:20022");
        } catch (Exception e) {
            return false;
        }
    }	
	
	public static void readtypemsg(String msgStr) {
		String messageType = msgStr.replaceAll("(?s).*<Document.*(" + Constants.ISO20022_REGEX + ")\".*>.*</Document>.*", "$1");
	}

	// public static Set<Class> findAllClassesForPkg(String packageName) {
	// 	Reflections reflections = new Reflections(packageName, new SubTypesScanner(false));
	// 	return reflections.getSubTypesOf(Object.class).stream().collect(Collectors.toSet());
	// }
}
