package gob.bcb.iso20022.pojo;

public class Mkt extends Role {
	private Integer codregla = 0;
	private String nrosec = "";
	private String codctaper = "";
	private String modeltype = "";
	private String codctapers = "";
	private String accesscode = "";
	private String modelowner = "";
	private String modelname = "";
	private String agencycode = "";
	private String currency = "";
	private String country = "";
	private String security = "";
	private String methodtype = "";

	public Mkt() {
	}

	public Integer getCodregla() {
		return codregla;
	}

	public void setCodregla(Integer codregla) {
		this.codregla = codregla;
	}

	public String getNrosec() {
		return nrosec;
	}

	public void setNrosec(String nrosec) {
		this.nrosec = nrosec;
	}

	public String getCodctaper() {
		return codctaper;
	}

	public void setCodctaper(String codctaper) {
		this.codctaper = codctaper;
	}

	public String getModeltype() {
		return modeltype;
	}

	public void setModeltype(String modeltype) {
		this.modeltype = modeltype;
	}

	public String getCodctapers() {
		return codctapers;
	}

	public void setCodctapers(String codctapers) {
		this.codctapers = codctapers;
	}

	public String getAccesscode() {
		return accesscode;
	}

	public void setAccesscode(String accesscode) {
		this.accesscode = accesscode;
	}

	public String getModelowner() {
		return modelowner;
	}

	public void setModelowner(String modelowner) {
		this.modelowner = modelowner;
	}

	public String getModelname() {
		return modelname;
	}

	public void setModelname(String modelname) {
		this.modelname = modelname;
	}

	public String getAgencycode() {
		return agencycode;
	}

	public void setAgencycode(String agencycode) {
		this.agencycode = agencycode;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getSecurity() {
		return security;
	}

	public void setSecurity(String security) {
		this.security = security;
	}

	public String getMethodtype() {
		return methodtype;
	}

	public void setMethodtype(String methodtype) {
		this.methodtype = methodtype;
	}

}
