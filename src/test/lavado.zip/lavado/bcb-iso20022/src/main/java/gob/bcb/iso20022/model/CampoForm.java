package gob.bcb.iso20022.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

public class CampoForm {
	private Integer idDetallePlantilla;
	private Integer idcmp;
	private String descripcion;
	private Integer tipoCampo;
	private String tabla;
	private String column;
	private String valor;
	private String tablaRel;
	private String action;
	private String catalogo;
	private String campoKey;
	private String campoValue;
	private String valorAdic;
	private Date fecha;
	private BigDecimal valDecimal;
	private Boolean valBool;
	private Integer valEntero;
	private String tipoValor;
	private Object valorObj;
	private Map objectKeyMaptributes;
	private Map<String, String> mapAtr = new HashMap<>();
	public CampoForm() {
	}

	public CampoForm(String valor, Integer tipoCampo, String tablaa, String columna) {
		this.setValor(valor);
		this.setTipoCampo(tipoCampo);
		this.setColumn(columna);
		this.setTabla(tablaa);
	}
	
	public CampoForm(String tabla, String column, String valor) {
		this.setValor(valor);
		this.setColumn(column);
		this.setTabla(tabla);
		// return this;
	}

	
	public Integer getIdDetallePlantilla() {
		return idDetallePlantilla;
	}

	public void setIdDetallePlantilla(Integer idDetallePlantilla) {
		this.idDetallePlantilla = idDetallePlantilla;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Integer getTipoCampo() {
		return tipoCampo;
	}

	public void setTipoCampo(Integer tipoCampo) {
		this.tipoCampo = tipoCampo;
	}

	public String getTabla() {
		return tabla;
	}

	public void setTabla(String tabla) {
		this.tabla = tabla;
	}

	public String getColumn() {
		return column;
	}

	public void setColumn(String column) {
		this.column = column;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getTablaRel() {
		return tablaRel;
	}

	public void setTablaRel(String tablaRel) {
		this.tablaRel = tablaRel;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getCampoKey() {
		return campoKey;
	}

	public void setCampoKey(String campoKey) {
		this.campoKey = campoKey;
	}

	public String getCampoValue() {
		return campoValue;
	}

	public void setCampoValue(String campoValue) {
		this.campoValue = campoValue;
	}

	public Date getFecha() {
		return fecha;
	}

	public Calendar getFechaAsCalendar() {
		Calendar c = GregorianCalendar.getInstance();
		c.setTime(fecha);
		return c;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public BigDecimal getValDecimal() {
		return valDecimal;
	}

	public void setValDecimal(BigDecimal valDecimal) {
		this.valDecimal = valDecimal;
	}

	public Boolean getValBool() {
		return valBool;
	}

	public void setValBool(Boolean valBool) {
		this.valBool = valBool;
	}

	public Integer getValEntero() {
		return valEntero;
	}

	public void setValEntero(Integer valEntero) {
		this.valEntero = valEntero;
	}

	public String getTipoValor() {
		return tipoValor;
	}

	public void setTipoValor(String tipoValor) {
		this.tipoValor = tipoValor;
	}

	public String getCatalogo() {
		return catalogo;
	}

	public void setCatalogo(String catalogo) {
		this.catalogo = catalogo;
	}
	
	public Object getValorObj() {
		return valorObj;
	}

	public void setValorObj(Object valorObj) {
		this.valorObj = valorObj;
	}

	public Map getObjectKeyMaptributes() {
		return objectKeyMaptributes;
	}

	public void setObjectKeyMaptributes(Map objectKeyMaptributes) {
		this.objectKeyMaptributes = objectKeyMaptributes;
	}

	public void putAtrib(String key, String value) {
		mapAtr.putIfAbsent(key, value);
	}
	
	public Map<String, String> getMapAtr() {
		return mapAtr; 
	}
	
	public Integer getIdcmp() {
		return idcmp;
	}

	public void setIdcmp(Integer idcmp) {
		this.idcmp = idcmp;
	}

	public String toStringCF() {
		return "[" + tabla + "_" + column + "] " + valor + ", Decimal=" + valDecimal + ", Fecha=" + fecha + "[" + valEntero + "]";
	}

	public String getValorAdic() {
		return valorAdic;
	}

	public void setValorAdic(String valorAdic) {
		this.valorAdic = valorAdic;
	}
	
	public String getNameCF() {
		String name = StringUtils.trimToEmpty(tabla).toLowerCase() + StringUtils.capitalize(StringUtils.trimToEmpty(column).toLowerCase());		
		name = StringUtils.trimToEmpty(tabla) + (StringUtils.isAllBlank(tabla) ? "" : ".") + (StringUtils.trimToEmpty(column));
		name = Arrays.asList(tabla, column).stream().filter(cad -> !StringUtils.isAllBlank(cad))
		.collect(Collectors.joining("."));
		return name;
	}
}
