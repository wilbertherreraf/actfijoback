package gob.bcb.iso20022.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.MxId;
import com.prowidesoftware.swift.model.field.SwiftParseUtils;

public class MxDataTypesConversor {
	private static final Logger log = LoggerFactory.getLogger(MxDataTypesConversor.class);
	private static final Pattern PATTERN_TYPEMSG = Pattern.compile(".*([a-zA-Z]{4}).(\\d{3}).(\\d{3}).(\\d{2}).*");
	public static final String ISOTIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String ISODATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_FORMAT_BO = "dd-MM-yyyy";
	public static final String ISOAMT_FORMAT = "#####0.00";

	/*
	 * Max35Text ISODateTime Max15NumericText ActiveCurrencyAndAmount ISODate
	 * Max34Text BICFIIdentifier Max140Text Max70Text ExternalServiceLevel1Code
	 * ActiveOrHistoricCurrencyAndAmount BaseOneRate ChargeBearerType1Code
	 * AnyBICIdentifier AccountIdentification4Choice
	 */
	public static String isoDate(Calendar value) {
		return ValidatorCodes.dateToString(value, ISODATE_FORMAT);
	}

	public static String isoDate(Date value) {
		return ValidatorCodes.dateToString(value, ISODATE_FORMAT);
	}

	public static String dateBO(Date value) {
		return ValidatorCodes.dateToString(value, DATE_FORMAT_BO);
	}

	public static String isoDTime(Calendar value) {
		return ValidatorCodes.dateToString(value, ISOTIME_FORMAT);
	}

	public static String isoDate() {
		return ValidatorCodes.dateToString(new Date(), ISODATE_FORMAT);
	}

	public static String isoDTime() {
		return ValidatorCodes.dateToString(new Date(), ISOTIME_FORMAT);
	}

	public static String isoAmt(BigDecimal amount) {
		return ValidatorCodes.bigDecimalToString(amount, ISOAMT_FORMAT);
	}

	public static String amtFmt(final BigDecimal bigDecimal) {
		if (bigDecimal != null) {
			final DecimalFormatSymbols symbols = new DecimalFormatSymbols();
			symbols.setDecimalSeparator(',');
			final DecimalFormat df = new DecimalFormat("0.##########", symbols);
			df.setParseBigDecimal(true);
			df.setDecimalSeparatorAlwaysShown(true);
			final String formatted = df.format(bigDecimal);
			return StringUtils.replaceChars(formatted, '.', ',');
		}
		return "";
	}

	public static String genUIID() {
		UUID uuid = UUID.randomUUID();
		String uuid36 = uuid.toString();
		return uuid36.toString();
	}

	public static String bic8(String bicStr, Boolean validate) {
		validate = validate == null ? false : validate;
		BIC bic = new BIC(bicStr);
		if (validate && !bic.isValid()) {
			return "";
		}
		return bic.getBic8();
	}

	public static String bic11(String bicStr) {
		boolean validate = false; // validate == null ? false : validate;
		BIC bic = new BIC(bicStr);
		if (validate && !bic.isValid()) {
			return "";
		}
		return bic.getBic11();
	}

	public static String abaCd(String valor, Boolean retNumber) {
		return retNumber ? ValidatorCodes.extractAba(valor) : (isAba(valor) ? valor : "");
	}

	public static boolean notBlk(Object o) {
		if (o == null) {
			return false;
		}
		if (o instanceof String) {
			String s = o.toString();
			return !StringUtils.isBlank(s);
		} else if (o instanceof BigDecimal) {
			BigDecimal d = (BigDecimal) o;
			return true;
		}
		return true;
	}

	public static Object eNvl(Object o, Object alter) {
		if (notBlk(o)) {
			return o;
		}
		return alter;
	}

	public static boolean vTrue() {
		return true;
	}

	public static boolean isAba(String valor) {
		return ValidatorCodes.isAba(valor);
	}

	public static boolean isIban(String valor) {
		return ValidatorCodes.isIban(valor);
	}

	public static void existsCad(String cad) {
		final List<String> lines = SwiftParseUtils.getLines(cad).stream().filter(StringUtils::isNotEmpty)
				// .filter(l -> !onlySlashes(l))
				.collect(Collectors.toList());

	}

	public static String genUUMID(String io, String bic, String version, String reference, String id) {
		Calendar created = Calendar.getInstance();
		StringBuilder suffix = new StringBuilder();
		if (created != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
			suffix.append(sdf.format(created.getTime()));
		}
		if (!StringUtils.isBlank(id)) {
			suffix.append(StringUtils.leftPad(id, 10, "0"));
		}
		if (suffix.length() == 0) {
			log.warn("The computed suffix for message UID is blank, provide either the creation date or the numeric identifier as parameters for getUID");
		}
		return genUUID(io, bic, version, reference) + suffix;
	}

	public static String genUUID(String io, String bic, String version, String reference) {
		StringBuilder uuid = new StringBuilder();
		uuid.append(io);
		BIC corresp = new BIC(bic);
		if (corresp != null) {
			uuid.append(corresp.getBic11());
		}
		final Matcher matcher = PATTERN_TYPEMSG.matcher(version);
        if (matcher.matches()) {
    		MxId id = new MxId(version);
    		uuid.append(id.getFunctionality());
    		// uuid.append(StringUtils.trimToEmpty(SwiftMessageUtils.reference(null)));
        } else {
        	uuid.append(version);
        }
        
		uuid.append(reference);
		// log.info("v: " + mxSwftMsg.getVersion() + " r " +
		// mxSwftMsg.getAppHdr().reference());
		return uuid.toString();
	}
}
