package gob.bcb.iso20022.excel.constant;

public class ExcelConstant {
    public static final String DEFAULT_SHEET_NAME = "Sheet1";
}
