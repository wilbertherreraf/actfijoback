package gob.bcb.iso20022.excel.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.BigDecimalValidator;
import org.apache.commons.validator.routines.DoubleValidator;
import org.apache.commons.validator.routines.FloatValidator;
import org.apache.commons.validator.routines.IntegerValidator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import gob.bcb.iso20022.excel.constant.ExcelConstant;
import gob.bcb.iso20022.excel.core.data.HeaderData;
import gob.bcb.iso20022.excel.core.factory.CsvFactory;
import gob.bcb.iso20022.excel.core.factory.ExcelFactory;
import gob.bcb.iso20022.excel.enums.FieldTypeEnum;
import gob.bcb.iso20022.excel.exception.ExcelManipulationException;
import gob.bcb.iso20022.excel.exception.ExcelReadException;
import gob.bcb.iso20022.excel.utils.ClassUtils;
import gob.bcb.iso20022.excel.utils.CommonFileUtils;
import gob.bcb.iso20022.excel.utils.CsvUtils;
import gob.bcb.iso20022.excel.utils.ExcelUtils;
import gob.bcb.iso20022.utils.ValidatorCodes;

/**
 * clase base de lectura de archivos excel, modificado de
 * https://github.com/Joebig7/mamba-excel.git (autor JoeBig7) se modifica por
 * las dependencias innecesarias en la fuente origen la clase se adapta al
 * proyecto
 * 
 * @author WHerrera
 *
 * @param <T>
 */
public class GenericReader<T> extends AbstractReader<T> {
	public static final Locale LOCALE_EN_US = new Locale("en", "US");

	public GenericReader(String path, Class type) {
		this(path, type, ExcelConstant.DEFAULT_SHEET_NAME);
	}

	public GenericReader(String path, Class type, String sheetName) {
		super(path, type, sheetName);
	}

	public GenericReader(InputStream is, Class type, String sheetName) {
		super(is, type, sheetName);
	}

	@Override
	protected void doExcelRead() {
		if (headerDataList == null || headerDataList.size() == 0) {
			throw new ExcelReadException("excel header can not be null");
		}
		Workbook workbook = null;
		if (inputStream == null && !StringUtils.isBlank(path))
			inputStream = CommonFileUtils.getFileInputStream(path);

		workbook = ExcelFactory.readInstance(inputStream, fileTypeEnum, path);

		if (Objects.isNull(workbook)) {
			throw new ExcelReadException(String.format("excel workbook %s is not found", sheetName));
		}

		Sheet sheet = workbook.getSheet(sheetName);
		if (Objects.isNull(sheet)) {
			sheet = workbook.getSheetAt(0);
		}
		if (Objects.isNull(sheet)) {
			throw new ExcelReadException(String.format("excel sheetName %s is not found", sheetName));
		}
		try {
			doSpecificExcelRead(sheet);
			readListener.doAfterRead();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			ExcelUtils.closeWorkbook(workbook);
			CommonFileUtils.closeInputStream(inputStream);
		}
	}

	@Override
	protected void doCsvRead() {
		CSVParser parser = null;
		Reader reader = null;

		if (inputStream != null)
			reader = CommonFileUtils.getFileReader(inputStream);
		else
			reader = CommonFileUtils.getFileReader(path);
		try {
			String[] headers = headerDataList.stream().map(HeaderData::getFieldName).collect(Collectors.toList()).toArray(new String[0]);
			//getcSVFormat().builder().setHeader(headers);
			//CSVFormat cSVFormat = CSVFormat.Builder.create().setHeader(headers).build();
			CSVFormat cSVFormat =  getcSVFormat().builder().setHeader(headers).build();
			parser = CsvFactory.readInstance(reader, cSVFormat);
			doSpecificCsvRead(parser.getRecords());
			readListener.doAfterRead();
		} catch (NoSuchFieldException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			CsvUtils.close(parser);
			CommonFileUtils.closeReader(reader);
		}
	}

	private void doSpecificExcelRead(Sheet sheet) {
		if (headerDataList.size() == 0) {
			return;
		}

		int rowNum = sheet.getPhysicalNumberOfRows();

		Map<Integer, HeaderData> mapCols = new LinkedHashMap<>();
		for (HeaderData headerData : headerDataList) {
			mapCols.put(headerData.getColPosition(), headerData);
		}

		Comparator<HeaderData> comparator = (x, y) -> x.getColPosition() - y.getColPosition();
		Optional<HeaderData> hdrMax = headerDataList.stream().max(comparator);
		int ncols = headerDataList.size();
		int firstRowData = headerDataList.get(0).getFirstRowData();

		boolean isMap = Map.class.isAssignableFrom(type);
		boolean isClassAsig = !isMap && obtainTargetObj() != null;

		if (hdrMax.isPresent())
			ncols = hdrMax.get().getColPosition();
		// rowNum = 25;
		int inserts = 0;
		for (int i = firstRowData; i < rowNum; i++) {
			Row row = sheet.getRow(i);
			if (Objects.isNull(row)) {
				continue;
			}
			Map<String, Object> fila = new LinkedHashMap<String, Object>();
			Object cellObj = null;
			if (isClassAsig)
				cellObj = obtainTargetObj();
			else
				cellObj = fila;
			// int j = 0;
			for (int j = 0; j <= ncols; j++) {
				Cell cell = row.getCell(j, MissingCellPolicy.CREATE_NULL_AS_BLANK);

				HeaderData headerData = mapCols.get(j);
				if (headerData == null) {
					continue;
				}
				String fieldName = headerData.getFieldName();
				Object cellValue = getCellValue(cell, headerData.getFieldTypeEnum());
				if (isClassAsig)
					ClassUtils.setField(cellObj, type, fieldName, cellValue);
				else
					fila.put(fieldName, cellValue);
			}
			// resultado.add(fila);

			readListener.invoke((T) cellObj);
			inserts++;
		}
		System.out.println("rows " + rowNum + " firstRowData:" + firstRowData + " inserts " + inserts);
	}

	private void doSpecificCsvRead(List<CSVRecord> recordList) throws NoSuchFieldException {
		boolean isMap = Map.class.isAssignableFrom(type);
		boolean isClassAsig = !isMap && obtainTargetObj() != null;
		int firstRowData = headerDataList.get(0).getFirstRowData();
		System.out.println("recordList.size " + recordList.size() + " firstRowData " + firstRowData);
		for (int i = firstRowData; i < recordList.size(); i++) {
			CSVRecord record = recordList.get(i);
			
			Object csvObj = obtainTargetObj();
			if (csvObj == null)
				return;
			
			for (int j = 0; j < headerDataList.size(); j++) {
				HeaderData headerData = headerDataList.get(j);
				String value = record.get(headerData.getFieldName());
				String fieldName = headerData.getFieldName();
				//System.out.println("[" + i + "-" + j + "] :=> " + headerData.getFieldTypeEnum() + " ::" + fieldName + " " + value);
				Object objVal = getCsvValue(value, headerData.getFieldTypeEnum());
				System.out.println("[" + i + "-" + j + "] => " + headerData.getFieldTypeEnum() + " ::" + fieldName + " objVal: " + objVal + " value:" + value);
				if (isClassAsig)
					ClassUtils.setField(csvObj, type, fieldName, objVal);
			}
			readListener.invoke((T) csvObj);
		}
	}

	private Object obtainTargetObj() {
		Object obj = null;
		try {
			obj = type.newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return obj;
	}

	private Object getCellValue(Cell cell, FieldTypeEnum fieldTypeEnum) {
		if (cell == null)
			return null;

		Object ocell = readCellValue(cell, cell.getCellType(), fieldTypeEnum, TolerantLevel.TOLERANT);

		if (ocell == null)
			return null;

		Class clazz = ocell.getClass();
		if (clazz == null)
			return null;

		switch (fieldTypeEnum) {
		case BIG_DECIMAL:
			if (BigDecimal.class.isAssignableFrom(clazz) //
					|| clazz.isPrimitive() || Number.class.isAssignableFrom(clazz)) {
				Double d = (Double) ocell;
				return new BigDecimal(d);
			} else {
				return stringToBigDecimal(ocell.toString());
			}
		case INTEGER:
			if (BigInteger.class.isAssignableFrom(clazz) //
					|| Integer.class.isAssignableFrom(clazz) || Long.class.isAssignableFrom(clazz)) {

				return Integer.parseInt(ocell.toString());
			} else {
				return stringToInteger(ocell.toString());
			}
		case LONG:
			if (BigInteger.class.isAssignableFrom(clazz) //
					|| Integer.class.isAssignableFrom(clazz) || Long.class.isAssignableFrom(clazz)) {

				return Long.parseLong(ocell.toString());
			} else {
				return stringToInteger(ocell.toString());
			}
		case DOUBLE:
			if (Double.class.isAssignableFrom(clazz)) {
				return (double) cell.getNumericCellValue();
			} else {
				return DoubleValidator.getInstance().validate(ocell.toString());
			}
		case FLOAT:
			if (Float.class.isAssignableFrom(clazz)) {
				return (float) cell.getNumericCellValue();
			} else {
				return FloatValidator.getInstance().validate(ocell.toString());
			}
		case BOOLEAN:
			if (Boolean.class.isAssignableFrom(clazz)) {
				return ocell;
			} else {
				return stringToBoolean(ocell.toString());
			}
		case DATE:
			if (Date.class.isAssignableFrom(clazz)) {
				return ocell;
			} else {
				String[] DATE_PATTERNS_BO = { "dd/MM/yyyy", "dd/MM/yy", "dd-MM-yyyy", "dd-MM-yy" };
				Date db = ValidatorCodes.stringWithPatternsToDate.apply(ocell.toString(), DATE_PATTERNS_BO).orElse(null);
				return db;
			}
		case STRING:
			return ocell.toString();
		case FORMULA:
			// return cell.getStringCellValue();
			return null;
		case BLANK:
			return null;
		default:
			throw new ExcelManipulationException("no suitable type for cell value");
		}
	}

	private static Object readCellValue(Cell cell, CellType type, FieldTypeEnum fieldTypeEnum, TolerantLevel tolerantLevel) {
		if (cell == null)
			return null;

//		CellType type = cell.getCellType();
		switch (type) {
		case NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {
				return (Date) cell.getDateCellValue();
			}
			double n = cell.getNumericCellValue();
			return n;
		case FORMULA:
			return readCellValue(cell, cell.getCachedFormulaResultType(), fieldTypeEnum, tolerantLevel);
		case BOOLEAN:
			return cell.getBooleanCellValue();
		case ERROR:
			return tolerantLevel.readErrorCell(cell);
		case BLANK:
			return null;
		case STRING:
			return cell.getStringCellValue();
		default:
			return tolerantLevel.readUnknownCellType(cell);
		}
	}

	private Object getCsvValue(String value, FieldTypeEnum fieldTypeEnum) {
		if (value == null) {
			return "";
		}
		switch (fieldTypeEnum) {
		case INTEGER:
			return Integer.parseInt(value);
		case LONG:
			return Long.parseLong(value);
		case DOUBLE:
			return Double.parseDouble(value);
		case BIG_DECIMAL:
			return ValidatorCodes.stringToBigDecimal(value);
		case FLOAT:
			return Float.parseFloat(value);
		case BOOLEAN:
			return Boolean.parseBoolean(value);
		case STRING:
			return value.toString();
		case FORMULA:
			return value;
		case BLANK:
			return "";
		case DATE: {
			String[] DATE_PATTERNS_BO = { "dd/MM/yyyy", "dd/MM/yy", "dd-MM-yyyy", "dd-MM-yy" };
			Date db = ValidatorCodes.stringWithPatternsToDate.apply(value, DATE_PATTERNS_BO).orElse(null);
			return db;			
		}
		default:
			throw new ExcelManipulationException("no suitable type for csv value");
		}
	}

	private enum TolerantLevel {
		STRICT, TOLERANT, AGGRESSIVE_READ;

		public boolean isStrict() {
			return STRICT == this;
		}

		public boolean isTolerant() {
			return TOLERANT != this;
		}

		public boolean isAggressiveReading() {
			return AGGRESSIVE_READ == this;
		}

		public void headerRowOutOfScope(Sheet sheet) {
			String message = String.format("caption row out of scope in sheet[%s] !", sheet.getSheetName());
			if (isStrict()) {
				throw new RuntimeException(message);
			}
		}

		public void columnIndexMapNotFullyBuilt(Sheet sheet) {
			String message = String.format("column index not fully built on sheet: " + sheet.getSheetName());
			if (isStrict()) {
				throw new RuntimeException(message);
			}
		}

		public void onReadCellException(Exception e, Sheet sheet, Row row, int cellIndex) {
			String errorMessage = String.format("Error reading cell value: %s-%s@[%s]", cellIndex, row.getRowNum(), sheet.getSheetName());
			if (isStrict()) {
				throw new RuntimeException(errorMessage);
			}
		}

		public void onReadCellException(Exception e, Cell cell) {
			String errorMessage = String.format("Error reading cell value: %s@[%s]", cell.getAddress(), cell.getSheet().getSheetName());
			if (isStrict()) {
				throw new RuntimeException(errorMessage);
			}
		}

		public Object readErrorCell(Cell cell) {
			if (isStrict()) {
				throw new RuntimeException(
						String.format("Error cell value encountered: %s@[%s]", cell.getAddress(), cell.getRow().getSheet().getSheetName()));
			}
			return null;
		}

		public Object readUnknownCellType(Cell cell) {
			if (isStrict()) {
				throw new RuntimeException(
						String.format("Unknown cell type encountered: %s@[%s]", cell.getAddress(), cell.getRow().getSheet().getSheetName()));
			}
			return null;
		}

		public void errorSettingCellValueToPojo(Exception e, Cell cell, Object value, Class<?> schema) {
			String errorMessage = String.format("failed to set cell value[%s] to POJO[%s]: %s@[%s]", value, schema, cell.getAddress(),
					cell.getRow().getSheet().getSheetName());
			if (isStrict()) {
				throw new RuntimeException(errorMessage);
			}
		}
	}

	public static Integer stringToInteger(String value) {
		return !StringUtils.isBlank(value) ? IntegerValidator.getInstance().validate(value) : null;
	}

	public static BigDecimal stringToBigDecimal(String value) {
		String newValue = value != null ? value.trim().replace("%", "") : null;
		BigDecimal val = BigDecimalValidator.getInstance().validate(newValue, LOCALE_EN_US);
		return val == null ? BigDecimal.ZERO : val;
	}

	public static Boolean stringToBoolean(String value) {
		return value != null && (value.trim().equals("1") || value.trim().equalsIgnoreCase("true") || value.trim().equalsIgnoreCase("verdadero")
				|| value.trim().equalsIgnoreCase("T"));
	}

	public void mapa(Sheet sheet) {
		Map<Integer, List<Cell>> contents = new HashMap<>();
		for (Row row : sheet) {
			contents.put(row.getRowNum(), new ArrayList<>());
			for (Cell c : row) {
				contents.get(row.getRowNum()).add(c);
			}
		}
		int r = 0;

		for (Entry<Integer, List<Cell>> entry : contents.entrySet()) {
			Integer k = entry.getKey();
			List<Cell> v = entry.getValue();
			int c = 0;
			for (Cell cell : v) {
				System.out.println(r + ":" + c + "Row " + k + " ->  " + cell);
				c++;
			}

			r++;
		}
		;
	}
}
