
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para DeliveryReport complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DeliveryReport"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SenderReference" type="{urn:swift:saa:xsd:saa.2.0}SenderReference"/&gt;
 *         &lt;element name="ReceiverDeliveryStatus" type="{urn:swift:saa:xsd:saa.2.0}ReceiverDeliveryStatus"/&gt;
 *         &lt;element name="OriginalInstanceAddressee" type="{urn:swift:saa:xsd:saa.2.0}AddressFullName"/&gt;
 *         &lt;element name="ReportingApplication" type="{urn:swift:saa:xsd:saa.2.0}ReportingApplication"/&gt;
 *         &lt;element name="NetworkInfo" type="{urn:swift:saa:xsd:saa.2.0}NetworkInfo"/&gt;
 *         &lt;element name="SAAInfo" type="{urn:swift:saa:xsd:saa.2.0}SAAInfo" minOccurs="0"/&gt;
 *         &lt;element name="Interventions" type="{urn:swift:saa:xsd:saa.2.0}Interventions"/&gt;
 *         &lt;element name="IsRelatedInstanceOriginal" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="RelatedInstanceAddressee" type="{urn:swift:saa:xsd:saa.2.0}AddressFullName" minOccurs="0"/&gt;
 *         &lt;element name="MessageCreator" type="{urn:swift:saa:xsd:saa.2.0}MessageCreator"/&gt;
 *         &lt;element name="IsMessageModified" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="MessageFields" type="{urn:swift:saa:xsd:saa.2.0}MessageFields"/&gt;
 *         &lt;element name="Message" type="{urn:swift:saa:xsd:saa.2.0}Message" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeliveryReport", propOrder = {
    "senderReference",
    "receiverDeliveryStatus",
    "originalInstanceAddressee",
    "reportingApplication",
    "networkInfo",
    "saaInfo",
    "interventions",
    "isRelatedInstanceOriginal",
    "relatedInstanceAddressee",
    "messageCreator",
    "isMessageModified",
    "messageFields",
    "message"
})
public class DeliveryReport {

    @XmlElement(name = "SenderReference", required = true)
    protected String senderReference;
    @XmlElement(name = "ReceiverDeliveryStatus", required = true)
    @XmlSchemaType(name = "string")
    protected ReceiverDeliveryStatus receiverDeliveryStatus;
    @XmlElement(name = "OriginalInstanceAddressee", required = true)
    protected AddressFullName originalInstanceAddressee;
    @XmlElement(name = "ReportingApplication", required = true)
    @XmlSchemaType(name = "string")
    protected ReportingApplication reportingApplication;
    @XmlElement(name = "NetworkInfo", required = true)
    protected NetworkInfo networkInfo;
    @XmlElement(name = "SAAInfo")
    protected SAAInfo saaInfo;
    @XmlElement(name = "Interventions", required = true)
    protected Interventions interventions;
    @XmlElement(name = "IsRelatedInstanceOriginal")
    protected boolean isRelatedInstanceOriginal;
    @XmlElement(name = "RelatedInstanceAddressee")
    protected AddressFullName relatedInstanceAddressee;
    @XmlElement(name = "MessageCreator", required = true)
    @XmlSchemaType(name = "string")
    protected MessageCreator messageCreator;
    @XmlElement(name = "IsMessageModified")
    protected boolean isMessageModified;
    @XmlElement(name = "MessageFields", required = true)
    @XmlSchemaType(name = "string")
    protected MessageFields messageFields;
    @XmlElement(name = "Message")
    protected Message message;

    /**
     * Obtiene el valor de la propiedad senderReference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenderReference() {
        return senderReference;
    }

    /**
     * Define el valor de la propiedad senderReference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenderReference(String value) {
        this.senderReference = value;
    }

    /**
     * Obtiene el valor de la propiedad receiverDeliveryStatus.
     * 
     * @return
     *     possible object is
     *     {@link ReceiverDeliveryStatus }
     *     
     */
    public ReceiverDeliveryStatus getReceiverDeliveryStatus() {
        return receiverDeliveryStatus;
    }

    /**
     * Define el valor de la propiedad receiverDeliveryStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link ReceiverDeliveryStatus }
     *     
     */
    public void setReceiverDeliveryStatus(ReceiverDeliveryStatus value) {
        this.receiverDeliveryStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad originalInstanceAddressee.
     * 
     * @return
     *     possible object is
     *     {@link AddressFullName }
     *     
     */
    public AddressFullName getOriginalInstanceAddressee() {
        return originalInstanceAddressee;
    }

    /**
     * Define el valor de la propiedad originalInstanceAddressee.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressFullName }
     *     
     */
    public void setOriginalInstanceAddressee(AddressFullName value) {
        this.originalInstanceAddressee = value;
    }

    /**
     * Obtiene el valor de la propiedad reportingApplication.
     * 
     * @return
     *     possible object is
     *     {@link ReportingApplication }
     *     
     */
    public ReportingApplication getReportingApplication() {
        return reportingApplication;
    }

    /**
     * Define el valor de la propiedad reportingApplication.
     * 
     * @param value
     *     allowed object is
     *     {@link ReportingApplication }
     *     
     */
    public void setReportingApplication(ReportingApplication value) {
        this.reportingApplication = value;
    }

    /**
     * Obtiene el valor de la propiedad networkInfo.
     * 
     * @return
     *     possible object is
     *     {@link NetworkInfo }
     *     
     */
    public NetworkInfo getNetworkInfo() {
        return networkInfo;
    }

    /**
     * Define el valor de la propiedad networkInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link NetworkInfo }
     *     
     */
    public void setNetworkInfo(NetworkInfo value) {
        this.networkInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad saaInfo.
     * 
     * @return
     *     possible object is
     *     {@link SAAInfo }
     *     
     */
    public SAAInfo getSAAInfo() {
        return saaInfo;
    }

    /**
     * Define el valor de la propiedad saaInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SAAInfo }
     *     
     */
    public void setSAAInfo(SAAInfo value) {
        this.saaInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad interventions.
     * 
     * @return
     *     possible object is
     *     {@link Interventions }
     *     
     */
    public Interventions getInterventions() {
        return interventions;
    }

    /**
     * Define el valor de la propiedad interventions.
     * 
     * @param value
     *     allowed object is
     *     {@link Interventions }
     *     
     */
    public void setInterventions(Interventions value) {
        this.interventions = value;
    }

    /**
     * Obtiene el valor de la propiedad isRelatedInstanceOriginal.
     * 
     */
    public boolean isIsRelatedInstanceOriginal() {
        return isRelatedInstanceOriginal;
    }

    /**
     * Define el valor de la propiedad isRelatedInstanceOriginal.
     * 
     */
    public void setIsRelatedInstanceOriginal(boolean value) {
        this.isRelatedInstanceOriginal = value;
    }

    /**
     * Obtiene el valor de la propiedad relatedInstanceAddressee.
     * 
     * @return
     *     possible object is
     *     {@link AddressFullName }
     *     
     */
    public AddressFullName getRelatedInstanceAddressee() {
        return relatedInstanceAddressee;
    }

    /**
     * Define el valor de la propiedad relatedInstanceAddressee.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressFullName }
     *     
     */
    public void setRelatedInstanceAddressee(AddressFullName value) {
        this.relatedInstanceAddressee = value;
    }

    /**
     * Obtiene el valor de la propiedad messageCreator.
     * 
     * @return
     *     possible object is
     *     {@link MessageCreator }
     *     
     */
    public MessageCreator getMessageCreator() {
        return messageCreator;
    }

    /**
     * Define el valor de la propiedad messageCreator.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageCreator }
     *     
     */
    public void setMessageCreator(MessageCreator value) {
        this.messageCreator = value;
    }

    /**
     * Obtiene el valor de la propiedad isMessageModified.
     * 
     */
    public boolean isIsMessageModified() {
        return isMessageModified;
    }

    /**
     * Define el valor de la propiedad isMessageModified.
     * 
     */
    public void setIsMessageModified(boolean value) {
        this.isMessageModified = value;
    }

    /**
     * Obtiene el valor de la propiedad messageFields.
     * 
     * @return
     *     possible object is
     *     {@link MessageFields }
     *     
     */
    public MessageFields getMessageFields() {
        return messageFields;
    }

    /**
     * Define el valor de la propiedad messageFields.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageFields }
     *     
     */
    public void setMessageFields(MessageFields value) {
        this.messageFields = value;
    }

    /**
     * Obtiene el valor de la propiedad message.
     * 
     * @return
     *     possible object is
     *     {@link Message }
     *     
     */
    public Message getMessage() {
        return message;
    }

    /**
     * Define el valor de la propiedad message.
     * 
     * @param value
     *     allowed object is
     *     {@link Message }
     *     
     */
    public void setMessage(Message value) {
        this.message = value;
    }

}
