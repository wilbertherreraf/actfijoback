package gob.bcb.iso20022.exceptions;

public class ParseException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public ParseException(String msg) {
		super(msg);
	}

}
