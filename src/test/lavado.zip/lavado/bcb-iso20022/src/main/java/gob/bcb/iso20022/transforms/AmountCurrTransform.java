package gob.bcb.iso20022.transforms;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.rules.AbstractAction;
import gob.bcb.iso20022.rules.Action;
import gob.bcb.iso20022.rules.CompiledRule;
import gob.bcb.iso20022.swift.MappingRule;
import gob.bcb.iso20022.utils.MxDataTypesConversor;

/**
 * @author: wherrera
 * 
 */
public class AmountCurrTransform extends AbstractAction<MappingRule, CampoForm> {
	public final static String name = TransformEnum.AMTCURR.toString();

	public AmountCurrTransform() {
		super(name);
	}

	
	protected CampoForm initializeOutputResult(CompiledRule rule, MappingRule input) {
		return new CampoForm();
	}

	
	public CampoForm execute(CompiledRule rule, MappingRule input, Map<String, Object> facts) {
		input.getMapFacts().forEach((k,v) -> {
			if (!StringUtils.isBlank(k) && v != null)
				facts.putIfAbsent(k, v);
		});

		
		return null;
	}
	
	
	public void postExecuteAction(CompiledRule rule, MappingRule input, CampoForm output, Map<String, Object> facts) {
		if (output != null && output.getValorObj() != null) {
			if (output.getValorObj() instanceof CampoForm) {
				SwfMencampos swfCampo = input.getSwfCampo();
				CampoForm cfOut = (CampoForm) output.getValorObj();
				
				CampoForm cf = new CampoForm(rule.getRule().getNamespace(), rule.getRule().getName(), output.getValor());
				cf.setValor(MxDataTypesConversor.isoAmt(cfOut.getValDecimal()));
				cf.setCatalogo(swfCampo.getMtfXmltag());
				input.addCampo(cf);
				
				CampoForm cfC = new CampoForm(rule.getRule().getNamespace(), rule.getRule().getName(), output.getValor());
				cfC.setValor(cfOut.getValorAdic());
				cfC.setCatalogo(swfCampo.getMtfXmltag() + "/@Ccy");
				
				input.addCampo(cfC);
			}
		}
	}
	
	
	public void postExecuteSubAction(CompiledRule rule, Action sAction, MappingRule input, CampoForm output, Map<String, Object> facts) {
		if (output == null)
			return;
		
		output.setTabla(rule.getRule().getNamespace());
		output.setColumn(rule.getRule().getName());
//		output.setCatalogo(sAction.getAttribute());
		//output.setValor(output.getValor());
		
		CampoForm cf = new CampoForm(rule.getRule().getNamespace(), rule.getRule().getName(), output.getValor());
		cf.setCatalogo(output.getCatalogo());
		
		//input.addCampo(output);
		input.addCampo(cf);
		CampoForm cfCurr = new CampoForm(rule.getRule().getNamespace(), rule.getRule().getName(), output.getValorAdic());
		cfCurr.setCatalogo(output.getCatalogo() + "/@Ccy");
		input.addCampo(cfCurr);
	}

}
