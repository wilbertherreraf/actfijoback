package gob.bcb.iso20022.excel.utils;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;

//import org.apache.commons.csv.CSVParser;
//import org.apache.commons.csv.CSVPrinter;

import gob.bcb.iso20022.excel.core.data.HeaderData;
import gob.bcb.iso20022.excel.exception.CsvException;

public class CsvUtils {

    public static void write(CSVPrinter csvPrinter, List<HeaderData> headerDataList, List<List<Object>> contentDataList) throws IOException {
        if (Objects.isNull(csvPrinter)) {
            throw new CsvException("CSVPrinter is null");
        }

        if (Objects.nonNull(headerDataList)) {
            List<String> headerNames = headerDataList.stream().map(HeaderData::getFieldName).collect(Collectors.toList());
            csvPrinter.printRecord(headerNames);
        }

        if (Objects.nonNull(contentDataList)) {
            for (List<Object> list : contentDataList) {
                csvPrinter.printRecord(list);
            }
        }
    }

    /**
     *
     * @param csvPrinter
     */
    public static void close(CSVPrinter csvPrinter) {
        if (Objects.nonNull(csvPrinter)) {
            try {
                csvPrinter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     *
     * @param csvPrinter
     */
    public static void flush(CSVPrinter csvPrinter) {
        if (Objects.nonNull(csvPrinter)) {
            try {
                csvPrinter.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     *
     * @param csvParser
     */
    public static void close(CSVParser csvParser) {
        if (Objects.nonNull(csvParser)) {
            try {
                csvParser.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
