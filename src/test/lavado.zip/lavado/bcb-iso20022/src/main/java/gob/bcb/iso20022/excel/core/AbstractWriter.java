package gob.bcb.iso20022.excel.core;

import gob.bcb.iso20022.excel.component.ExcelProperty;
import gob.bcb.iso20022.excel.core.data.HeaderData;
import gob.bcb.iso20022.excel.core.factory.ExcelFactory;
import gob.bcb.iso20022.excel.enums.FileTypeEnum;

import org.apache.poi.ss.usermodel.Workbook;

import java.util.List;

/**
 * @description excel writer parent class
 */
public abstract class AbstractWriter extends ExcelProperty {
    public AbstractWriter(String path) {
        this.path = path;
    }

    public void write() {
        write(path);
    }

    public void write(List<HeaderData> headerDataList, List<List<Object>> contentDataList) {
        this.headerDataList = headerDataList;
        this.contentDataList = contentDataList;
        write(path);
    }

    private void write(String path) {
        if (path.endsWith(FileTypeEnum.CSV.getFileType())) {
            doCsvWrite(path);
        } else {
            doExcelWrite(ExcelFactory.writeInstance(path));
        }
    }

    /**
     *
     * @param workbook
     */
    abstract protected void doExcelWrite(Workbook workbook);

    /**
     * @param path
     */
    abstract protected void doCsvWrite(String path);
}
