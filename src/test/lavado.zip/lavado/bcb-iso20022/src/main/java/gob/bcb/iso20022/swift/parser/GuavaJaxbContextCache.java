package gob.bcb.iso20022.swift.parser;

import java.util.concurrent.ExecutionException;

import javax.xml.bind.JAXBContext;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.prowidesoftware.swift.model.mx.JaxbContextCache;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;

/**
 * A jaxb context cache with Guava to test cache implementation injection in {@link JaxbContextLoader}
 *
 * @since 9.0
 */
public class GuavaJaxbContextCache implements JaxbContextCache {

    private final Cache<Class, JAXBContext> cache = CacheBuilder.newBuilder().maximumSize(100).build();

    public JAXBContext get(final Class messageClass, final Class<?>[] classes) throws ExecutionException {
        return cache.get(messageClass, () -> {
            if (classes != null && classes.length > 0) {
                return JAXBContext.newInstance(classes);
            } else {
                return JAXBContext.newInstance(messageClass);
            }
        });
    }

    /**
     * Drops all cached contexts
     */
    public void clear() {
        cache.cleanUp();
    }

    /**
     * Drops the cached context for the specific MX implementation class
     *
     * @return the remove context, if it was present, or null otherwise
     */
    public JAXBContext clear(Class clazz) {
        if (cache != null) {
            cache.invalidate(clazz);
        }
        return null;
    }

    /**
     * @return the number of cached contexts
     */
    public long size() {
        if (cache != null) {
            return cache.size();
        }
        return 0;
    }    
}
