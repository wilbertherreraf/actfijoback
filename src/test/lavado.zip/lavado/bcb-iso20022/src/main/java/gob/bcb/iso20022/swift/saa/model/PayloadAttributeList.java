
package gob.bcb.iso20022.swift.saa.model;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para PayloadAttributeList complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PayloadAttributeList"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PayloadAttribute" type="{urn:swift:saa:xsd:saa.2.0}PayloadAttribute" maxOccurs="3" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PayloadAttributeList", propOrder = {
    "payloadAttributes"
})
public class PayloadAttributeList {

    @XmlElement(name = "PayloadAttribute")
    protected List<PayloadAttribute> payloadAttributes;

    /**
     * Gets the value of the payloadAttributes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the payloadAttributes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPayloadAttributes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PayloadAttribute }
     * 
     * 
     */
    public List<PayloadAttribute> getPayloadAttributes() {
        if (payloadAttributes == null) {
            payloadAttributes = new ArrayList<PayloadAttribute>();
        }
        return this.payloadAttributes;
    }

}
