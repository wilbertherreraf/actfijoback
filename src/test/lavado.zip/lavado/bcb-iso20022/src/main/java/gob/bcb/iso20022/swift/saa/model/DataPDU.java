
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


/**
 * <p>Clase Java para DataPDU complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DataPDU"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Revision" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Header" type="{urn:swift:saa:xsd:saa.2.0}Header"/&gt;
 *         &lt;element name="Body" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="LAU" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DataPDU", propOrder = {
    "revision",
    "header",
    "body",
    "lau"
})
@XmlRootElement(name = "DataPDU")
public class DataPDU {

    @XmlElement(name = "Revision", required = true)
    protected String revision;
    @XmlElement(name = "Header", required = true)
    protected Header header;
    @XmlElement(name = "Body")
    protected SwAny body;
    @XmlElement(name = "LAU")
    protected SwAny lau;

    /**
     * Obtiene el valor de la propiedad revision.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevision() {
        return revision;
    }

    /**
     * Define el valor de la propiedad revision.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public DataPDU setRevision(String value) {
        this.revision = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad header.
     * 
     * @return
     *     possible object is
     *     {@link Header }
     *     
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Define el valor de la propiedad header.
     * 
     * @param value
     *     allowed object is
     *     {@link Header }
     *     
     */
    public DataPDU setHeader(Header value) {
        this.header = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad body.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getBody() {
        return body;
    }

    /**
     * Define el valor de la propiedad body.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public DataPDU setBody(SwAny value) {
        this.body = value;
        return this;
    }

    /**
     * Obtiene el valor de la propiedad lau.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getLAU() {
        return lau;
    }

    /**
     * Define el valor de la propiedad lau.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public DataPDU setLAU(SwAny value) {
        this.lau = value;
        return this;
    }



}
