
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para HistoryIntvCategory.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="HistoryIntvCategory"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="TransmissionReport"/&gt;
 *     &lt;enumeration value="DeliveryReport"/&gt;
 *     &lt;enumeration value="TransmissionResponse"/&gt;
 *     &lt;enumeration value="Security"/&gt;
 *     &lt;enumeration value="Routing"/&gt;
 *     &lt;enumeration value="MesgAsTransmitted"/&gt;
 *     &lt;enumeration value="MesgAsReceived"/&gt;
 *     &lt;enumeration value="MesgModified"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "HistoryIntvCategory")
@XmlEnum
public enum HistoryIntvCategory {

    @XmlEnumValue("TransmissionReport")
    TRANSMISSION_REPORT("TransmissionReport"),
    @XmlEnumValue("DeliveryReport")
    DELIVERY_REPORT("DeliveryReport"),
    @XmlEnumValue("TransmissionResponse")
    TRANSMISSION_RESPONSE("TransmissionResponse"),
    @XmlEnumValue("Security")
    SECURITY("Security"),
    @XmlEnumValue("Routing")
    ROUTING("Routing"),
    @XmlEnumValue("MesgAsTransmitted")
    MESG_AS_TRANSMITTED("MesgAsTransmitted"),
    @XmlEnumValue("MesgAsReceived")
    MESG_AS_RECEIVED("MesgAsReceived"),
    @XmlEnumValue("MesgModified")
    MESG_MODIFIED("MesgModified"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    HistoryIntvCategory(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static HistoryIntvCategory fromValue(String v) {
        for (HistoryIntvCategory c: HistoryIntvCategory.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
