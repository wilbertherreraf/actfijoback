package gob.bcb.iso20022.translate;

import static gob.bcb.iso20022.excel.enums.FieldTypeEnum.INTEGER;

import static gob.bcb.iso20022.excel.enums.FieldTypeEnum.STRING;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.api.Facts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

import gob.bcb.iso20022.excel.ExcelFactory;
import gob.bcb.iso20022.excel.core.data.HeaderData;
import gob.bcb.iso20022.excel.core.data.HeaderDataBuilder;
import gob.bcb.iso20022.excel.core.listener.DataReadListener;
import gob.bcb.iso20022.excel.exception.ExcelReadException;
import gob.bcb.iso20022.exceptions.CompileException;
import gob.bcb.iso20022.exceptions.DuplicateNameException;
import gob.bcb.iso20022.exceptions.NoActionFoundException;
import gob.bcb.iso20022.exceptions.NoMatchingRuleFoundException;
import gob.bcb.iso20022.exceptions.ParseException;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.rules.Engine;
import gob.bcb.iso20022.rules.IAction;
import gob.bcb.iso20022.rules.Rule;
import gob.bcb.iso20022.swift.FieldSwf;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.MappingRule;
import gob.bcb.iso20022.swift.MappingTable;
import gob.bcb.iso20022.utils.MxDataTypesConversor;

/**
 * @author: wherrera
 * 
 */
public class FormatEngine extends PropsTranslate {
	private final static Logger log = LoggerFactory.getLogger(FormatEngine.class);

	private MappingTable mappingTable;
	private ExcelFactory excelFactory;
	private Engine engine;

	private final static Cache<String, Rule> cacheRule = CacheBuilder.newBuilder().maximumSize(500).build();

	private FormatEngine() {
		log.info("Creando FormatEngine ..." + (engine == null));
	}

	public static FormatEngine getInstance() {
		return new FormatEngine(); // FormatEngineHolder.instance;
	}

	public FormatEngine configRulesXls(String nfile, String sheet, Integer firstRowData) {
//		if (initialized)
//			return this;
		HeaderDataBuilder hdrDBuilder = headersXlsMX().nameSheet(sheet).firstRowData(firstRowData);
		excelFactory = ExcelFactory.build().readInstance(nfile, SwfMencampos.class, hdrDBuilder.getHeaderContent(), hdrDBuilder.getNameSheet());
		excelFactory.setSheetName(sheet);

		return this;
	}

	public FormatEngine readRulesXls(String codMT) {
		if (excelFactory == null) {
			throw new ExcelReadException(String.format("Datos de lectura de plantilla no fueron seteados."));
		}
//		if (initialized)
//			return this;
		log.info("inicializando format engine...");

		List<SwfMencampos> swfMencampos = new ArrayList<>();
		excelFactory.read(new DataReadListener<SwfMencampos>((users -> {
			users.forEach(u -> {
				// u.setMtfCodmt(codMT);
				swfMencampos.add(u);
			});

		})));

		mappingTable = new MappingTable("", FileFormat.XLS, FileFormat.XLS);
		fillRulesToMappingTable(swfMencampos, mappingTable);

		return this;
	}

	public FormatEngine readRulesExt(String typeMessage, List<SwfMencampos> swfMencamposList, String fileFormat) {
		mappingTable = new MappingTable(typeMessage, FileFormat.valueOf(fileFormat), FileFormat.valueOf(fileFormat));
		fillRulesToMappingTable(swfMencamposList, mappingTable);

		return this;
	}

	private void fillRulesToMappingTable(List<SwfMencampos> swfMencamposList, MappingTable mappingTable) {
		swfMencamposList.stream()//
				.filter(s -> !StringUtils.isBlank(s.getMtfNemo()))//
				.forEach(u -> {
					Rule r = new Rule(u.getMtfNemo(), u.toStringID(), u.getMtfCondicion(), u.getMtfReglavalid(), 1, u.getMtfNemo(), u.getMtfDescrip(),
							u.getMtfExpresion(), u.getMtfXmltag());
					r.getFullyQualifiedName();
					// int cont = 1;
//					r.addAction(String.valueOf(cont++), u.getMtfSubaction1())//
//							.addAction(String.valueOf(cont++), u.getMtfSubaction2())//
//							.addAction(String.valueOf(cont++), u.getMtfSubaction3())//
//							.addAction(String.valueOf(cont++), u.getMtfSubaction4())//
//							.addAction(String.valueOf(cont++), u.getMtfSubaction5())//
//					;
//					for (String sact : u.getMtfSubaction()) {
//						if (!StringUtils.isBlank(sact)) {
//							r.addAction(String.valueOf(cont++), sact);
//						}
//					}

					boolean expValid = !StringUtils.isBlank(r.getAction()) || !StringUtils.isBlank(r.getExpression()) || r.getActions().size() > 0;
					// log.info("rule {} {} -> {} OUT: {}" , expValid,r.getFullyQualifiedName(),
					// u.toStringID(), r.getOutcome());
					if (expValid) {
						MappingRule mapRule = new MappingRule();
						mapRule.setRule(r);
						mapRule.setSwfCampo(u);

						Supplier<IAction> iaction = MappingTable.mapActions().get(r.getOutcome());
						if (iaction == null) {
							throw new RuntimeException("Transformador inexistente " + r.getOutcome());
						}
						mapRule.setActTransform(iaction.get());
						mappingTable.addMappingRule(mapRule);
					}
				});
		if (mappingTable.getMappingRuleList().size() == 0) {
			throw new RuntimeException("no se registro ninguna regla valida para" + mappingTable.getTypeMessage());
		}

	}

	public FormatEngine initEngineRules() throws DuplicateNameException, CompileException, ParseException {
		List<Rule> rules = rulesMapping(mappingTable);
		if (rules.size() == 0) {
			throw new RuntimeException("No se pudo recuperar reglas a evaluar para " + mappingTable.getTypeMessage());
		}
		engine = new Engine(rules, true).addMethod(MxDataTypesConversor.class);
		return this;
	}

	public MappingTable translate(MappingTable mappingTableIn)
			throws NoMatchingRuleFoundException, NoActionFoundException, DuplicateNameException, CompileException, ParseException {
		if (engine == null) {
			throw new RuntimeException("Transformador no fue inicializado");
		}

		mappingTableIn.getMappingRuleList().forEach(t -> {
			try {
				engine.addCompiledRuleToMap(true, t.getRule());
			} catch (CompileException e) {
				throw new RuntimeException("Error al registrar regla: " + e.getMessage(), e);
			}
		});

		MappingTable mpptabResult = new MappingTable(mappingTableIn.getTypeMessage(), mappingTableIn.getFfSource(), mappingTableIn.getFfDestine());

		List<MappingRule> rules = new LinkedList<>(mappingTable.getMappingRuleList());
		rules.addAll(mappingTableIn.getMappingRuleList());

		Facts f = mappingTableIn.getFacts();
		Map<String, Object> facts = f.asMap();
		log.info("Inicio eval reglas {} rls: {} facts: {}", mappingTableIn.getTypeMessage(), rules.size(), facts.size());

		for (MappingRule mapRule : rules) {
			// log.info("rule " + mapRule.getRule().getFullyQualifiedName() + " => " +
			// mapRule.getRule().getAction()+ " => " + mapRule.getRule().getExpression() + "
			// " + mapRule.getRule().getOutcome());
			MappingRule mapRuleN = new MappingRule();
			mapRuleN.setRule(mapRule.getRule());
			mapRuleN.setSwfCampo(mapRule.getSwfCampo());
			mapRuleN.setActTransform(mapRule.getActTransform());
			mapRuleN.factsSett(f);
			mapRuleN.putFacts(engine.getStatics());
			mapRuleN.putFact(FieldSwf.FACT_SWFCMP, mapRule.getSwfCampo());

			boolean matchRule = engine.executeAction(mapRuleN.getRule().getFullyQualifiedName(), mapRuleN, mapRuleN.getActTransform(), facts);
			mpptabResult.addMappingRule(mapRuleN);
		}
		return mpptabResult;
	}

	public MappingTable translate(List<SwfMencampos> swfMencamposList, MappingTable mappingTableIn)
			throws NoMatchingRuleFoundException, NoActionFoundException, DuplicateNameException, CompileException, ParseException {
		
//		MappingTable mappingTable = new MappingTable(mappingTableIn.getTypeMessage(), mappingTableIn.getFfSource(), mappingTableIn.getFfDestine());
//		fillRulesToMappingTable(swfMencamposList, mappingTable);
		List<Rule> rulesR = new ArrayList<>();
		
//		Engine engine = new Engine(rulesR, true).addMethod(MxDataTypesConversor.class);

		mappingTableIn.getMappingRuleList().forEach(t -> {
//				engine.addCompiledRuleToMap(true, t.getRule());
				rulesR.add(t.getRule());
		});

		MappingTable mpptabResult = new MappingTable(mappingTableIn.getTypeMessage(), mappingTableIn.getFfSource(), mappingTableIn.getFfDestine());

		Facts f = mappingTableIn.getFacts();
		Map<String, Object> facts = f.asMap();
		log.info("Inicio eval reglas {} rls: {} facts: {}", mappingTableIn.getTypeMessage(), facts.size());

		for (SwfMencampos sc : swfMencamposList) {
			if (StringUtils.isBlank(sc.getMtfNemo())){
				continue;
			}
			 			
			Rule r = cacheRule.getIfPresent(sc.toStringID() + sc.getMtfNemo());
			if (r == null) {
				r = new Rule(sc.getMtfNemo(), sc.toStringID(), sc.getMtfCondicion(), sc.getMtfReglavalid(), 1, sc.getMtfNemo(), sc.getMtfDescrip(),
						sc.getMtfExpresion(), sc.getMtfXmltag());
				cacheRule.put(sc.toStringID() + sc.getMtfNemo(), r);
				log.info("rule " + sc.toStringID() +" :: "+ sc.getMtfNemo());
			}
			rulesR.add(r);
			Supplier<IAction> iaction = MappingTable.mapActions().get(r.getOutcome());
			
			MappingRule mapRuleN = new MappingRule();
			mapRuleN.setRule(r);
			mapRuleN.setSwfCampo(sc);
			mapRuleN.setActTransform(iaction.get());
			mapRuleN.factsSett(f);
			mapRuleN.putFacts(engine.getStatics());
			mapRuleN.putFact(FieldSwf.FACT_SWFCMP, sc);
			
			Engine engine = new Engine(rulesR, true).addMethod(MxDataTypesConversor.class);
			boolean matchRule = engine.executeAction(mapRuleN.getRule().getFullyQualifiedName(), mapRuleN, mapRuleN.getActTransform(), facts);
			mpptabResult.addMappingRule(mapRuleN);
		}
		return mpptabResult;
	}
	public MappingTable translate(MappingTable mappingTableIn, boolean betterOpt)
			throws NoMatchingRuleFoundException, NoActionFoundException, DuplicateNameException, CompileException, ParseException {
		if (engine == null) {
			throw new RuntimeException("Transformador no fue inicializado.");
		}

		mappingTableIn.getMappingRuleList().forEach(t -> {
			try {
				engine.addCompiledRuleToMap(true, t.getRule());
			} catch (CompileException e) {
				throw new RuntimeException("Error al registrar regla: " + e.getMessage(), e);
			}
		});

		MappingTable mpptabResult = new MappingTable(mappingTableIn.getTypeMessage(), mappingTableIn.getFfSource(), mappingTableIn.getFfDestine());

		List<MappingRule> rules = new LinkedList<>(mappingTable.getMappingRuleList());
		rules.addAll(mappingTableIn.getMappingRuleList());

		Map<String, Object> facts = mappingTableIn.getFacts().asMap();
		log.info("Inicio eval reglas {} rls: {} facts: {}", mappingTableIn.getTypeMessage(), rules.size(), facts.size());

		for (MappingRule mapRule : rules) {
			log.info("rule " + mapRule.getRule().getFullyQualifiedName() + " => " + mapRule.getRule().getAction() + " => "
					+ mapRule.getRule().getExpression());
			MappingRule mapRuleN = new MappingRule();
			mapRuleN.setRule(mapRule.getRule());
			mapRuleN.setSwfCampo(mapRule.getSwfCampo());
			mapRuleN.setActTransform(mapRule.getActTransform());
			mapRuleN.factsSett(mappingTableIn.getFacts());
			mapRuleN.putFacts(engine.getStatics());
			mapRuleN.putFact(FieldSwf.FACT_SWFCMP, mapRule.getSwfCampo());
			boolean matchRule = engine.executeAction(mapRuleN.getRule().getFullyQualifiedName(), mapRuleN, mapRuleN.getActTransform(), facts);
			mpptabResult.addMappingRule(mapRuleN);

			if (betterOpt) {
				if (matchRule) {
					return mpptabResult;
				}
			}

		}
		return mpptabResult;
	}

	public static List<Rule> rulesMapping(MappingTable mappingTable) {
		Map<String, List<Rule>> mRules = mappingTable.getMappingRuleList().stream().map(mr -> mr.getRule())//
				.collect(Collectors.groupingBy(Rule::getFullyQualifiedName))//
		;

		return mRules.entrySet().stream().map(e -> e.getValue().get(0)).collect(Collectors.toList());
	}

	public static HeaderDataBuilder headersXlsMX() {
		HeaderDataBuilder headerDataBuilder = HeaderDataBuilder.instance();
		List<HeaderData> headerDataList = headerDataBuilder//
				.fill("mtfId", INTEGER, 0)//
				.fill("mtfNemo", STRING, 1)//
				.fill("mtfCodcampo", STRING, 2)//
				.fill("mtfSecpadre", STRING, 3)//
				.fill("mtfCondicion", STRING, 4)//
				.fill("mtfExpresion", STRING, 5)//
				.fill("mtfCardinal", STRING, 6)//
				.fill("mtfTipocampo", STRING, 7)//
				.fill("mtfReglavalid", STRING, 8)//
				.fill("mtfFormato", STRING, 9)//
				.fill("mtfBloque", STRING, 10)//
				.fill("mtfXmltag", STRING, 15)//
				.fill("mtfSubaction", STRING, 16)//
				.fill("mtfSubaction", STRING, 17)//
				.fill("mtfSubaction", STRING, 18)//
				.fill("mtfSubaction", STRING, 19)//
				.fill("mtfSubaction", STRING, 20)//
				.fill("mtfSubaction", STRING, 21)//
				// .fill("mtfCodmt", STRING )//
				// .fill("mtfNro", INTEGER, 0)//
				// .fill("mtfGrpopt", INTEGER )//
//        		.fill("mtfDescrip",                  STRING,3 )//
//        		.fill("mtfStatus",                   STRING )//
//        		.fill("mtfReglaswf",                 STRING )//
//        		.fill("mtfDatoadic",                 STRING )//
//        		.fill("mtfDefault",                  STRING )//
//        		.fill("mtfEstado",                   STRING )//
//        		.fill("mtfIndexiso",                 STRING )//
				// .fill("mtfNivel", INTEGER,2 )//
//        		.fill("mtfCambiavalor",              STRING )//
//        		.fill("mtfMinimo",                   STRING )//
//        		.fill("mtfValidacionerror",          STRING )//
//        		.fill("mtfCambiatipousr",            STRING )//
//        		.fill("mtfCardinalmult",             STRING,13 )//

//				.fill("mtfSinonimos", STRING, 17)//
//				.fill("mtfConvalornoreq", STRING, 18)//
//				.fill("mtfEsopcional", STRING, 19)//
//				.fill("mtfEsadicional", STRING, 20)//
				.firstRowData(2)//
				.build();
		return headerDataBuilder;
	}

//	public MappingTable getMpptabResult() {
//		return mpptabResult;
//	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}
}
