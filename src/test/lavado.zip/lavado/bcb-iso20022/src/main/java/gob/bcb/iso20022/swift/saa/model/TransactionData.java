
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TransactionData complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TransactionData"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransactionDataResult" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="TransactionDataDetails" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionData", propOrder = {
    "transactionDataResult",
    "transactionDataDetails"
})
public class TransactionData {

    @XmlElement(name = "TransactionDataResult", required = true)
    protected String transactionDataResult;
    @XmlElement(name = "TransactionDataDetails")
    protected String transactionDataDetails;

    /**
     * Obtiene el valor de la propiedad transactionDataResult.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionDataResult() {
        return transactionDataResult;
    }

    /**
     * Define el valor de la propiedad transactionDataResult.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionDataResult(String value) {
        this.transactionDataResult = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionDataDetails.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionDataDetails() {
        return transactionDataDetails;
    }

    /**
     * Define el valor de la propiedad transactionDataDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionDataDetails(String value) {
        this.transactionDataDetails = value;
    }

}
