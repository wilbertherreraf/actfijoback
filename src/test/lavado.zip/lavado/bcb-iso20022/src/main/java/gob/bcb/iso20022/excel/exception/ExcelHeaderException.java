package gob.bcb.iso20022.excel.exception;

public class ExcelHeaderException extends RuntimeException{
    public ExcelHeaderException() {
        super();
    }

    public ExcelHeaderException(String message) {
        super(message);
    }
}
