package gob.bcb.iso20022.excel.enums;

public enum FileTypeEnum {
    XLS("xls"),
    XLSX("xlsx"),
    CSV("csv");

    String fileType;

    FileTypeEnum(String fileType) {
        this.fileType = fileType;
    }


    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }
}
