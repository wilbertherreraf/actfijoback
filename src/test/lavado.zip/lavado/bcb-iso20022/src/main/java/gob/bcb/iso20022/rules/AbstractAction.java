package gob.bcb.iso20022.rules;


import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

import org.apache.commons.lang3.StringUtils;
import org.mvel2.MVEL;
import org.mvel2.templates.CompiledTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is an abstract implementation of the {@link IAction} interface. Its
 * implementation simply provides a mechanism for naming the object, and bases
 * the {@link #equals(Object)} and {@link #hashCode()} on that name.
 * 
 * @see IAction
 */
public abstract class AbstractAction<Input, Output> implements IAction<Input, Output> {
	private static final Logger log = LoggerFactory.getLogger(AbstractAction.class);	
	public final static String NAMEDEFAULT = "ACTIONDEFAULT";
	public final static String INPUT_KEYWORD = "input";
	public final static String OUTPUT_KEYWORD = "output";
	public final static String OUTPUTSUB_KEYWORD = "outputsub";
	public final static String RULEIN_KEYWORD = "rulein";
	private final Map<String, Object> methodsStatic = new HashMap<>();
	private final String name;
	private boolean addStatics = false;
	private BiConsumer<Rule, Output> afterIActionExec;

	public AbstractAction(String name, BiConsumer<Rule, Output> listenerCondicionC) {
		this.name = name;
		this.afterIActionExec = listenerCondicionC;
		postConstruct();
	}

	public AbstractAction(String name) {
		this(name, null);
	}

	public AbstractAction() {
		this(NAMEDEFAULT, null);
	}

	private void postConstruct() {
		if (afterIActionExec == null) {
			afterIActionExec = (r, i) -> {
			};
		}
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void afterCondition(CompiledRule rule, Input input, boolean accepted) {
		Output outputIni = initializeOutputResult(rule, input);
		
		Map<String, Object> vars = generateVars(input, outputIni, null);
		Output outputExe = execute(rule, input, vars);
		Output output = outputExe != null ? outputExe : outputIni;
		
		executeAction(rule, vars);
		if (output != null)
			postExecuteAction(rule, input, output, vars);

		executeSubActions(rule, input, vars);
	}

	protected Object executeAction(CompiledRule rule, Map<String, Object> vars) {

		Rule r = rule.getRule();
		if (StringUtils.isBlank(r.getAction())) {
			return null;
		}

		try {
			rule.compileAction(false);
		} catch (Exception e) {
			log.warn("No se puede parsear la expresion " + r.getAction() + " " + e.getMessage());
			return null;
		}

		Serializable compiled = rule.getCompiledAction();

		try {
			Object o = MVEL.executeExpression(compiled, vars);
			if (o != null) {
				if (String.valueOf(o).equals("true")) {
					return null;
				} else {
					return o;
				}
			}
		} catch (Exception e) {
			log.warn("No se puede parsear la expresion " + r.getAction() + " " + e.getMessage());
		}
		return null;
	}

	protected void executeSubActions(CompiledRule rule, Input input, Map<String, Object> vars) {
		for (Action action : rule.getRule().getActions()) {
			if (StringUtils.isBlank(action.getValue())) {
				continue;
			}

			try {
				Output output = initializeOutputResult(rule, input);
				if (output != null)
					vars.put(OUTPUTSUB_KEYWORD, output);
				
				addMethods(vars);
				
				Serializable compiledAction = MVEL.compileExpression(action.getValue());
				MVEL.executeExpression(compiledAction, vars);
				postExecuteSubAction(rule, action, input, output, vars);
			} catch (Exception e) {
				log.warn("No se puede parsear sub action " + action.getAttribute() + ":" + action.getValue() + " " + e.getMessage());
			}
		}
	}

	protected abstract Output initializeOutputResult(CompiledRule rule, Input input);
	
	protected Map<String, Object> generateVars(Input input, Output output, Map<String, Object> statics) {
		//Map<String, Object> vars = new HashMap<String, Object>(statics); // initialise with static stuff
		Map<String, Object> vars = new HashMap<String, Object>(); // initialise with static stuff
		if (input != null)
			vars.put(INPUT_KEYWORD, input);
		if (output != null)
			vars.put(OUTPUT_KEYWORD, output);
		
		addMethods(vars);
		
		return vars;
	}

	public AbstractAction addMethod(Class clazz) {
		for (Method method : clazz.getDeclaredMethods()) {
			addMethod(method.getName(), method);
		}
		return this;
	}

	public AbstractAction addMethod(String nameMethod, Method method) {
		if (!method.getName().contains("$")) {
			method.setAccessible(true);
			methodsStatic.putIfAbsent(nameMethod, method);
			addStatics = true;
		}
		return this;
	}	
	
	public void addMethods(Map<String, Object> vars) {
		methodsStatic.forEach((k, v) -> {
			if (!vars.containsKey(k)) {
				vars.put(k, v);
			}
		});
		addStatics = false;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		@SuppressWarnings("unchecked")
		AbstractAction<Input, Output> other = (AbstractAction<Input, Output>) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Action [name=" + name + "]";
	}

	public BiConsumer<Rule, Output> getAfterIActionExec() {
		return afterIActionExec;
	}

	public void setAfterIActionExec(BiConsumer<Rule, Output> afterIActionExec) {
		this.afterIActionExec = afterIActionExec;
	}
}
