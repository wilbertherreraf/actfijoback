package gob.bcb.iso20022.model;

import java.util.Date;
import java.util.List;
import java.util.function.Function;

public class SwfReglasmerc {
	private Integer mktCodregla;
	private String mktNrosec;
	private String rhdAbccodctaper;
	private String rhdModeltype;
	private String rhdCodctapers;
	private String rhdAccesscode;
	private String rhdModelowner;
	private String rhdModelname;
	private String rhdAgencycode;
	private String rhdCurrency;
	private String rhdCountry;
	private String rhdSecurity;
	private String rhdMethodtype;
	
	private String mktPset;
	private String mktCtaglbcusto;
	private String mktCustoacctnm;
	private String mktCustoname;
	private String mktCustobic;
	private String mktCustoaddress;
	private String mktCustocity;
	private String mktCustoctry;
	private String mktCtacontab;
	private String mktPaymentcurr;
	private String mktAltercurr;
	private String mktAlterctacash;	
	private String mktIdpartdepo1;
	private String mktIdpartdepo2;
	private String mktIdpartdepo3;
	private String mktAgentid;
	private String mktPartname;
	private String mktPartcity;	
	private String mktPartctry;	
	private String mktInstbic;	
	private String mktInstid;
	private String mktInstname;
	private String mktInstaccnm;	
	private String mktInstaddress;
	private String mktInstctry;	
	private String mktInstcity;	
	private String mktInsttype;
	private String mktCtalocalagent;
	private String mktCorrespctasec;	
	private String mktSubagentname;
	private String mktSubagentaddress;
	private String mktSubagentbic;
	private String mktSubagentctry;
	private String mktSubagentcity;
	private String mktCashctanumber;	
	private String mktCorrespname;
	private String mktCorrespbic;
	private String mktCorrespaddress;
	private String mktCorrespctry;
	private String mktCorrespcity;
	private String mktCorrespctacash;
	private String mktRelationship;	
	private String mktRegbic;
	private String mktRegname;	
	private String mktRegaddress;
	private String mktRegcity;
	private String mktRegctry;
	private String mktReceivingagebic;
	private String mktInfoadic;
	private Date mktFechavig;
	
	public SwfReglasmerc() {
		// TODO Auto-generated constructor stub
	}

	public String getRhdModeltype() {
		return rhdModeltype;
	}

	public void setRhdModeltype(String rhdModeltype) {
		this.rhdModeltype = rhdModeltype;
	}

	public String getRhdCodctapers() {
		return rhdCodctapers;
	}

	public void setRhdCodctapers(String rhdCodctapers) {
		this.rhdCodctapers = rhdCodctapers;
	}

	public String getRhdModelname() {
		return rhdModelname;
	}

	public void setRhdModelname(String rhdModelname) {
		this.rhdModelname = rhdModelname;
	}

	public String getRhdCurrency() {
		return rhdCurrency;
	}

	public void setRhdCurrency(String rhdCurrency) {
		this.rhdCurrency = rhdCurrency;
	}

	public String getRhdCountry() {
		return rhdCountry;
	}

	public void setRhdCountry(String rhdCountry) {
		this.rhdCountry = rhdCountry;
	}

	public String getRhdSecurity() {
		return rhdSecurity;
	}

	public void setRhdSecurity(String rhdSecurity) {
		this.rhdSecurity = rhdSecurity;
	}

	public String getRhdMethodtype() {
		return rhdMethodtype;
	}

	public void setRhdMethodtype(String rhdMethodtype) {
		this.rhdMethodtype = rhdMethodtype;
	}

	public String getRhdAccesscode() {
		return rhdAccesscode;
	}

	public void setRhdAccesscode(String rhdAccesscode) {
		this.rhdAccesscode = rhdAccesscode;
	}

	public String getRhdModelowner() {
		return rhdModelowner;
	}

	public void setRhdModelowner(String rhdModelowner) {
		this.rhdModelowner = rhdModelowner;
	}

	public String getRhdAgencycode() {
		return rhdAgencycode;
	}

	public void setRhdAgencycode(String rhdAgencycode) {
		this.rhdAgencycode = rhdAgencycode;
	}

	public String getRhdAbccodctaper() {
		return rhdAbccodctaper;
	}

	public void setRhdAbccodctaper(String rhdAbccodctaper) {
		this.rhdAbccodctaper = rhdAbccodctaper;
	}

	public SwfReglasmerc putRhdAbccodctaper(String rhdAbccodctaper) {
		this.rhdAbccodctaper = rhdAbccodctaper;
		return this;
	}

	public SwfReglasmerc putRhdAccesscode(String rhdAccesscode) {
		this.rhdAccesscode = rhdAccesscode;
		return this;
	}

	public SwfReglasmerc putRhdAgencycode(String rhdAgencycode) {
		this.rhdAgencycode = rhdAgencycode;
		return this;
	}

	public SwfReglasmerc putRhdCodctapers(String rhdCodctapers) {
		this.rhdCodctapers = rhdCodctapers;
		return this;
	}

	public SwfReglasmerc putRhdCountry(String rhdCountry) {
		this.rhdCountry = rhdCountry;
		return this;
	}

	public SwfReglasmerc putRhdMethodtype(String rhdMethodtype) {
		this.rhdMethodtype = rhdMethodtype;
		return this;
	}

	public SwfReglasmerc putRhdModelname(String rhdModelname) {
		this.rhdModelname = rhdModelname;
		return this;
	}

	public SwfReglasmerc putRhdModelowner(String rhdModelowner) {
		this.rhdModelowner = rhdModelowner;
		return this;
	}

	public SwfReglasmerc putRhdModeltype(String rhdModeltype) {
		this.rhdModeltype = rhdModeltype;
		return this;
	}

	public SwfReglasmerc putRhdSecurity(String rhdSecurity) {
		this.rhdSecurity = rhdSecurity;
		return this;
	}

	public SwfReglasmerc putRhdCurrency(String rhdCurrency) {
		this.rhdCurrency = rhdCurrency;
		return this;
	}

	public String getMktPset() {
		return mktPset;
	}

	public void setMktPset(String mktPset) {
		this.mktPset = mktPset;
	}

	public String getMktCtaglbcusto() {
		return mktCtaglbcusto;
	}

	public void setMktCtaglbcusto(String mktCtaglbcusto) {
		this.mktCtaglbcusto = mktCtaglbcusto;
	}

	public String getMktCustoname() {
		return mktCustoname;
	}

	public void setMktCustoname(String mktCustoname) {
		this.mktCustoname = mktCustoname;
	}

	public String getMktCustobic() {
		return mktCustobic;
	}

	public void setMktCustobic(String mktCustobic) {
		this.mktCustobic = mktCustobic;
	}

	public String getMktCustoaddress() {
		return mktCustoaddress;
	}

	public void setMktCustoaddress(String mktCustoaddress) {
		this.mktCustoaddress = mktCustoaddress;
	}

	public String getMktCustocity() {
		return mktCustocity;
	}

	public void setMktCustocity(String mktCustocity) {
		this.mktCustocity = mktCustocity;
	}

	public String getMktCashctanumber() {
		return mktCashctanumber;
	}

	public void setMktCashctanumber(String mktCashctanumber) {
		this.mktCashctanumber = mktCashctanumber;
	}

	public String getMktPaymentcurr() {
		return mktPaymentcurr;
	}

	public void setMktPaymentcurr(String mktPaymentcurr) {
		this.mktPaymentcurr = mktPaymentcurr;
	}

	public String getMktAltercurr() {
		return mktAltercurr;
	}

	public void setMktAltercurr(String mktAltercurr) {
		this.mktAltercurr = mktAltercurr;
	}

	public String getMktRelationship() {
		return mktRelationship;
	}

	public void setMktRelationship(String mktRelationship) {
		this.mktRelationship = mktRelationship;
	}

	public String getMktCorrespname() {
		return mktCorrespname;
	}

	public void setMktCorrespname(String mktCorrespname) {
		this.mktCorrespname = mktCorrespname;
	}

	public String getMktCorrespbic() {
		return mktCorrespbic;
	}

	public void setMktCorrespbic(String mktCorrespbic) {
		this.mktCorrespbic = mktCorrespbic;
	}

	public String getMktCorrespctry() {
		return mktCorrespctry;
	}

	public void setMktCorrespctry(String mktCorrespctry) {
		this.mktCorrespctry = mktCorrespctry;
	}

	public String getMktCorrespctacash() {
		return mktCorrespctacash;
	}

	public void setMktCorrespctacash(String mktCorrespctacash) {
		this.mktCorrespctacash = mktCorrespctacash;
	}

	public String getMktCorrespctasec() {
		return mktCorrespctasec;
	}

	public void setMktCorrespctasec(String mktCorrespctasec) {
		this.mktCorrespctasec = mktCorrespctasec;
	}

	public String getMktIdpartdepo1() {
		return mktIdpartdepo1;
	}

	public void setMktIdpartdepo1(String mktIdpartdepo1) {
		this.mktIdpartdepo1 = mktIdpartdepo1;
	}

	public String getMktIdpartdepo2() {
		return mktIdpartdepo2;
	}

	public void setMktIdpartdepo2(String mktIdpartdepo2) {
		this.mktIdpartdepo2 = mktIdpartdepo2;
	}

	public String getMktIdpartdepo3() {
		return mktIdpartdepo3;
	}

	public void setMktIdpartdepo3(String mktIdpartdepo3) {
		this.mktIdpartdepo3 = mktIdpartdepo3;
	}

	public String getMktAgentid() {
		return mktAgentid;
	}

	public void setMktAgentid(String mktAgentid) {
		this.mktAgentid = mktAgentid;
	}

	public String getMktCtalocalagent() {
		return mktCtalocalagent;
	}

	public void setMktCtalocalagent(String mktCtalocalagent) {
		this.mktCtalocalagent = mktCtalocalagent;
	}

	public String getMktAlterctacash() {
		return mktAlterctacash;
	}

	public void setMktAlterctacash(String mktAlterctacash) {
		this.mktAlterctacash = mktAlterctacash;
	}

	public String getMktSubagentname() {
		return mktSubagentname;
	}

	public void setMktSubagentname(String mktSubagentname) {
		this.mktSubagentname = mktSubagentname;
	}

	public String getMktSubagentbic() {
		return mktSubagentbic;
	}

	public void setMktSubagentbic(String mktSubagentbic) {
		this.mktSubagentbic = mktSubagentbic;
	}

	public String getMktSubagentctry() {
		return mktSubagentctry;
	}

	public void setMktSubagentctry(String mktSubagentctry) {
		this.mktSubagentctry = mktSubagentctry;
	}

	public String getMktRegbic() {
		return mktRegbic;
	}

	public void setMktRegbic(String mktRegbic) {
		this.mktRegbic = mktRegbic;
	}

	public String getMktRegcity() {
		return mktRegcity;
	}

	public void setMktRegcity(String mktRegcity) {
		this.mktRegcity = mktRegcity;
	}

	public String getMktRegctry() {
		return mktRegctry;
	}

	public void setMktRegctry(String mktRegctry) {
		this.mktRegctry = mktRegctry;
	}

	public String getMktReceivingagebic() {
		return mktReceivingagebic;
	}

	public void setMktReceivingagebic(String mktReceivingagebic) {
		this.mktReceivingagebic = mktReceivingagebic;
	}

	public Integer getMktCodregla() {
		return mktCodregla;
	}

	public void setMktCodregla(Integer mktCodregla) {
		this.mktCodregla = mktCodregla;
	}

	public String getMktCtacontab() {
		return mktCtacontab;
	}

	public void setMktCtacontab(String mktCtacontab) {
		this.mktCtacontab = mktCtacontab;
	}

	public Date getMktFechavig() {
		return mktFechavig;
	}

	public void setMktFechavig(Date mktFechavig) {
		this.mktFechavig = mktFechavig;
	}

	public String getMktRegname() {
		return mktRegname;
	}

	public void setMktRegname(String mktRegname) {
		this.mktRegname = mktRegname;
	}

	public String getMktRegaddress() {
		return mktRegaddress;
	}

	public void setMktRegaddress(String mktRegaddress) {
		this.mktRegaddress = mktRegaddress;
	}

	public String getMktPartcity() {
		return mktPartcity;
	}

	public void setMktPartcity(String mktPartcity) {
		this.mktPartcity = mktPartcity;
	}

	public String getMktPartctry() {
		return mktPartctry;
	}

	public void setMktPartctry(String mktPartctry) {
		this.mktPartctry = mktPartctry;
	}

	public String getMktSubagentaddress() {
		return mktSubagentaddress;
	}

	public void setMktSubagentaddress(String mktSubagentaddress) {
		this.mktSubagentaddress = mktSubagentaddress;
	}

	public String getMktCorrespcity() {
		return mktCorrespcity;
	}

	public void setMktCorrespcity(String mktCorrespcity) {
		this.mktCorrespcity = mktCorrespcity;
	}

	public String getMktCorrespaddress() {
		return mktCorrespaddress;
	}

	public void setMktCorrespaddress(String mktCorrespaddress) {
		this.mktCorrespaddress = mktCorrespaddress;
	}

	public String getMktInfoadic() {
		return mktInfoadic;
	}

	public void setMktInfoadic(String mktInfoadic) {
		this.mktInfoadic = mktInfoadic;
	}

	public String getMktInstaddress() {
		return mktInstaddress;
	}

	public void setMktInstaddress(String mktInstaddress) {
		this.mktInstaddress = mktInstaddress;
	}

	public String getMktInstname() {
		return mktInstname;
	}

	public void setMktInstname(String mktInstname) {
		this.mktInstname = mktInstname;
	}

	public String getMktInstbic() {
		return mktInstbic;
	}

	public void setMktInstbic(String mktInstbic) {
		this.mktInstbic = mktInstbic;
	}

	public String getMktInstid() {
		return mktInstid;
	}

	public void setMktInstid(String mktInstid) {
		this.mktInstid = mktInstid;
	}

	public String getMktPartname() {
		return mktPartname;
	}

	public void setMktPartname(String mktPartname) {
		this.mktPartname = mktPartname;
	}

	public String getMktInstctry() {
		return mktInstctry;
	}

	public void setMktInstctry(String mktInstctry) {
		this.mktInstctry = mktInstctry;
	}


	public String getMktNrosec() {
		return mktNrosec;
	}

	public void setMktNrosec(String mktNrosec) {
		this.mktNrosec = mktNrosec;
	}

	public String getMktSubagentcity() {
		return mktSubagentcity;
	}

	public void setMktSubagentcity(String mktSubagentcity) {
		this.mktSubagentcity = mktSubagentcity;
	}

	public String getMktInstcity() {
		return mktInstcity;
	}

	public void setMktInstcity(String mktInstcity) {
		this.mktInstcity = mktInstcity;
	}

	public String getMktCustoctry() {
		return mktCustoctry;
	}

	public void setMktCustoctry(String mktCustoctry) {
		this.mktCustoctry = mktCustoctry;
	}

	public String hdrs() {
		return 
				"Agencycode|Currency|Accesscode|CSM|"+
						"Codregla|Nrosec|Pset|Ctaglbcusto|Custoacctnm|Custoname|Custobic|Custoaddress|Custocity|Custoctry|Cashctanumber|"+
						"Ctacontab|Paymentcurr|Altercurr|Relationship|Correspname|Correspbic|Correspaddress|Correspctry|Correspcity|"+
						"Correspctacash|Correspctasec|Idpartdepo1|Idpartdepo2|Idpartdepo3|Agentid|Instbic|Instid|Instname|"+
						"Instaddress|Instctry|Instcity|Partname|Partcity|Partctry|Ctalocalagent|Alterctacash|Subagentname|Subagentaddress|"+
						"Subagentbic|Subagentctry|Subagentcity|Regbic|Regname|Regaddress|Regcity|Regctry|Receivingagebic|Fechavig";
	}

	public String toStringSH() {
		return String.format(
				"%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s",
				rhdAgencycode,rhdCurrency,rhdAccesscode,
				rhdCountry+"-"+rhdSecurity+"-"+rhdMethodtype,
				mktCodregla, mktNrosec, mktPset, mktCtaglbcusto, mktCustoacctnm,mktCustoname, mktCustobic, mktCustoaddress, mktCustocity, mktCustoctry, mktCashctanumber,
				mktCtacontab, mktPaymentcurr, mktAltercurr, mktRelationship, mktCorrespname, mktCorrespbic, mktCorrespaddress, mktCorrespctry, mktCorrespcity,
				mktCorrespctacash, mktCorrespctasec, mktIdpartdepo1, mktIdpartdepo2, mktIdpartdepo3, mktAgentid, mktInstbic, mktInstid, mktInstname,
				mktInstaddress, mktInstctry, mktInstcity, mktPartname, mktPartcity, mktPartctry, mktCtalocalagent, mktAlterctacash, mktSubagentname, mktSubagentaddress,
				mktSubagentbic, mktSubagentctry, mktSubagentcity,mktRegbic, mktRegname, mktRegaddress, mktRegcity, mktRegctry, mktReceivingagebic, mktFechavig);
	}

	public String toStringRh() {
		Function<String, String> nullEmp = s -> {
			return (s == null) ? "" : s.trim();
		};

		return "=>" + nullEmp.apply(rhdModeltype) + " CSM[" + nullEmp.apply(rhdCountry) + "-"
				+ nullEmp.apply(rhdSecurity) + "-" + nullEmp.apply(rhdMethodtype) + "] (" + nullEmp.apply(rhdCurrency) + "), A/C["
				+ nullEmp.apply(rhdAbccodctaper) + ":"+ nullEmp.apply(rhdCodctapers) + ":" + nullEmp.apply(rhdAccesscode) + "] MDL[" + nullEmp.apply(rhdModelowner) + "-"
				+ nullEmp.apply(rhdModelname) +"-"+ nullEmp.apply(rhdAgencycode)+ "]";
	}

	public String getMktInsttype() {
		return mktInsttype;
	}

	public void setMktInsttype(String mktInsttype) {
		this.mktInsttype = mktInsttype;
	}

	public String getMktCustoacctnm() {
		return mktCustoacctnm;
	}

	public void setMktCustoacctnm(String mktCustoacctnm) {
		this.mktCustoacctnm = mktCustoacctnm;
	}

	public String getMktInstaccnm() {
		return mktInstaccnm;
	}

	public void setMktInstaccnm(String mktInstaccnm) {
		this.mktInstaccnm = mktInstaccnm;
	}
	
}
