package gob.bcb.iso20022.excel.exception;

/**
 * @Author JoeBig7
 * @date 2021/12/14 18:06:14
 */
public class CsvException extends RuntimeException{

    public CsvException() {
        super();
    }

    public CsvException(String message) {
        super(message);
    }
}
