package gob.bcb.iso20022.excel.utils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import gob.bcb.iso20022.excel.exception.ExcelReadException;

/**
 * Util para reflection 
 * @author WHerrera
 *
 */
public class ClassUtils {
    
    public static boolean isAccessorMethod(final Method method) {
        
        return isGetterMethod(method)
                || isBooleanGetterMethod(method)
                || isSetterMethod(method);
        
    }
    
    public static boolean isGetterMethod(final Method method) {
        
        final String methodName = method.getName();
        if(!methodName.startsWith("get")) {
            return false;
            
        } else if(methodName.length() <= 3) {
            return false;
        }
        
        if(method.getParameterCount() > 0) {
            return false;
        }
        
        if(method.getReturnType().equals(Void.class)) {
            return false;
        }
        
        return true;
        
    }
    
    public static boolean isSetterMethod(final Method method) {
        
        final String methodName = method.getName();
        if(!methodName.startsWith("set")) {
            return false;
            
        } else if(methodName.length() <= 3) {
            return false;
        }
        
        if(method.getParameterCount() != 1) {
            return false;
        }
        
        return true;
        
    }
    
    public static boolean isBooleanGetterMethod(final Method method) {
        
        final String methodName = method.getName();
        if(!methodName.startsWith("is")) {
            return false;
            
        } else if(methodName.length() <= 2) {
            return false;
        }
        
        if(method.getParameterCount() > 0) {
            return false;
        }
        
        if(!isPrimitiveBoolean(method.getReturnType())) {
            return false;
        }
        
        return true;
    }
    
    public static boolean isPrimitiveBoolean(final Class<?> type) {
        if(type.isPrimitive() && boolean.class.isAssignableFrom(type)) {
            return true;
        }
        
        return false;
    }
    
    public static Optional<Field> extractField(final Class<?> targetClass, final String propertyName, final Class<?> propertyType) {
        
        final Field field;
        try {
            field = targetClass.getDeclaredField(propertyName);
        } catch (NoSuchFieldException | SecurityException e) {
            return Optional.empty();
        }
        
        field.setAccessible(true);
        
        if(!field.getType().equals(propertyType)) {
            return Optional.empty();
            
        }
        
        return Optional.of(field);
        
    }
    
    public static Optional<Method> extractGetter(final Class<?> targetClass, final String propertyName, final Class<?> propertyType) {
        
        final String methodName = "get" + StringUtils.capitalize(propertyName);
        
        Method method;
        try {
            method = targetClass.getMethod(methodName);
            
        } catch (NoSuchMethodException | SecurityException e) {
            return Optional.empty();
        }
        
        method.setAccessible(true);
        
        if(method.getParameterCount() > 0) {
            return Optional.empty();
        }
        
        if(propertyType != null && !method.getReturnType().equals(propertyType)) {
            return Optional.empty();
        }
        
        return Optional.of(method);
    }
    
    public static Optional<Method> extractBooleanGetter(final Class<?> targetClass, final String propertyName) {
        
        final String methodName = "is" + StringUtils.capitalize(propertyName);
        
        Method method;
        try {
            method = targetClass.getMethod(methodName);
            
        } catch (NoSuchMethodException | SecurityException e) {
            return Optional.empty();
        }
        
        method.setAccessible(true);
        
        if(!method.getReturnType().equals(boolean.class)) {
            return Optional.empty();
        }
        
        return Optional.of(method);
    }
    
    public static Optional<Method> extractSetter(final Class<?> targetClass, final String propertyName, final Class<?> propertyType) {
        
        final String methodName = "set" + StringUtils.capitalize(propertyName);
        
        Method method;
        try {
            method = targetClass.getMethod(methodName, propertyType);
        } catch (NoSuchMethodException | SecurityException e) {
            return Optional.empty();
        }
        
        method.setAccessible(true);
        
        return Optional.of(method);
    }
    
    @SuppressWarnings("unchecked")
    public static <T> Optional<T> getAnnotationAttribute(final Annotation anno, final String attrName, final Class<T> attrType) {
        
        try {
            final Method method = anno.annotationType().getMethod(attrName);
            method.setAccessible(true);
            if(!attrType.equals(method.getReturnType())) {
                return Optional.empty();
            }
            
            final Object value = method.invoke(anno);
            return Optional.of((T)value);
            
        } catch (Exception e) {
            return Optional.empty();
        }
        
    }
    
    public static <T>  boolean hasAnnotationAttribute(final Annotation anno, final String attrName, final Class<T> attrType) {
       
        return getAnnotationAttribute(anno, attrName, attrType).isPresent();
        
    }

    //final Class<?> targetClass, final String propertyName, final Class<?> propertyType
    public static void setField(Object cellObj, final Class<?> type, String fieldName, Object cellValue){
    	if (cellObj == null || cellValue == null || StringUtils.isBlank(fieldName))
    		return;
    	
    	Optional<Method> setterOpt = extractSetter(cellObj.getClass(), fieldName, cellValue.getClass());
    	try {
    		if (setterOpt.isPresent())
    			setterOpt.get().invoke(cellObj,cellValue);
		} catch (Exception e) {
			throw new ExcelReadException("Error al setear campo excel a objeto " + fieldName);
		}
    }
    
    public static Object getField(Object cellObj, String fieldName){
    	Optional<Method> getterOpt = extractGetter(cellObj.getClass(), fieldName, null);
    	try {
			return getterOpt.get().invoke(cellObj);
		} catch (IllegalAccessException e) {
			return null;
		} catch (IllegalArgumentException e) {
			return null;
		} catch (InvocationTargetException e) {
			return null;
		}
    }
}
