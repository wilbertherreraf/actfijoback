package gob.bcb.iso20022.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Diccionario del detalle de campos entre formatos MT y MX, base de la 
 * 
 */
public class SwfMencampos implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer mtfId;

	private String mtfCodcampo;
	private String mtfCodmt;
	private Integer mtfNro;
	private Integer mtfGrpopt;
	private String mtfNemo;
	private String mtfDescrip;
	private String mtfReglavalid;
	private String mtfStatus;
	private String mtfTipocampo;
	private String mtfCondicion;
	private String mtfExpresion;
	private String mtfSecpadre;
	private String mtfBloque;
	private String mtfFormato;
	private String mtfReglaswf;
	private String mtfDatoadic;
	private String mtfDefault;
	private String mtfEstado;

	private String mtfIndexiso;
	private Integer mtfNivel;
	private String mtfXmltag;
	private String mtfCardinal;	
	private String mtfCambiavalor;
	private String mtfMinimo;
	private String mtfValidacionerror;
	private String mtfCambiatipousr;
	private String mtfCardinalmult;
	private String mtfSinonimos;
	private String mtfConvalornoreq;
	private String mtfEsopcional;
	private String mtfEsadicional;
	private String mtfSubaction1;
	private String mtfSubaction2;
	private String mtfSubaction3;
	private String mtfSubaction4;
	private String mtfSubaction5;	
	private final List<String> mtfSubaction = new ArrayList<>();

	public SwfMencampos() {
	}

	public Integer getMtfId() {
		return mtfId;
	}

	public void setMtfId(Integer mtfId) {
		this.mtfId = mtfId;
	}

	public String getMtfCodcampo() {
		return this.mtfCodcampo;
	}
	public void setMtfCodcampo(String mtfCodcampo) {
		this.mtfCodcampo = mtfCodcampo;
	}
	public String getMtfCodmt() {
		return this.mtfCodmt;
	}
	public void setMtfCodmt(String mtfCodmt) {
		this.mtfCodmt = mtfCodmt;
	}
	public Integer getMtfNro() {
		return this.mtfNro;
	}
	public void setMtfNro(Integer mtfNro) {
		this.mtfNro = mtfNro;
	}
	
	public Integer getMtfGrpopt() {
		return mtfGrpopt;
	}
	public void setMtfGrpopt(Integer mtfGrpopt) {
		this.mtfGrpopt = mtfGrpopt;
	}
	
	public String getMtfDescrip() {
		return this.mtfDescrip;
	}

	public void setMtfDescrip(String mtfDescrip) {
		this.mtfDescrip = mtfDescrip;
	}

	public String getMtfReglavalid() {
		return this.mtfReglavalid;
	}

	public void setMtfReglavalid(String mtfReglavalid) {
		this.mtfReglavalid = mtfReglavalid;
	}

	public String getMtfStatus() {
		return this.mtfStatus;
	}

	public void setMtfStatus(String mtfStatus) {
		this.mtfStatus = mtfStatus;
	}

	public String getMtfTipocampo() {
		return mtfTipocampo;
	}

	public void setMtfTipocampo(String mtfTipocampo) {
		this.mtfTipocampo = mtfTipocampo;
	}

	public String getMtfCondicion() {
		return mtfCondicion;
	}

	public void setMtfCondicion(String mtfCondicion) {
		this.mtfCondicion = mtfCondicion;
	}

	public String getMtfExpresion() {
		return mtfExpresion;
	}

	public void setMtfExpresion(String mtfExpresion) {
		this.mtfExpresion = mtfExpresion;
	}

	public String getMtfSecpadre() {
		return mtfSecpadre;
	}

	public void setMtfSecpadre(String mtfSecpadre) {
		this.mtfSecpadre = mtfSecpadre;
	}

	public String getMtfBloque() {
		return mtfBloque;
	}

	public void setMtfBloque(String mtfBloque) {
		this.mtfBloque = mtfBloque;
	}

	public String getMtfFormato() {
		return mtfFormato;
	}

	public void setMtfFormato(String mtfFormato) {
		this.mtfFormato = mtfFormato;
	}

	public String getMtfReglaswf() {
		return mtfReglaswf;
	}

	public void setMtfReglaswf(String mtfReglaswf) {
		this.mtfReglaswf = mtfReglaswf;
	}

	public String getMtfDatoadic() {
		return mtfDatoadic;
	}

	public void setMtfDatoadic(String mtfDatoadic) {
		this.mtfDatoadic = mtfDatoadic;
	}

	public String getMtfDefault() {
		return mtfDefault;
	}

	public void setMtfDefault(String mtfDefault) {
		this.mtfDefault = mtfDefault;
	}

	public String getMtfNemo() {
		return mtfNemo;
	}

	public void setMtfNemo(String mtfNemo) {
		this.mtfNemo = mtfNemo;
	}

	public String getMtfEstado() {
		return mtfEstado;
	}

	public void setMtfEstado(String mtfEstado) {
		this.mtfEstado = mtfEstado;
	}

	public String getMtfIndexiso() {
		return mtfIndexiso;
	}

	public void setMtfIndexiso(String mtfIndexiso) {
		this.mtfIndexiso = mtfIndexiso;
	}

	public Integer getMtfNivel() {
		return mtfNivel;
	}

	public void setMtfNivel(Integer mtfNivel) {
		this.mtfNivel = mtfNivel;
	}

	public String getMtfXmltag() {
		return mtfXmltag;
	}

	public void setMtfXmltag(String mtfXmltag) {
		this.mtfXmltag = mtfXmltag;
	}

	public String getMtfCardinal() {
		return mtfCardinal;
	}

	public void setMtfCardinal(String mtfCardinal) {
		this.mtfCardinal = mtfCardinal;
	}

	public String getMtfCambiavalor() {
		return mtfCambiavalor;
	}

	public void setMtfCambiavalor(String mtfCambiavalor) {
		this.mtfCambiavalor = mtfCambiavalor;
	}

	public String getMtfMinimo() {
		return mtfMinimo;
	}

	public void setMtfMinimo(String mtfMinimo) {
		this.mtfMinimo = mtfMinimo;
	}

	public String getMtfValidacionerror() {
		return mtfValidacionerror;
	}

	public void setMtfValidacionerror(String mtfValidacionerror) {
		this.mtfValidacionerror = mtfValidacionerror;
	}

	public String getMtfCambiatipousr() {
		return mtfCambiatipousr;
	}

	public void setMtfCambiatipousr(String mtfCambiatipousr) {
		this.mtfCambiatipousr = mtfCambiatipousr;
	}

	public String getMtfCardinalmult() {
		return mtfCardinalmult;
	}

	public void setMtfCardinalmult(String mtfCardinalmult) {
		this.mtfCardinalmult = mtfCardinalmult;
	}

	public String getMtfSinonimos() {
		return mtfSinonimos;
	}

	public void setMtfSinonimos(String mtfSinonimos) {
		this.mtfSinonimos = mtfSinonimos;
	}

	public String getMtfConvalornoreq() {
		return mtfConvalornoreq;
	}

	public void setMtfConvalornoreq(String mtfConvalornoreq) {
		this.mtfConvalornoreq = mtfConvalornoreq;
	}

	public String getMtfEsopcional() {
		return mtfEsopcional;
	}

	public void setMtfEsopcional(String mtfEsopcional) {
		this.mtfEsopcional = mtfEsopcional;
	}

	public String getMtfEsadicional() {
		return mtfEsadicional;
	}

	public void setMtfEsadicional(String mtfEsadicional) {
		this.mtfEsadicional = mtfEsadicional;
	}

	public List<String> getMtfSubaction() {
		return mtfSubaction;
	}
	
	public void setMtfSubaction(String subAction) {
		mtfSubaction.add(subAction);
	}
	
	public String toStringID() {
		return "[" + mtfCodmt+ "." + mtfGrpopt + "." + mtfNro + "." + mtfCodcampo + "]";
	}

	public String getMtfSubaction1() {
		return mtfSubaction1;
	}

	public void setMtfSubaction1(String mtfSubaction1) {
		this.mtfSubaction1 = mtfSubaction1;
	}

	public String getMtfSubaction2() {
		return mtfSubaction2;
	}

	public void setMtfSubaction2(String mtfSubaction2) {
		this.mtfSubaction2 = mtfSubaction2;
	}

	public String getMtfSubaction3() {
		return mtfSubaction3;
	}

	public void setMtfSubaction3(String mtfSubaction3) {
		this.mtfSubaction3 = mtfSubaction3;
	}

	public String getMtfSubaction4() {
		return mtfSubaction4;
	}

	public void setMtfSubaction4(String mtfSubaction4) {
		this.mtfSubaction4 = mtfSubaction4;
	}

	public String getMtfSubaction5() {
		return mtfSubaction5;
	}

	public void setMtfSubaction5(String mtfSubaction5) {
		this.mtfSubaction5 = mtfSubaction5;
	}

	public static Supplier<SwfMencampos> cloneSwfMencampos(SwfMencampos swfMencamposOld) {
		return () -> {
			if (swfMencamposOld == null) {
				return null;
			}
			
			SwfMencampos swfMencamposNew = new SwfMencampos();
			swfMencamposNew.setMtfId(swfMencamposOld.getMtfId());
			swfMencamposNew.setMtfCodmt(swfMencamposOld.getMtfCodmt());
			swfMencamposNew.setMtfNro(swfMencamposOld.getMtfNro());
			swfMencamposNew.setMtfGrpopt(swfMencamposOld.getMtfGrpopt());
			swfMencamposNew.setMtfCodcampo(swfMencamposOld.getMtfCodcampo());
			swfMencamposNew.setMtfNemo(swfMencamposOld.getMtfNemo());
			swfMencamposNew.setMtfBloque(swfMencamposOld.getMtfBloque());
			swfMencamposNew.setMtfFormato(swfMencamposOld.getMtfFormato());
			swfMencamposNew.setMtfSecpadre(swfMencamposOld.getMtfSecpadre());
			swfMencamposNew.setMtfStatus(swfMencamposOld.getMtfStatus());
			swfMencamposNew.setMtfTipocampo(swfMencamposOld.getMtfTipocampo());
			swfMencamposNew.setMtfIndexiso(swfMencamposOld.getMtfIndexiso());
			swfMencamposNew.setMtfNivel(swfMencamposOld.getMtfNivel());
			swfMencamposNew.setMtfMinimo(swfMencamposOld.getMtfMinimo());
			swfMencamposNew.setMtfSinonimos(swfMencamposOld.getMtfSinonimos());
			swfMencamposNew.setMtfSubaction1(swfMencamposOld.getMtfSubaction1());
			swfMencamposNew.setMtfSubaction2(swfMencamposOld.getMtfSubaction2());
			swfMencamposNew.setMtfSubaction3(swfMencamposOld.getMtfSubaction3());
			swfMencamposNew.setMtfSubaction4(swfMencamposOld.getMtfSubaction4());
			swfMencamposNew.setMtfSubaction5(swfMencamposOld.getMtfSubaction5());
			return swfMencamposNew;
		};
	}

	public static Supplier<SwfMencampos> cloneSwfMencamposLg(SwfMencampos swfMencamposOld) {
		return () -> {
			if (swfMencamposOld == null) {
				return null;
			}
			
			SwfMencampos swfMencamposNew = new SwfMencampos();
			swfMencamposNew.setMtfId(swfMencamposOld.getMtfId());
			swfMencamposNew.setMtfCodmt(swfMencamposOld.getMtfCodmt());
			swfMencamposNew.setMtfNro(swfMencamposOld.getMtfNro());
			swfMencamposNew.setMtfGrpopt(swfMencamposOld.getMtfGrpopt());
			swfMencamposNew.setMtfCodcampo(swfMencamposOld.getMtfCodcampo());
			swfMencamposNew.setMtfNemo(swfMencamposOld.getMtfNemo());
			swfMencamposNew.setMtfBloque(swfMencamposOld.getMtfBloque());
			swfMencamposNew.setMtfCondicion(swfMencamposOld.getMtfCondicion());
			swfMencamposNew.setMtfDatoadic(swfMencamposOld.getMtfDatoadic());
			swfMencamposNew.setMtfDefault(swfMencamposOld.getMtfDefault());
			swfMencamposNew.setMtfDescrip(swfMencamposOld.getMtfDescrip());
			swfMencamposNew.setMtfExpresion(swfMencamposOld.getMtfExpresion());
			swfMencamposNew.setMtfFormato(swfMencamposOld.getMtfFormato());
			swfMencamposNew.setMtfReglaswf(swfMencamposOld.getMtfReglaswf());
			swfMencamposNew.setMtfReglavalid(swfMencamposOld.getMtfReglavalid());
			swfMencamposNew.setMtfSecpadre(swfMencamposOld.getMtfSecpadre());
			swfMencamposNew.setMtfStatus(swfMencamposOld.getMtfStatus());
			swfMencamposNew.setMtfTipocampo(swfMencamposOld.getMtfTipocampo());
			swfMencamposNew.setMtfEstado(swfMencamposOld.getMtfEstado());
			swfMencamposNew.setMtfIndexiso(swfMencamposOld.getMtfIndexiso());
			swfMencamposNew.setMtfNivel(swfMencamposOld.getMtfNivel());
			swfMencamposNew.setMtfXmltag(swfMencamposOld.getMtfXmltag());
			swfMencamposNew.setMtfCardinal(swfMencamposOld.getMtfCardinal());
			swfMencamposNew.setMtfCambiavalor(swfMencamposOld.getMtfCambiavalor());
			swfMencamposNew.setMtfMinimo(swfMencamposOld.getMtfMinimo());
			swfMencamposNew.setMtfValidacionerror(swfMencamposOld.getMtfValidacionerror());
			swfMencamposNew.setMtfCambiatipousr(swfMencamposOld.getMtfCambiatipousr());
			swfMencamposNew.setMtfCardinalmult(swfMencamposOld.getMtfCardinalmult());
			swfMencamposNew.setMtfSinonimos(swfMencamposOld.getMtfSinonimos());
			swfMencamposNew.setMtfConvalornoreq(swfMencamposOld.getMtfConvalornoreq());
			swfMencamposNew.setMtfEsopcional(swfMencamposOld.getMtfEsopcional());
			swfMencamposNew.setMtfEsadicional(swfMencamposOld.getMtfEsadicional());
//			swfMencamposNew.setMtfSubaction(swfMencamposOld.getMtfSubaction());
			swfMencamposNew.setMtfSubaction1(swfMencamposOld.getMtfSubaction1());
			swfMencamposNew.setMtfSubaction2(swfMencamposOld.getMtfSubaction2());
			swfMencamposNew.setMtfSubaction3(swfMencamposOld.getMtfSubaction3());
			swfMencamposNew.setMtfSubaction4(swfMencamposOld.getMtfSubaction4());
			swfMencamposNew.setMtfSubaction5(swfMencamposOld.getMtfSubaction5());			
			return swfMencamposNew;
		};
	}
	
}