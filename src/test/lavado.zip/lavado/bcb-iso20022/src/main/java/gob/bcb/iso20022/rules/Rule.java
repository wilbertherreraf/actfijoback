package gob.bcb.iso20022.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class Rule implements Comparable<Rule> {

	private String id;
	private String name;
	private String expression;
	private String outcome;
	private int priority = 1;
	private String namespace;
	private String description;
	private String action;
	private String path;
	private List<Action> actions = new ArrayList<>();
	private List<String> facts = new ArrayList<>();

	public Rule() {

	}

	public Rule(final String id, final String name, final String expression, final String outcome, final int priority, final String namespace,
			final String description, String action, String path) {
		if (name == null)
			throw new AssertionError("name may not be null");
		// if(expression == null) throw new AssertionError("expression may not be
		// null");
		if (namespace == null)
			throw new AssertionError("namespace may not be null");
		this.id = id;
		this.name = name;
		this.expression = expression;
		this.outcome = outcome;
		this.priority = priority;
		this.namespace = namespace;
		this.description = description;
		this.action = action;
		this.path = path;
	}

	public Rule(String id, final String name, final String expression, final String outcome, final int priority, final String namespace,
			final String description, String action) {
		this(id, name, expression, outcome, priority, namespace, description, action, null);
	}

	public Rule(final String name, final String expression, final String outcome, final int priority, final String namespace, final String description,
			String action) {
		this(name + "." + namespace, name, expression, outcome, priority, namespace, description, action);
	}

	public Rule(final String name, final String expression, final String outcome, final int priority, final String namespace, final String description) {
		this(name, expression, outcome, priority, namespace, null, null);
	}

	public Rule(final String name, final String expression, final String outcome, final int priority, final String namespace) {
		this(name, expression, outcome, priority, namespace, null);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getExpression() {
		return expression;
	}

	public String getOutcome() {
		return outcome;
	}

	public int getPriority() {
		return priority;
	}

	public String getNamespace() {
		return namespace;
	}

	public String getDescription() {
		return description;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public List<Action> getActions() {
		return actions;
	}

	public void setActions(List<Action> actions) {
		this.actions = actions;
	}

	public List<String> getFacts() {
		return facts;
	}

	public void setFacts(List<String> facts) {
		this.facts = facts;
	}

	/**
	 * @return the {@link #namespace} concatenated with the {@link #name}, separated
	 *         by a '.'
	 */
	public String getFullyQualifiedName() {
		return namespace + "." + name;
	}

	public void setExpression(String expression) {
		this.expression = expression;
	}

	public void setOutcome(String outcome) {
		this.outcome = outcome;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Rule build() {
		return this;
	}

	public Rule addActions(final Map<String, String> actions) {
		for (final Map.Entry<String, String> entry : actions.entrySet()) {
			addAction(entry.getKey(), entry.getValue());
		}
		return this;
	}

	public Rule addAction(String key, String value) {
		if (!StringUtils.isBlank(value)) {
			final Action action = new Action();
			action.setAttribute(key);
			action.setValue(value);
			getActions().add(action);
		}
		return this;
	}

	@Override
	public int compareTo(Rule r) {
		// reversed, since we want highest priority first in the list!
		return (this.priority < r.priority ? 1 : (this.priority == r.priority ? 0 : -1));
	}

	@Override
	public Rule clone() {
		Rule rule = new Rule(id, name, expression, outcome, priority, namespace, description, action, path);

		if (actions != null) {
			final List<Action> actionList = new ArrayList<>();
			rule.setActions(actionList);
			actions.forEach(action -> actionList.add((Action) action.clone()));
		}
		if (facts != null) {
			final List<String> factList = new ArrayList<>();
			rule.setFacts(factList);
			factList.addAll(facts);
		}
		return rule;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((expression == null) ? 0 : expression.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((namespace == null) ? 0 : namespace.hashCode());
		result = prime * result + ((outcome == null) ? 0 : outcome.hashCode());
		result = prime * result + priority;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rule other = (Rule) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (expression == null) {
			if (other.expression != null)
				return false;
		} else if (!expression.equals(other.expression))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (namespace == null) {
			if (other.namespace != null)
				return false;
		} else if (!namespace.equals(other.namespace))
			return false;
		if (outcome == null) {
			if (other.outcome != null)
				return false;
		} else if (!outcome.equals(other.outcome))
			return false;
		if (priority != other.priority)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Rule [name=" + name + ", expression=" + expression + ", outcome=" + outcome + ", priority=" + priority + ", namespace=" + namespace
				+ ", description=" + description + "]";
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}
