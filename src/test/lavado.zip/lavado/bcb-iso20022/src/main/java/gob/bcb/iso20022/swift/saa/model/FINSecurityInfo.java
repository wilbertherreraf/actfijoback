
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para FINSecurityInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="FINSecurityInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ChecksumResult" type="{urn:swift:saa:xsd:saa.2.0}ChecksumResult" minOccurs="0"/&gt;
 *         &lt;element name="ChecksumValue" type="{urn:swift:saa:xsd:saa.2.0}ChecksumValue" minOccurs="0"/&gt;
 *         &lt;element name="PACResult" type="{urn:swift:saa:xsd:saa.2.0}MACPACResult" minOccurs="0"/&gt;
 *         &lt;element name="PACValue" type="{urn:swift:saa:xsd:saa.2.0}MACPACValue" minOccurs="0"/&gt;
 *         &lt;element name="MACResult" type="{urn:swift:saa:xsd:saa.2.0}MACPACResult" minOccurs="0"/&gt;
 *         &lt;element name="MACValue" type="{urn:swift:saa:xsd:saa.2.0}MACPACValue" minOccurs="0"/&gt;
 *         &lt;element name="MACSignatureValue" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="PAC2SignatureValue" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FINSecurityInfo", propOrder = {
    "checksumResult",
    "checksumValue",
    "pacResult",
    "pacValue",
    "macResult",
    "macValue",
    "macSignatureValue",
    "pac2SignatureValue"
})
public class FINSecurityInfo {

    @XmlElement(name = "ChecksumResult")
    @XmlSchemaType(name = "string")
    protected ChecksumResult checksumResult;
    @XmlElement(name = "ChecksumValue")
    protected String checksumValue;
    @XmlElement(name = "PACResult")
    @XmlSchemaType(name = "string")
    protected MACPACResult pacResult;
    @XmlElement(name = "PACValue")
    protected String pacValue;
    @XmlElement(name = "MACResult")
    @XmlSchemaType(name = "string")
    protected MACPACResult macResult;
    @XmlElement(name = "MACValue")
    protected String macValue;
    @XmlElement(name = "MACSignatureValue")
    protected SwAny macSignatureValue;
    @XmlElement(name = "PAC2SignatureValue")
    protected SwAny pac2SignatureValue;

    /**
     * Obtiene el valor de la propiedad checksumResult.
     * 
     * @return
     *     possible object is
     *     {@link ChecksumResult }
     *     
     */
    public ChecksumResult getChecksumResult() {
        return checksumResult;
    }

    /**
     * Define el valor de la propiedad checksumResult.
     * 
     * @param value
     *     allowed object is
     *     {@link ChecksumResult }
     *     
     */
    public void setChecksumResult(ChecksumResult value) {
        this.checksumResult = value;
    }

    /**
     * Obtiene el valor de la propiedad checksumValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChecksumValue() {
        return checksumValue;
    }

    /**
     * Define el valor de la propiedad checksumValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChecksumValue(String value) {
        this.checksumValue = value;
    }

    /**
     * Obtiene el valor de la propiedad pacResult.
     * 
     * @return
     *     possible object is
     *     {@link MACPACResult }
     *     
     */
    public MACPACResult getPACResult() {
        return pacResult;
    }

    /**
     * Define el valor de la propiedad pacResult.
     * 
     * @param value
     *     allowed object is
     *     {@link MACPACResult }
     *     
     */
    public void setPACResult(MACPACResult value) {
        this.pacResult = value;
    }

    /**
     * Obtiene el valor de la propiedad pacValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPACValue() {
        return pacValue;
    }

    /**
     * Define el valor de la propiedad pacValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPACValue(String value) {
        this.pacValue = value;
    }

    /**
     * Obtiene el valor de la propiedad macResult.
     * 
     * @return
     *     possible object is
     *     {@link MACPACResult }
     *     
     */
    public MACPACResult getMACResult() {
        return macResult;
    }

    /**
     * Define el valor de la propiedad macResult.
     * 
     * @param value
     *     allowed object is
     *     {@link MACPACResult }
     *     
     */
    public void setMACResult(MACPACResult value) {
        this.macResult = value;
    }

    /**
     * Obtiene el valor de la propiedad macValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMACValue() {
        return macValue;
    }

    /**
     * Define el valor de la propiedad macValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMACValue(String value) {
        this.macValue = value;
    }

    /**
     * Obtiene el valor de la propiedad macSignatureValue.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getMACSignatureValue() {
        return macSignatureValue;
    }

    /**
     * Define el valor de la propiedad macSignatureValue.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setMACSignatureValue(SwAny value) {
        this.macSignatureValue = value;
    }

    /**
     * Obtiene el valor de la propiedad pac2SignatureValue.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getPAC2SignatureValue() {
        return pac2SignatureValue;
    }

    /**
     * Define el valor de la propiedad pac2SignatureValue.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setPAC2SignatureValue(SwAny value) {
        this.pac2SignatureValue = value;
    }

}
