
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para SWIFTNetSecurityInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="SWIFTNetSecurityInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IsNRRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="SignerDN" type="{urn:swift:saa:xsd:saa.2.0}DN" minOccurs="0"/&gt;
 *         &lt;element name="NRType" type="{urn:swift:saa:xsd:saa.2.0}NRType" minOccurs="0"/&gt;
 *         &lt;element name="NRWarning" type="{urn:swift:saa:xsd:saa.2.0}NRWarning" minOccurs="0"/&gt;
 *         &lt;element name="SignatureResult" type="{urn:swift:saa:xsd:saa.2.0}SignatureResult" minOccurs="0"/&gt;
 *         &lt;element name="SignatureValue" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="ResponseNRType" type="{urn:swift:saa:xsd:saa.2.0}NRType" minOccurs="0"/&gt;
 *         &lt;element name="ResponseNRWarning" type="{urn:swift:saa:xsd:saa.2.0}NRWarning" minOccurs="0"/&gt;
 *         &lt;element name="ResponseSignatureResult" type="{urn:swift:saa:xsd:saa.2.0}SignatureResult" minOccurs="0"/&gt;
 *         &lt;element name="ResponseSignatureValue" type="{urn:swift:saa:xsd:saa.2.0}SwAny" minOccurs="0"/&gt;
 *         &lt;element name="FileDigestAlgorithm" type="{urn:swift:saa:xsd:saa.2.0}FileDigestAlgorithm" minOccurs="0"/&gt;
 *         &lt;element name="FileDigestValue" type="{urn:swift:saa:xsd:saa.2.0}FileDigestValue" minOccurs="0"/&gt;
 *         &lt;element name="DigestList" type="{urn:swift:saa:xsd:saa.2.0}DigestList" minOccurs="0"/&gt;
 *         &lt;element name="ThirdPartySignerDN" type="{urn:swift:saa:xsd:saa.2.0}DN" minOccurs="0"/&gt;
 *         &lt;element name="PartialCopyResult" type="{urn:swift:saa:xsd:saa.2.0}SignatureResult" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SWIFTNetSecurityInfo", propOrder = {
    "isNRRequested",
    "signerDN",
    "nrType",
    "nrWarning",
    "signatureResult",
    "signatureValue",
    "responseNRType",
    "responseNRWarning",
    "responseSignatureResult",
    "responseSignatureValue",
    "fileDigestAlgorithm",
    "fileDigestValue",
    "digestList",
    "thirdPartySignerDN",
    "partialCopyResult"
})
public class SWIFTNetSecurityInfo {

    @XmlElement(name = "IsNRRequested")
    protected Boolean isNRRequested;
    @XmlElement(name = "SignerDN")
    protected String signerDN;
    @XmlElement(name = "NRType")
    @XmlSchemaType(name = "string")
    protected NRType nrType;
    @XmlElement(name = "NRWarning")
    protected String nrWarning;
    @XmlElement(name = "SignatureResult")
    @XmlSchemaType(name = "string")
    protected SignatureResult signatureResult;
    @XmlElement(name = "SignatureValue")
    protected SwAny signatureValue;
    @XmlElement(name = "ResponseNRType")
    @XmlSchemaType(name = "string")
    protected NRType responseNRType;
    @XmlElement(name = "ResponseNRWarning")
    protected String responseNRWarning;
    @XmlElement(name = "ResponseSignatureResult")
    @XmlSchemaType(name = "string")
    protected SignatureResult responseSignatureResult;
    @XmlElement(name = "ResponseSignatureValue")
    protected SwAny responseSignatureValue;
    @XmlElement(name = "FileDigestAlgorithm")
    @XmlSchemaType(name = "string")
    protected FileDigestAlgorithm fileDigestAlgorithm;
    @XmlElement(name = "FileDigestValue")
    protected String fileDigestValue;
    @XmlElement(name = "DigestList")
    protected DigestList digestList;
    @XmlElement(name = "ThirdPartySignerDN")
    protected String thirdPartySignerDN;
    @XmlElement(name = "PartialCopyResult")
    @XmlSchemaType(name = "string")
    protected SignatureResult partialCopyResult;

    /**
     * Obtiene el valor de la propiedad isNRRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsNRRequested() {
        return isNRRequested;
    }

    /**
     * Define el valor de la propiedad isNRRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsNRRequested(Boolean value) {
        this.isNRRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad signerDN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignerDN() {
        return signerDN;
    }

    /**
     * Define el valor de la propiedad signerDN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignerDN(String value) {
        this.signerDN = value;
    }

    /**
     * Obtiene el valor de la propiedad nrType.
     * 
     * @return
     *     possible object is
     *     {@link NRType }
     *     
     */
    public NRType getNRType() {
        return nrType;
    }

    /**
     * Define el valor de la propiedad nrType.
     * 
     * @param value
     *     allowed object is
     *     {@link NRType }
     *     
     */
    public void setNRType(NRType value) {
        this.nrType = value;
    }

    /**
     * Obtiene el valor de la propiedad nrWarning.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNRWarning() {
        return nrWarning;
    }

    /**
     * Define el valor de la propiedad nrWarning.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNRWarning(String value) {
        this.nrWarning = value;
    }

    /**
     * Obtiene el valor de la propiedad signatureResult.
     * 
     * @return
     *     possible object is
     *     {@link SignatureResult }
     *     
     */
    public SignatureResult getSignatureResult() {
        return signatureResult;
    }

    /**
     * Define el valor de la propiedad signatureResult.
     * 
     * @param value
     *     allowed object is
     *     {@link SignatureResult }
     *     
     */
    public void setSignatureResult(SignatureResult value) {
        this.signatureResult = value;
    }

    /**
     * Obtiene el valor de la propiedad signatureValue.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getSignatureValue() {
        return signatureValue;
    }

    /**
     * Define el valor de la propiedad signatureValue.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setSignatureValue(SwAny value) {
        this.signatureValue = value;
    }

    /**
     * Obtiene el valor de la propiedad responseNRType.
     * 
     * @return
     *     possible object is
     *     {@link NRType }
     *     
     */
    public NRType getResponseNRType() {
        return responseNRType;
    }

    /**
     * Define el valor de la propiedad responseNRType.
     * 
     * @param value
     *     allowed object is
     *     {@link NRType }
     *     
     */
    public void setResponseNRType(NRType value) {
        this.responseNRType = value;
    }

    /**
     * Obtiene el valor de la propiedad responseNRWarning.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseNRWarning() {
        return responseNRWarning;
    }

    /**
     * Define el valor de la propiedad responseNRWarning.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseNRWarning(String value) {
        this.responseNRWarning = value;
    }

    /**
     * Obtiene el valor de la propiedad responseSignatureResult.
     * 
     * @return
     *     possible object is
     *     {@link SignatureResult }
     *     
     */
    public SignatureResult getResponseSignatureResult() {
        return responseSignatureResult;
    }

    /**
     * Define el valor de la propiedad responseSignatureResult.
     * 
     * @param value
     *     allowed object is
     *     {@link SignatureResult }
     *     
     */
    public void setResponseSignatureResult(SignatureResult value) {
        this.responseSignatureResult = value;
    }

    /**
     * Obtiene el valor de la propiedad responseSignatureValue.
     * 
     * @return
     *     possible object is
     *     {@link SwAny }
     *     
     */
    public SwAny getResponseSignatureValue() {
        return responseSignatureValue;
    }

    /**
     * Define el valor de la propiedad responseSignatureValue.
     * 
     * @param value
     *     allowed object is
     *     {@link SwAny }
     *     
     */
    public void setResponseSignatureValue(SwAny value) {
        this.responseSignatureValue = value;
    }

    /**
     * Obtiene el valor de la propiedad fileDigestAlgorithm.
     * 
     * @return
     *     possible object is
     *     {@link FileDigestAlgorithm }
     *     
     */
    public FileDigestAlgorithm getFileDigestAlgorithm() {
        return fileDigestAlgorithm;
    }

    /**
     * Define el valor de la propiedad fileDigestAlgorithm.
     * 
     * @param value
     *     allowed object is
     *     {@link FileDigestAlgorithm }
     *     
     */
    public void setFileDigestAlgorithm(FileDigestAlgorithm value) {
        this.fileDigestAlgorithm = value;
    }

    /**
     * Obtiene el valor de la propiedad fileDigestValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileDigestValue() {
        return fileDigestValue;
    }

    /**
     * Define el valor de la propiedad fileDigestValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileDigestValue(String value) {
        this.fileDigestValue = value;
    }

    /**
     * Obtiene el valor de la propiedad digestList.
     * 
     * @return
     *     possible object is
     *     {@link DigestList }
     *     
     */
    public DigestList getDigestList() {
        return digestList;
    }

    /**
     * Define el valor de la propiedad digestList.
     * 
     * @param value
     *     allowed object is
     *     {@link DigestList }
     *     
     */
    public void setDigestList(DigestList value) {
        this.digestList = value;
    }

    /**
     * Obtiene el valor de la propiedad thirdPartySignerDN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThirdPartySignerDN() {
        return thirdPartySignerDN;
    }

    /**
     * Define el valor de la propiedad thirdPartySignerDN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThirdPartySignerDN(String value) {
        this.thirdPartySignerDN = value;
    }

    /**
     * Obtiene el valor de la propiedad partialCopyResult.
     * 
     * @return
     *     possible object is
     *     {@link SignatureResult }
     *     
     */
    public SignatureResult getPartialCopyResult() {
        return partialCopyResult;
    }

    /**
     * Define el valor de la propiedad partialCopyResult.
     * 
     * @param value
     *     allowed object is
     *     {@link SignatureResult }
     *     
     */
    public void setPartialCopyResult(SignatureResult value) {
        this.partialCopyResult = value;
    }

}
