
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the gob2.bcb.iso20022.swift.saa.model package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PDEPDMPDE_QNAME = new QName("urn:swift:saa:xsd:saa.2.0", "PDE");
    private final static QName _PDEPDMPDM_QNAME = new QName("urn:swift:saa:xsd:saa.2.0", "PDM");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: gob2.bcb.iso20022.swift.saa.model
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DataPDU }
     * 
     */
    public DataPDU createDataPDU() {
        return new DataPDU();
    }

    /**
     * Create an instance of {@link Header }
     * 
     */
    public Header createHeader() {
        return new Header();
    }

    /**
     * Create an instance of {@link SwAny }
     * 
     */
    public SwAny createSwAny() {
        return new SwAny();
    }

    /**
     * Create an instance of {@link AddressFullName }
     * 
     */
    public AddressFullName createAddressFullName() {
        return new AddressFullName();
    }

    /**
     * Create an instance of {@link AddressInfo }
     * 
     */
    public AddressInfo createAddressInfo() {
        return new AddressInfo();
    }

    /**
     * Create an instance of {@link Intervention }
     * 
     */
    public Intervention createIntervention() {
        return new Intervention();
    }

    /**
     * Create an instance of {@link HistoryIntervention }
     * 
     */
    public HistoryIntervention createHistoryIntervention() {
        return new HistoryIntervention();
    }

    /**
     * Create an instance of {@link Interventions }
     * 
     */
    public Interventions createInterventions() {
        return new Interventions();
    }

    /**
     * Create an instance of {@link HistoryInterventions }
     * 
     */
    public HistoryInterventions createHistoryInterventions() {
        return new HistoryInterventions();
    }

    /**
     * Create an instance of {@link RoutingInstruction }
     * 
     */
    public RoutingInstruction createRoutingInstruction() {
        return new RoutingInstruction();
    }

    /**
     * Create an instance of {@link PDEPDM }
     * 
     */
    public PDEPDM createPDEPDM() {
        return new PDEPDM();
    }

    /**
     * Create an instance of {@link Product }
     * 
     */
    public Product createProduct() {
        return new Product();
    }

    /**
     * Create an instance of {@link ProductList }
     * 
     */
    public ProductList createProductList() {
        return new ProductList();
    }

    /**
     * Create an instance of {@link Digest }
     * 
     */
    public Digest createDigest() {
        return new Digest();
    }

    /**
     * Create an instance of {@link DigestList }
     * 
     */
    public DigestList createDigestList() {
        return new DigestList();
    }

    /**
     * Create an instance of {@link MessageProperty }
     * 
     */
    public MessageProperty createMessageProperty() {
        return new MessageProperty();
    }

    /**
     * Create an instance of {@link MessagePropertyList }
     * 
     */
    public MessagePropertyList createMessagePropertyList() {
        return new MessagePropertyList();
    }

    /**
     * Create an instance of {@link InterfaceInfo }
     * 
     */
    public InterfaceInfo createInterfaceInfo() {
        return new InterfaceInfo();
    }

    /**
     * Create an instance of {@link NetworkInfo }
     * 
     */
    public NetworkInfo createNetworkInfo() {
        return new NetworkInfo();
    }

    /**
     * Create an instance of {@link TransactionData }
     * 
     */
    public TransactionData createTransactionData() {
        return new TransactionData();
    }

    /**
     * Create an instance of {@link FINNetworkInfo }
     * 
     */
    public FINNetworkInfo createFINNetworkInfo() {
        return new FINNetworkInfo();
    }

    /**
     * Create an instance of {@link PayloadAttribute }
     * 
     */
    public PayloadAttribute createPayloadAttribute() {
        return new PayloadAttribute();
    }

    /**
     * Create an instance of {@link PayloadAttributeList }
     * 
     */
    public PayloadAttributeList createPayloadAttributeList() {
        return new PayloadAttributeList();
    }

    /**
     * Create an instance of {@link RecipientListType }
     * 
     */
    public RecipientListType createRecipientListType() {
        return new RecipientListType();
    }

    /**
     * Create an instance of {@link ThirdPartyListType }
     * 
     */
    public ThirdPartyListType createThirdPartyListType() {
        return new ThirdPartyListType();
    }

    /**
     * Create an instance of {@link DistributionInfo }
     * 
     */
    public DistributionInfo createDistributionInfo() {
        return new DistributionInfo();
    }

    /**
     * Create an instance of {@link SWIFTNetNetworkInfo }
     * 
     */
    public SWIFTNetNetworkInfo createSWIFTNetNetworkInfo() {
        return new SWIFTNetNetworkInfo();
    }

    /**
     * Create an instance of {@link SecurityInfo }
     * 
     */
    public SecurityInfo createSecurityInfo() {
        return new SecurityInfo();
    }

    /**
     * Create an instance of {@link FINSecurityInfo }
     * 
     */
    public FINSecurityInfo createFINSecurityInfo() {
        return new FINSecurityInfo();
    }

    /**
     * Create an instance of {@link SWIFTNetSecurityInfo }
     * 
     */
    public SWIFTNetSecurityInfo createSWIFTNetSecurityInfo() {
        return new SWIFTNetSecurityInfo();
    }

    /**
     * Create an instance of {@link SAAInfo }
     * 
     */
    public SAAInfo createSAAInfo() {
        return new SAAInfo();
    }

    /**
     * Create an instance of {@link DeliveryNotification }
     * 
     */
    public DeliveryNotification createDeliveryNotification() {
        return new DeliveryNotification();
    }

    /**
     * Create an instance of {@link Message }
     * 
     */
    public Message createMessage() {
        return new Message();
    }

    /**
     * Create an instance of {@link HistoryReport }
     * 
     */
    public HistoryReport createHistoryReport() {
        return new HistoryReport();
    }

    /**
     * Create an instance of {@link TransmissionReport }
     * 
     */
    public TransmissionReport createTransmissionReport() {
        return new TransmissionReport();
    }

    /**
     * Create an instance of {@link DeliveryReport }
     * 
     */
    public DeliveryReport createDeliveryReport() {
        return new DeliveryReport();
    }

    /**
     * Create an instance of {@link MessageStatus }
     * 
     */
    public MessageStatus createMessageStatus() {
        return new MessageStatus();
    }

    /**
     * Create an instance of {@link SessionStatus }
     * 
     */
    public SessionStatus createSessionStatus() {
        return new SessionStatus();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn:swift:saa:xsd:saa.2.0", name = "PDE", scope = PDEPDM.class)
    public JAXBElement<String> createPDEPDMPDE(String value) {
        return new JAXBElement<String>(_PDEPDMPDE_QNAME, String.class, PDEPDM.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "urn:swift:saa:xsd:saa.2.0", name = "PDM", scope = PDEPDM.class)
    public JAXBElement<String> createPDEPDMPDM(String value) {
        return new JAXBElement<String>(_PDEPDMPDM_QNAME, String.class, PDEPDM.class, value);
    }

}
