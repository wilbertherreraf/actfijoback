package gob.bcb.iso20022.exceptions;

public class DuplicateNameException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public DuplicateNameException(String msg) {
		super(msg);
	}

}
