package gob.bcb.iso20022.model;

public interface IOperacionDatos {

}
