package gob.bcb.iso20022.excel.core.factory;

import static gob.bcb.iso20022.excel.enums.FileTypeEnum.XLS;
import static gob.bcb.iso20022.excel.enums.FileTypeEnum.XLSX;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import gob.bcb.iso20022.excel.enums.FileTypeEnum;
import gob.bcb.iso20022.excel.exception.ExcelManipulationException;

public class ExcelFactory {

    /**
    *
     * @param path
     * @return
     */
    public static Workbook writeInstance(String path) {
        if (path.endsWith(XLSX.getFileType()) ) {
            return new XSSFWorkbook();
        } else if (path.endsWith(XLS.getFileType())) {
            return new HSSFWorkbook();
        } else {
            throw new ExcelManipulationException("file type is not supported");
        }
    }

    /**
     *
     * @param inputStream
     * @param path
     * @return
     */
    public static Workbook readInstance(InputStream inputStream, String path) {
    	boolean isXlsx = StringUtils.isBlank(path) || (!StringUtils.isBlank(path) && path.toLowerCase().endsWith(XLSX.getFileType()));
    	boolean isXls = !isXlsx && !StringUtils.isBlank(path) && path.toLowerCase().endsWith(XLS.getFileType());
    	FileTypeEnum fileTypeEnum = null;
    	if (isXls)
    		fileTypeEnum = FileTypeEnum.XLS;
    	else if (isXlsx) 
    		fileTypeEnum = FileTypeEnum.XLSX;
    	
    	return readInstance(inputStream, fileTypeEnum, path);
    }
    
    public static Workbook readInstance(InputStream inputStream, FileTypeEnum fileTypeEnum) {
    	return readInstance(inputStream, fileTypeEnum, "");
    }
    
    public static Workbook readInstance(InputStream inputStream, FileTypeEnum fileTypeEnum, String path) {
    	boolean isXls = fileTypeEnum == null && !StringUtils.isBlank(path) && path.toLowerCase().endsWith(XLS.getFileType());
    	if (isXls)
    		fileTypeEnum = FileTypeEnum.XLS;
    	fileTypeEnum = fileTypeEnum != null ? fileTypeEnum : FileTypeEnum.XLSX;  
        try (InputStream file = inputStream != null ? inputStream : new FileInputStream(new File(path))){
        	if (fileTypeEnum == FileTypeEnum.XLSX) {
            	//InputStream file = new FileInputStream(new File(path));
                return new XSSFWorkbook(file);
        	} else if (fileTypeEnum == FileTypeEnum.XLS) {
                return new HSSFWorkbook(file);
            } else {
                throw new ExcelManipulationException("file type is not supported");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
