package gob.bcb.iso20022.excel.core.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import gob.bcb.iso20022.excel.constant.ExcelConstant;
import gob.bcb.iso20022.excel.enums.FieldTypeEnum;

public class HeaderDataBuilder {

    private final List<HeaderData> headerContent= new ArrayList<>();
    private String nameSheet;
    private Integer firstRowData = 1;
    private Map<Integer, String> mRowField = new HashMap<>();
    
    private HeaderDataBuilder(String nameSheet) {
    	this.nameSheet = nameSheet;
    }

    private HeaderDataBuilder() {
    	this(ExcelConstant.DEFAULT_SHEET_NAME);
    }

    public static HeaderDataBuilder instance() {
        HeaderDataBuilder builder = new HeaderDataBuilder();
        return builder;
    }

    public static HeaderDataBuilder instance(String nameSheet) {
        HeaderDataBuilder builder = new HeaderDataBuilder(nameSheet);
        return builder;
    }
    
    public HeaderDataBuilder fill(String name, FieldTypeEnum fileTypeEnum, Integer colPosition) {
    	if (StringUtils.isBlank(name))
    		name = "COL_" + colPosition.toString();
        HeaderData headerData = new HeaderData(name, fileTypeEnum, colPosition);
        headerData.setFirstRowData(firstRowData);
        headerContent.add(headerData);
        return this;
    }
    
    public HeaderDataBuilder fill(String name, FieldTypeEnum fileTypeEnum) {
        return fill(name, fileTypeEnum, headerContent.size());
    }
    
    public HeaderDataBuilder fill(String name) {
        return fill(name, FieldTypeEnum.STRING);
    }


    public List<HeaderData> build() {
        return headerContent;
    }

	public String getNameSheet() {
		return nameSheet;
	}

	public List<HeaderData> getHeaderContent() {
		return headerContent;
	}

	public HeaderDataBuilder firstRowData(Integer firstRowData) {
		this.firstRowData = firstRowData;
		headerContent.forEach(h -> {
			h.setFirstRowData(firstRowData);
		});
		return this;
	}

	public HeaderDataBuilder nameSheet(String nameSheet) {
		this.nameSheet = nameSheet;
		return this;
	}
}
