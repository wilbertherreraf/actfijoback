package gob.bcb.iso20022.translate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.ws.commons.schema.XmlSchema;
import org.apache.ws.commons.schema.XmlSchemaAny;
import org.apache.ws.commons.schema.XmlSchemaAttributeOrGroupRef;
import org.apache.ws.commons.schema.XmlSchemaChoice;
import org.apache.ws.commons.schema.XmlSchemaChoiceMember;
import org.apache.ws.commons.schema.XmlSchemaCollection;
import org.apache.ws.commons.schema.XmlSchemaComplexType;
import org.apache.ws.commons.schema.XmlSchemaContent;
import org.apache.ws.commons.schema.XmlSchemaContentModel;
import org.apache.ws.commons.schema.XmlSchemaElement;
import org.apache.ws.commons.schema.XmlSchemaMaxInclusiveFacet;
import org.apache.ws.commons.schema.XmlSchemaMaxLengthFacet;
import org.apache.ws.commons.schema.XmlSchemaParticle;
import org.apache.ws.commons.schema.XmlSchemaPatternFacet;
import org.apache.ws.commons.schema.XmlSchemaSequence;
import org.apache.ws.commons.schema.XmlSchemaSequenceMember;
import org.apache.ws.commons.schema.XmlSchemaSimpleContent;
import org.apache.ws.commons.schema.XmlSchemaSimpleContentExtension;
import org.apache.ws.commons.schema.XmlSchemaSimpleType;
import org.apache.ws.commons.schema.XmlSchemaSimpleTypeRestriction;
import org.apache.ws.commons.schema.XmlSchemaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.pojo.Node;
import gob.bcb.iso20022.pojo.Tree;

public class UtilsXsd {
	private static final Logger log = LoggerFactory.getLogger(UtilsXsd.class);

	private static XmlSchemaCollection xmlSchemaCollection;
	private static Map<QName, List<XmlSchemaElement>> xsdElements = new HashMap<QName, List<XmlSchemaElement>>();
	private static List<XmlSchemaElement> schemaElements = new ArrayList<XmlSchemaElement>();
	private Integer maxLevel = -1;
	private AtomicInteger ai = new AtomicInteger(0);
	public UtilsXsd() {

	}

	public UtilsXsd(Integer maxLevel) {
		this.maxLevel = maxLevel;
	}

	public Node<SwfMencampos> unmarshallXsd(String nfile, String codMx, LinkedList<SwfMencampos> r) {
		File h = new File(nfile);

		InputStream xsdAsStream;
		try {
			xsdAsStream = new FileInputStream(h.getAbsolutePath());
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}

		XmlSchemaCollection xmlSchemaCollection = new XmlSchemaCollection();
		XmlSchema schema = xmlSchemaCollection.read(new StreamSource(xsdAsStream));
		Map.Entry<QName, XmlSchemaElement> entry = schema.getElements().entrySet().iterator().next();

		XmlSchemaElement childElement = xmlSchemaCollection.getElementByQName(entry.getKey());

		Node<SwfMencampos> root = Node.createNodeDefault(codMx, "8");
		SwfMencampos curr = (SwfMencampos) root.getSwfMencampos();
		curr.setMtfGrpopt(0);
		curr.setMtfNemo("");
		curr.setMtfTipocampo("ROOT");
		curr.setMtfNivel(0);
		curr.setMtfCodcampo(childElement.getName());
		curr.setMtfXmltag("/" + childElement.getName());
		curr.setMtfFormato(childElement.getName());
		curr.setMtfMinimo("1");
		curr.setMtfCardinal("1");
		curr.setMtfNivel(0);
		
		getChildElementNames(childElement, "/", 0, 0, r, null, root);

		return root;
	}

	private Node<SwfMencampos> getChildElementNames(XmlSchemaElement element, String pathIn, Integer level, Integer nro, LinkedList<SwfMencampos> lc,
			Node<SwfMencampos> padre, Node<SwfMencampos> current) {

		if (padre == null && !current.hasCurrent()) {
			log.info("EN ROOT: " + current.getSwfMencampos().toStringID());

			SwfMencampos swr = current.getSwfMencampos();
			current.setSwfMencamposCrr(swr);
			Node<SwfMencampos> padreNew = getChildElementNames(element, pathIn, level, nro, lc, current, current);
			log.info("saliendo................");
			return padreNew;
		}
		String wrap = StringUtils.leftPad("", level * 3, " ");

		String father = "SIN PADRE";
		if (padre != null) {
			SwfMencampos pp = padre.getSwfMencampos();
			if (pp != null)
				father = String.format("%s %s[%s]", pp.toStringID(), pp.getMtfNemo(), pp.getMtfTipocampo());
		}

		 log.info("{}[{}:{}] {} -> {}\t{}: [{}]{}", wrap, level, nro,
		 father,current.nodoID(), current.getSwfMencampos().getMtfNemo(),
		 current.getSwfMencampos().getMtfTipocampo());

		XmlSchemaType elementType = element != null ? element.getSchemaType() : null;
		final String path = pathIn + "/" + element.getName();

		SwfMencampos swf = null;
		if (padre != null && padre.getSwfMencampos() != null)
			swf = createSwfcampo(element, pathIn, level, nro, padre.getSwfMencampos());
		else {
			swf = createSwfcampo(element, pathIn, level, nro, new SwfMencampos());
		}
		swf.setMtfCodmt(padre.getSwfMencampos().getMtfCodmt());
		swf.setMtfSecpadre(current.getSwfMencampos().getMtfSecpadre());
		String codCmp = !StringUtils.isBlank(current.getSwfMencampos().getMtfBloque()) ? current.getSwfMencampos().getMtfBloque() + "-" : "";
		swf.setMtfCodcampo(codCmp + swf.getMtfCodcampo());
		swf.setMtfNro(current.getSwfMencampos().getMtfNro());
		
		boolean evalTag = ((level <= maxLevel && maxLevel > 0) || (maxLevel <= 0));
		if (!evalTag) {
			evalTag = isMandatory(swf);
		} 

		if (!evalTag) {
			evalTag = level > maxLevel && (maxLevel > 0) && padre.getSwfMencampos().getMtfNivel() > maxLevel;
		}

		lc.add(swf);
		if (!evalTag) {
//			log.info("Tag breaking!! {} {} - {} - {} - {} {} -> {}", swf.getMtfNemo(), isMandatory(swf), level, swf.getMtfNivel(),
//					padre.getSwfMencampos().getMtfNivel(), maxLevel, swf.getMtfXmltag());
			return padre;
		}

		Node<SwfMencampos> padreN = new Node<SwfMencampos>(swf);
		padreN.setSwfMencamposCrr(swf);
		swf.setMtfId(ai.addAndGet(1));
		Tree.addChild(padre, padreN);
		
		if (elementType instanceof XmlSchemaComplexType) {
			XmlSchemaParticle allParticles = ((XmlSchemaComplexType) elementType).getParticle();
			if (allParticles == null) {
				XmlSchemaContentModel st = ((XmlSchemaComplexType) elementType).getContentModel();
				XmlSchemaSimpleContent sc = (XmlSchemaSimpleContent) st;
				XmlSchemaContent cont = sc.getContent();
				XmlSchemaSimpleContentExtension se = (XmlSchemaSimpleContentExtension) cont;

				for (XmlSchemaAttributeOrGroupRef a : se.getAttributes()) {
					log.info("atrib " + a.toString());
					swf.setMtfTipocampo("AMT");
					swf.setMtfXmltag(path + "/@Ccy");
				}
				// Tree.addChild(padre, padreN);
			} else {
				if (allParticles instanceof XmlSchemaAny) {
				} else if (allParticles instanceof XmlSchemaElement) {
				} else if (allParticles instanceof XmlSchemaChoice) {
					// log.info(" **Element Schema Choice " + element.getName());
					XmlSchemaChoice ch = (XmlSchemaChoice) allParticles;
					swf.setMtfTipocampo("CH");

					Integer levelCh = level + 1;
					Integer nroc = current.getSwfMencampos().getMtfNro() + 1;
					
					Integer nwNro = current.getSwfMencampos().getMtfNro() + 1;
					for (XmlSchemaChoiceMember c : ch.getItems()) {
						XmlSchemaElement itemElements = (XmlSchemaElement) c;

						SwfMencampos swfCh = createSwfcampo(itemElements, path, levelCh, 1, padre.getSwfMencampos());
						swfCh.setMtfTipocampo("ICH");
						swfCh.setMtfSecpadre(swf.getMtfNemo());
						swfCh.setMtfBloque(element.getName());
						swfCh.setMtfNro(nroc);
						Node<SwfMencampos> currCh = new Node<SwfMencampos>(swfCh);
						currCh.setSwfMencamposCrr(swfCh);
						
						Node<SwfMencampos> padreNew = getChildElementNames(itemElements, path, levelCh, 1, lc, padreN, currCh);
						nwNro = currCh.getSwfMencampos().getMtfNro();
					}
					current.getSwfMencampos().setMtfNro(nwNro);
				} else if (allParticles instanceof XmlSchemaSequence) {
					final XmlSchemaSequence xmlSchemaSequence = (XmlSchemaSequence) allParticles;
					swf.setMtfTipocampo("SQ");
					Integer nroc = 1;
					current.getSwfMencampos().setMtfNro(current.getSwfMencampos().getMtfNro() + 1);
					for (XmlSchemaSequenceMember item : xmlSchemaSequence.getItems()) {
					
						if (item instanceof XmlSchemaElement) {
							XmlSchemaElement itemElements = (XmlSchemaElement) item;
							SwfMencampos swfCh = createSwfcampo(itemElements, path, level + 1, nroc, padreN.getSwfMencampos());
							swfCh.setMtfNro(current.getSwfMencampos().getMtfNro());
							swfCh.setMtfTipocampo("ISQ");
							swfCh.setMtfSecpadre(swf.getMtfNemo());
							swfCh.setMtfBloque(element.getName());
							//current.getSwfMencampos().setMtfNro(nro);
							
							Node<SwfMencampos> currCh = new Node<SwfMencampos>(swfCh);
							currCh.setSwfMencamposCrr(swfCh);
							addChild(element.getQName(), itemElements, swfCh);
							Node<SwfMencampos> padreNew = getChildElementNames(itemElements, path, level + 1, nroc, lc, padreN, currCh);
							// Tree.addChild(padre, padreNew);
							current.getSwfMencampos().setMtfNro(currCh.getSwfMencampos().getMtfNro() + 1);
						} else if (item instanceof XmlSchemaChoice) {
							log.info(" **item XmlSchemaChoice " + item.getClass().getSimpleName() + " -> " + path);							
							XmlSchemaChoice ch = (XmlSchemaChoice) item;
							swf.setMtfTipocampo("CH");

							Integer levelCh = level + 1;
							nroc = current.getSwfMencampos().getMtfNro() + 1;
							
							Integer nwNro = current.getSwfMencampos().getMtfNro() + 1;
							for (XmlSchemaChoiceMember c : ch.getItems()) {
								XmlSchemaElement itemElements = (XmlSchemaElement) c;

								SwfMencampos swfCh = createSwfcampo(itemElements, path, levelCh, 1, padre.getSwfMencampos());
								swfCh.setMtfTipocampo("ICH");
								swfCh.setMtfSecpadre(swf.getMtfNemo());
								swfCh.setMtfBloque(element.getName());
								swfCh.setMtfNro(nroc);
								Node<SwfMencampos> currCh = new Node<SwfMencampos>(swfCh);
								currCh.setSwfMencamposCrr(swfCh);
								
								Node<SwfMencampos> padreNew = getChildElementNames(itemElements, path, levelCh, 1, lc, padreN, currCh);
								nwNro = currCh.getSwfMencampos().getMtfNro();
							}
							current.getSwfMencampos().setMtfNro(nwNro);
						}
						nroc++;
					}
				}
			}

		} else if (elementType instanceof XmlSchemaSimpleType) {
			XmlSchemaSimpleType st = (XmlSchemaSimpleType) elementType;

			XmlSchemaSimpleTypeRestriction sr = (XmlSchemaSimpleTypeRestriction) st.getContent();
			swf.setMtfTipocampo(sr.getBaseTypeName().getLocalPart());
			if (sr.getFacets().size() > 0) {
				String tablaPropJoin = sr.getFacets().stream().map(m -> m.getValue().toString()).collect(Collectors.joining(", "));
				if (sr.getFacets().size() == 1) {
					if (sr.getFacets().get(0) instanceof XmlSchemaPatternFacet) {
						swf.setMtfReglaswf(tablaPropJoin);
						swf.setMtfTipocampo("regex");
					}
				} else {
					if (sr.getFacets().get(0) instanceof XmlSchemaMaxLengthFacet && sr.getFacets().get(1) instanceof XmlSchemaMaxInclusiveFacet) {
						swf.setMtfReglaswf(tablaPropJoin);
					} else {
						swf.setMtfDatoadic(tablaPropJoin);
					}
				}
			}
		}

		return padre;
	}

	public static List<SwfMencampos> visitNode(Node<SwfMencampos> node) {
		List<SwfMencampos> resp = new ArrayList<>();
		resp.add(node.getSwfMencampos());
		for (Node<SwfMencampos> n : node.getChildArray()) {
			List<SwfMencampos> respA = visitNode(n);
			respA.forEach(nn -> {
				resp.add(nn);
			});
		}

		return resp;
	}

	private static void addChild(QName qName, XmlSchemaElement child, SwfMencampos swf) {

		List<XmlSchemaElement> values = xsdElements.get(qName);
		if (values == null) {
			values = new ArrayList<XmlSchemaElement>();
		}
		// log.info("en clid " + qName.getLocalPart() + " " + child.getName() + " " +
		// xsdElements.size() + " -> " + values.size());
		values.add(child);
		xsdElements.put(qName, values);
	}

	public static SwfMencampos createSwfcampo(XmlSchemaElement element, String pathIn, Integer level, Integer nro, SwfMencampos padre) {
		XmlSchemaType elementType = element != null ? element.getSchemaType() : null;

		final String path = pathIn + "/" + element.getName();
		String corr = StringUtils.leftPad(nro.toString(), 2, "0");
		String nemoP = !StringUtils.isBlank(padre.getMtfNemo()) ? padre.getMtfNemo() + "." : "";
		SwfMencampos swf = new SwfMencampos();
		
		String wrap = StringUtils.rightPad(element.getName(), 15, "X");
		wrap = element.getName();
		String codCmp = padre.getMtfCodcampo();
		swf.setMtfGrpopt(0);
		swf.setMtfNro(nro);
		swf.setMtfCodcampo(wrap);
		swf.setMtfCodmt(padre.getMtfCodmt());
		swf.setMtfXmltag(path);
		swf.setMtfFormato(elementType.getName());
		swf.setMtfMinimo(String.valueOf(element.getMinOccurs()));
		swf.setMtfCardinal(String.valueOf(element.getMaxOccurs()));
		swf.setMtfNivel(level);
		swf.setMtfNemo(nemoP + corr);
		swf.setMtfTipocampo("TEXT");
		swf.setMtfStatus("O");

		if (isMandatory(swf)) {
			swf.setMtfStatus("M");
		}
		return swf;
	}

	public static boolean isMandatory(SwfMencampos swf) {
		return (!StringUtils.isBlank(swf.getMtfMinimo()) && swf.getMtfMinimo().equals("1"))
				|| (!StringUtils.isBlank(swf.getMtfStatus()) && swf.getMtfStatus().equals("M"));
	}

	public static boolean isChoice(SwfMencampos swf) {
		return !StringUtils.isBlank(swf.getMtfTipocampo()) && swf.getMtfTipocampo().equals("CH");
	}

	public static boolean isSequence(SwfMencampos swf) {
		return !StringUtils.isBlank(swf.getMtfTipocampo()) && swf.getMtfTipocampo().equals("SQ");
	}
}
