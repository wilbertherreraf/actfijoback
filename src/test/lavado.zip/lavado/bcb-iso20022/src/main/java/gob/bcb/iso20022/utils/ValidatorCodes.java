package gob.bcb.iso20022.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.BigDecimalValidator;
import org.apache.commons.validator.routines.DateValidator;
import org.apache.commons.validator.routines.IntegerValidator;
import org.apache.commons.validator.routines.ShortValidator;
import org.apache.commons.validator.routines.checkdigit.ABANumberCheckDigit;
import org.apache.commons.validator.routines.checkdigit.CUSIPCheckDigit;
import org.apache.commons.validator.routines.checkdigit.CheckDigitException;
import org.apache.commons.validator.routines.checkdigit.ISINCheckDigit;
import org.apache.commons.validator.routines.checkdigit.SedolCheckDigit;

import gob.bcb.iso20022.utilsBank.iban.Iban;

public class ValidatorCodes {
	public static final String PATTERN_DATE_DDMMYYYY = "dd/MM/yyyy";
	public static final String PATTERN_DATE_MMDDYYYY = "MM/dd/yyyy";
	public static final String PATTERN_DATE_DDMMYY = "dd/MM/yy";
	public static final String PATTERN_DATE_YYYYMMDD = "yyyyMMdd";
	public static final String PATTERN_DECIMAL = "#####0.00";
	public static final String PATTERN_DECIMAL_OUT = "#,##0.00";
	public static final String[] DATE_PATTERNS0 = { PATTERN_DATE_DDMMYYYY, PATTERN_DATE_MMDDYYYY, "yyyy/MM/dd", "dd-MM-yyyy", "MM-dd-yyyy", "yyyy-MM-dd",
			"yyyyMMdd" };
	public static final String[] DATE_PATTERNS_EN = { "MM/dd/yy", PATTERN_DATE_MMDDYYYY, "yy-MM-dd", "yyyy-MM-dd", PATTERN_DATE_DDMMYYYY };
	public static final String[] DATE_PATTERNS_BO = { PATTERN_DATE_DDMMYYYY };
	public static final Locale LOCALE_EN_US = new Locale("en", "US");
	public static final String PATTERN_ISIN11 = "[A-Z]{2,2}[A-Z0-9]{9,9}[0-9]{0,1}";
	public static final String PATTERN_CUSIP8 = "[A-Z0-9]{8,8}";
	public static final String CODE_FOREX = "[A-Z]{3,3}/[A-Z]{3,3}[0-9]{0,1}";
	public static final String CODEFUTURE_4_5 = "[A-Z]{1,1}[0-9A-Z]{1,1}[FGHJKMNQUVXZ][0-9]{1,2}";
	public static final String CODEFUTURE_3 = "[A-Z]{1,1}[FGHJKMNQUVXZ][0-9]{1,1}";

	public static Predicate<String> isBlank = text -> text == null || text.trim().length() == 0;

	public static Boolean isIsinCusipCash(String value) {
		return (value != null) && value.contains("CASH");
	}

	public static Boolean isCusip(String value) {
		// log.info("OOO> Validator CUSIP " + value);
		return (value != null) && (CUSIPCheckDigit.CUSIP_CHECK_DIGIT.isValid(value.trim()) && (value.trim().length() == 9));
	}

	public static Boolean isIsin(String value) {
		return value != null && (ISINCheckDigit.ISIN_CHECK_DIGIT.isValid(value.trim()) && (value.trim().length() == 12));
		// || Pattern.matches(PATTERN_ISIN11, value));
	}

	public static Boolean isIsin11(String value) {
		return value != null && (ISINCheckDigit.ISIN_CHECK_DIGIT.isValid(value.trim()) && (value.trim().length() == 11));
		// || Pattern.matches(PATTERN_ISIN11, value));
	}

	public static Boolean isSedol(String value) {
		// log.info("OOO> Validator CUSIP " + value);
		return (value != null) && (SedolCheckDigit.SEDOL_CHECK_DIGIT.isValid(value) && (value.trim().length() == 7));
	}

	/*
	 * verifica si el codigo matchea con el formato isin
	 */
	public static Boolean isIsinWithFormat(String value) {
		return value != null && Pattern.matches(PATTERN_ISIN11, value);
	}

	public static Boolean isCusip8(String value) {
		// return CUSIPCheckDigit.CUSIP_CHECK_DIGIT.isValid(value) && (value != null);
		return (value != null) && CUSIPCheckDigit.CUSIP_CHECK_DIGIT.isValid(value.trim()) && (value.trim().length() == 8); // &&
																															// Pattern.matches(PATTERN_CUSIP8,
																															// value);
	}

	public static String calculateDigitCusip(String value) {
		try {
			return CUSIPCheckDigit.CUSIP_CHECK_DIGIT.calculate(value);
		} catch (CheckDigitException e) {
			// throw new RuntimeException("Codigo invalido " + value + " " + e.getMessage(),
			// e);
			return "";
		}
	}

	public static String calculateDigitCusip8(String value) {
		try {
			return isCusip8(value) ? CUSIPCheckDigit.CUSIP_CHECK_DIGIT.calculate(value) : "";
		} catch (CheckDigitException e) {
			// throw new RuntimeException("Codigo invalido " + value + " " + e.getMessage(),
			// e);
			return "";
		}
	}

	public static String calculateDigitIsin(String value) {
		try {
			return ISINCheckDigit.ISIN_CHECK_DIGIT.calculate(value);
		} catch (CheckDigitException e) {
			// throw new RuntimeException("Codigo invalido " + value + " " + e.getMessage(),
			// e);
			return "";
		}
	}

	public static String calculateDigitSedol(String value) {
		try {
			return SedolCheckDigit.SEDOL_CHECK_DIGIT.calculate(value);
		} catch (CheckDigitException e) {
			// throw new RuntimeException("Codigo invalido " + value + " " + e.getMessage(),
			// e);
			return "";
		}
	}

	public static String fixDigitCusip(String value) {
		String checkDig = calculateDigitCusip(value);
		return value.concat(checkDig);
	}

	public static String fixDigitIsin(String value) {
		String checkDig = calculateDigitIsin(value);
		return value.concat(checkDig);
	}

	public static String getCusipIsinWithDigit(String valuePar) {
		String value = trimEmpty(valuePar);
		if (isCusip(value)) {
			return value;
		} else if (value.length() == 8) {
			return fixDigitCusip(value);
		}

		if (isIsin(value)) {
			return value;
		} else if (value.length() == 11) {
			return fixDigitIsin(value);
		}
		return value;
	}

	public static String getCusipIsinWithoutDigit(String valuePar) {
		String value = trimEmpty(valuePar);
		if (isCusip(value)) {
			return value.length() > 8 ? value.substring(0, 8) : value;
		} else if (value.length() == 8) {
			return value;
		}

		if (isIsin(value)) {
			return value.length() > 10 ? value.substring(0, 11) : value;
		} else if (value.length() == 11) {
			return value;
		}
		return value;
	}

	public static Boolean isCodeSecValid(String value) {
		return isIsin(value) || isCusip(value) || isSedol(value);
	}

	public static Boolean isCodeSecValidOpt(String value) {
		return isCodeSecValid(value) || isCusip8(value);
	}

	public static BiFunction<String, String, Optional<String>> returnIsin() {
		return (isin, cusip) -> Optional.ofNullable(isIsin(isin) ? getCusipIsinWithoutDigit(isin) : (isIsin(cusip) ? getCusipIsinWithoutDigit(cusip) : null));
	}

	public static BiFunction<String, String, Optional<String>> returnCusip() {
		return (isin, cusip) -> Optional.ofNullable(isCusip(isin) ? isin : (isCusip(cusip) ? cusip : null));
	}

	public static BiFunction<String, String, Optional<String>> returnSedol() {
		return (isin, cusip) -> Optional.ofNullable(isSedol(isin) ? isin : (isSedol(cusip) ? cusip : null));
	}

	public static BiFunction<String, String, Optional<String>> returnIsinOrCusipReal(Consumer<String> idOtroC) {
		return (isin, cusip) -> {
			String idSecPrinc = isin != null ? isin.trim().toUpperCase() : "";
			String idSecOtro = cusip != null ? cusip.trim().toUpperCase() : "";

			if (isBlank.test(idSecPrinc) && isBlank.test(idSecOtro)) {
				return Optional.empty();
			}

			if (idSecPrinc.equals(idSecOtro)) {
				idSecOtro = "";
			}
			if (isFrxFuture().test(idSecPrinc) || isFrxFuture().test(idSecOtro)) {
				return Optional.empty();
			}

			if (isBlank.test(idSecPrinc) || isBlank.test(idSecOtro)) {
				if (isBlank.test(idSecPrinc)) {
					idSecPrinc = idSecOtro;
					idSecOtro = "";
				}
			}

			Optional<String> isinOpt = Optional.ofNullable(isIsin(idSecPrinc) ? idSecPrinc : (isIsin(idSecOtro) ? idSecOtro : null));
			if (isinOpt.isPresent()) {
				if (idOtroC != null)
					idOtroC.accept(isinOpt.get().equals(idSecPrinc) ? idSecOtro : idSecPrinc);
				return isinOpt;
			} else {
				Optional<String> cusipOpt = Optional.ofNullable(isCusip(idSecPrinc) ? idSecPrinc : (isCusip(idSecOtro) ? idSecOtro : null));
				if (cusipOpt.isPresent()) {
					if (idOtroC != null)
						idOtroC.accept(cusipOpt.get().equals(idSecPrinc) ? idSecOtro : idSecPrinc);
					return cusipOpt;
				} else {
					if (isSedol(idSecPrinc)) {
						if (idOtroC != null)
							idOtroC.accept(idSecOtro);
						return Optional.ofNullable(idSecPrinc);
					} else if (isSedol(idSecOtro)) {
						if (idOtroC != null)
							idOtroC.accept(idSecPrinc);
						return Optional.ofNullable(idSecOtro);
					}

					return Optional.empty();
				}
			}
		};
	}

	public static BiFunction<String, String, Optional<String>> returnIsinOrCusip() {
		return (isin, cusip) -> {
			Optional<String> isinOpt = returnIsin().apply(isin, cusip);
			if (isinOpt.isPresent()) {
				return isinOpt;
			} else {
				Optional<String> cusipOpt = returnCusip().apply(isin, cusip);
				if (cusipOpt.isPresent()) {
					return cusipOpt;
				} else {
					return returnSedol().apply(isin, cusip);
				}
			}
		};
	}

	public static BiFunction<String, String, Optional<String>> returnIsinOrCusipFormat() {
		return (isin, cusip) -> {
			Optional<String> isinOpt = Optional.ofNullable(isIsinWithFormat(isin) ? isin : (isIsinWithFormat(cusip) ? cusip : null));

			if (isinOpt.isPresent()) {
				return isinOpt;
			} else {
				return Optional.ofNullable(isCusip8(isin) ? fixDigitCusip(isin) : (isCusip8(cusip) ? fixDigitCusip(cusip) : null));
			}
		};
	}

	public static BiFunction<String, String, Optional<String>> returnCodeSecurity() {
		return (isin, cusip) -> {
			String idSecPrinc = isin != null ? isin.trim().toUpperCase() : "";
			String idSecOtro = cusip != null ? cusip.trim().toUpperCase() : "";

			if (isBlank.test(idSecPrinc) && isBlank.test(idSecOtro)) {
				return Optional.empty();
			}

			if (idSecPrinc.equals(idSecOtro)) {
				idSecOtro = "";
			}
			if (isFrxFuture().test(idSecPrinc) || isFrxFuture().test(idSecOtro)) {
				return Optional.empty();
				// return Optional.of(isin);
			}

			if (isBlank.test(idSecPrinc) || isBlank.test(idSecOtro)) {
				if (isBlank.test(idSecPrinc)) {
					idSecPrinc = idSecOtro;
					idSecOtro = "";
				}
			}

			return !isBlank.test(idSecPrinc) ? Optional.of(idSecPrinc) : Optional.empty();
		};
	}

	public static BiFunction<String, String, String> returnCodeSecurityFormat() {
		return (isin, cusip) -> {
			return returnIsinOrCusip().apply(isin, cusip).orElseGet(() -> {
				if (isFrxFuture().test(isin) || isFrxFuture().test(cusip)) {
					return null;
				}
				String isinCusipJoin = Arrays.asList(isin != null ? isin : null, cusip != null ? cusip : null)//
						.stream()//
						.filter(isBlank.negate())//
						.distinct().collect(Collectors.joining(""));
				// return isIsinWithFormat(isin) ? isin : (isIsinWithFormat(cusip) ? cusip :
				// isinCusipJoin);
				return returnIsinOrCusipFormat().apply(isin, cusip).orElse(isinCusipJoin);
			});
		};
	}

	public static Predicate<String> isFrxFuture() {
		return codeSecutiry -> isForexFuture(codeSecutiry);
	}

	public static Boolean isForexFuture(String codeSecutiry) {
		return isForexCode(codeSecutiry) || isFutureSymbol(codeSecutiry);
	}

	public static boolean isForexCode(String command) {
		if (isBlank.test(command))
			return false;
		return Pattern.matches(CODE_FOREX, command.trim().toUpperCase());
	}

	public static boolean isFutureSymbol(String command) {
		if (command == null)
			return false;

		boolean isMatch = Pattern.matches(CODEFUTURE_4_5, command.trim());
		if (!isMatch && command.trim().length() == 3) {
			isMatch = Pattern.matches(CODEFUTURE_3, command.trim());
		}

		return isMatch;
	}

	public static final String CODESEC_PROPIETARY_ = "";
	public static final String CODESEC_SUFIX_ = "";

	public static BiFunction<String, String, String> tipoCodeSecurity(Consumer<String> proprietaryC, Consumer<String> actualizaOtroidC) {
		return (isin, cusip) -> {
			isin = isin != null ? isin.trim().toUpperCase() : "";
			cusip = cusip != null ? cusip.trim().toUpperCase() : "";

			// Optional<String> codeSecurityInOpt = returnIsinOrCusipReal(null).apply(isin,
			// cusip);

			if (isBlank.test(isin) && isBlank.test(cusip)) {
				return null;
			}
			if (isin.equals(cusip)) {
				cusip = "";
			}
			if (isBlank.test(isin) || isBlank.test(cusip)) {
				if (isBlank.test(isin)) {
					isin = cusip;
					cusip = "";
				}
			}

			String codeSecurity = isin;

			String sufix = "";
			String proprietarySch = "";
			String tipoSec = "";
			String nuevoOtroId = "";

			if (isIsin(codeSecurity)) {
				Boolean matche = Pattern.matches("[A-Z]{2,2}[A-Z0-9]{1,}", codeSecurity.trim());
				if (matche) {
					sufix = codeSecurity.trim().substring(0, 2);
				}
				tipoSec = "ISIN";
				String cu = codeSecurity.substring(2, 11);

				if (sufix.equals("US") || sufix.equals("CA")) {
					// Common Code National securities identification number for ICSDs issued by the
					// National Numbering Association
					// Clearstreaam and Euroclear.
					proprietarySch = "US";
					if (!isBlank.test(cusip) && codeSecurity.contains(cusip) && cu.contains(cusip)) {
						// el cusip es parte del isin
						nuevoOtroId = cu;
					}

//				} else if (sufix.equals("US") || sufix.equals("CA")) {
//					proprietarySch = "US";
//					
//					if (!isBlank.test(cusip) &&  codeSecurity.contains(cusip) && cu.contains(cusip) ){
//						// el cusip es parte del isin 
//						nuevoOtroId = cu; 
//					}

				} else {
					// Stock Exchange Daily Official List (SEDOL) : National securities
					// identification number for GB issued by the
					// National Numbering Association London Stock Exchange.
					if (!isBlank.test(sufix)) {
						proprietarySch = "EU";
						tipoSec = "ISIN";
					} else {
						tipoSec = "ISIN";
						proprietarySch = sufix;
					}
				}
			} else if (isCusip(codeSecurity)) {
				tipoSec = "CUSP";
				sufix = codeSecurity.trim().substring(0, 2);
				// Boolean matcheCu =
				// Pattern.matches("[ABCDEFGHJKLMNPQRSTUVWXY]{1,1}[A-Z0-9]{1,}",
				// codeSecurity.trim());
				Boolean matcheCu = Pattern.matches("[A-Z]{1,1}[A-Z0-9]{1,}", codeSecurity.trim());
				if (matcheCu) {
					// cusip custodio dummy
					proprietarySch = "CINS";
				} else {
					proprietarySch = "US";
				}

				if (sufix.equals("PP")) {
					// titulos asignados a america
					tipoSec = "CUSTPP";
					proprietarySch = "CUSTPP";
				}

			} else if (isSedol(codeSecurity)) {
				tipoSec = "SEDL";
				proprietarySch = "PARTY";
			} else {
				// Ticker Code assigned by an exchange to identify financial instruments
				tipoSec = "TIKR";
				proprietarySch = "CUST";
				// sufix = codeSecurity.trim().length() > 5 ? codeSecurity.trim().substring(0,
				// 2) : "";
				Boolean matcheCu = Pattern.matches("[A-Z]{2,2}[A-Z0-9]{1,6}", codeSecurity.trim());

				if (matcheCu && isBlank.test(cusip)) {
					sufix = codeSecurity.trim().substring(0, 2);
					nuevoOtroId = fixDigitCusip(codeSecurity);
					tipoSec = "CUSP";
					// cusip custodio dummy
					proprietarySch = "CINS";

					if (sufix.equals("PP")) {
						proprietarySch = "CUSTPP";
						tipoSec = "CUSTPP";
					}
				} else {
					Boolean matche = isIsinWithFormat(codeSecurity.trim()); // Pattern.matches("[A-Z]{2,2}[A-Z0-9]{1,9}", codeSecurity.trim());

					if (matche) {
						tipoSec = "ISIN";
						sufix = codeSecurity.trim().substring(0, 2);
						if (sufix.equals("XS")) {
							proprietarySch = "EU";
						} else if (sufix.equals("US") || sufix.equals("CA")) {
							proprietarySch = "US";
						} else {
							proprietarySch = sufix;
						}
					}
				}
			}

			if (proprietaryC != null) {
				proprietaryC.accept(proprietarySch);
			}

			if (actualizaOtroidC != null && !isBlank.test(nuevoOtroId)) {
				actualizaOtroidC.accept(nuevoOtroId);
			}
			return tipoSec;
		};
	}

	/**
	 * determina si un codigo de sec es intercambiable
	 * 
	 * @param isincusptipo
	 * @param isincuspsfx
	 * @return
	 */
	public static boolean isIsinCuInter(String isincusptipo, String isincuspsfx) {
		if (isBlank.test(isincusptipo) || isBlank.test(isincuspsfx)) {
			return false;
		}

		Boolean isIsi = isincusptipo.equalsIgnoreCase("ISIN") && isincuspsfx.trim().length() == 2;
		Boolean isCuUS = isincusptipo.equalsIgnoreCase("CUSP") && isincuspsfx.equalsIgnoreCase("US");
		return isIsi || isCuUS;
	}

	/**
	 * determina si es codigo bloomberg
	 * 
	 * @param isincusptipo
	 * @param isincuspsfx
	 * @return
	 */
	public static boolean isIsinCuCodBloo(String isincusptipo, String isincuspsfx) {
		if (isBlank.test(isincusptipo) || isBlank.test(isincuspsfx)) {
			return false;
		}
		return isincusptipo.equalsIgnoreCase("CUSP") && isincuspsfx.equalsIgnoreCase("CUSTPP");
	}

	/**
	 * detrmina si es codigo cusip emitido por SEC
	 * 
	 * @param isincusptipo
	 * @param isincuspsfx
	 * @return
	 */
	public static boolean isCuCins(String isincusptipo, String isincuspsfx) {
		if (isBlank.test(isincusptipo) || isBlank.test(isincuspsfx)) {
			return false;
		}

		return isincusptipo.equalsIgnoreCase("CUSP") && isincuspsfx.equalsIgnoreCase("CINS");
	}

	/************** converts Date **********************/
	/**
	 * Convierte una cadena a fecha dado un patron del origen
	 */
	public static Function<Date, String> dateToStringDDMMYYYY = date -> {
		return dateToString(date, PATTERN_DATE_DDMMYYYY);
	};

	public static Function<Date, String> dateToStringDDMMYY = date -> {
		return dateToString(date, PATTERN_DATE_DDMMYY);
	};

	public static BiFunction<String, String, Optional<Date>> stringToDate = (value, patternSource) -> Optional
			.ofNullable(DateValidator.getInstance().validate(value, patternSource));

	public static Boolean isValidDate(String value, String pattern) {
		return stringToDate.apply(value, pattern).isPresent();
	}

	/**
	 * encuentra el patron de una fecha cadena dado un conjunto de patrones validos
	 */
	public static BiFunction<String, String[], Optional<String>> patternDateForStringDate = (valueDate, patternsValids) -> Stream.of(patternsValids)
			.filter(pattern -> isValidDate(valueDate, pattern)).findFirst();

	public static String dateToString(Date value, String patternTarget) {
		return DateValidator.getInstance().format(value, patternTarget);
	}

	public static String dateToString(Calendar value, String patternTarget) {
		return DateValidator.getInstance().format(value, patternTarget);
	}

	/*
	 * "yyyy.MM.dd G 'at' HH:mm:ss z" 2001.07.04 AD at 12:08:56 PDT
	 * "EEE, MMM d, ''yy" Wed, Jul 4, '01 "h:mm a" 12:08 PM "hh 'o''clock' a, zzzz"
	 * 12 o'clock PM, Pacific Daylight Time "K:mm a, z" 0:08 PM, PDT
	 * "yyyyy.MMMMM.dd GGG hh:mm aaa" 02001.July.04 AD 12:08 PM
	 * "EEE, d MMM yyyy HH:mm:ss Z" Wed, 4 Jul 2001 12:08:56 -0700 "yyMMddHHmmssZ"
	 * 010704120856-0700 "yyyy-MM-dd'T'HH:mm:ss.SSSZ" 2001-07-04T12:08:56.235-0700
	 * "yyyy-MM-dd'T'HH:mm:ss.SSSXXX" 2001-07-04T12:08:56.235-07:00 "YYYY-'W'ww-u"
	 * 2001-W27-3
	 * 
	 */
	public static String dateToStringLong(Date value) {
		Locale LOCALE_EN_ES = new Locale("es", "ES");
		String patternTarget = "dd 'de' MMMMM 'de' yyyy";
		return DateValidator.getInstance().format(value, patternTarget, LOCALE_EN_ES);
	}

	public static BiFunction<String, String[], Optional<Date>> stringWithPatternsToDate = (value, patternsValids) -> {
		Optional<String> pattString = patternDateForStringDate.apply(value, patternsValids);
		return pattString.isPresent() ? stringToDate.apply(value, pattString.get()) : Optional.empty();
	};

	public static Function<String, Optional<String>> stringDateToStringNormalize(String[] patternsValids, String patterOutput) {
		return value -> {
			Optional<String> pattString = patternDateForStringDate.apply(value, patternsValids);
			if (pattString.isPresent()) {
				Date fecha = stringWithPatternsToDate.apply(value, patternsValids).get();
				return Optional.ofNullable(dateToString(fecha, patterOutput));
			}
			return Optional.empty();
		};
	};

	public static Function<String, Date> convertToDate() {
		return strdate -> {
			Date d = stringWithPatternsToDate.apply(strdate, DATE_PATTERNS_EN).orElse(null);
			Date db = d == null ? stringWithPatternsToDate.apply(strdate, DATE_PATTERNS_BO).orElse(null) : d;
			return db;
		};
	}

	/************** Fin: converts Date **********************/

	/************** converts Decimal **********************/
	public static Function<BigDecimal, String> bigDecimalToStringF(String pattern) {
		return valor -> {
			return bigDecimalToString(valor, pattern);
		};
	}

	public static Boolean validDecimal(String value, String pattern) {
		return BigDecimalValidator.getInstance().isValid(value, pattern, LOCALE_EN_US);
	}

	public static Boolean isValidDecimal(String value) {
		String newValue = value != null ? value.trim().replace("%", "") : null;
		return BigDecimalValidator.getInstance().isValid(newValue, LOCALE_EN_US);
	}

	public static BigDecimal stringToBigDecimal(String value) {
		String newValue = value != null ? value.trim().replace("%", "") : null;
		BigDecimal val = BigDecimalValidator.getInstance().validate(newValue, LOCALE_EN_US);
		return val == null ? BigDecimal.ZERO : val;

	}

	public static String bigDecimalToString(BigDecimal value, String pattern) {
		if (value == null) {
			return "";
		}
		DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(LOCALE_EN_US);
		otherSymbols.setDecimalSeparator('.');
		// otherSymbols.setGroupingSeparator(' ');
		DecimalFormat df = new DecimalFormat(pattern, otherSymbols);

		return df.format(value); // BigDecimalValidator.getInstance().format(value, pattern);
	}

	public static String bigDecimalToStringES(BigDecimal value, String pattern) {
		Locale LOCALE_ES_BO = new Locale("es", "ES");
		DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(LOCALE_ES_BO);
		otherSymbols.setDecimalSeparator(',');
		DecimalFormat df = new DecimalFormat(pattern, otherSymbols);

		return df.format(value); // BigDecimalValidator.getInstance().format(value, pattern);
	}

	public static Function<String, Optional<String>> stringDecimalToStringNormalize(String patterOutput) {
		return value -> {
			// if (isValidDecimal(value)){
			BigDecimal val = stringToBigDecimal(value);
			return Optional.ofNullable(bigDecimalToString(val, patterOutput));
			// }
			// return Optional.empty();
		};
	}

	/************** Fin: converts Decimal **********************/

	/************** converts Boolean **********************/
	public static Boolean stringToBoolean(String value) {
		return value != null && (value.trim().equals("1") || value.trim().equalsIgnoreCase("true") || value.trim().equalsIgnoreCase("verdadero")
				|| value.trim().equalsIgnoreCase("T"));
	}

	/************** Fin: converts Boolean **********************/

	public static Integer stringToInteger(String value) {
		return !isBlank.test(value) ? IntegerValidator.getInstance().validate(value) : null;
	}

	public static Boolean isNumber(String value) {
		return stringToInteger(value) != null;
	}

	public static Short stringToShort(String value) {
		return ShortValidator.getInstance().validate(value);
	}

	public static final String NUMBERS_PATT = "([-]{0,1}[0-9.]+)"; // Ej.
																	// -45.36,
																	// 0.36
	public static final String NUMBERS_RANG_PATT = "([0-9]+[-][0-9]+)"; // Ej.
																		// 99-23

	/**
	 * Extrae el ultimo numero decimal inserto en una cadena que contiene caracteres
	 * y numeros
	 * 
	 * @param value
	 * @return
	 */
	public static String extractNumbers(String value) {
		return extractLastPattern(value, NUMBERS_PATT);
	}

	public static String extractRangeNumbers(String value) {
		return extractLastPattern(value, NUMBERS_RANG_PATT);
	}

	public static String extractRangeOrNumber(String value) {
		String resp = extractRangeNumbers(value);
		return (resp.equals("")) ? extractNumbers(value) : resp;
	}

	public static String extractLastPattern(String value, String pattern) {
		if (value == null)
			return "";

		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(value);

		String resp = "";
		while (m.find())
			resp = m.group();

		return resp.trim();
	}

	/**
	 * 
	 * @param s
	 * @param regex
	 * @param index de 0 a lenght - 1
	 * @return
	 */
	public static String splitAndGetIndex(String s, String regex, int index) {
		index = index < 0 ? 0 : index;
		List<String> list = Arrays.stream(StringUtils.trimToEmpty(s).split(regex)).collect(Collectors.toList());
		return list.size() > index ? list.get(index) : "";
	}

	public static String trimEmpty(String value) {
		return value != null ? value.trim() : "";
	}

	public static String extractAba(String valor) {
		if (StringUtils.isBlank(valor))
			return null;
		valor = valor.trim().toUpperCase();
		int pos = valor.indexOf("FW");
		if (pos == 0) {
			String aba = pos == 0 ? valor.substring(pos + 2) : valor;
			boolean isValid = aba != null && aba.matches("[0-9]{9}");
			return ((pos >= 0) && isValid && ABANumberCheckDigit.ABAN_CHECK_DIGIT.isValid(aba) ? aba : null);
		} else {
			String aba = valor;
			boolean isValid = aba != null && aba.matches("[0-9]{9}");			
			return (isValid && ABANumberCheckDigit.ABAN_CHECK_DIGIT.isValid(aba) ? aba : null);
		}
	}

	public static boolean isAba(String valor) {
		return !StringUtils.isBlank(extractAba(valor));
	}

	public static boolean isIban(String valor) {
		boolean val = !StringUtils.isBlank(valor) && Iban.isValid(valor);
		return val;
	}

	static final Pattern ctryCityPat = Pattern.compile("[A-Z]{2,2}/[^*&@]{1,}");

	public static String extractCtry(String valor) {
		if (StringUtils.isBlank(valor))
			return valor;

		boolean isMatch = ctryCityPat.matcher(StringUtils.trimToEmpty(valor)).matches();
		if (isMatch) {
			return valor.substring(0, 2);
		}
		return null;
	}

	public static String extractCity(String valor) {
		if (StringUtils.isBlank(valor))
			return valor;

		boolean isMatch = ctryCityPat.matcher(StringUtils.trimToEmpty(valor)).matches();
		if (isMatch) {
			return valor.substring(3);
		}
		return valor;
	}

	public static void main(String[] args) {
		System.out.println(isAba("FW026009593") + " " + extractAba("fw026009593") + " - " + isAba("026009593") + " " + extractAba("026009593"));
		System.out.println(isAba("FW026009503") + " " + extractAba("fw026009503") + " - " + isAba("026009503") + " " + extractAba("026009503"));
	}
	/*
	 * public static boolean isCusip88(String cusip) {
	 * 
	 * int sum = 0; for( int i= 1; i <= 8; i++) { char c = cusip.charAt(i); if (c is
	 * a digit then v := numeric value of the digit c else if c is a letter then p
	 * := ordinal position of c in the alphabet (A=1, B=2...) v := p + 9 else if c =
	 * "*" then v := 36 else if c = "@" then v := 37 else if c = "#" then v := 38
	 * end if if i is even then v := v × 2 end if
	 * 
	 * sum := sum + int( v div 10) + v mod 10 }
	 * 
	 * return (10 - (sum mod 10)) mod 10 return true; }
	 */
}
