package gob.bcb.iso20022.exceptions;

public class DataValidationSwitfException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DataValidationSwitfException() {
	}
	
	public DataValidationSwitfException(String message) {
        super(message);
    }
	
    public DataValidationSwitfException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataValidationSwitfException(Throwable cause) {
        super(cause);
    }
}
