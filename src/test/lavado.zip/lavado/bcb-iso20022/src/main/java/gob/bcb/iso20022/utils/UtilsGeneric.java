package gob.bcb.iso20022.utils;

import java.io.BufferedReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

public final class UtilsGeneric {
	private static final String IP_REGEX = ".+@.+\\.[a-z]+";
	public static final String SEPARATOR_PARAMS = ",";
	public static final String strVarIni = "@"; // "\\@";
	// spacios coma y punto y coma
	public static final String strVarFin = "[\\s|,|;]"; // "[\\s,;]";
	public static final String PATTERN_VARIABLE = "[" + strVarIni + "]{1,1}[A-Z0-9_a-z]{1,}"; // "[\\s,;]";
	public static final String PATTERN_NOMBRECAMPOVAR = "[A-Z0-9_a-z]{1,}";
	public static int MAX_LINE_CHARS = 35;
	public static String EOF = "@EOF@";

	/**
	 * Generate a valid xs:ID string.
	 */

	public static String generateUUID() {
		return UUID.randomUUID().toString();
	}

	public static void validarEmail(String emailAddress) {
		if (StringUtils.isBlank(emailAddress)) {
			return;
		}
		Pattern mask = null;

		mask = Pattern.compile(IP_REGEX);
		Matcher matcher = mask.matcher(emailAddress);

		if (!matcher.matches()) {
			throw new RuntimeException("Direccion de correo invalido");
		}

	}

	public static final Charset ISO_CHARSET = Charset.forName("UTF-8");

	public static final String token_parlista_arr = " *& *";
	public static final String token_parlista_eq = " *= *";

	public static Map<String, String> paramsLista(String text) {

		Map<String, String> map = new LinkedHashMap<String, String>();
		if (text == null || text.trim().length() == 0) {
			return map;
		}
		String params = new String(text);

		String[] pairsAmp = params.split(token_parlista_arr);

		for (String keyValue : pairsAmp) {
			String[] pairs = keyValue.split(token_parlista_eq, 2);
			// System.out.println(keyValue + " == " + pairs.length + " :: " +pairs[0]);
			if (pairs.length == 2 && pairs[0].length() > 0) {
				boolean isValidKey = Pattern.matches(PATTERN_NOMBRECAMPOVAR, pairs[0]);
				//if (isValidKey)
					map.put(pairs[0], pairs[1]);
			}
		}
		return map;
	}

	/**
	 * Retorna un mapa de campo y valor , no valida el nombre del campo
	 * 
	 * @param text
	 * @return
	 */
	public static Map<String, String> paramsListaNoVal(String text) {

		Map<String, String> map = new LinkedHashMap<String, String>();
		if (text == null || text.trim().length() == 0) {
			return map;
		}
		String params = new String(text);

		String[] pairsAmp = params.split(token_parlista_arr);

		for (String keyValue : pairsAmp) {
			String[] pairs = keyValue.split(token_parlista_eq, 2);
			// System.out.println(keyValue + " == " + pairs.length + " :: " +pairs[0]);
			if (pairs.length == 2 && pairs[0].length() > 0) {
				map.put(pairs[0], pairs[1]);
			}
		}
		return map;
	}

	public static String mapParamsToString(Map<String, String> params) {
		String paramLista = "";
		int cont = 1;
		for (Entry<String, String> param : params.entrySet()) {
			String key = param.getKey();
			String value = param.getValue();
			if (value != null && value.trim().length() > 0)
				paramLista = paramLista.concat(key).concat("=").concat(value.trim()).concat(((cont + 1) > params.size() ? "" : " & "));
			cont++;
		}
		return paramLista;
	}

	public static String mapParVarsToString(Map<String, String> params) {
		String paramLista = "";
		int cont = 1;
		for (Entry<String, String> param : params.entrySet()) {
			String key = param.getKey();
			String value = param.getValue();
			boolean isValidKey = Pattern.matches(PATTERN_NOMBRECAMPOVAR, key);
			if (isValidKey)
				paramLista = paramLista.concat(key).concat("=").concat(value != null ? value.trim() : "").concat(((cont + 1) > params.size() ? "" : " & "));
			cont++;
		}
		return paramLista;
	}

	public static Map<String, String> valoresVar(String cadenaVars) {
		Map<String, String> map = new HashMap<String, String>();
		if (StringUtils.isBlank(cadenaVars)) {
			return map;
		}
		StringTokenizer tok = new StringTokenizer(cadenaVars, "@", true);
		while (tok.hasMoreTokens()) {
			String entry = tok.nextToken();
			if (entry.length() == 1) {
				entry = tok.nextToken(" ").trim();
				map.put("@" + entry, "");
				try {
					tok.nextToken("@");
				} catch (Exception e) {
				}
			}
		}
		return map;
	}

	/**
	 * retorna una lista de variables que inician con el token
	 * 
	 * @param text
	 * @param strIni
	 * @param strFin
	 * @return
	 */
	public static List<String> listaVars(String text, String strIni, String strFin) {
		List<String> splitLista = new ArrayList<>();
		if (text == null || text.trim().length() == 0) {
			return splitLista;
		}

		Pattern pattern = Pattern.compile("" + strIni + "(.*?)(?=" + strFin + ")");
		// agregamos espacio para variables al final de la cadena
		Matcher matcher = pattern.matcher(text + " ");

		while (matcher.find()) {
			String swiftPlano = matcher.group();
			if (swiftPlano.trim().length() > 1 && swiftPlano.split(" ").length == 1) {
				boolean isMatch = Pattern.matches(PATTERN_VARIABLE, swiftPlano);
				if (isMatch)
					splitLista.add(swiftPlano);

			}
		}
		return splitLista;
	}

	public static List<String> listaVars(String text) {
		return listaVars(text, strVarIni, strVarFin);
	}

	/**
	 * extrae parametros de una cadena del patron func(param1, param2, ...)
	 * 
	 * @param text
	 * @param strIni
	 * @param strFin
	 * @return
	 */
	public static List<String> extractParams(String text, String strIni, String strFin) {
		List<String> splitLista = new ArrayList<>();
		if (text == null || text.trim().length() == 0) {
			return splitLista;
		}
		// final String strIni = "\\(";
		// final String strFin = "\\)";

		Pattern pattern = Pattern.compile("" + strIni + "(.*?)(?=" + strFin + ")");
		// agregamos espacio para variables al final de la cadena
		Matcher matcher = pattern.matcher(text + " ");

		while (matcher.find()) {
			String swiftPlano = matcher.group();
			// el patron incluye en el primer grupo el '('
			if (swiftPlano.startsWith("(")) {
				swiftPlano = swiftPlano.substring(1);
			}
			splitLista.add(swiftPlano.trim());
		}
		List<String> paramsLista = new ArrayList<>();
		splitLista.forEach(s -> {
			paramsLista.addAll(Arrays.asList(s.split(SEPARATOR_PARAMS)).stream().map(p -> p.trim()).collect(Collectors.toList()));

		});
		return paramsLista;
	}

	public static List<String> extractParams(String text) {
		return extractParams(text, "\\(", "\\)");
	}
	
	public static Map<Integer, String> extractParamsMap(String text) {
		Map<Integer, String> map = new LinkedHashMap<Integer, String>();
		List<String> extractP = extractParams(text);
		int pos = 0;
		for (String var : extractP) {
			map.put(pos++, var);
		}
		return map;
	}

	public static List<String> parse(String regex, String string) {
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		Matcher matcher = pat.matcher(string);
		List<String> result = new ArrayList<String>();
		if (matcher.matches()) {
			int groups = matcher.groupCount();
			for (int i = 1; i <= groups; i++) {
				result.add(matcher.group(i));
			}
		}
		return result;
	}

	public static String encodeURL(String url, String sessionParam, String sessionAlias) {
		String encodedSessionAlias = urlEncode(sessionAlias);
		int queryStart = url.indexOf("?");

		if (queryStart < 0) {
			return url + "?" + sessionParam + "=" + encodedSessionAlias;
		}

		String path = url.substring(0, queryStart);
		String query = url.substring(queryStart + 1, url.length());
		String replacement = "$1" + encodedSessionAlias;
		query = query.replaceFirst("((^|&)" + sessionParam + "=)([^&]+)?", replacement);
		if (url.endsWith(query)) {
			// no existing alias
			if (!url.contains(sessionParam)) {
				if (!(query.endsWith("&") || query.length() == 0)) {
					query += "&";
				}
				query += sessionParam + "=" + encodedSessionAlias;
			}
		}

		return path + "?" + query;
	}

	public static String urlEncode(String value) {
		try {
			if (value == null)
				value = "";
			return URLEncoder.encode(value, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * busca el primer patron que cumple la cadena, retorna el valor del patron
	 * 
	 * @param patternsMap
	 * @return
	 */
	public static Function<String, Optional<String>> findPatternForValue(Map<String, String> patternsMap) {
		return val -> {
			if (val == null)
				return Optional.empty();

			Optional<Entry<String, String>> fcPat = patternsMap.entrySet().stream()//
					.filter(entry -> Pattern.matches(entry.getValue(), val.trim()))//
					.findFirst();

			return fcPat.isPresent() ? Optional.of(fcPat.get().getValue()) : Optional.empty();
		};
	}

	public static Function<String, Optional<String>> extractStrForPatt(Map<String, String> patternsMap) {
		return cadena -> {
			if (cadena == null)
				return Optional.empty();

			Optional<String> subCad = patternsMap.entrySet().stream().map(entry -> {
				// verificamos si cadena cumple con el patron
				Pattern pattern = Pattern.compile(entry.getKey());
				Matcher matcher = pattern.matcher(cadena);
				if (matcher.find()) {
					// extraemos el la subcadena
					Pattern patternExt = Pattern.compile(entry.getValue());
					Matcher matcherExt = patternExt.matcher(cadena);
					if (matcherExt.find())
						return Optional.of(matcherExt.group());
				}
				String snull = null;
				return Optional.ofNullable(snull);
			}).filter(s -> s.isPresent()).findFirst().map(s -> s.get());

			return subCad;
		};

	}

	public static Function<String, Optional<String>> extractStrForPatt(String regex) {
		return cadena -> {
			if (cadena == null)
				return Optional.empty();

			// verificamos si cadena cumple con el patron
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(cadena);
			if (matcher.find()) {
				// extraemos el la subcadena
				return Optional.of(matcher.group());
			}

			return Optional.empty();
		};

	}

	public static Boolean entreComillas(String text) {
		return text != null ? text.trim().startsWith("'") && text.trim().endsWith("'") : false;
	}

	public static String removeCharsInvalids(String str) {
		if (str == null) {
			return str;
		}
		String value = str.trim();
	    String nfdNormalizedString = Normalizer.normalize(value, Normalizer.Form.NFD); 
	    Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
	    String strNew = pattern.matcher(nfdNormalizedString).replaceAll("");
	    return StringUtils.replaceChars(strNew, "´'\"", "");
	}

	public static String truncate(String string0, int maxLength, String suffix, boolean defaultTruncateAtWord) {
		if (StringUtils.isBlank(string0)) {
			return null;
		}
		String string = StringUtils.trimToEmpty(string0);
		if (string.length() <= maxLength) {
			return string + suffix;
		}
		if (suffix == null || maxLength - suffix.length() <= 0) {
			return StringUtils.trimToEmpty(string.substring(0, maxLength));
		}

		if (defaultTruncateAtWord) {
			// find the latest space within maxLength
			String sc = string.substring(0, maxLength + 1);
			int lastSpace = sc.lastIndexOf(" ");
			if (lastSpace > 0) {
				return StringUtils.trimToEmpty(string.substring(0, lastSpace)) + suffix;
			}
		}
		return StringUtils.trimToEmpty(string.substring(0, maxLength)) + suffix;

	}
	
	public static List<String> splitInLines(int maxLineChars, String valor, int linesMax, String suffix, String cadenaInicio, int startLine) {
		String frase = "";
		List<String> result = new ArrayList<String>();
		cadenaInicio = StringUtils.trimToEmpty(cadenaInicio);
		int line = 0;
		String prefijo = "";
		
		valor = StringUtils.trimToEmpty(valor);
		valor = StringUtils.replaceChars(valor, "\r\n", "  ");		
		valor = StringUtils.replace(valor, "//", " ");
		do {
			valor = StringUtils.trimToEmpty(valor);			
			if (line >= startLine && StringUtils.isNotBlank(valor)) {
				prefijo = cadenaInicio;
			} else {
				prefijo = "";
			}
			valor = prefijo.concat(valor);
//			System.out.println("frase " + frase + " %% " + frase.length() + " valor: "  + valor);
			frase = truncate(valor, maxLineChars, EOF, true);
			frase = StringUtils.trimToEmpty(frase);
			
			if (StringUtils.isNotBlank(frase)) {
				int lastSpace = frase.lastIndexOf(EOF);
//				System.out.println(lastSpace + ">> " +frase + " :: " + frase.length() + " ??[" + valor + "] $$ " + valor.length());

				frase = frase.substring(0,lastSpace);
				valor = valor.substring(frase.length());
				
				frase = (frase.startsWith("-") ? frase.replaceFirst("-", "") : frase);
//				System.out.println(frase + " <::> " + valor );
//				System.out.println(frase + " :: " + frase.length() + " ?? " + valor );
				frase = StringUtils.trimToEmpty(frase);
				result.add(frase);				
				line++;
//				System.out.println(prefijo.concat(frase) + " :: " + prefijo.concat(frase).length());
			}
		} while (valor.length() > 0 && result.size() < linesMax);
		
		return result;
	}

	public static String decodeFromUri(String strToDecode){
		if (StringUtils.isBlank(strToDecode)) {
			return null;
		}
		boolean isEncoded = true;
		try {
			new URI(strToDecode);
		} catch (URISyntaxException e) {
			isEncoded = false;
		}

		if (isEncoded) {
			try {
				return URLDecoder.decode(strToDecode, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				throw new RuntimeException("Error en URLDecoder.decode " + e.getMessage(), e);
			}
		}
		return strToDecode;
	}
	
	public static List<String> stringToList(String content) {
		List<String> lista = new ArrayList<>();
		try {
			final BufferedReader r = new BufferedReader(new StringReader(content));
			String l;
			while ((l = r.readLine()) != null) {
				lista.add(l);
			}
		} catch (final Exception e) {
			//log.error("Error in EOL correction: " + e);
		}
		return lista;
	}	
	
	public static int extractNumber(String strIn, String cini, String cfin) {
		if (StringUtils.isBlank(strIn)) {
			return -1;
		}
		String str = strIn.toLowerCase();
		int maxIndex = str.indexOf(cini) + cini.length();
		int textIndex = str.indexOf(cfin);
		if (maxIndex < 0|| textIndex < 0)
			return -1;
		String numStr = str.substring(maxIndex, textIndex);
		if (ValidatorCodes.isNumber(numStr)) {
			int num = Integer.parseInt(numStr);
			return num;			
		}
		return -1;
	}
	
	public static String truncateSuffix(String txt, int lenmax) {
		txt = (txt == null ? "" : txt).trim();
		return txt != null && txt.length() > lenmax ? txt.substring(0, lenmax - 3) + "..." : txt;
	}
}
