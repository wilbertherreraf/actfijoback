package gob.bcb.iso20022.pojo;

import org.apache.commons.lang3.StringUtils;

public class RmtInf {
	private String tpRmtInf = "";
	private String cd = "";
	private Integer lItem = 0;
	private String ustrd = "";
	private String formatStrd = "";
	
	public RmtInf() {
	}

	public String getTpRmtInf() {
		return tpRmtInf;
	}

	public void setTpRmtInf(String tpRmtInf) {
		this.tpRmtInf = tpRmtInf;
	}

	public String getCd() {
		return cd;
	}

	public void setCd(String cd) {
		this.cd = cd;
	}

	public Integer getlItem() {
		return lItem;
	}

	public void setlItem(Integer lItem) {
		this.lItem = lItem;
	}

	public String getUstrd() {
		return ustrd;
	}

	public void setUstrd(String ustrd) {
		this.ustrd = ustrd;
	}

	public String getFormatStrd() {
		return formatStrd;
	}

	public void setFormatStrd(String formatStrd) {
		this.formatStrd = formatStrd;
	}
	
	public String strLine() {
		return tpRmtInf + "|" +StringUtils.trimToEmpty(ustrd); 
	}	
}
