package gob.bcb.iso20022.transforms;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.rules.AbstractAction;
import gob.bcb.iso20022.rules.Action;
import gob.bcb.iso20022.rules.CompiledRule;
import gob.bcb.iso20022.swift.MappingRule;
import gob.bcb.iso20022.utils.UtilsGeneric;

/**
 * @author: wherrera
 * 
 */
public class TextSimpleTransform extends AbstractAction<MappingRule, CampoForm> {
	private static final Logger log = LoggerFactory.getLogger(TextSimpleTransform.class);
	public final static String name = TransformEnum.MTTOMX.toString();
	public final static String SWF_STATUS_MANDATORY = "R";//Required
	public TextSimpleTransform() {
		super(name);
	}

	@Override
	protected CampoForm initializeOutputResult(CompiledRule rule, MappingRule input) {
		return new CampoForm();
	}

	@Override
	public CampoForm execute(CompiledRule rule, MappingRule input, Map<String, Object> facts) {
		input.getMapFacts().forEach((k, v) -> {
			if (!StringUtils.isBlank(k) && v != null)
				facts.putIfAbsent(k, v);
		});

		if (StringUtils.isBlank(input.getRule().getAction())) {
			String valDef = StringUtils.trimToEmpty(input.getSwfCampo().getMtfDefault());
			if (!valDef.isEmpty()) {
				CampoForm output = new CampoForm();
				output.setTabla(rule.getRule().getNamespace());
				output.setColumn(rule.getRule().getName());
				output.setCatalogo(rule.getRule().getPath());
				output.setValor(valDef);

				return output;
			}
		}
		return null;
	}

	@Override
	public void postExecuteAction(CompiledRule rule, MappingRule input, CampoForm output, Map<String, Object> facts) {
		SwfMencampos swfCampo = input.getSwfCampo();
		if (output != null && output.getValorObj() != null && (output.getValorObj() instanceof CampoForm)) {
			CampoForm cfOut = (CampoForm) output.getValorObj();
			cfOut.setCatalogo(rule.getRule().getPath());
			
			if (isMandatory(swfCampo, cfOut)) {
				throw new RuntimeException("Valor requerido " + swfCampo.toStringID());
			}
			
			if (addOptional(swfCampo, cfOut)) {
				evalFormat(swfCampo, cfOut);
				//log.info(rule.getRule().getPath() + " POR AQUI");
				input.addCampo(cfOut);				
			}
		} else {
			output.setTabla(rule.getRule().getNamespace());
			output.setColumn(rule.getRule().getName());
			output.setCatalogo(rule.getRule().getPath());
			if (addOptional(swfCampo, output)) {
				evalFormat(swfCampo, output);
				//log.info(rule.getRule().getPath() + " POR AQUI(X)");
				input.updCFResult(output);				
			}
		}
	}

	@Override
	public void postExecuteSubAction(CompiledRule rule, Action sAction, MappingRule input, CampoForm output, Map<String, Object> facts) {
		if (output == null)
			return;

		output.setTabla(rule.getRule().getNamespace());
		output.setColumn(rule.getRule().getName());
		output.setCatalogo(rule.getRule().getPath());

		if (!StringUtils.isBlank(output.getTabla()) && output.getValorObj() != null) {
			input.setCampoForm(output);
		}
		input.updCFResult(output);
	}
	
	private static void evalFormat(SwfMencampos sc, CampoForm cf) {
		if (sc == null)
			return;
		if (!StringUtils.isBlank(cf.getValor()) && !StringUtils.isBlank(sc.getMtfFormato())) {
			int ln = UtilsGeneric.extractNumber(sc.getMtfFormato(), "max", "text");
			if (ln > 0 && cf.getValor().length() > ln) {
				String nc = cf.getValor().substring(0, ln);
				cf.setValor(nc);
			}
		}
	}
	
	private static boolean addOptional(SwfMencampos sc, CampoForm cf) {
		if (sc == null)
			return true;
		if (StringUtils.isBlank(cf.getValor()) && !StringUtils.isBlank(sc.getMtfStatus())) {
			boolean isStr = !StringUtils.isBlank(cf.getTipoValor()) && cf.getTipoValor().equalsIgnoreCase("string"); 
			if (sc.getMtfStatus().trim().equalsIgnoreCase("o") && isStr) {
				return false;
			}
		}		
		return true;
	}
	
	public static boolean isMandatory(SwfMencampos swf, CampoForm cf) {
		return StringUtils.isBlank(cf.getValor()) && (!StringUtils.isBlank(swf.getMtfStatus()) && swf.getMtfStatus().equals(SWF_STATUS_MANDATORY));
	}	
}
