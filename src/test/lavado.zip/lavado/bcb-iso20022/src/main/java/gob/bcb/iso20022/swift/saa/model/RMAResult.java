
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para RMAResult.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="RMAResult"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Success"/&gt;
 *     &lt;enumeration value="Bypassed"/&gt;
 *     &lt;enumeration value="NoRecord"/&gt;
 *     &lt;enumeration value="NotEnabled"/&gt;
 *     &lt;enumeration value="InvalidPeriod"/&gt;
 *     &lt;enumeration value="Unauthorised"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RMAResult")
@XmlEnum
public enum RMAResult {

    @XmlEnumValue("Success")
    SUCCESS("Success"),
    @XmlEnumValue("Bypassed")
    BYPASSED("Bypassed"),
    @XmlEnumValue("NoRecord")
    NO_RECORD("NoRecord"),
    @XmlEnumValue("NotEnabled")
    NOT_ENABLED("NotEnabled"),
    @XmlEnumValue("InvalidPeriod")
    INVALID_PERIOD("InvalidPeriod"),
    @XmlEnumValue("Unauthorised")
    UNAUTHORISED("Unauthorised");
    private final String value;

    RMAResult(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RMAResult fromValue(String v) {
        for (RMAResult c: RMAResult.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
