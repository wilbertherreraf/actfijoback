package gob.bcb.iso20022.pojo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.swift.TemplateGenFSwf;

public class Node<T> {

	private static final Logger log = LoggerFactory.getLogger(Node.class);
	private T swfMencampos;
	private T swfMencamposCrr;
	private T swfMencamposNxt;
	Node<T> parent;
	List<Node<T>> childArray;

	public Node() {
		// this.swfMencampos = new SwfMencampos();
		childArray = new ArrayList<>();
	}

	public Node(T swfMencampos) {
		this.swfMencampos = swfMencampos; // (T) SwfMencampos.cloneSwfMencampos((SwfMencampos) swfMencampos).get();
		childArray = new ArrayList<>();
	}

	public Node<T> getParent() {
		return parent;
	}

	public void setParent(Node<T> parent) {
		this.parent = parent;
	}

	public List<Node<T>> getChildArray() {
		return childArray;
	}

	public void setChildArray(List<Node<T>> childArray) {
		this.childArray = childArray;
	}

	public Node<T> addChild(Node<T> child) {
		if (!child.hasParent()) {
			childArray.add(child);
			child.setParent(this);
			// child.getParent().setParent(this);
		} else {
			Node<T> p = addChild(child.getParent());
		}
		// List<Node> childArray = getChildArray();
		// for (Node childn : childArray) {
		// this.childArray.add(new Node(childn));
		// }
		return this;
	}

//	public String getNombre() {
//		return nombre;
//	}
//
//	public void setNombre(String nombre) {
//		this.nombre = nombre;
//	}

	public T getSwfMencampos() {
		return swfMencampos;
	}

	public void setSwfMencampos(T swfMencampos) {
		if (swfMencampos instanceof SwfMencampos)
			this.swfMencampos = swfMencampos;
			//this.swfMencampos = (T) SwfMencampos.cloneSwfMencampos((SwfMencampos) swfMencampos).get();
		else
			this.swfMencampos = (T) swfMencampos;
	}

	public T getSwfMencamposCrr() {
		return swfMencamposCrr;
	}

	public void setSwfMencamposCrr(T swfMencamposCrr) {
		if (swfMencampos instanceof SwfMencampos)
			this.swfMencamposCrr = swfMencamposCrr;
			//this.swfMencamposCrr = (T) SwfMencampos.cloneSwfMencampos((SwfMencampos) swfMencamposCrr).get();
		else
			this.swfMencamposCrr = (T) swfMencamposCrr;
	}

	public T getSwfMencamposNxt() {
		return swfMencamposNxt;
	}

	public void setSwfMencamposNxt(T swfMencamposNxt) {
		if (swfMencampos instanceof SwfMencampos)
			this.swfMencamposNxt = swfMencamposNxt;
			//this.swfMencamposNxt = (T) SwfMencampos.cloneSwfMencampos((SwfMencampos) swfMencamposNxt).get();
		else
			this.swfMencamposNxt = (T) swfMencamposNxt;
	}

	public boolean hasParent() {
		return parent != null;
	}

	public boolean hasCurrent() {
		return swfMencamposCrr != null;
	}

	public boolean hasNext() {
		return swfMencamposNxt != null;
	}

	public void print(Integer level) {
		//String corr = String.format("%0" + (level + 1) + "d", 0);
		String corr = StringUtils.leftPad("", level, "0");		
		//if (swfMencampos instanceof SwfMencampos) {
			String padre = hasParent() && parent.getSwfMencampos() != null ? ((SwfMencampos) parent.getSwfMencampos()).toStringID() : " SIN PADRE";
			if (swfMencampos != null)
				log.info(corr + " " + padre + " : " + ((SwfMencampos) swfMencampos).toStringID() + " : " + childArray.size() + " _> " + ((SwfMencampos) swfMencampos).getMtfXmltag());
			else
				log.info(corr + " " + padre + " : NULO PADRE");
		//}
		childArray.forEach(ch -> {
			ch.print(level + 2);
		});
	}

	public String parentID() {
		if (swfMencampos != null && swfMencampos instanceof SwfMencampos)
			return hasParent() && parent.getSwfMencampos() != null ? ((SwfMencampos) parent.getSwfMencampos()).toStringID() : " SIN PADRE";
		else
			return null;
	}

	public String currentID() {
		if (swfMencampos != null && swfMencampos instanceof SwfMencampos)
			return hasCurrent() ? ((SwfMencampos) swfMencamposCrr).toStringID() : "";
		else
			return null;
	}

	public String nodoID() {
		if (swfMencampos != null && swfMencampos instanceof SwfMencampos)
			return swfMencampos != null ? ((SwfMencampos) swfMencampos).toStringID() : "";
		else
			return null;
	}

	public static Node createNodeDefault(String codMT, String bloque) {
		return new Node(createMencamposDefault(codMT, bloque).get());
	}

	public static <T> Supplier<T> createMencamposDefault(String codMT, String bloque) {
		return () -> {
			SwfMencampos swfMencamposCurr = new SwfMencampos();
			swfMencamposCurr.setMtfCodmt(codMT);
			swfMencamposCurr.setMtfNro(0);
			swfMencamposCurr.setMtfBloque(bloque);
			swfMencamposCurr.setMtfStatus(TemplateGenFSwf.SWF_STATUS_MANDATORY);
			swfMencamposCurr.setMtfNivel(1);

			return (T) swfMencamposCurr;
		};
	}

}
