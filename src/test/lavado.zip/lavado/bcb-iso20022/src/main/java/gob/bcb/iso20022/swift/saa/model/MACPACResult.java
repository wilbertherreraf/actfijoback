
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para MACPACResult.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="MACPACResult"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Success"/&gt;
 *     &lt;enumeration value="SuccessFuture"/&gt;
 *     &lt;enumeration value="SuccessOld"/&gt;
 *     &lt;enumeration value="Bypassed"/&gt;
 *     &lt;enumeration value="NoKey"/&gt;
 *     &lt;enumeration value="Failed"/&gt;
 *     &lt;enumeration value="InvalidDigest"/&gt;
 *     &lt;enumeration value="InvalidSignerDN"/&gt;
 *     &lt;enumeration value="InvalidCertPolicyID"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "MACPACResult")
@XmlEnum
public enum MACPACResult {

    @XmlEnumValue("Success")
    SUCCESS("Success"),
    @XmlEnumValue("SuccessFuture")
    SUCCESS_FUTURE("SuccessFuture"),
    @XmlEnumValue("SuccessOld")
    SUCCESS_OLD("SuccessOld"),
    @XmlEnumValue("Bypassed")
    BYPASSED("Bypassed"),
    @XmlEnumValue("NoKey")
    NO_KEY("NoKey"),
    @XmlEnumValue("Failed")
    FAILED("Failed"),
    @XmlEnumValue("InvalidDigest")
    INVALID_DIGEST("InvalidDigest"),
    @XmlEnumValue("InvalidSignerDN")
    INVALID_SIGNER_DN("InvalidSignerDN"),
    @XmlEnumValue("InvalidCertPolicyID")
    INVALID_CERT_POLICY_ID("InvalidCertPolicyID");
    private final String value;

    MACPACResult(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MACPACResult fromValue(String v) {
        for (MACPACResult c: MACPACResult.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
