package gob.bcb.iso20022.rules;

import java.io.Serializable;

import org.mvel2.MVEL;

import gob.bcb.iso20022.exceptions.CompileException;

public class CompiledRule {
	private final Rule rule;
	private final Serializable compiled;
	private Serializable compiledAction;

	public CompiledRule(Rule rule) {
		this.rule = rule;
		this.compiled = MVEL.compileExpression(rule.getExpression());
		// this.compiledAction = MVEL.compileExpression(rule.getAction());
	}

	public Rule getRule() {
		return rule;
	}

	public Serializable getCompiled() {
		return compiled;
	}

	public Serializable getCompiledAction() {
		return compiledAction;
	}

	public void compileAction(boolean throwExceptionIfCompilationFails) throws CompileException {
		if (compiledAction != null)
			return;
		
		try {
			this.compiledAction = MVEL.compileExpression(rule.getAction());
		} catch (org.mvel2.CompileException ex) {
			if (throwExceptionIfCompilationFails) {
				throw new CompileException("Failed to compile " + rule.getFullyQualifiedName() + ": " + ex.getMessage());
			}
		}
	}
}
