
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ReceiverDeliveryStatus.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="ReceiverDeliveryStatus"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="RcvDelivered"/&gt;
 *     &lt;enumeration value="RcvAborted"/&gt;
 *     &lt;enumeration value="RcvDelayedNak"/&gt;
 *     &lt;enumeration value="RcvFCPReleased"/&gt;
 *     &lt;enumeration value="RcvOverdue"/&gt;
 *     &lt;enumeration value="RcvUnknown"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ReceiverDeliveryStatus")
@XmlEnum
public enum ReceiverDeliveryStatus {

    @XmlEnumValue("RcvDelivered")
    RCV_DELIVERED("RcvDelivered"),
    @XmlEnumValue("RcvAborted")
    RCV_ABORTED("RcvAborted"),
    @XmlEnumValue("RcvDelayedNak")
    RCV_DELAYED_NAK("RcvDelayedNak"),
    @XmlEnumValue("RcvFCPReleased")
    RCV_FCP_RELEASED("RcvFCPReleased"),
    @XmlEnumValue("RcvOverdue")
    RCV_OVERDUE("RcvOverdue"),
    @XmlEnumValue("RcvUnknown")
    RCV_UNKNOWN("RcvUnknown");
    private final String value;

    ReceiverDeliveryStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ReceiverDeliveryStatus fromValue(String v) {
        for (ReceiverDeliveryStatus c: ReceiverDeliveryStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
