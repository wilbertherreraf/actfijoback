package gob.bcb.iso20022.pojo;

import org.apache.commons.lang3.StringUtils;

public class Acc extends Role{
	private String tpAcc="";
	private String idaccint="";
	private String idgen="";
	private String idacc="";
	private String currExch = "";
	private String iban="";
	private String contab="";
	private String accDescr="";
	private String accStat="";
	
	public Acc() {

	}
	
	public Acc(String tpAcc, String idgen, String idacc, String currExch, String accDescr) {
		this.tpAcc = tpAcc;
		this.idgen = idgen;
		this.idacc = idacc;
		this.currExch = currExch;
		this.accDescr = accDescr;
	}

	public Acc(String tpAcc, String iban) {
		this.tpAcc = StringUtils.trimToEmpty(tpAcc);
		this.iban = StringUtils.trimToEmpty(iban);
	}

	public String getIdgen() {
		return idgen;
	}
	public void setIdgen(String idgen) {
		this.idgen = idgen;
	}
	public String getIdacc() {
		return idacc;
	}
	public void setIdacc(String idacc) {
		this.idacc = StringUtils.trimToEmpty(idacc);
	}
	public String getContab() {
		return contab;
	}
	public void setContab(String contab) {
		this.contab = contab;
	}
	public String getAccDescr() {
		return accDescr;
	}
	public void setAccDescr(String descr) {
		this.accDescr = StringUtils.trimToEmpty(descr);
	}

	public String getAccStat() {
		return accStat;
	}

	public void setAccStat(String accStat) {
		this.accStat = accStat;
	}

	public String getTpAcc() {
		return tpAcc;
	}

	public void setTpAcc(String tpAcc) {
		this.tpAcc = tpAcc;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = StringUtils.trimToEmpty(iban);
	}

	public String getCurrExch() {
		return currExch;
	}

	public void setCurrExch(String currExch) {
		this.currExch = StringUtils.trimToEmpty(currExch);
	}

	public String getIdaccint() {
		return idaccint;
	}

	public void setIdaccint(String idaccint) {
		this.idaccint = idaccint;
	}

	@Override
	public String toString() {
		return idacc + "|" + iban + "|" + contab;
	}

	public String strLine() {
		return idacc + "|" + iban + "|" + contab;
	}
}
