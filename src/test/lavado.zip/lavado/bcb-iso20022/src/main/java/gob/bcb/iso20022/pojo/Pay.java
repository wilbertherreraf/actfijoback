package gob.bcb.iso20022.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class Pay {
	private String tpPay = ""; //
	private Integer litem = 0;
	private String coditem = "";	
	private String cd = "";
	private String desc = "";
	private String currPay = "";
	private BigDecimal amtPay = BigDecimal.ZERO;	
	private BigDecimal penal = BigDecimal.ZERO;
	private BigDecimal disco = BigDecimal.ZERO;
	private BigDecimal tax = BigDecimal.ZERO;
	private BigDecimal comis = BigDecimal.ZERO;
	private BigDecimal intcalc = BigDecimal.ZERO;
	private Date dtReq;
	private Date dtExe;

	private String idPaytrx = "";
	private String tpcarg = "";
	private String codoper = "";
	private String tpPayPart = "";// debt, cred, initial, debtag, credag, intermag, forwarding agent, instructed,
									// instructing, pay obligation, ult debtor, ult creditor

	public Pay() {
	}

	public String getTpPay() {
		return tpPay;
	}

	public void setTpPay(String tpPay) {
		this.tpPay = tpPay;
	}

	public String getCurrPay() {
		return currPay;
	}

	public void setCurrPay(String curr) {
		this.currPay = curr;
	}

	public BigDecimal getAmtPay() {
		return amtPay;
	}

	public void setAmt(BigDecimal amt) {
		this.amtPay = amt;
	}

	public Date getDtReq() {
		return dtReq;
	}

	public void setDtReq(Date dtReq) {
		this.dtReq = dtReq;
	}

	public Date getDtExe() {
		return dtExe;
	}

	public void setDtExe(Date dtExe) {
		this.dtExe = dtExe;
	}

	public String getTpPayPart() {
		return tpPayPart;
	}

	public void setTpPayPart(String tpPayPart) {
		this.tpPayPart = tpPayPart;
	}

	public String getIdPaytrx() {
		return idPaytrx;
	}

	public void setIdPaytrx(String idPaytrx) {
		this.idPaytrx = idPaytrx;
	}

	public Integer getLitem() {
		return litem;
	}

	public void setLitem(Integer litem) {
		this.litem = litem;
	}

	public String getCoditem() {
		return coditem;
	}

	public void setCoditem(String coditem) {
		this.coditem = coditem;
	}

	public String getTpcarg() {
		return tpcarg;
	}

	public void setTpcarg(String tpcarg) {
		this.tpcarg = tpcarg;
	}

	public String getCodoper() {
		return codoper;
	}

	public void setCodoper(String codoper) {
		this.codoper = codoper;
	}

	public BigDecimal getPenal() {
		return penal;
	}

	public void setPenal(BigDecimal penal) {
		this.penal = penal;
	}

	public BigDecimal getDisco() {
		return disco;
	}

	public void setDisco(BigDecimal disco) {
		this.disco = disco;
	}

	public BigDecimal getTax() {
		return tax;
	}

	public void setTax(BigDecimal tax) {
		this.tax = tax;
	}

	public BigDecimal getComis() {
		return comis;
	}

	public void setComis(BigDecimal comis) {
		this.comis = comis;
	}

	public BigDecimal getIntcalc() {
		return intcalc;
	}

	public void setIntcalc(BigDecimal intcalc) {
		this.intcalc = intcalc;
	}

	public String getCd() {
		return cd;
	}

	public void setCd(String cd) {
		this.cd = cd;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
