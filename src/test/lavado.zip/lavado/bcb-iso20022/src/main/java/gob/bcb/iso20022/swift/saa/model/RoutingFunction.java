
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para RoutingFunction.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="RoutingFunction"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Route"/&gt;
 *     &lt;enumeration value="DisposeToRoutingStep"/&gt;
 *     &lt;enumeration value="DisposeToRoutingPoint"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RoutingFunction")
@XmlEnum
public enum RoutingFunction {

    @XmlEnumValue("Route")
    ROUTE("Route"),
    @XmlEnumValue("DisposeToRoutingStep")
    DISPOSE_TO_ROUTING_STEP("DisposeToRoutingStep"),
    @XmlEnumValue("DisposeToRoutingPoint")
    DISPOSE_TO_ROUTING_POINT("DisposeToRoutingPoint");
    private final String value;

    RoutingFunction(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RoutingFunction fromValue(String v) {
        for (RoutingFunction c: RoutingFunction.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
