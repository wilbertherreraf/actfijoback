package gob.bcb.iso20022.lau;

import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
//import org.apache.ws.commons.schema.utils.DOMUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.prowidesoftware.swift.model.mx.JaxbContextLoader;

import gob.bcb.iso20022.core.xml.JaxBConversionService;
import gob.bcb.iso20022.swift.saa.xmldsig.SignatureType;

public class LAU {
	private static final Logger log = LoggerFactory.getLogger(LAU.class);
	static final String ALGO_HMAC_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#hmac-sha256";
	static final String EXCL_XML_N14C = "http://www.w3.org/2001/10/xml-exc-c14n#";
	static final String ALGO_SHA256 = "http://www.w3.org/2001/04/xmlenc#sha256";
	static final String DS_NS = "http://www.w3.org/2000/09/xmldsig#";
	static final String HMAC_SHA256 = "HmacSHA256";
	static final String NS_SAA = "urn:swift:saa:xsd:saa.2.0";
	static final String NS_SAA_LAU = "Saa:LAU";
	static final String NS_XMLNS = "xmlns:Saa";

	private static final int BYTE_BUFFER_SIZE = 10000;

	private Document docSign;
	private SecretKeySpec secretKey;
	private SignatureType signature;
	private String xmlOrig;
	private boolean hasSignature = false;
	final static transient Class[] _classes = new Class[] { SignatureType.class };
	
	public LAU extractSignatureFromXml(String xml) {
		xmlOrig = xml;
		signature = null;
		docSign = JaxBConversionService.getDomFromString(xml);
		NodeList sigList = docSign.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
		if (sigList.getLength() == 0) {
			return this;			
		}else {
			signature = extractSignature(docSign,false);
			return this; //signXmlV2(xml, null, false);			
		}
	}
	private SignatureType extractSignature(Document docSigned, boolean errorIfExistSign) {
		try {
			NodeList sigList = docSigned.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
			if (sigList.getLength() == 0) {
				if (errorIfExistSign) {
					throw new Exception("Cannot find Signature element");
				}
				return null;
			}
			Node node = sigList.item(0);
			JAXBContext context = JaxbContextLoader.INSTANCE.get(SignatureType.class, _classes);
			String sxml = JaxBConversionService.node2XML(node);

			Unmarshaller u = context.createUnmarshaller();
			JAXBElement<SignatureType> a = (JAXBElement<SignatureType>) u.unmarshal(new StringReader(sxml));

			SignatureType s = a.getValue();
			return s;
		} catch (Exception e) {
			log.error("Error al extraer firma " + e.getMessage(), e);
			if (errorIfExistSign)
				throw new RuntimeException("Error al transgormar Firma: " + e.getMessage(), e);
		}
		return null;
	}

	public LAU settingKey(AuthParameters authParameters) {
		if (authParameters != null) {
			try {
				secretKey = authParameters.getKey();
			} catch (Exception e) {
				throw new RuntimeException("Error al configurar Key LAU " + e.getMessage());
			}
		}
		return this;
	}

	public String signXmlV2(String xml) {
		if (StringUtils.isBlank(xml))
			throw new RuntimeException("Xml a firmar nulo");
		signature = null;
		xmlOrig = xml;
		Document doc = JaxBConversionService.getDomFromString(xml);		
		//removeNodeLau(docSign);
		String signed = signXmlV2(doc);
		return signed;
	}

	public String signXmlV2(Document doc) {
		signLAU(doc);
		docSign = doc;
		String signed = JaxBConversionService.getStringFromDom(docSign);
		return signed;		
	}

	public String signXmlV2(String xml, AuthParameters authParameters) {
		signature = null;
		settingKey(authParameters);
		String signed = signXmlV2(xml);

		return signed;
	}

	private void signLAU(Document document) {
		try {
			if (secretKey == null) {
				throw new RuntimeException("Process LAU: Key not found");
			}
			
			XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");
			SignatureMethod signatureMethod = factory.newSignatureMethod(ALGO_HMAC_SHA256, null);

			CanonicalizationMethod canonicalizationMethod = factory.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (XMLStructure) null);

			List<Transform> transforms = new ArrayList<Transform>();
			transforms.add(factory.newTransform(Transform.ENVELOPED, (XMLStructure) null));
			transforms.add(factory.newTransform(EXCL_XML_N14C, (XMLStructure) null));

			DigestMethod digestMethod = factory.newDigestMethod(ALGO_SHA256, null);

			Reference reference = factory.newReference("", digestMethod, transforms, null, null);

			SignedInfo signedInfo = factory.newSignedInfo(canonicalizationMethod, signatureMethod, Collections.singletonList(reference));

			Element LAUElement = document.createElement(NS_SAA_LAU);
			Element rootElement = document.getDocumentElement();
			rootElement.appendChild(LAUElement);

			DOMSignContext domSignContext = new DOMSignContext(secretKey, LAUElement);
			domSignContext.setDefaultNamespacePrefix("ds");

			XMLSignature signature = factory.newXMLSignature(signedInfo, null);
			signature.sign(domSignContext);
		} catch (Exception e) {
			throw new RuntimeException("Error al firmar con LAU: " + e.getMessage(), e);
		}
	}

	private boolean validate(Document doc) {
		try {
			if (secretKey == null)
				throw new RuntimeException("No existe llave LAU configurada.");

			XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");

			NodeList sigList = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
			
			if (sigList.getLength() == 0) {
				throw new Exception("Cannot find Signature element");
			}

			SecretKeySpec secret_key = secretKey;
			DOMValidateContext valContext = new DOMValidateContext(secret_key, sigList.item(0));
			XMLSignature xmlSignature = factory.unmarshalXMLSignature(valContext);
			boolean valid = xmlSignature.validate(valContext);
			return valid;
		} catch (Exception e) {
			throw new RuntimeException("Error al validar LAU: " + e.getMessage(), e);
		}
	}

    public boolean validateLAU(Document doc){
		try {
			if (doc == null) {
				throw new RuntimeException("Documento a firmar nulo.");
			}
			Element dataPDU = findFirst(doc.getDocumentElement(), NS_SAA, "DataPDU");
			if (dataPDU == null)
				throw new IllegalStateException("No se encontró <saa:DataPDU>.");

			Element lau = firstChildNS(dataPDU, NS_SAA, "LAU");
			if (lau == null)
				throw new IllegalStateException("No se encontró <saa:LAU> dentro de <saa:DataPDU>.");

			Element dsSig = firstChildNS(lau, DS_NS, "Signature");
			if (dsSig == null)
				throw new IllegalStateException("No se encontró <ds:Signature> bajo <saa:LAU>.");

			Node lauNextSibling = lau.getNextSibling(); // para reinsertarlo en la misma posición
			Node lauParent = lau.getParentNode(); // == dataPDU
			lauParent.removeChild(lau);

            XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");

            SecretKeySpec hmacKey = secretKey;
            DOMValidateContext ctx = new DOMValidateContext(hmacKey, dsSig);

            markIdAttributesRecursively(doc.getDocumentElement(), "Id");
            if (dataPDU.hasAttribute("Id")) {
                ctx.setIdAttributeNS(dataPDU, null, "Id");
            }

            XMLSignature sig = fac.unmarshalXMLSignature(ctx);
            boolean coreValid = sig.validate(ctx);
            return coreValid;

		} catch (Exception e) {
			throw new RuntimeException("Error al validar LAU: " + e.getMessage(), e);
		}
	}

	public boolean hasSignature() {
		if (docSign == null)
			return false;
		NodeList sigList = docSign.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
		boolean hasSign = sigList.getLength() > 0;
		return hasSign ;
	}

	public boolean hasSaaLAU() {
		NodeList nl = docSign.getElementsByTagNameNS(NS_SAA, "LAU");
		return nl.getLength() > 0;
	}

	public boolean validate(String signedXml) {

		if (!hasSignature() || signedXml == null) {
			return false;
		}
		Document doc = JaxBConversionService.getDomFromString(signedXml);
		return validate(doc);
	}

	public boolean validate(String signedXml, AuthParameters authParameters) {
		Document docSigned = JaxBConversionService.getDomFromString(signedXml);
		settingKey(authParameters);
		return validate(docSigned);
	}


	public SignatureType extractSignatureType() {
		if (signature == null)
			signature = extractSignature(docSign, false);
		return signature;
	}

	public static String removeNodeLau(String xml) {
		Document doc = JaxBConversionService.getDomFromString(xml);
		removeNodeLau(doc);
		String xmlNew = JaxBConversionService.getStringFromDom(doc);
		return xmlNew;
	}
	public static void removeNodeLau(Document doc) {
		Element dataPDU_real = findFirst(doc.getDocumentElement(), NS_SAA, "DataPDU");;
		Element eNew = removeLauElement(dataPDU_real);
		
	}

    public static Element removeLauElement(Element dataPDU) {
        NodeList nl = dataPDU.getElementsByTagNameNS(NS_SAA, "LAU");
        Element lau = null;
        if (nl.getLength() > 0) {
            lau = (Element) nl.item(0);
            while (lau.hasChildNodes()) 
				lau.removeChild(lau.getFirstChild());
        }  else {
			return null;
		}
		
		while (lau.hasChildNodes()) 
            lau.removeChild(lau.getFirstChild());		
        return lau;
    }

	private boolean validateLAU(String signedXml) {
		Document doc = JaxBConversionService.getDomFromString(signedXml);
		return validateLAU(doc);
	}

	private boolean validateSigLAU(String signedXml) {
		Document doc = JaxBConversionService.getDomFromString(signedXml);
		NodeList nl = doc.getElementsByTagNameNS(NS_SAA, "LAU");			
		if (nl.getLength() == 0) {
			throw new RuntimeException("Xml no tiene rama " + NS_SAA_LAU);
		}

		return validate(doc);
	}	

	public String getDigestValue() {
		return JaxBConversionService.valueOfTag(docSign, "DigestValue");
	}

	public String getSignatureValue() {
		return JaxBConversionService.valueOfTag(docSign, "SignatureValue");
	}

	public String getSignedInfo() {
		Node node = JaxBConversionService.findTagInDoc(docSign, "SignedInfo");
		return JaxBConversionService.node2XML(node,true, true);
	}

	public String getSignedInfoCanno() {
		Node node = JaxBConversionService.findTagInDoc(docSign, "SignedInfo");
		return JaxBConversionService.node2XMLCanno(node);
	}
	
	public String getPayLoadCanno(String tag) {
		Node node = JaxBConversionService.findTagInDoc(docSign, tag);
		return JaxBConversionService.node2XMLCanno(node);
	}
	
	public static String generateHMacSHA256(final String key, final String data) {
		try {
			final Mac hMacSHA256 = Mac.getInstance(HMAC_SHA256);
			byte[] hmacKeyBytes = key.getBytes(StandardCharsets.UTF_8);
			final SecretKeySpec secretKey = new SecretKeySpec(hmacKeyBytes, HMAC_SHA256);
			hMacSHA256.init(secretKey);
			byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
			byte[] res = hMacSHA256.doFinal(dataBytes);

			return DatatypeConverter.printBase64Binary(res);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static String hmacDigest(String msg, String keyString, String algo) {
		String digest = null;
		try {
			SecretKeySpec key = new SecretKeySpec((keyString).getBytes(StandardCharsets.UTF_8), algo);
			Mac mac = Mac.getInstance(algo);
			mac.init(key);

			byte[] bytes = mac.doFinal(msg.getBytes("ASCII"));

			StringBuffer hash = new StringBuffer();
			for (int i = 0; i < bytes.length; i++) {
				String hex = Integer.toHexString(0xFF & bytes[i]);
				if (hex.length() == 1) {
					hash.append('0');
				}
				hash.append(hex);
			}
			digest = hash.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return digest;
	}

	public byte[] sign(InputStream pContent) {
		try {
			final Mac mac = Mac.getInstance(HMAC_SHA256);
			mac.init(secretKey);
			final byte[] buffer = new byte[BYTE_BUFFER_SIZE];
			int len = pContent.read(buffer);
			while (len > 0) {
				mac.update(buffer, 0, len);
				len = pContent.read(buffer);
			}
			return mac.doFinal();

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public String sign(String content) {
		byte[] s = sign(content.getBytes(StandardCharsets.UTF_8));
		return DatatypeConverter.printHexBinary(s);
	}
	
	public byte[] sign(byte[] pContent) {
		try {
			final Mac mac = Mac.getInstance(HMAC_SHA256);
			mac.init(secretKey);
			return mac.doFinal(pContent);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static String digest(String in) {
		final byte[] hash = DigestUtils.sha256(in);
		return Base64.encodeBase64String(hash);
	}

	public SecretKeySpec getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(SecretKeySpec secret_key) {
		this.secretKey = secret_key;
	}

    private static void markIdAttributesRecursively(Element e, String idLocalName) {
        if (e.hasAttribute(idLocalName)) {
            e.setIdAttribute(idLocalName, true);
        }
        NodeList nl = e.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            if (n instanceof Element) {
                markIdAttributesRecursively((Element) n, idLocalName);
            }
        }
    }	

	private static Element findFirst(Element start, String ns, String local) {
        if (start == null)
            return null;
        if (local.equals(start.getLocalName()) && ns.equals(start.getNamespaceURI()))
            return start;
        NodeList nl = start.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            if (n instanceof Element) {
                Element e = findFirst((Element) n, ns, local);
                if (e != null)
                    return e;
            }
        }
        return null;
    }
    private static Element firstChildNS(Element parent, String ns, String ln) {
        NodeList nl = parent.getElementsByTagNameNS(ns, ln);
        return nl.getLength() > 0 ? (Element) nl.item(0) : null;
    }

	// public byte[] si() {
	// 	try {
	// 		NodeList sigList = docSign.getElementsByTagNameNS(XMLSignature.XMLNS, "SignedInfo");
	// 		XMLSignatureFactory factory = XMLSignatureFactory.getInstance("DOM");
	// 		DOMValidateContext context = new DOMValidateContext(secretKey, sigList.item(0));
			
	// 		CanonicalizationMethod canonicalizationMethod = factory.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (XMLStructure) null);
			
	// 		Element siElem = DOMUtil.getFirstChildElement(sigList.item(0), "SignedInfo");

	// 		final Mac hmac = Mac.getInstance(HMAC_SHA256);
	// 		hmac.init(secretKey);
	// 		return hmac.doFinal();
	// 	} catch (Exception e) {
	// 		throw new RuntimeException("Error al validar LAU: " + e.getMessage(), e);
	// 	}
	// }
	
}
