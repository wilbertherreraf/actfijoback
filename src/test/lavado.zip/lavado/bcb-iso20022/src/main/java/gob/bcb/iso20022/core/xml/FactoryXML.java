package gob.bcb.iso20022.core.xml;

import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.XPath;

import com.github.simy4.xpath.XmlBuilder;

public class FactoryXML {
	private String isoVersion;
	private final Set<Object> keys = new LinkedHashSet<>();
	private Map<String, Object> xpathToValueMap = new LinkedHashMap<String, Object>();
	private XmlBuilder xmlBuilder = new XmlBuilder();
	private Document document;

	public FactoryXML() {

	}

//	public Map<String, Object> getXpathToValueMap() {
//		return xpathToValueMap;
//	}

	public void createDocument() {
		document = xmlBuilder.build(DocumentHelper.createDocument());
	}

	public Document getDocument() {
		return document;
	}

	public FactoryXML genDocument() throws Exception {
		xmlBuilder.putAll(xpathToValueMap);
		document = xmlBuilder.build(DocumentHelper.createDocument());
		return this;
	}

	public FactoryXML addExpresion(String key, Object value) {
		keys.add(key);
		xpathToValueMap.put(key, value);
		return this;
	}

	public FactoryXML addExpresion(String key, String value) {
		keys.add(key);
		xpathToValueMap.put(key, value);
		return this;
	}

	public synchronized FactoryXML remove(Object key) {
		keys.remove(key);
		xpathToValueMap.remove(key);
		return this;
	}

	public synchronized Enumeration<Object> keys() {
		return Collections.enumeration(keys);
	}

	public synchronized Map<String, Object> toMap() {
		Map<String, Object> map = new LinkedHashMap<String, Object>(keys.size());
		for (Object orderedKey : keys) {
			map.put(String.valueOf(orderedKey), xpathToValueMap.get(orderedKey));
		}
		return map;
	}
}
