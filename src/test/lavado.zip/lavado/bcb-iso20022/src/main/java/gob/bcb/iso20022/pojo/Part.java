package gob.bcb.iso20022.pojo;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

public class Part extends Role{
	private String codPartInt = "";	
	private String nm = "";
	private String idpart = "";
	private String tpPart = "";// Debtor ,Creditor, Ultimate Debtor, Ultimate Creditor, Initiating Party, Account Owner
	private String address="";
	private String strtNm="";                               
	private String bldgNb="";                                       
	private String bldgNm = "";	
	private String twnNm="";                                        
	private String ctry="";
	private String ctrySubDvsn = "";	
	private String dept = "";	
	private String pstCd = "";
	private String acron="";
	private String tpIden=""; // organization, person
	private String cd="";
	private String bic="";	
	private String contact="";
	private String loc="";
	private String nmOrg="";
	private String nmPer="";
	private String mmbId = "";
	private String dn = "";
	
	public Part() {
	}
	
	public Part(String codPartInt, String nm, String address, String strtNm, String bldgNb, String twnNm, String ctry, String acron) {
		this.codPartInt = codPartInt;
		this.nm = nm;
		this.address = address;
		this.strtNm = strtNm;
		this.bldgNb = bldgNb;
		this.twnNm = twnNm;
		this.ctry = ctry;
		this.acron = acron;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = StringUtils.trimToEmpty(address);
	}
	public String getStrtNm() {
		return strtNm;
	}
	public void setStrtNm(String strtNm) {
		this.strtNm = StringUtils.trimToEmpty(strtNm);
	}
	public String getBldgNb() {
		return bldgNb;
	}
	public void setBldgNb(String bldgNb) {
		this.bldgNb = StringUtils.trimToEmpty(bldgNb);
	}
	public String getTwnNm() {
		return twnNm;
	}
	public void setTwnNm(String twnNm) {
		this.twnNm = StringUtils.trimToEmpty(twnNm);
	}
	public String getCtry() {
		return ctry;
	}
	public void setCtry(String ctry) {
		this.ctry = StringUtils.trimToEmpty(ctry);
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = StringUtils.trimToEmpty(nm);
	}
	public String getIdpart() {
		return idpart;
	}
	public void setIdpart(String idpart) {
		this.idpart = idpart;
	}
	public String getTpPart() {
		return StringUtils.trimToEmpty(tpPart);
	}
	public void setTpPart(String tpPart) {
		this.tpPart = tpPart;
	}

	public String getCodPartInt() {
		return codPartInt;
	}

	public void setCodPartInt(String codPartInt) {
		this.codPartInt = StringUtils.trimToEmpty(codPartInt);
	}

	public String getAcron() {
		return acron;
	}

	public void setAcron(String acron) {
		this.acron = StringUtils.trimToEmpty(acron);
	}
	
	public String getTpIden() {
		return tpIden;
	}
	public void setTpIden(String tpIden) {
		this.tpIden = tpIden;
	}
	public String getCd() {
		return cd;
	}
	public void setCd(String cd) {
		this.cd = StringUtils.trimToEmpty(cd);
	}
	public String getBic() {
		return bic;
	}
	public void setBic(String bic) {
		this.bic = StringUtils.trimToEmpty(bic);
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}                                              

	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getNmOrg() {
		return nmOrg;
	}
	public void setNmOrg(String nmOrg) {
		this.nmOrg = StringUtils.trimToEmpty(nmOrg);
	}
	public String getNmPer() {
		return nmPer;
	}
	public void setNmPer(String nmPer) {
		this.nmPer = nmPer;
	}

	public String getMmbId() {
		return StringUtils.trimToEmpty(mmbId);
	}

	public void setMmbId(String mmbId) {
		this.mmbId = StringUtils.trimToEmpty(mmbId);
	}

	@Override
	public String toString() {
		return getRole() + "[" + codPartInt + "," + nm + "," + idpart + "," + tpPart + "," + address + "," + strtNm
				+ "," + bldgNb + "," + twnNm + "," + ctry + "," + tpIden + "," + cd + "," + bic + "," + mmbId
				+ "]";
	}

	public String strLine() {
		return codPartInt + "|" + nm + "|" + address + "|" + strtNm + "|" + twnNm + "|" + ctry + "|" + cd + "|" + bic + "|" + mmbId
				+ "";
	}

	public String getCtrySubDvsn() {
		return ctrySubDvsn;
	}

	public void setCtrySubDvsn(String ctrySubDvsn) {
		this.ctrySubDvsn = ctrySubDvsn;
	}

	public String getBldgNm() {
		return bldgNm;
	}

	public void setBldgNm(String bldgNm) {
		this.bldgNm = bldgNm;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getPstCd() {
		return pstCd;
	}

	public void setPstCd(String pstCd) {
		this.pstCd = pstCd;
	}

	public String getDn() {
		return dn;
	}

	public void setDn(String dn) {
		this.dn = dn;
	}
	
//	public String toLinea() {
//		String linea = Arrays.asList(getPartTabla(), componenteField).stream().filter(cad -> cad != null && cad.trim().length() > 0)
//				.collect(Collectors.joining(separatorTabProp));
//		return linea;
//	}
	
	
}
