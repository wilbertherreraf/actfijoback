package gob.bcb.iso20022.excel.core;

import gob.bcb.iso20022.excel.component.context.ExcelContext;

import gob.bcb.iso20022.excel.core.factory.CsvFactory;
import gob.bcb.iso20022.excel.utils.CommonFileUtils;
import gob.bcb.iso20022.excel.utils.CsvUtils;
import gob.bcb.iso20022.excel.utils.ExcelUtils;

//import org.apache.commons.csv.CSVPrinter;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @Author JoeBig7
 * @date 2021/7/16 16:39:56
 * @description generic excel writer class
 */
public class GenericWriter extends AbstractWriter {

    public GenericWriter(String path) {
        super(path);
    }

    /**
     *
     * @param workbook
     */
    @Override
    protected void doExcelWrite(Workbook workbook) {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(path);
            ExcelContext componentContext = getDefaultComponentContext(workbook);
            componentContext.combine().write(fos);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            CommonFileUtils.closeOutputStream(fos);
            ExcelUtils.closeWorkbook(workbook);
        }
    }

    @Override
    protected void doCsvWrite(String path) {
//        CSVPrinter csvPrinter = CsvFactory.writeInstance(path);
//        try {
//            CsvUtils.write(csvPrinter, headerDataList, contentDataList);
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            CsvUtils.flush(csvPrinter);
//            CsvUtils.close(csvPrinter);
//        }
    }

    private ExcelContext getDefaultComponentContext(Workbook workbook) {
        ExcelContext componentContext = new ExcelContext(workbook, headerDataList, contentDataList);
        return componentContext;
    }
}