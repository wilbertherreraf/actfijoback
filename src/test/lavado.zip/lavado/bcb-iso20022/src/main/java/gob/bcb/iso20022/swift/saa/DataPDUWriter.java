package gob.bcb.iso20022.swift.saa;

import java.io.StringReader;
import java.util.Objects;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlSchema;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.dom.DOMResult;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.prowidesoftware.swift.model.MxSwiftMessage;
import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.prowidesoftware.swift.model.mx.AppHdr;
import com.prowidesoftware.swift.model.mx.DefaultEscapeHandler;
import com.prowidesoftware.swift.model.mx.EscapeHandler;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;
import com.prowidesoftware.swift.model.mx.MxWriteConfiguration;
import com.prowidesoftware.swift.model.mx.MxWriteImpl;
import com.prowidesoftware.swift.model.mx.MxWriteParams;
import com.prowidesoftware.swift.model.mx.adapters.TypeAdaptersConfiguration;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

import gob.bcb.iso20022.core.xml.JaxBConversionService;
import gob.bcb.iso20022.lau.AuthParameters;
import gob.bcb.iso20022.lau.LAU;
import gob.bcb.iso20022.swift.saa.model.AddressFullName;
import gob.bcb.iso20022.swift.saa.model.AddressInfo;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.swift.saa.model.Header;
import gob.bcb.iso20022.swift.saa.model.InterfaceInfo;
import gob.bcb.iso20022.swift.saa.model.Message;
import gob.bcb.iso20022.swift.saa.model.NetworkInfo;
import gob.bcb.iso20022.swift.saa.model.SubFormat;
import gob.bcb.iso20022.swift.saa.model.SwAny;
import gob.bcb.iso20022.utils.MxDataTypesConversor;
import gob.bcb.iso20022.utils.UtilsFile;

/**
 * @author: wherrera
 * 
 */
public class DataPDUWriter {
	private static final Logger log = LoggerFactory.getLogger(DataPDUWriter.class);
	public final static String DATAPDU_NAME = "DataPDU";
	private MxWriteParams params = new MxWriteParams();
	private AbstractMX mx;
	private DataPDU dataPDU;
	private Document docDataPDU;
	private String saaXml;
	private String xmlDoc;
	private String xmlSigned;
	final static transient Class[] _classes = new Class[] { DataPDU.class };
	private LAU signerLau;

	public DataPDUWriter() {
		params = new MxWriteParams();
		dataPDU = new DataPDU();
		createConfig("", false, new DefaultEscapeHandler(), new TypeAdaptersConfiguration(), null, null);
	}
	public DataPDUWriter(final AbstractMX mx) {
		this();
		this.mx = mx;
	}

	public DataPDUWriter createConfig(String prefix, boolean includeXMLDeclaration, EscapeHandler escapeHandler, TypeAdaptersConfiguration adapters,
			JAXBContext context, String indent) {
		params.prefix = prefix;
		params.includeXMLDeclaration = includeXMLDeclaration;
		params.escapeHandler = escapeHandler;
		if (adapters != null)
			params.adapters = adapters;

		 if (context != null)
		 	params.context = context;
		params.indent = indent;

		return this;
	}

	public DataPDUWriter createDataPDU(AbstractMX mx) {
		Objects.requireNonNull(mx, "Objecto MX no debe ser nulo");
		this.mx = mx;		
		initBody();		
		xmlDoc = mx.message();
		dataPDU = parserToDataPDU(xmlDoc);

		if (!hasBody()) {
			SwAny swAny = new SwAny();
			swAny.getContent().add(mx);
			dataPDU.setBody(swAny);
		}
		log.info("xml con formato pdu hasheader ? {} body {} lau {}", hasHeader(),hasBody(), hasLau());		
		return this;
	}

	public DataPDUWriter createDataPDU(String xml) {
		Validate.notBlank(xml, "XML DataPDU a parsear no debe ser blanco");						
		initBody();
		xmlDoc = xml;
		this.mx = AbstractMX.parse(xml);
		log.info("MX {} {}", mx.getMxId().id(), mx.getMxId().camelized());
		dataPDU = parserToDataPDU(xmlDoc);
		if (!hasBody()) {
			SwAny swAny = new SwAny();
			swAny.getContent().add(mx);
			dataPDU.setBody(swAny);
		}
		log.info("Xml con formato pdu hasheader ? {} body {} lau {}", hasHeader(),hasBody(), hasLau());				
		return this;
	}

	// crea el objeto clon DataPDU
	public static DataPDU parserToDataPDU(String xmlSource) {
		Validate.notBlank(xmlSource, "XML DataPDU a parsear no debe ser blanco");
		try {
			int pos = xmlSource.indexOf(DATAPDU_NAME);
			if (pos >= 0) {
				JAXBContext context = JaxbContextLoader.INSTANCE.get(DataPDU.class, _classes);

				Unmarshaller u = context.createUnmarshaller();
				DataPDU dataPDU = (DataPDU) u.unmarshal(new StringReader(xmlSource));
				return dataPDU;
			} else {
				log.warn("XML no contiene el tag {}, se procede crear DataPDU x default", DATAPDU_NAME);				
				DataPDU dataPDU = new DataPDU();
				dataPDU.setBody(new SwAny());
				return dataPDU;
			}
		} catch (Exception e) {
			throw new RuntimeException("DataPDU no pudo ser desparceado(vea errores anteriores): " + e.getMessage(), e);
		}
	}

	public String xmlSaa() {
		if (saaXml == null)
			buildXmlSaa();
		return saaXml;
	}

	public String xmlSaaV1() {
		// Todo: whf version 2.0.0
		Document doc = toDoc();
		String saaXml = JaxBConversionService.getStringFromDom(doc);

		if (StringUtils.isBlank(saaXml)) {
			throw new RuntimeException("Cadena XML de DataPDU nulo");
		}
		String xmlBz = message();
		if (StringUtils.isBlank(xmlBz)) {
			return saaXml;
		}
		return embeddedSaa(saaXml, xmlBz);
	}

	public DataPDUWriter buildXmlSaa(){
		xmlSigned = null;
		docDataPDU = docFromDataPdu(dataPDU);
		String saaDataPDUIni = JaxBConversionService.getStringFromDom(docDataPDU);

		if (StringUtils.isBlank(saaDataPDUIni)) {
			throw new RuntimeException("Cadena XML de DataPDU nulo");
		}
		String xmlBz = message();
		if (StringUtils.isBlank(xmlBz)) {
			return this;
		}
		saaXml = embeddedSaa(saaDataPDUIni, xmlBz);		
		log.info("Construyendo saaXML header {} body {} lau {}--->", hasHeader(), hasBody(), hasLau());
		// log.info("saaXmlWithoutPdu:>>>>>>>  {}",saaDataPDUIni);		
		// log.info("xml Document:>>>>>>>  {}",xmlBz);				
		// log.info("Result :>>>>>>>  {}",saaXml);						
		return this;
	}

	private String buidPartDocument(MxWriteParams params) {
		params.includeXMLDeclaration = false;
		String xml = MxWriteImpl.write(mx.getNamespace(), mx, mx.getClasses(), params);
		Document doc = JaxBConversionService.getDomFromString(xml);

		return JaxBConversionService.getStringFromDom(doc, false);
	}
	private String document(AbstractMX mx, MxWriteParams params) {
		params.includeXMLDeclaration = false;
		String xml = MxWriteImpl.write(mx.getNamespace(), mx, mx.getClasses(), params);
		Document doc = JaxBConversionService.getDomFromString(xml);
		String xmlDoc = JaxBConversionService.getStringFromDom(doc, false);
		return xmlDoc;
	}

	private String message() {
		if (mx == null) {
			throw new RuntimeException("Proceso de obtener xml SAA requiere objeto MX");
		}
		
		MxWriteConfiguration usableConf = new MxWriteConfiguration();
		usableConf.includeXMLDeclaration = false;

		StringBuilder xml = new StringBuilder();

		params.prefix = null;
		params.indent = "";
		
		final String header = header(mx.getAppHdr(), params);
		if (header != null) {
			xml.append(header);
		}
		xmlDoc = buidPartDocument(params);
		xml.append(xmlDoc);
		return xml.toString();		
	}

	private String header(AppHdr appHdr, MxWriteParams params) {
		if (appHdr == null) {
			return null;
		}

		params.includeXMLDeclaration = false;
		String xml = appHdr.xml(params);
		return xml;
	}
	
	public DataPDUWriter xmlPduFromFile(String nFile) {
		String xmlPDU = UtilsFile.readFileAsString2(nFile);
		return createDataPDU(xmlPDU);
	}

	public String signSaaXml() {
		if (signerLau == null)
			throw new RuntimeException("Objeto firmador LAU nulo");

		if (saaXml == null) 
			buildXmlSaa();

		if (xmlSigned == null) {
			if (hasLau()) {
				dataPDU.setLAU(null);
				docDataPDU = docFromDataPdu(dataPDU);
			}
			xmlSigned = signerLau.signXmlV2(docDataPDU);
			dataPDU = parserToDataPDU(xmlSigned);
			boolean valid = validate();
			if (!valid) {
				log.error("ERROR DE VALIDACION, firma invalida!!, xmlfirmalo -------->");
				log.error(xmlSigned);
				//throw new RuntimeException("Esto no deberia ocurrir, error en validacion de lau de documento, comunique al administrador");
			}
			saaXml = xmlSigned;
		}
		return xmlSigned;
	}

	public static String removeLAUSignature(String xml) {
		String n = LAU.removeNodeLau(xml);
		DataPDU dp = parserToDataPDU(n);
		dp.setLAU(null);
		Document d = docFromDataPdu(dp);
		LAU.removeNodeLau(d);
		String newXml = JaxBConversionService.getStringFromDom(d);
		return newXml;
	}

	public boolean validate(){
		if (signerLau == null)
			throw new RuntimeException("No existe firmador LAU configurado");
		if (xmlSigned == null)
			throw new RuntimeException("Documento no fue firmado.");
		if (!signerLau.hasSignature()) {
			log.info("Documento xml sin firma");
			return false;
		}
		boolean valid = signerLau.validate(xmlSigned);
		log.info("Documento con firma valida? {}",valid);
		return valid;
	}

	public boolean validateOnlyXml(String xmlSngd){
		if (signerLau == null)
			throw new RuntimeException("No existe firmador LAU configurado");		
		DataPDU dpdu = parserToDataPDU(xmlSngd);
		log.info("VAlidando xml lau ? {}", dpdu.getLAU() != null);
		return (dpdu.getLAU() != null) && signerLau.validate(xmlSngd);
	}

	public String getSignatureValue() {
		if (!hasLau() )
			return null;
		return  JaxBConversionService.valueOfTag(docDataPDU, "SignatureValue");
		//return signerLau.getSignatureValue();
	}

	public String getDigestValue() {
		if (dataPDU != null && dataPDU.getLAU() != null) {
			if (dataPDU.getLAU().getContent().size() > 0) {
				Node node = (org.w3c.dom.Element) dataPDU.getLAU().getContent().get(0);
				String sign = JaxBConversionService.valueOfTag(node,"DigestValue");
				return sign;
			}
		}
		return null;		
	}

	private DataPDUWriter initBody() {
		//Objects.requireNonNull(dataPDU, "Objecto dataPDU no debe ser nulo");
		if (dataPDU == null) {
			dataPDU = new DataPDU();
		}
		if (dataPDU.getBody() == null) {
			dataPDU.setBody(new SwAny());
		}
		saaXml = null;
		xmlSigned = null;
		dataPDU.getBody().getContent().clear();
		dataPDU.setLAU(null);
		return this;
	}
	public DataPDUWriter initLAU() {
		Objects.requireNonNull(dataPDU, "Objecto dataPDU no debe ser nulo");
		if (dataPDU.getLAU() != null) {
			dataPDU.setBody(null);
		}
		return this;
	}

	public static String embeddedSaa(String saaXmlWithoutPdu, String trxXml) {
		Validate.notBlank(saaXmlWithoutPdu, "XML DataPDU no debe ser blanco");
		Validate.notBlank(trxXml, "XML cuerpo de DataPDU no debe ser blanco");

		final String tagToReplace = "<Saa:Body/>";
		final String tagBody = "Saa:Body";
		StringBuilder xmlBody = new StringBuilder();

		xmlBody.append("<").append(tagBody).append(">");
		xmlBody.append(trxXml);
		xmlBody.append("</").append(tagBody).append(">");
		//String saaXmlRet = saaXml.replace(tagToReplace, xmlBody.toString()).trim();
		String saaXml = StringUtils.replace(saaXmlWithoutPdu, tagToReplace, xmlBody.toString()).trim();
		return saaXml;
	}

	public Document toDoc() {
		try {
			JAXBContext context = JaxbContextLoader.INSTANCE.get(DataPDU.class, _classes);
			Marshaller marshaller = context.createMarshaller();

			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true);
			DocumentBuilder docBuilder = domFactory.newDocumentBuilder();
			Document document = docBuilder.newDocument();
			DOMResult domResult = new DOMResult(document);

			XmlSchema xmlSchema = DataPDU.class.getPackage().getAnnotation(XmlSchema.class);
			marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper() {
				@Override
				public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
					if (xmlSchema.namespace().equals(namespaceUri)) {
						return "Saa";
					}
					return suggestion;
				}
			});

			marshaller.marshal(dataPDU, domResult);
			return document;
		} catch (Exception e) {
			throw new RuntimeException("DataPDU desparceo: " + e.getMessage(), e);
		}
	}
	public DataPDUWriter xml(String xmlPDU) {
		createConfig("", false, new DefaultEscapeHandler(), new TypeAdaptersConfiguration(), null, null);
		this.mx = AbstractMX.parse(xmlPDU);
		return createDataPDUFromXml(xmlPDU).initBody();
	}

	public DataPDUWriter createDataPDUFromXml(String xml) {
		Validate.notBlank(xml, "XML DataPDU a parsear no debe ser blanco");
		try {
			int pos = xml.indexOf(DATAPDU_NAME);
			if (pos >= 0) {
				JAXBContext context = JaxbContextLoader.INSTANCE.get(DataPDU.class, _classes);

				Unmarshaller u = context.createUnmarshaller();
				dataPDU = (DataPDU) u.unmarshal(new StringReader(xml));
			} else {
				dataPDU = new DataPDU();
			}
			return this;
		} catch (Exception e) {
			throw new RuntimeException("DataPDU no pudo ser desparceado(vea errores anteriores): " + e.getMessage(), e);
		}
	}
	public DataPDU getDataPDU() {
		return dataPDU;
	}

	public LAU getSignerLau() {
		return signerLau;
	}

	public void setSignerLau(LAU signerLau) {
		this.signerLau = signerLau;
	}
	public DataPDUWriter configKeyLau(AuthParameters authParameters) {

		this.signerLau = new LAU().settingKey(authParameters);
		return this;
	}
	public boolean hasHeader(){
		return dataPDU != null && dataPDU.getHeader() != null && dataPDU.getHeader().getMessage() != null 
		&& !StringUtils.isBlank(dataPDU.getHeader().getMessage().getMessageIdentifier());
	}
	public boolean hasBody(){
		return dataPDU != null && dataPDU.getBody() != null && dataPDU.getBody().getContent() != null 
		&& dataPDU.getBody().getContent().size() > 0;
	}
	public boolean hasLau(){
		return dataPDU != null && dataPDU.getLAU() != null && dataPDU.getLAU().getContent() != null 
		&& dataPDU.getBody().getContent().size() > 0;
	}

	public static void updateFromMxMessage0(DataPDU dataPDU, MxSwiftMessage mxSwftMsg) {
		Objects.requireNonNull(dataPDU, "Objecto dataPDU no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader(), "Objecto dataPDU.Header no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage(), "Objecto dataPDU.Header.Message no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getSender(), "Objecto Sender no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getReceiver(), "Objecto Receiver no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getInterfaceInfo(), "Objecto InterfaceInfo no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getNetworkInfo(), "Objecto NetworkInfo no debe ser nulo");
		// presumponremos que nunca habra msgs de outputs, q mal!!!
		String uumid = MxDataTypesConversor.genUUMID("I", mxSwftMsg.getSender(), mxSwftMsg.getMxId().id(), mxSwftMsg.getReference(), "");
		dataPDU.getHeader().getMessage().setSenderReference(uumid);
		dataPDU.getHeader().getMessage().setMessageIdentifier(mxSwftMsg.getIdentifier());
		dataPDU.getHeader().getMessage().setFormat(mxSwftMsg.isMX() ? "MX" : "MT");
		dataPDU.getHeader().getMessage().setSubFormat(SubFormat.INPUT);
		dataPDU.getHeader().getMessage().getSender().getFullName().setX1(mxSwftMsg.getSender());
		dataPDU.getHeader().getMessage().getReceiver().getFullName().setX1(mxSwftMsg.getReceiver());
		dataPDU.getHeader().getMessage().getInterfaceInfo().setUserReference(mxSwftMsg.getReference());
		dataPDU.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo().setRequestType(mxSwftMsg.getMessageType());
	}

	public static Document docFromDataPdu(DataPDU dataPDU) {
		try {
			JAXBContext context = JaxbContextLoader.INSTANCE.get(DataPDU.class, _classes);
			Marshaller marshaller = context.createMarshaller();

			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true);
			DocumentBuilder docBuilder = domFactory.newDocumentBuilder();
			Document document = docBuilder.newDocument();
			DOMResult domResult = new DOMResult(document);

			XmlSchema xmlSchema = DataPDU.class.getPackage().getAnnotation(XmlSchema.class);
			marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper() {
				@Override
				public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
					if (xmlSchema.namespace().equals(namespaceUri)) {
						return "Saa";
					}
					return suggestion;
				}
			});
			log.info("DATAPDU_NAME marnulo {}, dapdunul {}, domnul {}",(marshaller == null), (dataPDU == null),(domResult == null));
			marshaller.marshal(dataPDU, domResult);
			return document;
		} catch (Exception e) {
			throw new RuntimeException("DataPDU desparceo: " + e.getMessage(), e);
		}
	}

	public static DataPDU newDataPDU() {
		DataPDU dataPDU = new DataPDU()//
				.setHeader((new Header())//
						.setMessage(new Message()//
								.setNetworkInfo(new NetworkInfo())//
								.setSender(new AddressInfo().setFullName(new AddressFullName()))//
								.setReceiver(new AddressInfo().setFullName(new AddressFullName()))//
								.setInterfaceInfo(new InterfaceInfo()))//
				);
		return dataPDU;
	}
}
