package gob.bcb.iso20022.excel.core.factory;

//import org.apache.commons.csv.CSVFormat;
//import org.apache.commons.csv.CSVParser;
//import org.apache.commons.csv.CSVPrinter;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;

public class CsvFactory {
    public static CSVPrinter writeInstance(String path) {
        return writeInstance(path, CSVFormat.DEFAULT);
    } 

    public static CSVPrinter writeInstance(String path, CSVFormat csvFormat) {
        CSVPrinter printer = null;
        try {
            printer = new CSVPrinter(new FileWriter(path), CSVFormat.DEFAULT);
        } catch (IOException e) {
        	throw new RuntimeException(e);
        }
        return printer; 
    }


    /**
     *
     * @param reader
     * @return
     */
    public static CSVParser readInstance(Reader reader, String[] headers) {
        CSVParser parse = null;
        try {
            parse = CSVParser.parse(reader, CSVFormat.Builder.create().setHeader(headers).build());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return parse;
    }

    public static CSVParser readInstance(Reader reader, CSVFormat cSVFormat) {
        CSVParser parse = null;
        try {
            parse = CSVParser.parse(reader, cSVFormat);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return parse;
    }    
}
