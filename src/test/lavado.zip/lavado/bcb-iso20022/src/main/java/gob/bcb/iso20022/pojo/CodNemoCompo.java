package gob.bcb.iso20022.pojo;

import java.util.Arrays;

import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

public class CodNemoCompo {
	private final String separatorTabProp;
	private final String separatorFldCompo;
	private String sequence = "";
	private String subSequence = "";
	private String sequenceLit = "";
	private String sequenceNum = "";
	private String grpOpt = "";
	private String codCampo = "";
	private String codCampoNL = "";
	private String codCampoNum = "";
	private String codCampoLit = "";
	private String codCampoOrder = "";
	// private String campoOpt = "";
	private String tabla = "";
	private String componente = "";
	/**
	 * en este campo va el codigo del componente si cumple el patron
	 */
	private String componenteField = "";
	private String valor = "";
	private Boolean nemoIsField = false;

	public CodNemoCompo(String separatorFldCompo, String separatorTabProp) {
		this.separatorFldCompo = separatorFldCompo;
		this.separatorTabProp = separatorTabProp;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	public String getSubSequence() {
		return subSequence;
	}

	public void setSubSequence(String subSequence) {
		this.subSequence = subSequence;
	}

	public String getGrpOpt() {
		return grpOpt;
	}

	public void setGrpOpt(String grpOpt) {
		this.grpOpt = grpOpt == null ? "" : grpOpt.replace(".", "");
	}

	public String getCodCampo() {
		return codCampo;
	}

	public void setCodCampo(String codCampo) {
		this.codCampo = codCampo;
	}

	public String getComponente() {
		return componente;
	}

	public void setComponente(String componente) {
		this.componente = componente;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getTabla() {
		return tabla;
	}

	public void setTabla(String tabla) {
		this.tabla = tabla;
	}

	public Boolean getNemoIsField() {
		return nemoIsField;
	}

	public void setNemoIsField(Boolean nemoIsField) {
		this.nemoIsField = nemoIsField;
	}

	public String getCodCampoNum() {
		return codCampoNum;
	}

	public void setCodCampoNum(String codCampoNum) {
		this.codCampoNum = codCampoNum == null ? "" : codCampoNum.replace(".", "");
	}

	public String getCodCampoLit() {
		return codCampoLit;
	}

	public void setCodCampoLit(String codCampoLit) {
		this.codCampoLit = codCampoLit;
	}

	public String getCodCampoOrder() {
		return codCampoOrder;
	}

	public void setCodCampoOrder(String codCampoOrder) {
		this.codCampoOrder = codCampoOrder == null ? "" : codCampoOrder.replace(".", "");
	}

	public String getComponenteField() {
		return componenteField;
	}

	public void setComponenteField(String componenteField) {
		this.componenteField = componenteField;
	}

	public String getCodCampoNL() {
		return codCampoNL;
	}

	public void setCodCampoNL(String codCampoNL) {
		this.codCampoNL = codCampoNL;
	}


	/**********************/

	public String getPartTabla() {

		String partTablaJoin = Arrays.asList(sequence, grpOpt, codCampo).stream().filter(cad -> cad != null && cad.trim().length() > 0)
				.collect(Collectors.joining(separatorFldCompo));

		return nemoIsField ? partTablaJoin : tabla;
	}

	public String getPartTabCompo() {

		String partTablaJoin = Arrays.asList(getPartTabla(), componente).stream().filter(cad -> cad != null && cad.trim().length() > 0)
				.collect(Collectors.joining(separatorTabProp));

		return partTablaJoin;
	}

	public String getValorNemo() {
		String partTablaJoin = Arrays.asList(sequence, grpOpt, codCampo).stream().filter(cad -> cad != null && cad.trim().length() > 0)
				.collect(Collectors.joining(separatorFldCompo));

		return Arrays.asList(partTablaJoin, componente).stream().filter(cad -> cad != null && cad.trim().length() > 0)
				.collect(Collectors.joining(separatorTabProp));

	}

	public String formatSGFnlit() {
		String partTablaJoin = Arrays.asList(sequence, grpOpt, codCampoNum, codCampoLit).stream().filter(cad -> cad != null && cad.trim().length() > 0)
				.collect(Collectors.joining(separatorFldCompo));

		String tablaPropJoin = Arrays.asList(partTablaJoin, componenteField).stream().filter(cad -> cad != null && cad.trim().length() > 0)
				.collect(Collectors.joining(separatorTabProp));

		return nemoIsField ? tablaPropJoin : "";
	}

	/**
	 * Formato Sequence Grupo Field y Componente Field
	 * 
	 * @return
	 */
	public String formatoSGFC() {

		String partTablaJoin = Arrays.asList(getPartTabla(), componenteField).stream().filter(cad -> cad != null && cad.trim().length() > 0)
				.collect(Collectors.joining(separatorTabProp));

		return partTablaJoin;
	}

	/**
	 * retorna enformato nemo según
	 * Sl: Secuencia parte literal,
	 * Sn: Secuencia parte numerica,
	 * G: Grupo
	 * Fn: campo parte numerica
	 * Fl: cmpo parte literal
	 * Fo: campo parte order
	 * C: componente
	 * @param format
	 * @return
	 */
	public String format(String format) {

		String partTablaJoin = Arrays
				.asList((format.contains("Sl") ? sequenceLit : "") + (format.contains("Sn") ? sequenceNum : ""), //
						format.contains("G") ? grpOpt : null, //
						(format.contains("Fn") ? codCampoNum : "") + (format.contains("Fl") ? codCampoLit : ""), //
						format.contains("Fo") ? codCampoOrder : null)
				.stream().filter(cad -> cad != null && cad.trim().length() > 0).collect(Collectors.joining(separatorFldCompo));

		String tablaPropJoin = Arrays.asList(partTablaJoin != null ? partTablaJoin : null, format.contains("C") ? componenteField : null).stream()
				.filter(cad -> cad != null && cad.trim().length() > 0).collect(Collectors.joining(separatorTabProp));

		return tablaPropJoin;
	}

	public String formatNemo(){
		StringBuffer format = new StringBuffer();
		format.append(StringUtils.isBlank(sequenceLit) ? "" : "Sl");
		format.append(StringUtils.isBlank(sequenceNum) ? "" : "Sn");
		format.append(StringUtils.isBlank(grpOpt) ? "" : "G");
		format.append(StringUtils.isBlank(codCampoNum) ? "" : "Fn");
		format.append(StringUtils.isBlank(codCampoLit) ? "" : "Fl");
		format.append(StringUtils.isBlank(componenteField) ? "" : "C");

		return format.toString();
	}

	/**
	 * retorna solo el campo numerico no la opcion literal y el componente, sino cumple el formato nemo retorna vacio
	 * 
	 * @return
	 */
	public String formatSGFn() {
		//format("SlSnGFnC");
		return format("SlSnGFnC");
	}
	@Override
	public String toString() {
		return "[Valor: " + valor + ", S: " + sequence + ", G: " + grpOpt + ", F: " + codCampo + " (" + codCampoNL + "=" + codCampoNum + "-" + codCampoLit
				+ "-" + codCampoOrder + "), T: " + tabla + ", C: " + componente + "]" + ", Tabla=" + getPartTabla();
	}

	public String getSequenceLit() {
		return sequenceLit;
	}

	public void setSequenceLit(String sequenceLit) {
		this.sequenceLit = sequenceLit;
	}

	public String getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(String sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

}
