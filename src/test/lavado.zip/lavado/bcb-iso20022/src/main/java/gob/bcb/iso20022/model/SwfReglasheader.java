package gob.bcb.iso20022.model;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class SwfReglasheader {
	private Integer rhdCodregla;

	private String rhdAbccodctaper;
	private String rhdModeltype;
	private String rhdCodctapers;
	private String rhdAccesscode;
	private String rhdModelowner;
	private String rhdModelname;
	private String rhdAgencycode;
	private String rhdCurrency;
	private String rhdCountry;
	private String rhdSecurity;
	private String rhdMethodtype;
	private List<SwfReglasmerc> swfReglasmercList = new ArrayList<>();
	private List<SwfReglasheader> swfReglasheaderRelList = new ArrayList<>();
	private SwfReglasmerc swfReglasmerc = null;
	private SwfReglasheader swfReglasheaderRel = null;
	
	public SwfReglasheader() {
	}

	public Integer getRhdCodregla() {
		return rhdCodregla;
	}

	public void setRhdCodregla(Integer rhdCodregla) {
		this.rhdCodregla = rhdCodregla;
	}

	public String getRhdModeltype() {
		return rhdModeltype;
	}

	public void setRhdModeltype(String rhdModeltype) {
		this.rhdModeltype = rhdModeltype;
	}

	public String getRhdCodctapers() {
		return rhdCodctapers;
	}

	public void setRhdCodctapers(String rhdCodctapers) {
		this.rhdCodctapers = rhdCodctapers;
	}

	public String getRhdModelname() {
		return rhdModelname;
	}

	public void setRhdModelname(String rhdModelname) {
		this.rhdModelname = rhdModelname;
	}

	public String getRhdCurrency() {
		return rhdCurrency;
	}

	public void setRhdCurrency(String rhdCurrency) {
		this.rhdCurrency = rhdCurrency;
	}

	public String getRhdCountry() {
		return rhdCountry;
	}

	public void setRhdCountry(String rhdCountry) {
		this.rhdCountry = rhdCountry;
	}

	public String getRhdSecurity() {
		return rhdSecurity;
	}

	public void setRhdSecurity(String rhdSecurity) {
		this.rhdSecurity = rhdSecurity;
	}

	public String getRhdMethodtype() {
		return rhdMethodtype;
	}

	public void setRhdMethodtype(String rhdMethodtype) {
		this.rhdMethodtype = rhdMethodtype;
	}

	public String getRhdAccesscode() {
		return rhdAccesscode;
	}

	public void setRhdAccesscode(String rhdAccesscode) {
		this.rhdAccesscode = rhdAccesscode;
	}

	public String getRhdModelowner() {
		return rhdModelowner;
	}

	public void setRhdModelowner(String rhdModelowner) {
		this.rhdModelowner = rhdModelowner;
	}

	public String getRhdAgencycode() {
		return rhdAgencycode;
	}

	public void setRhdAgencycode(String rhdAgencycode) {
		this.rhdAgencycode = rhdAgencycode;
	}

	public List<SwfReglasmerc> getSwfReglasmercList() {
		return swfReglasmercList;
	}

	public void setSwfReglasmercList(List<SwfReglasmerc> swfReglasmercList) {
		this.swfReglasmercList = swfReglasmercList;
	}

	public String getRhdAbccodctaper() {
		return rhdAbccodctaper;
	}

	public void setRhdAbccodctaper(String rhdAbccodctaper) {
		this.rhdAbccodctaper = rhdAbccodctaper;
	}

	public SwfReglasheader putRhdAbccodctaper(String rhdAbccodctaper) {
		this.rhdAbccodctaper = rhdAbccodctaper;
		return this;
	}

	public SwfReglasheader putRhdAccesscode(String rhdAccesscode) {
		this.rhdAccesscode = rhdAccesscode;
		return this;
	}

	public SwfReglasheader putRhdAgencycode(String rhdAgencycode) {
		this.rhdAgencycode = rhdAgencycode;
		return this;
	}

	public SwfReglasheader putRhdCodctapers(String rhdCodctapers) {
		this.rhdCodctapers = rhdCodctapers;
		return this;
	}

	public SwfReglasheader putRhdCodregla(Integer rhdCodregla) {
		this.rhdCodregla = rhdCodregla;
		return this;
	}

	public SwfReglasheader putRhdCountry(String rhdCountry) {
		this.rhdCountry = rhdCountry;
		return this;
	}

	public SwfReglasheader putRhdMethodtype(String rhdMethodtype) {
		this.rhdMethodtype = rhdMethodtype;
		return this;
	}

	public SwfReglasheader putRhdModelname(String rhdModelname) {
		this.rhdModelname = rhdModelname;
		return this;
	}

	public SwfReglasheader putRhdModelowner(String rhdModelowner) {
		this.rhdModelowner = rhdModelowner;
		return this;
	}

	public SwfReglasheader putRhdModeltype(String rhdModeltype) {
		this.rhdModeltype = rhdModeltype;
		return this;
	}

	public SwfReglasheader putRhdSecurity(String rhdSecurity) {
		this.rhdSecurity = rhdSecurity;
		return this;
	}

	public SwfReglasheader putRhdCurrency(String rhdCurrency) {
		this.rhdCurrency = rhdCurrency;
		return this;
	}

	public String toStringRh() {
		Function<String, String> nullEmp = s -> {
			return (s == null) ? "" : s.trim();
		};

		return (rhdCodregla != null ? rhdCodregla : "") + "=>" + nullEmp.apply(rhdModeltype) + " CSM[" + nullEmp.apply(rhdCountry) + "-"
				+ nullEmp.apply(rhdSecurity) + "-" + nullEmp.apply(rhdMethodtype) + "] (" + nullEmp.apply(rhdCurrency) + "), A/C["
				+ nullEmp.apply(rhdAbccodctaper) + ":"+ nullEmp.apply(rhdCodctapers) + ":" + nullEmp.apply(rhdAccesscode) + "] MDL[" + nullEmp.apply(rhdModelowner) + "-"
				+ nullEmp.apply(rhdModelname) +"-"+ nullEmp.apply(rhdAgencycode)+ "]";
	}

	public SwfReglasmerc getSwfReglasmerc() {
		return swfReglasmerc;
	}

	public void setSwfReglasmerc(SwfReglasmerc swfReglasmerc) {
		this.swfReglasmerc = swfReglasmerc;
	}

	public SwfReglasheader getSwfReglasheaderRel() {
		return swfReglasheaderRel;
	}

	public void setSwfReglasheaderRel(SwfReglasheader swfReglasheaderRel) {
		this.swfReglasheaderRel = swfReglasheaderRel;
	}

	public List<SwfReglasheader> getSwfReglasheaderRelList() {
		return swfReglasheaderRelList;
	}

	public void setSwfReglasheaderRelList(List<SwfReglasheader> swfReglasheaderRelList) {
		this.swfReglasheaderRelList = swfReglasheaderRelList;
	}

}
