
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TranslatedResult.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="TranslatedResult"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Success"/&gt;
 *     &lt;enumeration value="TruncationNonRef"/&gt;
 *     &lt;enumeration value="TruncationRef"/&gt;
 *     &lt;enumeration value="Failure"/&gt;
 *     &lt;enumeration value="Partial"/&gt;
 *     &lt;enumeration value="Other"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "TranslatedResult")
@XmlEnum
public enum TranslatedResult {

    @XmlEnumValue("Success")
    SUCCESS("Success"),
    @XmlEnumValue("TruncationNonRef")
    TRUNCATION_NON_REF("TruncationNonRef"),
    @XmlEnumValue("TruncationRef")
    TRUNCATION_REF("TruncationRef"),
    @XmlEnumValue("Failure")
    FAILURE("Failure"),
    @XmlEnumValue("Partial")
    PARTIAL("Partial"),
    @XmlEnumValue("Other")
    OTHER("Other");
    private final String value;

    TranslatedResult(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TranslatedResult fromValue(String v) {
        for (TranslatedResult c: TranslatedResult.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
