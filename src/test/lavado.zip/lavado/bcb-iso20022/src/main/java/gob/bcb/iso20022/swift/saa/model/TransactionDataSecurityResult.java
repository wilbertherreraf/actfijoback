
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TransactionDataSecurityResult.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="TransactionDataSecurityResult"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Success"/&gt;
 *     &lt;enumeration value="Bypassed"/&gt;
 *     &lt;enumeration value="InvalidDigest"/&gt;
 *     &lt;enumeration value="InvalidSignerDN"/&gt;
 *     &lt;enumeration value="InvalidCertPolicyID"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "TransactionDataSecurityResult")
@XmlEnum
public enum TransactionDataSecurityResult {

    @XmlEnumValue("Success")
    SUCCESS("Success"),
    @XmlEnumValue("Bypassed")
    BYPASSED("Bypassed"),
    @XmlEnumValue("InvalidDigest")
    INVALID_DIGEST("InvalidDigest"),
    @XmlEnumValue("InvalidSignerDN")
    INVALID_SIGNER_DN("InvalidSignerDN"),
    @XmlEnumValue("InvalidCertPolicyID")
    INVALID_CERT_POLICY_ID("InvalidCertPolicyID");
    private final String value;

    TransactionDataSecurityResult(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static TransactionDataSecurityResult fromValue(String v) {
        for (TransactionDataSecurityResult c: TransactionDataSecurityResult.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
