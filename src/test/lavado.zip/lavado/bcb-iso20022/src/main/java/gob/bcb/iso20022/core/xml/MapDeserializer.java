package gob.bcb.iso20022.core.xml;

import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.stream.Collectors;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;

public class MapDeserializer implements JsonDeserializer<Map<String, Object>> {
	private SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

	@Override
	public Map<String, Object> deserialize(JsonElement elem, Type type, JsonDeserializationContext context) throws JsonParseException {

		return elem.getAsJsonObject().entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e -> {
			if (e.getValue().isJsonObject()) {
				return context.deserialize(e.getValue(), JsonObject.class);
			}
			return e.getValue().isJsonPrimitive() ? toPrimitive(e.getValue().getAsJsonPrimitive(), context) : //
			(context.deserialize(e.getValue(), Object.class)//
			);
		}));
	}

	private Object toPrimitive(JsonPrimitive jsonValue, JsonDeserializationContext context) {
		if (jsonValue.isBoolean())
			return jsonValue.getAsBoolean();
		else if (jsonValue.isString()) {

			return jsonValue.getAsString();
		} else {
			BigDecimal bigDec = jsonValue.getAsBigDecimal();
			Long l;
			Integer i;
			if ((i = toInteger(bigDec)) != null) {
				return i;
			} else if ((l = toLong(bigDec)) != null) {
				return l;
			} else {
				return bigDec.doubleValue();
			}
		}
	}

	private Long toLong(BigDecimal val) {
		try {
			return val.toBigIntegerExact().longValue();
		} catch (ArithmeticException e) {
			return null;
		}
	}

	private Integer toInteger(BigDecimal val) {
		try {
			return val.intValueExact();
		} catch (ArithmeticException e) {
			return null;
		}
	}

	private Date formatDate(JsonElement value) {
		try {
			return format.parse(value.getAsString());
		} catch (ParseException ex) {
			throw new JsonParseException(ex);
		}
	}
}