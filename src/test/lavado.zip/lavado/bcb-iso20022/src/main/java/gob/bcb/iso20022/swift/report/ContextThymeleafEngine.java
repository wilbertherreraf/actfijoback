package gob.bcb.iso20022.swift.report;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

public class ContextThymeleafEngine {

	private static class ContextThymeleafEngineHolder{
		public static final ContextThymeleafEngine engine = new ContextThymeleafEngine();
	}
	
	private ClassLoaderTemplateResolver templateResolver;
	private TemplateEngine templateEngine;
	private ContextThymeleafEngine() {
	}
	
	private ContextThymeleafEngine(ClassLoaderTemplateResolver templateResolver) {
		this.templateResolver = templateResolver;
	}
	
	public static ContextThymeleafEngine instance() {
		return ContextThymeleafEngineHolder.engine;
	}
	
	public ContextThymeleafEngine initialize() {
	    if (templateResolver == null) {
			ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
			templateResolver.setPrefix("templates/");
		    templateResolver.setSuffix(".html");
		    templateResolver.setTemplateMode(TemplateMode.HTML);
		    templateResolver.setCacheable(true);
		    this.templateResolver = templateResolver;
	    }
	    return this;
	}
	
	public TemplateEngine templateEngine() {
		if (this.templateEngine == null) {
		    TemplateEngine templateEngine = new TemplateEngine();
		    templateEngine.setTemplateResolver(templateResolver);
		    this.templateEngine = templateEngine;
		}

		return this.templateEngine;		
	}
}
