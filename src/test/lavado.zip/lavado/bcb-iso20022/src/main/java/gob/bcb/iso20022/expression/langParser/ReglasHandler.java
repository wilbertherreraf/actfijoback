package gob.bcb.iso20022.expression.langParser;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.jeasy.rules.api.Facts;
import org.jeasy.rules.api.Rules;
import org.jeasy.rules.api.RulesEngine;
import org.jeasy.rules.core.DefaultRulesEngine;
import org.jeasy.rules.mvel.MVELRule;
import org.jeasy.rules.mvel.MVELRuleFactory;
import org.jeasy.rules.support.RuleDefinition;
import org.jeasy.rules.support.reader.JsonRuleDefinitionReader;
import org.jeasy.rules.support.reader.RuleDefinitionReader;
import org.jeasy.rules.support.reader.YamlRuleDefinitionReader;

/**
 * evalua expresiones MVEL scripting , al momento soporta formatos de archivo
 * YML
 * 
 * @author WHerrera
 *
 */
public class ReglasHandler {

	/**
	 * inicializa y evalua una expresion de un archivo YAML para un ID de regla
	 * especifico
	 * 
	 * @return
	 */
	public static Function<String, Function<String, Consumer<Supplier<Facts>>>> initEvalExpressionIDYML() {
		return fileName -> {
			RulesEngine rulesEngine = createDefRulesEngine().get();
			List<RuleDefinition> ruleDefinitions = getRuleDef(createRuleDefinitionReaderYML()).apply(fileName);
			Function<String, Rules> subReglasParaIDF = subReglasParaID(ruleDefinitions);
			return ruleID -> {
				if (ruleID == null || ruleID.trim().length() == 0) {
					Rules rules = leerReglasDeArchFuncYML().apply(fileName);
					return evaluateExpression(rules, rulesEngine);
				}
				Rules rules = subReglasParaIDF.apply(ruleID);
				return evaluateExpression(rules, rulesEngine);
			};
		};
	}

	/**
	 * inicializa y evalua una expresion de un archivo Json para un ID de regla
	 * especifico
	 * 
	 * @return
	 */
	public static Function<String, Function<String, Consumer<Supplier<Facts>>>> initEvalExpressionIDJSON() {
		return fileName -> {
			RulesEngine rulesEngine = createDefRulesEngine().get();
			List<RuleDefinition> ruleDefinitions = getRuleDef(createRuleDefinitionReaderJSON()).apply(fileName);
			Function<String, Rules> subReglasParaIDF = subReglasParaID(ruleDefinitions);
			return ruleID -> {
				Rules rules = subReglasParaIDF.apply(ruleID);
				return evaluateExpression(rules, rulesEngine);
			};
		};
	}

	public static Function<String, Rules> leerReglasDeArchFuncYML() {
		return s -> leerReglasDeArch(createMVELRuleFactoryYML()).apply(s);
	}

	public static Function<String, Rules> leerReglasDeArchFuncJSON() {
		return s -> leerReglasDeArch(createMVELRuleFactoryJSON()).apply(s);
	}

	public static Consumer<Supplier<Facts>> evaluateExpression(Rules rules, RulesEngine rulesEngine) {
		Consumer<Facts> executeRulesCon = executeRules(rules, rulesEngine);
		return factsSup -> {
			Facts facts = factsSup.get();
			executeRulesCon.accept(facts);
		};
	}

	/**
	 * ejecuta las reglas segun el tipo, tomar en cuenta que tipo de expresion esta
	 * en evaluacion
	 * 
	 * @param rules
	 * @param rulesEngine
	 * @return
	 */
	public static Consumer<Facts> executeRules(Rules rules, RulesEngine rulesEngine) {
		return facts -> {
			rulesEngine.fire(rules, facts);
		};
	}

	public static Function<String, Rules> leerReglasDeArch(Supplier<MVELRuleFactory> createMVELRuleFactory) {
		MVELRuleFactory factory = createMVELRuleFactory.get();
		return fileName -> {
			File rulesDescriptor = new File(fileName);
			try {
				return factory.createRules(new FileReader(rulesDescriptor));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		};
	}

	/**
	 * extrae las subreglas en formato MVEL de un archivo JSON o YAML
	 * 
	 * @param createRuleDefinition
	 * @param fileName
	 * @return
	 */
	public static Function<String, Rules> subReglasParaID(List<RuleDefinition> ruleDefinitions) {
		// List<RuleDefinition> ruleDefinitions =
		// getRuleDef(createRuleDefinition).apply(fileName);
		return ruleID -> {
			Rules rules = new Rules();
			ruleDefinitions.forEach(r -> {
				if (r.getName().equalsIgnoreCase(ruleID)) {
					for (RuleDefinition sr : r.getComposingRules()) {
						MVELRule mVELRule = new MVELRule()//
								.name(sr.getName())//
								.description(sr.getDescription())//
								.priority(sr.getPriority())//
								.when(sr.getCondition());
						// log.info("****** En gen MVErules {} - {}",sr.getName(),sr.getCondition());
						for (String action : sr.getActions()) {
							mVELRule.then(action);
						}
						rules.register(mVELRule);
					}
				}
			});
			return rules;
		};
	}

	/**
	 * inicializa el objeto de hechos a evaluar
	 * 
	 * @return
	 */
	public static Function<HashMap<String, Object>, Facts> initFacts() {
		return (mapFacts) -> {
			Facts facts = new Facts();
			mapFacts.entrySet().forEach(m -> {
				if (m.getValue() != null)
					facts.put(m.getKey(), m.getValue());
			});
			return facts;
		};
	}

	public static Supplier<Facts> initFactsOper(Supplier<HashMap<String, Object>> generarDomainVarsSup) {
		return () -> {
			return initFacts().apply(generarDomainVarsSup.get());
		};
	}

	public static Function<String, List<RuleDefinition>> getRuleDef(Supplier<RuleDefinitionReader> createRuleDefinitionSup) {
		return fileName -> {
			File rulesDescriptor = new File(fileName);
			try {
				return createRuleDefinitionSup.get().read(new FileReader(rulesDescriptor));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}

		};
	}

	public static Supplier<RulesEngine> createDefRulesEngine() {
		return () -> new DefaultRulesEngine();
	}

	public static Supplier<MVELRuleFactory> createMVELRuleFactoryYML() {
		return () -> new MVELRuleFactory(createRuleDefinitionReaderYML().get());
	}

	public static Supplier<MVELRuleFactory> createMVELRuleFactoryJSON() {
		return () -> new MVELRuleFactory(createRuleDefinitionReaderJSON().get());
	}

	public static Supplier<RuleDefinitionReader> createRuleDefinitionReaderYML() {
		return () -> new YamlRuleDefinitionReader();
	}

	public static Supplier<RuleDefinitionReader> createRuleDefinitionReaderJSON() {
		return () -> new JsonRuleDefinitionReader();
	}
	
}
