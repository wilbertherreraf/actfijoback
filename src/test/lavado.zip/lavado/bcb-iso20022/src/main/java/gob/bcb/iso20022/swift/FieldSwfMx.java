package gob.bcb.iso20022.swift;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.AbstractMessage;
import com.prowidesoftware.swift.model.MxId;
import com.prowidesoftware.swift.model.MxSwiftMessage;
import com.prowidesoftware.swift.model.mx.AppHdr;
import com.prowidesoftware.swift.model.mx.AppHdrFactory;
import com.prowidesoftware.swift.model.mx.BusinessAppHdrV01;
import com.prowidesoftware.swift.model.mx.BusinessAppHdrV02;
import com.prowidesoftware.swift.model.mx.NamespaceReader;

import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.exceptions.DataValidationSwitfException;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.Node;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.parser.SwiftMessageMX;
import gob.bcb.iso20022.swift.saa.DataPDUWriter;
import gob.bcb.iso20022.swift.saa.model.AddressFullName;
import gob.bcb.iso20022.swift.saa.model.AddressInfo;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.swift.saa.model.Header;
import gob.bcb.iso20022.swift.saa.model.InterfaceInfo;
import gob.bcb.iso20022.swift.saa.model.Message;
import gob.bcb.iso20022.swift.saa.model.NetworkInfo;
import gob.bcb.iso20022.swift.saa.model.SubFormat;
import gob.bcb.iso20022.swift.saa.model.SwAny;
import gob.bcb.iso20022.utils.MxDataTypesConversor;

public abstract class FieldSwfMx extends FieldSwf {
	private static final Logger log = LoggerFactory.getLogger(FieldSwfMx.class);
	private static final Pattern pattern = Pattern.compile(".*([a-zA-Z]{4}).(\\d{3}).(\\d{3}).(\\d{2}).*");

	@Override
	public String generateMsg() {
		SwiftMessageAbstract sma = instruccion.getMessageHolder();
		sma.createMsg();

		if (StringUtils.isBlank(sma.getMenPlano())) {
			throw new DataValidationSwitfException("No se pudo crear mensaje Swift MT ");
		}

		log.info("MX generado " + instruccion.getSwfMsgParam().getMenIdTMessageTx());
		return sma.getMenPlano();
	}

	public void registerFactsDef() {
		FieldsCommandMx.mapFuncs().forEach((k, v) -> {
			instruccion.getMappingTable().putFact(k, v);
		});
	}

	public void translate() {
		String typeMessage = instruccion.getSwfMsgParam().getMenTypemessage();
		try {
			MappingTable mpptab = formatEngine.translate(instruccion.swfMencamposList(), instruccion.getMappingTable());

			if (mpptab.getMappingRuleList().size() == 0) {
				throw new DataValidationSwitfException("Proceso de generacion Swift de reglas no retorno ningun resultado " + typeMessage);
			}
//			Map<String, String> mpp = mpptab.toProperties();
//			mpp.forEach((k,v) -> {
//				log.info(k + " : " + v);
//			});
			instruccion.setMapTableResult(mpptab);
		} catch (Exception e) {
			log.error("Error al evaluar reglas " + e.getMessage());
			throw new RuntimeException(e);
		}
	}

	public void translatePost() {
		String typeMessage = instruccion.getSwfMsgParam().getMenTypemessage();

		MappingTable mpptab = instruccion.getMapTableResult();
		if (mpptab.getMappingRuleList().size() == 0) {
			throw new DataValidationSwitfException("MX:" + typeMessage + " Lista de valores para mensaje vacio. Genere la operacion nuevamente.");
		}
		String mxXml = mpptab.toXML();

		if (StringUtils.isBlank(mxXml)) {
			throw new DataValidationSwitfException("MX: Conversion de propiedades a XML no retorna ningun valor.");
		}
		
		if (instruccion.getMapTableResult().noExecs().size() > 0) {
			log.warn("No calculados: ", instruccion.getMapTableResult().noExecs().size());
			instruccion.getMapTableResult().noExecs().forEach(r -> {
				log.info(r.getFullyQualifiedName() + " " + r.getPath() + " " + r.getAction());
			});
		}
		
		SwiftMessageAbstract sma = new SwiftMessageMX(mxXml);
		sma.setTypeMessage(typeMessage);

		instruccion.setMessageHolder(sma);
	}

	public void generaHeaderMsg() {

	}

	public AppHdr crearHeaderMsg() {
		SwiftMessageAbstract sma = instruccion.getMessageHolder();
		String xmlPlano = sma.getMenPlanoOrig();
		AppHdr appHdr = null;
		boolean existHdr = !StringUtils.isBlank(xmlPlano) && NamespaceReader.elementExists(xmlPlano, AppHdr.HEADER_LOCALNAME);

		if (!existHdr) {
			String typeMessage = instruccion.getSwfMsgParam().getMenTypemessage();
			String hdrVersion = instruccion.getSwfMsgParam().getMenHdrversion();

			MxId id = new MxId(typeMessage);
			String bizMsgIdr = instruccion.getSwfMsgParam().getMenCodswift();

			if (!StringUtils.isBlank(hdrVersion) && BusinessAppHdrV02.NAMESPACE.endsWith(hdrVersion)) {
				BusinessAppHdrV02 h = AppHdrFactory.createBusinessAppHdrV02(instruccion.getSwfMsgParam().getMenEmisor(),
						instruccion.getSwfMsgParam().getMenReceiver(), bizMsgIdr, id);
				appHdr = h;
			} else {
				BusinessAppHdrV01 h = AppHdrFactory.createBusinessAppHdrV01(instruccion.getSwfMsgParam().getMenEmisor(),
						instruccion.getSwfMsgParam().getMenReceiver(), bizMsgIdr, id);
				appHdr = h;
			}
		}
		return appHdr;
	}

	public DataPDU crearHeaderPDU(SwiftMessageAbstract sma, boolean created) {
		String xmlPlano = sma.getMenPlanoOrig();
		boolean existHdr = !StringUtils.isBlank(xmlPlano) && NamespaceReader.elementExists(xmlPlano, "MessageIdentifier");

		if (existHdr) {
//			existHdr = NamespaceReader.elementExists(xmlPlano, "Revision");
//			existHdr = existHdr && NamespaceReader.elementExists(xmlPlano, "MessageIdentifier");
		}

		if (existHdr) {
			DataPDUWriter w = new DataPDUWriter().xml(xmlPlano);
			return w.getDataPDU();
		} else {
			if (created) {
				DataPDU dataPDU = newDataPDU();
				String uumid = MxDataTypesConversor.genUUMID("I", instruccion.getSwfMsgParam().getMenEmisor(),
						instruccion.getSwfMsgParam().getMenTypemessage(), instruccion.getSwfMsgParam().getMenCodswift(), "");
				dataPDU.getHeader().getMessage().setSenderReference(uumid);
				dataPDU.getHeader().getMessage().setMessageIdentifier(instruccion.getSwfMsgParam().getMenTypemessage());
				dataPDU.getHeader().getMessage().setFormat(instruccion.getSwfMsgParam().getMenFormato());
				dataPDU.getHeader().getMessage().setSubFormat(SubFormat.INPUT);
				// dataPDU.getHeader().getMessage().getSender().setDN("");
				dataPDU.getHeader().getMessage().getSender().getFullName().setX1(instruccion.getSwfMsgParam().getMenEmisor());
				// dataPDU.getHeader().getMessage().getReceiver().setDN("");
				dataPDU.getHeader().getMessage().getReceiver().getFullName().setX1(instruccion.getSwfMsgParam().getMenReceiver());
				dataPDU.getHeader().getMessage().getInterfaceInfo().setUserReference(instruccion.getSwfMsgParam().getMenCodswift());

				dataPDU.setBody(new SwAny());
				return dataPDU;
			}
		}
		return null;
	}

	public void recuperarSwfCampos(String typeMessage, String bloque) {
		log.info("===oooOO CREANDO MX[" + typeMessage + "] OOooo=== ");

		Node<SwfMencampos> nodesTree = genTreeNodes(typeMessage, bloque);
		if (nodesTree.getChildArray().size() == 0) {
			log.warn("Consulta de campos swift no retorna registros para MX: " + typeMessage + " bloque: " + bloque);
			return;
		}
		LinkedHashMap<Integer, SwfMencampos> treeCampos = new LinkedHashMap<Integer, SwfMencampos>();
		recTreeCampos(nodesTree, treeCampos);

		log.info("Campos recuperados de consulta {} - {} regs. {}", typeMessage, bloque, treeCampos.size());
		instruccion.setTreeMencampos(treeCampos);
	}

	public Node<SwfMencampos> genTreeNodes(String tMsgTrx, String bloque) {
		HashMap<Integer, SwfMencampos> swfCamposMap = camposToMap(tMsgTrx, bloque);

		if (swfCamposMap.size() == 0)
			throw new DataValidationSwitfException("Mapa de campos no retorna ningun resultado para " + tMsgTrx + " bloque: " + bloque);

		LinkedHashMap<String, Object> xmlProperties = new LinkedHashMap<String, Object>();
		swfCamposMap.forEach((k, swfMencampos) -> {
			xmlProperties.put(swfMencampos.getMtfXmltag(), swfMencampos.getMtfId());
		});
		// LinkedHashMap<String, Object> xmlProperties0 = toProps(swfCamposMap, true);

		if (xmlProperties.size() == 0) {
			throw new DataValidationSwitfException("No se genero mapa de XML de propiedades.");
		}

		String xml = XmlToMap.xmlFromXPath4J(xmlProperties);
		Node<SwfMencampos> padre = Node.createNodeDefault(tMsgTrx, bloque);
		XmlToMap.xmlToNodes(xml, swfCamposMap, padre);

		return padre;
	}

	public void dataValidation() {
		super.dataValidation();

		SwfMsgParam swfMsgParam = instruccion.getSwfMsgParam();

		if (FileFormat.valueOf(swfMsgParam.getMenFormato()) != FileFormat.MX)
			throw new DataValidationSwitfException("Formato debe ser " + FileFormat.MX.toString());

		final Matcher matcher = pattern.matcher(swfMsgParam.getMenTypemessage());

		if (!matcher.matches())
			throw new DataValidationSwitfException("TypeMessage no cumple el formato ISO establecido " + swfMsgParam.getMenTypemessage());
	}

	public String toXml(String mtfCodmt, String mtfBloque) {
		HashMap<Integer, SwfMencampos> swfCamposMap = camposToMap(mtfCodmt, mtfBloque);
		LinkedHashMap<String, Object> xmlProperties = toProps(swfCamposMap, true);

		return XmlToMap.xmlFromXPath4J(xmlProperties);
	}

	public HashMap<Integer, SwfMencampos> camposToMap(String mtfCodmt, String mtfBloque) {
		List<SwfMencampos> campos = getSwfMencamposIsoDao().findByMT(mtfCodmt, mtfBloque);
		HashMap<Integer, SwfMencampos> swfCamposMap = new HashMap<Integer, SwfMencampos>();
		for (SwfMencampos swfMencampos : campos) {
			swfCamposMap.put(swfMencampos.getMtfId(), swfMencampos);
		}
		return swfCamposMap; // camposToMap(campos);
	}

	public HashMap<Integer, Node<SwfMencampos>> camposToMapNodes(String mtfCodmt, String mtfBloque) {
		HashMap<Integer, Node<SwfMencampos>> swfCamposMap = new HashMap<Integer, Node<SwfMencampos>>();
		List<SwfMencampos> campos = getSwfMencamposIsoDao().findByMT(mtfCodmt, mtfBloque);
		List<String> keys = campos.stream().map(c -> c.getMtfXmltag()).distinct().collect(Collectors.toList());

		for (SwfMencampos swfMencampos : campos) {
			if (!StringUtils.isBlank(swfMencampos.getMtfXmltag()) && !StringUtils.isBlank(swfMencampos.toStringID())) {
				boolean conCh = keys.stream().filter(s -> s.startsWith(swfMencampos.getMtfXmltag() + "/")).findFirst().isPresent();
				if (!conCh) {
					Node<SwfMencampos> n = new Node<SwfMencampos>(swfMencampos);
					swfCamposMap.put(swfMencampos.getMtfId(), n);
				}
			}
		}
		return swfCamposMap;
	}

	public static HashMap<Integer, SwfMencampos> camposToMap(List<SwfMencampos> campos) {
		HashMap<Integer, SwfMencampos> swfCamposMap = new HashMap<Integer, SwfMencampos>();

		List<String> keys = campos.stream().map(c -> c.getMtfXmltag()).distinct().collect(Collectors.toList());

		for (SwfMencampos swfMencampos : campos) {
			if (!StringUtils.isBlank(swfMencampos.getMtfXmltag())) {
				boolean conCh = keys.stream().filter(s -> s != null && s.startsWith(swfMencampos.getMtfXmltag() + "/")).findFirst().isPresent();
				if (!conCh) {
					swfCamposMap.put(swfMencampos.getMtfId(), swfMencampos);
				}
			}
		}
		return swfCamposMap;
	}

	public static LinkedHashMap<String, Object> toProps(HashMap<Integer, SwfMencampos> swfCamposMap, boolean all) {
		LinkedHashMap<String, Object> xmlProperties = new LinkedHashMap<String, Object>();
		List<String> keys = swfCamposMap.values().stream().map(c -> c.getMtfXmltag()).distinct().collect(Collectors.toList());

		swfCamposMap.forEach((k, swfMencampos) -> {
			String arrStr = swfMencampos.getMtfGrpopt().compareTo(0) > 0 ? "[" + swfMencampos.getMtfGrpopt() + "]" : "";
			if (!all) {
				boolean conCh = keys.stream().filter(s -> s.startsWith(swfMencampos.getMtfXmltag() + "/")).findFirst().isPresent();
				if (!conCh) {
					xmlProperties.put(swfMencampos.getMtfXmltag() + arrStr, swfMencampos.getMtfId());
				}
			} else {
				xmlProperties.put(swfMencampos.getMtfXmltag() + arrStr, swfMencampos.getMtfId());
			}
		});
		return xmlProperties;
	}

	public static LinkedHashMap<String, Object> toProps(List<SwfMencampos> campos, boolean all) {
		LinkedHashMap<String, Object> xmlProperties = new LinkedHashMap<String, Object>();

		List<String> keys = campos.stream().filter(p -> !StringUtils.isBlank(p.getMtfXmltag())).map(c -> c.getMtfXmltag()).distinct()
				.collect(Collectors.toList());

		campos.forEach(swfMencampos -> {
			String arrStr = swfMencampos.getMtfGrpopt().compareTo(0) > 0 ? "[" + swfMencampos.getMtfGrpopt() + "]" : "";
			if (!all) {
				boolean conCh = keys.stream().filter(s -> s.startsWith(swfMencampos.getMtfXmltag() + "/")).findFirst().isPresent();
				if (!conCh) {
					xmlProperties.put(swfMencampos.getMtfXmltag() + arrStr, swfMencampos.getMtfId());
				}
			} else {
				xmlProperties.put(swfMencampos.getMtfXmltag() + arrStr, swfMencampos.getMtfId());
			}
		});
		return xmlProperties;
	}

	public static Predicate<SwfMencampos> fldNoAssignable() {
		return swfMencampos -> swfMencampos.getMtfTipocampo() != null
				&& (swfMencampos.getMtfTipocampo().trim().equals("GT") || swfMencampos.getMtfTipocampo().trim().startsWith("CH"));
	}

	public void settingHdr(AbstractMessage mt) {
	}

	public static void updateFromMxMessage(DataPDU dataPDU, MxSwiftMessage mxSwftMsg) {
//		dataPDU.setRevision("");
		Objects.requireNonNull(dataPDU, "Objecto dataPDU no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader(), "Objecto dataPDU.Header no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage(), "Objecto dataPDU.Header.Message no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getSender(), "Objecto Sender no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getReceiver(), "Objecto Receiver no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getInterfaceInfo(), "Objecto InterfaceInfo no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getNetworkInfo(), "Objecto NetworkInfo no debe ser nulo");
		// Validate.notBlank(xml, "XML to parse must not be a blank string");
		String uumid = MxDataTypesConversor.genUUMID("I", mxSwftMsg.getSender(), mxSwftMsg.getMxId().id(), mxSwftMsg.getReference(), "");
		dataPDU.getHeader().getMessage().setSenderReference(uumid);
		dataPDU.getHeader().getMessage().setMessageIdentifier(mxSwftMsg.getIdentifier());
		dataPDU.getHeader().getMessage().setFormat(mxSwftMsg.isMX() ? "MX" : "MT");
		dataPDU.getHeader().getMessage().setSubFormat(SubFormat.INPUT);
		// dataPDU.getHeader().getMessage().getSender().setDN("");
		dataPDU.getHeader().getMessage().getSender().getFullName().setX1(mxSwftMsg.getSender());
		// dataPDU.getHeader().getMessage().getReceiver().setDN("");
		dataPDU.getHeader().getMessage().getReceiver().getFullName().setX1(mxSwftMsg.getReceiver());
		dataPDU.getHeader().getMessage().getInterfaceInfo().setUserReference(mxSwftMsg.getReference());
		// dataPDU.getHeader().getMessage().getInterfaceInfo().setServiceURI("");
		// dataPDU.getHeader().getMessage().getInterfaceInfo().setMessageTypeURI("");
		// dataPDU.getHeader().getMessage().getNetworkInfo().setPriority("");
		// dataPDU.getHeader().getMessage().getNetworkInfo().setService("");
		dataPDU.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo().setRequestType(mxSwftMsg.getMessageType());
		// dataPDU.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo().setRequestSubtype("");
	}

	public static DataPDU newDataPDU() {
		DataPDU dataPDU = new DataPDU()//
				.setHeader((new Header())//
						.setMessage(new Message()//
								.setNetworkInfo(new NetworkInfo())//
								.setSender(new AddressInfo().setFullName(new AddressFullName()))//
								.setReceiver(new AddressInfo().setFullName(new AddressFullName()))//
								.setInterfaceInfo(new InterfaceInfo()))//
				);
		return dataPDU;
	}
}
