@javax.xml.bind.annotation.XmlSchema(namespace = "urn:swift:saa:xsd:saa.2.0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package gob.bcb.iso20022.swift.saa.model;
