
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para MessageStatus complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="MessageStatus"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SenderReference" type="{urn:swift:saa:xsd:saa.2.0}SenderReference"/&gt;
 *         &lt;element name="SeqNr" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="IsSuccess" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="ErrorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ErrorText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SAAInfo" type="{urn:swift:saa:xsd:saa.2.0}SAAInfo" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageStatus", propOrder = {
    "senderReference",
    "seqNr",
    "isSuccess",
    "errorCode",
    "errorText",
    "saaInfo"
})
public class MessageStatus {

    @XmlElement(name = "SenderReference", required = true)
    protected String senderReference;
    @XmlElement(name = "SeqNr")
    protected Integer seqNr;
    @XmlElement(name = "IsSuccess")
    protected boolean isSuccess;
    @XmlElement(name = "ErrorCode")
    protected String errorCode;
    @XmlElement(name = "ErrorText")
    protected String errorText;
    @XmlElement(name = "SAAInfo")
    protected SAAInfo saaInfo;

    /**
     * Obtiene el valor de la propiedad senderReference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenderReference() {
        return senderReference;
    }

    /**
     * Define el valor de la propiedad senderReference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenderReference(String value) {
        this.senderReference = value;
    }

    /**
     * Obtiene el valor de la propiedad seqNr.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSeqNr() {
        return seqNr;
    }

    /**
     * Define el valor de la propiedad seqNr.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSeqNr(Integer value) {
        this.seqNr = value;
    }

    /**
     * Obtiene el valor de la propiedad isSuccess.
     * 
     */
    public boolean isIsSuccess() {
        return isSuccess;
    }

    /**
     * Define el valor de la propiedad isSuccess.
     * 
     */
    public void setIsSuccess(boolean value) {
        this.isSuccess = value;
    }

    /**
     * Obtiene el valor de la propiedad errorCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Define el valor de la propiedad errorCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorCode(String value) {
        this.errorCode = value;
    }

    /**
     * Obtiene el valor de la propiedad errorText.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorText() {
        return errorText;
    }

    /**
     * Define el valor de la propiedad errorText.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorText(String value) {
        this.errorText = value;
    }

    /**
     * Obtiene el valor de la propiedad saaInfo.
     * 
     * @return
     *     possible object is
     *     {@link SAAInfo }
     *     
     */
    public SAAInfo getSAAInfo() {
        return saaInfo;
    }

    /**
     * Define el valor de la propiedad saaInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link SAAInfo }
     *     
     */
    public void setSAAInfo(SAAInfo value) {
        this.saaInfo = value;
    }

}
