
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para DistributionInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DistributionInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RecipientDNList" type="{urn:swift:saa:xsd:saa.2.0}RecipientListType"/&gt;
 *         &lt;element name="OrigSnFRef" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DistributionInfo", propOrder = {
    "recipientDNList",
    "origSnFRef"
})
public class DistributionInfo {

    @XmlElement(name = "RecipientDNList", required = true)
    protected RecipientListType recipientDNList;
    @XmlElement(name = "OrigSnFRef", required = true)
    protected String origSnFRef;

    /**
     * Obtiene el valor de la propiedad recipientDNList.
     * 
     * @return
     *     possible object is
     *     {@link RecipientListType }
     *     
     */
    public RecipientListType getRecipientDNList() {
        return recipientDNList;
    }

    /**
     * Define el valor de la propiedad recipientDNList.
     * 
     * @param value
     *     allowed object is
     *     {@link RecipientListType }
     *     
     */
    public void setRecipientDNList(RecipientListType value) {
        this.recipientDNList = value;
    }

    /**
     * Obtiene el valor de la propiedad origSnFRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigSnFRef() {
        return origSnFRef;
    }

    /**
     * Define el valor de la propiedad origSnFRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigSnFRef(String value) {
        this.origSnFRef = value;
    }

}
