package gob.bcb.iso20022.transforms;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.rules.AbstractAction;
import gob.bcb.iso20022.rules.CompiledRule;
import gob.bcb.iso20022.swift.MappingRule;

public class FuncDtTransform extends AbstractAction<MappingRule, CampoForm> {
	public final static String name = TransformEnum.FACTDATE.toString();

	public FuncDtTransform() {
		super(name);
	}

	@Override
	protected CampoForm initializeOutputResult(CompiledRule rule, MappingRule input) {
		return null;
	}

	@Override
	public CampoForm execute(CompiledRule rule, MappingRule input, Map<String, Object> facts) {
        SimpleDateFormat marshalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        SimpleDateFormat unmarshalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss[.SSS][XXX]");
        String strDate = marshalFormat.format(new Date());

		CampoForm cfo = new CampoForm();
		cfo.setTabla(rule.getRule().getNamespace());
		cfo.setColumn(rule.getRule().getName());
		cfo.setCatalogo(rule.getRule().getPath());
		
		cfo.setValor(strDate);
		input.updCFResult(cfo);		

		return cfo;
	}
}
