package gob.bcb.iso20022.swift.report;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.html2pdf.resolver.font.DefaultFontProvider;
import com.itextpdf.kernel.events.Event;
import com.itextpdf.kernel.events.IEventHandler;
import com.itextpdf.kernel.events.PdfDocumentEvent;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.pdf.xobject.PdfFormXObject;
import com.itextpdf.layout.Canvas;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.property.TextAlignment;
import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.SwiftBlockUser;
import com.prowidesoftware.swift.model.SwiftMessage;

import gob.bcb.iso20022.core.ArchivoSinpleImpl;
import gob.bcb.iso20022.dao.SwfMencamposIsoDao;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.ArchivoSinple;
import gob.bcb.iso20022.pojo.Block4;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.utils.UtilsDate;

/**
 * 
 * @author WHerrera
 *
 */
public class SwiftMessageReport {
	private static final Logger log = LoggerFactory.getLogger(SwiftMessageReport.class);
	private final static String SOUR = "reportSwift";

	private static final int OUTPUT_BYTE_ARRAY_INITIAL_SIZE = 4096;
	private static final String baseUri = "./src/main/resources/templates/";
	private final Properties props = new Properties();
	private SwfMsgParam swfMsgParam = new SwfMsgParam();
	private final Context context = new Context();
	private final List<Block4> block4List = new ArrayList<>();
	private final List<String> errors = new ArrayList<>();
	private SwfMencamposIsoDao swfMencamposDao;

	public SwiftMessageReport() {
		context.setVariable("appSubgcia", "");
		context.setVariable("appAppnombre", "");
		context.setVariable("msgTipodescrip", "");
		context.setVariable("senderDescrip", "");
		context.setVariable("receiverDescrip", "");
		context.setVariable("errors", errors);
	}

	public SwiftMessageReport(SwfMencamposIsoDao swfMencamposDao) {
		this();
		this.swfMencamposDao = swfMencamposDao;
	}

	public SwiftMessageReport initReport(String message, Consumer<SwfMsgParam> updMsgParamC) {
		SwiftMessageAbstract sma = FactoryParser.createParser(message).extractMetadata();
		swfMsgParam = sma.getSwfMsgParam();
		sma.setSwfMencamposDao(swfMencamposDao);

		fillMsgParam(sma);

		if (updMsgParamC != null)
			updMsgParamC.accept(swfMsgParam);

		swfMsgParam.setMenFechoralit(UtilsDate.stringFromDate(swfMsgParam.getMenFecreg(), "dd/MM/yyyy hh:mm:ss"));

		List<Block4> block4L = sma.createBlock4Long().getBlock4(); // fillBlock4(sma);
		block4List.addAll(block4L);
		errors.clear();
		if (swfMsgParam.getVerifica())
			errors.addAll(validateAndAddErrors(sma));
		return this;
	}

	public ArchivoSinple createReportFile(String dest) throws IOException {

		String html = genHtmlContext();
		if (StringUtils.isBlank(html)) {
			throw new RuntimeException("Proceso de reporte no produjo ningun contenido, revise parametros");
		}
		if (StringUtils.isBlank(dest)) {
			dest = swfMsgParam.getMenIdoperacion() + ".pdf";
		}
		ArchivoSinple archivoSinple = createPdf(html);
		archivoSinple.setName(dest);

		return archivoSinple;
	}

	public ArchivoSinple createPdf(String html) throws IOException {
		ConverterProperties properties = new ConverterProperties();
		properties.setFontProvider(new DefaultFontProvider(true, true, true));
		properties.setBaseUri(baseUri);

		Footer footerHandler = new Footer();
		try (ByteArrayOutputStream out = new ByteArrayOutputStream(OUTPUT_BYTE_ARRAY_INITIAL_SIZE)) {
			HtmlConverter.convertToPdf(html, out, properties);
			ArchivoSinple archivoSinple = ArchivoSinpleImpl.newFromOutputStream(out, "dummyfile.pdf");
			// archivoSinple.setName(dest);
			out.close();

			return archivoSinple;
		}
	}

	private String genHtmlContext() {
		String baseDir = "";
		// URL in =
		// SwiftMessageReport.class.getClassLoader().getResource("templates/reportSwift.html");

		try {
			// InputStream is = UtilsFile.inputStreamResource("templates/reportSwift.html",
			// getClass());
			URL in = Thread.currentThread().getContextClassLoader().getResource("templates/reportSwift.html");
			// Path path = Paths.get(in.toURI());
			// baseDir = path.toFile().getParent();
			File f = new File(in.toURI());
			baseDir = f.getParent();
			log.info("setting baseDir " + baseDir);
		} catch (Exception e) {
			log.error("Error!!! al setear baseDir: " + e.getMessage());
			baseDir = "templates";
			// throw new RuntimeException("Error " + e.getMessage(), e);
		}

		context.setVariable("baseDir", baseDir);
		context.setVariable("msgParam", swfMsgParam);
		context.setVariable("block4list", block4List);
		props.forEach((k, v) -> {
//			log.info("props " + k + " = " + v);
			context.setVariable(k.toString(), v);
		});

		TemplateEngine templateEngine = ContextThymeleafEngine.instance().initialize().templateEngine();
		String html = templateEngine.process(SOUR, context);

		// log.debug(html);
		return html;
	}

	private SwfMsgParam fillMsgParam(SwiftMessageAbstract sma) {
		if (sma.isMt()) {
			MtSwiftMessage mt = (MtSwiftMessage) sma.getMsg();
			
			SwiftMessage swiftMessage = mt.modelMessage();
			// SwiftBlock5 block5 = swiftMessage.getuBlock5();
			SwiftBlockUser sBlock = swiftMessage.getUserBlock("S");
			if (sBlock != null && !sBlock.isEmpty()) {
				swfMsgParam.setUserBlock(sBlock.toJson());
			} else {
				//swfMsgParam.setUserBlock(UtilsDate.stringFromDate(swfMsgParam.getMenFecreg(), "dd/MM/yyyy hh:mm:ss"));
			}
		} else if (sma.isMx()) {
			String sign = sma.getdPDUWriter().getSignatureValue();
			if (!StringUtils.isBlank(sign)) {
				swfMsgParam.setUserBlock("LAU: " + sign  +" Hash: " + sma.getdPDUWriter().getDigestValue());
			} else {
				//swfMsgParam.setUserBlock(UtilsDate.stringFromDate(swfMsgParam.getMenFecreg(), "dd/MM/yyyy hh:mm:ss"));
			}
		}
		swfMsgParam
				.setFooter(swfMsgParam.getAuditusr() + ":" + swfMsgParam.getAuditwst() + ":" + UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy hh:mm:ss"));
		return sma.getSwfMsgParam();
	}

	public List<String> validateAndAddErrors(SwiftMessageAbstract sma) {
		List<String> errors;
		try {
			errors = sma.validateSyntax();
			log.info("errors =====> " + errors.size());
			return errors;
		} catch (Exception e) {
			log.error("Error al validar sintaxis " + e.getMessage());
			return new ArrayList<>();
			// throw new RuntimeException("Error al validar sintaxis " + e.getMessage(), e);
		}
	}

	public Properties getProps() {
		return props;
	}

	public SwfMsgParam getSwfMsgParam() {
		return swfMsgParam;
	}

	protected class Footer implements IEventHandler {
		protected PdfFormXObject placeholder;
		protected float side = 20;
		protected float x = 300;
		protected float y = 25;
		protected float space = 4.5f;
		protected float descent = 3;

		public Footer() {
			placeholder = new PdfFormXObject(new Rectangle(0, 0, side, side));
		}

		@Override
		public void handleEvent(Event event) {
			PdfDocumentEvent docEvent = (PdfDocumentEvent) event;
			PdfDocument pdf = docEvent.getDocument();
			PdfPage page = docEvent.getPage();
			int pageNumber = pdf.getPageNumber(page);
			Rectangle pageSize = page.getPageSize();

			// Creates drawing canvas
			PdfCanvas pdfCanvas = new PdfCanvas(page);
			Canvas canvas = new Canvas(pdfCanvas, pageSize);

			Paragraph p = new Paragraph().add("Page ").add(String.valueOf(pageNumber)).add(" of");

			canvas.showTextAligned(p, x, y, TextAlignment.RIGHT);
			canvas.close();

			// Create placeholder object to write number of pages
			pdfCanvas.addXObjectAt(placeholder, x + space, y - descent);
			pdfCanvas.release();
		}

		public void writeTotal(PdfDocument pdf) {
			Canvas canvas = new Canvas(placeholder, pdf);
			canvas.showTextAligned(String.valueOf(pdf.getNumberOfPages()), 0, descent, TextAlignment.LEFT);
			canvas.close();
		}
	}

}
