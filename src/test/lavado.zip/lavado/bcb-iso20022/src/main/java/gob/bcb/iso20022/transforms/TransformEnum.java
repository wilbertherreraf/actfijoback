package gob.bcb.iso20022.transforms;

public enum TransformEnum {
	FACTVAL, MTTOMX, GENLIST, AMTCURR, FACTDATE, FLDMX, FLDMT
}
