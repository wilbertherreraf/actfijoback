package gob.bcb.iso20022.commons;


public class Constants {
	public static final String SWF_PATT_NEMO_SSF = "SSF";
	public static final String SWF_PATT_NEMO_SF = "SF";
	public static final String SWF_PATT_SEP = ".";
	public static final String SWF_PATT_SEPUNIQ = "[" + SWF_PATT_SEP + "]";
	public static final String SWF_PATT_SEQ = "S[A-Z]";
	public static final String SWF_PATT_SUBSEQ = SWF_PATT_SEQ + "[0-9]";
	public static final String SWF_PATT_GRUPOPT = SWF_PATT_SEPUNIQ + "[0-9]" + SWF_PATT_SEPUNIQ;
	public static final String SWF_PATT_FIELDONLY = "[1-9][0-9][A-Z]{0,1}";
	public static final String SWF_PATT_FIELDORDER = "(\\.[1-9]){0,1}";
	public static final String SWF_PATT_FIELD = SWF_PATT_FIELDONLY + SWF_PATT_FIELDORDER;
	public static final String SWF_PATT_NAMECOMPO = "[A-Za-z]{3,3}[A-Z0-9a-z]{0,}";

	public static final String CAMPOFORM_TABLANAME_SEPARATOR = "_";
	public static final String JB_TABLANAME_SEPARATOR = "_";
	public static final String JB_TABLACOLUMN_SEPARATOR = ".";

	public final static String ISO20022_REGEX = "[a-z]{4}\\.[0-9]{3}\\.[0-9]{3}\\.[0-9]{2}([A-Z0-9]{2})?";
	
	public static final String CODCAMPO_IDAPP = "IDAPP";
	public static final String CODCAMPO_SERVID = "SERVID";
	public static final String CODCAMPO_LTERMINAL = "LTID";
	public static final String CODCAMPO_SESSNUM = "SESSNUM";
	public static final String CODCAMPO_SEQNUM = "SEQNUM";
	public static final String CODCAMPO_PRIORITY = "PRIOR";
	public static final String CODCAMPO_RECEIVER = "RECEIVER";
	
	public static final String TIPO_MENSAJE_IN = "I";
	public static final String TIPO_MENSAJE_OUT = "O";
}
