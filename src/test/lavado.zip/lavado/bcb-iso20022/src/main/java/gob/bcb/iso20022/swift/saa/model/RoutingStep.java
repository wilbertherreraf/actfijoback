
package gob.bcb.iso20022.swift.saa.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para RoutingStep.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="RoutingStep"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="Verify"/&gt;
 *     &lt;enumeration value="Authorise"/&gt;
 *     &lt;enumeration value="Modify"/&gt;
 *     &lt;enumeration value="ReadyToSend"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "RoutingStep")
@XmlEnum
public enum RoutingStep {

    @XmlEnumValue("Verify")
    VERIFY("Verify"),
    @XmlEnumValue("Authorise")
    AUTHORISE("Authorise"),
    @XmlEnumValue("Modify")
    MODIFY("Modify"),
    @XmlEnumValue("ReadyToSend")
    READY_TO_SEND("ReadyToSend");
    private final String value;

    RoutingStep(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RoutingStep fromValue(String v) {
        for (RoutingStep c: RoutingStep.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
