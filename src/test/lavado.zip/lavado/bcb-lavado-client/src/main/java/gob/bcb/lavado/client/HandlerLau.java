package gob.bcb.lavado.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.client.lau.GeneratorLAU;

public class HandlerLau {
	private static final Logger log = LoggerFactory.getLogger(HandlerLau.class);
	private static GeneratorLAU instance;
	//private static HandlerLau instance;
	
	private HandlerLau(){
	}
	
	public static GeneratorLAU getCurrentInstance(){
		if (instance == null){
			throw new RuntimeException("Instancia no inicializada");			
		}
		return instance;
	}
	
	public static GeneratorLAU initCurrentInstance(String pathBase, String idGenerator) throws Exception{
		if (instance == null){
			instance = new GeneratorLAU(pathBase, idGenerator);
			instance.loadGeneratorLau(false);
		}
		
		return instance;
	}
	
	
}
