package gob.bcb.lavado.client.pojos;

import java.util.Date;

public class GenLauDto {
	private String lauKeyFirstPart;
	private String lauKeySecondPart;
	private Integer diasVigencia = 0;
	private Date fechaCreacion;
	private Date fechaCaducidad;
	private String lauEstado;	
	public String getLauKeyFirstPart() {
		return lauKeyFirstPart;
	}

	public void setLauKeyFirstPart(String lauKeyFirstPart) {
		this.lauKeyFirstPart = lauKeyFirstPart;
	}

	public String getLauKeySecondPart() {
		return lauKeySecondPart;
	}

	public void setLauKeySecondPart(String lauKeySecondPart) {
		this.lauKeySecondPart = lauKeySecondPart;
	}

	public Integer getDiasVigencia() {
		return diasVigencia;
	}

	public void setDiasVigencia(Integer diasVigencia) {
		this.diasVigencia = diasVigencia;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public Date getFechaCaducidad() {
		return fechaCaducidad;
	}

	public void setFechaCaducidad(Date fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}

	public String getLauEstado() {
		return lauEstado;
	}

	public void setLauEstado(String lauEstado) {
		this.lauEstado = lauEstado;
	}
	
}
