package gob.bcb.lavado.client.crypto;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.Mac;

import org.apache.commons.lang3.tuple.ImmutablePair;

public interface CryptoProvider {

	/**
	 * Returns a cipher object for symmetric data encrpytion.
	 * 
	 * @param key
	 *            The encryption key returned from getSeededKey(). Other keys
	 *            may not be accepted.
	 * @param cryptMode
	 *            One of Cipher.ENCRYPT_MODE, Cipher.DECRYPT_MODE.
	 * @return A Cipher object that can be used for encrpytion/description,
	 *         depending on the value of cryptMode.
	 * @throws InvalidAlgorithmParameterException
	 */
	Cipher getCipher(Key key, int cryptMode) throws InvalidKeyException, InvalidAlgorithmParameterException;

	void addKey(String fileName, String password, Key key, String nameKey, String keyAlias, String keyPassword) throws Exception;

	void addKeySymetric(String keyAlias, String keyPassword) throws Exception;

	Key getKeySystem();

	String exportKeyToStr(String keyAlias, String keyAliasExport, String keyPassword) throws Exception;

	void importKeyFromString(String fsEncode, String passFs, String keyAlias, String keyAliasNew, String keyPassword) throws Exception;

	void addKeyMac(String keyAlias, String keyPassword) throws Exception;

	Mac initCipherMac(Key key) throws InvalidKeyException;

	Key getKey(String keyAlias);


	/**
	 * Returns the server's private key used for digitally signing data. /
	 * PrivateKey loadPrivateKey();
	 * 
	 * /** Returns the server's certificate used for digitally validating
	 * signatures. / Certificate loadCertificate();
	 * 
	 * /** Returns the signature algorithm (RSA/DSA) / Signature
	 * getSignatureAlgorithm();
	 */
}
