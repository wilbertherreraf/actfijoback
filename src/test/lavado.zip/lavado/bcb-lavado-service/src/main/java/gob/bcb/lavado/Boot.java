package gob.bcb.lavado;

import java.io.File;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.core.env.Environment;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.config.LavadoProperties;

public class Boot {
	private static final Logger log = LoggerFactory.getLogger(Boot.class);

	@Autowired
	private Environment env;

//	@Autowired
//	private LavadoProperties lavadoProperties;
	@Autowired
	private AppProperties appProperties;
	@PostConstruct
	public void initApplication() throws Throwable {
		log.info("Running with Spring profile(s) : {}", Arrays.toString(env.getActiveProfiles()));
		log.info("Running with Spring profile(s) : {}", appProperties.getLavado().getAppdir());		
		setupStorage();
		Collection<String> activeProfiles = Arrays.asList(env.getActiveProfiles());
		if (activeProfiles.contains(Constants.SPRING_PROFILE_DEVELOPMENT) && activeProfiles.contains(Constants.SPRING_PROFILE_PRODUCTION)) {
			log.error("You have misconfigured your application! It should not run " + "with both the 'dev' and 'prod' profiles at the same time.");
		}
	}

	public static void main(String[] args) throws UnknownHostException {
		log.info("===========OOOOOOOOOOOOOoooooOOOOOOOO==================");
		SpringApplication app = new SpringApplication(ConfigApp.class);
		Map<String, Object> defProperties = new HashMap<>();
		defProperties.put("spring.profiles.default", Constants.SPRING_PROFILE_DEVELOPMENT);
		
		app.setDefaultProperties(defProperties);
		
		Environment env = app.run(args).getEnvironment();
		log.info(env.getProperty("spring.application.name") + " " + env.getProperty("spring.config.location"));

		// ApplicationContext ctx = SpringApplication.run(Boot.class, args);
		//
		// Environment env = ctx.getEnvironment();
		//
		// log.info(
		// "\n----------------------------------------------------------\n\t" +
		// "Application '{}' is running! Access URLs:\n\t"
		// + "Local: \t\thttp://127.0.0.1:{}\n\t" + "External:
		// \thttp://{}:{}\n----------------------------------------------------------",
		// env.getProperty("spring.application.name"),
		// env.getProperty("server.port"),
		// InetAddress.getLocalHost().getHostAddress(),
		// env.getProperty("server.port"));
		//
		// String configServerStatus = env.getProperty("configserver.status");
		// log.info("\n----------------------------------------------------------\n\t"
		// +
		// "Config Server:
		// \t{}\n----------------------------------------------------------",
		// configServerStatus == null ? "Not found or not setup for this
		// application" : configServerStatus);
		//
		// String[] beanNames = ctx.getBeanDefinitionNames();
		// Arrays.sort(beanNames);
	}

	protected void setupStorage() throws Throwable {
		final File DIR_QUERIES_DIRECTORY = new File(appProperties.getLavado().getAppdir(), Constants.DIR_QUERIES);

		File[] files = { new File(appProperties.getLavado().getAppdir()), DIR_QUERIES_DIRECTORY };
		for (File f : files) {
			log.info("File " + f.getAbsolutePath());
			if (!f.exists() && !f.mkdirs()) {
				String msg = String.format(
						"you must create the queries directory ('%s') " + "and make it accessible to this process. Unable to do so from this process.",
						f.getAbsolutePath());
				throw new RuntimeException(msg);
			}
		}
	}
}
