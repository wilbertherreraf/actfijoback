package gob.bcb.lavado.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Norms;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TermVector;

/**
 * The persistent class for the ofa_akalist database table.
 * 
 */
@Entity
@Table(name = "ofa_akalist")
//@NamedQuery(name = "OfaAkalist.findAll", query = "SELECT o FROM OfaAkalist o")
public class OfaAkalist implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="aka_id")
	@DocumentId
    private Integer akaId;
	
	@Column(name = "aka_uid")
	//@Field(name="akaUidID", store = Store.YES, analyze = Analyze.NO, norms = Norms.NO)
	private Integer akaUid;

	@Field(analyze = Analyze.NO, norms = Norms.NO)
	//@Field(store = Store.YES, termVector = TermVector.NO)
	@Column(name = "aka_category")
	private String akaCategory;

	@Field(store = Store.YES, analyze = Analyze.NO, norms = Norms.NO)
	//@Field(store = Store.YES, termVector = TermVector.NO)
	@Column(name = "aka_entryuid")
	private Integer akaEntryuid;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "aka_firstname")
	private String akaFirstname;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "aka_lastname")
	private String akaLastname;

	@Field(analyze = Analyze.NO, norms = Norms.NO)
	@Column(name = "aka_type")
	private String akaType;

	//@ContainedIn
	@IndexedEmbedded(includeEmbeddedObjectId = true)	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "aka_entryuid", nullable = false, insertable = false, updatable = false, referencedColumnName = "sdn_id")
	private OfaSdnentry ofaSdnentry;

	public OfaAkalist() {
	}

	public Integer getAkaUid() {
		return this.akaUid;
	}

	public void setAkaUid(Integer akaUid) {
		this.akaUid = akaUid;
	}

	public String getAkaCategory() {
		return this.akaCategory;
	}

	public void setAkaCategory(String akaCategory) {
		this.akaCategory = akaCategory;
	}

	public Integer getAkaEntryuid() {
		return this.akaEntryuid;
	}

	public void setAkaEntryuid(Integer akaEntryuid) {
		this.akaEntryuid = akaEntryuid;
	}

	public String getAkaFirstname() {
		return this.akaFirstname;
	}

	public void setAkaFirstname(String akaFirstname) {
		this.akaFirstname = akaFirstname;
	}

	public String getAkaLastname() {
		return this.akaLastname;
	}

	public void setAkaLastname(String akaLastname) {
		this.akaLastname = akaLastname;
	}

	public String getAkaType() {
		return this.akaType;
	}

	public void setAkaType(String akaType) {
		this.akaType = akaType;
	}

	public OfaSdnentry getOfaSdnentry() {
		return ofaSdnentry;
	}

	public void setOfaSdnentry(OfaSdnentry ofaSdnentry) {
		this.ofaSdnentry = ofaSdnentry;
	}

	public Integer getAkaId() {
		return akaId;
	}

	public void setAkaId(Integer akaId) {
		this.akaId = akaId;
	}

}
