package gob.bcb.lavado.exception;

public class BusinessException extends Exception {

    /**
     * Crear una nueva instancia de <code>DataBaseException</code> sin mensaje.
     */
    public BusinessException() {
    }
    /**
     * Construir una instancia de <code>DataBaseException</code> especifiacndo el mensaje.
     * @param msg el mensaje.
     */
    public BusinessException(String msg) {
        super(msg);
    }
    public BusinessException(String msg, Throwable t) {
		super(msg, t);
	}
    public BusinessException(Throwable t) {
		super(t);
	}    
}

