package gob.bcb.lavado.commons;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.xwpf.converter.pdf.PdfConverter;
import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.io.parser.SwiftParser;
import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.SwiftBlock1;
import com.prowidesoftware.swift.model.SwiftBlock2;
import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftBlock5;
import com.prowidesoftware.swift.model.SwiftBlockUser;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;

import fr.opensagres.xdocreport.core.XDocReportException;
import fr.opensagres.xdocreport.document.IXDocReport;
import fr.opensagres.xdocreport.document.registry.XDocReportRegistry;
import fr.opensagres.xdocreport.template.IContext;
import fr.opensagres.xdocreport.template.TemplateEngineKind;
import fr.opensagres.xdocreport.template.formatter.FieldsMetadata;
import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.pojos.GenUsuario;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.swift.SwiftMessageBcb;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.HeaderMsg;
import gob.bcb.swift.pojos.SwiftDatos;

public class ReporteSwift extends ArchivoSinpleServiceImpl {

	private static final Logger log = LoggerFactory.getLogger(ReporteSwift.class);

	private ArchivoSinpleServiceImpl templateService = new ArchivoSinpleServiceImpl();
	private IXDocReport report;
	private IContext context;
	private static final int OUTPUT_BYTE_ARRAY_INITIAL_SIZE = 4096;
	public static final String FILE_REPORT_SWIFT = "reposwift.docx";
	
	public ReporteSwift() {

	}

	public void inicializar(ArchivoSinpleServiceImpl templateService) {
		try {
			log.info("inicializando report xdocreport " + (TemplateEngineKind.Freemarker == null) + " " + templateService.getArchivoSinple().getName());
			report = XDocReportRegistry.getRegistry().loadReport(templateService.getArchivoSinple().getStream(), TemplateEngineKind.Freemarker);
			FieldsMetadata metadata = report.createFieldsMetadata();
			metadata.load("block4", Block4.class, true);

			context = report.createContext();
			log.info("Contexto Freemaker inicializado ...");
		} catch (IOException e) {
			log.error("IOException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("IOException: Error al generar Documento " + e.getMessage(), e);
		} catch (XDocReportException e) {
			log.error("XDocReportException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("XDocReportException: Error al generar Documento " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Exception: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("Exception: Error al generar Documento " + e.getMessage(), e);
		}
	}
	
	public void populateReport(SwiftDatos swiftDatos,List<Block4> block4List) {
		HeaderMsg headerMsg = createHeaderMsgReport(swiftDatos.getSwiftMessageBcb(), swiftDatos );		
		context.put("header", headerMsg);
		context.put("block4", block4List);
	}
	
	public void populateReportError(String error, String Descripcion) {
		HeaderMsg headerMsg = new HeaderMsg();
//		headerMsg.setMt(Descripcion);
//		headerMsg.setSender(error);
		headerMsg.setFechora(UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy hh:mm:ss"));		
		removeNulsFromHeaderMsg(headerMsg);		
		List<Block4> block4List		 = new ArrayList<>();
		Block4 block4 = new Block4();
		block4.setName("ERROR");
		block4.setValue(Descripcion);		
		block4.setReference(error);		
		block4.setValueDescrip(Descripcion);
		block4List.add(block4);
		context.put("header", headerMsg);
		context.put("block4", block4List);
		
	}
	
	private HeaderMsg createHeaderMsgReport(SwiftMessageBcb swiftMessageBcb, SwiftDatos swiftDatos ){
		log.debug("En createHeaderMsgReport: \n");

		HeaderMsg headerMsg = new HeaderMsg();
		headerMsg.setMencodmen("");
		if (swiftDatos.getSwfMensaje().getMenCodmen() != null)
			headerMsg.setMencodmen(String.valueOf(swiftDatos.getSwfMensaje().getMenCodmen()));

		headerMsg.setNrocorr("");
		if (swiftDatos.getSwfMensaje().getMenNrocorr() != null)
			headerMsg.setNrocorr(String.valueOf(swiftDatos.getSwfMensaje().getMenNrocorr()));

		headerMsg.setOperator((swiftDatos.getSwfMensaje().getMenCodusrswf() == null ? "" : swiftDatos.getSwfMensaje().getMenCodusrswf()));
		headerMsg.setCodusuario((swiftDatos.getAuditusr() == null ? "" : swiftDatos.getAuditusr()) + " "
				+ (swiftDatos.getAuditwst() == null ? "" : swiftDatos.getAuditwst()));
		
		headerMsg.setPriority(swiftMessageBcb.getBlock2().getMessagePriority());

		headerMsg.setNroreference(swiftDatos.getSwfMensaje().getMenInout());
		headerMsg.setReference(swiftDatos.getSwfMensaje().getMenCodswift());

		headerMsg.setMur(swiftMessageBcb.getSwiftMessage().getMUR());
		headerMsg.setMt(swiftDatos.getSwfMensaje().getMenCodmt());
		headerMsg.setMtdescrip(swiftDatos.getSwfTipomensaje().getTimDescrip());
		
		String senderdescrip = (swiftDatos.getSwfBicsSender().getBicDescrip() == null ? "" : swiftDatos.getSwfBicsSender().getBicDescrip()
				.trim())
				+ "\n"
				+ (swiftDatos.getSwfBicsSender().getBicCiudad() == null ? "" : swiftDatos.getSwfBicsSender().getBicCiudad().trim())
				+ ", " + (swiftDatos.getSwfBicsSender().getBicPais() == null ? "" : swiftDatos.getSwfBicsSender().getBicPais().trim());
		headerMsg.setSender(swiftDatos.getSwfMensaje().getMenEmisor());		
		headerMsg.setSenderdescrip(senderdescrip);

		String receiverdescrip = (swiftDatos.getSwfBicsReceiver().getBicDescrip() == null ? "" : swiftDatos.getSwfBicsReceiver().getBicDescrip()
				.trim())
				+ "\n"
				+ (swiftDatos.getSwfBicsReceiver().getBicCiudad() == null ? "" : swiftDatos.getSwfBicsReceiver().getBicCiudad().trim())
				+ ", " + (swiftDatos.getSwfBicsReceiver().getBicPais() == null ? "" : swiftDatos.getSwfBicsReceiver().getBicPais().trim());		
		headerMsg.setReceiver(swiftDatos.getSwfMensaje().getMenReceiver());
		headerMsg.setReceiverdescrip(receiverdescrip);
			
		SwiftBlock5 block5 = swiftMessageBcb.getSwiftMessage().getBlock5();

		if (block5 == null) {
			block5 = new SwiftBlock5();
			headerMsg.setFooter(UtilsDate.stringFromDate(swiftDatos.getSwfMensaje().getMenAuditfho(), "dd/MM/yyyy hh:mm:ss"));
		} else {
			headerMsg.setFooter(block5.toJson());
		}
		SwiftBlockUser swiftBlockUser  = swiftMessageBcb.getSwiftMessage().getUserBlock(SwiftMessageBcb.nameUserBlockS);
		if (swiftBlockUser != null) {
			headerMsg.setUserblock(swiftBlockUser.toJson());
		} else {
			headerMsg.setUserblock("");
		}
		headerMsg.setFechora(UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy hh:mm:ss"));
		
		removeNulsFromHeaderMsg(headerMsg);
		return headerMsg;
	}
	public void render() {
		log.info("##### En renderReport...##########");
		ByteArrayOutputStream out = null;
		long start = System.currentTimeMillis();
		try {
			log.info("Antes de renderReport ");
			out = new ByteArrayOutputStream(OUTPUT_BYTE_ARRAY_INITIAL_SIZE);
			report.process(context, out);

			newFromOutputStream(out, templateService.getArchivoSinple().getNameOriginal());
			out.close();
			log.info("##### FIN renderReport...########## [" + (System.currentTimeMillis() - start) + " ms]");
		} catch (IOException e) {
			log.error("IOException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("IOException: Error al generar Documento " + e.getMessage(), e);
		} catch (XDocReportException e) {
			log.error("XDocReportException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("XDocReportException: Error al generar Documento " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Exception: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("Exception: Error al generar Documento " + e.getMessage(), e);
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					log.error("Error al cerrar Documento " + e.getMessage(), e);
				}
			}
		}
	}

	public ArchivoSinple convertToPDF(ArchivoSinple archivoSinple, String nameFile) {
		log.info("eN convertToPDF archivoSinple " + archivoSinple.getHash());
		long startTime = System.currentTimeMillis();
		ByteArrayOutputStream out = null;
		try {
			// String file = "CL01FM";
			InputStream in = archivoSinple.getStream();
			// 1) Load docx with POI XWPFDocument
			XWPFDocument document = new XWPFDocument(in);

			// 2) Convert POI XWPFDocument 2 PDF with iText
			out = new ByteArrayOutputStream(OUTPUT_BYTE_ARRAY_INITIAL_SIZE);
			PdfOptions options = null;

			PdfConverter.getInstance().convert(document, out, options);

			ArchivoSinpleServiceImpl archivoSinpleServiceImpl = new ArchivoSinpleServiceImpl();
			archivoSinpleServiceImpl.newFromOutputStream(out, nameFile);
			archivoSinpleServiceImpl.getArchivoSinple().setNameOriginal(nameFile);

			out.close();
			log.info("Generate PDF " + archivoSinpleServiceImpl.getArchivoSinple().getName() + "["
					+ archivoSinpleServiceImpl.getArchivoSinple().getNameOriginal() + "] with " + (System.currentTimeMillis() - startTime) + " ms.");
			return archivoSinpleServiceImpl.getArchivoSinple();
		} catch (IOException e) {
			log.error("IOException: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("IOException: Error al generar Documento " + e.getMessage(), e);
		} catch (Exception e) {
			log.error("Exception: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("Exception: Error al generar Documento " + e.getMessage(), e);
		} catch (Throwable e) {
			log.error("Throwable: Error al generar Documento " + e.getMessage(), e);
			throw new SwiftAdminException("Throwable: Error al generar Documento " + e.getMessage(), e);
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					log.error("Error al cerrar Documento " + e.getMessage(), e);
				}
			}
		}
	}

	public ArchivoSinpleServiceImpl getTemplateService() {
		return templateService;
	}

	public void setTemplateService(ArchivoSinpleServiceImpl templateService) {
		this.templateService = templateService;
	}

	public IContext getContext() {
		return context;
	}

	public void setContext(IContext context) {
		this.context = context;
	}

	public void initReporteSwift() {
		// inicialiar reporte swift
		InputStream in = this.getClass().getClassLoader().getResourceAsStream(FILE_REPORT_SWIFT);

		ArchivoSinpleServiceImpl archivoSinpleServiceImpl = new ArchivoSinpleServiceImpl();
		archivoSinpleServiceImpl.fileUpload(in, FILE_REPORT_SWIFT);
		archivoSinpleServiceImpl.getArchivoSinple().setDirectory("");

		this.templateService = archivoSinpleServiceImpl;
		inicializar(this.templateService);
	}
	
	private void removeNulsFromHeaderMsg(HeaderMsg headerMsg) {
		headerMsg.setMencodmen((headerMsg.getMencodmen() == null ? "" : headerMsg.getMencodmen().trim()));
		headerMsg.setOperator((headerMsg.getOperator() == null ? "" : headerMsg.getOperator().trim()));
		headerMsg.setPriority((headerMsg.getPriority() == null ? "" : headerMsg.getPriority().trim()));
		headerMsg.setNroreference((headerMsg.getNroreference() == null ? "" : headerMsg.getNroreference().trim()));
		headerMsg.setReference((headerMsg.getReference() == null ? "" : headerMsg.getReference().trim()));
		headerMsg.setNroinreference((headerMsg.getNroinreference() == null ? "" : headerMsg.getNroinreference().trim()));
		headerMsg.setInreference((headerMsg.getInreference() == null ? "" : headerMsg.getInreference().trim()));
		headerMsg.setMt((headerMsg.getMt() == null ? "" : headerMsg.getMt().trim()));
		headerMsg.setMtdescrip((headerMsg.getMtdescrip() == null ? "" : headerMsg.getMtdescrip().trim()));
		headerMsg.setSender((headerMsg.getSender() == null ? "" : headerMsg.getSender().trim()));
		headerMsg.setSenderdescrip((headerMsg.getSenderdescrip() == null ? "" : headerMsg.getSenderdescrip().trim()));
		headerMsg.setReceiver((headerMsg.getReceiver() == null ? "" : headerMsg.getReceiver().trim()));
		headerMsg.setReceiverdescrip((headerMsg.getReceiverdescrip() == null ? "" : headerMsg.getReceiverdescrip().trim()));
		headerMsg.setMur((headerMsg.getMur() == null ? "" : headerMsg.getMur().trim()));
		headerMsg.setNrocorr((headerMsg.getNrocorr() == null ? "" : headerMsg.getNrocorr().trim()));
		headerMsg.setFooter((headerMsg.getFooter() == null ? "" : headerMsg.getFooter().trim()));
		headerMsg.setUserblock((headerMsg.getUserblock() == null ? "" : headerMsg.getUserblock().trim()));
		headerMsg.setFechora((headerMsg.getFechora() == null ? "" : headerMsg.getFechora().trim()));
		headerMsg.setCodusuario((headerMsg.getCodusuario() == null ? "" : headerMsg.getCodusuario().trim()));
	}
	
}
