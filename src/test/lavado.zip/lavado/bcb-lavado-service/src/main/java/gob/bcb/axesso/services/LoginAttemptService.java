package gob.bcb.axesso.services;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import gob.bcb.lavado.commons.Constants;

@Service
public class LoginAttemptService {
	private static final Logger log = LoggerFactory.getLogger(LoginAttemptService.class);
	private final int MAX_ATTEMPT = Constants.SEC_MAX_ATTEMPT;

	private LoadingCache<String, Integer> attemptsCache;

	@Autowired
	private AxessoDaoService axessoDaoService;

	public LoginAttemptService() {
		super();
		init(Constants.SEC_TIME_LOCKED_FOR_ATTEMPS);
	}
	
	public void init(Integer timelockedInSeconds){
		log.info("Iniciando cache sessions " + timelockedInSeconds);
		attemptsCache = CacheBuilder.newBuilder().maximumSize(350).expireAfterWrite(timelockedInSeconds, TimeUnit.SECONDS).build(new CacheLoader<String, Integer>() {
			@Override
			public Integer load(final String key) {
				return 0;
			}
		});
	}
	//

	public boolean loginSucceeded(final String username) {
		attemptsCache.invalidate(username);
		return axessoDaoService.loginSuccessAndPasswordChangeRequired(username);
	}

	public void loginFailed(final String key) {
		int attempts = 0;
		try {
			attempts = attemptsCache.get(key);
		} catch (final ExecutionException e) {
			attempts = 0;
		}
		attempts++;
		attemptsCache.put(key, attempts);
		try {
			axessoDaoService.actualizaIntentos(key, attempts);
		} catch (Exception e) {
			log.error(e.getMessage());
			attemptsCache.invalidate(key);			
		}
		
	}

	public boolean isBlocked(final String key) {
		try {
			boolean blocked = attemptsCache.get(key) >= MAX_ATTEMPT;
			if (blocked) {
				Integer pswIntfallpassw = axessoDaoService.getIntentos(key);

				blocked = pswIntfallpassw.compareTo(0) > 0;

				if (!blocked) {
					// desbloqueado por el administrador ... posiblemente
					attemptsCache.invalidate(key);
				}
			}
			log.info("user {} Bloqueado? {}", key, blocked);
			return blocked;
		} catch (final Exception e) {
			return false;
		}
	}

}
