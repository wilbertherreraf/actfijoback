package gob.bcb.lavado.lavadoclient;

public class SearchParamsBean {
 
}
