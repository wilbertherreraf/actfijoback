package gob.bcb.lavado.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TermVector;

@Entity
@Table(name = "ofa_blanklist")
public class OfaBlanklist {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "blc_id")
	@DocumentId
	private Integer blcId;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "blc_content")
	private String blcContent;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "blc_estadoauto")
	private String blcEstadoauto;
	
	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "blc_type")
	private String blcType;

	@Column(name = "blc_tabstatusauto")
	private Integer blcTabstatusauto;
	
	@Column(name = "blc_statusauto")
	private Integer blcStatusauto;
	
	@Field(store = Store.NO, analyze=Analyze.NO,index=Index.NO)		
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "blc_auditfho")
	private Date blcAuditfho;

	@Field(store = Store.NO, analyze=Analyze.NO,index=Index.NO)		
	@Column(name = "blc_auditusr")
	private String blcAuditusr;

	@Field(store = Store.NO, analyze=Analyze.NO,index=Index.NO)		
	@Column(name = "blc_auditwst")
	private String blcAuditwst;

	//@Transient
	@ManyToOne(fetch = FetchType.EAGER)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumns({ @JoinColumn(updatable=false,insertable=false,name = "blc_statusauto", referencedColumnName = "des_codigo"),
			@JoinColumn(updatable=false,insertable=false,name = "blc_tabstatusauto", referencedColumnName = "des_codtab") })
	private GenDesctabla genDesctablaStatusauto;
	
	public OfaBlanklist(){
		
	}
	
	public Integer getBlcId() {
		return blcId;
	}

	public void setBlcId(Integer blcId) {
		this.blcId = blcId;
	}

	public String getBlcContent() {
		return blcContent;
	}

	public void setBlcContent(String blcContent) {
		this.blcContent = blcContent;
	}

	public String getBlcType() {
		return blcType;
	}

	public void setBlcType(String blcType) {
		this.blcType = blcType;
	}

	public Integer getBlcTabstatusauto() {
		return blcTabstatusauto;
	}

	public void setBlcTabstatusauto(Integer blcTabstatusauto) {
		this.blcTabstatusauto = blcTabstatusauto;
	}

	public Integer getBlcStatusauto() {
		return blcStatusauto;
	}

	public void setBlcStatusauto(Integer blcStatusauto) {
		this.blcStatusauto = blcStatusauto;
	}

	public Date getBlcAuditfho() {
		return blcAuditfho;
	}

	public void setBlcAuditfho(Date blcAuditfho) {
		this.blcAuditfho = blcAuditfho;
	}

	public String getBlcAuditusr() {
		return blcAuditusr;
	}

	public void setBlcAuditusr(String blcAuditusr) {
		this.blcAuditusr = blcAuditusr;
	}

	public String getBlcAuditwst() {
		return blcAuditwst;
	}

	public void setBlcAuditwst(String blcAuditwst) {
		this.blcAuditwst = blcAuditwst;
	}

	@Override
	public String toString() {
		return "OfaBlanklist [blcId=" + blcId + ", blcContent=" + blcContent + ", blcType=" + blcType + ", blcTabstatusauto=" + blcTabstatusauto
				+ ", blcStatusauto=" + blcStatusauto + ", blcAuditfho=" + blcAuditfho + ", blcAuditusr=" + blcAuditusr + ", blcAuditwst=" + blcAuditwst + "]";
	}

	public String getBlcEstadoauto() {
		return blcEstadoauto;
	}

	public void setBlcEstadoauto(String blcEstadoauto) {
		this.blcEstadoauto = blcEstadoauto;
	}

	public GenDesctabla getGenDesctablaStatusauto() {
		return genDesctablaStatusauto;
	}

	public void setGenDesctablaStatusauto(GenDesctabla genDesctablaStatusauto) {
		this.genDesctablaStatusauto = genDesctablaStatusauto;
	}
	

}
