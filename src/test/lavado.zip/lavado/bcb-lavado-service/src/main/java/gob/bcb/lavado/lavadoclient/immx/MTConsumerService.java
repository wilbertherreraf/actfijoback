package gob.bcb.lavado.lavadoclient.immx;

import gob.bcb.core.utils.ManejoPropiedades;
import gob.bcb.lavado.commons.ConfiguracionesConfig;
import gob.bcb.lavado.pojos.immx.ResultadoMxPojo;
import gob.bcb.lavado.pojos.immx.SwfMensajeMxPojo;
import gob.bcb.lavado.pojos.immx.SwfRelacionMtMxPojo;
import gob.bcb.lavado.rest.dto.immx.RequestMT;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static gob.bcb.lavado.commons.Constants.BASE_DIR_APP;

public class MTConsumerService {

    private static final String CONVERT_MT_103 = "/convert/convertMT103";
    private static final String CONVERT_MT_202 = "/convert/convertMT202";
    private static final String CONVERT_MT_910 = "/convert/convertMT910";
    private static final String INSERTA_MX = "/mensajeMx";
    private static final String GET_MENSAJES_MX = "/mensajeMx";
    private static final String GET_BUSCAR_POR_CODMEN_NROCORR = "/mensajeMx/buscar";
    private static final String PUT_ACTUALIZAR = "/mensajeMx/actualizar";

    private static final String GET_BUSCAR_RELACION_POR_TIPO = "/relacionMtMx/buscarPortipo";

    private static final String PUT_ACTUALIZAR_RELACION = "/relacionMtMx/actualizar";

    private static final String SERVICE_URL_IMMX;
    private static final Logger log = LoggerFactory.getLogger(MTConsumerService.class);

    private ManejoPropiedades manejoPropiedades;

    static {
        Properties props = new Properties();
        try (InputStream input = new FileInputStream(BASE_DIR_APP + "clientes.properties")) {
            props.load(input);
            SERVICE_URL_IMMX = props.getProperty("service.url.immx");
            log.info("SERVICE_URL_IMMX cargado: " + SERVICE_URL_IMMX);
        } catch (IOException e) {
            throw new RuntimeException("Error al leer cliente.properties desde el sistema de archivos", e);
        }
    }

    public ResultadoMxPojo callConvertMTService0(RequestMT request) {

        log.info("***** AL INGRESO AL callConvertMTService " + request.toString());

        RestTemplate restTemplate = new RestTemplate();

        String codigoMT = request.getCodigoMT();
        String url = "";
        try {
            switch (codigoMT) {
                case "103":
                    url = SERVICE_URL_IMMX + CONVERT_MT_103;
                    break;
                case "202":
                    url = SERVICE_URL_IMMX + CONVERT_MT_202;
                    break;
                case "910":
                    url = SERVICE_URL_IMMX + CONVERT_MT_910;
                    break;
            }

            manejoPropiedades = new ManejoPropiedades();
            String clienteConfiguracionesConfig = manejoPropiedades
                    .getConfig(ConfiguracionesConfig.CONFIG_URLS.getValor());
            manejoPropiedades.initPropiedadesExternas(clienteConfiguracionesConfig);
            String apiKey = manejoPropiedades.getValorPropiedadExterna(ConfiguracionesConfig.APY_KEY_IMMX.getValor());

            // Configurar headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("API_KEY", apiKey);
            headers.set("COD_APP", "IMMX");

            // Construir la entidad de la petición
            HttpEntity<RequestMT> httpEntity = new HttpEntity<>(request, headers);

            // Realizar la llamada POST

            log.info("ANTES DE REALIZAR llamada url: {} request: {}", url, request);

            ResponseEntity<ResultadoMxPojo> responseEntity = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    httpEntity,
                    ResultadoMxPojo.class);

            log.info("***** RESPONSE ENTTTY: " + responseEntity);

            // Retornar el objeto resultado
            return responseEntity.getBody();
        } catch (Exception e) {
            log.error("Mensaje no convertido (" + codigoMT + "), Error: {}", e.getMessage(), e);
            throw new RuntimeException("Error en llamada api " + e.getMessage(), e);
        }
    }

    /**
     * Método para consumir el servicio REST que inserta un mensaje MX.
     *
     * @param mensajeMx Objeto de tipo SwfMensajeMxPojo con los datos a enviar
     * @return Objeto SwfMensajeMxPojo con la respuesta del servicio
     */
    public SwfMensajeMxPojo insertarMensajeMxService0(SwfMensajeMxPojo mensajeMx) {
        log.info("***** INGRESO AL MÉTODO insertarMensajeMxService EN EL CONSUMER DE IMMX *****");
        RestTemplate restTemplate = new RestTemplate();

        manejoPropiedades = new ManejoPropiedades();
        String clienteConfiguracionesConfig = manejoPropiedades.getConfig(ConfiguracionesConfig.CONFIG_URLS.getValor());
        manejoPropiedades.initPropiedadesExternas(clienteConfiguracionesConfig);
        String apiKey = manejoPropiedades.getValorPropiedadExterna(ConfiguracionesConfig.APY_KEY_IMMX.getValor());

        // Configuración de los headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("API_KEY", apiKey);
        headers.set("COD_APP", "IMMX");

        HttpEntity<SwfMensajeMxPojo> requestEntity = new HttpEntity<>(mensajeMx, headers);
        System.out.println("requestEntity = " + requestEntity);

        // Realizar la llamada POST
        try {
            ResponseEntity<SwfMensajeMxPojo> responseEntity = restTemplate.postForEntity(
                    SERVICE_URL_IMMX + INSERTA_MX,
                    requestEntity,
                    SwfMensajeMxPojo.class);

            return responseEntity.getBody();
        } catch (Exception e) {
            log.info("Mensaje MX no Insertado (" + mensajeMx + "-" + "), Error: " + e);
            return null;
        }
    }

    public SwfMensajeMxPojo actualizar0(SwfMensajeMxPojo mensajePojo) {
        log.info("***** INGRESO AL MÉTODO actualizar EN EL CONSUMER DE IMMX *****");
        log.info("mensajePojo = " + mensajePojo);
        RestTemplate restTemplate = new RestTemplate();

        manejoPropiedades = new ManejoPropiedades();
        String clienteConfiguracionesConfig = manejoPropiedades.getConfig(ConfiguracionesConfig.CONFIG_URLS.getValor());
        manejoPropiedades.initPropiedadesExternas(clienteConfiguracionesConfig);
        String apiKey = manejoPropiedades.getValorPropiedadExterna(ConfiguracionesConfig.APY_KEY_IMMX.getValor());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("API_KEY", apiKey);
        headers.set("COD_APP", "IMMX");

        HttpEntity<SwfMensajeMxPojo> entity = new HttpEntity<>(mensajePojo, headers);
        String url = SERVICE_URL_IMMX + PUT_ACTUALIZAR;

        try {
            ResponseEntity<SwfMensajeMxPojo> response = restTemplate.exchange(
                    url,
                    HttpMethod.PUT,
                    entity,
                    SwfMensajeMxPojo.class);
            return response.getBody();
        } catch (org.springframework.web.client.HttpClientErrorException e) {
            log.info("Mensaje MX no actualizado(" + mensajePojo + "-" + "), Error: " + e);
            return null;
        }
    }

    /**
     * Método para consumir el servicio REST que retorna todos los mensajes MX.
     * Este método simula la llamada equivalente al curl:
     * curl --location 'http://localhost:8084/bcb-immx-be-rest/rest/mensajeMx' \
     * --header 'Accept: application/json'
     *
     * @return Arreglo de SwfMensajeMxPojo con la lista de mensajes
     */
    public SwfMensajeMxPojo[] obtenerTodosMensajesMx0() {
        RestTemplate restTemplate = new RestTemplate();

        manejoPropiedades = new ManejoPropiedades();
        String clienteConfiguracionesConfig = manejoPropiedades.getConfig(ConfiguracionesConfig.CONFIG_URLS.getValor());
        manejoPropiedades.initPropiedadesExternas(clienteConfiguracionesConfig);
        String apiKey = manejoPropiedades.getValorPropiedadExterna(ConfiguracionesConfig.APY_KEY_IMMX.getValor());

        log.info("******************************************");
        log.info("apiKey = " + apiKey);
        log.info("******************************************");

        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.set("API_KEY", apiKey);
        headers.set("COD_APP", "IMMX");

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        try {
            ResponseEntity<SwfMensajeMxPojo[]> responseEntity = restTemplate.exchange(
                    SERVICE_URL_IMMX + GET_MENSAJES_MX,
                    HttpMethod.GET,
                    entity,
                    SwfMensajeMxPojo[].class);
            return responseEntity.getBody();
        } catch (Exception e) {
            log.info("Mensajes MX no encontrados (SWIFT -" + "), Error: " + e);
            return null;
        }
    }

    public SwfMensajeMxPojo buscarPorCodmenYNroCorr0(Integer menCodmen, Integer menNroCorr) {
        RestTemplate restTemplate = new RestTemplate();

        manejoPropiedades = new ManejoPropiedades();
        String clienteConfiguracionesConfig = manejoPropiedades.getConfig(ConfiguracionesConfig.CONFIG_URLS.getValor());
        manejoPropiedades.initPropiedadesExternas(clienteConfiguracionesConfig);
        String apiKey = manejoPropiedades.getValorPropiedadExterna(ConfiguracionesConfig.APY_KEY_IMMX.getValor());

        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.set("API_KEY", apiKey);
        headers.set("COD_APP", "IMMX");

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        String url = SERVICE_URL_IMMX + GET_BUSCAR_POR_CODMEN_NROCORR + "/" + menCodmen + "/" + menNroCorr;

        try {
            ResponseEntity<SwfMensajeMxPojo> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    SwfMensajeMxPojo.class);
            return response.getBody();
        } catch (Exception e) {
            log.info("Mensaje MX no encontrado (" + menCodmen + "-" + menNroCorr + "), Error: " + e);
            return null;
        }
    }

    public SwfRelacionMtMxPojo[] buscarParametrosPorTipo0(Integer tipoMensaje) {
        RestTemplate restTemplate = new RestTemplate();

        manejoPropiedades = new ManejoPropiedades();
        String clienteConfiguracionesConfig = manejoPropiedades.getConfig(ConfiguracionesConfig.CONFIG_URLS.getValor());
        manejoPropiedades.initPropiedadesExternas(clienteConfiguracionesConfig);
        String apiKey = manejoPropiedades.getValorPropiedadExterna(ConfiguracionesConfig.APY_KEY_IMMX.getValor());

        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.set("API_KEY", apiKey);
        headers.set("COD_APP", "IMMX");

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        String url = SERVICE_URL_IMMX + GET_BUSCAR_RELACION_POR_TIPO + "/" + tipoMensaje;

        try {
            ResponseEntity<SwfRelacionMtMxPojo[]> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    SwfRelacionMtMxPojo[].class);
            return response.getBody();
        } catch (Exception e) {
            log.info("Mensaje no encontrado (" + tipoMensaje + "-" + "), Error: " + e);
            return null;
        }
    }

    public SwfRelacionMtMxPojo actualizarRelacionMtMX0(SwfRelacionMtMxPojo mensajePojo) {
        RestTemplate restTemplate = new RestTemplate();

        manejoPropiedades = new ManejoPropiedades();
        String clienteConfiguracionesConfig = manejoPropiedades.getConfig(ConfiguracionesConfig.CONFIG_URLS.getValor());
        manejoPropiedades.initPropiedadesExternas(clienteConfiguracionesConfig);
        String apiKey = manejoPropiedades.getValorPropiedadExterna(ConfiguracionesConfig.APY_KEY_IMMX.getValor());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("API_KEY", apiKey);
        headers.set("COD_APP", "IMMX");

        HttpEntity<SwfRelacionMtMxPojo> entity = new HttpEntity<>(mensajePojo, headers);
        String url = SERVICE_URL_IMMX + PUT_ACTUALIZAR_RELACION;

        try {
            ResponseEntity<SwfRelacionMtMxPojo> response = restTemplate.exchange(
                    url,
                    HttpMethod.PUT,
                    entity,
                    SwfRelacionMtMxPojo.class);
            return response.getBody();
        } catch (org.springframework.web.client.HttpClientErrorException e) {
            log.info("Relación MtMx no realizada (" + mensajePojo + "-" + "), Error: " + e);
            return null;
        }
    }
    
}
