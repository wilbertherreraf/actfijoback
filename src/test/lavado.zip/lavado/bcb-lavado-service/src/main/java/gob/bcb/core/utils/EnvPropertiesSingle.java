package gob.bcb.core.utils;

import java.util.Map;

/**
 * @author DIDS - rquispe
 */
public final class EnvPropertiesSingle {

    private static Map<String, String> properties = null;

    public static Map<String, String> getProperties() {
        if (properties == null)
            properties = System.getenv();
        return properties;
    }

    public static String getPropertie(String pKey) {
        return getProperties().get(pKey);
    }

}
