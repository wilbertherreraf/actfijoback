package gob.bcb.client;

import gob.bcb.core.utils.ManejoPropiedades;
import gob.bcb.lavado.commons.ClientesConfig;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;


public class PeticionesRest {
    private static final Logger log = LoggerFactory.getLogger(PeticionesRest.class);
    static MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    public OkHttpClient client;
    public String host;

    private ManejoPropiedades manejoPropiedades;

    public Response ejecutarPostConParametro(String hostDireccion, String json) throws IOException {
        Response response;
        RequestBody body = RequestBody.create(JSON, json);

        HttpUrl route = HttpUrl.parse(hostDireccion).newBuilder().build();
        Request request = new Request.Builder().url(route.url())
                .post(body).addHeader("Content-Type","application/json").build();

        response = client.newCall(request).execute();
        return response;
    }

    public Response ejecutarPostConParametroToken(String hostDireccion, String json,String token) throws IOException {
        Response response;
        RequestBody body = RequestBody.create(JSON, json);

        HttpUrl route = HttpUrl.parse(hostDireccion).newBuilder().build();
        Request request = new Request.Builder().url(route.url())
                .post(body).addHeader("Content-Type","application/json")
                .addHeader("Authorization", "Bearer " + token)
                .build();

        response = client.newCall(request).execute();
        return response;
    }

    public Response ejecutarGetSinParametro(String hostDireccion) throws IOException {
        Response response;
        HttpUrl route = HttpUrl.parse(hostDireccion).newBuilder().build();
        Request request = new Request.Builder().url(route.url())
                .get().addHeader("Content-Type","application/json").build();

        response = client.newCall(request).execute();
        return response;
    }

    public Response ejecutarGetSinParametroToken(String hostDireccion,String token) throws IOException {
        Response response;
        HttpUrl route = HttpUrl.parse(hostDireccion).newBuilder().build();
        Request request = new Request.Builder().url(route.url())
                .get().addHeader("Content-Type","application/json")
                .addHeader("Authorization", "Bearer " + token)
                .build();

        response = client.newCall(request).execute();
        return response;
    }


    public Response ejecutarPutSinParametro(String hostDireccion, String json) throws IOException {
        
        RequestBody body = RequestBody.create(JSON, json);

        HttpUrl route = HttpUrl.parse(hostDireccion).newBuilder().build();
        Request request = new Request.Builder().url(route.url())
                .put(body).addHeader("Content-Type","application/json")
                .build();

        String curlCommand = buildCurlCommand(request);
        log.info("CURL ::::    "+ curlCommand);
        Response response = client.newCall(request).execute();
        return response;
    }

    public Response ejecutarPutSinParametroToken(String hostDireccion, String json,String token) throws IOException {
        Response response;
        RequestBody body = RequestBody.create(JSON, json);

        HttpUrl route = HttpUrl.parse(hostDireccion).newBuilder().build();
        Request request = new Request.Builder().url(route.url())
                .put(body).addHeader("Content-Type","application/json")
                .addHeader("Authorization", "Bearer " + token)
                .build();

        String curlCommand = buildCurlCommand(request);
        log.info("CURL ::::    "+ curlCommand);
        response = client.newCall(request).execute();
        return response;
    }


    public void configSAI() {

       manejoPropiedades = new ManejoPropiedades();
        String clienteConfig = manejoPropiedades.getClienteConfig(ClientesConfig.CLIENTES_URLS.getValor());
        manejoPropiedades.initPropiedadesExternas(clienteConfig);
        String vUrl = manejoPropiedades.getValorPropiedadExterna(ClientesConfig.SAI_BASE_URL.getValor());
        this.client = new OkHttpClient();
//        this.client = getUnsafeOkHttpClient();
        host = vUrl;
    }


    protected static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Crear un gestor de confianza que no realice verificación SSL
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[]{};
                        }
                    }
            };

            // Configurar un contexto SSL con el gestor de confianza
            final SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

            // Configurar el cliente OkHttp para usar el contexto SSL personalizado
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            String proxyHost = "10.1.11.50";
            int proxyPort = 8080;

            // Crear una instancia de Proxy
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));


            return new OkHttpClient.Builder()
                    .sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0])
                    .hostnameVerifier((hostname, session) -> true)
                    .proxy(proxy)
                    .build();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static String buildCurlCommand(Request request) {
        // Construir el comando cURL equivalente
        StringBuilder curlCommand = new StringBuilder("curl");

        // Agregar la URL
        curlCommand.append(" '").append(request.url()).append("'");

        // Agregar las cabeceras
        for (String name : request.headers().names()) {
            curlCommand.append(" -H '").append(name).append(": ").append(request.headers().get(name)).append("'");
        }

        // Agregar el método
        curlCommand.append(" --request ").append(request.method());

        // Agregar el cuerpo si es un método que lo permite (POST, PUT, etc.)
        if (request.method().equals("POST") || request.method().equals("PUT")) {
            // Aquí puedes agregar la lógica para obtener el cuerpo de la solicitud y agregarlo al comando cURL
            // Por ejemplo, request.body().toString() para obtener el cuerpo en forma de cadena
            curlCommand.append(" --data ").append(request.body().toString());
        }

        return curlCommand.toString();
    }

}
