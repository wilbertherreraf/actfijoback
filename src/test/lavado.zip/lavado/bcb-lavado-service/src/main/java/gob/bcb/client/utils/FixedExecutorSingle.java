package gob.bcb.client.utils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class FixedExecutorSingle {
    private static ExecutorService executor;// = Executors.newFixedThreadPool(3);

    public static ExecutorService instance() {
        if (executor == null)
            executor = create(100);
        return executor;
    }

    public static ExecutorService create(int corePoolSize) {

        return create(corePoolSize, 19718);
    }

    public static ExecutorService create(int corePoolSize, int maximumPoolSize) {
        executor = new ThreadPoolExecutor(corePoolSize, maximumPoolSize, 10L,
                TimeUnit.SECONDS, new LinkedBlockingQueue(maximumPoolSize));
        return executor;
    }

}
