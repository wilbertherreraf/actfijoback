/**
 * InternaException.java
 *
 * Creado el 28 de mayo de 2003, 08:48 AM
 */

package gob.bcb.lavado.exception;


/**
 * Crea una nueva instancia de <code>InternaException</code> sin mensaje.
 */
public class InternalException extends java.lang.Exception {

    /**
     * Crea una nueva instancia de <code>InternaException</code> sin mensaje.
     */
    public InternalException() {
    }


    /**
     * Construye una instancia de <code>InternaException</code> incluyendo el mensaje.
     * @param msg detalle del mensaje.
     */
    public InternalException(String msg) {
        super(msg);
    }
}
