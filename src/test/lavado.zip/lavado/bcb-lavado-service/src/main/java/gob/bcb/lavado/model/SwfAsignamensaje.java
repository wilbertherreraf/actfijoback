package gob.bcb.lavado.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;


/**
 * The persistent class for the swf_asignamensaje database table.
 * 
 */
@Entity
@Table(name="swf_asignamensaje")
public class SwfAsignamensaje implements Serializable, gob.bcb.lavado.model.DomainObject {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SwfAsignamensajePK id;

	@Column(name="res_codemppadre")
	private Integer resCodemppadre;
	
	@Column(name="res_corrasigna")
	private Integer resCorrasigna;
	
    @Temporal( TemporalType.DATE)
	@Column(name="res_fechoraasigna")
	private Date resFechoraasigna;

	@Column(name = "res_arecod")
	private String resArecod;
	
	@Column(name = "res_glosa")
	private String resGlosa;
	
	@Column(name = "res_notif")
	private String resNotif;

	@Column(name="res_estrevision")
	private Integer resEstrevision;
	
	@Column(name="res_tabestrevision")
	private Integer resTabestrevision;
	
    @Temporal( TemporalType.DATE)
	@Column(name="res_fechorarevisa")
	private Date resFechorarevisa;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "res_auditfho")
	private Date resAuditfho;

	@Column(name = "res_auditusr")
	private String resAuditusr;

	@Column(name = "res_auditwst")
	private String resAuditwst;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumns( { @JoinColumn(updatable=false,insertable=false,name = "res_estrevision", referencedColumnName = "des_codigo"),
			@JoinColumn(updatable=false,insertable=false,name = "res_tabestrevision", referencedColumnName = "des_codtab")})	
	private GenDesctabla genDesctablaEstrevision;

	public SwfAsignamensaje() {
	}

	public SwfAsignamensajePK getId() {
		return this.id;
	}

	public void setId(SwfAsignamensajePK id) {
		this.id = id;
	}

	public Integer getResCodemppadre() {
		return this.resCodemppadre;
	}

	public void setResCodemppadre(Integer resCodemppadre) {
		this.resCodemppadre = resCodemppadre;
	}

	public GenDesctabla getGenDesctablaEstrevision() {
		return this.genDesctablaEstrevision;
	}

	public void setGenDesctablaEstrevision(GenDesctabla genDesctablaEstrevision) {
		this.genDesctablaEstrevision = genDesctablaEstrevision;
	}

	public Integer getResCorrasigna() {
		return resCorrasigna;
	}

	public void setResCorrasigna(Integer resCorrasigna) {
		this.resCorrasigna = resCorrasigna;
	}

	public Date getResFechoraasigna() {
		return resFechoraasigna;
	}

	public void setResFechoraasigna(Date resFechoraasigna) {
		this.resFechoraasigna = resFechoraasigna;
	}

	public Date getResFechorarevisa() {
		return resFechorarevisa;
	}

	public void setResFechorarevisa(Date resFechorarevisa) {
		this.resFechorarevisa = resFechorarevisa;
	}

	public Date getResAuditfho() {
		return resAuditfho;
	}

	public void setResAuditfho(Date resAuditfho) {
		this.resAuditfho = resAuditfho;
	}

	public String getResAuditusr() {
		return resAuditusr;
	}

	public void setResAuditusr(String resAuditusr) {
		this.resAuditusr = resAuditusr;
	}

	public String getResAuditwst() {
		return resAuditwst;
	}

	public void setResAuditwst(String resAuditwst) {
		this.resAuditwst = resAuditwst;
	}

	public String getResArecod() {
		return resArecod;
	}

	public void setResArecod(String resArecod) {
		this.resArecod = resArecod;
	}

	public String getResGlosa() {
		return resGlosa;
	}

	public void setResGlosa(String resGlosa) {
		this.resGlosa = resGlosa;
	}

	public String getResNotif() {
		return resNotif;
	}

	public void setResNotif(String resNotif) {
		this.resNotif = resNotif;
	}

	public Integer getResEstrevision() {
		return resEstrevision;
	}

	public void setResEstrevision(Integer resEstrevision) {
		this.resEstrevision = resEstrevision;
	}

	public Integer getResTabestrevision() {
		return resTabestrevision;
	}

	public void setResTabestrevision(Integer resTabestrevision) {
		this.resTabestrevision = resTabestrevision;
	}

	@Override
	public String toString() {
		return "SwfAsignamensaje [id=" + id + ", resCodemppadre=" + resCodemppadre + ", resCorrasigna=" + resCorrasigna + ", resFechoraasigna=" + resFechoraasigna
				+ ", resArecod=" + resArecod + ", resGlosa=" + resGlosa + ", resNotif=" + resNotif + ", resEstrevision=" + resEstrevision + ", resTabestrevision="
				+ resTabestrevision + ", resFechorarevisa=" + resFechorarevisa + ", resAuditfho=" + resAuditfho + ", resAuditusr=" + resAuditusr + ", resAuditwst=" + resAuditwst
				+ "]";
	}

	
}