package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the gen_moneda database table.
 * 
 */
@Entity(name = "d_portsw.gen_moneda")
@Table(name="gen_moneda")
public class GenMoneda implements Serializable, gob.bcb.lavado.model.DomainObject {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="mon_codmon")
	private Integer monCodmon;

	@Column(name="mon_abrev")
	private String monAbrev;

	@Column(name="mon_codmoncoin")
	private String monCodmoncoin;

	@Column(name="mon_descrip")
	private String monDescrip;

	public GenMoneda() {
	}

	public Integer getMonCodmon() {
		return this.monCodmon;
	}

	public void setMonCodmon(Integer monCodmon) {
		this.monCodmon = monCodmon;
	}

	public String getMonAbrev() {
		return this.monAbrev;
	}

	public void setMonAbrev(String monAbrev) {
		this.monAbrev = monAbrev;
	}

	public String getMonCodmoncoin() {
		return this.monCodmoncoin;
	}

	public void setMonCodmoncoin(String monCodmoncoin) {
		this.monCodmoncoin = monCodmoncoin;
	}

	public String getMonDescrip() {
		return this.monDescrip;
	}

	public void setMonDescrip(String monDescrip) {
		this.monDescrip = monDescrip;
	}

}