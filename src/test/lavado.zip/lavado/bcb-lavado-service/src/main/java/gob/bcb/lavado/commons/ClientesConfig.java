/**
 * ╔╗ ┌─┐┌┐┌┌─┐┌─┐  ╔═╗┌─┐┌┐┌┌┬┐┬─┐┌─┐┬    ┌┬┐┌─┐  ╔╗ ┌─┐┬  ┬┬  ┬┬┌─┐
 * ╠╩╗├─┤││││  │ │  ║  ├┤ │││ │ ├┬┘├─┤│     ││├┤   ╠╩╗│ ││  │└┐┌┘│├─┤
 * ╚═╝┴ ┴┘└┘└─┘└─┘  ╚═╝└─┘┘└┘ ┴ ┴└─┴ ┴┴─┘  ─┴┘└─┘  ╚═╝└─┘┴─┘┴ └┘ ┴┴ ┴
 * Copyright © 2022 - ${project.inceptionYear}
 * Licensed under BCB Licence version 1.0
 * See https://www.bcb.gob.bo/licenses/LICENSE-1.0
 */
package gob.bcb.lavado.commons;
/**
 * @author DIDS - acalvi
 */
import lombok.Getter;

@Getter
public enum ClientesConfig {
    CLIENTES_URLS("clientes.urls"),
    CONNECTION_TIME_OUT("connection.timeout"),
    READ_TIME_OUT("read.timeout"),
    SAI_BASE_URL("sai.base.url");
    String valor;

    ClientesConfig(String valor) {
//        System.out.println("SE RECUPERA VALOR DE valor "+valor);
        this.valor = valor;
    }
}
