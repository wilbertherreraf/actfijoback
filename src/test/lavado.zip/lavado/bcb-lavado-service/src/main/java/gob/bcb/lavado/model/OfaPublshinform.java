package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ofa_publshinform database table.
 * 
 */
@Entity
@Table(name="ofa_publshinform")
@NamedQuery(name="OfaPublshinform.findAll", query="SELECT o FROM OfaPublshinform o")
public class OfaPublshinform implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="pin_publishdate")
	private String pinPublishdate;

	@Column(name="pin_recordcount")
	private Integer pinRecordcount;

	public OfaPublshinform() {
	}

	public String getPinPublishdate() {
		return this.pinPublishdate;
	}

	public void setPinPublishdate(String pinPublishdate) {
		this.pinPublishdate = pinPublishdate;
	}

	public Integer getPinRecordcount() {
		return this.pinRecordcount;
	}

	public void setPinRecordcount(Integer pinRecordcount) {
		this.pinRecordcount = pinRecordcount;
	}

}