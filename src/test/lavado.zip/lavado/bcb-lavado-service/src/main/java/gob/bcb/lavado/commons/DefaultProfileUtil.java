package gob.bcb.lavado.commons;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.boot.SpringApplication;
import org.springframework.core.io.ClassPathResource;

import gob.bcb.core.utils.UtilsProperties;

/**
 * Utility class to load a Spring profile to be used as default when there is no
 * <code>spring.profiles.active</code> set in the environment or as command line
 * argument. If the value is not available in <code>application.yml</code> then
 * <code>dev</code> profile will be used as default.
 */
public final class DefaultProfileUtil {
	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(DefaultProfileUtil.class);
	private static final String SPRING_CONFIG_LOCATION = "spring.config.location";
	private static final String SPRING_PROFILE_ACTIVE = "spring.profiles.active";	
	private static final Properties BUILD_PROPERTIES = readProperties();

	/**
	 * Get a default profile from <code>application.yml</code>.
	 */
	public static String getDefaultActiveProfiles() {
		log.info("en getDefaultActiveProfiles");
		if (BUILD_PROPERTIES != null) {
			String activeProfile = BUILD_PROPERTIES.getProperty(SPRING_PROFILE_ACTIVE);
		
			//log.info(BUILD_PROPERTIES.getProperty("spring.batch.job.enabled"));			
			log.info("activeProfile " + activeProfile);
			log.info(SPRING_CONFIG_LOCATION + " : " + BUILD_PROPERTIES.getProperty(SPRING_CONFIG_LOCATION));			
			log.info(BUILD_PROPERTIES.getProperty("spring.application.name"));			
			log.info(BUILD_PROPERTIES.stringPropertyNames().toString());
			if (activeProfile != null && !activeProfile.isEmpty()
					&& (activeProfile.contains(Constants.SPRING_PROFILE_DEVELOPMENT) || activeProfile.contains(Constants.SPRING_PROFILE_PRODUCTION))) {
				log.info("spring.batch.initializer.enabled " + BUILD_PROPERTIES.toString());
				return activeProfile;
			}
		}
		log.warn("No Spring profile configured, running with default profile: {}", Constants.SPRING_PROFILE_DEVELOPMENT);
		return Constants.SPRING_PROFILE_DEVELOPMENT;
	}

	/**
	 * Set a default to use when no profile is configured.
	 */
	public static void addDefaultProfile(SpringApplication app) {
		Map<String, Object> defProperties = new HashMap<>();
		/*
		 * The default profile to use when no other profiles are defined This
		 * cannot be set in the <code>application.yml</code> file. See
		 * https://github.com/spring-projects/spring-boot/issues/1219
		 */
		defProperties.put(SPRING_CONFIG_LOCATION, getDefaultActiveProfiles());
		defProperties.put(SPRING_PROFILE_ACTIVE, getDefaultActiveProfiles());		
		log.info("spring.batch.initializer.enabled " );
		app.setDefaultProperties(defProperties);
	}

	/**
	 * Load application.yml from classpath.
	 */
	private static Properties readPropertiesYaml() {
		try {
			YamlPropertiesFactoryBean factory = new YamlPropertiesFactoryBean();
			log.info("en readProperties");
			factory.setResources(new ClassPathResource("config/application.yml"));
			log.info("en readProperties " + factory.getObject().toString());			
			return factory.getObject();
		} catch (Exception e) {
			log.error("Failed to read application.yml to get default profile");
		}
		return null;
	}
	
	private static Properties readProperties() {
		String pathFile = Constants.BASE_DIR_APP + "application.properties";
		try {
			Properties properties = UtilsProperties.loadFileMsgProperties(pathFile);
			log.info("en readProperties " + pathFile);
			return properties;
		} catch (Exception e) {
			log.error("Failed to read application.yml to get default profile");
		}
		return null;
	}	
}
