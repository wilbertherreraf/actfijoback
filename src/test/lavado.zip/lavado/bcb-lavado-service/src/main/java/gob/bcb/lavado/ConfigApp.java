package gob.bcb.lavado;

import java.io.File;
import java.util.Arrays;
import java.util.Collection;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.config.LavadoProperties;

@Configuration
@ComponentScan
@EnableAutoConfiguration
@PropertySource(value = "file:" + Constants.BASE_DIR_APP + Constants.FILE_APPLICATION)
//@EnableConfigurationProperties({ AppProperties.class, LavadoProperties.class})
@EnableConfigurationProperties({ AppProperties.class})
public class ConfigApp {
	private static final Logger log = LoggerFactory.getLogger(ConfigApp.class);

	@Autowired
	private Environment env;

	public ConfigApp() {
		log.info("Creando ConfigApp " + (env == null));
	}

	@PostConstruct
	public void initApplication() throws Throwable {
		log.info("------- Params Service Service -------");		
		log.info("server.port : " +  env.getProperty("server.port"));
		log.info("server.address: " + env.getProperty("server.address"));
		log.info("server.contextPath: " + env.getProperty("server.contextPath"));
		log.info("spring.application.name: " + env.getProperty("spring.application.name"));		
		log.info("Running with Spring profile(s) : {}", Arrays.toString(env.getActiveProfiles()));
		log.info("Running with spring.config.location: " + env.getProperty("spring.config.location"));
		//log.info("Running with portia.jdbcUrl: " + env.getProperty("portia.jdbcUrl"));
		Collection<String> activeProfiles = Arrays.asList(env.getActiveProfiles());
		if (activeProfiles.contains(Constants.SPRING_PROFILE_DEVELOPMENT) && activeProfiles.contains(Constants.SPRING_PROFILE_PRODUCTION)) {
			log.error("You have misconfigured your application! It should not run " + "with both the 'dev' and 'prod' profiles at the same time.");
		}
		createDirs();
	}

	/**
	 * Creacion de directorios de la aplicacion
	 */
	private void createDirs(){
		String pathBase = env.getProperty("spring.config.location");
		new File(pathBase + Constants.DIR_FILES_STORE).mkdirs();
		new File(pathBase + Constants.DIR_LOTES).mkdirs();
		new File(pathBase + Constants.DIR_OFAC_FILES).mkdirs();		
		new File(pathBase + Constants.DIR_OFAC_FILES_TMP).mkdirs();		
		new File(pathBase + Constants.DIR_OFAC_FILES_DESCARGA).mkdirs();		
		new File(pathBase + Constants.DIR_QUERIES).mkdirs();			
	}
}
