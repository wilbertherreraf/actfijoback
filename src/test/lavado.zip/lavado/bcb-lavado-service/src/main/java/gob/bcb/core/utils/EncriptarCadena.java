package gob.bcb.core.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import static org.apache.commons.codec.binary.Base64.decodeBase64;
import static org.apache.commons.codec.binary.Base64.encodeBase64;

/**
 * Creado por pali el 20/01/2017.
 */
public final class EncriptarCadena {
    // Constante define el tipo de algoritmo a utilizar (AES, DES, RSA).
    public final static String cAlgoritoEncriptacion = "AES";

    // Constante que define del tipo de cifrado a utilizar.
    public final static String cTipoCifrado = "AES/CBC/PKCS5Padding";

    // Constante que define vector de inicializaciÃ³n.
    public final static String cVectorInicializacion = "0123456789ABCDEF";
    // Propiedad que almacena la dirección url de la llave.
    private static String pathLlave;

    // Propiedad de tipo "EncriptarCadena"
    private static EncriptarCadena encriptarCadena;

    /**
     * Constructor que inicializa la clase.
     * @param pPathLlave Dirección donde se encuentra la llave para la encriptación.
     */
    private EncriptarCadena(String pPathLlave){
        // Almacena parametro de entrada.
        pathLlave = pPathLlave;
    }

    /**
     * Método que instancia la clase "EncriptarCadena" solo una vez.
     * @param pPathLlave Dirección donde se encuentra la llave para la encriptación.
     */
    public static EncriptarCadena initialize(String pPathLlave) {

        // Verifica si la clase ya fue instanciada.
        if (encriptarCadena == null){
            // Inicializa clase de tipo "EncriptarCadena".
            encriptarCadena = new EncriptarCadena(pPathLlave);
        }
        // Retorna clase instanciada.
        return encriptarCadena;
    }

    /**
     * Función de tipo cadena que recibe una llave, un vector de inicialización y el texto que se desea cifrar
     * @param pLlave Llave en tipo cadena a utilizar.
     * @param pVectorInicializacion Vector de inicialización a utilizar.
     * @param pTextoCifrar Texto o cadena sin cifrar.
     * @return Texto cifrado de tipo cadena.
     */
    private static String encriptar(String pLlave, String pVectorInicializacion, String pTextoCifrar) throws Exception {
        // Instancia clase que almacena tipo de encriptación.
        Cipher vClaseCipher = Cipher.getInstance(cTipoCifrado);
        // Instancia clase que especifica la llave secreta.
        SecretKeySpec vClaseSkeySpec = new SecretKeySpec(pLlave.getBytes(), cAlgoritoEncriptacion);
        // Instancia clase que especifica el vector de inicialización.
        IvParameterSpec vClaseVectorInicializacion = new IvParameterSpec(pVectorInicializacion.getBytes());
        // Inicializa el modo de encriptacion con la llave y vector de inicialización.
        vClaseCipher.init(Cipher.ENCRYPT_MODE, vClaseSkeySpec, vClaseVectorInicializacion);
        // Obtiene cadena encriptada.
        byte[] vCadenaEncriptada = vClaseCipher.doFinal(pTextoCifrar.getBytes());
        // Retorna cadena encriptada.
        return new String(encodeBase64(vCadenaEncriptada));
    }

    /**
     * Función de tipo cadena que recibe una llave, un vector de inicialización y el texto que se desea descifrar
     * @param pLlave Llave en tipo cadena a utilizar.
     * @param pVectorInicializacion Vector de inicialización a utilizar.
     * @param pTextoCifrado Texto cifrado de tipo cadena.
     * @return Texto desencriptado de tipo cadena.
     */
    private static String desencriptar(String pLlave, String pVectorInicializacion, String pTextoCifrado) throws Exception {
        // Instancia clase que almacena tipo de encriptación.
        Cipher vClaseCipher = Cipher.getInstance(cTipoCifrado);
        // Instancia clase que especifica la llave secreta.
        SecretKeySpec vClaseSkeySpec = new SecretKeySpec(pLlave.getBytes(), cAlgoritoEncriptacion);
        // Instancia clase que especifica el vector de inicialización.
        IvParameterSpec vClaseVectorInicializacion = new IvParameterSpec(pVectorInicializacion.getBytes());
        // Almacena texto o cadena cifrada.
        byte[] vCadenaCifrada = decodeBase64(pTextoCifrado);
        // Inicializa el modo de desencriptacion con la llave y vector de inicialización.
        vClaseCipher.init(Cipher.DECRYPT_MODE, vClaseSkeySpec, vClaseVectorInicializacion);
        // Obtiene cadena desencriptada o descifrada..
        byte[] vCadenaDescifrada = vClaseCipher.doFinal(vCadenaCifrada);
        // Retorna cadena deencriptada.
        return new String(vCadenaDescifrada);
    }

    /**
     * Función de tipo cadena que recibe una llave, un vector de inicialización y el texto que se desea cifrar.
     * @param pTexto Texto o cadena para la encriptación.
     * @return Texto desencriptado de tipo cadena.
     */
    public static String encriptarMensaje(String pTexto) {

        // Instancia variable para cadena cifrada.
        String vCadenaCifrada = "";

        // Instancia clase de tipo "UtilsFile".
        UtilsFile vClaseUtil = new UtilsFile();

        // Obtiene la llave a traves de la dirección del archivo.
        String vLlave = vClaseUtil.readFileAsString2(pathLlave);
        System.out.println(" vLlave " + vLlave);
        try {
            // Obtiene cadena cifrada o encriptada.
            vCadenaCifrada = encriptar(vLlave, cVectorInicializacion, pTexto);
        }
        catch (Exception e) {
            // Envia mensaje generado por la excepción.
            throw new RuntimeException(e.getMessage(), e);
        }
        // Retorna cadena encriptada o cifrada.
        return new String(vCadenaCifrada);
    }

    /**
     * Función de tipo cadena que recibe una llave, un vector de inicialización y el texto que se desea descifrar.
     * @param pTextoCifrado Texto cifrado de tipo cadena.
     * @return Texto desencriptado de tipo cadena.
     */
    public static String desencriptarMensaje(String pTextoCifrado) {

        // Instancia variable para cadena descifrada.
        String vCadenaDescifrada = "";

        // Instancia clase de tipo "UtilsFile".
        UtilsFile vClaseUtil = new UtilsFile();

        // Obtiene la llave a traves de la dirección del archivo.
        String vLlave = vClaseUtil.readFileAsString2(pathLlave);

        try {
            // Obtiene cadena descifrada o desencriptada.
            vCadenaDescifrada = desencriptar(vLlave, cVectorInicializacion, pTextoCifrado);
        }
        catch (Exception e) {
            // Envia mensaje generado por la excepción.
            throw new RuntimeException(e.getMessage(), e);            
        }
        // Retorna cadena encriptada o cifrada.
        return new String(vCadenaDescifrada);
    }
}
