package gob.bcb.core.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;

public class WebUtils {

	private final static Logger LOGGER = LoggerFactory.getLogger(WebUtils.class);

	protected final static String X_FORWARDED_FOR_HEADER = "X-FORWARDED-FOR";

	private WebUtils() {
		// Assert.noObject();
	}

	public static HttpServletRequest geHttpServletRequest() {
		final HttpServletRequest httpServletRequest = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		if (httpServletRequest == null){
			throw new RuntimeException("HttpServletRequest nulo!");
		}
		//Assert.notNull(httpServletRequest, "HttpServletRequest should exists here !");

		return httpServletRequest;
	}

	public static URI createURI(final Serializable id) {
		//Assert.notNull(id);
		if (id == null)
			throw new RuntimeException("Serializable id nulo!");
		URI uri;
		try {
			uri = new URI(ServletUriComponentsBuilder.fromCurrentServletMapping().path("/{id}").buildAndExpand(id).toString());
		} catch (final URISyntaxException e) {
			LOGGER.error("Cannot create URI for given id:" + id, e);
			throw new RuntimeException("Error fatal " + e.getMessage(), e);
		}
		return uri;
	}

	public static String getIpAdress(final HttpServletRequest httpServletRequest) {
		//Assert.notNull(httpServletRequest);
		if (httpServletRequest == null)
			throw new RuntimeException("httpServletRequest nulo!");
		String ipAddress = httpServletRequest.getHeader(X_FORWARDED_FOR_HEADER);
		if (ipAddress == null) {
			ipAddress = httpServletRequest.getRemoteAddr();
		}
		return ipAddress;
	}
}
