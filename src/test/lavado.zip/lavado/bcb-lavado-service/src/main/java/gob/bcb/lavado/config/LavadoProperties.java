package gob.bcb.lavado.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.util.StringUtils;

import gob.bcb.lavado.commons.Constants;

//@ConfigurationProperties(prefix = "lavado", ignoreUnknownFields = false)
public class LavadoProperties {
	private static final Logger log = LoggerFactory.getLogger(LavadoProperties.class);	
	private String appdir = Constants.BASE_DIR_APP;
	private final Search search = new Search();
	
	public LavadoProperties() {
		log.info("Creando LavadoProperties...");
	}
	public Search getSearch() {
		return search;
	}

	public String getAppdir() {
		return appdir;
	}

	public void setAppdir(String appdir) {
		this.appdir = appdir;
	}

	public static class Search {
		private String indexdir = Constants.BASE_DIR_APP + "indexes/";
		private String idEstrategiaplano = "REGISTRADOS";
		
		public String getIndexdir() {
			return indexdir;
		}

		public void setIndexdir(String indexdir) {
			this.indexdir = indexdir;
		}

		public String getIdEstrategiaplano() {
			return idEstrategiaplano;
		}

		public void setIdEstrategiaplano(String idEstrategiaplano) {
			this.idEstrategiaplano = idEstrategiaplano;
		}

	}
}
