package gob.bcb.client;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import gob.bcb.core.utils.ManejoPropiedades;
import gob.bcb.lavado.rest.dto.ResultadoSirh;
import gob.bcb.lavado.rest.dto.ValidarJwtRequest;
import okhttp3.Response;

public class AutenticacionRestClient extends PeticionesRest {

    protected Logger log = LoggerFactory.getLogger(this.getClass());

    private ManejoPropiedades manejoPropiedades;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public Gson JSON = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss")
            .create();

    public ResultadoSirh validarToken(ValidarJwtRequest jwtRequest) throws IOException {
        configSAI();
        String vRuta = host + "/auth";

        Response response = ejecutarPutSinParametro(vRuta, JSON.toJson(jwtRequest));

        if (response.code() == 200 || response.code() == 201) {

            String vResponseString = response.body().string();
            log.info(vResponseString);
            ResultadoSirh vResultado = JSON.fromJson(vResponseString, new TypeToken<ResultadoSirh>() {
            }.getType());
            response.body().close();
            return vResultado;
        } else {
            String vResponseString = response.body().string();

            ResultadoSirh resultado = JSON.fromJson(vResponseString,
                    new TypeToken<ResultadoSirh>() {
                    }.getType());
            response.body().close();
            return resultado;
        }
    }

    public ResultadoSirh validarApiKey(ValidarApiKeyRequest apiKeyRequest) {
        configSAI();
        String vRuta = host + "/auth/validarApikey";
        // log.info("***** Validando API Key en SAI");
        // log.info("***** URL SAI: " + vRuta);
        try {
            log.info("en validarApiKey APP: {} apikey {} ruta: {}", apiKeyRequest.getCodApp(),
                    apiKeyRequest.getApiKey(), vRuta);
            String json = JSON.toJson(apiKeyRequest);
            log.info("en validarApiKey APP: {} apikey {} ruta: {} jsonreq: {}", apiKeyRequest.getCodApp(),
                    apiKeyRequest.getApiKey(), vRuta, json);
            Response response = ejecutarPutSinParametro(vRuta, json);

            if (response.code() == 200 || response.code() == 201) {

                String vResponseString = response.body().string();
                log.info(vResponseString);
                ResultadoSirh vResultado = JSON.fromJson(vResponseString, new TypeToken<ResultadoSirh>() {
                }.getType());
                response.body().close();
                return vResultado;
            } else {
                String vResponseString = response.body().string();
                log.info("error-< " + vResponseString);
                ResultadoSirh resultado = new ResultadoSirh();
                resultado.setMensaje(vResponseString);
                resultado.setCorrecto(false);
                resultado.setStatus("" + response.code());
                // ResultadoSirh resultado=JSON.fromJson(vResponseString, new
                // TypeToken<ResultadoSirh>() {}.getType());
                response.body().close();
                return resultado;
            }
        } catch (Exception e) {
            log.error("Error en validar key {}", e.getMessage(), e);
            throw new RuntimeException("Error en validar key " + e.getMessage(), e);
        }
    }
}