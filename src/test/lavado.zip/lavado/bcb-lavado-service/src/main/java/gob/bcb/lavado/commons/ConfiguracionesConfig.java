package gob.bcb.lavado.commons;

import lombok.Getter;

@Getter
public enum ConfiguracionesConfig {
    CONFIG_URLS("config.filtro"),
    APY_KEY_IMMX("immx.api.key");

    String valor;

    ConfiguracionesConfig(String valor) {
        this.valor = valor;
    }
}
