/*
 * To change this template, choose Tools | Templates

 * and open the template in the editor.
 */
package gob.bcb.core.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.utils.ParserSwiftMessage;
import gob.bcb.lavado.exception.SwiftAdminException;

public class ArchivoUtil {
	private static final Logger log = LoggerFactory.getLogger(ArchivoUtil.class);
	private static final Charset UTF_8 = StandardCharsets.UTF_8;
	private static final Charset ISO_8859_1 = StandardCharsets.ISO_8859_1;

	/**
	 * Metodo que copia archivos en el sitema de archivos
	 * 
	 * @param origen
	 *                El archivo que se desea copiar
	 * @param destino
	 *                La ruta de la copia
	 * @throws FileNotFoundException
	 *                               En caso de no existir el archivo origen
	 * @throws IOException
	 *                               En caso de que no se pueda escribir en disco
	 */
	public static void copiarArchivos(File origen, File destino) throws FileNotFoundException, IOException {

		InputStream in = new FileInputStream(origen);
		// For Overwrite the file.
		OutputStream out = new FileOutputStream(destino);

		byte[] buf = new byte[1024];
		int len;
		while ((len = in.read(buf)) > 0) {
			out.write(buf, 0, len);
		}
		in.close();
		out.close();
	}

	/**
	 * Elimina la barra de separacion de rutas al final del nombre
	 * 
	 * @param nombre
	 *               El nombre del archivo
	 * @return El nombre del archivo sin la barra final de separador de rutas
	 */
	public static String formatearNombre(String nombre) {
		if (nombre.lastIndexOf('\\') > 0) {
			nombre = nombre.substring(nombre.lastIndexOf('\\') + 1);
		} else if (nombre.lastIndexOf('/') > 0) {
			nombre = nombre.substring(nombre.lastIndexOf('/') + 1);
		}
		return nombre;
	}

	public static String obtenerExtension(String nombre) {
		String extension = "";
		if (nombre == null) {
			return extension;
		}
		int ultimoPunto = nombre.lastIndexOf('.');
		if (ultimoPunto > 0) {
			extension = nombre.substring(ultimoPunto + 1);
		}
		return extension;
	}

	/**
	 * Metodo que retorna el tipo de mime de un archivo a partir de su extension
	 * 
	 * @param nombre
	 *               Nombre del archivo
	 * @return El tipo mime para el archivo
	 */
	public static String obtenerMime(String nombre) {
		String mime = null;
		String extension = obtenerExtension(nombre);
		if (extension != null && extension.trim().length() > 0) {
			mime = getMimeFromExt(extension);
		} else {
			mime = "application/x-binary";
		}
		return mime;
	}

	public static String getMimeFromExt(String extension) {
		String mime = null;
		if (extension.equalsIgnoreCase("avi")) {
			mime = "video/avi";
		} else if (extension.equalsIgnoreCase("bin")) {
			mime = "application/x-binary";
		} else if (extension.equalsIgnoreCase("bmp")) {
			mime = "image/bmp";
		} else if (extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx")) {
			mime = "application/msword";
		} else if (extension.equalsIgnoreCase("exe")) {
			mime = "application/octet-stream";
		} else if (extension.equalsIgnoreCase("gif")) {
			mime = "image/gif";
		} else if (extension.equalsIgnoreCase("java")) {
			mime = "text/plain";
		} else if (extension.equalsIgnoreCase("jpeg")) {
			mime = "image/jpeg";
		} else if (extension.equalsIgnoreCase("jpg")) {
			mime = "image/jpeg";
		} else if (extension.equalsIgnoreCase("mid")) {
			mime = "audio/midi";
		} else if (extension.equalsIgnoreCase("midi")) {
			mime = "audio/midi";
		} else if (extension.equalsIgnoreCase("mov")) {
			mime = "video/quicktime";
		} else if (extension.equalsIgnoreCase("mp3")) {
			mime = "audio/mpeg3";
		} else if (extension.equalsIgnoreCase("mpeg")) {
			mime = "video/mpeg";
		} else if (extension.equalsIgnoreCase("mpg")) {
			mime = "video/mpeg";
		} else if (extension.equalsIgnoreCase("mpp")) {
			mime = "application/vnd.ms-project";
		} else if (extension.equalsIgnoreCase("pdf")) {
			mime = "application/pdf";
		} else if (extension.equalsIgnoreCase("pot")) {
			mime = "application/mspowerpoint";
		} else if (extension.equalsIgnoreCase("png")) {
			mime = "image/png";
		} else if (extension.equalsIgnoreCase("pps")) {
			mime = "application/mspowerpoint";
		} else if (extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx")) {
			mime = "application/mspowerpoint";
		} else if (extension.equalsIgnoreCase("ps")) {
			mime = "application/postscript";
		} else if (extension.equalsIgnoreCase("tar")) {
			mime = "application/x-tar";
		} else if (extension.equalsIgnoreCase("text")) {
			mime = "text/plain";
		} else if (extension.equalsIgnoreCase("tgz")) {
			mime = "application/gnutar";
		} else if (extension.equalsIgnoreCase("txt")) {
			mime = "text/plain";
		} else if (extension.equalsIgnoreCase("xla")) {
			mime = "application/excel";
		} else if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx")) {
			mime = "application/vnd.ms-excel";
		} else if (extension.equalsIgnoreCase("xml")) {
			mime = "text/xml";
		} else if (extension.equalsIgnoreCase("zip")) {
			mime = "application/zip";
		} else if (extension.equalsIgnoreCase("odt")) {
			mime = "application/vnd.oasis.opendocument.text";
		} else if (extension.equalsIgnoreCase("ods")) {
			mime = "application/vnd.oasis.opendocument.spreadsheet";
		} else if (extension.equalsIgnoreCase("odp")) {
			mime = "application/vnd.oasis.opendocument.presentation";
		} else if (extension.equalsIgnoreCase("odg")) {
			mime = "application/vnd.oasis.opendocument.graphics";
		} else if (extension.equalsIgnoreCase("odc")) {
			mime = "application/vnd.oasis.opendocument.chart";
		} else if (extension.equalsIgnoreCase("odf")) {
			mime = "application/vnd.oasis.opendocument.formula";
		} else if (extension.equalsIgnoreCase("odb")) {
			mime = "application/vnd.oasis.opendocument.database[cita requerida]";
		} else if (extension.equalsIgnoreCase("odi")) {
			mime = "application/vnd.oasis.opendocument.image";
		} else if (extension.equalsIgnoreCase("odm")) {
			mime = "application/vnd.oasis.opendocument.text-master";
		} else {
			mime = "application/x-binary";
		}
		return mime;
	}

	public static String encriptarCodArchivo(Integer codArchivo) {
		return "" + ((codArchivo * 3) + 7);
	}

	public static Integer desencriptarCodArchivo(String codArchivo) {
		Integer codigo = Integer.parseInt(codArchivo);
		codigo = codigo - 7;
		codigo = codigo / 3;
		return codigo;
	}

	public static String checkSumFile(String pathFile) throws Exception {
		if (StringUtils.isBlank(pathFile)) {
			return null;
		}
		FileInputStream fis = new FileInputStream(pathFile);

		return checkSumFile(fis);
	}

	public static String checkSumFile(InputStream fis) throws Exception {
		// FileInputStream fis = new FileInputStream(new File(pathFile));
		MessageDigest messageDigest = MessageDigest.getInstance("SHA1");
		byte[] dataBytes = new byte[1024];
		int nread = 0;

		while ((nread = fis.read(dataBytes)) != -1) {
			messageDigest.update(dataBytes, 0, nread);
		}
		byte[] mdbytes = messageDigest.digest();

		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < mdbytes.length; i++) {
			sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
		}

		log.info("Hash " + sb.toString());
		return sb.toString();
	}

	public static String checkSumString0(String[] fis) throws Exception {
		// FileInputStream fis = new FileInputStream(new File(pathFile));
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");

		for (String s : fis) {
			// log.info("==> " + s);
			messageDigest.update(s.getBytes());
		}
		byte[] mdbytes = messageDigest.digest();

		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < mdbytes.length; i++) {
			String hexVal = Integer.toHexString(0xFF & mdbytes[i]);
			if (hexVal.length() == 1) {
				sb.append("0");
			}
			sb.append(hexVal);
		}

		// log.info("Hash " + sb.toString() );
		return sb.toString();
	}

	public static String checkSumString(String[] fis) throws Exception {
		// FileInputStream fis = new FileInputStream(new File(pathFile));
		if (fis == null || fis.length == 0) {
			return "";
		}
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");

		for (String s : fis) {
			log.info("==> " + s);
			messageDigest.update(s.getBytes());
		}
		byte[] mdbytes = messageDigest.digest();

		StringBuffer sb = new StringBuffer("");
		for (int i = 0; i < mdbytes.length; i++) {
			log.info("OO==> " + String.valueOf(mdbytes[i]));
			sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
		}

		// log.info("Hash " + sb.toString() );
		return sb.toString();
	}

	public static String getOriginalFilename(String pathFile) {
		// check for Unix-style path
		int pos = pathFile.lastIndexOf("/");
		if (pos == -1) {
			// check for Windows-style path
			pos = pathFile.lastIndexOf("\\");
		}
		if (pos != -1) {
			// any sort of path separator found
			return pathFile.substring(pos + 1);
		} else {
			// plain name
			return pathFile;
		}
	}

	public static File checkFile(String pathFile) {
		if (StringUtils.isBlank(pathFile)) {
			log.error("Ruta archivo nulo");
			// return;
			throw new RuntimeException("Ruta archivo nulo");
		}

		File h = new File(pathFile);
		if (!h.exists() || h.isDirectory()) {
			log.error("Archivo inexistente " + pathFile);
			throw new RuntimeException("Archivo inexistente " + pathFile);
		}
		return h;
	}

	public static String hashString(String stringToEncrypt) {
		return DigestUtils.md5Hex(stringToEncrypt);
	}

	public static String decodeFromUri(String strToDecode) {
		boolean isEncoded = true;
		String decodeStr = null;
		try {
			new URI(strToDecode);
		} catch (URISyntaxException e) {
			isEncoded = false;
		}
		log.info("Plano isEncoded? " + isEncoded);
		if (isEncoded) {
			try {
				decodeStr = URLDecoder.decode(strToDecode, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				throw new SwiftAdminException("Error en URLDecoder.decode " + e.getMessage(), e);
			}
			boolean isMt = ParserSwiftMessage.isFormatSwift(decodeStr);
			boolean isMx = false;
			if(!isMt) {
				isMx = ParserSwiftMessage.isFormatSwiftMx(decodeStr);				
			}
			boolean hasFormat = isMt || isMx;
			log.info(":>Plano isMt? " + isMt + " isMX: " + isMx + " hasFormat? " + hasFormat);						
			if (hasFormat)
				decodeStr = strToDecode;
			else
				decodeStr = decoderString(strToDecode);
		} else {
			boolean isMt = ParserSwiftMessage.isFormatSwift(strToDecode);
			boolean isMx = false;
			if(!isMt) {
				isMx = ParserSwiftMessage.isFormatSwiftMx(strToDecode);				

			}
			boolean hasFormat = isMt || isMx;
			log.info("Plano isMt? " + isMt + " isMX: " + isMx + " hasFormat? " + hasFormat);			
			if (hasFormat)
				decodeStr = strToDecode;
			else
				decodeStr = decoderString(strToDecode);
		}

		return decodeStr;
	}

	public static String encodeString(String menPlano) {
		if (StringUtils.isBlank(menPlano)) {
			return "";
		}

		byte[] xmlEncBy = Base64.getUrlEncoder().encode(menPlano.getBytes());
		String menEnc = new String(xmlEncBy, UTF_8);
		return menEnc;
	}

	public static String decoderString(String strEncode) {

			if (StringUtils.isBlank(strEncode)) {
				return "";
			}

			byte[] xmlEncBy = Base64.getUrlDecoder().decode(strEncode);
			String menEnc = new String(xmlEncBy, UTF_8);
			return menEnc;
	}

	public static void main(String args[]) {
		String str = "asdfw";
		String encStr = ArchivoUtil.encodeString(str);
		System.out.println("String encode " + encStr);
		String cad = "ezE6RjAxQkNFQkJPTFBBWFhYMTAwMDEwMDAwMX17MjpJMTAzU0NCTFVTMzNYWFhYTn17Mzp7MTA4OkFVVH19ezQ6DQo6MjA6MjgzNy8yMDA4MjYvSFZSDQo6MjNCOkNSRUQNCjozMkE6MjYwODIwVVNENjA1Miw5Nw0KOjUwRjovMzk4Nw0KMS9NSU5JU1RFUklPIERFIFJFTEFDSU9ORVMgRVhURVJJT1JFUw0KMi9CT3xMQSBQQVp8fFBMQVpBIE1VUklMTE8gSlVOSU4gRVNRLiBJTkdBVkl8fHx8fHx8fHx8DQozL0JPL0xBIFBBWg0KOjUzQjovMzU0NDAyMDY4MjAwMQ0KQkFOQ08gQ0VOVFJBTCBERSBCT0xJVklBDQo6NTdBOkVTUENFU01NWFhYDQo6NTlGOi9FUzI0MDAzMDEwMDMyNDAwMDQ0OTAyNzENCjEvQ09OU1VMQURPIERFIEJPTElWSUEgRU4gTUFEUklEIEVTUEFOQQ0KMi9FU3xNQURSSUR8fENBTExFIEFWSUFET1IgTElOREJFUkdIfDN8fHx8fHx8fHwNCjMvRVMvTUFEUklEDQo6NzA6UFJPQ0VTTyAxMDIgUEFHTyBBIFBFUlNPTkFMIERFDQpFTUJBSkFEQVMgWSBDT05TVUxBRE9TDQpDT1JSRVNQT05ESUVOVEUgQUwgTUVTIERFDQpESUNJRU1CUkUgUExBTklMTEEgMTIyNTENCjo3MUE6T1VSDQotfQ==";
		String decoSTring = ArchivoUtil.decoderString(cad);
		System.out.println(decoSTring);
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++");		
		encStr = "ezE6RjAxQkNFQkJPTFBBWFhYMTAwMDEwMDAwMX17MjpJMTAzU0NCTFVTMzNYWFhYTn17Mzp7MTA4OkFVVH19ezQ6DQo6MjA6MjgzNy8yMDA4MjYvSFZSDQo6MjNCOkNSRUQNCjozMkE6MjYwODIwVVNENjA1Miw5Nw0KOjUwRjovMzk4Nw0KMS9NSU5JU1RFUklPIERFIFJFTEFDSU9ORVMgRVhURVJJT1JFUw0KMi9CT3xMQSBQQVp8fFBMQVpBIE1VUklMTE8gSlVOSU4gRVNRLiBJTkdBVkl8fHx8fHx8fHx8DQozL0JPL0xBIFBBWg0KOjUzQjovMzU0NDAyMDY4MjAwMQ0KQkFOQ08gQ0VOVFJBTCBERSBCT0xJVklBDQo6NTdBOkVTUENFU01NWFhYDQo6NTlGOi9FUzI0MDAzMDEwMDMyNDAwMDQ0OTAyNzENCjEvQ09OU1VMQURPIERFIEJPTElWSUEgRU4gTUFEUklEIEVTUEFOQQ0KMi9FU3xNQURSSUR8fENBTExFIEFWSUFET1IgTElOREJFUkdIfDN8fHx8fHx8fHwNCjMvRVMvTUFEUklEDQo6NzA6UFJPQ0VTTyAxMDIgUEFHTyBBIFBFUlNPTkFMIERFDQpFTUJBSkFEQVMgWSBDT05TVUxBRE9TDQpDT1JSRVNQT05ESUVOVEUgQUwgTUVTIERFDQpESUNJRU1CUkUgUExBTklMTEEgMTIyNTENCjo3MUE6T1VSDQotfQ==";
		String decStr = ArchivoUtil.decodeFromUri(encStr);
		System.out.println("String DECO " + decStr);
		System.out.println("****************************************************************** ");
		String againDec = ArchivoUtil.decodeFromUri(decStr);
		System.out.println("AGAIN encode:::::: " + againDec);
		System.out.println(DigestUtils.md5Hex(
				"passwordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpasswordpassword"));

	}
}
