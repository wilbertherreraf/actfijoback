package gob.bcb.lavado.config;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import gob.bcb.lavado.QL.contbcb.CoinQLBeanImpl;
import gob.bcb.lavado.commons.Constants;

@Configuration
@ComponentScan(basePackageClasses = { CoinQLBeanImpl.class })
@ConfigurationProperties(prefix = Constants.PROP_PREFIX_CONTBCB)
public class DomainAndPersistenceCoin extends HikariConfig {
	private static final Logger log = LoggerFactory.getLogger(DomainAndPersistenceCoin.class);

	private JpaVendorAdapter jpaVendorAdapter() {
		HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
		hibernateJpaVendorAdapter.setShowSql(false);
		hibernateJpaVendorAdapter.setDatabase(Database.INFORMIX);
		hibernateJpaVendorAdapter.setDatabasePlatform("org.hibernate.dialect.InformixDialect");
		return hibernateJpaVendorAdapter;
	}

//	@Bean(name = "dataSourceCoin", destroyMethod = "close")
//	public DataSource dataSourceCoin() throws IllegalArgumentException, NamingException {
//		log.info("dataSourceCoin " + getJdbcUrl() + " " + getDataSourceJNDI());
//
//		JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
//		bean.setJndiName(getDataSourceJNDI());
//		bean.setProxyInterface(DataSource.class);
//		bean.setLookupOnStartup(false);
//		bean.afterPropertiesSet();
//		
//		HikariDataSource ds = new HikariDataSource();
//		ds.setDataSource((DataSource) bean.getObject());
//		// ds.setDataSourceJNDI(getDataSourceJNDI());
//		ds.addDataSourceProperty("cachePrepStmts", "true");
//		ds.addDataSourceProperty("useServerPrepStmts", "true");
//		ds.setAutoCommit(false);
//		ds.setPoolName(Constants.PUNIT_CONTBCB);
//		return ds;
//	}

	@Bean(name = "dataSourceCoin")
	public DataSource dataSourceCoin() throws NamingException {
		log.info("dataSourceCoin " + getJdbcUrl() + " " + getDataSourceJNDI());

		JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
		// bean.setJndiName(Constants.JNDI_CONTBCB);
		bean.setJndiName(getDataSourceJNDI());
		bean.setProxyInterface(DataSource.class);
		bean.setLookupOnStartup(false);
		bean.afterPropertiesSet();
		return (DataSource) bean.getObject();
	}

	@Bean(name = "entityManagerFactoryCoin")
	public LocalContainerEntityManagerFactoryBean entityManagerFactoryCoin(@Qualifier("dataSourceCoin") DataSource dataSourceCoin) {
		log.info("Coin:::: entityManagerFactoryCoin " + (dataSourceCoin == null));
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dataSourceCoin);
		em.setPackagesToScan(CoinQLBeanImpl.class.getPackage().getName());
		em.setJpaVendorAdapter(jpaVendorAdapter());
		em.setPersistenceUnitName(Constants.PUNIT_CONTBCB);

		em.afterPropertiesSet();
		log.info("entityManagerFactoryCoin config hecho... " + em.getPersistenceUnitName());
		return em;
	}

}