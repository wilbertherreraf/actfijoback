package gob.bcb.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ValidarApiKeyRequest implements Serializable {
    private static final long serialVersionUID = 1L;
    private String codApp;

    private String apiKey;
}
