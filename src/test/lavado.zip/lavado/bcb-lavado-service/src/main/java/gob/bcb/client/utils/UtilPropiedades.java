package gob.bcb.client.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Objects;
import java.util.Properties;
import java.util.ResourceBundle;

public class UtilPropiedades {
    public static final String PROP_CLIENTE = "ruta.properties.client";
    public static final String PROP_CORREO = "ruta.properties.correo";
    public static final String PROP_SIN_FILTRO = "ruta.properties.sin.filtro";
    public static final String PROP_PRIVATE = "ruta.properties.private";
    public static final String PROP_CONFIG = "RUTAS_PROPERTIES_EXT";
    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private static final Locale locale = new Locale("es", "ES");
    private static final String urlConfig = ResourceBundle.getBundle("application", locale).getString(PROP_CONFIG);
    private Properties propiedadesExternas;
    private Properties propiedadesConfig;

    public static final String CERTIFICADO_PUBLICO = "ruta.certificado.pubkey";
    public static final String CERTIFICADO_PRIVADO = "ruta.certificado.private";
    public static final String CERTIFICADO_PUBLICO_ADUANA = "ruta.certificado.aduana";

    public UtilPropiedades() {
        initPropiedadesConfig();
    }

    private void initPropiedadesConfig() {
        try {
            InputStream resourceStream = new FileInputStream(urlConfig);
            propiedadesConfig = new Properties();
            propiedadesConfig.load(resourceStream);
            resourceStream.close();
        } catch (IOException e) {
            log.error("No se pudo obtener las configuraciones");
        }
    }

    public String getConfig(String name) {
        String config = "";
        try {
            config = propiedadesConfig.getProperty(name);
        } catch (Exception e) {
            log.error("No se encontro propiedad :" + name);
        }
        return config;
    }

    public void initPropiedadesExternas(String ruta) {
        try {
            InputStream resourceStream = new FileInputStream(ruta);
            propiedadesExternas = new Properties();
            propiedadesExternas.load(resourceStream);
            resourceStream.close();//cerramos
        } catch (IOException e) {
            log.error("No se pudo obtener las rutas externas");
        }
    }

    public Properties initPropiedadesFilter() {
        Properties properties = new Properties();
        try {
            String ruta = propiedadesConfig.getProperty(PROP_SIN_FILTRO);
            InputStream resourceStream = new FileInputStream(ruta);
            properties.load(resourceStream);
            resourceStream.close();
        } catch (IOException e) {
            log.error("No se pudo obtener las rutas sin filtro");
        }
        return properties;
    }

    public String getValorPropiedadExterna(String name) {
        String config = "";
        try {
            config = propiedadesExternas.getProperty(name);
        } catch (Exception e) {
            log.error("No se encontro el mensaje: " + name);
        }
        return config;
    }

    public String getCliente(String valor) {
        String rutaClientes = getConfig(PROP_CLIENTE);
        initPropiedadesExternas(rutaClientes);
        return getValorPropiedadExterna(valor);
    }

    public String getPrivate(String valor) {
        String rutaPrivate = getConfig(PROP_PRIVATE);
        initPropiedadesExternas(rutaPrivate);
        return getValorPropiedadExterna(valor);
    }

    public String getCertificadoPublico(String valor) {
        String rutaPrivate = getConfig(CERTIFICADO_PUBLICO);
        initPropiedadesExternas(rutaPrivate);
        return getValorPropiedadExterna(valor);
    }

    public String getCertificadoPublicoAduana(String valor) {
        String rutaPrivate = getConfig(CERTIFICADO_PUBLICO_ADUANA);
        initPropiedadesExternas(rutaPrivate);
        return getValorPropiedadExterna(valor);
    }
/*    public String getCertificadoPrivado(String valor) {
        String rutaPrivate = getConfig(CERTIFICADO_PRIVADO);
        initPropiedadesExternas(rutaPrivate);
        return getValorPropiedadExterna(valor);
    }*/
    public String getCertificadoPrivado(String name) {
        String config = "";
        try {
            config = propiedadesConfig.getProperty(name);
        } catch (Exception e) {
            log.error("No se encontro propiedad :" + name);
        }
        return config;
    }


    public Properties getPropCorreo() {
        Properties properties = new Properties();
        try {
            InputStream resourceStream = new FileInputStream(propiedadesConfig.getProperty(PROP_CORREO));
            properties.load(resourceStream);
            resourceStream.close();
            Objects.requireNonNull(properties, "No se encontro: " + PROP_CORREO);
        } catch (Exception e) {
            log.error("Ocurrio un error en obtener Propiedades de correo");
        }
        return properties;
    }

}
