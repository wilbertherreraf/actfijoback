package gob.bcb.lavado.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TermVector;

@Entity
@Table(name = "ofa_blacklist")
@NamedQuery(name = "OfaBlacklist.findAll", query = "SELECT o FROM OfaBlacklist o")
public class OfaBlacklist implements Serializable {
		private static final long serialVersionUID = 1L;

		@Id
		@Column(name = "blk_id")
		@DocumentId
		private Integer blkId;

		@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
		@Column(name = "blk_content")
		private String blkContent;

		@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
		@Column(name = "blk_type")
		private String blkType;

		@Field(store = Store.NO, analyze=Analyze.NO,index=Index.NO)		
		@Temporal(TemporalType.TIMESTAMP)
		@Column(name = "blk_auditfho")
		private Date blkAuditfho;

		@Field(store = Store.NO, analyze=Analyze.NO,index=Index.NO)		
		@Column(name = "blk_auditusr")
		private String blkAuditusr;

		@Field(store = Store.NO, analyze=Analyze.NO,index=Index.NO)		
		@Column(name = "blk_auditwst")
		private String blkAuditwst;
		
		public OfaBlacklist() {

		}
		
		public Integer getBlkId() {
			return blkId;
		}

		public void setBlkId(Integer blkId) {
			this.blkId = blkId;
		}

		public String getBlkContent() {
			return blkContent;
		}

		public void setBlkContent(String blkContent) {
			this.blkContent = blkContent;
		}

		public String getBlkType() {
			return blkType;
		}

		public void setBlkType(String blkType) {
			this.blkType = blkType;
		}

		public Date getBlkAuditfho() {
			return blkAuditfho;
		}

		public void setBlkAuditfho(Date blkAuditfho) {
			this.blkAuditfho = blkAuditfho;
		}

		public String getBlkAuditwst() {
			return blkAuditwst;
		}

		public void setBlkAuditwst(String blkAuditwst) {
			this.blkAuditwst = blkAuditwst;
		}

		public String getBlkAuditusr() {
			return blkAuditusr;
		}

		public void setBlkAuditusr(String blkAuditusr) {
			this.blkAuditusr = blkAuditusr;
		}

		@Override
		public String toString() {
			return "OfaBlacklist [blkId=" + blkId + ", blkContent=" + blkContent + ", blkType=" + blkType + ", blkAuditfho=" + blkAuditfho + ", blkAuditusr="
					+ blkAuditusr + ", blkAuditwst=" + blkAuditwst + "]";
		}
		
		
}
