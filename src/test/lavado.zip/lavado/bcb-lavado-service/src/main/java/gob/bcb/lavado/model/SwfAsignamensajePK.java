package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the swf_asignamensaje database table.
 * 
 */
@Embeddable
public class SwfAsignamensajePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="res_codmen")
	private Integer resCodmen;

	@Column(name="res_codemp")
	private Integer resCodemp;

	public SwfAsignamensajePK() {
	}
	public Integer getResCodmen() {
		return this.resCodmen;
	}
	public void setResCodmen(Integer resCodmen) {
		this.resCodmen = resCodmen;
	}
	public Integer getResCodemp() {
		return this.resCodemp;
	}
	public void setResCodemp(Integer resCodemp) {
		this.resCodemp = resCodemp;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SwfAsignamensajePK)) {
			return false;
		}
		SwfAsignamensajePK castOther = (SwfAsignamensajePK)other;
		return 
			(this.resCodmen == castOther.resCodmen)
			&& (this.resCodemp == castOther.resCodemp);
	}

	public int hashCode() {
		final Integer prime = 31;
		Integer hash = 17;
		hash = hash * prime + this.resCodmen;
		hash = hash * prime + this.resCodemp;
		
		return hash;
	}
}