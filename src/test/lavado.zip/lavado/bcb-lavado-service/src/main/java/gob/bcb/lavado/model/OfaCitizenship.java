package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;

/**
 * The persistent class for the ofa_citizenship database table.
 * 
 */

@Entity
//@Indexed
@Table(name = "ofa_citizenship")
@NamedQuery(name = "OfaCitizenship.findAll", query = "SELECT o FROM OfaCitizenship o")
public class OfaCitizenship implements Serializable {
	private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="cit_id")
    @DocumentId
    private Integer citId;
	
	@Column(name = "cit_uid")
	private Integer citUid;

	@Field
	@Column(name = "cit_country")
	private String citCountry;

	@Field
	@Column(name = "cit_entryuid")
	private Integer citEntryuid;

	@Field
	@Column(name = "cit_mainentry")
	private String citMainentry;

	@ContainedIn
	////@IndexedEmbedded
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "cit_entryuid", nullable = false, insertable = false, updatable = false, referencedColumnName = "sdn_id")
	private OfaSdnentry ofaSdnentry;

	public OfaCitizenship() {
	}

	public Integer getCitUid() {
		return this.citUid;
	}

	public void setCitUid(Integer citUid) {
		this.citUid = citUid;
	}

	public String getCitCountry() {
		return this.citCountry;
	}

	public void setCitCountry(String citCountry) {
		this.citCountry = citCountry;
	}

	public Integer getCitEntryuid() {
		return this.citEntryuid;
	}

	public void setCitEntryuid(Integer citEntryuid) {
		this.citEntryuid = citEntryuid;
	}

	public String getCitMainentry() {
		return this.citMainentry;
	}

	public void setCitMainentry(String citMainentry) {
		this.citMainentry = citMainentry;
	}

	public OfaSdnentry getOfaSdnentry() {
		return ofaSdnentry;
	}

	public void setOfaSdnentry(OfaSdnentry ofaSdnentry) {
		this.ofaSdnentry = ofaSdnentry;
	}

	public Integer getCitId() {
		return citId;
	}

	public void setCitId(Integer citId) {
		this.citId = citId;
	}

}
