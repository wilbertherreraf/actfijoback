package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

/**
 * The persistent class for the gen_desctabla database table.
 * 
 */
@Entity(name = "d_portsw.gen_desctabla")
@Table(name = "gen_desctabla")
public class GenDesctabla implements Serializable, gob.bcb.lavado.model.DomainObject {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private GenDesctablaPK id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "des_auditfho")
	private Date desAuditfho;

	@Column(name = "des_auditusr")
	private String desAuditusr;

	@Column(name = "des_auditwst")
	private String desAuditwst;

	@Column(name = "des_codeiso")
	private String desCodeiso;

	@Column(name = "des_descrip")
	private String desDescrip;

	@Column(name = "des_status")
	private String desStatus;

	// uni-directional many-to-one association to GenTablas
//	@ManyToOne
//	@JoinColumn(name = "des_codtab", insertable = false, updatable = false)
//	private GenTablas genTablas;

	public GenDesctabla() {
	}

	public GenDesctablaPK getId() {
		return this.id;
	}

	public void setId(GenDesctablaPK id) {
		this.id = id;
	}

	public Date getDesAuditfho() {
		return this.desAuditfho;
	}

	public void setDesAuditfho(Date desAuditfho) {
		this.desAuditfho = desAuditfho;
	}

	public String getDesAuditusr() {
		return this.desAuditusr;
	}

	public void setDesAuditusr(String desAuditusr) {
		this.desAuditusr = desAuditusr;
	}

	public String getDesAuditwst() {
		return this.desAuditwst;
	}

	public void setDesAuditwst(String desAuditwst) {
		this.desAuditwst = desAuditwst;
	}

	public String getDesCodeiso() {
		return this.desCodeiso;
	}

	public void setDesCodeiso(String desCodeiso) {
		this.desCodeiso = desCodeiso;
	}

	public String getDesDescrip() {
		return this.desDescrip;
	}

	public void setDesDescrip(String desDescrip) {
		this.desDescrip = desDescrip;
	}

	public String getDesStatus() {
		return this.desStatus;
	}

	public void setDesStatus(String desStatus) {
		this.desStatus = desStatus;
	}
//
//	public GenTablas getGenTablas() {
//		return this.genTablas;
//	}
//
//	public void setGenTablas(GenTablas genTablas) {
//		this.genTablas = genTablas;
//	}

}