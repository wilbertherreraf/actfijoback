package gob.bcb.core.utils;

import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.KeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Collections;
import java.util.List;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.KeyValue;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class FirmaHelper {
	private static final Log log = LogFactory.getLog(FirmaHelper.class);
	private XMLSignatureFactory fac;

	public Document sign(Document doc, KeyPair keyPair) {
		if (log.isTraceEnabled()) {
			// log.trace("Document to be signed={0}", new
			// Object[]{SamlUtils.getDocumentAsString(doc)});
		}

		PrivateKey signingKey = keyPair.getPrivate();
		PublicKey publicKey = keyPair.getPublic();

		DOMSignContext dsc = new DOMSignContext(signingKey, doc.getDocumentElement());
		dsc.setDefaultNamespacePrefix("dsig");

		try {
			DigestMethod digestMethodObj = fac.newDigestMethod(DigestMethod.SHA1, null);
			Transform transform = fac.newTransform(CanonicalizationMethod.INCLUSIVE, (TransformParameterSpec) null);

			List<Transform> transformList = Collections.singletonList(transform);
			String referenceURI = "#" + doc.getDocumentElement().getAttribute("ID");
			Reference ref = fac.newReference(referenceURI, digestMethodObj, transformList, null, null);

			String canonicalizationMethodType = CanonicalizationMethod.INCLUSIVE;
			CanonicalizationMethod canonicalizationMethod = fac.newCanonicalizationMethod(canonicalizationMethodType, (C14NMethodParameterSpec) null);

			List<Reference> referenceList = Collections.singletonList(ref);

			String signatureMethodString = publicKey.getAlgorithm().equalsIgnoreCase("RSA") ? SignatureMethod.RSA_SHA1 : SignatureMethod.DSA_SHA1;
			SignatureMethod signatureMethod = fac.newSignatureMethod(signatureMethodString, null);
			SignedInfo si = fac.newSignedInfo(canonicalizationMethod, signatureMethod, referenceList);

			KeyInfoFactory kif = fac.getKeyInfoFactory();
			KeyValue kv = kif.newKeyValue(publicKey);
			KeyInfo ki = kif.newKeyInfo(Collections.singletonList(kv));

			XMLSignature signature = fac.newXMLSignature(si, ki);

			signature.sign(dsc);
		} catch (XMLSignatureException e) {
			throw new RuntimeException(e);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		} catch (InvalidAlgorithmParameterException e) {
			throw new RuntimeException(e);
		} catch (KeyException e) {
			throw new RuntimeException(e);
		} catch (MarshalException e) {
			throw new RuntimeException(e);

		}
		return doc;
	}

	public void validateSignature(Key publicKey, Document signedDoc) throws Exception {
		NodeList nl = signedDoc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
		if (nl == null || nl.getLength() == 0) {
			throw new Exception("Signature element is not present or has zero length.");
		}

		try {
			DOMValidateContext valContext = new DOMValidateContext(publicKey, nl.item(0));
			XMLSignature signature = fac.unmarshalXMLSignature(valContext);
			boolean signatureValid = signature.validate(valContext);

			if (log.isTraceEnabled() && !signatureValid) {
				boolean sv = signature.getSignatureValue().validate(valContext);
				log.trace("Signature validation status: " + sv);

				@SuppressWarnings("unchecked")
				List<Reference> references = signature.getSignedInfo().getReferences();
				for (Reference ref : references) {
					log.trace("[Ref id=" + ref.getId() + ":uri=" + ref.getURI() + "] validity status:" + ref.validate(valContext));
				}
			}

			if (!signatureValid) {
				throw new Exception("Invalid signature.");
			}
		} catch (XMLSignatureException e) {
			throw new RuntimeException(e);
		} catch (MarshalException e) {
			throw new RuntimeException(e);
		}
	}
}
