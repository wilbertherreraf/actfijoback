package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;


/**
 * The persistent class for the ofa_dateofbirth database table.
 * 
 */
@Entity
//@Indexed
@Table(name="ofa_dateofbirth")
@NamedQuery(name="OfaDateofbirth.findAll", query="SELECT o FROM OfaDateofbirth o")
public class OfaDateofbirth implements Serializable {
	private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="bir_id")
	private Integer birId;
    
	@Column(name="bir_uid")
	private Integer birUid;

	@Field
	@Column(name="bir_dateofbirth")
	private String birDateofbirth;

	@Field
	@Column(name="bir_entryuid")
	private Integer birEntryuid;

	@Field
	@Column(name="bir_mainentry")
	private String birMainentry;

	@ContainedIn
	////@IndexedEmbedded
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bir_entryuid", nullable = false, insertable = false, updatable = false, referencedColumnName = "sdn_id")
	private OfaSdnentry ofaSdnentry;
	
	public OfaDateofbirth() {
	}

	public Integer getBirUid() {
		return this.birUid;
	}

	public void setBirUid(Integer birUid) {
		this.birUid = birUid;
	}

	public String getBirDateofbirth() {
		return this.birDateofbirth;
	}

	public void setBirDateofbirth(String birDateofbirth) {
		this.birDateofbirth = birDateofbirth;
	}

	public Integer getBirEntryuid() {
		return this.birEntryuid;
	}

	public void setBirEntryuid(Integer birEntryuid) {
		this.birEntryuid = birEntryuid;
	}

	public String getBirMainentry() {
		return this.birMainentry;
	}

	public void setBirMainentry(String birMainentry) {
		this.birMainentry = birMainentry;
	}

	public OfaSdnentry getOfaSdnentry() {
		return ofaSdnentry;
	}

	public void setOfaSdnentry(OfaSdnentry ofaSdnentry) {
		this.ofaSdnentry = ofaSdnentry;
	}

	public Integer getBirId() {
		return birId;
	}

	public void setBirId(Integer birId) {
		this.birId = birId;
	}

}
