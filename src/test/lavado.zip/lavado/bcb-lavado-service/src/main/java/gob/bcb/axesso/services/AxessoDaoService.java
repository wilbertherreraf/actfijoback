package gob.bcb.axesso.services;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.userdetails.UsernameNotFoundException;

import gob.bcb.jee.axesso.entidades.Password;
import gob.bcb.jee.axesso.excepciones.OperationException;
import gob.bcb.lavado.pojos.GenUsuario;

public interface AxessoDaoService {
	GenUsuario getGenUsuarioFromLogin(String login) throws UsernameNotFoundException;

	Password changePassword(String usrLogin, String password, String passwordNew, HttpServletResponse response, HttpServletRequest request)
			throws UsernameNotFoundException;

	void actualizaIntentos(String username, Integer intentos) throws Exception;

	Password findPasswordByLogin(String usrLogin, String password) throws OperationException;

	Integer getIntentos(String username);

	boolean loginSuccessAndPasswordChangeRequired(String username);

}
