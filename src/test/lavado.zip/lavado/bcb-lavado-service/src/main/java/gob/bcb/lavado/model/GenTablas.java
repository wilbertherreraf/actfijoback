package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the gen_tablas database table.
 * 
 */
@Entity(name = "d_portsw.gen_tablas") 
@Table(name="gen_tablas")
public class GenTablas implements Serializable, gob.bcb.lavado.model.DomainObject {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="tab_codigo")
	private Integer tabCodigo;

	@Column(name="tab_descripcion")
	private String tabDescripcion;

	public GenTablas() {
	}

	public Integer getTabCodigo() {
		return this.tabCodigo;
	}

	public void setTabCodigo(Integer tabCodigo) {
		this.tabCodigo = tabCodigo;
	}

	public String getTabDescripcion() {
		return this.tabDescripcion;
	}

	public void setTabDescripcion(String tabDescripcion) {
		this.tabDescripcion = tabDescripcion;
	}

}