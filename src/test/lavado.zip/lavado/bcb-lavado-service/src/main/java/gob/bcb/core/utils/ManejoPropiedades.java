/**
 * ╔╗ ┌─┐┌┐┌┌─┐┌─┐  ╔═╗┌─┐┌┐┌┌┬┐┬─┐┌─┐┬    ┌┬┐┌─┐  ╔╗ ┌─┐┬  ┬┬  ┬┬┌─┐
 * ╠╩╗├─┤││││  │ │  ║  ├┤ │││ │ ├┬┘├─┤│     ││├┤   ╠╩╗│ ││  │└┐┌┘│├─┤
 * ╚═╝┴ ┴┘└┘└─┘└─┘  ╚═╝└─┘┘└┘ ┴ ┴└─┴ ┴┴─┘  ─┴┘└─┘  ╚═╝└─┘┴─┘┴ └┘ ┴┴ ┴
 * Copyright © 2022 - ${project.inceptionYear}
 * Licensed under BCB Licence version 1.0
 * See https://www.bcb.gob.bo/licenses/LICENSE-1.0
 */
package gob.bcb.core.utils;
/**
 * @author DIDS - acalvi
 */
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

public class ManejoPropiedades {

    protected final Logger log = LoggerFactory.getLogger(this.getClass());

    private static final String CLIENTES_CONFIG_PROPERTIES = "clientes";
    public ResourceBundle clientesProperties;
    private static final String CONFIG_PROPERTIES = "config";
    public ResourceBundle configProperties;
    private static final String URL_SIN_FILTRO = "noFilter";
    public ResourceBundle noFilterProperties;
    Properties propiedadesExternas;
    private static final String CORREO_SITES = "correo";
    public ResourceBundle correoProperties;

    public ManejoPropiedades() {
        Locale locale = new Locale("es", "ES");
        this.clientesProperties = ResourceBundle.getBundle(CLIENTES_CONFIG_PROPERTIES, locale);
        this.configProperties = ResourceBundle.getBundle(CONFIG_PROPERTIES, locale);
    }

    /**
     * Obtiene las configuraciones del cliente
     * @param name Nombre del cliente
     * @return propiedad del cliente
     */
    public String getClienteConfig(String name) {
        String config = "";
        try {
            config = getValor(clientesProperties,name);
        } catch (Exception e) {
            log.error("Error: param: " + name + " -> " + e.getMessage());
            throw new RuntimeException("Error: param: " + name + " -> " + e.getMessage());
        }
        return config;
    }

    /**
     * Obtiene las configuraciones de una archivo de configuraciones externas
     * @param ruta Ruta del archivo de configuraciones
     */
    public void initPropiedadesExternas(String ruta) {
        try {
            File file = new File(ruta);
            InputStream resourceStream = new FileInputStream(file);
            propiedadesExternas = new Properties();
            propiedadesExternas.load(resourceStream);
        } catch (IOException e) {
            log.error("");
        }
    }

    /**
     * Obtiene las configuraciones del cliente
     * @param name Nombre del cliente
     * @return propiedad del cliente
     */
    public String getValorPropiedadExterna(String name) {
        String config = "";
        try {
            config = propiedadesExternas.getProperty(name);
        } catch (Exception e) {
            log.error("Error: param: " + name + " -> " + e.getMessage());
            throw new RuntimeException("Error: param: " + name + " -> " + e.getMessage());
        }
        return config;
    }

    /**
     * Obtiene las configuraciones del Config
     * @param name Nombre del config
     * @return propiedad del config
     */
    public String getConfig(String name) {
        String config = "";
        try {
            config = getValor(configProperties,name);
        } catch (Exception e) {
            log.error("Error: param: " + name + " -> " + e.getMessage());
            throw new RuntimeException("Error: param: " + name + " -> " + e.getMessage());
        }
        return config;
    }

    /**
     * Obtiene las configuraciones del noFilter
     * @param name Nombre del noFilter
     * @return propiedad del noFilter
     */
    public String getnoFilterConfig(String name) {
        String config = "";
        try {
            config = getValor(noFilterProperties,name);
        } catch (Exception e) {
            log.error("Error: param: " + name + " -> " + e.getMessage());
            throw new RuntimeException("Error: param: " + name + " -> " + e.getMessage());
        }
        return config;
    }

    /**
     * Obtiene las configuraciones del noFilter
     * @param name Nombre del noFilter
     * @return propiedad del noFilter
     */
    public String getConfigFilter(String name) {
        String config = "";
        try {
            config = getValor(configProperties,name);
        } catch (Exception e) {
            log.error("Error: param: " + name + " -> " + e.getMessage());
            throw new RuntimeException("Error: param: " + name + " -> " + e.getMessage());
        }
        return config;
    }

    public String getCorreoConfig(String name) {
        String config = "";
        try {
            config = getValor(correoProperties,name);
        } catch (Exception e) {
            log.error("Error: param: " + name + " -> " + e.getMessage());
            throw new RuntimeException("Error: param: " + name + " -> " + e.getMessage());
        }
        return config;
    }

    /**
     * Obtiene las configuraciones del correo
     * @param name Nombre del correo
     * @return propiedad del correo
     */
    public String getCorreoFilter(String name) {
        String config = "";
        try {
            config = getValor(correoProperties,name);
        } catch (Exception e) {
            log.error("Error: param: " + name + " -> " + e.getMessage());
            throw new RuntimeException("Error: param: " + name + " -> " + e.getMessage());
        }
        return config;
    }

    public static String getValor(ResourceBundle rb,String name) {
        String vUrl = rb.getString(name);
        if (vUrl.startsWith("${") && vUrl.endsWith("}"))
            vUrl = EnvPropertiesSingle.getPropertie(vUrl.replace("${", "").replace("}", ""));
        return vUrl;
    }

}
