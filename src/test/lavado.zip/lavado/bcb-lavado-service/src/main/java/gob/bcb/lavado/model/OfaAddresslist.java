package gob.bcb.lavado.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Norms;
import org.hibernate.search.annotations.Store;

/**
 * The persistent class for the ofa_addresslist database table.
 * 
 */
//@Indexed
@Entity
@Table(name = "ofa_addresslist")
@NamedQuery(name = "OfaAddresslist.findAll", query = "SELECT o FROM OfaAddresslist o")
public class OfaAddresslist implements Serializable {
	private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="adr_id")
	private Integer adrId;
	
	@Column(name = "adr_uid")
	private Integer adrUid;

	@Field(store = Store.YES)
	@Column(name = "adr_address1")
	private String adrAddress1;

	@Field(store = Store.YES)
	@Column(name = "adr_address2")
	private String adrAddress2;

	@Field(store = Store.YES)
	@Column(name = "adr_address3")
	private String adrAddress3;

	@Field(store = Store.YES)
	@Column(name = "adr_city")
	private String adrCity;

	@Field(store = Store.YES)
	@Column(name = "adr_country")
	private String adrCountry;

	@Field(analyze = Analyze.NO,norms=Norms.NO)
	@Column(name = "adr_entryuid")
	private Integer adrEntryuid;

	@Field(analyze = Analyze.NO,norms=Norms.NO)
	@Column(name = "adr_postalcode")
	private String adrPostalcode;

	@Field(store = Store.YES, analyze = Analyze.NO)
	@Column(name = "adr_stateorprovinc")
	private String adrStateorprovinc;

	@ContainedIn
	////@IndexedEmbedded()
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "adr_entryuid", nullable = false, insertable = false, updatable = false, referencedColumnName = "sdn_id")
	private OfaSdnentry ofaSdnentry;

	public OfaAddresslist() {
	}

	public Integer getAdrUid() {
		return this.adrUid;
	}

	public void setAdrUid(Integer adrUid) {
		this.adrUid = adrUid;
	}

	public String getAdrAddress1() {
		return this.adrAddress1;
	}

	public void setAdrAddress1(String adrAddress1) {
		this.adrAddress1 = adrAddress1;
	}

	public String getAdrAddress2() {
		return this.adrAddress2;
	}

	public void setAdrAddress2(String adrAddress2) {
		this.adrAddress2 = adrAddress2;
	}

	public String getAdrAddress3() {
		return this.adrAddress3;
	}

	public void setAdrAddress3(String adrAddress3) {
		this.adrAddress3 = adrAddress3;
	}

	public String getAdrCity() {
		return this.adrCity;
	}

	public void setAdrCity(String adrCity) {
		this.adrCity = adrCity;
	}

	public String getAdrCountry() {
		return this.adrCountry;
	}

	public void setAdrCountry(String adrCountry) {
		this.adrCountry = adrCountry;
	}

	public Integer getAdrEntryuid() {
		return this.adrEntryuid;
	}

	public void setAdrEntryuid(Integer adrEntryuid) {
		this.adrEntryuid = adrEntryuid;
	}

	public String getAdrPostalcode() {
		return this.adrPostalcode;
	}

	public void setAdrPostalcode(String adrPostalcode) {
		this.adrPostalcode = adrPostalcode;
	}

	public String getAdrStateorprovinc() {
		return this.adrStateorprovinc;
	}

	public void setAdrStateorprovinc(String adrStateorprovinc) {
		this.adrStateorprovinc = adrStateorprovinc;
	}

	public OfaSdnentry getOfaSdnentry() {
		return ofaSdnentry;
	}

	public void setOfaSdnentry(OfaSdnentry ofaSdnentry) {
		this.ofaSdnentry = ofaSdnentry;
	}

	public Integer getAdrId() {
		return adrId;
	}

	public void setAdrId(Integer adrId) {
		this.adrId = adrId;
	}

}
