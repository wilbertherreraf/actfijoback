package gob.bcb.lavado.commons;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class EmailDetalle  implements Serializable  {
	private String[] to;
	private String toName;
	private String from;
	private String fromName;
	private String subject;	
	private String content;
	private Map<String, String> params = new HashMap<String, String>();
	public EmailDetalle() {
	}
	public EmailDetalle(String[] to, String subject, String content) {
		this.to = to;
		this.content =content;
		this.subject = subject;
	}
	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getFromName() {
		return fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public String getToName() {
		return toName;
	}

	public void setToName(String toName) {
		this.toName = toName;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String[] getTo() {
		return to;
	}

	public void setTo(String[] to) {
		this.to = to;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	@Override
	public String toString() {
		return "EmailDetalle [to=" + Arrays.toString(to) + ", toName=" + toName + ", from=" + from + ", fromName=" + fromName + ", subject="
				+ subject + ", content=" + content + "]";
	}
	public Map<String, String> getParams() {
		return params;
	}
	public void setParams(Map<String, String> params) {
		this.params = params;
	}

}
