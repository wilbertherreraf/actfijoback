package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;


/**
 * The persistent class for the ofa_placeofbirth database table.
 * 
 */
@Entity
//@Indexed
@Table(name="ofa_placeofbirth")
@NamedQuery(name="OfaPlaceofbirth.findAll", query="SELECT o FROM OfaPlaceofbirth o")
public class OfaPlaceofbirth implements Serializable {
	private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="pob_id")
    private Integer pobId;
    
	@Column(name="pob_uid")
	private Integer pobUid;

	@Field
	@Column(name="pob_entryuid")
	private Integer pobEntryuid;

	@Field
	@Column(name="pob_mainentry")
	private String pobMainentry;

	@Field
	@Column(name="pob_placeofbirth")
	private String pobPlaceofbirth;

	@ContainedIn
	////@IndexedEmbedded
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "pob_entryuid", nullable = false, insertable = false, updatable = false, referencedColumnName = "sdn_id")
	private OfaSdnentry ofaSdnentry;
	
	public OfaPlaceofbirth() {
	}

	public Integer getPobUid() {
		return this.pobUid;
	}

	public void setPobUid(Integer pobUid) {
		this.pobUid = pobUid;
	}

	public Integer getPobEntryuid() {
		return this.pobEntryuid;
	}

	public void setPobEntryuid(Integer pobEntryuid) {
		this.pobEntryuid = pobEntryuid;
	}

	public String getPobMainentry() {
		return this.pobMainentry;
	}

	public void setPobMainentry(String pobMainentry) {
		this.pobMainentry = pobMainentry;
	}

	public String getPobPlaceofbirth() {
		return this.pobPlaceofbirth;
	}

	public void setPobPlaceofbirth(String pobPlaceofbirth) {
		this.pobPlaceofbirth = pobPlaceofbirth;
	}

	public OfaSdnentry getOfaSdnentry() {
		return ofaSdnentry;
	}

	public void setOfaSdnentry(OfaSdnentry ofaSdnentry) {
		this.ofaSdnentry = ofaSdnentry;
	}

	public Integer getPobId() {
		return pobId;
	}

	public void setPobId(Integer pobId) {
		this.pobId = pobId;
	}

}
