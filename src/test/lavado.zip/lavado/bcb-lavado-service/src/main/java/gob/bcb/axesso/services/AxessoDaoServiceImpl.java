package gob.bcb.axesso.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.jee.axesso.entidades.Password;
import gob.bcb.jee.axesso.entidades.Recurso;
import gob.bcb.jee.axesso.entidades.Usuario;
import gob.bcb.jee.axesso.entidades.UsuarioRol;
import gob.bcb.jee.axesso.entidades.pojo.DatosAuditoria;
import gob.bcb.jee.axesso.excepciones.EntityValidationException; 
import gob.bcb.jee.axesso.excepciones.OperationException;
import gob.bcb.jee.axesso.remoto.PasswordEjbRemoto;
import gob.bcb.jee.axesso.remoto.RecursoEjbRemoto;
import gob.bcb.jee.axesso.remoto.UsuarioEjbRemoto;
import gob.bcb.jee.axesso.remoto.UsuarioRolEjbRemoto;
import gob.bcb.jee.axesso.util.UtilRemoto;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.pojos.GenUsuario;

@Service("axessoDaoService")
public class AxessoDaoServiceImpl implements AxessoDaoService {
	private static final Logger log = LoggerFactory.getLogger(AxessoDaoServiceImpl.class);
	public static int STATUSER_VIGENTE = 1;
	@Autowired
	private AppProperties appProperties;
	private PasswordEjbRemoto passwordEjbRemoto;
	private UsuarioEjbRemoto usuarioEjbRemoto;
	private UsuarioRolEjbRemoto usuarioRolEjbRemoto;
	private RecursoEjbRemoto recursoEjbRemoto;

	// static {
	// passwordEjbRemoto =
	// UtilRemoto.consumirEJBAXESSO(PasswordEjbRemoto.class);
	// usuarioEjbRemoto = UtilRemoto.consumirEJBAXESSO(UsuarioEjbRemoto.class);
	// usuarioRolEjbRemoto =
	// UtilRemoto.consumirEJBAXESSO(UsuarioRolEjbRemoto.class);
	// recursoEjbRemoto = UtilRemoto.consumirEJBAXESSO(RecursoEjbRemoto.class);
	//
	// }
	public AxessoDaoServiceImpl() {
		log.info("creando AxessoDaoServiceImpl...");
		initRemotos();
	}

	public void initRemotos() {
		passwordEjbRemoto = UtilRemoto.consumirEJBAXESSO(PasswordEjbRemoto.class);
		usuarioEjbRemoto = UtilRemoto.consumirEJBAXESSO(UsuarioEjbRemoto.class);
		usuarioRolEjbRemoto = UtilRemoto.consumirEJBAXESSO(UsuarioRolEjbRemoto.class);
		recursoEjbRemoto = UtilRemoto.consumirEJBAXESSO(RecursoEjbRemoto.class);
		log.info("remotos inicializados...");
	}

	public Password findPasswordByLogin(String usrLogin, String password) throws OperationException {
		log.info("findPasswordByLogin usrLogin {}", usrLogin);
		Password passwordEjb = passwordEjbRemoto.getPasswordByLoginAndPassword(usrLogin, password);
		if (passwordEjb != null) {
			log.info("passwordEjb " + passwordEjb.getId().getPasswordId() + " " + passwordEjb.getId().getUsuarioId());
		} else
			log.info("passwordEjb nulooo ");

		return passwordEjb;
	}

	public List<String> recursosLista(Integer idUsuario, String uraCodapp) throws OperationException {
		List<String> parameterMapKeys = new ArrayList();
		Map<String, String> mapaCtrl = new HashMap<String, String>();
		List<UsuarioRol> usuarioRolLista = usuarioRolEjbRemoto.listByUsuarioIdAndAplicaionId(idUsuario, uraCodapp);
		for (UsuarioRol usuarioRol : usuarioRolLista) {
			List<Recurso> recursoList = recursoEjbRemoto.listByRol(usuarioRol.getId().getRolId(), usuarioRol.getId().getAplicacionId());
			for (Recurso recurso : recursoList) {
				if (!mapaCtrl.containsKey(recurso.getId().getRecursoId())) {
					parameterMapKeys.add(recurso.getId().getRecursoId());
					mapaCtrl.put(recurso.getId().getRecursoId(), recurso.getId().getRecursoId());
				}
			}
		}
		return parameterMapKeys;
	}

	public GenUsuario getGenUsuarioFromLogin(String login) throws UsernameNotFoundException {
		String usrLogin = StringUtils.trimToEmpty(login);
		log.info("::> Inicio autenticacion " + usrLogin);
		final String idApplication = appProperties.getIdApplication();

		Usuario usuario = null;
		try {
			usuario = usuarioEjbRemoto.getByLogin(usrLogin);
			log.info("Null?? ===> " + (usuario == null));
			if (usuario == null) {
				throw new UsernameNotFoundException("Usuario " + usrLogin + " inexistente");
			}
		} catch (NullPointerException e) {
			log.error("NullPointerException usuario invalido " + usrLogin);
			throw new UsernameNotFoundException("Usuario inexistente");
		} catch (OperationException e) {
			log.warn("Password invalido " + usrLogin);
			throw new UsernameNotFoundException(e.getMessage());
		}
		Optional<Usuario> usuarioEjb = Optional.of(usuario);
		if (!usuarioEjb.isPresent()) {
			log.warn("Password invalido " + usrLogin);
			throw new UsernameNotFoundException("Password inexistente " + usrLogin);
		}

		List<String> recursos = new ArrayList();
		try {
			recursos = recursosLista(usuario.getId(), idApplication);
		} catch (OperationException e) {
			log.warn("Error al buscar recursos " + usrLogin);
			throw new InsufficientAuthenticationException("Error al buscar recursos " + usrLogin);
		}

		GenUsuario genUsuario = new GenUsuario();
		genUsuario.setUsrLogin(usrLogin);
		// List<String> recursos = rolLista.stream().map(r ->
		// r.getId().getRolId()).collect(Collectors.toList());
		genUsuario.setRecursos(recursos);

		genUsuario.setUsrNombres(StringUtils.trimToEmpty(usuarioEjb.get().getNombres()) + " " + StringUtils.trimToEmpty(usuarioEjb.get().getApellidos()));
		genUsuario.setUsrCoduser(String.valueOf(usuarioEjb.get().getId()));
		genUsuario.setUsrCodemp(usuarioEjb.get().getCodEmpleado());
		genUsuario.setUsrEmail(usuarioEjb.get().getEmail());
		genUsuario.setUsrCodage(Integer.valueOf(usuarioEjb.get().getAgencia().getId()));

		if (StringUtils.isBlank(usuarioEjb.get().getCodEmpleado())) {
			log.error("Usuario " + usrLogin + " sin codigo de empleado en AXESSO!!!");
			throw new InsufficientAuthenticationException("Usuario " + usrLogin + " no tiene registrado codigo de empleado en Axesso, comuníquese con seguridad");
		}

		log.info("==>Credenciales creada usuario " + genUsuario.getUsrLogin() + "[" + genUsuario.getUsrNombres() + "] recursos " + ArrayUtils.toString(genUsuario.getRecursos())
				+ " UsrCodemp " + genUsuario.getUsrCodemp());

		return genUsuario;
	}

	public Password changePassword(String usrLogin, String password, String passwordNew, HttpServletResponse response, HttpServletRequest request)
			throws UsernameNotFoundException {

		log.info("changePassword " + usrLogin);
		Password passwordEjb = null;
		try {
			validar(usrLogin, passwordNew);			
			passwordEjb = passwordEjbRemoto.getPasswordByLoginAndPassword(usrLogin, password);
			if (passwordEjb == null) {
				throw new UsernameNotFoundException("La contraseña anterior no corresponde " + usrLogin);
			}

			DatosAuditoria datosAuditoria = new DatosAuditoria();
			datosAuditoria.setFecha(new Date());
			datosAuditoria.setHost(request.getRemoteAddr());
			datosAuditoria.setUsuario(usrLogin);

			passwordEjbRemoto.asignarPassword(Integer.valueOf(passwordEjb.getId().getUsuarioId()), passwordNew, datosAuditoria, true, false);

			passwordEjb = passwordEjbRemoto.getPasswordByLoginAndPassword(usrLogin, passwordNew);
			if (passwordEjb == null) {
				throw new UsernameNotFoundException("Error al verificar password " + usrLogin);
			}
		} catch (EntityValidationException e) {
			throw new UsernameNotFoundException("Error al cambiar contraseña " + ArrayUtils.toString(e.getFieldErrors()));
		} catch (Exception e) {
			log.error("Error al cambiar password " + e.getMessage(), e);
			throw new UsernameNotFoundException(e.getMessage(), e);
		}

		return passwordEjb;
	}

	public void actualizaIntentos(String username, Integer intentos) throws Exception {
		log.info("actualiza Intentos user {} intentos {}", username, intentos);
		passwordEjbRemoto.actualizaIntentos(username, intentos);
		log.info("Actualizado intentos [{} - {}]", username, intentos);
	}

	public Integer getIntentos(String username) {
		log.info("intentos user {} ", username);
		Integer intentos = passwordEjbRemoto.getIntentos(username);
		log.info("Actualizado intentos [{} - {}]", username, intentos);
		return intentos;
	}

	public boolean loginSuccessAndPasswordChangeRequired(String username) {
		try {
			log.info("loginSuccessAndPasswordChangeRequired user {} ", username);
			actualizaIntentos(username, 0);
			Date fechaVigente = passwordEjbRemoto.getFechaPasswordVigente(username);
			log.info("loginSuccessAndPasswordChangeRequired password vigente {} user {}", fechaVigente, username);
			if (fechaVigente == null)
				return true;
			boolean passChangeRequired = UtilsDate.compara(new Date(), fechaVigente) > 0;

			return passChangeRequired;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new UsernameNotFoundException(e.getMessage());
		}
	}

	public void validar(String usrLogin, String password) throws Exception {
		if (password.length() < 8) {
			throw new UsernameNotFoundException("La contraseña debe contener como mínimo 8 caracteres");
		}
		if (password.toLowerCase().contains(usrLogin.toLowerCase())) {
			throw new UsernameNotFoundException("El password no debe contener el nombre del usuario");
		}
		String upperCaseChars = "(.*[A-Z].*)";
		if (!password.matches(upperCaseChars)) {
			throw new UsernameNotFoundException("La contraseña debe contener al menos una letra mayuscula");
		}
		String lowerCaseChars = "(.*[a-z].*)";
		if (!password.matches(lowerCaseChars)) {
			throw new UsernameNotFoundException("La contraseña debe contener al menos una letra minuscula");
		}
		String numbers = "(.*[0-9].*)";
		if (!password.matches(numbers)) {
			throw new UsernameNotFoundException("La contraseña debe contener al menos un número");
		}
		String specialChars = "(.*[,~,!,@,#,$,%,^,&,*,(,),_,=,+,|,;,:,<,>,/,?,.].*$)";
		if (!password.matches(specialChars) && !password.contains("-")) {
			throw new UsernameNotFoundException("La contraseña debe contener al menos un caracter especial");
		}
//		List<Password> passwords = listPasswordsByUsuarioId(usuario.getId());
//		if (passwords != null) {
//			String passwordCifrado = UtilSeguridad.getHash(password, UtilSeguridad.SHA1).trim();
//			int numPassword = passwords.size() > 8 ? 8 : passwords.size();
//			for (int i = 0; i < numPassword; i++) {
//				if (passwords.get(i).getPassword().trim().equalsIgnoreCase(passwordCifrado)) {
//					throw new UsernameNotFoundException("La contraseña debe ser diferente a las ultimas 8 contraseñas usadas");
//				}
//			}
//		}
		
	}
}
