package gob.bcb.lavado.config;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.aop.interceptor.SimpleAsyncUncaughtExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gob.bcb.lavado.commons.ExceptionHandlingAsyncTaskExecutor;

@Configuration
@EnableAsync
@EnableScheduling
public class AsyncConfiguration implements AsyncConfigurer {

	private final Logger log = LoggerFactory.getLogger(AsyncConfiguration.class);

	@Autowired
	private AppProperties appProperties;
	@Autowired
	private Environment env;
	
	@Override
	@Bean(name = "taskExecutor")
	public Executor getAsyncExecutor() {
		log.info("oooooooooo Creating Async Task Executor oooooooooo.." + (env == null));
		log.info("UUUUUUUUUUUUUUUUUUUUUUUUUUUUU");		
		log.info("server.port : " +  env.getProperty("server.port"));
		log.info("server.port : " +  env.getProperty("spring.server.port"));		
		log.info("server.address: " + env.getProperty("server.address"));
		log.info("server.contextPath: " + env.getProperty("server.contextPath"));
		log.info("spring.application.name: " + env.getProperty("spring.application.name"));		
		log.info("Running with Spring profile(s) : {}", Arrays.toString(env.getActiveProfiles()));
		log.info("Running with spring.config.location: " + env.getProperty("spring.config.location"));
		

		log.info("Creating Async Task Executor " + appProperties.getAsync().getCorePoolSize());
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(appProperties.getAsync().getCorePoolSize());
		executor.setMaxPoolSize(appProperties.getAsync().getMaxPoolSize());
		executor.setQueueCapacity(appProperties.getAsync().getQueueCapacity());
		executor.setThreadNamePrefix("lavado-Executor-");
		return new ExceptionHandlingAsyncTaskExecutor(executor);
	}

	@Override
	public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
		return new SimpleAsyncUncaughtExceptionHandler();
	}

	@Bean(name = "taskScheduler")
	public TaskScheduler scheduler() {
		log.info("oooooooooo Creating Task Scheduler oooooooooo");
		ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
		taskScheduler.setPoolSize(5);
		taskScheduler.setThreadNamePrefix("ThreadPoolTaskScheduler-");
		return taskScheduler;
	}

	@Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        log.info("Configurando rest templateeeeeeeeeeeeee");
        // Configurar ObjectMapper con UTF-8
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(JsonGenerator.Feature.ESCAPE_NON_ASCII, false);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        
        // Convertidores
        List<HttpMessageConverter<?>> converters = new ArrayList<>();
        
        StringHttpMessageConverter stringConverter = 
            new StringHttpMessageConverter(StandardCharsets.UTF_8);
        converters.add(stringConverter);
        
        MappingJackson2HttpMessageConverter jsonConverter = 
            new MappingJackson2HttpMessageConverter(mapper);
        jsonConverter.setDefaultCharset(StandardCharsets.UTF_8);
        converters.add(jsonConverter);
        
        restTemplate.setMessageConverters(converters);
        
        return restTemplate;
    }	
}
