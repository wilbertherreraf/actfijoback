package gob.bcb.lavado.lavadoclient;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.translate.FormatEngine;
import gob.bcb.lavado.client.ClienteLvd;
import gob.bcb.lavado.client.HandlerGeneratorLauCli;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.services.SessionsSearcherService;

public class ClienteLvdMxTest {
	protected final static Logger log = LoggerFactory.getLogger(ClienteLvdMxTest.class);
	private String url = "http://10.3.11.82:8881/lavado/";
	ClienteLvd clienteLvd;
	@Autowired
	private SessionsSearcherService sessionsSearcherService;

//	@Test
	public void happyDayCompletCycleOneTest() throws Exception {
		String codApp = "TESTX02";
		log.info("=== registroNoObservadoConCorrelativoSolicitadoTest " + url);
		clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", codApp);
		String archSwift = "src/test/resources/swifts/m1875.dos"; // src/test/resources/swifts/swf_sinobservacion.dos
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		SearchResponse searchResponse = clienteLvd.getIniSessionLavado(codApp, "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);
		String codigo = String.valueOf(System.currentTimeMillis()).substring(8);

		searchResponse = clienteLvd.solicitarCorrelativo(codApp, codigo, "usertest", idsession);

		Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
		log.info("ANTES DE SCAM " + idsession + " Operacion " + menCodmen);
		searchResponse = clienteLvd.scanSwiftRegistro(codApp, "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(),
				codigo, idsession, menPlano);

		searchResponse = clienteLvd.postSessionLavado(codApp, "usertest", idsession);
	}

//	@Test
	public void happyDayCompletCycleTest() throws Exception {
		String codApp = "TESTX02";
		for (int i = 1; i < 2; i++) {
			log.info("=== registroNoObservadoConCorrelativoSolicitadoTest " + url);
			clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", codApp);
			String archSwift = "src/test/resources/mx/pacs008cli.xml"; // src/test/resources/swifts/swf_sinobservacion.dos
			String menPlano = UtilsFile.readFileAsString2(archSwift);

			SearchResponse searchResponse = clienteLvd.getIniSessionLavado(codApp, "usertest");
			String idsession = searchResponse.getCodoperacion();
			log.info("SESSION LAVADO " + idsession);
			String codigo = String.valueOf(System.currentTimeMillis()).substring(8);

			searchResponse = clienteLvd.solicitarCorrelativo(codApp, codigo, "usertest", idsession);
			Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
			Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(0) > 0);
			Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);

			Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
			log.info("ANTES DE SCAM " + idsession + " Operacion " + menCodmen);
			searchResponse = clienteLvd.scanSwiftRegistro(codApp, "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(),
					codigo, idsession, menPlano);

			Assert.assertNotNull("searchResponse nulo", searchResponse);
			Assert.assertTrue("Cod swift debe diferente de nulo", !StringUtils.isBlank(searchResponse.getCodoperacion()));
			Assert.assertTrue("Cod swift debe ser mayor a cero", Integer.valueOf(searchResponse.getCodoperacion()).compareTo(menCodmen) == 0);
			Assert.assertTrue("Correlativo debe ser mayor a cero", searchResponse.getNrocorr().compareTo(0) > 0);
			String menPlanoN = searchResponse.getMenPlano();
			log.info("ANTES DE PREAUTO " + idsession);

			SwiftMessageAbstract sma = FactoryParser.createParser(menPlanoN);
			String menPlanoS = sma.getMenPlano();
			// HandlerGeneratorLauCli.getCurrentInstanceHGenCli().

			searchResponse = clienteLvd.preautorizarSwift(codApp, "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(),
					codigo, idsession, menPlanoN);

			searchResponse = clienteLvd.postSessionLavado(codApp, "usertest", idsession);
			Assert.assertTrue("Registros actualizados debe ser >0", searchResponse.getCountRegs().compareTo(0) > 0);
			Assert.assertTrue("Cod de respuesta invalida", searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO));

		}
	}

	// @Test
	public void testConcurrentTest2() throws Exception {
		log.info("!!!!!!!!!!!!!!!!!! [ INICIO CONCURRENCIA ] !!!!!!!!!!!!!!!!!!");
		AtomicInteger ai = new AtomicInteger();
		ai.set(0);
		String codApp = "SIOCWEB";
		Stream<CompletableFuture<Integer>> futureWrite = UtilsFile.filesDir("src/test/resources/concu").stream().map(f -> {
			return CompletableFuture.supplyAsync(() -> {
				try {
					String nFile = f.getName();
					int item = ai.addAndGet(1);
					log.info("=== " + nFile + " =============");

					String idApp = codApp + item;
					ClienteLvd clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", idApp);
					String archSwift = f.getAbsolutePath();
					String menPlano = UtilsFile.readFileAsString2(archSwift);
					String idoperacion = String.valueOf(System.nanoTime());
					menPlano = menPlano.replace("04054727", idoperacion);

					SearchResponse searchResponse = clienteLvd.getIniSessionLavado(idApp, "usertest");
					String idsession = searchResponse.getCodoperacion();

					String codigo = String.valueOf(System.currentTimeMillis()).substring(8) + item;
					log.info(codigo + " -> SESSION LAVADO " + idsession);
					searchResponse = clienteLvd.solicitarCorrelativo(idApp, codigo, "usertest", idsession);

					Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
					Integer nrocorr = searchResponse.getNrocorr();
					searchResponse = clienteLvd.postSessionLavado(idApp, "usertest", idsession);

					log.info("********** {" + item + "} ********************** " + menCodmen + " " + nrocorr, item);
					searchResponse = clienteLvd.getIniSessionLavado(idApp, "usertest");
					idsession = searchResponse.getCodoperacion();

					log.info("**********1111111111111111{" + item + "}111111111111********************** " + menCodmen + " Nrocorr: " + nrocorr
							+ " idsession: " + idsession);

					searchResponse = clienteLvd.scanSwiftRegistro(idApp, "usertest", menCodmen, nrocorr, codigo, idsession, menPlano);

					searchResponse = clienteLvd.postSessionLavado(idApp, "usertest", idsession);
					log.info("**********222222222222222{" + item + "}22222222222222**********************");
					searchResponse = clienteLvd.getIniSessionLavado(idApp, "usertest");
					idsession = searchResponse.getCodoperacion();

					searchResponse = clienteLvd.preautorizarSwift(idApp, "usertest", menCodmen, nrocorr, codigo, idsession, menPlano);

					searchResponse = clienteLvd.postSessionLavado(idApp, "usertest", idsession);
					log.info("FFFFFin {" + item + "} FFFFFFIN");
					return item;
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			});
		});

		List<CompletableFuture<Integer>> priceFutures = futureWrite.collect(Collectors.<CompletableFuture<Integer>>toList());

		log.info("-------------IIIIIIIIII------------------- ");
		priceFutures.stream().map(CompletableFuture::join).count();// collect(Collectors.toList());
	}

//	@Test
	public void completeCycleMasiveTest() {
		String codApp = "TESTPERF0";
		log.info("=== testMasivoTest Request URL " + url);
		String inputDirectory = "e:/wil/projects/lavado/datos/mts20212022";
		int count = 0;
		int observ = 0;
		ClienteLvd clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", codApp);
		SearchResponse searchResponse;
		try {
			searchResponse = clienteLvd.getIniSessionLavado(codApp, "usertest");
		} catch (Exception e1) {
			throw new RuntimeException(e1);
		}

		String idsession = searchResponse.getCodoperacion();

		for (File f : UtilsFile.filesDir(inputDirectory)) {
			long startTime = System.currentTimeMillis();
			count++;
			log.info("------[{}] {}-------", count, f.getName());
			String archSwift = f.getAbsolutePath();

			try {
				String menPlano = UtilsFile.readFileAsString2(archSwift);

				// SearchResponse searchResponse = clienteLvd.getIniSessionLavado(codApp,
				// "usertest");

				// log.info("SESSION LAVADO " + idsession);
				String codigo = String.format("%04d", count) + String.valueOf(System.currentTimeMillis()).substring(8);

				searchResponse = clienteLvd.solicitarCorrelativo(codApp, codigo, "usertest", idsession);

				Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
				// log.info("ANTES DE SCAM " + idsession + " Operacion " + menCodmen);
				searchResponse = clienteLvd.scanSwiftRegistro(codApp, "usertest", menCodmen, searchResponse.getNrocorr(), codigo, idsession, menPlano);

				log.info("==>>>>> {}: Countregs: {}, {}/{} cod: {}, descr: {} at[{}]", count, searchResponse.getCountRegs(), observ, count,
						searchResponse.getCodResp(), searchResponse.getDescripResp(), (System.currentTimeMillis() - startTime));

				if (searchResponse.getCountRegs().compareTo(0) > 0 && searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_01)) {
					log.info("\nObservado: {}\t{}", menCodmen, f.getName());
					observ++;
				} else if (searchResponse.getCountRegs().compareTo(0) > 0 || !searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
					log.info("\nERROR EN LAVADO: {}\t{}", menCodmen, f.getName());
				}
//				searchResponse = clienteLvd.preautorizarSwift(codApp, "usertest", Integer.valueOf(searchResponse.getCodoperacion()),
//						searchResponse.getNrocorr(), codigo, idsession, menPlanoN);
//	
				if (count > 1) {
					break;
				}
			} catch (Exception e) {
				log.error("Error " + e.getMessage());
			}
		}

		try {
			clienteLvd.postSessionLavado(codApp, "usertest", idsession);
		} catch (Exception e) {
			log.error("Error " + e.getMessage());
		}
	}

	@Test
	public void completeCycleMasiveParTest() {
		log.info("!!!!!!!!!!!!!!!!!! [ INICIO CONCURRENCIA ] !!!!!!!!!!!!!!!!!!");
		AtomicInteger ai = new AtomicInteger();
		ai.set(0);
		AtomicInteger aioberv = new AtomicInteger();
		aioberv.set(0);

		AtomicInteger aierr = new AtomicInteger();
		aierr.set(0);
		String codApp = "TESTPERF";
		log.info("=== testMasivoTest Request URL " + url);
		String inputDirectory = "e:/wil/projects/lavado/datos/mts20212022cmp";

		ClienteLvd clienteLvd = ClienteLvd.init(url, "/opt/aplicaciones/lavado", codApp);
		SearchResponse searchResponse1;
		try {
			searchResponse1 = clienteLvd.getIniSessionLavado(codApp, "usertest");
		} catch (Exception e1) {
			throw new RuntimeException(e1);
		}

		String idsession = searchResponse1.getCodoperacion();

		Stream<CompletableFuture<Integer>> futureWrite = UtilsFile.filesDir(inputDirectory).stream().map(f -> {
			return CompletableFuture.supplyAsync(() -> {
				int errors = aierr.get();
				try {
					String nFile = f.getName();
					int item = ai.addAndGet(1);

					if (errors > 5) {
						// return item;
					}

					int observ = aioberv.get();
					log.info("------[{}] {}-------", item, nFile);

					long startTime = System.currentTimeMillis();
					String archSwift = f.getAbsolutePath();

					try {
						final String menPlano = UtilsFile.readFileAsString2(archSwift);
						String codigo = String.format("%04d", item) + String.valueOf(System.currentTimeMillis()).substring(8);

						SearchResponse searchResponse = clienteLvd.solicitarCorrelativo(codApp, codigo, "usertest", idsession);

						Integer menCodmen = Integer.valueOf(searchResponse.getCodoperacion());
						SearchResponse searchResponse2 = clienteLvd.scanSwiftRegistro(codApp, "usertest", menCodmen, searchResponse.getNrocorr(), codigo,
								idsession, menPlano);

						log.info("==>>>>> {}: Countregs: {}, {}/{} cod: {}, descr: {} at[{}]", item, searchResponse2.getCountRegs(), observ, item,
								searchResponse2.getCodResp(), searchResponse2.getDescripResp(), (System.currentTimeMillis() - startTime));

						if (searchResponse2.getCountRegs().compareTo(0) > 0 && searchResponse2.getCodResp().equals(Constants.COD_RESP_ERR_01)) {
							log.info("\nObservado: {}\t{}", menCodmen, f.getName());
							aioberv.addAndGet(1);
						} else if (searchResponse2.getCountRegs().compareTo(0) > 0 || !searchResponse2.getCodResp().equals(Constants.COD_RESP_EXITO)) {
							log.info("\nERROR EN LAVADO: {}\t{}", menCodmen, f.getName());
							aierr.addAndGet(1);
						}
					} catch (Exception e) {
						log.error("Error " + e.getMessage());
					}
					return item; 
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			});
		});

		List<CompletableFuture<Integer>> priceFutures = futureWrite.collect(Collectors.<CompletableFuture<Integer>>toList());

		log.info("-------------IIIIIIIIII------------------- ");
		priceFutures.stream().map(m -> {
			try {
				log.info("En comple {} ", m.get());
			} catch (Exception e) {
				log.error("error cople " + e.getMessage());
			}
			return m;
		}).map(CompletableFuture::join).count();// collect(Collectors.toList());

		try {
			clienteLvd.postSessionLavado(codApp, "usertest", idsession);
		} catch (Exception e) {
			log.error("Error " + e.getMessage());
		}
	}

	public void recolectFields2() throws Exception {
		log.info("!!!!!!!!!!!!!!!!!! [ INICIO CONCURRENCIA ] !!!!!!!!!!!!!!!!!!");
		AtomicInteger ai = new AtomicInteger();
		ai.set(0);
		String codApp = "SIOCWEB";
		UtilsFile.filesDir("src/test/resources/concu").stream().forEach(f -> {
			try {
				String nFile = f.getName(); 
				String mtFile = UtilsFile.readFileAsString2(nFile);
				log.info("=== " + nFile + " =============");
				SwiftMessageAbstract sma = FactoryParser.createParser(mtFile);
				

			} catch (Exception e) {
				log.error("Error " + e.getMessage());
			}			
		}) ;
	}
}
