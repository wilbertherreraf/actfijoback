package gob.bcb.lavado.services;

import org.apache.commons.codec.binary.Base64;
import java.util.Date;
import java.util.Map;

import javax.crypto.spec.SecretKeySpec;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.iso20022.lau.AuthParameters;
import gob.bcb.iso20022.lau.LAU;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.swift.saa.xmldsig.SignatureType;
import gob.bcb.iso20022.utils.UtilsFile;
import gob.bcb.lavado.client.lau.GeneratorLAU;
import gob.bcb.lavado.client.utils.UtilsSec;
import gob.bcb.swift.pojos.SwiftDatos;

public class OpersLAUTest {
	private static final Logger log = LoggerFactory.getLogger(OpersLAUTest.class);

	//@Test
	public void smaUpdLAUTest() {
		try {
			String nfile = "src/test/resources/mx/pacsaa.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menplano);
			SwiftMessageAbstract sm = swiftDatos.getSwiftMessageAbs();
			
			log.info("***********Orig****************");
			log.info(sm.getMenPlano());
			sm.updMsgForSign();
		
			GeneratorLAU genLau = loadGeneratorLAU();
			
			AuthParameters authParameters = new AuthParameters((SecretKeySpec) genLau.getKeyMac());
			sm.addBlockLAU(authParameters);
			log.info("+++++++++ with LAU++++++++++");
			log.info(sm.getMenPlano());
			log.info("hash : " + sm.getSwfMsgParam().getMenHash());
			UtilsFile.grabaEnArchivo2(sm.getMenPlano(), "e:/tmp/pacsigned.xml");
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
	
//	@Test
	public void smaUpdMsgLAUTest() {
		try {
			String nfile = "src/test/resources/mx/pacsaa.xml"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menplano);
			SwiftMessageAbstract sm = swiftDatos.getSwiftMessageAbs();
			
			log.info("***********Orig****************");
			log.info(sm.getMenPlano());
			sm.updMsgForSign();

			DataPDU pdu = sm.getdPDUWriter().getDataPDU();
			pdu.getHeader().getMessage().getInterfaceInfo().setServiceURI("mp/mx/__mRWkJI2EeuXfsXXXXXX");
			pdu.getHeader().getMessage().getInterfaceInfo().setMessageTypeURI("mp/mx/__mRWkJI2EeuXfsPBlWnVxg/__mSksJI2EeuXfsPBlWnVxg");
			pdu.getHeader().getMessage().getNetworkInfo().setService("swift.finplus");
			pdu.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo().setRequestSubtype("swift.cbprplus.02");
			
			GeneratorLAU genLau = loadGeneratorLAU();
			
			AuthParameters authParameters = new AuthParameters((SecretKeySpec) genLau.getKeyMac());
			sm.addBlockLAU(authParameters);
			log.info("+++++++++ with LAU++++++++++");
			log.info(sm.getMenPlano());
			log.info("hash : " + sm.getSwfMsgParam().getMenHash());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}	

	@Test
	public void smaUpdWithSignedTest() {
		try {
			String parValor = "QUF7WFtaWVpTNUhofnxxTjhJSFF9NFdRfDR9UX00fl1xfHFOe1FYVDZWS2ZxUUlSSk5ZU0ZONFJKUjRRbVZbU25KWFR7UkxmcU1vVX5dW1FIWm5WbV5JU0teW1VwUllUe15LZg==";
			String ctrldt = UtilsSec.easeyDecrypt(new String(Base64.decodeBase64(parValor)));
			Map<String, String> map = UtilsGeneric.paramsLista(ctrldt);

			String lauKeyFP = map.get("lfp");
			String lauKeySP = map.get("lsp");
			
			log.info("======== inicio smaUpdWithSignedTest====================== " + lauKeyFP + " : " + lauKeySP);
			String nfile = "src/test/resources/mx/pacsigned.xml";
			String menplano = UtilsFile.readFileAsString2(nfile);
			
			SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menplano);
			SwiftMessageAbstract sm = swiftDatos.getSwiftMessageAbs();
			
			log.info("***********Orig****************");
			log.info(sm.getMenPlanoOrig());
			sm.updMsgForSign();
			LAU signer = new LAU();
			SignatureType s = signer.extractSignature(menplano);
			String dv = s.getSignedInfo().getReference().get(0).digestValue();
			log.info("hash : " + s.getSignatureValue().value() + " dv:" + dv);
			
			
//			GeneratorLAU genLau = loadGeneratorLAU();
//			
//			AuthParameters authParameters = new AuthParameters((SecretKeySpec) genLau.getKeyMac());
//			sm.addBlockLAU(authParameters);
//			log.info("+++++++++ with LAU++++++++++");
//			log.info(sm.getMenPlano());
//			log.info("hash : " + sm.getSwfMsgParam().getMenHash());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}	
	//@Test
	public void initGeneratorLAU() {
		try {
			log.info("============initGeneratorLAU=============");
			String phraseCommons = "secret phrase!";
			String codeKeyFP = "Abcd1234abcd1234";
			String codeKeySP = "Abcd1234abcd1234";

			GeneratorLAU generatorLAU = new GeneratorLAU("/opt/aplicaciones/lavado", "testlvd");
			generatorLAU.loadGeneratorLau(true);

			generatorLAU.updateCodeLau(codeKeyFP, codeKeySP, 90, new Date(), "", "codUsuario", "estacion", false);

			String phraseCommonslau = generatorLAU.signLau(phraseCommons);
			log.info("signed: " + phraseCommonslau);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	public GeneratorLAU loadGeneratorLAU() {
		try {
			String codeKeyFP = "Abcd1234abcd1234";
			String codeKeySP = "Abcd1234abcd1234";

			GeneratorLAU generatorLAU = new GeneratorLAU("/opt/aplicaciones/lavado", "testlvd");
			generatorLAU.loadGeneratorLau(true);

			generatorLAU.updateCodeLau(codeKeyFP, codeKeySP, 90, new Date(), "", "codUsuario", "estacion", false);
			return generatorLAU;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
		return null;
	}
}
