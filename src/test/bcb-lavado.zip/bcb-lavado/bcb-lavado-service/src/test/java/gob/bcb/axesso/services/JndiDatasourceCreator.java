package gob.bcb.axesso.services;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.commons.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;

public class JndiDatasourceCreator {
	private static final Logger log = LoggerFactory.getLogger(JndiDatasourceCreator.class);

	private static final String jndiName = "java:jboss/datasources/axessoDS";
	private static final String driverClassName = "com.informix.jdbc.IfxDriver";
	public static BasicDataSource dataSource;
	public static BasicDataSource dataSourceLvd;	
	public static Context context;
	
	public static void create(String username, String password, String url) throws Exception {
		try {
			final SimpleNamingContextBuilder builder = new SimpleNamingContextBuilder();
			dataSource = new BasicDataSource();
			dataSource.setUsername(username);
			dataSource.setPassword(password);
			dataSource.setDriverClassName(driverClassName);
			dataSource.setUrl(url);
			builder.bind(jndiName, dataSource);
			builder.activate();
		} catch (NamingException ex) {
			log.info(ex.getMessage());
		}
	}
	public static void createJndiMock(String username, String password, String url, String jndi) throws Exception {
		try {
			final SimpleNamingContextBuilder builder = new SimpleNamingContextBuilder();
			dataSourceLvd = new BasicDataSource();
			dataSourceLvd.setUsername(username);
			dataSourceLvd.setPassword(password);
			dataSourceLvd.setDriverClassName(driverClassName);
			dataSourceLvd.setUrl(url);
			builder.bind(jndi, dataSourceLvd);
			builder.activate();
			if (context == null)
				context = new InitialContext();
		    context.rebind(jndi,dataSourceLvd);

		} catch (NamingException ex) {
			log.info(ex.getMessage());
			throw ex;
		}
	}	
}
