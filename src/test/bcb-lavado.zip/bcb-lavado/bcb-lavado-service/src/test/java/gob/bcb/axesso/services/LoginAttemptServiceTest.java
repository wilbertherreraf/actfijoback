package gob.bcb.axesso.services;

import java.util.ArrayList;
import java.util.List;

//public class LoginAttemptServiceTest extends ConfigBaseTest {
public class LoginAttemptServiceTest {
	// private static final Logger log =
	// LoggerFactory.getLogger(LoginAttemptServiceTest.class);
	// //@Autowired
	// private LoginAttemptService loginAttemptService;
	// //@Autowired
	// private AxessoDaoService axessoDaoService;
	// //@Test
	// public void loginSucceededTest(){
	// log.info("loginSucceededTest");
	// boolean req = loginAttemptService.loginSucceeded("demooper");
	//
	// log.info("resp " + req);
	// }
	// //@Test
	// public void loginFailedTest(){
	// log.info("loginFailedTest");
	// loginAttemptService.init(3);
	// loginAttemptService.loginFailed("demooper");
	// log.info("intentos isBlocked " +
	// loginAttemptService.isBlocked("demooper"));
	// loginAttemptService.loginFailed("demooper");
	// log.info("intentos isBlocked " +
	// loginAttemptService.isBlocked("demooper"));
	// loginAttemptService.loginFailed("demooper");
	// Optional<AxsPasswords> axsPasswordOptOld =
	// axessoDaoService.findPasswordByLogin("demooper");
	// log.info("intentos " + axsPasswordOptOld.get().getPswIntfallpassw() + " "
	// + loginAttemptService.isBlocked("demooper"));
	// loginAttemptService.loginFailed("demooper");
	// log.info("=============================");
	// axsPasswordOptOld = axessoDaoService.findPasswordByLogin("demooper");
	// log.info("intentos " + axsPasswordOptOld.get().getPswIntfallpassw() + " "
	// + loginAttemptService.isBlocked("demooper"));
	//
	// try {
	// log.info("======== zzZZzZZzzzZZ =====================");
	// TimeUnit.SECONDS.sleep(5);
	// } catch (InterruptedException e) {
	// log.error("Exception thrown while sleeping in between runs of the scan
	// cleanup thread ", e);
	// }
	// log.info("intentos " + axsPasswordOptOld.get().getPswIntfallpassw() + " "
	// + loginAttemptService.isBlocked("demooper"));
	// }

	public void validar(String password) {
		List<String> errores = new ArrayList<String>();
		if (password.length() < 8) {
			errores.add("La contraseña debe contener como mínimo 8 caracteres");
		}
		String upperCaseChars = "(.*[A-Z].*)";
		if (!password.matches(upperCaseChars)) {
			errores.add("La contraseña debe contener al menos una letra mayuscula");
		}
		String lowerCaseChars = "(.*[a-z].*)";
		if (!password.matches(lowerCaseChars)) {
			errores.add("La contraseña debe contener al menos una letra minuscula");
		}
		String numbers = "(.*[0-9].*)";
		if (!password.matches(numbers)) {
			errores.add("La contraseña debe contener al menos un número");
		}
		String specialChars = "(.*[,~,!,@,#,$,%,^,&,*,(,),_,=,+,|,;,:,<,>,/,?,.].*$)";
		if (!password.matches(specialChars) && !password.contains("-")) {
			errores.add("La contraseña debe contener al menos un caracter especial");
		}
	}
	
	public static void main(String[] args) {
		String password = "Central.123";
		List<String> errores = new ArrayList<String>();
		if (password.length() < 8) {
			errores.add("La contraseña debe contener como mínimo 8 caracteres");
		}
		String upperCaseChars = "(.*[A-Z].*)";
		if (!password.matches(upperCaseChars)) {
			errores.add("La contraseña debe contener al menos una letra mayuscula");
		}
		String lowerCaseChars = "(.*[a-z].*)";
		if (!password.matches(lowerCaseChars)) {
			errores.add("La contraseña debe contener al menos una letra minuscula");
		}
		String numbers = "(.*[0-9].*)";
		if (!password.matches(numbers)) {
			errores.add("La contraseña debe contener al menos un número");
		}
		String specialChars = "(.*[,~,!,@,#,$,%,^,&,*,(,),_,=,+,|,;,:,<,>,/,?,.].*$)";
		if (!password.matches(specialChars) && !password.contains("-")) {
			errores.add("La contraseña debe contener al menos un caracter especial");
		}
		System.out.println(errores.size());
	}
}
