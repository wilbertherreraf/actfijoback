package gob.bcb.lavado.services;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;

import gob.bcb.core.utils.UtilsFile;

public class GenLau {
	private static final String HMAC_SHA256 = "HmacSHA256";
	private static final String GENERATED_EXT = ".generated";
	private static final String LAU_EXT = ".lau";
	private static final int XMLV2_PDU_START = 0x3C; //0x1f; // 0x3C
	private static final int XMLV2_SIG_OFFSET = 7;
	private static final int XMLV2_ENCODED_SIG_LEN = 24;
	private static final int XMLV2_PRELUDE_LEN = 0; //31; //0
	private static final int XMLV2_SIG_LEN = 32; //16;
	private static final int BYTE_BUFFER_SIZE = 10000;
	private static final int LAU_KEY_MIN_CHARS = 17;
	private static final int LAU_KEY_MAX_CHARS = 32;
	private boolean mXmlV2;
	private boolean mDigest;
	private boolean mValidate;
	private SecretKeySpec mKey;
	private String[] mFiles;

	public void run(String[] pArgs) throws Exception {
		for (int i = 0; i < pArgs.length; i++) {
			if ("-digest".equals(pArgs[i])) {
				mDigest = true;
			} else if ("-validate".equals(pArgs[i])) {
				mValidate = true;
			} else if ("-xmlv2".equals(pArgs[i])) {
				mXmlV2 = true;
			} else if ("-key".equals(pArgs[i])) {
				mKey = getKey(pArgs[++i]);
			} else {
				// out of named args, rest are files
				mFiles = Arrays.copyOfRange(pArgs, i, pArgs.length);
				break;
			}
		}

		if (mDigest && mXmlV2) {
			System.out.println("-digest and -xmlv2 options cannot be specified together");
			usage();
		}

		if (!mDigest && (mKey == null)) {
			System.out.println("-key option must be specified to sign or validate");
			usage();
		}

		if (mDigest) {
			digest();
		} else if (mValidate) {
			if (!mXmlV2 && mFiles.length != 2) {
				System.out.println("-validate option without -xmlv2 requires exactly two files");
				usage();
			}
			validate();
		} else {
			sign();
		}
	}

	// useful for unit test
	void setKey(SecretKeySpec pKey) {
		mKey = pKey;
	}

	// @SuppressFBWarnings(value = "DM_EXIT", justification = "Exit on incorrect
	// usage is OK for a utility here")
	SecretKeySpec getKey(String pEncodedKey) throws Exception {
		final byte[] key = new byte[LAU_KEY_MAX_CHARS];
		if (pEncodedKey.length() > LAU_KEY_MAX_CHARS || pEncodedKey.length() < LAU_KEY_MIN_CHARS) {
			System.out.println(String.format("LAU key must be between %d and %d characters in length", LAU_KEY_MIN_CHARS, LAU_KEY_MAX_CHARS));
			System.exit(-1);
		} else {
			Arrays.fill(key, (byte) 0);
			System.arraycopy(pEncodedKey.getBytes(StandardCharsets.UTF_8), 0, key, 0, pEncodedKey.getBytes(StandardCharsets.UTF_8).length);
		}
		return new SecretKeySpec(key, HMAC_SHA256);
	}

	// displays a SHA256 digest for every named file on the command line
	protected void digest() throws Exception {
		for (String s : mFiles) {
			try (InputStream in = new FileInputStream(s)) {
				final byte[] hash = DigestUtils.sha256(in);
				System.out.println("Base64 SHA-256 for " + s + ": " + Base64.encodeBase64String(hash));
			}
		}
	}

	// validates the LAU for a file
	protected void validate() throws Exception {
		if (mXmlV2) {
			validateXmlv2();
		} else {
			validateNormalFile();
		}

	}

	// validation of normal file (e.g. RJE) just compares HMAC 256 calculated
	// over content bytestream
	// @SuppressFBWarnings(value = "DM_EXIT", justification = "Exit on incorrect
	// usage is OK here")
	protected void validateNormalFile() throws Exception {
		final Mac mac = Mac.getInstance(HMAC_SHA256);
		mac.init(mKey);
		final byte[] expected;
		try (InputStream in = new FileInputStream(mFiles[0])) {
			expected = Base64.encodeBase64(sign(in));
		}
		try (InputStream in = new FileInputStream(mFiles[1])) {
			final byte[] given = IOUtils.toByteArray(in);
			if (Arrays.equals(expected, given)) {
				System.out.println("LAU is correct");
			} else {
				System.out.println("LAU is incorrect. Expected: " + expected);
				System.exit(1);
			}
		}
	}

	// validation of XmlV2 files
	// @SuppressFBWarnings(value = "DM_EXIT", justification = "Exit on incorrect
	// usage is OK here")
	protected void validateXmlv2() throws Exception {
		for (String s : mFiles) {
			try (InputStream in = new FileInputStream(s)) {
				final byte[] content = IOUtils.toByteArray(in);
				final byte[] signed = signXmlV2(content);
				if (!Arrays.equals(content, signed)) {
					System.out.println("LAU for " + s + " is incorrect");
					System.exit(1);
				} else {
					System.out.println("LAU for " + s + " is correct");
				}
			}
		}
	}

	// sign the required files (generate either '.lau' for regular file or
	// '.generated' copy for Xmlv2)
	protected void sign() throws Exception {
		System.out.println("ini sign ");
		for (String s : mFiles) {
			final Mac mac = Mac.getInstance(HMAC_SHA256);
			mac.init(mKey);
			try (InputStream in = new FileInputStream(s)) {
				if (mXmlV2) {
					final byte[] content = IOUtils.toByteArray(in);
					if (content[0] == 0x3C) {
						System.out.println("firmando xml " + 0x1F+ " : " + 0x3C + " :: " + 0x1f + " - " + Byte.toString(content[0]));
						
						processXmlV2File(content, s);
					} else {
						System.out.println("Files must start 0x1F if option '-xmlv2' is specified 0x1f:: " + 0x1F+ " :: " + 0x3C + " :: " + content[0] + "' "  + (new String(content, StandardCharsets.UTF_8) ));
					}
				} else {
					processRegularFile(in, s);
				}
			}
		}
	}

	private void processXmlV2File(byte[] pContent, String pFileName) throws GeneralSecurityException, IOException {
		try (FileOutputStream out = new FileOutputStream(pFileName + GENERATED_EXT)) {
			out.write(signXmlV2(pContent));
		}
	}

	private byte[] signXmlV2(byte[] pContent) throws GeneralSecurityException {
		final byte[] signedContent = Arrays.copyOf(pContent, pContent.length);
		int start = 0;
		int end = 0;
		 String s = new String(signedContent, StandardCharsets.UTF_8);
		 System.out.println("ssss " + s.substring(0, 50));
		do {
			end = findPduEnd(signedContent, start);
			final byte[] signableContent = Arrays.copyOfRange(signedContent, start + XMLV2_PRELUDE_LEN, end); // 31
			s = new String(signableContent, StandardCharsets.UTF_8);
			System.out.println(start + " : " + end + "] <-- signableContent ::> " + s);
			
			final byte[] sig = sign(signableContent);
			// XMLv2 signatures are truncated in the PDU.
			s = DatatypeConverter.printHexBinary(sig);
			
			System.out.println("sig ::> " + s + " ::> " + DatatypeConverter.printBase64Binary(sig));			
			final byte[] truncated = Base64.encodeBase64(Arrays.copyOf(sig, XMLV2_SIG_LEN)); //16
			s = new String(truncated, StandardCharsets.UTF_8);
			System.out.println("truncated ::> " + s);
			for (int i = start; i < XMLV2_ENCODED_SIG_LEN; i++) { // 24
				signedContent[i + XMLV2_SIG_OFFSET] = truncated[i]; // 7
				s = new String(signedContent, StandardCharsets.UTF_8);
				System.out.println("------> signedContent ::> " + s);
			}
			System.out.println("************************" + start + " end ::> " + end + " " + signedContent.length);
			s = new String(signedContent, StandardCharsets.UTF_8);
			System.out.println(end + " ::< signedContent end ::> " + s);
			start = end;
			
		} while (end < signedContent.length);

		return signedContent;
	}

	private int findPduEnd(byte[] pContent, int pStartFrom) {
		for (int i = pStartFrom + 1; i < pContent.length; i++) {
			if (pContent[i] == (byte) XMLV2_PDU_START) {
				System.out.println("lenf content : " + pContent.length + " i: " + i);
				return i;
			}
		}
		System.out.println("lenf content2 : " + pContent.length);		
		return pContent.length;
	}

	private void processRegularFile(InputStream pContent, String pFileName) throws GeneralSecurityException, IOException {
		System.out.println("ini RegularFile ");
		try (FileOutputStream out = new FileOutputStream(pFileName + LAU_EXT)) {
			out.write(Base64.encodeBase64(sign(pContent)));
		}
	}

	// in memory version
	byte[] sign(byte[] pContent) throws GeneralSecurityException {
		final Mac mac = Mac.getInstance(HMAC_SHA256);
		mac.init(mKey);
		return mac.doFinal(pContent);
	}

	// uses an underlying buffer for large amounts of data
	byte[] sign(InputStream pContent) throws GeneralSecurityException, IOException {
		final Mac mac = Mac.getInstance(HMAC_SHA256);
		mac.init(mKey);
		final byte[] buffer = new byte[BYTE_BUFFER_SIZE];
		int len = pContent.read(buffer);
		while (len > 0) {
			mac.update(buffer, 0, len);
			len = pContent.read(buffer);
		}
		return mac.doFinal();
	}

	// CHECKSTYLE:OFF main app
	public static void main(String[] pArgs) throws InvalidKeyException, NoSuchAlgorithmException {
		// CHECKSTYLE:OFF
		int i = 0;
		String[] a = new String[4];
		a[0] = "-key";
		a[1] = "Abcd1234abcd1234Abcd1234abcd1234";
		a[2] = "-xmlv2";
		//a[3] = "e:/tmp/samplesaa.xml";		
		a[3] = "e:/tmp/siginfo.xml";
		if (a.length < 2) {
			usage();
		} else {
			try {
				System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
				new GenLau().run(a);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		main00();
		String k= "Abcd1234abcd1234Abcd1234abcd1234";
	    String m = UtilsFile.readFileAsString2("e:/tmp/siginfo.xml");
	    System.out.println("digest file=> " + hmacDigest(m, k, HMAC_SHA256));		
	    
	    System.out.println("HMacSHA256 file::=> " + generateHMacSHA256(k, m));
	}

	// @SuppressFBWarnings(value = "DM_EXIT", justification = "Exit on incorrect
	// usage is OK here")
	protected static void usage() {
		System.out.println("Usage: java -jar genLAU.jar [-xmlv2] -key <key> <file 1> ... <file N>");
		System.out.println("       java -jar genLAU.jar -digest <file 1> ... <file N>");
		System.out.println("       java -jar genLAU.jar -validate -key <key> <file> <LAU file>");
		System.out.println("       java -jar genLAU.jar -validate -xmlv2 -key <key> <file 1> ... <file N>");

		System.exit(-1);
	}
	
	public static void main00() {
	  	try {
		    String k= "Abcd1234abcd1234Abcd1234abcd1234";
		    String m = UtilsFile.readFileAsString2("e:/tmp/siginfo.xml");
		    Mac hasher = Mac.getInstance("HmacSHA256");
		    hasher.init(new SecretKeySpec(k.getBytes(), "HmacSHA256"));
		    
		    byte[] hash = hasher.doFinal(m.getBytes());
		    
		    // to lowercase hexits
		    String s = DatatypeConverter.printHexBinary(hash);
		    
		    // to base64
		    String s1 = DatatypeConverter.printBase64Binary(hash);
		    System.out.println("hash HexBinary:  " + s +"  hash Base64Binary: "+ s1 );
	  	}
	  	catch (NoSuchAlgorithmException e) {}
	  	catch (InvalidKeyException e) {}
	  }
	
	public static String hmacDigest(String msg, String keyString, String algo) {
	    String digest = null;
	    try {
	      SecretKeySpec key = new SecretKeySpec((keyString).getBytes("UTF-8"), algo);
	      Mac mac = Mac.getInstance(algo);
	      mac.init(key);

	      byte[] bytes = mac.doFinal(msg.getBytes("ASCII"));

	      StringBuffer hash = new StringBuffer();
	      for (int i = 0; i < bytes.length; i++) {
	        String hex = Integer.toHexString(0xFF & bytes[i]);
	        if (hex.length() == 1) {
	          hash.append('0');
	        }
	        hash.append(hex);
	      }
	      digest = hash.toString();
	    } catch (UnsupportedEncodingException e) {
	    } catch (InvalidKeyException e) {
	    } catch (NoSuchAlgorithmException e) {
	    }
	    return digest;
	  }
	
	public static String generateHMacSHA256(final String key, final String data)
			throws InvalidKeyException, NoSuchAlgorithmException {
	
		final Mac hMacSHA256 = Mac.getInstance("HmacSHA256");
		byte[] hmacKeyBytes = key.getBytes(StandardCharsets.UTF_8);
		final SecretKeySpec secretKey = new SecretKeySpec(hmacKeyBytes, "HmacSHA256");
		hMacSHA256.init(secretKey);
		byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
		byte[] res = hMacSHA256.doFinal(dataBytes);

		return DatatypeConverter.printBase64Binary(res);
	}	
}