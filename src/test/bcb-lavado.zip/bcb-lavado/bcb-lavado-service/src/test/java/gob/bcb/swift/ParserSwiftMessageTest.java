package gob.bcb.swift;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsGeneric;

public class ParserSwiftMessageTest {
	private static final Logger log = LoggerFactory.getLogger(ParserSwiftMessageTest.class);
	public final static int MAX_SOURCE_LENGTH = 88;

	@Test
	public void splitSwiftTest(){
		log.info("=========splitSwiftTest=========");		
		final String archSwift = "src/test/resources/lotesentrantes/lote01.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		log.info(UtilsGeneric.getShortText(menPlano, MAX_SOURCE_LENGTH));
		String[] res = ParserSwiftMessage.splitSwift(menPlano);
		Assert.assertTrue("Debe tener elementos", res.length > 10);		
	}
	
	@Test
	public void verificFormatTextTest(){
		log.info("=========verificFormatTextTest=========");		
		String valid = "{1:F21BCEBBOLPAXXX0819320083}{4:{177:1507281751}{451:0}";
		Assert.assertTrue("Error en validacion de mensaje", ParserSwiftMessage.isFormatSwift(valid));
		String invalid = "{1:";
		Assert.assertFalse("Se esperaba falso", ParserSwiftMessage.isFormatSwift(invalid));		
		valid = "a6utVO0{1:NmSEyqqufncl6bKQ}{COP:P}}$";
		Assert.assertTrue("Se esperaba True", ParserSwiftMessage.isFormatSwift(valid));		
	
	}	
}
