package gob.bcb.lavado.QL.rrhh;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.QL.rrhh.PlafinQLBean;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.UnidadOrgCoin;

public class PlafinQLBeanTest  extends ConfigBaseTest {
	protected final static Logger log = LoggerFactory.getLogger(PlafinQLBeanTest.class);
	@Autowired
	private PlafinQLBean plafinQLBean;
	
	@Test
	public void unidadesOrgTest(){
		log.info("unidadesOrgTest");
		List<UnidadOrgCoin> unidades = plafinQLBean.unidadesOrg();
		
		Assert.assertTrue("Se esperaba unidades", unidades.size() > 0);
		
		unidades.stream().forEach(u -> {
			List<Empleado> emples = plafinQLBean.findEmpleadosPorUnid(u.getCodUnidadOrg());
			log.info("Empleados unidad {} : {} ", emples.size(), u.getCodUnidadOrg());
			Assert.assertTrue("Se esperaba empleados para unidad: " + u.getCodUnidadOrg(), emples.size() > 0);
			Empleado emple = plafinQLBean.findEmpleado(emples.get(0).getNroEmpleado());
			Assert.assertNotNull("Objeto empleado nulo " + emples.get(0).getNroEmpleado(), emple);
		});
	}
}
