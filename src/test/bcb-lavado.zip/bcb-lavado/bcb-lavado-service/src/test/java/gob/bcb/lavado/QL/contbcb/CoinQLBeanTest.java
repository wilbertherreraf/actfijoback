package gob.bcb.lavado.QL.contbcb;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.axesso.services.JndiDatasourceCreator;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.QL.contbcb.CoinQLBean;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.ConfigBaseTest;


public class CoinQLBeanTest  extends ConfigBaseTest{
	private static final Logger log = LoggerFactory.getLogger(CoinQLBeanTest.class);
	@Autowired
	private CoinQLBean coinQLBean;


	@Test	
	public void noHabilTest(){
		String aniocurrent =  UtilsDate.stringFromDate(new Date(), "yyyy");
		Date fecha = UtilsDate.dateFromString("01/01/" + aniocurrent, "dd/MM/yyyy");
		Assert.assertFalse("Fecha " + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy")  + " no registrado en contbcb", coinQLBean.isHabil(fecha));
	}
	
	@Test
	public void getConnect() throws NamingException, SQLException{
		log.info("Coneect ");
		InitialContext jndiEnc = new InitialContext();
		DataSource ds = (DataSource) jndiEnc.lookup(Constants.JNDI_CONTBCB);
		
		log.info("Coneect "  + (ds == null));		
		Connection conn = ds.getConnection();		
		
	}
}
