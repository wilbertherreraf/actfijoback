package gob.bcb.swift;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.swift.CampoFormUtils;

public class SwiftMessageBcbTest {
	private static final Logger log = LoggerFactory.getLogger(SwiftMessageBcbTest.class);

//	@Test
	public void swiftMessageBcbHashOutcomming() throws IOException {
		final String archSwift = "src/test/resources/swifts/2405.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		//menPlano = menPlano.replace("\r\n", " ");
		log.info(menPlano);
		SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb(menPlano);
		SwiftMessageBcb swiftMessageBcb2 = new SwiftMessageBcb(menPlano);		
		swiftMessageBcb.fromString(menPlano);
		swiftMessageBcb2.fromString(menPlano);
		
		String without20 = swiftMessageBcb.checkSum();
		String with20 = swiftMessageBcb2.checkSum();
		log.info("OUT::>checkSum " + swiftMessageBcb.checkSum());
		log.info("OUT::>checkSum sin 20 " + swiftMessageBcb.checkSum("20"));
		Assert.assertTrue("Hash de swift incorrecto", without20.equals(with20));
	}
	
//	@Test
	public void swiftMessageBcbHashIncomming() throws IOException {
		final String archSwift = "src/test/resources/swifts/in_0001.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		//menPlano = menPlano.replace("\r\n", " ");
		log.info(menPlano);
		SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb(menPlano);
		SwiftMessageBcb swiftMessageBcb2 = new SwiftMessageBcb(menPlano);		
		swiftMessageBcb.fromString(menPlano);
		swiftMessageBcb2.fromString(menPlano);
		
		String without20 = swiftMessageBcb.checkSum();
		String with20 = swiftMessageBcb2.checkSum();
		log.info("IN::>checkSum " + swiftMessageBcb.checkSum());
		log.info("IN::>checkSum sin 20 " + swiftMessageBcb.checkSum("20"));
		Assert.assertTrue("Hash de swift incorrecto", without20.equals(with20));
	}
//	@Test
	public void isSimilarTest() throws IOException{
		String archSwift = "src/test/resources/swifts/sioc2016_5424__mcondo.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb(menPlano);
		SwiftMessageBcb swiftMessageBcb2 = new SwiftMessageBcb(menPlano);
		swiftMessageBcb.fromString(menPlano);
		log.info(swiftMessageBcb.getSwiftMessage().getSender());		
		swiftMessageBcb2.fromString(menPlano);		
		Assert.assertTrue("Swifts sin campo deben ser identicos", swiftMessageBcb.isSimilar(swiftMessageBcb2, "20"));
		Assert.assertTrue("Swifts con campo deben ser identicos", swiftMessageBcb.isSimilar(swiftMessageBcb2));
		
		archSwift = "src/test/resources/swifts/sioc2016_5424__mcondo_dif.dos";
		String menPlano2 = UtilsFile.readFileAsString2(archSwift);
		swiftMessageBcb2 = new SwiftMessageBcb(menPlano2);
		swiftMessageBcb2.fromString(menPlano2);
		
		Assert.assertFalse("Swifts con campo deben ser diferentes", swiftMessageBcb.isSimilar(swiftMessageBcb2));		
		
	}
	@Test
	public void isotestpru() {
		List<CampoForm> list = CampoFormUtils.classPropertiesCF(CampoForm.class);
		list.forEach(cf -> {
			System.out.println("cf " + cf.getTabla() + "." + cf.getColumn() + " " + cf.getTipoValor());
		});
	}
}
