package gob.bcb.lavado.search.queryparsers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.QueryParser.Operator;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.spans.SpanMultiTermQueryWrapper;
import org.apache.lucene.search.spans.SpanNearQuery;
import org.apache.lucene.search.spans.SpanOrQuery;
import org.apache.lucene.search.spans.SpanQuery;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaBlanklist;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.search.AnalizersHolder;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.facet.FacetQueryOfac;
import gob.bcb.lavado.search.indexer.JPASearchFactoryController;
import gob.bcb.lavado.search.indexer.JPASearchFactoryControllerImpl;
import gob.bcb.lavado.search.indexer.JPASearchFactoryHolder;
import gob.bcb.lavado.search.queryparsers.QueryParsersBuilder;

public class QueryParsersBuilderTest extends ConfigBaseTest {
	private static final Logger log = LoggerFactory.getLogger(QueryParsersBuilderTest.class);

	@Autowired
	private JPASearchFactoryHolder jPASearchFactoryHolder;

	// private JPASearchFactoryController jPASearchFactoryController;
	@Before
	@Override
	public void before() throws Exception {
		log.info("=== before  QueryParsersBuilderTest ===");
	}

	@Test
	public void createQueryParseTest() throws Exception {
		log.info("createQueryParseTest.....");
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		String query = "SHELIMAR";
		FieldQuery fieldQuery = FieldQuery.builder("1111").addField("sdnLastname", AnalizersHolder.getAnalyzerStandard()).addClazz(OfaSdnentry.class).addFuzzy(0, 0).addBoost(1f)
				.build();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, fieldQuery.getClazz());

		Query queryLucene = queryParsersBuilder.createQueryParse(fieldQuery.getField(), query, Operator.AND, fieldQuery.getBoost(), fieldQuery.getAnalyzer());
		runQuery(queryLucene, jPASearchFactoryController, fieldQuery.getClazz());
		jPASearchFactoryController.close();
	}

	@Test
	public void createQueryParseWithoutTemplateTest() throws Exception {
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		log.info("createQueryParseWithoutTemplateTest.....");
		String queryTemplate = "+sdnLastname:{0} +sdnSdntype:'individual'";

		FieldQuery fieldQuery = FieldQuery.builder("1111").addField("sdnLastname", AnalizersHolder.getAnalyzerStandard()).addClazz(OfaSdnentry.class)
				.addQueryTemplate(queryTemplate).addFuzzy(1, 1).addBoost(1.5f).build();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, fieldQuery.getClazz());
		String query = "+(sdnLastname:(alsate mejia))";
		Query queryLucene = queryParsersBuilder.createQueryParse(fieldQuery.getField(), query, Operator.OR, fieldQuery.getBoost(), fieldQuery.getAnalyzer());
		runQuery(queryLucene, jPASearchFactoryController, fieldQuery.getClazz());

		fieldQuery = FieldQuery.builder("1111").addField("sdnLastname", AnalizersHolder.getAnalyzerStandard()).addClazz(OfaSdnentry.class).addQueryTemplate(queryTemplate)
				.addFuzzy(1, 1).addBoost(1.5f).build();

		query = "+(sdnLastname:(alsate mejia)) +sdnSdntype:'individual'";
		// query = "+(sdnLastname: +sdnSdntype:'individual'";
		Query queryLucene1 = queryParsersBuilder.createQueryParse(fieldQuery.getField(), query, Operator.OR, fieldQuery.getBoost(), fieldQuery.getAnalyzer());
		runQuery(queryLucene1, jPASearchFactoryController, fieldQuery.getClazz());

		Query queryLucene2 = queryParsersBuilder.joinQueries(queryLucene, BooleanClause.Occur.MUST, queryLucene1, BooleanClause.Occur.MUST_NOT);
		runQuery(queryLucene2, jPASearchFactoryController, fieldQuery.getClazz());
		jPASearchFactoryController.close();
	}

	@Test
	public void createQueryFuzzyWithTemplateTest() {
		log.info("createQueryFuzzyWithTemplateTest.....");
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		String queryTemplate = "+sdnLastname:{0} +sdnSdntype:'individual'";

		FieldQuery fieldQuery = FieldQuery.builder("1111").addField("sdnLastname", AnalizersHolder.getAnalyzerStandard()).addClazz(OfaSdnentry.class)
				.addQueryTemplate(queryTemplate).addFuzzy(1, 1).addBoost(1.5f).build();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, fieldQuery.getClazz());
		String query = "alsate mejia";
		query = "alsate";
		log.info("antes createQueryFuzzyQueryField");
		Query queryLucene1 = queryParsersBuilder.createQueryFuzzyQueryField(fieldQuery.getField(), query, fieldQuery.getDistanceUpTo(), fieldQuery.getPrefixLength(),
				fieldQuery.getBoost());
		runQuery(queryLucene1, jPASearchFactoryController, fieldQuery.getClazz());
		jPASearchFactoryController.close();
	}

	@Test
	public void createQueryParseWithTemplateTest() throws Exception {
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		log.info("createQueryParseWithTemplateTest.....");
		String queryTemplate = "sdnSdntype:'individual'";

		FieldQuery fieldQuery = FieldQuery.builder("1111").addField("sdnLastname", AnalizersHolder.getAnalyzerStandard()).addClazz(OfaSdnentry.class)
				.addQueryTemplate(queryTemplate).addFuzzy(2, 1).addBoost(1.5f).build();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, fieldQuery.getClazz());

		String query = "alsate mejia";
		Query queryLucene = queryParsersBuilder.createQueryFuzzyField(fieldQuery.getField(), query, fieldQuery.getDistanceUpTo(), fieldQuery.getPrefixLength(),
				fieldQuery.getBoost());
		runQuery(queryLucene, jPASearchFactoryController, fieldQuery.getClazz());

		fieldQuery = FieldQuery.builder("1111").addField("sdnLastname", AnalizersHolder.getAnalyzerStandard()).addClazz(OfaSdnentry.class).addQueryTemplate(queryTemplate)
				.addBoost(1.5f).build();

		query = "sdnSdntype:'individual'";
		query = "(sdnLastname:alsate~1 sdnLastname:mejia~1)^1.5";
		query = queryLucene.toString();
		query = "sdnSdntype:'swift_bic'";
		Query queryLucene1 = queryParsersBuilder.createQueryParse("sdnSdntype", query, Operator.AND, fieldQuery.getBoost(), fieldQuery.getAnalyzer());
		Query queryLucene2 = queryParsersBuilder.joinQueries(queryLucene, BooleanClause.Occur.MUST, queryLucene1, BooleanClause.Occur.MUST);
		log.debug("joinQueries luceneQuery : " + queryLucene2);
		runQuery(queryLucene2, jPASearchFactoryController, fieldQuery.getClazz());
		jPASearchFactoryController.close();
	}

	@Test
	public void createQueryTermToFuzzyTest() throws Exception {
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		log.info("createQueryTermToFuzzyTest......");
		String queryTemplate = "sdnSdntype:'individual'";

		FieldQuery fieldQuery = FieldQuery.builder("1111").addField("sdnLastname", AnalizersHolder.getAnalyzerStandard()).addClazz(OfaSdnentry.class)
				.addQueryTemplate(queryTemplate).addFuzzy(2, 1).addBoost(1.5f).build();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, fieldQuery.getClazz());

		String query = "mejia alsate ";
		Query queryLucene = queryParsersBuilder.createQueryFuzzyField(fieldQuery.getField(), query, fieldQuery.getDistanceUpTo(), fieldQuery.getPrefixLength(),
				fieldQuery.getBoost());
		log.debug("QueryParse luceneQuery : " + queryLucene);
		runQuery(queryLucene, jPASearchFactoryController, fieldQuery.getClazz());

		query = queryLucene.toString();
		Query queryLucene1 = queryParsersBuilder.createQueryParse(fieldQuery.getField(), query, Operator.AND, fieldQuery.getBoost(), fieldQuery.getAnalyzer());
		log.debug("luceneQuery : " + queryLucene1);
		runQuery(queryLucene1, jPASearchFactoryController, fieldQuery.getClazz());

		jPASearchFactoryController.close();
	}

	@Test
	public void simpleQueryTest() throws Exception {
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		log.info("simpleQueryTest......");
		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, OfaSdnentry.class);

		String query = "sdnLastname:engineering sdnLastname:verkhnevolzhsky sdnLastname:compani";
		Query queryLucene1 = queryParsersBuilder.createQueryParse("sdnLastname", query, Operator.OR, 1.0f, AnalizersHolder.getAnalyzerWords());
		log.debug("luceneQuery : " + queryLucene1);
		runQuery(queryLucene1, jPASearchFactoryController, OfaSdnentry.class);

		jPASearchFactoryController.close();
	}

	@Test
	public void spanNearQueryTest() {
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		log.info("spanNearQueryTest......");
		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, OfaSdnentry.class);
		List<SpanOrQuery> terms = new ArrayList<>();

		Query spanOrQuery = queryParsersBuilder.createSpanOrQuery("sdnLastname", "mejia", 1, 1, 1, AnalizersHolder.getAnalyzerWords());
		terms.add((SpanOrQuery) spanOrQuery);

		spanOrQuery = queryParsersBuilder.createSpanOrQuery("sdnLastname", "asociados", 1, 1, 1, AnalizersHolder.getAnalyzerWords());
		terms.add((SpanOrQuery) spanOrQuery);

		Query query = new SpanNearQuery(terms.toArray(new SpanQuery[0]), 0, true);

		runQuery(query, jPASearchFactoryController, OfaSdnentry.class);
		jPASearchFactoryController.close();
	}

	@Test
	public void rewriteSpanFuzzyQueryTest() {
		log.info("rewriteSpanFuzzyQueryTest......");
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		FuzzyQuery fq = new FuzzyQuery(new Term("sdnLastname", "company"), 0, 1, 5, false);
		SpanQuery sfq = new SpanMultiTermQueryWrapper<>(fq);
		SpanOrQuery ql1 = new SpanOrQuery(new SpanQuery[] { sfq });

		FuzzyQuery term = new FuzzyQuery(new Term("sdnLastname", "engineerin"), 1, 1, 1, false);
		SpanQuery sfq0 = new SpanMultiTermQueryWrapper<>(term);
		SpanOrQuery ql0 = new SpanOrQuery(new SpanQuery[] { sfq0 });

		SpanQuery sfq00 = new SpanNearQuery(new SpanQuery[] { ql0, ql1 }, 1, true);
		runQuery(sfq00, jPASearchFactoryController, OfaSdnentry.class);
		jPASearchFactoryController.close();
	}

	@Test
	public void createQueryBoolOneQueryForManyFieldsTest() {
		log.info("createQueryBoolOneQueryForManyFieldsTest......");
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		String[] fields = { "sdnLastname", "sdnFirstname" };
		String query = "alsa mejia";
		BooleanClause.Occur[] flags = { BooleanClause.Occur.SHOULD, BooleanClause.Occur.SHOULD };

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, OfaSdnentry.class);
		Query queryLucene = queryParsersBuilder.createQueryBoolOneQueryForManyFields(query, fields, flags, AnalizersHolder.getAnalyzerStandard());

		jPASearchFactoryController.close();
	}

	@Test
	public void queryQuerySpanFuzzyTest() {
		log.info("queryQuerySpanFuzzyTest......");
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		String query = "BANK MARKAZI";
		query = "INTERNATIONAL FUND FOR AGRICULTURAL DEVELOPMENT";
		query = "INTERNATIONAL FUND FOR AGRICULTURAL";
		int slop = 1;
		int distanceUpTo = 0;
		int prefixLength = 0;
		float boost = 1;
		boolean inOrder = true;
		boolean exceptNumbers = true;
		Analyzer analyzer = AnalizersHolder.getEntityAnalyzer();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, OfaBlanklist.class);

		Query queryLucene0 = queryParsersBuilder.createQuerySpanNearFuzzy("blcContent", query, distanceUpTo, prefixLength, boost, slop, inOrder, 2, exceptNumbers, analyzer);

		runQuery(queryLucene0, jPASearchFactoryController, OfaBlanklist.class);
		jPASearchFactoryController.close();
	}

	@Test
	public void createQuerySpanOrQueryFuzzyTest() {
		log.info("createQuerySpanOrQueryFuzzyTest......");
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		String query = "de la perla del pacifico s.a. de c.v.";
		int slop = 2;
		int distanceUpTo = 2;
		int prefixLength = 0;
		float boost = 1;
		boolean inOrder = false;
		boolean exceptNumbers = false;
		Analyzer analyzer = AnalizersHolder.getEntityAnalyzer(Constants.BASE_DIR_APP + "queries/stop_words.txt");

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, OfaSdnentry.class);

		Query queryLucene = queryParsersBuilder.createQuerySpanOrQueryFuzzy("menPlano", query, distanceUpTo, prefixLength, boost, slop, inOrder, 2, exceptNumbers, analyzer);

		runQuery(queryLucene, jPASearchFactoryController, OfaSdnentry.class);
		jPASearchFactoryController.close();
	}

	@Test
	public void highlightFieldQuerySpanFuzzyTest() throws IOException, InvalidTokenOffsetsException {
		log.info("highlightFieldQuerySpanFuzzyTest.....");
		String query = "BANCO DE LA NACION MASKAN ADVOKATFIRMAN IRAN AVINGE KB SMALANDSGATAN123";
		query = "ALA AL DIN";
		String text = "BANCO DE LA NACION MASKAN ADVOKATFIRMAN IRAN AVINGE KB SMALANDSGATAN 20 BOX 1703 SE 11187";
		query = "/FW021082159 CITIBANK WEST FSB";
		text = "INTERNATIONAL FUND FOR AGRICULTURAL DEVELOPMENT";
		int slop = 2;
		int distanceUpTo = 0;
		int prefixLength = 0;
		float boost = 0;
		boolean inOrder = false;
		boolean exceptNumbers = true;
		int minWordLen = 2;
		Analyzer analyzer = AnalizersHolder.getEntityAnalyzer();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder();

		Query queryLucene0 = queryParsersBuilder.createQuerySpanNearFuzzy("blcContent", query, distanceUpTo, prefixLength, boost, slop, inOrder, minWordLen, exceptNumbers,
				analyzer);
		String observed = queryParsersBuilder.highlightField(queryLucene0, "blcContent", text, analyzer);
		log.info("observed SPAN: " + observed);
	}

	@Test
	public void createQuerySpanNearFuzzyTest() {
		log.info("createQuerySpanNearFuzzyTest.....");
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		String query = "BANCO DE LA NACION MASKAN ADVOKATFIRMAN AVINGE KB SMALANDSGATAN 20 BOX 1703 SE 11187, UKRAINE";
		int slop = 20;
		int distanceUpTo = 0;
		int prefixLength = 0;
		float boost = 1;
		boolean inOrder = true;
		boolean exceptNumbers = true;
		Analyzer analyzer = AnalizersHolder.getEntityAnalyzer();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, OfaSdnentry.class);
		analyzer = AnalizersHolder.getEntityAnalyzer(Constants.BASE_DIR_APP + "/queries/stop_words.txt");
		Query queryLucene = queryParsersBuilder.createQuerySpanNearFuzzy("sdnLastname", query, distanceUpTo, prefixLength, boost, slop, inOrder, 2, exceptNumbers, analyzer);

		runQuery(queryLucene, jPASearchFactoryController, OfaSdnentry.class);
		jPASearchFactoryController.close();
	}

	public void runQuery(Query queryLucene, JPASearchFactoryController jPASearchFactoryController, Class<?>... clazz) {
		FacetQueryOfac facetQueryOfac = new FacetQueryOfac(jPASearchFactoryController);
		List<SearchResultOfac> searchResultOfacRes = facetQueryOfac.search(queryLucene, clazz);
		log.info("runQuery with regs. " + searchResultOfacRes.size());
		for (SearchResultOfac searchResultOfac : searchResultOfacRes) {
			log.info("DocId: " + searchResultOfac.getDocId());
			if (searchResultOfac.getDocumentMatch() instanceof OfaSdnentry) {
				OfaSdnentry ofaSdnentry = (OfaSdnentry) searchResultOfac.getDocumentMatch();
				if (ofaSdnentry != null)
					log.info("::=> " + ofaSdnentry.getSdnEntryuid() + "[" + ofaSdnentry.getSdnSdntype() + "] " + ofaSdnentry.getSdnFirstname() + " "
							+ ofaSdnentry.getSdnLastname() + " " + ofaSdnentry.getSdnProgramlist() + " Query:[" + searchResultOfac.getScore() + "]");
			}
		}
	}

	@Test
	public void createQueryBicsTest() throws Exception {
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		log.info("createQueryBicsTest.....");
		String query = "AAALSAR";
		int slop = 8;
		int distanceUpTo = 1;
		int prefixLength = 0;
		float boost = 0;
		boolean inOrder = false;
		boolean exceptNumbers = false;

		Analyzer analyzer = AnalizersHolder.getEntityAnalyzer();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, SwfBics.class);
		Query queryLucene = queryParsersBuilder.createQuerySpanOrQueryFuzzy("id.bicCodbic", query, distanceUpTo, prefixLength, boost, slop, inOrder, 2, exceptNumbers, analyzer);

		runQuery(queryLucene, jPASearchFactoryController, SwfBics.class);
		jPASearchFactoryController.close();
	}

	@Test
	public void createQuerySpanNearFuzzyBlancaTest() {
		log.info("createQuerySpanNearFuzzyBlancaTest.....");
		JPASearchFactoryController jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		String query = "CITIBANK WEST FSB";
		int slop = 20;
		int distanceUpTo = 0;
		int prefixLength = 0;
		float boost = 1;
		boolean inOrder = true;
		boolean exceptNumbers = true;
		Analyzer analyzer = AnalizersHolder.getEntityAnalyzer();

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, OfaBlanklist.class);
		analyzer = AnalizersHolder.getEntityAnalyzer(Constants.BASE_DIR_APP + "queries/stop_words.txt");
		Query queryLucene = queryParsersBuilder.createQuerySpanNearFuzzy("blcContent", query, distanceUpTo, prefixLength, boost, slop, inOrder, 2, exceptNumbers, analyzer);

		runQuery(queryLucene, jPASearchFactoryController, OfaBlanklist.class);
		jPASearchFactoryController.close();
	}
}
