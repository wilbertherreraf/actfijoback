package gob.bcb.lavado.services;


import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.commons.ArchivoSinpleServiceImpl;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.search.OfacIndexer;
import gob.bcb.lavado.services.OfaListService;

public class OfaListServiceTest extends ConfigBaseTest {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OfaListService ofaListService;
	@Autowired
	private OfacIndexer ofacIndexer;
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
	
	//@Test
	public void indexOfaSdnentryTest() throws Exception {
		log.info("%%%%%%%%%%%%%% indexOfaSdnentry %%%%%%%%%%%%%%");
		ofacIndexer.indexOfaSdnentry();
		log.info("%%%%%%%%%%%%%% FINNNNNNNNNNNNNNNN indexOfaSdnentry %%%%%%%%%%%%%%");
	}

	public void indexLvdEntitiesTest() throws Exception {
		log.info("%%%%%%%%%%%%%% indexLvdEntities %%%%%%%%%%%%%%");
		ofacIndexer.indexLvdEntities();
	}

	@Test
	public void cargarListaOfacFuncTest() throws Throwable {
		log.info("%%%%%%%%%%%%%% cargarListaOfacImperativeTest %%%%%%%%%%%%%%");
		String fileSdn = "src/test/resources/ofac/lista_inicial.xml";
		//fileSdn = "src/test/resources/ofac/lista_indiv.xml";
		//fileSdn = "e:/tmp/lista_inicial.xml";
		fileSdn = "e:/tmp/full.xml";
		//fileSdn = "e:/tmp/indiv.XML";
		String nameFileOriginal = "lista_inicial.xml";
		ofaListService.truncateTablesOfac("aaaaaaaa", "bbbbbbbbbbbb");
		long startTime = System.currentTimeMillis();
		ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
		archivoSinpleService.fromPathfile(fileSdn, nameFileOriginal);
		
		swiftAdminDaoService.guardarLoteOfac("usertest", archivoSinpleService.getArchivoSinple(),"estacion");
		log.info("%%%%%%%%%%%%%% FIN cargarListaOfacImperativeTest %%%%%%%%%%%%%%");
		log.info("Done at (" + (System.currentTimeMillis() - startTime) + " ms.)");
	}	

//	@Test
	public void cargarListaOfacSecTest() throws Throwable {
		log.info("%%%%%%%%%%%%%% cargarListaOfacSecTest %%%%%%%%%%%%%%");
		String fileSdn = "src/test/resources/ofac/lista_inicial.xml";
		fileSdn = "e:/tmp/full.xml";
		String nameFileOriginal = "lista_inicial.xml";
		ofaListService.truncateTablesOfac("aaaaaaaa", "bbbbbbbbbbbb");
		long startTime = System.currentTimeMillis();
		ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
		archivoSinpleService.fromPathfile(fileSdn, nameFileOriginal);
		
		swiftAdminDaoService.guardarLoteOfacSec("usertest", archivoSinpleService.getArchivoSinple(),"estacion");
		log.info("%%%%%%%%%%%%%% FIN cargarListaOfacImperativeTest %%%%%%%%%%%%%%");
		log.info("Done at (" + (System.currentTimeMillis() - startTime) + " ms.)");
	}	

	//@Test
	public void cargarListaOfacTest() throws Throwable {
		log.info("%%%%%%%%%%%%%% cargarListaOfacImperativeTest %%%%%%%%%%%%%%");
		String fileSdn = "src/test/resources/ofac/lista_inicial.xml";
		//fileSdn = "src/test/resources/ofac/lista_indiv.xml";
		//fileSdn = "e:/tmp/lista_inicial.xml";
		fileSdn = "e:/tmp/ofac_202005.xml";
		//fileSdn = "e:/tmp/chiqui.xml";
		String nameFileOriginal = "lista_inicial.xml";
		
		ofaListService.truncateTablesOfac("codUsuario", "estacion");
		
		long startTime = System.currentTimeMillis();
		ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
		archivoSinpleService.fromPathfile(fileSdn, nameFileOriginal);
		
		swiftAdminDaoService.guardarLoteOfac("usertest", archivoSinpleService.getArchivoSinple(),"estacion");
		log.info("%%%%%%%%%%%%%% FIN cargarListaOfacImperativeTest %%%%%%%%%%%%%%");
		log.info("Done at (" + (System.currentTimeMillis() - startTime) + " ms.)");
	}	
}
