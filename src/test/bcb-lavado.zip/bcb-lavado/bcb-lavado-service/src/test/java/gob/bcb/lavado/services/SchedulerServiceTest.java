package gob.bcb.lavado.services;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.lavado.services.SchedulerService;

public class SchedulerServiceTest extends ConfigBaseTest{
	private static final Logger log = LoggerFactory.getLogger(SchedulerServiceTest.class);	
//	@Autowired
//	private SwiftAdminDaoService swiftAdminDaoService;
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private SchedulerService schedulerService;	
	@Test	 
	public void actualizarSwfParamsTest(){
		log.info("actualizarSwfParamsTest Scheduler.....");		
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_HORARIOSIMPORT);
		Assert.assertNotNull("Se esperaba swfParams", swfParams);
		Assert.assertNotNull("Se esperaba swfParams.getParValor", swfParams.getParValor());

		String hora = UtilsDate.stringFromDate(UtilsDate.addTime(new Date(), 2, 13), "HH:mm:ss");
		swfParams.setParValor(hora);
//		schedulerService.startScheduling(hora);
//		//swiftAdminDaoService.actualizarSwfParams(swfParams);
//		Assert.assertTrue("Scheduler no se ejecuto", SchedulerService.isRunningScheduler());
//		swfParams.setParValor(valOld);		
//		swiftAdminDaoService.actualizarSwfParams(swfParams);		
	}
}
