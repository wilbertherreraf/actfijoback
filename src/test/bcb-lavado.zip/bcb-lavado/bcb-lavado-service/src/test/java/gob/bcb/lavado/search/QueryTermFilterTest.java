package gob.bcb.lavado.search;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.BytesRefHash;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.AnalizersHolder;
import gob.bcb.lavado.search.QueryTermFilter;
import gob.bcb.lavado.search.analysis.EntityAnalyzer;
import gob.bcb.lavado.search.queryparsers.QueryParsersBuilder;

public class QueryTermFilterTest {
	protected final Logger log = LoggerFactory.getLogger(QueryTermFilterTest.class);	
	@Test
	public void createQueryTermFilter() throws IOException {
		String[] fieldsOut = { "sdnLastname", "sdnFirstname", "sdnRemarks", "sdnTitle", "sdnProgramlist"};
		QueryTermFilter queryTermFilter = new QueryTermFilter(fieldsOut, "hola mundo", 2,false, AnalizersHolder.getAnalyzerStandard());
		BytesRefHash bytesRefHash = queryTermFilter.getTerms("sdnLastname");

		BytesRef b = new BytesRef();
		BytesRef bb = bytesRefHash.get(0, b);
		bb = bytesRefHash.get(1, b);
		
		bytesRefHash = queryTermFilter.getTerms("sdnRemarks");

		for(String f : fieldsOut){
			BytesRefHash bytesRefHash0 = queryTermFilter.getTerms(f);
			for(int i=0 ; i< bytesRefHash0.size(); i++){
				bb = bytesRefHash.get(i, b);
				log.info(f + ":" + bb.utf8ToString());
			}
		}

	}
	@Test
	public void createMapQueryTermFilter() throws IOException {
		Map<String, QueryTermFilter> termFilters = new HashMap<>();
		String query = "hola changos mundo";
		String[] fieldsOut = { "sdnLastname", "sdnFirstname"};
		QueryTermFilter queryTermFilter = new QueryTermFilter(fieldsOut, query, 2,false, new EntityAnalyzer());
		
		termFilters.put("B01", queryTermFilter);
		
		BytesRefHash bytesRefHash = queryTermFilter.getTerms("sdnLastname");

		BytesRef b = new BytesRef();
		BytesRef bb = bytesRefHash.get(0, b);
		log.info(bb.utf8ToString() + "  " + b.utf8ToString());
		bb = bytesRefHash.get(1, b);
		log.info(bb.utf8ToString());
		
		bytesRefHash = queryTermFilter.getTerms("sdnRemarks");
		for(String f : fieldsOut){
			BytesRefHash bytesRefHash0 = queryTermFilter.getTerms(f);
			for(int i=0 ; i< bytesRefHash0.size(); i++){
				bb = bytesRefHash0.get(i, b);
				log.info(f + ":" + bb.utf8ToString());
			}
			
		}

	}	
}
