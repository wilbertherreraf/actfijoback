package gob.bcb.swift;

import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.iso20022.pojo.ArchivoSinple;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.report.SwiftMessageReport;
import gob.bcb.iso20022.translate.ValidationEngine;
import gob.bcb.lavado.config.ConfigBaseTest;

public class SwiftMessageClientTest extends ConfigBaseTest {
	protected final static Logger log = LoggerFactory.getLogger(SwiftMessageClientTest.class);

	@Test
	public void reportMtMessage() {
		try {
			String nfile = "src/test/resources/mx/pacs008cli.xml"; // siodex_103.txt
			
			String str = UtilsFile.readFileAsString2(nfile);
			
			SwiftMessageAbstract sm = FactoryParser.createParser(str).createBlock4Long();
		
			SwiftMessageReport swiftMessageReport = new SwiftMessageReport();
			ArchivoSinple archivoSinple = swiftMessageReport.initReport(str, mp -> {
				mp.setMenCodapp("CODAPP");
				mp.setMenIdoperacion(mp.getMenCodapp()+"_" + System.currentTimeMillis());
				mp.setVerifica(true);
			}).createReportFile(null);
			
			archivoSinple.setDirectory("e:/tmp");
			
			String p = UtilsFile.grabaEnArchivo(archivoSinple.getStream(), archivoSinple.getPathFile());
			log.info("info " + p);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
	
	//@Test
	public void validateMx() {
		try {
			log.info("inicio test=========================");
			
			ValidationEngine engine = ValidationEngine.getInstance().registerValidators();

			String nfile = "src/test/resources/mx/pacs008cli.xml"; // siodex_103.txt
			String str = UtilsFile.readFileAsString2(nfile);

			engine = ValidationEngine.getInstance();
			List errors = engine.validateMsg(str);
			log.info("TIENE ERRORES DE VALIDACION? " + (errors.size() > 0));
			
			errors.forEach(s -> {
				log.info("\n 	Detalle Error: " + s);
			});
			log.info("111111111111*******************");
			engine = ValidationEngine.getInstance();

			nfile = "src/test/resources/mx/pacs.008hdr.xml"; // siodex_103.txt
			str = UtilsFile.readFileAsString2(nfile);

			errors = engine.validateMsg(str);
			log.info("TIENE ERRORES DE VALIDACION? " + (errors.size() > 0));
			errors.forEach(s -> {
				log.info("Error: " + s);
			});
			log.info("2222222222222*******************");
			nfile = "src/test/resources/mxs/mxpacs01.mx"; // siodex_103.txt
			str = UtilsFile.readFileAsString2(nfile);
			engine = ValidationEngine.getInstance();
			errors = engine.validateMsg(str);
			log.info("TIENE ERRORES DE VALIDACION? " + (errors.size() > 0) + " "  + nfile);
			
			errors.forEach(s -> {
				log.info("\n 	Detalle Error: " + s);
			});			
			
			
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}	
	
	//@Test
	public void validateMxWithSma() {
		try {
			log.info("inicio test=========================");
			String nfile = "src/test/resources/mx/mxpacs01.mx"; // siodex_103.txt
			String menplano = UtilsFile.readFileAsString2(nfile);
			
			SwiftMessageAbstract sm = FactoryParser.createParser(menplano);
			List<String> errors = sm.validateSyntax();
			log.info("errors " + errors.size());
			errors.forEach(e -> {
				log.info("error " + e);
			});
			
			log.info("inicio valid=========================");
			nfile = "src/test/resources/mx/pacs008cli.xml"; // siodex_103.txt
			menplano = UtilsFile.readFileAsString2(nfile);
			
			sm = FactoryParser.createParser(menplano);
			errors = sm.validateSyntax();
			log.info("errors2 " + errors.size());
			errors.forEach(e -> {
				log.info("error " + e);
			});
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}	
}
