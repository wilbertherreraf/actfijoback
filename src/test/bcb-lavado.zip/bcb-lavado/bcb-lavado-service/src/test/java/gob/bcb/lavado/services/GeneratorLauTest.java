package gob.bcb.lavado.services;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.client.ClienteLvd;
import gob.bcb.lavado.client.HandlerGeneratorLauSrv;
import gob.bcb.lavado.client.lau.GeneratorLAU;
import gob.bcb.lavado.client.pojos.GenLauDto;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.client.utils.GeneradorPassword;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.repository.SwfParamsDao;

public class GeneratorLauTest extends ConfigBaseTest {
	private static final Logger log = LoggerFactory.getLogger(GeneratorLauTest.class);
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired 
	private AppProperties appProperties;
	@Autowired
	private SwfMensajeDao swfMensajeDao;
	
	private String url;
	
	@Before
	@Override
	public void before() throws Throwable {
		super.before();
		//initDataInicialBaseSearch();
		url = base.toString();
	}
	
	@Test
	public void generarNuevoLauEnviarMensajeTest() throws Exception {
		log.info("===========generarNuevoLauEnviarMensajeTest==============");
		gob.bcb.lavado.client.ClienteLvd clienteLvd = ClienteLvd.init(url, appProperties.getLavado().getAppdir(),"AICOS");
		
		SwfMensaje swfMensaje = generarMensaje();
		swfMensaje.setMenCodapp("AICOS");
		SearchResponse searchResponse = clienteLvd.getIniSessionLavado(swfMensaje.getMenCodapp(), 
				swfMensaje.getMenAuditusr());
		String idsesseion = searchResponse.getCodoperacion();
		searchResponse = clienteLvd.solicitarCorrelativo(swfMensaje.getMenCodapp(), swfMensaje.getMenRefer(),
				swfMensaje.getMenAuditusr(), idsesseion);		
		
		clienteLvd.postSessionLavado(swfMensaje.getMenCodapp(), swfMensaje.getMenAuditusr(), idsesseion);
		
		SwfMensaje swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		log.info("swfMensajeNew.getMenEstverifica() " + swfMensajeNew.getMenEstverifica());
		
		searchResponse = clienteLvd.getIniSessionLavado(swfMensaje.getMenCodapp(), 
				swfMensaje.getMenAuditusr());
		idsesseion = searchResponse.getCodoperacion();
		String menPlanoEnviar = swfMensaje.getMenPlano();
		searchResponse = clienteLvd.scanSwiftRegistro(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenCodmen(),
				swfMensajeNew.getMenNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, menPlanoEnviar);
		
		clienteLvd.postSessionLavado(swfMensaje.getMenCodapp(), swfMensaje.getMenAuditusr(), idsesseion);
		
		//generarNuevoLauTest();
		
		searchResponse = clienteLvd.getIniSessionLavado(swfMensaje.getMenCodapp(), 
				swfMensaje.getMenAuditusr());
		idsesseion = searchResponse.getCodoperacion();		
		searchResponse = clienteLvd.preautorizarSwift(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				swfMensajeNew.getMenCodmen(), swfMensajeNew.getMenNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, menPlanoEnviar);
		
		clienteLvd.postSessionLavado(swfMensaje.getMenCodapp(), swfMensaje.getMenAuditusr(), idsesseion);
	}
	
	//@Test
	public void generarNuevoClienteSinLauEnviarMensajeTest() throws Exception {
		log.info("===========generarNuevoClienteSinLauEnviarMensajeTest==============");
		gob.bcb.lavado.client.ClienteLvd clienteLvd = ClienteLvd.init(url, appProperties.getLavado().getAppdir(),"SIOC");
		
		SwfMensaje swfMensaje = generarMensaje();
		swfMensaje.setMenCodapp("SIOC");
		SearchResponse searchResponse = clienteLvd.getIniSessionLavado(swfMensaje.getMenCodapp(), 
				swfMensaje.getMenAuditusr());
		String idsesseion = searchResponse.getCodoperacion();
		searchResponse = clienteLvd.solicitarCorrelativo(swfMensaje.getMenCodapp(), swfMensaje.getMenRefer(),
				swfMensaje.getMenAuditusr(), idsesseion);		
		
		clienteLvd.postSessionLavado(swfMensaje.getMenCodapp(), swfMensaje.getMenAuditusr(), idsesseion);
		
		SwfMensaje swfMensajeNew = swfMensajeDao.findByCodigo(Integer.valueOf(searchResponse.getCodoperacion()));

		log.info("swfMensajeNew.getMenEstverifica() " + swfMensajeNew.getMenEstverifica());
		
		searchResponse = clienteLvd.getIniSessionLavado(swfMensaje.getMenCodapp(), 
				swfMensaje.getMenAuditusr());
		idsesseion = searchResponse.getCodoperacion();
		String menPlanoEnviar = swfMensaje.getMenPlano();
		searchResponse = clienteLvd.scanSwiftRegistro(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(), swfMensajeNew.getMenCodmen(),
				swfMensajeNew.getMenNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, menPlanoEnviar);
		
		clienteLvd.postSessionLavado(swfMensaje.getMenCodapp(), swfMensaje.getMenAuditusr(), idsesseion);
		
		generarNuevoLauTest();
		
		searchResponse = clienteLvd.getIniSessionLavado(swfMensaje.getMenCodapp(), 
				swfMensaje.getMenAuditusr());
		idsesseion = searchResponse.getCodoperacion();		
		searchResponse = clienteLvd.preautorizarSwift(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditusr(),
				swfMensajeNew.getMenCodmen(), swfMensajeNew.getMenNrocorr(), swfMensajeNew.getMenRefer(), idsesseion, menPlanoEnviar);
		
		clienteLvd.postSessionLavado(swfMensaje.getMenCodapp(), swfMensaje.getMenAuditusr(), idsesseion);
	}	
	//@Test
	public void generarNuevoLauTest() throws Exception {
		log.info("===========generarNuevoLauTest==============");
		SwfParams swfParamsCODIGOLAU = swfParamsDao.findByCod(Constants.PARAM_CODIGOLAU);
		SwfParams swfParamsCORREOSCODLAU = swfParamsDao.findByCod(Constants.PARAM_CORREOSCODLAU);
		
		GenLauDto genLauDtoCurrent = HandlerGeneratorLauSrv.getGeneratorLAU().getGenLauDto();
		GenLauDto genLauDtoNew = new GenLauDto();
		GeneradorPassword generadorPassword = new GeneradorPassword(GeneratorLAU.LAU_KEY_LENGTH, true, true, false, true, GeneratorLAU.LAU_KEY_LENGTH_CHARS_REPEAT);

		genLauDtoNew.setFechaCreacion(new Date());

		generadorPassword.generatePasswordUntilValid();
		genLauDtoNew.setLauKeyFirstPart(generadorPassword.getPassword());
		generadorPassword.generatePasswordUntilValid();
		genLauDtoNew.setLauKeySecondPart(generadorPassword.getPassword());
		genLauDtoNew.setLauEstado("NUEVO");
		
		swiftAdminDaoService.guardarNuevoLauYNotificarAdmSwift(swfParamsCODIGOLAU, swfParamsCORREOSCODLAU, genLauDtoCurrent, genLauDtoNew,
				"usertest", "test");
		swiftAdminDaoService.activarCodigoLauNuevo("usertest", "test");
	}

	public SwfMensaje generarMensaje() {
		log.info("generarMensaje"); 
		String codapp = "TEST";
		String coduser = "1622";
		String idoperacion = String.valueOf(System.currentTimeMillis());
		String menPlano = UtilsFile.readFileAsString2("src/test/resources/swifts/swf_sinobservacion.dos");
		menPlano = menPlano.replace("1392930010", idoperacion);

		// solicitud del correlativo
		SwfMensaje swfMensaje = new SwfMensaje();
		swfMensaje.setMenCodapp(codapp);
		swfMensaje.setMenAuditusr(coduser);
		swfMensaje.setMenCodusrswf("usertest");
		swfMensaje.setMenRefer(idoperacion);
		swfMensaje.setMenPlano(menPlano);
		return swfMensaje;
	}	
}
