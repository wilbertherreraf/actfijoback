package gob.bcb.lavado.ofac;

import java.io.File;
import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.model.OfaSdnentry;

public class OfacLoaderTest {
	private static final Logger log = LoggerFactory.getLogger(OfacLoaderTest.class);

	@Autowired
	private OfacLoader ofacLoader;

	@Test
	public void readFileToOfaSdnentryToListaTest() throws Exception {
		String rawString = "Bassam 'TU’MA Ruslan Alexandrovich ROMASHKІN Jesús Rafael SUÁREZ CHOURIO";
		rawString = stripAccents(rawString);
		
		ByteBuffer buffer = StandardCharsets.UTF_8.encode(rawString);

		String utf8EncodedString = StandardCharsets.ISO_8859_1.decode(buffer).toString();

		byte[] bytes = buffer.array();
		String n = new String(bytes);
		FileInputStream fis = new FileInputStream(new File("e:/tmp/chiqui.xml"));
		String result = IOUtils.toString(fis, "ISO-8859-1"); // "ISO-8859-1"
		log.info("inicio load **** {} ==> {} ", n, result);

		// String utf8EncodedString = StringUtils.newStringUtf8(bytes);
		byte[] b = utf8EncodedString.getBytes(StandardCharsets.ISO_8859_1);
		String s = new String(b);
//		assertEquals(rawString, utf8EncodedString);
		log.info("inicio load **** {} {} {}", rawString, utf8EncodedString, s);
		try {
			log.info("inicio load *********************");
			String file = "e:/tmp/consolidated.xml";
			file = "e:/tmp/20220523-UE.xml";
			file = "e:/tmp/chiqui.xml";
			// List<SdnEntry> ofaSdnentryList =
			// OfacLoader.readFileToOfaSdnentryToLista(file);

			List<OfaSdnentry> sdnEntryList = OfacLoader.readFileToOfaSdnentryToLista(1, file);
			sdnEntryList.forEach(sdn -> {
				String detectedCharset = charset(sdn.getSdnLastname(), new String[] { "ISO-8859-1", "UTF-8" });
				log.info("SDN {} : {} - {} {}", sdn.getSdnEntryuid(), detectedCharset, sdn.getSdnLastname(), sdn.getSdnFirstname());
			});
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	// @Test
	public void loadXMLtest() {
		try {
			log.info("inicio load");
			String file = "e:/tmp/SDN.XML";
			String file2 = "e:/tmp/FULL.XML";
//			ofacLoader.loadFileXML(file, 10);
			List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableList = OfacLoader.convertFileXMLInmutable(1, file2);
			for (ImmutablePair<Integer, List<OfaSdnentry>> inmu : immutableList) {
				log.info("regis {} {}", inmu.left, inmu.right.size());
				inmu.right.forEach(i -> {

					String detectedCharset = charset(i.getSdnLastname(), new String[] { "ISO-8859-1", "UTF-8" });
					log.info("reg {} {} {}", i.getSdnEntryuid(), detectedCharset, i.getSdnLastname());
				});
			}
			// ofacLoader.loadFileXML(file2, 10);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}

	public static String convert(String value, String fromEncoding, String toEncoding) {
		try {
			return new String(value.getBytes(fromEncoding), toEncoding);
		} catch (UnsupportedEncodingException e) {
			return "";
		}
	}

	public static String charset(String value, String charsets[]) {
		String probe = StandardCharsets.UTF_8.name();
		for (String c : charsets) {
			Charset charset = Charset.forName(c);
			if (charset != null) {
				if (value.equals(convert(convert(value, charset.name(), probe), probe, charset.name()))) {
					return c;
				}
			}
		}
		return StandardCharsets.UTF_8.name();
	}

	public static String stripAccents(String s)	{
	    s = Normalizer.normalize(s, Normalizer.Form.NFD);
	    s = s.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
	    return s;
	}	
}
