package gob.bcb.lavado.search.analysis;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.AnalizersHolder;
import gob.bcb.lavado.search.analysis.ShingleAnalyzer;
import gob.bcb.lavado.search.presearcher.HighlightsMatch.Hit;

public class ShingleAnalyzerTest {
	private final Logger log = LoggerFactory.getLogger(ShingleAnalyzerTest.class);

	@Test
	public void retrieveCandidatesTermsHitTest() {
		log.info("retrieveCandidatesTermsHitTest.....");		
		String query = "bancó banCo";
		StringBuffer sb = new StringBuffer();
		List<Hit> hits = ShingleAnalyzer.retrieveCandidatesTermsHit(query, 2, false, AnalizersHolder.getEntityAnalyzer());
		hits.forEach(h -> {
			sb.append(h.text).append(" ");
		});
		log.info(sb.toString());
		Assert.assertTrue("Cadena Hit resultante debe ser identica a la inicial", sb.toString().trim().equals(query.toLowerCase()));
	}
	@Test
	public void termFrequenciesHitTest() {
		log.info("termFrequenciesHitTest.....");		
		String query = "INDUSTRIAL que de DEVELOPMENT AND RENOVATION ORGANIZATION OF IRAN";
		List<Hit> hits = ShingleAnalyzer.termFrequenciesHit("field", query, 2, 3, 0,2,  false, AnalizersHolder.getEntityAnalyzer());
		Assert.assertTrue("hits == ", hits.size() == 14);
	}
	
	@Test
	public void isNumberTest(){
		log.info("isNumberTest.....");		
		Assert.assertTrue(ShingleAnalyzer.isNumber("FW123456"));
		Assert.assertFalse(ShingleAnalyzer.isNumber("ABCASDF"));		
		Assert.assertTrue(ShingleAnalyzer.isNumber("ABC123ASDF"));		
		Assert.assertTrue(ShingleAnalyzer.isNumber("ABC123,123ASDF"));		
		Assert.assertTrue(ShingleAnalyzer.isNumber("456.123"));		
		Assert.assertTrue(ShingleAnalyzer.isNumber("ASDF;WERT,22222"));		
		Assert.assertTrue(ShingleAnalyzer.isNumber("963,852"));		
		Assert.assertFalse(ShingleAnalyzer.isNumber("ASDF,wqer;rtufghj"));		
	}
	
}
