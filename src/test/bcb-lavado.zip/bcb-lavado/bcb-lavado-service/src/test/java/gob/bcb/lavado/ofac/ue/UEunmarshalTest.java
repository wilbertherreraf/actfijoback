package gob.bcb.lavado.ofac.ue;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.Source;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.oxm.Unmarshaller;
import org.springframework.oxm.XmlMappingException;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import gob.bcb.lavado.ofac.ue.model.SanctionEntity;

public class UEunmarshalTest {
	private static final Logger log = LoggerFactory.getLogger(UEunmarshalTest.class);
	@Test
	public void test() {
		log.info("xxx");
		log.info("xxx");
		log.info("xxx");
		log.info("xxx");
		System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
		String pathFile = "e:/tmp/FULL.xml";
		FileInputStream fis;
		try {
			fis = new FileInputStream(new File(pathFile));
			Resource inputSDNXML = new InputStreamResource(fis);
			
			Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
			jaxb2Marshaller.setClassesToBeBound(SanctionEntity.class);
			jaxb2Marshaller.setMappedClass(SanctionEntity.class);
			
			
			StaxEventItemReader staxEventItemReader = new StaxEventItemReader();
			
			staxEventItemReader.setFragmentRootElementNames("sanctionEntity".split(","));
			staxEventItemReader.setFragmentRootElementName("sanctionEntity");
			staxEventItemReader.setResource(inputSDNXML);

			staxEventItemReader.setUnmarshaller(new Unmarshaller() {
				@Override
				public Object unmarshal(Source source) throws XmlMappingException, IOException {
					SanctionEntity sdnEntry = (SanctionEntity) jaxb2Marshaller.unmarshal(source);
					// guardando el registro parseado
					//Export ofaSdnentry = sdnListMapper.getOfaSdnentry(sdnEntry, nrolote);
					return sdnEntry;
				}

				@Override
				public boolean supports(Class<?> clazz) {
					return true;
				}

			});
			
			StaxEventItemReader<SanctionEntity> itemReaderxml = (StaxEventItemReader<SanctionEntity>) staxEventItemReader;
			log.info("Antes de ExecutionContext...");
			itemReaderxml.open(new ExecutionContext());
			
			List<SanctionEntity> ofaSdnentryList = new ArrayList<SanctionEntity>();
			SanctionEntity ssxml0 = null;
			while ((ssxml0 = itemReaderxml.read()) != null) {
				ofaSdnentryList.add(ssxml0);
			}

			
			ofaSdnentryList.forEach(ofa -> {
				log.info("NameAlias {} {} {}" , ofa.getNameAlias().size(), ofa.getRemark(), ofa.getLogicalId());
				
				ofa.getNameAlias().forEach(na -> {
					log.info("	FirstName {} {}" , na.getFirstName(), na.getWholeName());
				});
//				ofa.getBirthdate().forEach(na -> {
//					log.info("	getCountryDescription {}" , na.getCountryDescription());
//					
//				});				
			});
			log.info("ofaSdnentryList {} : {}" , ofaSdnentryList.size(), ofaSdnentryList.get(0).getDesignationDetails());			
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			log.error("Errr " + e.getMessage(), e);
		}
	}

}
