package gob.bcb.lavado.services;

import java.net.URI;
import java.util.Optional;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.WebUtils;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfNumeraswf;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.repository.SwfNumeraswfDaoImpl;
import gob.bcb.lavado.repository.SwfPersonaDao;

public class NumeracionSwiftServiceTest extends ConfigBaseTest {
	protected final static Logger log = LoggerFactory.getLogger(NumeracionSwiftServiceTest.class);
	@Autowired
	private NumeracionSwiftService numeracionSwiftService;
	@Autowired
	private SwfPersonaDao swfPersonaDao;
	@Autowired
	private SwfNumeraswfDaoImpl swfNumeraswfDao;
	String url = "http://10.3.11.170:8080/lavado/";
	
	@Test
	public void solicitudManualTest() throws Throwable {
		//numeracionSwiftService.solicitudManual(50001, "ASD@ASD.COM", "test", "ip", url);
		numeracionSwiftService.solicitudManual(190, "ASD@ASD.COM", "test", "ip");
	}
	
//	@Test(expected=SwiftAdminException.class)
	public void solicitudManualSessionInvalidTest() throws Throwable {
		//numeracionSwiftService.solicitudManual(50001, "ASD@ASD.COM", "test", "ip", url);
		log.info("Esperando.........");
		Thread.sleep(10000);
		//numeracionSwiftService.solicitudManual(50001, "ASD@ASD.COM", "test", "ip", url);
	}	
	
	//@Test
	public void confirmacionSolicitudOKTest() throws Throwable {
		
		//numeracionSwiftService.solicitudManual(50001, "ASD@ASD.COM", "test", "ip", url);
		Integer nroSwift =swfNumeraswfDao.sigNroSwift(UtilsDate.gestionActual());
		
		SwfPersona swfPersona = swfPersonaDao.findByCodigo(50001);
		
		Optional<SwfNumeraswf> swfNumeraswf = swfNumeraswfDao.findByToken(UtilsDate.gestionActual(), swfPersona.getPerCodemp(), swfPersona.getPerIdverifica());
		log.info("PerIdverifica: {} - {} ", swfPersona.getPerIdverifica(), nroSwift);
		
		numeracionSwiftService.confirmacionSolicitud(swfNumeraswf.get().getNroCodnro(), swfPersona.getPerIdverifica(), nroSwift);
	}
	
	//@Test(expected=SwiftAdminException.class)
	//@Test
	public void confirmacionSolicitudErrorTest() throws Throwable {
		URI uri = WebUtils.createURI(1);
//		new URL("http://10.3.11.170:8080/lavado/");
		log.info(uri.getPath());
		//numeracionSwiftService.solicitudManual(50001, "ASD@ASD.COM", "test", "ip", url);
		Integer nroSwift =swfNumeraswfDao.sigNroSwift(UtilsDate.gestionActual());
		
		SwfPersona swfPersona = swfPersonaDao.findByCodigo(50001);
		nroSwift = nroSwift - 1;
		Optional<SwfNumeraswf> swfNumeraswf = swfNumeraswfDao.findByToken(UtilsDate.gestionActual(), swfPersona.getPerCodemp(), swfPersona.getPerIdverifica());
		log.info("PerIdverifica: {} - {} ", swfPersona.getPerIdverifica(), nroSwift);
		
		numeracionSwiftService.confirmacionSolicitud(swfNumeraswf.get().getNroCodnro(), swfPersona.getPerIdverifica(), nroSwift);
	}
}
