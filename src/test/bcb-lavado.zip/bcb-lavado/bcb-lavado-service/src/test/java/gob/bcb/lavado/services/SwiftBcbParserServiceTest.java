package gob.bcb.lavado.services;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.commons.ArchivoSinpleServiceImpl;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfAsignamensajeDao;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.repository.SwfPersonaDao;
import gob.bcb.lavado.services.AdminInOutMsgService;
import gob.bcb.lavado.services.SwiftBcbParserService;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

public class SwiftBcbParserServiceTest extends ConfigBaseTest {
	private static final Logger log = LoggerFactory.getLogger(SwiftBcbParserServiceTest.class);

	@Autowired
	private SwiftBcbParserService swiftBcbParserService;
	@Autowired
	private SwfPersonaDao swfPersonaDao;
	@Autowired
	private AdminInOutMsgService adminInOutMsgService;
	@Autowired
	private SwfAsignamensajeDao swfAsignamensajeDao;
	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Before
	@Override
	public void before() throws Throwable {
		super.before();
		log.info("setup SwiftBcbParserService");
	}

	@Test(expected=SwiftAdminException.class)
	public void parserSwiftMalFormedTest() {
		String archSwift = "src/test/resources/swifts/swf_mal_formado_in.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		swiftBcbParserService.swiftDatosFromString(menPlano);
	}

	@Test(expected=SwiftAdminException.class)
	public void parserSwiftMalFormedOutTest() {
		String archSwift = "src/test/resources/swifts/swf_mal_formado.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);

		swiftBcbParserService.swiftDatosFromString(menPlano);
	}

	@Test
	public void parserSwiftTest() {
		String archSwift = "src/test/resources/swifts/swf_4632_ent.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		log.info("parserSwiftTest...");
		SwiftDatos swiftDatos = swiftBcbParserService.swiftDatosFromString(menPlano);
		swiftDatos.getSwfMensaje().setBlock4List(swiftBcbParserService.createListBlock4(swiftDatos.getSwiftMessageBcb(), true));
		
		Assert.assertTrue("Debe tener elementos", swiftDatos.getSwfMensaje().getBlock4List().size() > 0);
	}

	@Test
	public void extraerSwiftsDeLoteTest(){
		log.info("extraerSwiftsDeLoteTest...");
		final String archSwift = "src/test/resources/lotesentrantes/lote02.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		log.debug(UtilsGeneric.getShortText(menPlano, 88));

		List<MensajesDatos> mensajesDatosLista = swiftBcbParserService.swfMensajeFromLote(menPlano);
		Assert.assertTrue("Debe tener elementos", mensajesDatosLista.size() > 1);
	}

	@Test
	public void cargarGuardarAsiganarLoteTest() {
		// TEST DE CICLO COMPLETO MENSAJES ENTRANTES de carga de lote salvado en
		// bdd, , scaneo y asignacion de mensajes
		log.info("Happy Day!!! cargarGuardarAsiganarLoteTest ==========");
		
		SwfPersona swfPersona = new SwfPersona();
		swfPersona.setPerNombre("user test");
		swfPersona.setPerEmail("test@bcb.com");
		swfPersona.setPerPrefunidadorgs("153");

		swfPersona = swfPersonaDao.saveorupdate(swfPersona);
		Integer codpersona =swfPersona.getPerCodemp(); 
		String pathFile = "src/test/resources/lotesentrantes/lote_small.txt";
		String nameFileOriginal = "lote_small.txt";
		String menPlano = UtilsFile.readFileAsString2(pathFile);

		log.info(UtilsGeneric.getShortText(menPlano, 88));

		ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
		archivoSinpleService.fromPathfile(pathFile, nameFileOriginal);

		SwfLote swfLoteSelected = new SwfLote();
		swfLoteSelected.setLotNomorig(nameFileOriginal);

		List<MensajesDatos> mensajesDatosLista = adminInOutMsgService.desparsearLoteFromArchivoSinple(archivoSinpleService.getArchivoSinple(), "test");
		Assert.assertTrue("Debe tener elementos", mensajesDatosLista.size() > 0);

		swfLoteSelected = adminInOutMsgService.guardarLote(codpersona, swfLoteSelected, archivoSinpleService.getArchivoSinple(), mensajesDatosLista);
		log.info("Lote salvado " + swfLoteSelected.getLotNrolote());

		try {
			log.info("Esperando[" + mensajesDatosLista.size() + " seg.] procesos sync searching... " + swfLoteSelected.getLotNrolote());
			TimeUnit.SECONDS.sleep(mensajesDatosLista.size());
		} catch (Exception ex) {
			log.error("Error al esperrar " + ex.getMessage());
		}
		
		SwfMensaje swfMensajeSelected = new SwfMensaje();
		swfMensajeSelected.setMenInout(Constants.TIPO_MENSAJE_IN);		
		
		List<MensajesDatos> mensajesDatosSelectedLista = swfMensajeDao.buscarMensajesEntrantes(swfMensajeSelected, null,
				codpersona, Constants.TAB_ESTREVISION_PEND, null, null, codpersona);
		
		mensajesDatosSelectedLista.forEach(mensajesDatos -> {
			log.info("mensajesDatos " + mensajesDatos.getSwfMensaje().getBlock4List().size());
			mensajesDatos.getSwfMensaje().getBlock4List().forEach(b -> {
				log.info("mensajesDatos block " + b.getName() + " " + b.getValue());				
			});
		});
		
		swfPersona = new SwfPersona();
		swfPersona.setPerNombre("user test");
		swfPersona.setPerEmail("testtest@bcb.gob.bo");
		swfPersona.setPerPrefunidadorgs("153");

		swfPersona = swfPersonaDao.saveorupdate(swfPersona);
		Integer codpersonaDest =swfPersona.getPerCodemp(); 
		
		log.info("iniciando test asignacion mensajes ");
		Empleado empleado = new Empleado();
		empleado.setNroEmpleado(codpersonaDest);
		empleado.setNombre(swfPersona.getPerNombre());
		empleado.setEmail(swfPersona.getPerEmail());

		mensajesDatosLista.forEach(mensajesDatos -> {
			mensajesDatos.setSeleccionado(true);
			swfAsignamensajeDao.crearAsignacion(mensajesDatos.getSwfMensaje(), codpersonaDest, codpersona, null, Constants.TAB_ESTREVISION_ENPROC_ASIGNACION, "usertest","test");
		});

		log.info("Mensajes asignados " + mensajesDatosLista.size());
		adminInOutMsgService.asignarYEnviarMailDeNotificacion(mensajesDatosLista.get(0), codpersona,"usertest","estacion");
		receiveMail(true);

	}
	
	@Test(expected=RuntimeException.class)
	public void parserLoteConFormatoInvalidoTest() {
		log.info("parserLoteConFormatoInvalidoTest...");
		String archSwift = "src/test/resources/ofac/lista_indiv.xml";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		log.info(UtilsGeneric.getShortText(menPlano, 88));

		swiftBcbParserService.swfMensajeFromLote(menPlano);
	}
	
	@Test
	public void block4FromStringTest() {
		log.info("block4FromStringTest...");
		String archSwift = "src/test/resources/swifts/sioc2016000017.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		log.info(menPlano);

		List<Block4> block4List = swiftBcbParserService.block4FromString(menPlano);
		for (Block4 block4 : block4List) {
			log.info("______________________");			
			log.info(block4.getName() +  ":" + block4.getReference());
			log.info(block4.getValue() + " => " + block4.getValueDescrip());
		}
	}	
}
