--==============================================================
-- DBMS name:      INFORMIX SQL 11.x
-- Created on:     12/11/2016 21:58:21
--==============================================================


alter table GEN_DESCTABLA
   drop constraint FK_REF_GEN_TAB1;

alter table OFA_ADDRESSLIST
   drop constraint FK_ADDR_OFA_SDN;

alter table OFA_AKALIST
   drop constraint FK_AKALST_OFA_SDN;

alter table OFA_CITIZENSHIP
   drop constraint FK_CIT_OFA_SDN;

alter table OFA_DATEOFBIRTH
   drop constraint FK_DAB_OFA_SDN;

alter table OFA_IDLIST
   drop constraint FK_IDLST_OFA_SDN;

alter table OFA_NATIONALITY
   drop constraint FK_NAT_OFA_SDN;

alter table OFA_PLACEOFBIRTH
   drop constraint FK_BIR_OFA_SDN;

alter table OFA_VESSELINFO
   drop constraint FK_VES_OFA_SDN;

alter table SWF_ASIGNAMENSAJE
   drop constraint FK_REF_SWF_MEN2;

alter table SWF_ASIGNAMENSAJE
   drop constraint FK_REF_SWF_EMA1;

alter table SWF_ASIGNAMENSAJE
   drop constraint FK_REF_GEN_DES2;

alter table SWF_DETMENSAJE
   drop constraint FK_REF_SWF_MEN1;

alter table SWF_MENCAMPOS
   drop constraint FK_REF_SWF_TIP1;

alter table SWF_MENSAJE
   drop constraint FK_REF_SWF_TIP2;

alter table SWF_MENSAJE
   drop constraint FK_REFEREN_SWF_LOT;

drop table GEN_DESCTABLA;

drop table GEN_TABLAS;

drop table OFA_ADDRESSLIST;

drop table OFA_AKALIST;

drop table OFA_CITIZENSHIP;

drop table OFA_DATEOFBIRTH;

drop table OFA_IDLIST;

drop table OFA_NATIONALITY;

drop table OFA_PLACEOFBIRTH;

drop table OFA_PRIM;

alter table OFA_PUBLSHINFORM
   drop constraint AK_KEY_1_OFA_PUBL;

drop table OFA_PUBLSHINFORM;

alter table OFA_SDNENTRY
   drop constraint AK_KEY_2_OFA_SDNE;

drop table OFA_SDNENTRY;

drop table OFA_VESSELINFO;

drop index IDXASIGMEN_5;

drop index IDXASIGMEN_3;

drop index IDXASIGMEN_2;

drop table SWF_ASIGNAMENSAJE;

drop table SWF_BICS;

drop index IDXDETMEN_5;

drop table SWF_DETMENSAJE;

drop table SWF_LOTE;

drop table SWF_MENCAMPOS;

drop index IDXMENS_3;

drop index IDXMENS_2;

drop index IDXMENS_1;

drop table SWF_MENSAJE;

drop table SWF_PARAMS;

drop table SWF_PERSONA;

drop table SWF_TIPOMENSAJE;

--==============================================================
-- Table: GEN_DESCTABLA
--==============================================================

create table GEN_DESCTABLA  (
  DES_CODTAB           INTEGER                         not null,
  DES_CODIGO           INTEGER                         not null,
  DES_DESCRIP          VARCHAR(100)                    not null,
  DES_CODEISO          VARCHAR(15),
  DES_STATUS           VARCHAR(1)                     default "A" 
      check (DES_STATUS in ("A","S"))
      constraint CKC_DES_STAT_GEN_D,
  DES_AUDITUSR         VARCHAR(15),
  DES_AUDITFHO         DATETIME YEAR TO SECOND,
  DES_AUDITWST         VARCHAR(20),
primary key (DES_CODTAB, DES_CODIGO)
      constraint PK_GEN_DESCTABLA
);

--==============================================================
-- Table: GEN_TABLAS
--==============================================================

create table GEN_TABLAS  (
  TAB_CODIGO           INTEGER                         not null,
  TAB_DESCRIPCION      VARCHAR(50)                     not null,
primary key (TAB_CODIGO)
      constraint PK_GEN_TABLAS
);

--==============================================================
-- Table: OFA_ADDRESSLIST
--==============================================================

create table OFA_ADDRESSLIST  (
  ADR_UID              integer                         not null,
  ADR_ENTRYUID         integer                         not null,
  ADR_ADDRESS1         lvarchar(300),
  ADR_ADDRESS2         lvarchar(300),
  ADR_ADDRESS3         lvarchar(300),
  ADR_CITY             varchar(100),
  ADR_STATEORPROVINC   varchar(100),
  ADR_POSTALCODE       varchar(100),
  ADR_COUNTRY          varchar(100),
primary key (ADR_UID)
      constraint PK_OFA_ADDRESSLIST
);

--==============================================================
-- Table: OFA_AKALIST
--==============================================================

create table OFA_AKALIST  (
  AKA_UID              integer                         not null,
  AKA_ENTRYUID         integer                         not null,
  AKA_TYPE             varchar(50),
  AKA_CATEGORY         varchar(50),
  AKA_LASTNAME         lvarchar(300),
  AKA_FIRSTNAME        lvarchar(300),
primary key (AKA_UID)
      constraint PK_OFA_AKALIST
);

--==============================================================
-- Table: OFA_CITIZENSHIP
--==============================================================

create table OFA_CITIZENSHIP  (
  CIT_UID              integer                         not null,
  CIT_ENTRYUID         integer                         not null,
  CIT_COUNTRY          varchar(100),
  CIT_MAINENTRY        lvarchar(300),
primary key (CIT_UID)
      constraint PK_OFA_CITIZENSHIP
);

--==============================================================
-- Table: OFA_DATEOFBIRTH
--==============================================================

create table OFA_DATEOFBIRTH  (
  BIR_UID              integer                         not null,
  BIR_ENTRYUID         integer                         not null,
  BIR_DATEOFBIRTH      varchar(100),
  BIR_MAINENTRY        lvarchar(300),
primary key (BIR_UID)
      constraint PK_OFA_DATEOFBIRTH
);

--==============================================================
-- Table: OFA_IDLIST
--==============================================================

create table OFA_IDLIST  (
  IDL_UID              integer                         not null,
  IDL_ENTRYUID         integer,
  IDL_IDTYPE           varchar(50),
  IDL_IDNUMBER         varchar(50),
  IDL_IDCOUNTRY        varchar(50),
  IDL_ISSUEDATE        varchar(25),
  IDL_EXPIRATIONDATE   varchar(25),
primary key (IDL_UID)
      constraint PK_OFA_IDLIST
);

--==============================================================
-- Table: OFA_NATIONALITY
--==============================================================

create table OFA_NATIONALITY  (
  NAT_UID              integer                         not null,
  NAT_ENTRYUID         integer                         not null,
  NAT_COUNTRY          varchar(100),
  NAT_MAINENTRY        lvarchar(300),
primary key (NAT_UID)
      constraint PK_OFA_NATIONALITY
);

--==============================================================
-- Table: OFA_PLACEOFBIRTH
--==============================================================

create table OFA_PLACEOFBIRTH  (
  POB_UID              integer                         not null,
  POB_ENTRYUID         integer                         not null,
  POB_PLACEOFBIRTH     varchar(100),
  POB_MAINENTRY        lvarchar(300),
primary key (POB_UID)
      constraint PK_OFA_PLACEOFBIRT
);

--==============================================================
-- Table: OFA_PRIM
--==============================================================

create table OFA_PRIM  (
  PRI_CODLISTA         INTEGER                        default 1 not null,
  PRI_ENTNUM           INTEGER                         not null,
  PRI_SDNNAME          LVARCHAR(358),
  PRI_SDNTYPE          VARCHAR(15),
  PRI_PROGRAM          VARCHAR(50),
  PRI_TITLE            VARCHAR(200),
  PRI_CALLSIGN         VARCHAR(10),
  PRI_VESSTYPE         VARCHAR(30),
  PRI_TONNAGE          VARCHAR(15),
  PRI_GRT              VARCHAR(8),
  PRI_VESSFLAG         VARCHAR(50),
  PRI_VESSOWNER        VARCHAR(150),
  PRI_REMARKS          LVARCHAR(1000),
  PRI_TABSTATUS        INTEGER                        default 1,
  PRI_STATUS           INTEGER                        default 1,
  PRI_FECREG           DATE,
  PRI_CODUSR           VARCHAR(30),
  PRI_AUDITUSR         VARCHAR(30),
  PRI_AUDITFHO         DATETIME YEAR TO SECOND,
  PRI_AUDITWST         VARCHAR(30),
primary key (PRI_CODLISTA, PRI_ENTNUM)
      constraint PK_OFA_PRIM
);

--==============================================================
-- Table: OFA_PUBLSHINFORM
--==============================================================

create table OFA_PUBLSHINFORM  (
  PIN_PUBLISHDATE      varchar(20)                     not null,
  PIN_RECORDCOUNT      integer                         not null
);

alter table OFA_PUBLSHINFORM
   add constraint unique (PIN_PUBLISHDATE)
      constraint AK_KEY_1_OFA_PUBL;

--==============================================================
-- Table: OFA_SDNENTRY
--==============================================================

create table OFA_SDNENTRY  (
  SDN_ID               integer                         not null,
  SDN_ENTRYUID         integer                         not null,
  SDN_FIRSTNAME        LVARCHAR(300),
  SDN_LASTNAME         LVARCHAR(300),
  SDN_TITLE            LVARCHAR(300),
  SDN_SDNTYPE          LVARCHAR(300),
  SDN_REMARKS          LVARCHAR(1000),
  SDN_PROGRAMLIST      LVARCHAR(300),
primary key (SDN_ID)
      constraint PK_OFA_SDNENTRY
);

alter table OFA_SDNENTRY
   add constraint unique (SDN_ENTRYUID)
      constraint AK_KEY_2_OFA_SDNE;

--==============================================================
-- Table: OFA_VESSELINFO
--==============================================================

create table OFA_VESSELINFO  (
  VES_ENTRYUID         integer                         not null,
  VES_CALLSIGN         varchar(100),
  VES_VESSELTYPE       varchar(100),
  VES_VESSELFLAG       varchar(100),
  VES_VESSELOWNER      varchar(100),
  VES_TONNAGE          varchar(100),
  VES_GROSSREGISTERE   varchar(100),
primary key (VES_ENTRYUID)
      constraint PK_OFA_VESSELINFO
);

--==============================================================
-- Table: SWF_ASIGNAMENSAJE
--==============================================================

create table SWF_ASIGNAMENSAJE  (
  RES_CODMEN           INTEGER                         not null,
  RES_CODEMP           INTEGER                         not null,
  RES_TABESTREVISION   INTEGER                        default 2,
  RES_ESTREVISION      INTEGER                        default 1,
  RES_FECHORAASIGNA    DATETIME YEAR TO SECOND,
  RES_FECHORAREVISA    DATETIME YEAR TO SECOND,
  RES_CODEMPPADRE      INTEGER,
  RES_CORRASIGNA       INTEGER,
  RES_GLOSA            VARCHAR(238),
  RES_ARECOD           VARCHAR(10),
  RES_NOTIF            VARCHAR(1)                     default "N",
  RES_AUDITUSR         VARCHAR(30),
  RES_AUDITFHO         DATETIME YEAR TO SECOND,
  RES_AUDITWST         VARCHAR(30),
primary key (RES_CODMEN, RES_CODEMP)
      constraint PK_SWF_ASIGNAMENSA
);

--==============================================================
-- Index: IDXASIGMEN_2
--==============================================================
create   index IDXASIGMEN_2 on SWF_ASIGNAMENSAJE (
        RES_CODEMP           ASC,
        RES_ESTREVISION      ASC,
        RES_CODEMPPADRE      ASC
);

--==============================================================
-- Index: IDXASIGMEN_3
--==============================================================
create   index IDXASIGMEN_3 on SWF_ASIGNAMENSAJE (
        RES_TABESTREVISION   ASC,
        RES_ESTREVISION      ASC
);

--==============================================================
-- Index: IDXASIGMEN_5
--==============================================================
create   index IDXASIGMEN_5 on SWF_ASIGNAMENSAJE (
        RES_ARECOD           ASC
);

--==============================================================
-- Table: SWF_BICS
--==============================================================

create table SWF_BICS  (
  BIC_CODBIC           varchar(30)                     not null,
  BIC_CODBRANCH        varchar(30)                     not null,
  BIC_DESCRIP          varchar(238),
  BIC_CIUDAD           varchar(238),
  BIC_DIRECC1          varchar(238),
  BIC_DIRECC2          varchar(238),
  BIC_PAIS             varchar(238),
primary key (BIC_CODBIC, BIC_CODBRANCH)
      constraint PK_SWF_BICS
);

--==============================================================
-- Table: SWF_DETMENSAJE
--==============================================================

create table SWF_DETMENSAJE  (
  DEM_CODMEN           INTEGER                         not null,
  DEM_NROCORR          INTEGER                         not null,
  DEM_CODMT            VARCHAR(20)                     not null,
  DEM_CODCAMPO         VARCHAR(20)                     not null,
  DEM_VALOR            LVARCHAR(6000),
primary key (DEM_CODMEN, DEM_NROCORR)
      constraint PK_SWF_DETMENSAJE
);

--==============================================================
-- Index: IDXDETMEN_5
--==============================================================
create   index IDXDETMEN_5 on SWF_DETMENSAJE (
        DEM_CODMEN           ASC,
        DEM_CODMT            ASC,
        DEM_CODCAMPO         ASC
);

--==============================================================
-- Table: SWF_LOTE
--==============================================================

create table SWF_LOTE  (
  LOT_NROLOTE          INTEGER                         not null,
  LOT_FECHORA          DATETIME YEAR TO SECOND,
  LOT_PATHFILE         VARCHAR(240),
  LOT_NOMORIG          VARCHAR(240),
  LOT_HASH             VARCHAR(100),
  LOT_AUDITUSR         VARCHAR(30),
  LOT_AUDITFHO         DATETIME YEAR TO SECOND,
  LOT_AUDITWST         VARCHAR(30),
primary key (LOT_NROLOTE)
      constraint PK_SWF_LOTE
);

--==============================================================
-- Table: SWF_MENCAMPOS
--==============================================================

create table SWF_MENCAMPOS  (
  MTF_CODMT            VARCHAR(20)                     not null,
  MTF_CODCAMPO         VARCHAR(20)                     not null,
  MTF_NRO              INTEGER                         not null,
  MTF_DESCRIP          VARCHAR(200),
  MTF_REGLAVALID       VARCHAR(50),
  MTF_STATUS           VARCHAR(2),
primary key (MTF_CODCAMPO, MTF_CODMT, MTF_NRO)
      constraint PK_SWF_MENCAMPOS
);

--==============================================================
-- Table: SWF_MENSAJE
--==============================================================

create table SWF_MENSAJE  (
  MEN_CODMEN           INTEGER                         not null,
  MEN_NROSWIFT         VARCHAR(10),
  MEN_NROCORR          INTEGER,
  MEN_CODMT            VARCHAR(20),
  MEN_PLANO            LVARCHAR(11000),
  MEN_NROLOTE          INTEGER,
  MEN_CODSWIFT         VARCHAR(100),
  MEN_EMISOR           VARCHAR(100),
  MEN_BIC              VARCHAR(10),
  MEN_BICCODCTRL       VARCHAR(2),
  MEN_BICBRANCH        VARCHAR(5),
  MEN_CODMON           INTEGER,
  MEN_REFER            VARCHAR(248),
  MEN_DESTINATARIO     VARCHAR(100),
  MEN_FECREG           DATETIME YEAR TO SECOND,
  MEN_TABESTMENSAJE    INTEGER                        default 3,
  MEN_ESTMENSAJE       INTEGER                        default 1,
  MEN_GESTION          INTEGER,
  MEN_AUDITUSR         VARCHAR(30),
  MEN_AUDITFHO         DATETIME YEAR TO SECOND,
  MEN_AUDITWST         VARCHAR(30),
primary key (MEN_CODMEN)
      constraint PK_SWF_MENSAJE
);

--==============================================================
-- Index: IDXMENS_1
--==============================================================
create   index IDXMENS_1 on SWF_MENSAJE (
        MEN_BIC              ASC,
        MEN_BICBRANCH        ASC
);

--==============================================================
-- Index: IDXMENS_2
--==============================================================
create   index IDXMENS_2 on SWF_MENSAJE (
        MEN_FECREG           ASC
);

--==============================================================
-- Index: IDXMENS_3
--==============================================================
create   index IDXMENS_3 on SWF_MENSAJE (
        MEN_TABESTMENSAJE    ASC,
        MEN_ESTMENSAJE       ASC
);

--==============================================================
-- Table: SWF_PARAMS
--==============================================================

create table SWF_PARAMS  (
  PAR_CODPAR           VARCHAR(30)                     not null,
  PAR_DESCRIP          VARCHAR(240)                    not null,
  PAR_VALOR            VARCHAR(240)                    not null,
primary key (PAR_CODPAR)
      constraint PK_SWF_PARAMS
);

--==============================================================
-- Table: SWF_PERSONA
--==============================================================

create table SWF_PERSONA  (
  PER_CODEMP           INTEGER                         not null,
  PER_NOMBRE           VARCHAR(100),
  PER_EMAIL            VARCHAR(50),
  PER_PREFUNIDADORGS   VARCHAR(238),
  PER_ARECOD           VARCHAR(10),
  PER_AUDITUSR         VARCHAR(30),
  PER_AUDITFHO         DATETIME YEAR TO SECOND,
  PER_AUDITWST         VARCHAR(30),
primary key (PER_CODEMP)
      constraint PK_SWF_PERSONA
);

--==============================================================
-- Table: SWF_TIPOMENSAJE
--==============================================================

create table SWF_TIPOMENSAJE  (
  TIM_CODMT            VARCHAR(20)                     not null,
  TIM_DESCRIP          VARCHAR(150)                    not null,
  TIM_INFO             CHAR(3800),
  TIM_TABTIPMENSA      INTEGER,
  TIM_TIPMENSA         INTEGER,
primary key (TIM_CODMT)
      constraint PK_SWF_TIPOMENSAJE
);

alter table GEN_DESCTABLA
   add constraint foreign key (DES_CODTAB)
      references GEN_TABLAS (TAB_CODIGO) 
      constraint FK_REF_GEN_TAB1;

alter table OFA_ADDRESSLIST
   add constraint foreign key (ADR_ENTRYUID)
      references OFA_SDNENTRY (SDN_ID) 
      constraint FK_ADDR_OFA_SDN;

alter table OFA_AKALIST
   add constraint foreign key (AKA_ENTRYUID)
      references OFA_SDNENTRY (SDN_ID) 
      constraint FK_AKALST_OFA_SDN;

alter table OFA_CITIZENSHIP
   add constraint foreign key (CIT_ENTRYUID)
      references OFA_SDNENTRY (SDN_ID) 
      constraint FK_CIT_OFA_SDN;

alter table OFA_DATEOFBIRTH
   add constraint foreign key (BIR_ENTRYUID)
      references OFA_SDNENTRY (SDN_ID) 
      constraint FK_DAB_OFA_SDN;

alter table OFA_IDLIST
   add constraint foreign key (IDL_ENTRYUID)
      references OFA_SDNENTRY (SDN_ENTRYUID) 
      constraint FK_IDLST_OFA_SDN;

alter table OFA_NATIONALITY
   add constraint foreign key (NAT_ENTRYUID)
      references OFA_SDNENTRY (SDN_ID) 
      constraint FK_NAT_OFA_SDN;

alter table OFA_PLACEOFBIRTH
   add constraint foreign key (POB_ENTRYUID)
      references OFA_SDNENTRY (SDN_ID) 
      constraint FK_BIR_OFA_SDN;

alter table OFA_VESSELINFO
   add constraint foreign key (VES_ENTRYUID)
      references OFA_SDNENTRY (SDN_ID) 
      constraint FK_VES_OFA_SDN;

alter table SWF_ASIGNAMENSAJE
   add constraint foreign key (RES_CODMEN)
      references SWF_MENSAJE (MEN_CODMEN) 
      constraint FK_REF_SWF_MEN2;

alter table SWF_ASIGNAMENSAJE
   add constraint foreign key (RES_CODEMP)
      references SWF_PERSONA (PER_CODEMP) 
      constraint FK_REF_SWF_EMA1;

alter table SWF_ASIGNAMENSAJE
   add constraint foreign key (RES_TABESTREVISION, RES_ESTREVISION)
      references GEN_DESCTABLA (DES_CODTAB, DES_CODIGO) 
      constraint FK_REF_GEN_DES2;

alter table SWF_DETMENSAJE
   add constraint foreign key (DEM_CODMEN)
      references SWF_MENSAJE (MEN_CODMEN) 
      constraint FK_REF_SWF_MEN1;

alter table SWF_MENCAMPOS
   add constraint foreign key (MTF_CODMT)
      references SWF_TIPOMENSAJE (TIM_CODMT) 
      constraint FK_REF_SWF_TIP1;

alter table SWF_MENSAJE
   add constraint foreign key (MEN_CODMT)
      references SWF_TIPOMENSAJE (TIM_CODMT) 
      constraint FK_REF_SWF_TIP2;

alter table SWF_MENSAJE
   add constraint foreign key (MEN_NROLOTE)
      references SWF_LOTE (LOT_NROLOTE) 
      constraint FK_REFEREN_SWF_LOT;

