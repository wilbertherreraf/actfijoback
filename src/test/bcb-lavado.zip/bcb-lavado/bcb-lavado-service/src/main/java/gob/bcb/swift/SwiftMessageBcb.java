package gob.bcb.swift;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.io.parser.SwiftParser;
import com.prowidesoftware.swift.model.SwiftBlock1;
import com.prowidesoftware.swift.model.SwiftBlock2;
import com.prowidesoftware.swift.model.SwiftBlock2Input;
import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.SwiftBlock3;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftBlock5;
import com.prowidesoftware.swift.model.SwiftBlockUser;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;

import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.iso20022.pojo.Block4;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;

/**
 * Mantiene los datos de un mensaje swift desparseado
 * 
 * @author wherrera
 *
 */
public class SwiftMessageBcb {
	private static final Logger log = LoggerFactory.getLogger(SwiftMessageBcb.class);
	public final static String nameUserBlockS = "S";
	public final static String nameUserBlockS_MDG = "MDG";	
	private String menPlano;
	private String menPlanoSinUser;
	private String hash;	
	private SwiftMessage swiftMessage = new SwiftMessage();
	private SwiftBlock1 block1= new SwiftBlock1();
	private SwiftBlock2 block2;
	private SwiftBlock2Input swiftBlock2Input= new SwiftBlock2Input();
	private SwiftBlock2Output swiftBlock2Output  = new SwiftBlock2Output();
	private SwiftBlock3 block3= new SwiftBlock3();
	private SwiftBlock4 block4= new SwiftBlock4();
	private SwiftBlock5 block5= new SwiftBlock5();
	private SwiftBlockUser blockUserS = new SwiftBlockUser(nameUserBlockS);
	
//	public SwiftMessageBcb() {
//		inicializar();
//		menPlano = "";
//	}

	public SwiftMessageBcb(String menPlano) {
		inicializar();
		this.menPlano = menPlano;
	}

	private void inicializar() {
		swiftMessage.setBlock1(block1);
		swiftMessage.setBlock3(block3);
		swiftMessage.setBlock4(block4);
		swiftMessage.setBlock5(block5);
	}

	public Field getField(String fieldName) {
		Field field = block4.getFieldByName(fieldName);
		return field;
	}

	public String FIN() {
		return swiftMessage.toMT().message();
	}

	public String FINSinUserBlock() {
		return swiftMessage.toMT().message();
	}
	
	public void fromString(String swiftPlano) throws IOException {
		if (StringUtils.isBlank(swiftPlano)) {
			throw new RuntimeException("Parametro swift Plano (RJE) nulo");
		}
		SwiftMessage swiftMessageaux = new SwiftMessage();

		SwiftParser swiftParser = new SwiftParser(swiftPlano);
		swiftMessage = swiftParser.message();

		block1 = swiftMessage.getBlock1();
		swiftMessageaux.setBlock1(block1);
		if (block1 == null){
			throw new RuntimeException("El texto no corresponde a un mensaje swift (RJE)");
		}
		block2 = swiftMessage.getBlock2();

		// mensajes salientes desde el bcb
		if (block2 != null)
			if (block2 instanceof SwiftBlock2Input)
				swiftBlock2Input = (SwiftBlock2Input) block2;
			// mensajes entrantes desde el bcb
			else if (block2 instanceof SwiftBlock2Output)
				swiftBlock2Output = (SwiftBlock2Output) block2;
		
		swiftMessageaux.setBlock2(block2);
		
		block3 = swiftMessage.getBlock3();
		block4 = swiftMessage.getBlock4();
		block5 = swiftMessage.getBlock5();

		swiftMessageaux.setBlock3(block3);
		swiftMessageaux.setBlock4(block4);
		swiftMessageaux.setBlock5(block5);
		menPlanoSinUser = swiftMessageaux.toMT().message();
		log.info("AAAAAAAAAAAAAAAAAAAAAAAA");
		log.info(menPlanoSinUser);
		log.info("AAAAAAAAAAAAAAAAAAAAAAAA");
		blockUserS = swiftMessage.getUserBlock(nameUserBlockS);
	}
	
	public boolean isValid() {
		return !((menPlano == null || menPlano.trim().length() == 0) || (swiftMessage.getBlockCount() <= 3) || (swiftMessage.getType() == null)
				|| (swiftMessage.getSender() == null) || (swiftMessage.getReceiver() == null)
				|| (block4 == null || block4.isEmpty() || block4.getTags().size() <= 1));
	}

	public SwiftBlock1 getBlock1() {
		return block1;
	}

	public void setBlock1(SwiftBlock1 block1) {
		this.block1 = block1;
	}

	public SwiftBlock2 getBlock2() {
		return block2;
	}

	public void setBlock2(SwiftBlock2 block2) {
		this.block2 = block2;
	}

	public SwiftBlock3 getBlock3() {
		return block3;
	}

	public void setBlock3(SwiftBlock3 block3) {
		this.block3 = block3;
	}

//	public SwiftBlock4 getBlock4() {
//		return block4;
//	}

	public void setBlock4(SwiftBlock4 block4) {
		this.block4 = block4;
	}

	public SwiftBlock5 getBlock5() {
		return block5;
	}

	public void setBlock5(SwiftBlock5 block5) {
		this.block5 = block5;
	}

	public SwiftBlockUser getBlockUserS() {
		return blockUserS;
	}

	public void setBlockUserS(SwiftBlockUser blockUserS) {
		this.blockUserS = blockUserS;
	}	
	
	public SwiftMessage getSwiftMessage() {
		return swiftMessage;
	}

	public void setSwiftMessage(SwiftMessage swiftMessage) {
		this.swiftMessage = swiftMessage;
	}

	public SwiftBlock2Output getSwiftBlock2Output() {
		return swiftBlock2Output;
	}

	public void setSwiftBlock2Output(SwiftBlock2Output swiftBlock2Output) {
		this.swiftBlock2Output = swiftBlock2Output;
	}

	public String getMenPlano() {
		return menPlano;
	}

	public String checkSum(String... exceptFields) {
		if (menPlano == null || menPlano.trim().length() == 0) {
			hash = "";
			return hash;
		}
		hash = ArchivoUtil.hashString(menPlano);
		return hash;
		
	}

	public boolean isSimilar(Object obj, String... exceptFields) {
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SwiftMessageBcb other = (SwiftMessageBcb) obj;
		return this.checkSum(exceptFields).equals(other.checkSum(exceptFields));
	}

	public String getHash() {
		if (hash == null)
			hash = checkSum();
		return hash;
	}

	public SwiftBlockUser addTagBlockUser(String blockName, String tagname, String value) {
		value = value.trim();
		tagname = tagname.trim();
		
		Tag tag = new Tag(tagname, value);
		List<Tag> tagsBlockUser = new ArrayList<Tag>();
		tagsBlockUser.add(tag);

		SwiftBlockUser swiftBlockUser = new SwiftBlockUser(blockName, tagsBlockUser);
		return swiftBlockUser;
	}
	
	/**
	 * Agrega el bloque S el tag de LAU MDG, si existe el bloque S lo agrega 
	 * @param codeLau codigo LAU del mensaje 
	 */
	public void addBlockLAU0(final String codeLau, boolean replaceValue){
		Tag tag = new Tag(nameUserBlockS_MDG, codeLau);		
		blockUserS = swiftMessage.getUserBlock(nameUserBlockS);
		if (blockUserS != null){
			Tag tagLAU = blockUserS.getTagByName(nameUserBlockS_MDG);
			if (tagLAU != null) {
//				log.info("Mensaje contiene TAG LAU {}: {}", tagLAU.getName(), tagLAU.getValue());
				if (replaceValue){
//					log.info("Mensaje contiene TAG LAU {}: {} reemplazando por {}", tagLAU.getName(), tagLAU.getValue(), codeLau);
					tagLAU.setValue(codeLau);
				}
				return;
			} 
			blockUserS.append(tag);
		} else {
			List<Tag> tagsBlockUser = new ArrayList<Tag>();
			tagsBlockUser.add(tag);
			blockUserS = new SwiftBlockUser(nameUserBlockS, tagsBlockUser);
			swiftMessage.addBlock(blockUserS);			
		}
	}
	
	public String getTagCodeLau(){
		SwiftBlockUser blockUserS = swiftMessage.getUserBlock(nameUserBlockS);
		if (blockUserS != null){
			Tag tagLAU = blockUserS.getTagByName(nameUserBlockS_MDG);
			if (tagLAU != null) {
				return tagLAU.getValue(); 
			}
		}
		return null; 
	}

	public String getMenPlanoSinUser() {
		return menPlanoSinUser;
	}


}
