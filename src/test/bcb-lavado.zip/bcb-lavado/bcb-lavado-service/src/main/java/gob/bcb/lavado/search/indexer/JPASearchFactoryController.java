package gob.bcb.lavado.search.indexer;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.hibernate.search.SearchFactory;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.query.dsl.QueryContextBuilder;

/**
 * This interface is the main entry point to get Search working in your JPA application
 *
 */
public interface JPASearchFactoryController {
	/**
	 * @param em may be null if you only want to do index related operations
	 */
	FullTextEntityManager getFullTextEntityManager(EntityManager em);

	/**
	 * closes this Controller and all underlying resources
	 */
	void close();

	EntityManagerFactory getEntityManagerFactory();

	void init();

	EntityManager createEntityManager();

	SearchFactory getSearchFactory();

	FullTextEntityManager getFullTextEntityManager();
}
