package gob.bcb.lavado.pojos;

import java.io.Serializable;

import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfPersona;

public class Asignacion implements Serializable {
	private Empleado empleado = new Empleado();
	private SwfAsignamensaje swfAsignamensaje = new SwfAsignamensaje();
	private UnidadOrgCoin unidadOrgCoin = new UnidadOrgCoin();
	private SwfPersona swfPersona = new SwfPersona();
	private SwfPersona swfPersonaPadre = new SwfPersona();

	public Empleado getEmpleado() {
		return empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

	public SwfAsignamensaje getSwfAsignamensaje() {
		return swfAsignamensaje;
	}

	public void setSwfAsignamensaje(SwfAsignamensaje swfAsignamensaje) {
		this.swfAsignamensaje = swfAsignamensaje;
	}

	public UnidadOrgCoin getUnidadOrgCoin() {
		return unidadOrgCoin;
	}

	public void setUnidadOrgCoin(UnidadOrgCoin unidadOrgCoin) {
		this.unidadOrgCoin = unidadOrgCoin;
	}

	public SwfPersona getSwfPersona() {
		return swfPersona;
	}

	public void setSwfPersona(SwfPersona swfPersona) {
		this.swfPersona = swfPersona;
	}

	public SwfPersona getSwfPersonaPadre() {
		return swfPersonaPadre;
	}

	public void setSwfPersonaPadre(SwfPersona swfPersonaPadre) {
		this.swfPersonaPadre = swfPersonaPadre;
	}
}
