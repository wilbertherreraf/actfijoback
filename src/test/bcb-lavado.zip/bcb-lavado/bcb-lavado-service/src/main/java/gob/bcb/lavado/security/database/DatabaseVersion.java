package gob.bcb.lavado.security.database;

/**
 * A Database version. Currently the version is simply a major int id that
 * should be incremented for each change set applied to the Database.
 * 
 */
public class DatabaseVersion {

	private final int major;

	/**
	 * Parse a DatabaseVersion from a String.
	 */
	public static DatabaseVersion valueOf(String string) {
		return new DatabaseVersion(Integer.valueOf(string));
	}

	/**
	 * The zero database version indicating no database has been installed.
	 */
	public static DatabaseVersion zero() {
		return new DatabaseVersion(0);
	}

	public boolean equals(Object o) {
		if (!(o instanceof DatabaseVersion)) {
			return false;
		}
		DatabaseVersion version = (DatabaseVersion) o;
		return major == version.major;
	}

	public int hashCode() {
		return major * 29;
	}

	/**
	 * True if this DatabaseVersion is less than the version provided.
	 */
	public boolean lessThan(DatabaseVersion version) {
		return major < version.major;
	}

	/**
	 * True if this DatabaseVersion is greater than the version provided.
	 */
	public boolean greaterThan(DatabaseVersion version) {
		return major > version.major;
	}

	private DatabaseVersion(int major) {
		this.major = major;
	}

	public String toString() {
		return String.valueOf(major);
	}
}
