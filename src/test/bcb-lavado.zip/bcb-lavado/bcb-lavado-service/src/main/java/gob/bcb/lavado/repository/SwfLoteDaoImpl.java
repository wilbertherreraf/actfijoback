package gob.bcb.lavado.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfLote;

@Repository("swfLoteDao")
@Transactional
public class SwfLoteDaoImpl implements SwfLoteDao {
	private static final Logger log = LoggerFactory.getLogger(SwfLoteDaoImpl.class);

//	@Autowired
//	private LavadoProperties lavadoProperties;
	@Autowired
	private AppProperties appProperties;
	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;

	@Autowired
	@Qualifier("entityManagerFactory")
	private EntityManagerFactory entityManagerFactory;

	public SwfLote findByCodigo(Integer lotNrolote) {
		String jpql = "SELECT t FROM SwfLote t WHERE t.lotNrolote = :lotNrolote ";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("lotNrolote", lotNrolote);
		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfLote) lista.get(0);
		}
		return null;
	}

	public List<SwfLote> findByTipolote(String lotTipolote) {
		String jpql = "SELECT t FROM SwfLote t WHERE t.lotTipolote = :lotTipolote ";
		jpql = jpql.concat("AND exists(select 1 from OfaSdnentry o where o.sdnNrolote = t.lotNrolote) ");
		Query query = entityManager.createQuery(jpql);
		query.setParameter("lotTipolote", lotTipolote);
		List lista = query.getResultList();
		return lista;
	}
	
	public SwfLote saveOrUpdate(SwfLote swfLote) {
		log.info("En  saveOrUpdate contrato ");

		if (swfLote.getLotNrolote() == null) {
			Integer perCodigo = getCodigo();

			swfLote.setLotNrolote(perCodigo);
			entityManager.persist(swfLote);
			log.info("nuevo " + swfLote.toString());
		} else {
			entityManager.merge(swfLote);

		}
		swfLote = findByCodigo(swfLote.getLotNrolote());
		return swfLote;
	}

	/**
	 * Guarda el archivo XML OFAC en un directorio 
	 */
	public SwfLote guardarLoteOfac(String codEmpleado, ArchivoSinple archivoSinple, boolean grabaEnDirectorio, String estacion) {
		if (archivoSinple == null) {
			throw new SwiftAdminException("Datos de archivo cargado nulo");
		}
		SwfLote swfLoteNew = new SwfLote();

		Integer perCodigo = getCodigo();
		
		if (archivoSinple.getDirectory() == null)
			throw new SwiftAdminException("Parametro directorio en objeto archivoSinple nulo");
		
		archivoSinple.setName(archivoSinple.getHash());
		archivoSinple.putPathFile();

		swfLoteNew.setLotPathfile(archivoSinple.getPathFile());
		swfLoteNew.setLotHash(archivoSinple.getHash());
		swfLoteNew.setLotNomorig(archivoSinple.getNameOriginal());
		swfLoteNew.setLotTipolote(Constants.TIPO_LOT_TIPOLOTE_OFAC);
		swfLoteNew.setLotFechora(new Date());
		swfLoteNew.setLotAuditfho(new Date());
		swfLoteNew.setLotAuditusr(codEmpleado);
		swfLoteNew.setLotAuditwst(estacion);
		swfLoteNew.setLotNrolote(perCodigo);
		entityManager.persist(swfLoteNew);
		
		if (grabaEnDirectorio){
			UtilsFile.grabaEnArchivo(archivoSinple.getStream(), archivoSinple.getPathFile());
			log.info(
					"Nuevo SDN lote [" + swfLoteNew.getLotNrolote() + "] SALVADO!!! EN " + swfLoteNew.getLotPathfile() + " HASH " + swfLoteNew.getLotHash());
		} else {
			log.info("Nuevo SDN lote creado(sin guardar): " + perCodigo);
		}
		return swfLoteNew;
	}
	
/**
 * guarda un archivo de lo lte con formato RJE
 */
	public SwfLote guardarLote(Integer codEmpleado, SwfLote swfLoteNew, ArchivoSinple archivoSinple) {
		if (archivoSinple == null)
			throw new SwiftAdminException("Datos de archivo de lote swift nulo");
		if (swfLoteNew.getLotNrolote() != null) {
			throw new SwiftAdminException("Lote swift con id[" + swfLoteNew.getLotNrolote() + "] generado, posiblemente ya fue guardado repita el proceso.");
		}

		Integer perCodigo = getCodigo();
		archivoSinple.setDirectory(appProperties.getLavado().getAppdir() + "/" + Constants.DIR_LOTES);
		archivoSinple.setName(perCodigo + "_" + archivoSinple.getHash());
		archivoSinple.putPathFile();

		swfLoteNew.setLotPathfile(archivoSinple.getPathFile());
		swfLoteNew.setLotHash(archivoSinple.getHash());
		swfLoteNew.setLotNomorig(archivoSinple.getNameOriginal());
		swfLoteNew.setLotFechora(new Date());
		swfLoteNew.setLotTipolote(Constants.TIPO_LOT_TIPOLOTE_SWIFT);
		swfLoteNew.setLotAuditusr(String.valueOf((codEmpleado == null ? "" : codEmpleado)));
		swfLoteNew.setLotNrolote(perCodigo);

		entityManager.persist(swfLoteNew);

		return findByCodigo(perCodigo);
	}

	private Integer getCodigo() {
		Integer codigo = null;
		StringBuilder query = new StringBuilder();
		query.append("select max(m.lotNrolote) from SwfLote m");

		List result = entityManager.createQuery(query.toString()).getResultList();
		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.info("Nuevo codigo : " + codigo);
		return codigo;

	}

}
