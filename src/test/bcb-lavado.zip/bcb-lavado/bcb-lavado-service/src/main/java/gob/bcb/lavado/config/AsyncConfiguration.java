package gob.bcb.lavado.config;

import java.util.Arrays;
import java.util.concurrent.Executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.aop.interceptor.SimpleAsyncUncaughtExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import gob.bcb.lavado.commons.ExceptionHandlingAsyncTaskExecutor;

@Configuration
@EnableAsync
@EnableScheduling
public class AsyncConfiguration implements AsyncConfigurer {

	private final Logger log = LoggerFactory.getLogger(AsyncConfiguration.class);

	@Autowired
	private AppProperties appProperties;
	@Autowired
	private Environment env;
	
	@Override
	@Bean(name = "taskExecutor")
	public Executor getAsyncExecutor() {
		log.info("oooooooooo Creating Async Task Executor oooooooooo.." + (env == null));
		log.info("UUUUUUUUUUUUUUUUUUUUUUUUUUUUU");		
		log.info("server.port : " +  env.getProperty("server.port"));
		log.info("server.port : " +  env.getProperty("spring.server.port"));		
		log.info("server.address: " + env.getProperty("server.address"));
		log.info("server.contextPath: " + env.getProperty("server.contextPath"));
		log.info("spring.application.name: " + env.getProperty("spring.application.name"));		
		log.info("Running with Spring profile(s) : {}", Arrays.toString(env.getActiveProfiles()));
		log.info("Running with spring.config.location: " + env.getProperty("spring.config.location"));
		

		log.info("Creating Async Task Executor " + appProperties.getAsync().getCorePoolSize());
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(appProperties.getAsync().getCorePoolSize());
		executor.setMaxPoolSize(appProperties.getAsync().getMaxPoolSize());
		executor.setQueueCapacity(appProperties.getAsync().getQueueCapacity());
		executor.setThreadNamePrefix("lavado-Executor-");
		return new ExceptionHandlingAsyncTaskExecutor(executor);
	}

	@Override
	public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
		return new SimpleAsyncUncaughtExceptionHandler();
	}

	@Bean(name = "taskScheduler")
	public TaskScheduler scheduler() {
		log.info("oooooooooo Creating Task Scheduler oooooooooo");
		ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
		taskScheduler.setPoolSize(5);
		taskScheduler.setThreadNamePrefix("ThreadPoolTaskScheduler-");
		return taskScheduler;
	}
}
