package gob.bcb.lavado.strategy;

public class QueryTemplate {
	private String id;
	private String[] fields;
	private String queryTemplate;
	private int distanceUpTo;
	private int prefixLength;
	private int slop = 0;
	private int minWordLen;
	private int minTerms;
	private String typeQ;
	private boolean inOrder = true;
	private boolean exceptNumbers = false;
	private String analyzer;
	private String andOr="AND";
	private String clazz;	
	private Validator validator;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String[] getFields() {
		return fields;
	}

	public void setFields(String[] fields) {
		this.fields = fields;
	}

	public String getQueryTemplate() {
		return queryTemplate;
	}

	public void setQueryTemplate(String queryTemplate) {
		this.queryTemplate = queryTemplate;
	}

	public int getDistanceUpTo() {
		return distanceUpTo;
	}

	public void setDistanceUpTo(int distanceUpTo) {
		this.distanceUpTo = distanceUpTo;
	}

	public int getPrefixLength() {
		return prefixLength;
	}

	public void setPrefixLength(int prefixLength) {
		this.prefixLength = prefixLength;
	}

	public int getSlop() {
		return slop;
	}

	public void setSlop(int slop) {
		this.slop = slop;
	}

	public boolean isInOrder() {
		return inOrder;
	}

	public void setInOrder(boolean inOrder) {
		this.inOrder = inOrder;
	}

	public String getAnalyzer() {
		return analyzer;
	}

	public void setAnalyzer(String analyzer) {
		this.analyzer = analyzer;
	}

	public Validator getValidator() {
		return validator;
	}

	public void setValidator(Validator validator) {
		this.validator = validator;
	}

	public String getClazz() {
		return clazz;
	}

	public void setClazz(String clazz) {
		this.clazz = clazz;
	}
	
	public String getAndOr() {
		return andOr;
	}

	public void setAndOr(String andOr) {
		this.andOr = andOr;
	}

	public int getMinWordLen() {
		return minWordLen;
	}

	public void setMinWordLen(int minWordLen) {
		this.minWordLen = minWordLen;
	}

	public String getTypeQ() {
		return typeQ;
	}

	public void setTypeQ(String typeQ) {
		this.typeQ = typeQ;
	}

	public boolean isExceptNumbers() {
		return exceptNumbers;
	}

	public void setExceptNumbers(boolean exceptNumbers) {
		this.exceptNumbers = exceptNumbers;
	}

	public int getMinTerms() {
		return minTerms;
	}

	public void setMinTerms(int minTerms) {
		this.minTerms = minTerms;
	}

	public class Validator{
		private int expectedFields;
		private boolean validateTerms;
		private float peso = 1.0f;
		private int expectedMatches = 0;
		private int minExpectedMatches;
		private String type = "SIMPLE";
		public int getExpectedFields() {
			return expectedFields;
		}
		public void setExpectedFields(int expectedFields) {
			this.expectedFields = expectedFields;
		}
		public boolean isValidateTerms() {
			return validateTerms;
		}
		public void setValidateTerms(boolean validateTerms) {
			this.validateTerms = validateTerms;
		}
		public int getExpectedMatches() {
			return expectedMatches;
		}
		public void setExpectedMatches(int expectedMatches) {
			this.expectedMatches = expectedMatches;
		}
		public int getMinExpectedMatches() {
			return minExpectedMatches;
		}
		public void setMinExpectedMatches(int minExpectedMatches) {
			this.minExpectedMatches = minExpectedMatches;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}		
	}
	
}
