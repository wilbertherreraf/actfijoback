package gob.bcb.lavado.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfBicsPK;

//public interface BancosRepository extends JpaRepository<SwfBics, SwfBicsPK>{
public interface BancosRepository{	

	Page<SwfBics> findAll(Pageable pageable);

}
