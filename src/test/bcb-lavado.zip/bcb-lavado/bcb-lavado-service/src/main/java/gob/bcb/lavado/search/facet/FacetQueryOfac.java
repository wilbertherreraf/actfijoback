package gob.bcb.lavado.search.facet;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang.ArrayUtils;
import org.apache.lucene.document.Document;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.highlight.QueryScorer;
import org.hibernate.search.engine.ProjectionConstants;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.transform.ResultTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.search.CandidateMatcher;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.Matches;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.indexer.JPASearchFactoryController;
import gob.bcb.lavado.search.queryparsers.QueryParsersBuilder;

public class FacetQueryOfac {
	private static final Logger log = LoggerFactory.getLogger(FacetQueryOfac.class);

	private Integer pageSize;
	private Integer page;
	private Sort sort;
	private Integer maxResults;
	private static final Integer DEFAULT_MAX_RESULTS = 200;

	private final JPASearchFactoryController jPASearchFactoryController;
	private IndexSearcher indexSearcher;
	private List<OfacQuery> ofacQueryLista = new LinkedList<>();

	private List<String> projectionHQ = new ArrayList<>();

	{
		projectionHQ.add(FullTextQuery.THIS);
		projectionHQ.add(FullTextQuery.SCORE);
//		projectionHQ.add(FullTextQuery.DOCUMENT);
		projectionHQ.add(FullTextQuery.ID);
		projectionHQ.add(FullTextQuery.DOCUMENT_ID);
	}

	public FacetQueryOfac(JPASearchFactoryController jPASearchFactoryController) {
		this.jPASearchFactoryController = jPASearchFactoryController;
	}

	protected FullTextQuery createFullTextQuery(Query queryLucene, String[] projection, Class<?>... entities) {
		if (queryLucene == null) {
			log.error("WARN!!!! Object LuceneQuery is null!");
			return null;
		}

		FullTextQuery hibernateQuery = jPASearchFactoryController.getFullTextEntityManager().createFullTextQuery(queryLucene, entities);
		hibernateQuery.setHint("javax.persistence.query.timeout", 10000);

		if (page != null) {
			hibernateQuery.setFirstResult((page.intValue() - 1) * pageSize.intValue());
			hibernateQuery.setMaxResults(pageSize.intValue());
			maxResults = pageSize.intValue();
		}
		if (sort != null)
			hibernateQuery.setSort(sort);

		if (maxResults != null)
			hibernateQuery.setMaxResults(maxResults.intValue());
		else
			hibernateQuery.setMaxResults(DEFAULT_MAX_RESULTS);

		if (projection != null && projection.length > 0)
			hibernateQuery.setProjection(projection);

		return hibernateQuery;
	}

	public List<SearchResultOfac> search(Query queryLucene, Class<?>... entities) {
		log.info("Search Generic for query: " + queryLucene);
		if (queryLucene == null) {
			log.error("Object queryLucene is null!");
			return new ArrayList<>();
		}
		long buildTime = System.nanoTime();

		ProjectionSimpleToSearchResultTransformer projectionSimple = new ProjectionSimpleToSearchResultTransformer();
		projectionSimple.setIdQuery(String.valueOf(Objects.hash(queryLucene.toString())));
		projectionSimple.setQueryLucene(queryLucene);

		FullTextQuery hibernateQuery = createFullTextQuery(queryLucene, projectionHQ.toArray(new String[0]), entities);
		if (hibernateQuery == null)
			return new ArrayList<>();
		hibernateQuery.setResultTransformer(projectionSimple);
		List<SearchResultOfac> searchResultOfacRes = hibernateQuery.getResultList();
		log.info("searchResultOfacRes ResultList size: " + searchResultOfacRes.size());
		buildTime = System.nanoTime() - buildTime;
		return searchResultOfacRes;
	}

	public List<SearchResultOfac> search(CandidateMatcher<SearchResultOfac> presearcherMatcher, OfacQuery ofacQuery) {
		long buildTime = System.currentTimeMillis();

		Optional<String> optionalValue = projectionHQ.stream().filter(s -> s.equalsIgnoreCase(ofacQuery.getField())).findFirst();
		if (!optionalValue.isPresent())
			projectionHQ.add(ofacQuery.getField());

		FullTextQuery hibernateQuery = createFullTextQuery(ofacQuery.getLuceneQuery(), projectionHQ.toArray(new String[0]),
				ofacQuery.getFieldQuery().getClazz());

		if (hibernateQuery == null)
			return new ArrayList<>();

		ProjectionQueryCollectorTransformer projectionQueryCollectorTransformer = new ProjectionQueryCollectorTransformer(ofacQuery, new QueryCollector() {
			@Override
			public void matchQuery(String id, SearchResultOfac matchQuery, Map result) {
				try {
					presearcherMatcher.matchQuery(id, matchQuery, null);
				} catch (IOException e) {
					log.error(e.getMessage(), e);
					throw new RuntimeException(e.getMessage(), e);
				}
			}

			@Override
			public Matches<SearchResultOfac> matches() {
				return presearcherMatcher.getMatches();
			}

			@Override
			public void removeMatches() {
			}
		});
		hibernateQuery.setResultTransformer(projectionQueryCollectorTransformer);

		List<SearchResultOfac> searchResultOfacRes = hibernateQuery.getResultList();
		buildTime = System.currentTimeMillis() - buildTime;
		log.info("Search " + searchResultOfacRes.size() + " regs. in {" + buildTime + "} milliseconds Q: " + ofacQuery.getQuery() + ":" + ofacQuery.getType()
				+ "] " + ofacQuery.getLuceneQuery());

		return searchResultOfacRes;
	}

	/**
	 * metodo principal para búsqueda
	 * 
	 * @param queryBuilder
	 * @param queryCollector
	 * @return
	 * @throws IOException
	 */
	public long search(QueryBuilder queryBuilder, QueryCollector queryCollector) throws IOException {
		long buildTime = System.nanoTime();
		int cont = 0;

		for (OfacQuery ofacQuery : ofacQueryLista) {
			if (ofacQuery.getLuceneQuery() == null) {
				log.error("Object ofacQuery.getLuceneQuery() is null!");
				continue;
			}
			Optional<String> optionalValue = projectionHQ.stream().filter(s -> s.equalsIgnoreCase(ofacQuery.getField())).findFirst();
			if (!optionalValue.isPresent())
				projectionHQ.add(ofacQuery.getField());

			maxResults = ofacQuery.getMaxResults();
			page = ofacQuery.getPage();
			pageSize = ofacQuery.getPageSize();

			ProjectionQueryCollectorTransformer projectionQueryCollectorTransformer = new ProjectionQueryCollectorTransformer(ofacQuery, queryCollector);

			FullTextQuery hibernateQuery = createFullTextQuery(ofacQuery.getLuceneQuery(), projectionHQ.toArray(new String[0]),
					ofacQuery.getFieldQuery().getClazz());
			if (hibernateQuery == null)
				continue;

			hibernateQuery.setResultTransformer(projectionQueryCollectorTransformer);

			List<SearchResultOfac> searchResultOfacR = hibernateQuery.getResultList();
			cont = cont + (searchResultOfacR != null ? searchResultOfacR.size() : 0);
			// whf this log its long, but are util
			log.debug("[" + searchResultOfacR.size() + "] Search for ofacQuery: " + ofacQuery.getLuceneQuery() + " -> " + ofacQuery.getField() + " :"
					+ ofacQuery.getQuery());
		}

		buildTime = System.nanoTime() - buildTime;
//		log.info("--> Fin Search[querys:" + ofacQueryLista.size() + "] index with total matches: " + (cont == 0 ? "Not found records!" : cont)
//				+ " records founds! [" + new BigDecimal(buildTime).divide(new BigDecimal(1000000)) + " ms.] <-- ");
		return buildTime;
	}

	public void commit(final List<OfacQuery> updates) {
		for (OfacQuery ofacQuery : updates) {
			ofacQueryLista.add(ofacQuery);
		}
	}

	public void commit(OfacQuery updates) throws IOException {
		ofacQueryLista.add(updates);
	}

	public interface QueryCollector {
		void matchQuery(String id, SearchResultOfac searchResultOfac, Map result);

		Matches<SearchResultOfac> matches();

		void removeMatches();
	}

	public interface QueryBuilder {
		List<OfacQuery> buildQuery(FieldQuery fieldQuery) throws IOException;

		List<OfacQuery> buildQuery(List<FieldQuery> fieldQuery) throws IOException;
	}

	public class ProjectionQueryCollectorTransformer implements ResultTransformer {
		private final QueryCollector matcher;
		private final OfacQuery ofacQuery;
		private QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder();

		public ProjectionQueryCollectorTransformer(OfacQuery ofacQuery, QueryCollector matcher) {
			this.matcher = matcher;
			this.ofacQuery = ofacQuery;
		}

		@Override
		public List transformList(List collection) {
			return collection;
		}

		@Override
		public Object transformTuple(Object[] tuple, String[] aliases) {
			Map result = new HashMap(tuple.length);

			for (int i = 0; i < tuple.length; i++) {
				String key = aliases[i];
				if (key != null) {
					result.put(key, tuple[i]);
				}
			}
			String docid = String.valueOf(result.get(FullTextQuery.ID));

			String idQuery = String.valueOf(Objects.hash(ofacQuery.getField(), ofacQuery.getQuery()));

			OfacQuery ofacQueryNew = new OfacQuery(idQuery, docid, ofacQuery.getQuery(), ofacQuery.getLuceneQuery());
			ofacQueryNew.setScore((float) result.get(FullTextQuery.SCORE));
			ofacQueryNew.setField(ofacQuery.getField());
			ofacQueryNew.setType(ofacQuery.getType());
			ofacQueryNew.setFieldQuery(ofacQuery.getFieldQuery());
			ofacQueryNew.setHit(ofacQuery.getHit());

			SearchResultOfac searchResultOfac = new SearchResultOfac(ofacQueryNew.getQueryId(), docid);
			searchResultOfac.setDocumentMatch(result.get(FullTextQuery.THIS));
			searchResultOfac.setScore(ofacQueryNew.getScore());

			ofacQueryNew.setTerm(String.valueOf(result.get(ofacQueryNew.getField())));
			log.debug("OOO(" +searchResultOfac.getScore()+ ") > term: [" + docid + "] " + ofacQuery.getQuery() + " :: " + ofacQueryNew.getTerm() + " :: " + idQuery + " type:Q: " +  ofacQueryNew.getFieldQuery().getTypeQ());
			searchResultOfac.setOfacQuery(ofacQueryNew);

			matcher.matchQuery(ofacQueryNew.getQueryId(), searchResultOfac, null);
			
			if (result.containsKey(ofacQuery.getField()) && ofacQuery.getField() == null) {
				Document document = (Document) result.get(ProjectionConstants.DOCUMENT);
				if (document != null) {
					// obtenemos la lista de valores para el campo a evaluar
					String[] values = document.getValues(ofacQuery.getField());
					//log.info(ofacQuery.getFieldQuery().getClazz().getSimpleName() + "-" + docid + " => "+ ofacQuery.getField() + " " + values.length+ " " + result.size()+  " aliases " + ArrayUtils.toString(aliases));					
					if (values.length == 1) {
						ofacQueryNew.setTerm(String.valueOf(result.get(ofacQueryNew.getField())));
						log.debug("OOO > term: [" + docid + "] " + ofacQuery.getQuery() + " :: " + ofacQueryNew.getTerm() + " :: " + idQuery + " type:Q: " +  ofacQueryNew.getFieldQuery().getTypeQ());
						searchResultOfac.setOfacQuery(ofacQueryNew);

						matcher.matchQuery(ofacQueryNew.getQueryId(), searchResultOfac, null);
					} else {
						// si existen elementos en lista se vuelca la consulta
						if (values.length > 1) {
							float maxScore = 0;
							for (String value : values) {
								// log.info(" value : " + ofacQuery.getField() +
								// " valor"+ value);
								try {
									Query queryLucene = queryParsersBuilder.createQuerySpanOrQueryFuzzy(ofacQuery.getField(), value,
											ofacQuery.getFieldQuery().getDistanceUpTo(), ofacQuery.getFieldQuery().getPrefixLength(),
											ofacQuery.getFieldQuery().getBoost(), ofacQuery.getFieldQuery().getSlop(), ofacQuery.getFieldQuery().isInOrder(),
											ofacQuery.getFieldQuery().getMinWordLen(), ofacQuery.getFieldQuery().isExceptNumbers(),
											ofacQuery.getFieldQuery().getAnalyzer());
									if (queryLucene == null)
										continue;

									QueryScorer scorer = queryParsersBuilder.highlightFieldFragmentScorer(queryLucene, ofacQuery.getField(),
											ofacQuery.getQuery(), ofacQuery.getFieldQuery().getAnalyzer());
									// if (scorer != null &&
									// scorer.getFragmentScore() > 0)
									// log.info(docid + " {"+ maxScore +"} - "
									// +scorer.getFragmentScore()+ " value : " +
									// value + " :: " + ofacQuery.getQuery());
									if (scorer != null && scorer.getFragmentScore() > 0 && scorer.getFragmentScore() >= maxScore) {

										idQuery = String.valueOf(Objects.hash(ofacQuery.getField(), value));// ofacQuery.getField()
																											// +
																											// ":"
																											// +
																											// value;
										ofacQueryNew = new OfacQuery(idQuery, docid, ofacQuery.getQuery(), ofacQuery.getLuceneQuery());
										ofacQueryNew.setScore((float) result.get(FullTextQuery.SCORE));
										ofacQueryNew.setField(ofacQuery.getField());
										ofacQueryNew.setType(ofacQuery.getType());
										ofacQueryNew.setFieldQuery(ofacQuery.getFieldQuery());
										ofacQueryNew.setHit(ofacQuery.getHit());

										searchResultOfac = new SearchResultOfac(ofacQueryNew.getQueryId(), docid);
										searchResultOfac.setDocumentMatch(result.get(FullTextQuery.THIS));
										searchResultOfac.setScore(ofacQueryNew.getScore());

										ofacQueryNew.setTerm(value);
										maxScore = scorer.getFragmentScore();
										searchResultOfac.setOfacQuery(ofacQueryNew);
										log.info("	[" + docid + "] " + scorer.getFragmentScore() + " MATCH value : " + ofacQuery.getField() + " Query: "
												+ ofacQuery.getQuery() + " valor: " + value);
										matcher.matchQuery(ofacQueryNew.getQueryId(), searchResultOfac, null);
									}

								} catch (Exception e) {
									log.error(e.getMessage(), e);
								}
							}
						}
					}
				}
			}

			return searchResultOfac;
		}
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Sort getSort() {
		return sort;
	}

	public void setSort(Sort sort) {
		this.sort = sort;
	}

	public Integer getMaxResults() {
		return maxResults;
	}

	public void setMaxResults(Integer maxResults) {
		this.maxResults = maxResults;
	}

	public IndexSearcher getIndexSearcher() {
		return indexSearcher;
	}

	public void setIndexSearcher(IndexSearcher indexSearcher) {
		this.indexSearcher = indexSearcher;
	}

	public JPASearchFactoryController getjPASearchFactoryController() {
		return jPASearchFactoryController;
	}

	public List<OfacQuery> getOfacQueryLista() {
		return ofacQueryLista;
	}
}
