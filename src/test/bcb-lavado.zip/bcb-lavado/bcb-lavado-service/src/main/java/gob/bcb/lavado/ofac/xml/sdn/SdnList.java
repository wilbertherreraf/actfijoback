package gob.bcb.lavado.ofac.xml.sdn;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="publshInformation">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Publish_Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="Record_Count" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="sdnEntry" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                   &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="title" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="sdnType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="remarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="programList">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="program" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="idList" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="id" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                                       &lt;element name="idType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="idNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="idCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="issueDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="expirationDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="akaList" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="aka" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                                       &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="category" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="addressList" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="address" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                                       &lt;element name="address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="address3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="stateOrProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="postalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="nationalityList" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="nationality" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                                       &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="citizenshipList" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="citizenship" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                                       &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="dateOfBirthList" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="dateOfBirthItem" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                                       &lt;element name="dateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="placeOfBirthList" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="placeOfBirthItem" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *                                       &lt;element name="placeOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="vesselInfo" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="callSign" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="vesselType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="vesselFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="vesselOwner" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="tonnage" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                             &lt;element name="grossRegisteredTonnage" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "publshInformation",
    "sdnEntry"
})
@XmlRootElement(name = "sdnList")
public class SdnList {

    @XmlElement(required = true)
    protected SdnList.PublshInformation publshInformation;
    @XmlElement(required = true)
    protected List<SdnList.SdnEntry> sdnEntry;

    /**
     * Obtiene el valor de la propiedad publshInformation.
     * 
     * @return
     *     possible object is
     *     {@link SdnList.PublshInformation }
     *     
     */
    public SdnList.PublshInformation getPublshInformation() {
        return publshInformation;
    }

    /**
     * Define el valor de la propiedad publshInformation.
     * 
     * @param value
     *     allowed object is
     *     {@link SdnList.PublshInformation }
     *     
     */
    public void setPublshInformation(SdnList.PublshInformation value) {
        this.publshInformation = value;
    }

    /**
     * Gets the value of the sdnEntry property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sdnEntry property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSdnEntry().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SdnList.SdnEntry }
     * 
     * 
     */
    public List<SdnList.SdnEntry> getSdnEntry() {
        if (sdnEntry == null) {
            sdnEntry = new ArrayList<SdnList.SdnEntry>();
        }
        return this.sdnEntry;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Publish_Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="Record_Count" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "publishDate",
        "recordCount"
    })
    public static class PublshInformation {

        @XmlElement(name = "Publish_Date")
        protected String publishDate;
        @XmlElement(name = "Record_Count")
        protected Integer recordCount;

        /**
         * Obtiene el valor de la propiedad publishDate.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPublishDate() {
            return publishDate;
        }

        /**
         * Define el valor de la propiedad publishDate.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPublishDate(String value) {
            this.publishDate = value;
        }

        /**
         * Obtiene el valor de la propiedad recordCount.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getRecordCount() {
            return recordCount;
        }

        /**
         * Define el valor de la propiedad recordCount.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setRecordCount(Integer value) {
            this.recordCount = value;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *         &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="title" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="sdnType" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="remarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="programList">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="program" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="idList" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="id" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                             &lt;element name="idType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="idNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="idCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="issueDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="expirationDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="akaList" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="aka" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                             &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="category" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="addressList" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="address" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                             &lt;element name="address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="address3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="stateOrProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="postalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="nationalityList" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="nationality" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                             &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="citizenshipList" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="citizenship" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                             &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="dateOfBirthList" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="dateOfBirthItem" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                             &lt;element name="dateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="placeOfBirthList" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="placeOfBirthItem" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
     *                             &lt;element name="placeOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *         &lt;element name="vesselInfo" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="callSign" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="vesselType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="vesselFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="vesselOwner" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="tonnage" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                   &lt;element name="grossRegisteredTonnage" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "uid",
        "firstName",
        "lastName",
        "title",
        "sdnType",
        "remarks",
        "programList",
        "idList",
        "akaList",
        "addressList",
        "nationalityList",
        "citizenshipList",
        "dateOfBirthList",
        "placeOfBirthList",
        "vesselInfo"
    })
    public static class SdnEntry {

        protected int uid;
        protected String firstName;
        @XmlElement(required = true)
        protected String lastName;
        protected String title;
        @XmlElement(required = true)
        protected String sdnType;
        protected String remarks;
        @XmlElement(required = true)
        protected SdnList.SdnEntry.ProgramList programList;
        protected SdnList.SdnEntry.IdList idList;
        protected SdnList.SdnEntry.AkaList akaList;
        protected SdnList.SdnEntry.AddressList addressList;
        protected SdnList.SdnEntry.NationalityList nationalityList;
        protected SdnList.SdnEntry.CitizenshipList citizenshipList;
        protected SdnList.SdnEntry.DateOfBirthList dateOfBirthList;
        protected SdnList.SdnEntry.PlaceOfBirthList placeOfBirthList;
        protected SdnList.SdnEntry.VesselInfo vesselInfo;

        /**
         * Obtiene el valor de la propiedad uid.
         * 
         */
        public int getUid() {
            return uid;
        }

        /**
         * Define el valor de la propiedad uid.
         * 
         */
        public void setUid(int value) {
            this.uid = value;
        }

        /**
         * Obtiene el valor de la propiedad firstName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFirstName() {
            return firstName;
        }

        /**
         * Define el valor de la propiedad firstName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFirstName(String value) {
            this.firstName = value;
        }

        /**
         * Obtiene el valor de la propiedad lastName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLastName() {
            return lastName;
        }

        /**
         * Define el valor de la propiedad lastName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLastName(String value) {
            this.lastName = value;
        }

        /**
         * Obtiene el valor de la propiedad title.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTitle() {
            return title;
        }

        /**
         * Define el valor de la propiedad title.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTitle(String value) {
            this.title = value;
        }

        /**
         * Obtiene el valor de la propiedad sdnType.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSdnType() {
            return sdnType;
        }

        /**
         * Define el valor de la propiedad sdnType.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSdnType(String value) {
            this.sdnType = value;
        }

        /**
         * Obtiene el valor de la propiedad remarks.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRemarks() {
            return remarks;
        }

        /**
         * Define el valor de la propiedad remarks.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRemarks(String value) {
            this.remarks = value;
        }

        /**
         * Obtiene el valor de la propiedad programList.
         * 
         * @return
         *     possible object is
         *     {@link SdnList.SdnEntry.ProgramList }
         *     
         */
        public SdnList.SdnEntry.ProgramList getProgramList() {
            return programList;
        }

        /**
         * Define el valor de la propiedad programList.
         * 
         * @param value
         *     allowed object is
         *     {@link SdnList.SdnEntry.ProgramList }
         *     
         */
        public void setProgramList(SdnList.SdnEntry.ProgramList value) {
            this.programList = value;
        }

        /**
         * Obtiene el valor de la propiedad idList.
         * 
         * @return
         *     possible object is
         *     {@link SdnList.SdnEntry.IdList }
         *     
         */
        public SdnList.SdnEntry.IdList getIdList() {
            return idList;
        }

        /**
         * Define el valor de la propiedad idList.
         * 
         * @param value
         *     allowed object is
         *     {@link SdnList.SdnEntry.IdList }
         *     
         */
        public void setIdList(SdnList.SdnEntry.IdList value) {
            this.idList = value;
        }

        /**
         * Obtiene el valor de la propiedad akaList.
         * 
         * @return
         *     possible object is
         *     {@link SdnList.SdnEntry.AkaList }
         *     
         */
        public SdnList.SdnEntry.AkaList getAkaList() {
            return akaList;
        }

        /**
         * Define el valor de la propiedad akaList.
         * 
         * @param value
         *     allowed object is
         *     {@link SdnList.SdnEntry.AkaList }
         *     
         */
        public void setAkaList(SdnList.SdnEntry.AkaList value) {
            this.akaList = value;
        }

        /**
         * Obtiene el valor de la propiedad addressList.
         * 
         * @return
         *     possible object is
         *     {@link SdnList.SdnEntry.AddressList }
         *     
         */
        public SdnList.SdnEntry.AddressList getAddressList() {
            return addressList;
        }

        /**
         * Define el valor de la propiedad addressList.
         * 
         * @param value
         *     allowed object is
         *     {@link SdnList.SdnEntry.AddressList }
         *     
         */
        public void setAddressList(SdnList.SdnEntry.AddressList value) {
            this.addressList = value;
        }

        /**
         * Obtiene el valor de la propiedad nationalityList.
         * 
         * @return
         *     possible object is
         *     {@link SdnList.SdnEntry.NationalityList }
         *     
         */
        public SdnList.SdnEntry.NationalityList getNationalityList() {
            return nationalityList;
        }

        /**
         * Define el valor de la propiedad nationalityList.
         * 
         * @param value
         *     allowed object is
         *     {@link SdnList.SdnEntry.NationalityList }
         *     
         */
        public void setNationalityList(SdnList.SdnEntry.NationalityList value) {
            this.nationalityList = value;
        }

        /**
         * Obtiene el valor de la propiedad citizenshipList.
         * 
         * @return
         *     possible object is
         *     {@link SdnList.SdnEntry.CitizenshipList }
         *     
         */
        public SdnList.SdnEntry.CitizenshipList getCitizenshipList() {
            return citizenshipList;
        }

        /**
         * Define el valor de la propiedad citizenshipList.
         * 
         * @param value
         *     allowed object is
         *     {@link SdnList.SdnEntry.CitizenshipList }
         *     
         */
        public void setCitizenshipList(SdnList.SdnEntry.CitizenshipList value) {
            this.citizenshipList = value;
        }

        /**
         * Obtiene el valor de la propiedad dateOfBirthList.
         * 
         * @return
         *     possible object is
         *     {@link SdnList.SdnEntry.DateOfBirthList }
         *     
         */
        public SdnList.SdnEntry.DateOfBirthList getDateOfBirthList() {
            return dateOfBirthList;
        }

        /**
         * Define el valor de la propiedad dateOfBirthList.
         * 
         * @param value
         *     allowed object is
         *     {@link SdnList.SdnEntry.DateOfBirthList }
         *     
         */
        public void setDateOfBirthList(SdnList.SdnEntry.DateOfBirthList value) {
            this.dateOfBirthList = value;
        }

        /**
         * Obtiene el valor de la propiedad placeOfBirthList.
         * 
         * @return
         *     possible object is
         *     {@link SdnList.SdnEntry.PlaceOfBirthList }
         *     
         */
        public SdnList.SdnEntry.PlaceOfBirthList getPlaceOfBirthList() {
            return placeOfBirthList;
        }

        /**
         * Define el valor de la propiedad placeOfBirthList.
         * 
         * @param value
         *     allowed object is
         *     {@link SdnList.SdnEntry.PlaceOfBirthList }
         *     
         */
        public void setPlaceOfBirthList(SdnList.SdnEntry.PlaceOfBirthList value) {
            this.placeOfBirthList = value;
        }

        /**
         * Obtiene el valor de la propiedad vesselInfo.
         * 
         * @return
         *     possible object is
         *     {@link SdnList.SdnEntry.VesselInfo }
         *     
         */
        public SdnList.SdnEntry.VesselInfo getVesselInfo() {
            return vesselInfo;
        }

        /**
         * Define el valor de la propiedad vesselInfo.
         * 
         * @param value
         *     allowed object is
         *     {@link SdnList.SdnEntry.VesselInfo }
         *     
         */
        public void setVesselInfo(SdnList.SdnEntry.VesselInfo value) {
            this.vesselInfo = value;
        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="address" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                   &lt;element name="address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="address3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="stateOrProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="postalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "address"
        })
        public static class AddressList {

            protected List<SdnList.SdnEntry.AddressList.Address> address;

            /**
             * Gets the value of the address property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the address property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getAddress().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link SdnList.SdnEntry.AddressList.Address }
             * 
             * 
             */
            public List<SdnList.SdnEntry.AddressList.Address> getAddress() {
                if (address == null) {
                    address = new ArrayList<SdnList.SdnEntry.AddressList.Address>();
                }
                return this.address;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *         &lt;element name="address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="address3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="stateOrProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="postalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "uid",
                "address1",
                "address2",
                "address3",
                "city",
                "stateOrProvince",
                "postalCode",
                "country"
            })
            public static class Address {

                protected int uid;
                protected String address1;
                protected String address2;
                protected String address3;
                protected String city;
                protected String stateOrProvince;
                protected String postalCode;
                protected String country;

                /**
                 * Obtiene el valor de la propiedad uid.
                 * 
                 */
                public int getUid() {
                    return uid;
                }

                /**
                 * Define el valor de la propiedad uid.
                 * 
                 */
                public void setUid(int value) {
                    this.uid = value;
                }

                /**
                 * Obtiene el valor de la propiedad address1.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAddress1() {
                    return address1;
                }

                /**
                 * Define el valor de la propiedad address1.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAddress1(String value) {
                    this.address1 = value;
                }

                /**
                 * Obtiene el valor de la propiedad address2.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAddress2() {
                    return address2;
                }

                /**
                 * Define el valor de la propiedad address2.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAddress2(String value) {
                    this.address2 = value;
                }

                /**
                 * Obtiene el valor de la propiedad address3.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getAddress3() {
                    return address3;
                }

                /**
                 * Define el valor de la propiedad address3.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setAddress3(String value) {
                    this.address3 = value;
                }

                /**
                 * Obtiene el valor de la propiedad city.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCity() {
                    return city;
                }

                /**
                 * Define el valor de la propiedad city.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCity(String value) {
                    this.city = value;
                }

                /**
                 * Obtiene el valor de la propiedad stateOrProvince.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getStateOrProvince() {
                    return stateOrProvince;
                }

                /**
                 * Define el valor de la propiedad stateOrProvince.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setStateOrProvince(String value) {
                    this.stateOrProvince = value;
                }

                /**
                 * Obtiene el valor de la propiedad postalCode.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getPostalCode() {
                    return postalCode;
                }

                /**
                 * Define el valor de la propiedad postalCode.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setPostalCode(String value) {
                    this.postalCode = value;
                }

                /**
                 * Obtiene el valor de la propiedad country.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCountry() {
                    return country;
                }

                /**
                 * Define el valor de la propiedad country.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCountry(String value) {
                    this.country = value;
                }

            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="aka" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                   &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="category" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "aka"
        })
        public static class AkaList {

            protected List<SdnList.SdnEntry.AkaList.Aka> aka;

            /**
             * Gets the value of the aka property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the aka property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getAka().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link SdnList.SdnEntry.AkaList.Aka }
             * 
             * 
             */
            public List<SdnList.SdnEntry.AkaList.Aka> getAka() {
                if (aka == null) {
                    aka = new ArrayList<SdnList.SdnEntry.AkaList.Aka>();
                }
                return this.aka;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="category" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "uid",
                "type",
                "category",
                "lastName",
                "firstName"
            })
            public static class Aka {

                protected int uid;
                @XmlElement(required = true)
                protected String type;
                @XmlElement(required = true)
                protected String category;
                protected String lastName;
                protected String firstName;

                /**
                 * Obtiene el valor de la propiedad uid.
                 * 
                 */
                public int getUid() {
                    return uid;
                }

                /**
                 * Define el valor de la propiedad uid.
                 * 
                 */
                public void setUid(int value) {
                    this.uid = value;
                }

                /**
                 * Obtiene el valor de la propiedad type.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getType() {
                    return type;
                }

                /**
                 * Define el valor de la propiedad type.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setType(String value) {
                    this.type = value;
                }

                /**
                 * Obtiene el valor de la propiedad category.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCategory() {
                    return category;
                }

                /**
                 * Define el valor de la propiedad category.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCategory(String value) {
                    this.category = value;
                }

                /**
                 * Obtiene el valor de la propiedad lastName.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getLastName() {
                    return lastName;
                }

                /**
                 * Define el valor de la propiedad lastName.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setLastName(String value) {
                    this.lastName = value;
                }

                /**
                 * Obtiene el valor de la propiedad firstName.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getFirstName() {
                    return firstName;
                }

                /**
                 * Define el valor de la propiedad firstName.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setFirstName(String value) {
                    this.firstName = value;
                }

            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="citizenship" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                   &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "citizenship"
        })
        public static class CitizenshipList {

            protected List<SdnList.SdnEntry.CitizenshipList.Citizenship> citizenship;

            /**
             * Gets the value of the citizenship property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the citizenship property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getCitizenship().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link SdnList.SdnEntry.CitizenshipList.Citizenship }
             * 
             * 
             */
            public List<SdnList.SdnEntry.CitizenshipList.Citizenship> getCitizenship() {
                if (citizenship == null) {
                    citizenship = new ArrayList<SdnList.SdnEntry.CitizenshipList.Citizenship>();
                }
                return this.citizenship;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *         &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "uid",
                "country",
                "mainEntry"
            })
            public static class Citizenship {

                protected int uid;
                @XmlElement(required = true)
                protected String country;
                protected Boolean mainEntry;

                /**
                 * Obtiene el valor de la propiedad uid.
                 * 
                 */
                public int getUid() {
                    return uid;
                }

                /**
                 * Define el valor de la propiedad uid.
                 * 
                 */
                public void setUid(int value) {
                    this.uid = value;
                }

                /**
                 * Obtiene el valor de la propiedad country.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCountry() {
                    return country;
                }

                /**
                 * Define el valor de la propiedad country.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCountry(String value) {
                    this.country = value;
                }

                /**
                 * Obtiene el valor de la propiedad mainEntry.
                 * 
                 */
                public Boolean isMainEntry() {
                    return mainEntry;
                }

                /**
                 * Define el valor de la propiedad mainEntry.
                 * 
                 */
                public void setMainEntry(Boolean value) {
                    this.mainEntry = value;
                }

            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="dateOfBirthItem" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                   &lt;element name="dateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "dateOfBirthItem"
        })
        public static class DateOfBirthList {

            protected List<SdnList.SdnEntry.DateOfBirthList.DateOfBirthItem> dateOfBirthItem;

            /**
             * Gets the value of the dateOfBirthItem property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the dateOfBirthItem property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getDateOfBirthItem().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link SdnList.SdnEntry.DateOfBirthList.DateOfBirthItem }
             * 
             * 
             */
            public List<SdnList.SdnEntry.DateOfBirthList.DateOfBirthItem> getDateOfBirthItem() {
                if (dateOfBirthItem == null) {
                    dateOfBirthItem = new ArrayList<SdnList.SdnEntry.DateOfBirthList.DateOfBirthItem>();
                }
                return this.dateOfBirthItem;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *         &lt;element name="dateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "uid",
                "dateOfBirth",
                "mainEntry"
            })
            public static class DateOfBirthItem {

                protected int uid;
                @XmlElement(required = true)
                protected String dateOfBirth;
                protected Boolean mainEntry;

                /**
                 * Obtiene el valor de la propiedad uid.
                 * 
                 */
                public int getUid() {
                    return uid;
                }

                /**
                 * Define el valor de la propiedad uid.
                 * 
                 */
                public void setUid(int value) {
                    this.uid = value;
                }

                /**
                 * Obtiene el valor de la propiedad dateOfBirth.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDateOfBirth() {
                    return dateOfBirth;
                }

                /**
                 * Define el valor de la propiedad dateOfBirth.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDateOfBirth(String value) {
                    this.dateOfBirth = value;
                }

                /**
                 * Obtiene el valor de la propiedad mainEntry.
                 * 
                 */
                public Boolean isMainEntry() {
                    return mainEntry;
                }

                /**
                 * Define el valor de la propiedad mainEntry.
                 * 
                 */
                public void setMainEntry(Boolean value) {
                    this.mainEntry = value;
                }

            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="id" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                   &lt;element name="idType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="idNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="idCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="issueDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="expirationDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "id"
        })
        public static class IdList {

            protected List<SdnList.SdnEntry.IdList.Id> id;

            /**
             * Gets the value of the id property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the id property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getId().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link SdnList.SdnEntry.IdList.Id }
             * 
             * 
             */
            public List<SdnList.SdnEntry.IdList.Id> getId() {
                if (id == null) {
                    id = new ArrayList<SdnList.SdnEntry.IdList.Id>();
                }
                return this.id;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *         &lt;element name="idType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="idNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="idCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="issueDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="expirationDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "uid",
                "idType",
                "idNumber",
                "idCountry",
                "issueDate",
                "expirationDate"
            })
            public static class Id {

                protected int uid;
                protected String idType;
                protected String idNumber;
                protected String idCountry;
                protected String issueDate;
                protected String expirationDate;

                /**
                 * Obtiene el valor de la propiedad uid.
                 * 
                 */
                public int getUid() {
                    return uid;
                }

                /**
                 * Define el valor de la propiedad uid.
                 * 
                 */
                public void setUid(int value) {
                    this.uid = value;
                }

                /**
                 * Obtiene el valor de la propiedad idType.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getIdType() {
                    return idType;
                }

                /**
                 * Define el valor de la propiedad idType.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setIdType(String value) {
                    this.idType = value;
                }

                /**
                 * Obtiene el valor de la propiedad idNumber.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getIdNumber() {
                    return idNumber;
                }

                /**
                 * Define el valor de la propiedad idNumber.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setIdNumber(String value) {
                    this.idNumber = value;
                }

                /**
                 * Obtiene el valor de la propiedad idCountry.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getIdCountry() {
                    return idCountry;
                }

                /**
                 * Define el valor de la propiedad idCountry.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setIdCountry(String value) {
                    this.idCountry = value;
                }

                /**
                 * Obtiene el valor de la propiedad issueDate.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getIssueDate() {
                    return issueDate;
                }

                /**
                 * Define el valor de la propiedad issueDate.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setIssueDate(String value) {
                    this.issueDate = value;
                }

                /**
                 * Obtiene el valor de la propiedad expirationDate.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getExpirationDate() {
                    return expirationDate;
                }

                /**
                 * Define el valor de la propiedad expirationDate.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setExpirationDate(String value) {
                    this.expirationDate = value;
                }

            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="nationality" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                   &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "nationality"
        })
        public static class NationalityList {

            protected List<SdnList.SdnEntry.NationalityList.Nationality> nationality;

            /**
             * Gets the value of the nationality property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the nationality property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getNationality().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link SdnList.SdnEntry.NationalityList.Nationality }
             * 
             * 
             */
            public List<SdnList.SdnEntry.NationalityList.Nationality> getNationality() {
                if (nationality == null) {
                    nationality = new ArrayList<SdnList.SdnEntry.NationalityList.Nationality>();
                }
                return this.nationality;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *         &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "uid",
                "country",
                "mainEntry"
            })
            public static class Nationality {

                protected int uid;
                @XmlElement(required = true)
                protected String country;
                protected Boolean mainEntry;

                /**
                 * Obtiene el valor de la propiedad uid.
                 * 
                 */
                public int getUid() {
                    return uid;
                }

                /**
                 * Define el valor de la propiedad uid.
                 * 
                 */
                public void setUid(int value) {
                    this.uid = value;
                }

                /**
                 * Obtiene el valor de la propiedad country.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCountry() {
                    return country;
                }

                /**
                 * Define el valor de la propiedad country.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCountry(String value) {
                    this.country = value;
                }

                /**
                 * Obtiene el valor de la propiedad mainEntry.
                 * 
                 */
                public Boolean isMainEntry() {
                    return mainEntry;
                }

                /**
                 * Define el valor de la propiedad mainEntry.
                 * 
                 */
                public void setMainEntry(Boolean value) {
                    this.mainEntry = value;
                }

            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="placeOfBirthItem" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
         *                   &lt;element name="placeOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "placeOfBirthItem"
        })
        public static class PlaceOfBirthList {

            protected List<SdnList.SdnEntry.PlaceOfBirthList.PlaceOfBirthItem> placeOfBirthItem;

            /**
             * Gets the value of the placeOfBirthItem property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the placeOfBirthItem property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getPlaceOfBirthItem().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link SdnList.SdnEntry.PlaceOfBirthList.PlaceOfBirthItem }
             * 
             * 
             */
            public List<SdnList.SdnEntry.PlaceOfBirthList.PlaceOfBirthItem> getPlaceOfBirthItem() {
                if (placeOfBirthItem == null) {
                    placeOfBirthItem = new ArrayList<SdnList.SdnEntry.PlaceOfBirthList.PlaceOfBirthItem>();
                }
                return this.placeOfBirthItem;
            }


            /**
             * <p>Clase Java para anonymous complex type.
             * 
             * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}int"/>
             *         &lt;element name="placeOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="mainEntry" type="{http://www.w3.org/2001/XMLSchema}Boolean"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "uid",
                "placeOfBirth",
                "mainEntry"
            })
            public static class PlaceOfBirthItem {

                protected int uid;
                @XmlElement(required = true)
                protected String placeOfBirth;
                protected Boolean mainEntry;

                /**
                 * Obtiene el valor de la propiedad uid.
                 * 
                 */
                public int getUid() {
                    return uid;
                }

                /**
                 * Define el valor de la propiedad uid.
                 * 
                 */
                public void setUid(int value) {
                    this.uid = value;
                }

                /**
                 * Obtiene el valor de la propiedad placeOfBirth.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getPlaceOfBirth() {
                    return placeOfBirth;
                }

                /**
                 * Define el valor de la propiedad placeOfBirth.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setPlaceOfBirth(String value) {
                    this.placeOfBirth = value;
                }

                /**
                 * Obtiene el valor de la propiedad mainEntry.
                 * 
                 */
                public Boolean isMainEntry() {
                    return mainEntry;
                }

                /**
                 * Define el valor de la propiedad mainEntry.
                 * 
                 */
                public void setMainEntry(Boolean value) {
                    this.mainEntry = value;
                }

            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="program" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "program"
        })
        public static class ProgramList {

            protected List<String> program;

            /**
             * Gets the value of the program property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the program property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getProgram().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link String }
             * 
             * 
             */
            public List<String> getProgram() {
                if (program == null) {
                    program = new ArrayList<String>();
                }
                return this.program;
            }

        }


        /**
         * <p>Clase Java para anonymous complex type.
         * 
         * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="callSign" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="vesselType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="vesselFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="vesselOwner" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="tonnage" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *         &lt;element name="grossRegisteredTonnage" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "callSign",
            "vesselType",
            "vesselFlag",
            "vesselOwner",
            "tonnage",
            "grossRegisteredTonnage"
        })
        public static class VesselInfo {

            protected String callSign;
            protected String vesselType;
            protected String vesselFlag;
            protected String vesselOwner;
            protected Integer tonnage;
            protected Integer grossRegisteredTonnage;

            /**
             * Obtiene el valor de la propiedad callSign.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCallSign() {
                return callSign;
            }

            /**
             * Define el valor de la propiedad callSign.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCallSign(String value) {
                this.callSign = value;
            }

            /**
             * Obtiene el valor de la propiedad vesselType.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getVesselType() {
                return vesselType;
            }

            /**
             * Define el valor de la propiedad vesselType.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setVesselType(String value) {
                this.vesselType = value;
            }

            /**
             * Obtiene el valor de la propiedad vesselFlag.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getVesselFlag() {
                return vesselFlag;
            }

            /**
             * Define el valor de la propiedad vesselFlag.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setVesselFlag(String value) {
                this.vesselFlag = value;
            }

            /**
             * Obtiene el valor de la propiedad vesselOwner.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getVesselOwner() {
                return vesselOwner;
            }

            /**
             * Define el valor de la propiedad vesselOwner.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setVesselOwner(String value) {
                this.vesselOwner = value;
            }

            /**
             * Obtiene el valor de la propiedad tonnage.
             * 
             * @return
             *     possible object is
             *     {@link Integer }
             *     
             */
            public Integer getTonnage() {
                return tonnage;
            }

            /**
             * Define el valor de la propiedad tonnage.
             * 
             * @param value
             *     allowed object is
             *     {@link Integer }
             *     
             */
            public void setTonnage(Integer value) {
                this.tonnage = value;
            }

            /**
             * Obtiene el valor de la propiedad grossRegisteredTonnage.
             * 
             * @return
             *     possible object is
             *     {@link Integer }
             *     
             */
            public Integer getGrossRegisteredTonnage() {
                return grossRegisteredTonnage;
            }

            /**
             * Define el valor de la propiedad grossRegisteredTonnage.
             * 
             * @param value
             *     allowed object is
             *     {@link Integer }
             *     
             */
            public void setGrossRegisteredTonnage(Integer value) {
                this.grossRegisteredTonnage = value;
            }

        }

    }

}
