package gob.bcb.lavado.security.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DatabaseUpgrader implementation that expects to be fully configured
 * programatically. Stores version information in a DatabaseVersion table in the
 * database.
 */
public class GenericDatabaseUpgrader implements DatabaseUpgrader {

	private static final Logger logger = LoggerFactory.getLogger(GenericDatabaseUpgrader.class);

	private final DataSource dataSource;

	private DatabaseVersion currentVersion;

	/**
	 * Constructs a database upgrader that upgrades the Database accessed by the
	 * provided {@link DataSource}.
	 * 
	 * @param dataSource
	 *            the factory for database connections
	 */
	public GenericDatabaseUpgrader(DataSource dataSource) {
		this.dataSource = dataSource;
		currentVersion = findCurrentVersion();
		if (logger.isInfoEnabled()) {
			logger.info("VERSION_ENC DB: Database is at Version: " + currentVersion);
		}
	}

	// implementing DatabaseUpgrader

	public DatabaseVersion getCurrentDatabaseVersion() {
		return currentVersion;
	}

	// internal helpers

	private DatabaseVersion findCurrentVersion() {
		Connection connection = null;
		try {
			logger.info("XXXXXXXXXXXXXXX");
			connection = dataSource.getConnection();
			logger.info("YYYYYYYYYYYYYY");			
			// checks if the parameter exists
			Statement stmt = connection.createStatement();
			
			try {
				stmt.execute("select par_valor as value from swf_params where par_codpar = 'VERSION_ENC'");
				ResultSet queryResult = stmt.getResultSet();
				try {
					queryResult.next();
					String value = queryResult.getString("value");
					if (value == null) {
						logger.error("Parametro VERSION_ENC no definido en tabla swf_params");
						throw new RuntimeException("Parametro VERSION_ENC no definido en tabla swf_params");
					}
					queryResult.close();

					return DatabaseVersion.valueOf(value);
				} finally {
					queryResult.close();
				}
			} finally {
				stmt.close();
			}
		} catch (Exception e) {
			logger.error("Error al obterner version en BD " + e.getMessage());
			throw new RuntimeException("No se puede obtener version de encriptado de swf_params 'VERSION_ENC'" , e);
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {

				}
			}
		}
	}

}