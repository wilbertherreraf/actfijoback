package gob.bcb.lavado.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TermVector;

import gob.bcb.swift.pojos.Block4;

/**
 * The persistent class for the swf_mensaje database table.
 * 
 */
@Entity
@Table(name = "swf_mensaje")
public class SwfMensaje implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "men_codmen")
	@DocumentId
	private Integer menCodmen;

	@Column(name = "men_codmt")
	private String menCodmt;

	@Column(name = "men_nrocorr")
	private Integer menNrocorr;

	@Column(name = "men_nroswift")
	private String menNroswift;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "men_plano")
	private String menPlano;

	@Column(name = "men_codswift")
	private String menCodswift;

	@Column(name = "men_nrolote")
	private Integer menNrolote;

	@Column(name = "men_emisor")
	private String menEmisor;

	@Column(name = "men_receiver")
	private String menReceiver;

	@Column(name = "men_bic")
	private String menBic;

	@Column(name = "men_biccodctrl")
	private String menBiccodctrl;

	@Column(name = "men_bicbranch")
	private String menBicbranch;

	@Column(name = "men_monswift")
	private String menMonswift;
	
	@Column(name = "men_codmon")
	private Integer menCodmon;

	@Column(name = "men_gestion")
	private Integer menGestion;

	@Column(name = "men_refer")
	private String menRefer;

	@Column(name = "men_idtmessagetx")
	private String menIdtmessagetx;
	
	@Column(name = "men_formato")
	private String menFormato;
	
	@Column(name = "men_inout")
	private String menInout;

	@Column(name = "men_destinatario")
	private String menDestinatario;

	@Column(name = "men_codusrswf")
	private String menCodusrswf;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "men_fecauto")
	private Date menFecauto;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "men_fecreg")
	private Date menFecreg;

	@Column(name = "men_tabestverifica")
	private Integer menTabestverifica;

	@Column(name = "men_estverifica")
	private Integer menEstverifica;

	@Column(name = "men_tabestautoriza")
	private Integer menTabestautoriza;

	@Column(name = "men_estautoriza")
	private Integer menEstautoriza;

	@Column(name = "men_usrlvdverifica")
	private String menUsrlvdverifica;

	@Column(name = "men_hash")
	private String menHash;

	@Column(name = "men_codapp")
	private String menCodapp;

	@Column(name = "men_firmaorigen")
	private String menFirmaorigen;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "men_auditfho")
	private Date menAuditfho;

	@Column(name = "men_auditusr")
	private String menAuditusr;

	@Column(name = "men_auditwst")
	private String menAuditwst;

	@Column(name = "men_tabestmensaje")
	private Integer menTabestmensaje;

	@Column(name = "men_estmensaje")
	private Integer menEstmensaje;

	@ManyToOne(fetch = FetchType.EAGER)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumns( { @JoinColumn(updatable=false,insertable=false,name = "men_estmensaje", referencedColumnName = "des_codigo"),
			@JoinColumn(updatable=false,insertable=false,name = "men_tabestmensaje", referencedColumnName = "des_codtab")})
	private GenDesctabla genDesctablaEstmensaje;

	@ManyToOne(fetch = FetchType.EAGER)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumns( { @JoinColumn(updatable=false,insertable=false,name = "men_estverifica", referencedColumnName = "des_codigo"),
			@JoinColumn(updatable=false,insertable=false,name = "men_tabestverifica", referencedColumnName = "des_codtab")})
	private GenDesctabla genDesctablaEstverifica;
	
	@Transient
	private List<Block4> block4List = new ArrayList<>();
	@Transient
	private String swiftfPlano;

	public SwfMensaje() {
	}

	public Integer getMenCodmen() {
		return this.menCodmen;
	}

	public void setMenCodmen(Integer menCodmen) {
		this.menCodmen = menCodmen;
	}

	public String getMenCodmt() {
		return this.menCodmt;
	}

	public void setMenCodmt(String menCodmt) {
		this.menCodmt = menCodmt;
	}

	public String getMenNroswift() {
		return this.menNroswift;
	}

	public void setMenNroswift(String menNroswift) {
		this.menNroswift = menNroswift;
	}

	public String getMenPlano() {
		return this.menPlano;
	}

	public void setMenPlano(String menPlano) {
		this.menPlano = menPlano;
	}

	public String getMenCodswift() {
		return menCodswift;
	}

	public void setMenCodswift(String menCodswift) {
		this.menCodswift = menCodswift;
	}

	public Integer getMenNrolote() {
		return menNrolote;
	}

	public void setMenNrolote(Integer menNrolote) {
		this.menNrolote = menNrolote;
	}

	public String getMenEmisor() {
		return menEmisor;
	}

	public void setMenEmisor(String menEmisor) {
		this.menEmisor = menEmisor;
	}

	public Integer getMenCodmon() {
		return menCodmon;
	}

	public void setMenCodmon(Integer menCodmon) {
		this.menCodmon = menCodmon;
	}

	public String getMenRefer() {
		return menRefer;
	}

	public void setMenRefer(String menRefer) {
		this.menRefer = menRefer;
	}

	public String getMenDestinatario() {
		return menDestinatario;
	}

	public void setMenDestinatario(String menDestinatario) {
		this.menDestinatario = menDestinatario;
	}

	public Date getMenFecreg() {
		return menFecreg;
	}

	public void setMenFecreg(Date menFecreg) {
		this.menFecreg = menFecreg;
	}

	public GenDesctabla getGenDesctablaEstmensaje() {
		return genDesctablaEstmensaje;
	}

	public void setGenDesctablaEstmensaje(GenDesctabla genDesctablaEstmensaje) {
		this.genDesctablaEstmensaje = genDesctablaEstmensaje;
	}

	public Integer getMenNrocorr() {
		return menNrocorr;
	}

	public void setMenNrocorr(Integer menNrocorr) {
		this.menNrocorr = menNrocorr;
	}

	public Integer getMenGestion() {
		return menGestion;
	}

	public void setMenGestion(Integer menGestion) {
		this.menGestion = menGestion;
	}

	public Date getMenAuditfho() {
		return menAuditfho;
	}

	public void setMenAuditfho(Date menAuditfho) {
		this.menAuditfho = menAuditfho;
	}

	public String getMenAuditusr() {
		return menAuditusr;
	}

	public void setMenAuditusr(String menAuditusr) {
		this.menAuditusr = menAuditusr;
	}

	public String getMenAuditwst() {
		return menAuditwst;
	}

	public void setMenAuditwst(String menAuditwst) {
		this.menAuditwst = menAuditwst;
	}

	public String getMenBic() {
		return menBic;
	}

	public void setMenBic(String menBic) {
		this.menBic = menBic;
	}

	public String getMenBiccodctrl() {
		return menBiccodctrl;
	}

	public void setMenBiccodctrl(String menBiccodctrl) {
		this.menBiccodctrl = menBiccodctrl;
	}

	public String getMenBicbranch() {
		return menBicbranch;
	}

	public void setMenBicbranch(String menBicbranch) {
		this.menBicbranch = menBicbranch;
	}

//	public Set<SwfDetmensaje> getSwfDetmensaje() {
//		return swfDetmensaje;
//	}
//
//	public void setSwfDetmensaje(Set<SwfDetmensaje> swfDetmensaje) {
//		this.swfDetmensaje = swfDetmensaje;
//	}

	public String getMenInout() {
		return menInout;
	}

	public void setMenInout(String menInout) {
		this.menInout = menInout;
	}

	public Integer getMenTabestverifica() {
		return menTabestverifica;
	}

	public void setMenTabestverifica(Integer menTabestverifica) {
		this.menTabestverifica = menTabestverifica;
	}

	public Integer getMenEstverifica() {
		return menEstverifica;
	}

	public void setMenEstverifica(Integer menEstverifica) {
		this.menEstverifica = menEstverifica;
	}

	public String getMenUsrlvdverifica() {
		return menUsrlvdverifica;
	}

	public void setMenUsrlvdverifica(String menUsrlvdverifica) {
		this.menUsrlvdverifica = menUsrlvdverifica;
	}

	public String getMenHash() {
		return menHash;
	}

	public void setMenHash(String menHash) {
		this.menHash = menHash;
	}

	public String getMenCodapp() {
		return menCodapp;
	}

	public void setMenCodapp(String menCodapp) {
		this.menCodapp = menCodapp;
	}

	public String getMenFirmaorigen() {
		return menFirmaorigen;
	}

	public void setMenFirmaorigen(String menFirmaorigen) {
		this.menFirmaorigen = menFirmaorigen;
	}

	public String getMenCodusrswf() {
		return menCodusrswf;
	}

	public void setMenCodusrswf(String menCodusrswf) {
		this.menCodusrswf = menCodusrswf;
	}

	public Date getMenFecauto() {
		return menFecauto;
	}

	public void setMenFecauto(Date menFecauto) {
		this.menFecauto = menFecauto;
	}

	public String getMenReceiver() {
		return menReceiver;
	}

	public void setMenReceiver(String menReceiver) {
		this.menReceiver = menReceiver;
	}

	public List<Block4> getBlock4List() {
		return block4List;
	}

	public void setBlock4List(List<Block4> block4List) {
		this.block4List = block4List;
	}

	public String getSwiftfPlano() {
		return swiftfPlano;
	}

	public void setSwiftfPlano(String swiftfPlano) {
		this.swiftfPlano = swiftfPlano;
	}

	public Integer getMenTabestautoriza() {
		return menTabestautoriza;
	}

	public void setMenTabestautoriza(Integer menTabestautoriza) {
		this.menTabestautoriza = menTabestautoriza;
	}

	public Integer getMenEstautoriza() {
		return menEstautoriza;
	}

	public void setMenEstautoriza(Integer menEstautoriza) {
		this.menEstautoriza = menEstautoriza;
	}

	@Override
	public String toString() {
		return "SwfMensaje [menCodmen=" + menCodmen + ", menCodmt=" + menCodmt + ", menNrocorr=" + menNrocorr + ", menNroswift=" + menNroswift
				+ ", menCodswift=" + menCodswift + ", menNrolote=" + menNrolote + ", menEmisor=" + menEmisor + ", menReceiver=" + menReceiver + ", menBic="
				+ menBic + ", menBiccodctrl=" + menBiccodctrl + ", menBicbranch=" + menBicbranch + ", menCodmon=" + menCodmon + ", menGestion=" + menGestion
				+ ", menRefer=" + menRefer + ", menInout=" + menInout + ", menDestinatario=" + menDestinatario + ", menCodusrswf=" + menCodusrswf
				+ ", menFecauto=" + menFecauto + ", menFecreg=" + menFecreg + ", menTabestverifica=" + menTabestverifica + ", menEstverifica="
				+ menEstverifica + ", menTabestautoriza=" + menTabestautoriza + ", menEstautoriza=" + menEstautoriza + ", menUsrlvdverifica="
				+ menUsrlvdverifica + ", menHash=" + menHash + ", menCodapp=" + menCodapp + ", menFirmaorigen=" + menFirmaorigen + ", menAuditfho="
				+ menAuditfho + ", menAuditusr=" + menAuditusr + ", menAuditwst=" + menAuditwst + ", block4List="
				+ (block4List != null ? block4List.size() : 0) + "]";
	}

	public Integer getMenTabestmensaje() {
		return menTabestmensaje;
	}

	public void setMenTabestmensaje(Integer menTabestmensaje) {
		this.menTabestmensaje = menTabestmensaje;
	}

	public Integer getMenEstmensaje() {
		return menEstmensaje;
	}

	public void setMenEstmensaje(Integer menEstmensaje) {
		this.menEstmensaje = menEstmensaje;
	}

	public GenDesctabla getGenDesctablaEstverifica() {
		return genDesctablaEstverifica;
	}

	public void setGenDesctablaEstverifica(GenDesctabla genDesctablaEstverifica) {
		this.genDesctablaEstverifica = genDesctablaEstverifica;
	}

	public String getMenIdtmessagetx() {
		return menIdtmessagetx;
	}

	public void setMenIdtmessagetx(String menIdtmessagetx) {
		this.menIdtmessagetx = menIdtmessagetx;
	}

	public String getMenFormato() {
		return menFormato;
	}

	public void setMenFormato(String menFormato) {
		this.menFormato = menFormato;
	}

	public String getMenMonswift() {
		return menMonswift;
	}

	public void setMenMonswift(String menMonswift) {
		this.menMonswift = menMonswift;
	}

}
