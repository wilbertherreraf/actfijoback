package gob.bcb.lavado.search;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

/**
 * Records matches from a match run for a specific {@link InputDocument} within a {@link DocumentBatch}
 * @param <T> the type of {@link QueryMatch} recorded
 */
public class DocumentMatches<T extends QueryMatch> implements Iterable<T> {

    private final String docId;
    private final Collection<T> matches;

    /** Create a DocumentMatches object recording no matches for a given document */
    public static <T extends QueryMatch> DocumentMatches<T> noMatches(String docId) {
        return new DocumentMatches<>(docId, Collections.<T>emptyList());
    }

    /**
     * Create a DocumentMatches object for a specific document
     * @param docId the document id
     * @param matches a collection of QueryMatch objects
     */
    public DocumentMatches(String docId, Collection<T> matches) {
        this.docId = docId;
        this.matches = matches;
    }

    @Override
    public Iterator<T> iterator() {
        return matches.iterator();
    }

    /** Return the docid for this object */
    public String getDocId() {
        return docId;
    }

    /** Return the matches for this object */
    public Collection<T> getMatches() {
        return matches;
    }
}
