package gob.bcb.lavado.repository;

import java.util.Collection;

import gob.bcb.lavado.model.OfaIdlist;

public interface OfaIdlistDao {

	//@Override
	Collection<OfaIdlist> loadOfaIdlists(Integer userId);

}