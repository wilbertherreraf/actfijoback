package gob.bcb.swift.commons;

import gob.bcb.core.utils.StringFormat;
import gob.bcb.core.utils.UtilsGeneric;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.prowidesoftware.swift.model.field.SwiftParseUtils;

public class MensSwiftUtiles {
	public static int MAX_LINE_CHARS = 35;
	public static String EOF = "@EOF@";
	
	/**
	 * divide una cadena en lineas menores a 35 caracteres 
	 * @param valor
	 * @param linesMax lineas maximo del resultado
	 * @param suffix cadena de separacion por linea
	 * @param cadenaInicio 
	 * @param startLine
	 * @return
	 */
	public static List<String> splitInLines(String valor, int linesMax, String suffix, String cadenaInicio, int startLine) {
		String frase = "";
		List<String> result = new ArrayList<String>();
		cadenaInicio = StringUtils.trimToEmpty(cadenaInicio);
		int line = 0;
		String prefijo = "";
		
		valor = StringUtils.trimToEmpty(valor);
		valor = MensSwiftUtiles.reemplazarCaracteresInvalidos(valor);
		valor = StringUtils.replaceChars(valor, "\r\n", "  ");		
		valor = StringUtils.replace(valor, "//", " ");
		do {
			valor = StringUtils.trimToEmpty(valor);			
			if (line >= startLine && StringUtils.isNotBlank(valor)) {
				prefijo = cadenaInicio;
			} else {
				prefijo = "";
			}
			valor = prefijo.concat(valor);
			frase = UtilsGeneric.truncate(valor, MAX_LINE_CHARS, EOF, true);
			frase = StringUtils.trimToEmpty(frase);
			
			if (StringUtils.isNotBlank(frase)) {
				int lastSpace = frase.lastIndexOf(EOF);

				frase = frase.substring(0,lastSpace);
				valor = valor.substring(frase.length());
				
				frase = (frase.startsWith("-") ? frase.replaceFirst("-", "") : frase);
				frase = StringUtils.trimToEmpty(frase);
				result.add(frase);				
				line++;
			}
		} while (valor.length() > 0 && result.size() < linesMax);
		
		return result;
	}

	public static String newStringFromBytes(byte[] bytes, String charsetName) {
		try {
			return new String(bytes, charsetName);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("Impossible failure: Charset.forName(\"" + charsetName + "\") returns invalid name.");

		}
	}
	
	public static String charsInvalids = "ÁÉÍÓÚÑáéíóúñ?\"";
	public static String charsValids =   "AEIOUNaeioun  ";

	public static boolean isValidoConcepto(String valor, String ctrlPalabras) {
		valor = StringUtils.trimToEmpty(valor);
		valor = reemplazarCaracteresInvalidos(valor);
		String[] arrValor = StringUtils.split(valor, " ,;\r\n//");
		String[] arrCtrlPalabras = StringUtils.split(ctrlPalabras, " ,;");

		boolean containsStringsIntoArray = StringFormat.containsStringsIntoArray(arrValor, arrCtrlPalabras, true);
		System.out.println(ArrayUtils.toString(arrValor) + " " + ArrayUtils.toString(arrCtrlPalabras) + " containsStringsIntoArray "
				+ containsStringsIntoArray);
		return !containsStringsIntoArray;
	}

	public static String reemplazarCaracteresInvalidos(String valor) {
		valor = StringUtils.trimToEmpty(valor);
		if (StringUtils.isBlank(valor)) {
			return valor;
		}
		String nuevovalor = StringUtils.replaceChars(valor, charsInvalids, charsValids);
		return nuevovalor;
	}

	public static final Charset UTF8_CHARSET = Charset.forName("UTF-8");
}
