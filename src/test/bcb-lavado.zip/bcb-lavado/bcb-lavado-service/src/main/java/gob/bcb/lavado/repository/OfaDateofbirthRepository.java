package gob.bcb.lavado.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaDateofbirth;

@Repository
public interface OfaDateofbirthRepository extends JpaRepository<OfaDateofbirth, Integer> {

}
