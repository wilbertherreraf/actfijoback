package gob.bcb.lavado.repository;

import gob.bcb.lavado.model.SwfTipomensaje;


public interface SwfTipomensajeDao {

	SwfTipomensaje getByCodigo(String timCodmt);

}
