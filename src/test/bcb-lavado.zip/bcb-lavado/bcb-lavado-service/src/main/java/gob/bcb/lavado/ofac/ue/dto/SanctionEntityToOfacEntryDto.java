package gob.bcb.lavado.ofac.ue.dto;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

import gob.bcb.lavado.model.OfaAddresslist;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaDateofbirth;
import gob.bcb.lavado.model.OfaIdlist;
import gob.bcb.lavado.model.OfaPlaceofbirth;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.ofac.ue.model.Birthdate;
import gob.bcb.lavado.ofac.ue.model.Identification;
import gob.bcb.lavado.ofac.ue.model.NameAlias;
import gob.bcb.lavado.ofac.ue.model.Regulation;
import gob.bcb.lavado.ofac.ue.model.SanctionEntity;
import gob.bcb.lavado.ofac.ue.model.SubjectType;

/**
 * mapeo de lista Union Europea a estructura OFAC
 * 
 * @author WHerrera
 *
 */
public class SanctionEntityToOfacEntryDto {
	/*******************************************
	 * UE UE UE UE UE UE
	 *****************************/

	public static OfaSdnentry sdnEntryToOfaSdnentry(SanctionEntity sdnEntry) {
		if (sdnEntry == null) {
			return null;
		}

		OfaSdnentry ofaSdnentry = new OfaSdnentry();
		ofaSdnentry.setSdnEntryuid(sdnEntry.getLogicalId());

		if (sdnEntry.getNameAlias().size() > 0) {
			SubjectType subjectType = sdnEntry.getSubjectType();
			Regulation regulation = sdnEntry.getRegulation();
			boolean found = false;
			for (NameAlias nameAlias : sdnEntry.getNameAlias()) {
				String detectedCharset = charset(nameAlias.getWholeName(), new String[] { "ISO-8859-1", "UTF-8" });
				if (detectedCharset.equals("ISO-8859-1")) {
					// ofaSdnentry.setSdnFirstname(nameAlias.getFirstName());
					// ofaSdnentry.setSdnFirstname(nameAlias.getWholeName());
					ofaSdnentry.setSdnLastname(nameAlias.getWholeName());
					ofaSdnentry.setSdnTitle(nameAlias.getTitle());
					String type = subjectType.getClassificationCode() != null ? subjectType.getClassificationCode() : "P";
					type = type.equalsIgnoreCase("P") ? "individual" : (type.equalsIgnoreCase("E") ? "entity" : subjectType.getCode());
					ofaSdnentry.setSdnSdntype(type); // individual - o quitar de las estrategias
					ofaSdnentry.setSdnRemarks(convert(sdnEntry.getRemark(), "UTF-8", "ISO-8859-1"));
					ofaSdnentry.setSdnProgramlist(regulation.getProgramme());
					found = true;
					break;
				}
			}

			if (!found ) {
				NameAlias nameAlias = sdnEntry.getNameAlias().get(0);
				
				ByteBuffer buffer = StandardCharsets.UTF_8.encode(nameAlias.getWholeName()); 
				String utf8EncodedString = StandardCharsets.ISO_8859_1.decode(buffer).toString();
				
				// ofaSdnentry.setSdnFirstname(nameAlias.getFirstName());
				// ofaSdnentry.setSdnFirstname(nameAlias.getWholeName());
				ofaSdnentry.setSdnLastname(utf8EncodedString);
				ofaSdnentry.setSdnTitle(nameAlias.getTitle());
				String type = subjectType.getClassificationCode() != null ? subjectType.getClassificationCode() : "P";
				type = type.equalsIgnoreCase("P") ? "individual" : (type.equalsIgnoreCase("E") ? "entity" : subjectType.getCode());
				ofaSdnentry.setSdnSdntype(type); // individual - o quitar de las estrategias
				//ofaSdnentry.setSdnRemarks(sdnEntry.getRemark());
				ofaSdnentry.setSdnRemarks(convert(sdnEntry.getRemark(), "UTF-8", "ISO-8859-1"));
				ofaSdnentry.setSdnProgramlist(regulation.getProgramme());				
			}
		}
		return ofaSdnentry;

	}

	public static Set<OfaAddresslist> addressListToOfaAddresslist(SanctionEntity sdnEntry) {
		if (sdnEntry.getAddress() == null) {
			return null;
		}
		Set<OfaAddresslist> ofaIdlists = new HashSet<>();

		for (gob.bcb.lavado.ofac.ue.model.Address id : sdnEntry.getAddress()) {
			OfaAddresslist ofaIdlist = new OfaAddresslist();

			// ofaIdlist.setAdrEntryuid(sdnEntry.getLogicalId());
			ofaIdlist.setAdrUid(Integer.valueOf(id.getLogicalId()));
			ofaIdlist.setAdrAddress1(convert(id.getStreet(), "UTF-8", "ISO-8859-1"));
			ofaIdlist.setAdrCity(convert(id.getCity(), "UTF-8", "ISO-8859-1"));
			ofaIdlist.setAdrStateorprovinc(convert(id.getPlace(), "UTF-8", "ISO-8859-1"));
			ofaIdlist.setAdrPostalcode(id.getZipCode());
			ofaIdlist.setAdrCountry(id.getCountryIso2Code());

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public static Set<OfaDateofbirth> dateOfBirthListToOfaDateofbirth(SanctionEntity sdnEntry) {
		if (sdnEntry.getBirthdate() == null) {
			return null;
		}
		Set<OfaDateofbirth> ofaIdlists = new HashSet<>();

		for (Birthdate id : sdnEntry.getBirthdate()) {
			OfaDateofbirth ofaIdlist = new OfaDateofbirth();

			// ofaIdlist.setBirEntryuid(sdnEntry.getLogicalId());
			ofaIdlist.setBirUid(id.getLogicalId());
			ofaIdlist.setBirDateofbirth(id.getBirthdate());
			ofaIdlist.setBirMainentry(id.getCountryIso2Code());

			// log.info("dateeee " + sdnEntry.getUid() + " - "+id.getUid() + " " +
			// Boolean.toString(id.isMainEntry()));
			ofaIdlists.add(ofaIdlist);
		}

		return ofaIdlists;
	}

	public static Set<OfaPlaceofbirth> placeOfBirthListToOfaPlaceofbirth(SanctionEntity sdnEntry) {
		if (sdnEntry.getBirthdate() == null) {
			return null;
		}
		Set<OfaPlaceofbirth> ofaIdlists = new HashSet<>();

		for (Birthdate id : sdnEntry.getBirthdate()) {
			OfaPlaceofbirth ofaIdlist = new OfaPlaceofbirth();

			// ofaIdlist.setPobEntryuid(sdnEntry.getLogicalId());
			ofaIdlist.setPobUid(id.getLogicalId());
			ofaIdlist.setPobPlaceofbirth(convert(id.getCountryDescription(), "UTF-8", "ISO-8859-1"));
			ofaIdlist.setPobMainentry(convert(id.getPlace(), "UTF-8", "ISO-8859-1"));

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public static Set<OfaAkalist> akaListToOfaAkalist(SanctionEntity sdnEntry) {
		if (sdnEntry.getNameAlias() == null) {
			return null;
		}
		Set<OfaAkalist> ofaIdlists = new HashSet<>();

		SubjectType subjectType = sdnEntry.getSubjectType();

		for (NameAlias nameAlias : sdnEntry.getNameAlias()) {
			OfaAkalist ofaIdlist = new OfaAkalist();
			// ofaIdlist.setAkaEntryuid(sdnEntry.getLogicalId());
			ofaIdlist.setAkaUid(nameAlias.getLogicalId());
			// ofaIdlist.setAkaFirstname(id.getFirstName());
			ofaIdlist.setAkaCategory((nameAlias.getStrong() != null ? nameAlias.getStrong() : "false").equalsIgnoreCase("TRUE") ? "strong" : "weak");
			ofaIdlist.setAkaType(subjectType.getCode());
			
			String detectedCharset = charset(nameAlias.getWholeName(), new String[] { "ISO-8859-1", "UTF-8" });
			if (detectedCharset.equals("ISO-8859-1")) {
				ofaIdlist.setAkaLastname(nameAlias.getWholeName());
			} else {
				ByteBuffer buffer = StandardCharsets.UTF_8.encode(nameAlias.getWholeName()); 
				String utf8EncodedString = StandardCharsets.ISO_8859_1.decode(buffer).toString();

				ofaIdlist.setAkaLastname(utf8EncodedString);				
			}

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public static Set<OfaIdlist> identificationListToOfaIdlist(SanctionEntity sdnEntry) {
		if (sdnEntry.getIdentification() == null) {
			return null;
		}
		Set<OfaIdlist> ofaIdlists = new HashSet<>();

		for (Identification id : sdnEntry.getIdentification()) {
			OfaIdlist ofaIdlist = new OfaIdlist();

			// ofaIdlist.setIdlEntryuid(sdnEntry.getUid());
			ofaIdlist.setIdlUid(id.getLogicalId());
			ofaIdlist.setIdlIdtype(convert(id.getIdentificationTypeDescription(), "UTF-8", "ISO-8859-1"));
			ofaIdlist.setIdlIdnumber(convert(id.getNumber(), "UTF-8", "ISO-8859-1"));
			ofaIdlist.setIdlIdcountry(convert(id.getCountryDescription(), "UTF-8", "ISO-8859-1"));
			ofaIdlist.setIdlIssuedate(convert(id.getNameOnDocument(), "UTF-8", "ISO-8859-1"));
//			ofaIdlist.setIdlExpirationdate(id.getExpirationDate());

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public static String convert(String value, String fromEncoding, String toEncoding) {
		if (value == null || value.trim().isEmpty())
			return "";
		try {
			return new String(value.getBytes(fromEncoding), toEncoding);
		} catch (UnsupportedEncodingException e) {
			return "";
		}
	}

	public static String charset(String value, String charsets[]) {
		if (value == null || value.trim().isEmpty())
			return value;
		
		String probe = StandardCharsets.UTF_8.name();
		for (String c : charsets) {
			Charset charset = Charset.forName(c);
			if (charset != null) {
				if (value.equals(convert(convert(value, charset.name(), probe), probe, charset.name()))) {
					return c;
				}
			}
		}
		return StandardCharsets.UTF_8.name();
	}
}
