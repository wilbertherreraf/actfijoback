package gob.bcb.lavado.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaIdlist;

@Repository
public interface OfaIdlistRepository extends JpaRepository<OfaIdlist, Integer>{ // extends JpaRepository<OfaIdlist, Integer> {
	List<OfaIdlist> findByIdlEntryuid(@Param("idlEntryuid") Integer idlEntryuid);
	//Page<OfaIdlist> findByIdlEntryuid(@Param("idlEntryuid") Integer idlEntryuid, Pageable pageable);

	Page<OfaIdlist> findByIdlEntryuid(Integer id, Pageable pageable);
	
}
