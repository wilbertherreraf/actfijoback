package gob.bcb.lavado.search.queryparsers;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.OfacQuery;

public class OfacQueryBuilder {
	private final Logger log = LoggerFactory.getLogger(OfacQueryBuilder.class);

	public OfacQueryBuilder() {
	}
	
	public OfacQuery createOfacQuery(String query, final FieldQuery fieldQuery, Query queryLucene) {
		OfacQuery ofacQuery = createOfacQuery( null, fieldQuery.getId(), fieldQuery.getField(), query, queryLucene);
		ofacQuery.setFieldQuery(fieldQuery);
		
		return ofacQuery;
	}
	
	public OfacQuery createOfacQuery(String queryId, String docId, String field, String query, Query queryLucene) {
		if (queryLucene == null) {
			return null;
		}
		// String queryIdQ = String.valueOf(Objects.hash(field,
		// queryLucene.toString()));
		String queryIdQ = String.valueOf(Objects.hash(field, query));//field + ":" + query;
		OfacQuery ofacQuery = new OfacQuery(queryIdQ, docId, query, queryLucene);
		ofacQuery.setField(field);

		ofacQuery.setType(OfacQuery.Type.EXACT);
		if (queryLucene instanceof FuzzyQuery) 
			ofacQuery.setType(OfacQuery.Type.ANY);
		
		return ofacQuery;
	}

}
