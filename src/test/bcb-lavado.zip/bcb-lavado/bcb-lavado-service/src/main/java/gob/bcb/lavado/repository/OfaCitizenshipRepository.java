package gob.bcb.lavado.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaCitizenship;

@Repository
public interface OfaCitizenshipRepository extends JpaRepository<OfaCitizenship,Integer>{

}
