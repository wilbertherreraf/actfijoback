package gob.bcb.lavado.ofac.xml.sdn;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the gob.bcb.lavado.ofac.xml.sdn package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: gob.bcb.lavado.ofac.xml.sdn
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SdnList }
     * 
     */
    public SdnList createSdnList() {
        return new SdnList();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry }
     * 
     */
    public SdnList.SdnEntry createSdnListSdnEntry() {
        return new SdnList.SdnEntry();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.PlaceOfBirthList }
     * 
     */
    public SdnList.SdnEntry.PlaceOfBirthList createSdnListSdnEntryPlaceOfBirthList() {
        return new SdnList.SdnEntry.PlaceOfBirthList();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.DateOfBirthList }
     * 
     */
    public SdnList.SdnEntry.DateOfBirthList createSdnListSdnEntryDateOfBirthList() {
        return new SdnList.SdnEntry.DateOfBirthList();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.CitizenshipList }
     * 
     */
    public SdnList.SdnEntry.CitizenshipList createSdnListSdnEntryCitizenshipList() {
        return new SdnList.SdnEntry.CitizenshipList();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.NationalityList }
     * 
     */
    public SdnList.SdnEntry.NationalityList createSdnListSdnEntryNationalityList() {
        return new SdnList.SdnEntry.NationalityList();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.AddressList }
     * 
     */
    public SdnList.SdnEntry.AddressList createSdnListSdnEntryAddressList() {
        return new SdnList.SdnEntry.AddressList();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.AkaList }
     * 
     */
    public SdnList.SdnEntry.AkaList createSdnListSdnEntryAkaList() {
        return new SdnList.SdnEntry.AkaList();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.IdList }
     * 
     */
    public SdnList.SdnEntry.IdList createSdnListSdnEntryIdList() {
        return new SdnList.SdnEntry.IdList();
    }

    /**
     * Create an instance of {@link SdnList.PublshInformation }
     * 
     */
    public SdnList.PublshInformation createSdnListPublshInformation() {
        return new SdnList.PublshInformation();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.ProgramList }
     * 
     */
    public SdnList.SdnEntry.ProgramList createSdnListSdnEntryProgramList() {
        return new SdnList.SdnEntry.ProgramList();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.VesselInfo }
     * 
     */
    public SdnList.SdnEntry.VesselInfo createSdnListSdnEntryVesselInfo() {
        return new SdnList.SdnEntry.VesselInfo();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.PlaceOfBirthList.PlaceOfBirthItem }
     * 
     */
    public SdnList.SdnEntry.PlaceOfBirthList.PlaceOfBirthItem createSdnListSdnEntryPlaceOfBirthListPlaceOfBirthItem() {
        return new SdnList.SdnEntry.PlaceOfBirthList.PlaceOfBirthItem();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.DateOfBirthList.DateOfBirthItem }
     * 
     */
    public SdnList.SdnEntry.DateOfBirthList.DateOfBirthItem createSdnListSdnEntryDateOfBirthListDateOfBirthItem() {
        return new SdnList.SdnEntry.DateOfBirthList.DateOfBirthItem();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.CitizenshipList.Citizenship }
     * 
     */
    public SdnList.SdnEntry.CitizenshipList.Citizenship createSdnListSdnEntryCitizenshipListCitizenship() {
        return new SdnList.SdnEntry.CitizenshipList.Citizenship();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.NationalityList.Nationality }
     * 
     */
    public SdnList.SdnEntry.NationalityList.Nationality createSdnListSdnEntryNationalityListNationality() {
        return new SdnList.SdnEntry.NationalityList.Nationality();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.AddressList.Address }
     * 
     */
    public SdnList.SdnEntry.AddressList.Address createSdnListSdnEntryAddressListAddress() {
        return new SdnList.SdnEntry.AddressList.Address();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.AkaList.Aka }
     * 
     */
    public SdnList.SdnEntry.AkaList.Aka createSdnListSdnEntryAkaListAka() {
        return new SdnList.SdnEntry.AkaList.Aka();
    }

    /**
     * Create an instance of {@link SdnList.SdnEntry.IdList.Id }
     * 
     */
    public SdnList.SdnEntry.IdList.Id createSdnListSdnEntryIdListId() {
        return new SdnList.SdnEntry.IdList.Id();
    }

}
