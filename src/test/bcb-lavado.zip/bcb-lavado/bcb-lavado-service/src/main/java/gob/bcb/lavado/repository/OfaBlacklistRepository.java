package gob.bcb.lavado.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaBlacklist;

@Repository
public interface OfaBlacklistRepository extends JpaRepository<OfaBlacklist, Integer> {
	@Query("select t from OfaBlacklist t where t.blkId = (select max(m.blkId) from OfaBlacklist m) ")
	Optional<OfaBlacklist> findOneMaximo();
	
}
