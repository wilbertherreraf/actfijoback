//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.05.17 a las 11:37:50 AM BOT 
//


package gob.bcb.lavado.ofac.ue.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}regulationSummary"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="circa" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="calendarType" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="city" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="zipCode" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="birthdate" type="{http://www.w3.org/2001/XMLSchema}date" /&gt;
 *       &lt;attribute name="dayOfMonth" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="monthOfYear" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="year" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="region" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="place" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="countryIso2Code" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="countryDescription" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="regulationLanguage" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="logicalId" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "regulationSummary"
})
@XmlRootElement(name = "birthdate")
public class Birthdate {

    @XmlElement(required = true)
    protected RegulationSummary regulationSummary;
    @XmlAttribute(name = "circa")
    protected String circa;
    @XmlAttribute(name = "calendarType")
    protected String calendarType;
    @XmlAttribute(name = "city")
    protected String city;
    @XmlAttribute(name = "zipCode")
    protected String zipCode;
    @XmlAttribute(name = "birthdate")
    @XmlSchemaType(name = "date")
    protected String birthdate;
    @XmlAttribute(name = "dayOfMonth")
    protected Integer dayOfMonth;
    @XmlAttribute(name = "monthOfYear")
    protected Integer monthOfYear;
    @XmlAttribute(name = "year")
    protected Integer year;
    @XmlAttribute(name = "region")
    protected String region;
    @XmlAttribute(name = "place")
    protected String place;
    @XmlAttribute(name = "countryIso2Code")
    protected String countryIso2Code;
    @XmlAttribute(name = "countryDescription")
    protected String countryDescription;
    @XmlAttribute(name = "regulationLanguage")
    protected String regulationLanguage;
    @XmlAttribute(name = "logicalId")
    protected Integer logicalId;

    /**
     * Obtiene el valor de la propiedad regulationSummary.
     * 
     * @return
     *     possible object is
     *     {@link RegulationSummary }
     *     
     */
    public RegulationSummary getRegulationSummary() {
        return regulationSummary;
    }

    /**
     * Define el valor de la propiedad regulationSummary.
     * 
     * @param value
     *     allowed object is
     *     {@link RegulationSummary }
     *     
     */
    public void setRegulationSummary(RegulationSummary value) {
        this.regulationSummary = value;
    }

    /**
     * Obtiene el valor de la propiedad circa.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCirca() {
        return circa;
    }

    /**
     * Define el valor de la propiedad circa.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCirca(String value) {
        this.circa = value;
    }

    /**
     * Obtiene el valor de la propiedad calendarType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalendarType() {
        return calendarType;
    }

    /**
     * Define el valor de la propiedad calendarType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalendarType(String value) {
        this.calendarType = value;
    }

    /**
     * Obtiene el valor de la propiedad city.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Define el valor de la propiedad city.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Obtiene el valor de la propiedad zipCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZipCode() {
        return zipCode;
    }

    /**
     * Define el valor de la propiedad zipCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZipCode(String value) {
        this.zipCode = value;
    }

    /**
     * Obtiene el valor de la propiedad birthdate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public String getBirthdate() {
        return birthdate;
    }

    /**
     * Define el valor de la propiedad birthdate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBirthdate(String value) {
        this.birthdate = value;
    }

    /**
     * Obtiene el valor de la propiedad dayOfMonth.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDayOfMonth() {
        return dayOfMonth;
    }

    /**
     * Define el valor de la propiedad dayOfMonth.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDayOfMonth(Integer value) {
        this.dayOfMonth = value;
    }

    /**
     * Obtiene el valor de la propiedad monthOfYear.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMonthOfYear() {
        return monthOfYear;
    }

    /**
     * Define el valor de la propiedad monthOfYear.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMonthOfYear(Integer value) {
        this.monthOfYear = value;
    }

    /**
     * Obtiene el valor de la propiedad year.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getYear() {
        return year;
    }

    /**
     * Define el valor de la propiedad year.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setYear(Integer value) {
        this.year = value;
    }

    /**
     * Obtiene el valor de la propiedad region.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegion() {
        return region;
    }

    /**
     * Define el valor de la propiedad region.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegion(String value) {
        this.region = value;
    }

    /**
     * Obtiene el valor de la propiedad place.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlace() {
        return place;
    }

    /**
     * Define el valor de la propiedad place.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlace(String value) {
        this.place = value;
    }

    /**
     * Obtiene el valor de la propiedad countryIso2Code.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryIso2Code() {
        return countryIso2Code;
    }

    /**
     * Define el valor de la propiedad countryIso2Code.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryIso2Code(String value) {
        this.countryIso2Code = value;
    }

    /**
     * Obtiene el valor de la propiedad countryDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryDescription() {
        return countryDescription;
    }

    /**
     * Define el valor de la propiedad countryDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryDescription(String value) {
        this.countryDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad regulationLanguage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegulationLanguage() {
        return regulationLanguage;
    }

    /**
     * Define el valor de la propiedad regulationLanguage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegulationLanguage(String value) {
        this.regulationLanguage = value;
    }

    /**
     * Obtiene el valor de la propiedad logicalId.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLogicalId() {
        return logicalId;
    }

    /**
     * Define el valor de la propiedad logicalId.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLogicalId(Integer value) {
        this.logicalId = value;
    }

}
