package gob.bcb.lavado.repository;

import gob.bcb.lavado.model.GenTablas;

public interface GenTablasDao {

}
