package gob.bcb.lavado.repository;

import java.util.Date;

import java.util.List;

import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfDetmensaje;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfTipomensaje;
import gob.bcb.lavado.pojos.Asignacion;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.swift.pojos.SwiftDatos;

public interface SwfMensajeDao {
	SwfMensaje findByCodigo(Integer menCodmen);

	SwfMensaje cambiarEstadoAsignacion(SwfMensaje swfMensaje, Integer nuevoEstado);

	void verificaEstado(SwfMensaje swfMensaje);

	List<SwfAsignamensaje> asignacionesByCodEmpEstRev(Integer resCodmen, Integer resCodemp, Integer estRevision);

	MensajesDatos mensajeDatosFromSwfMensaje(SwfMensaje swfMensaje, SwfBics swfBics, SwfTipomensaje swfTipomensaje, Integer codempleado,
			Integer estRevision, boolean recuperaAsignacion);
	
	List<SwfMensaje> findObservados(Integer menEstverifica);

	SwfMensaje registrarNuevo(SwfMensaje swfMensaje);

	List<MensajesDatos> buscarMensajesEntrantes(SwfMensaje swfMensaje, Integer resCodempasig, Integer resCodemp, Integer resEstrevision, Date conFecinicio, Date conFecfin,
			Integer codEmpleadoFiltro);

	List<SwfMensaje> buscarMensajesEntrantes(SwfMensaje swfMensaje, Integer resCodempasig, Integer resCodemp, Integer resEstrevision, Date conFecinicio, Date conFecfin);
	
	List<SwfMensaje> findByNroLote(Integer menNrolote);

	SwfMensaje findByHash(String menHash, String menInout);

	SwfMensaje cambiarEstadoPostScan(Integer codMen, Integer countRegs, String accionScan);

	List<SwfMensaje> findByEstautoriza(Integer menEstautoriza, Integer menEstmensaje);

	List<SwfMensaje> findByCodOperacion(String menRefer, String menCodapp);

	SwfMensaje solicitarCorrelativo(String codapp, String codUsuario, String codoperacion, String estacion, String idSession);

	SwfMensaje cambiarEstadoVerificacion(Integer codMen, String codUsuario, Integer newEstado, String estacion);

	Integer cerrarTransaccion(String idsession);

	SwiftDatos preAutorizarSwift(Integer codlvd, String codapp, String coduser, String codoperacion, String idSession, String menPlano, String estacion,
			String codelau);
	
	SwiftDatos preAutorizaSwift(Integer menCodmen, String codapp, String coduser, String codoperacion, String idsession, String menPlano, String estacion, String codelau);

	SwiftDatos actualizarConPlano(String menPlano, String codapp, Integer menCodmen, Integer nroCorrelativo, String codoperacion, String coduser, String estacion,
			String idsession, String codelau);

	SwfMensaje guardarEnImportados(Integer codMen, String codUsuario, String pathDirSwift, String estacion);

	SwfMensaje cambiarEstadoAutorizacion(Integer codMen, String codUsuario, Integer newEstado, String estacion);

	List<SwfAsignamensaje> asignacionesDeATerceros(Integer resCodmen, Integer resCodemp, Integer estRevision);

	SwfAsignamensaje swfAsignamensajeCodigo(Integer resCodmen, Integer resCodemp);

	List<SwfAsignamensaje> asignacionesByEmpMasHijos(Integer resCodmen, Integer resCodemp, Integer estRevision);

	SwfMensaje updateRegSinEnc(SwfMensaje swfMensaje);

	String getDirectorySwiftFromMsg(FileFormat standard);

	



}
