package gob.bcb.lavado.search.presearcher;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.search.CandidateMatcher;
import gob.bcb.lavado.search.DocumentBatch;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.MatcherFactory;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.Presearcher;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.facet.FacetQueryOfac;
import gob.bcb.lavado.search.queryparsers.OfacQueryBuilder;
import gob.bcb.lavado.search.queryparsers.QueryParsersBuilder;

import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.spans.SpanNearQuery;
import org.apache.lucene.search.spans.SpanOrQuery;
import org.apache.lucene.search.spans.SpanQuery;
import org.hibernate.search.jpa.FullTextQuery;

/**
 * CandidateMatcher class that will return exact hit positions for all matching
 * queries
 *
 * If a stored query cannot be rewritten so as to extract Spans, a
 * {@link HighlightsMatch} object with no Hit positions will be returned.
 */

public class HighlightingMatcher extends CandidateMatcher<SearchResultOfac> {
	private static final Logger log = LoggerFactory.getLogger(HighlightingMatcher.class);
	private final FacetQueryOfac facetQueryOfac;
	Map<String, OfacQuery> matchesFieldQuery = new HashMap<>();
	public final static float DEFAULT_WEIGHT = 0.3f;

	public HighlightingMatcher(DocumentBatch<?> batch, FacetQueryOfac facetQueryOfac) {
		super(batch);
		this.facetQueryOfac = facetQueryOfac;
		this.setWeightSearch(DEFAULT_WEIGHT);
	}

	public HighlightingMatcher(DocumentBatch<?> batch, FacetQueryOfac facetQueryOfac, float weightSearch) {
		this(batch, facetQueryOfac);
		this.setWeightSearch(weightSearch);
	}

	@Override
	protected void doMatchQuery(String queryId, SearchResultOfac matchQuery, Map<String, String> metadata) throws IOException {
		if (matchQuery == null)
			return;
		findHighlights(queryId, matchQuery);
	}

	@Override
	public void addMatch(SearchResultOfac match) {
		super.addMatch(match);
	}

	@Override
	public SearchResultOfac resolve(SearchResultOfac match1, SearchResultOfac match2) {
		return match1.getOfacQuery().getScore() < match2.getOfacQuery().getScore() ? match2 : match1;
	}

	@Override
	protected SearchResultOfac doMatch(SearchResultOfac match) {
		match.addMatch(match.getOfacQuery().getQueryId(), match.getOfacQuery().getField(), match.getOfacQuery());
		return match;
	}

	@Override
	public List<SearchResultOfac> adjustComponent(SearchResultOfac searchResultOfacP) throws IOException {
		return null;
	}

	protected void findHighlights(String query, SearchResultOfac searchResultOfac) {
		OfacQueryBuilder ofacQueryBuilder = new OfacQueryBuilder();
		String querySpan = "";
		String textSpan = "";
		for (OfacQuery ofacQueryMatch : searchResultOfac.getMatches()) {
			QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(facetQueryOfac.getjPASearchFactoryController(),
					ofacQueryMatch.getFieldQuery().getClazz());
			// en lista ofac
			querySpan = ofacQueryMatch.getTerm();
			// texto
			textSpan = query;
			if (ofacQueryMatch.getFieldQuery().getTypeQ().equals("W")) {
				// white list
//				querySpan = query;
//				textSpan = ofacQueryMatch.getTerm();

			}

//			Query queryLucene = queryParsersBuilder.createQuerySpanNearFuzzy(ofacQueryMatch.getFieldQuery().getField(), querySpan,
//					ofacQueryMatch.getFieldQuery().getDistanceUpTo(), ofacQueryMatch.getFieldQuery().getPrefixLength(),
//					ofacQueryMatch.getFieldQuery().getBoost(), ofacQueryMatch.getFieldQuery().getSlop(), ofacQueryMatch.getFieldQuery().isInOrder(),
//					ofacQueryMatch.getFieldQuery().getMinWordLen(), ofacQueryMatch.getFieldQuery().isExceptNumbers(),
//					ofacQueryMatch.getFieldQuery().getAnalyzer());

			Query queryLucene = queryParsersBuilder.createQuerySpanNearFuzzy(ofacQueryMatch.getFieldQuery().getField(), querySpan,
					ofacQueryMatch.getFieldQuery().getDistanceUpTo(), ofacQueryMatch.getFieldQuery().getPrefixLength(),
					ofacQueryMatch.getFieldQuery().getBoost(), ofacQueryMatch.getFieldQuery().getSlop(), ofacQueryMatch.getFieldQuery().isInOrder(),
					ofacQueryMatch.getFieldQuery().getMinWordLen(), false,
					ofacQueryMatch.getFieldQuery().getAnalyzer());			
			if (queryLucene == null)
				continue;

			OfacQuery ofacQueryNew = ofacQueryBuilder.createOfacQuery(ofacQueryMatch.getTerm(), ofacQueryMatch.getFieldQuery(), queryLucene);

			ofacQueryNew.setScore(ofacQueryMatch.getScore());
			ofacQueryNew.setTerm(ofacQueryMatch.getTerm());
			try {
				String observed = queryParsersBuilder.highlightField(queryLucene, ofacQueryNew.getFieldQuery().getField(), textSpan,
						ofacQueryNew.getFieldQuery().getAnalyzer());

				log.debug(searchResultOfac.getDocId() + " ::> " + observed + " " + ofacQueryNew.getQueryId() + " " + ofacQueryNew.getField() + " query: "
						+ query + " term: " + ofacQueryMatch.getTerm() + " " + queryLucene + " typeQ: " + ofacQueryNew.getFieldQuery().getTypeQ());

				if (!StringUtils.isBlank(observed)) {
					ofacQueryNew.setTermHigh(observed);
					SearchResultOfac searchResultOfacNew = new SearchResultOfac(ofacQueryNew.getQueryId(), searchResultOfac.getDocId());
					searchResultOfacNew.setDocumentMatch(searchResultOfac.getDocumentMatch());
					searchResultOfacNew.setScore(ofacQueryNew.getScore());
					searchResultOfacNew.setOfacQuery(ofacQueryNew);

					searchResultOfacNew.addMatch(ofacQueryNew.getQueryId(), ofacQueryNew.getField(), ofacQueryNew);
					log.debug("Query " + querySpan + " textSpan: " + textSpan + " typeQ: " + ofacQueryNew.getFieldQuery().getTypeQ());
					this.addMatch(searchResultOfacNew);
				}
			} catch (Exception e) {
				throw new RuntimeException("Error en math High " + e.getMessage(), e);
			}
		}
	}

	/**
	 * Imprime las consultas filtradas (solo para test o debug)
	 * 
	 * @param matchesFieldQuery
	 */
	public static void printOfacQueryMap(Map<String, Map<String, OfacQuery>> matchesFieldQuery) {
		log.info("===>Consultas: " + matchesFieldQuery.values().size() + " <====");
		for (Entry<String, Map<String, OfacQuery>> queryLucen : matchesFieldQuery.entrySet()) {
			Map<String, OfacQuery> ql = queryLucen.getValue();
			for (Entry<String, OfacQuery> oq : ql.entrySet()) {
				OfacQuery ofacQuery = oq.getValue();
				log.info("KEy: " + queryLucen.getKey() + " " + oq.getKey() + "\t, Id:" + ofacQuery.getQueryId() + "] " + ofacQuery.getDocId() + "[Sc: "
						+ ofacQuery.getScore() + ":" + ofacQuery.getQuery() + "] , LuceneQuery:[" + ofacQuery.getType() + "] " + ofacQuery.getLuceneQuery());
			}
		}
	}

	public static final MatcherFactory<SearchResultOfac> FACTORY = new MatcherFactory<SearchResultOfac>() {
		@Override
		public HighlightingMatcher createMatcher(DocumentBatch docs, FacetQueryOfac facetQueryOfac) {
			return new HighlightingMatcher(docs, facetQueryOfac);
		}
	};

}
