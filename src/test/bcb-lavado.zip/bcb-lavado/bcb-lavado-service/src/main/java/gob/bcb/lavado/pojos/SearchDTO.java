package gob.bcb.lavado.pojos;

import org.apache.commons.lang.StringUtils;
import org.apache.lucene.search.BooleanClause;

public class SearchDTO {
	public static final String _AND_ = "AND"; 
	public static final String _OR_ = "OR";
	public static final String _ANDNOT_ = "AND NOT";
	private String field;
	private String queryTemplate;	
	private String query;
	private String operatorToken = "OR";
	private Integer max;
	private String[] queries;
	private String[] fields;
	private BooleanClause.Occur[] flags;
	
	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public Integer getMax() {
		return max;
	}

	public void setMax(Integer maxResults) {
		this.max = maxResults;
	}

	public String getQueryTemplate() {
		return queryTemplate;
	}

	public void setQueryTemplate(String queryTemplate) {
		this.queryTemplate = queryTemplate;
	}

	public String getOperatorToken() {
		return (StringUtils.isBlank(operatorToken)?_OR_: operatorToken.trim().toUpperCase());
	}

	public void setOperatorToken(String operatorToken) {
		if (StringUtils.isBlank(operatorToken)){
			this.operatorToken = _OR_;
		}
		
		this.operatorToken = operatorToken;
	}

	public boolean isOperatorAND(){
		return (getOperatorToken().equals(_AND_));
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String[] getQueries() {
		return queries;
	}

	public void setQueries(String[] queries) {
		this.queries = queries;
	}

	public String[] getFields() {
		return fields;
	}

	public void setFields(String[] fields) {
		this.fields = fields;
	}

	public BooleanClause.Occur[] getFlags() {
		return flags;
	}

	public void setFlags(BooleanClause.Occur[] flags) {
		this.flags = flags;
	}
}
