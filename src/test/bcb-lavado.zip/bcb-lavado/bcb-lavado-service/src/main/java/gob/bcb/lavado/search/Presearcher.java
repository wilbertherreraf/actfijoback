package gob.bcb.lavado.search;

import java.util.List;

public interface Presearcher {

	List<OfacQuery> buildQuery(String query, List<FieldQuery> fieldQueryList);
	List<OfacQuery> buildQuery(String query, FieldQuery fieldQuery);
	List<OfacQuery> getOfacQueryList();
}
