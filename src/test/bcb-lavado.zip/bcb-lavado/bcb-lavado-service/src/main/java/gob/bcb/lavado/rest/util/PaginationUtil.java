package gob.bcb.lavado.rest.util;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.web.util.UriComponentsBuilder;

import gob.bcb.core.utils.UtilsGeneric;

/**
 * Utility class for handling pagination.
 *
 * <p>
 * Pagination uses the same principles as the
 * <a href="https://developer.github.com/v3/#pagination">Github API</a>, and
 * follow <a href="http://tools.ietf.org/html/rfc5988">RFC 5988 (Link
 * header)</a>.
 */
public class PaginationUtil {

    public static HttpHeaders generatePaginationHttpHeaders(Page<?> page, String baseUrl)
            throws URISyntaxException {

            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Total-Count", "" + page.getTotalElements());
            String link = "";
            if ((page.getNumber() + 1) < page.getTotalPages()) {
                link = "<" + generateUri(baseUrl, page.getNumber() + 1, page.getSize()) + ">; rel=\"next\",";
            }
            // prev link
            if ((page.getNumber()) > 0) {
                link += "<" + generateUri(baseUrl, page.getNumber() - 1, page.getSize()) + ">; rel=\"prev\",";
            }
            // last and first link
            int lastPage = 0;
            if (page.getTotalPages() > 0) {
                lastPage = page.getTotalPages() - 1;
            }
            link += "<" + generateUri(baseUrl, lastPage, page.getSize()) + ">; rel=\"last\",";
            link += "<" + generateUri(baseUrl, 0, page.getSize()) + ">; rel=\"first\"";
            headers.add(HttpHeaders.LINK, link);
            return headers;
        }

        private static String generateUri(String baseUrl, int page, int size) throws URISyntaxException {
            return UriComponentsBuilder.fromUriString(baseUrl).queryParam("page", page).queryParam("size", size).toUriString();
        }

	public static void parseLinks(String header){
		Map<String, String> mapr = new HashMap<>();
		Map<String, String> map = UtilsGeneric.paramsLista(header,",",";");
		for (Entry<String, String> e : map.entrySet()) {
			String a = e.getKey();
			String b = e.getValue();
			System.out.println(a + " | " + b);
			String url = a.replaceAll("<(.*)>", "$1").trim();
			System.out.println(url);
			String[] aa = url.split("[?]");
			Map<String, String> map2 = UtilsGeneric.paramsLista(aa[1],"&","=");
			for (Entry<String, String> e2 : map2.entrySet()) {
				String a2 = e2.getKey();
				String b2 = e2.getValue();
				System.out.println(a2 + " | " + b2);
			}
			map2 = UtilsGeneric.paramsLista(b,"&","=");
			for (Entry<String, String> e2 : map2.entrySet()) {
				String a2 = e2.getKey();
				String b2 = e2.getValue();
				System.out.println(a2 + " | " + b2);
			}			
		}
		
   	
    }
	public static void main(String[] args) {
		String s = "</api/banco/allbancos?page=1&size=20>; rel=\"next\",</api/banco/allbancos?page=79&size=20>; rel=\"last\",</api/banco/allbancos?page=0&size=20>; rel=\"first\"";
		parseLinks(s);		
	}
	
}
