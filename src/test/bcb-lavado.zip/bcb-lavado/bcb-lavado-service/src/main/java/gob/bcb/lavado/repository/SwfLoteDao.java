package gob.bcb.lavado.repository;

import java.util.List;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.pojos.MensajesDatos;

public interface SwfLoteDao {

	SwfLote findByCodigo(Integer lotNrolote);

	SwfLote saveOrUpdate(SwfLote swfLote);

	SwfLote guardarLote(Integer codEmpleado, SwfLote swfLoteNew, ArchivoSinple archivoSinple);

	List<SwfLote> findByTipolote(String lotTipolote);

	SwfLote guardarLoteOfac(String codEmpleado, ArchivoSinple archivoSinple, boolean grabaEnDirectorio, String estacion);

}
