package gob.bcb.lavado.security.crypto;

import java.security.GeneralSecurityException;
import java.security.Key;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

public class CryptoUtilImpl implements ICryptoUtil{	
	private static final Logger log = LoggerFactory.getLogger(CryptoUtilImpl.class);
	private CryptoProvider activeProvider;
	/**
	 * The size of a bare DSA signature (two 160-bit integers)
	 */
	static public final int BARE_DSA_SIGNATURE_SIZE = 40;

	public void initialize(String fileKeystore, String password, boolean createKeystoreFileIfNotExist) throws Exception {
		// Check preconditions: Maximum key length
		log.info("initialize CryptoUtil " + fileKeystore);
		activeProvider = new DefaultCryptoProvider(fileKeystore, password, createKeystoreFileIfNotExist);
	}

	public Key getCryptoKey(String seed) {
		return activeProvider.getKey(new ImmutablePair<KeyHive, String>(KeyHive.SYSTEM, seed));
	}

	private byte[] encryptBytes(byte[] data, Key key) {
		try {
			Cipher cipher = activeProvider.getCipher(key, Cipher.ENCRYPT_MODE);
			return cipher.doFinal(data);
		} catch (GeneralSecurityException e) {
			throw new CryptoException("Crypto engine failed to encrypt", e);
		}
	}

	private byte[] decryptBytes(byte[] data, Key key) throws IllegalBlockSizeException, BadPaddingException {
		try {
			Cipher cipher = activeProvider.getCipher(key, Cipher.DECRYPT_MODE);
			return cipher.doFinal(data);
		} catch (Exception e) {
			throw new CryptoException("Crypto engine failed to initialize decryption", e);
		}
	}

	// @Override
	public String encryptAndBase64(byte[] data, Key key) {
		return Base64.encodeBase64String(encryptBytes(data, key));
	}

	// @Override
	public byte[] decryptBase64(String base64andEncrypted, Key key) throws IllegalBlockSizeException, BadPaddingException {
		return decryptBytes(Base64.decodeBase64(base64andEncrypted), key);
	}

}
