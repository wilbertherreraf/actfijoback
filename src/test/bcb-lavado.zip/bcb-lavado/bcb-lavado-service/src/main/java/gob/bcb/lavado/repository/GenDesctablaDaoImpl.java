package gob.bcb.lavado.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.GenDesctabla;

@Repository("genDesctablaDao")
//@Transactional
public class GenDesctablaDaoImpl implements GenDesctablaDao {
	private static final Logger log = LoggerFactory.getLogger(GenDesctablaDaoImpl.class);
	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;
	
	@Autowired
	@Qualifier("entityManagerFactory")	
	private EntityManagerFactory entityManagerFactory;

	
	public List<GenDesctabla> findByDesCodtab(Integer desCodtab){
		String jpql = "SELECT t FROM gob.bcb.lavado.model.GenDesctabla t WHERE t.id.desCodtab = :desCodtab";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("desCodtab", desCodtab);
		List lista = query.getResultList();

		return lista;
		
	}
	public GenDesctabla findByDesCodtab(Integer desCodtab, Integer desCodigo){
		String jpql = "SELECT t FROM gob.bcb.lavado.model.GenDesctabla t WHERE t.id.desCodtab = :desCodtab and t.id.desCodigo = :desCodigo ";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("desCodtab", desCodtab);
		query.setParameter("desCodigo", desCodigo);
		List lista = query.getResultList();
		if (lista.size() >0){
			return (GenDesctabla) lista.get(0);
		}
		return null;
		
	}

}
