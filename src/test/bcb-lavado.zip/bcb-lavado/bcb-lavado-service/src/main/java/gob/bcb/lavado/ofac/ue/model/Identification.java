//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.05.19 a las 01:08:51 AM BOT 
//


package gob.bcb.lavado.ofac.ue.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="remark" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}regulationSummary"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="diplomatic" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="knownExpired" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="knownFalse" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="reportedLost" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="revokedByIssuer" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="issuedBy" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="latinNumber" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="nameOnDocument" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="number" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="region" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="identificationTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="identificationTypeDescription" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="countryIso2Code" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="countryDescription" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="regulationLanguage" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="logicalId" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "remark",
    "regulationSummary"
})
@XmlRootElement(name = "identification")
public class Identification {

    protected String remark;
    @XmlElement(required = true)
    protected RegulationSummary regulationSummary;
    @XmlAttribute(name = "diplomatic")
    protected String diplomatic;
    @XmlAttribute(name = "knownExpired")
    protected String knownExpired;
    @XmlAttribute(name = "knownFalse")
    protected String knownFalse;
    @XmlAttribute(name = "reportedLost")
    protected String reportedLost;
    @XmlAttribute(name = "revokedByIssuer")
    protected String revokedByIssuer;
    @XmlAttribute(name = "issuedBy")
    protected String issuedBy;
    @XmlAttribute(name = "latinNumber")
    protected String latinNumber;
    @XmlAttribute(name = "nameOnDocument")
    protected String nameOnDocument;
    @XmlAttribute(name = "number")
    protected String number;
    @XmlAttribute(name = "region")
    protected String region;
    @XmlAttribute(name = "identificationTypeCode")
    protected String identificationTypeCode;
    @XmlAttribute(name = "identificationTypeDescription")
    protected String identificationTypeDescription;
    @XmlAttribute(name = "countryIso2Code")
    protected String countryIso2Code;
    @XmlAttribute(name = "countryDescription")
    protected String countryDescription;
    @XmlAttribute(name = "regulationLanguage")
    protected String regulationLanguage;
    @XmlAttribute(name = "logicalId")
    protected Integer logicalId;

    /**
     * Obtiene el valor de la propiedad remark.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemark() {
        return remark;
    }

    /**
     * Define el valor de la propiedad remark.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemark(String value) {
        this.remark = value;
    }

    /**
     * Obtiene el valor de la propiedad regulationSummary.
     * 
     * @return
     *     possible object is
     *     {@link RegulationSummary }
     *     
     */
    public RegulationSummary getRegulationSummary() {
        return regulationSummary;
    }

    /**
     * Define el valor de la propiedad regulationSummary.
     * 
     * @param value
     *     allowed object is
     *     {@link RegulationSummary }
     *     
     */
    public void setRegulationSummary(RegulationSummary value) {
        this.regulationSummary = value;
    }

    /**
     * Obtiene el valor de la propiedad diplomatic.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiplomatic() {
        return diplomatic;
    }

    /**
     * Define el valor de la propiedad diplomatic.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiplomatic(String value) {
        this.diplomatic = value;
    }

    /**
     * Obtiene el valor de la propiedad knownExpired.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKnownExpired() {
        return knownExpired;
    }

    /**
     * Define el valor de la propiedad knownExpired.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKnownExpired(String value) {
        this.knownExpired = value;
    }

    /**
     * Obtiene el valor de la propiedad knownFalse.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKnownFalse() {
        return knownFalse;
    }

    /**
     * Define el valor de la propiedad knownFalse.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKnownFalse(String value) {
        this.knownFalse = value;
    }

    /**
     * Obtiene el valor de la propiedad reportedLost.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReportedLost() {
        return reportedLost;
    }

    /**
     * Define el valor de la propiedad reportedLost.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReportedLost(String value) {
        this.reportedLost = value;
    }

    /**
     * Obtiene el valor de la propiedad revokedByIssuer.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevokedByIssuer() {
        return revokedByIssuer;
    }

    /**
     * Define el valor de la propiedad revokedByIssuer.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevokedByIssuer(String value) {
        this.revokedByIssuer = value;
    }

    /**
     * Obtiene el valor de la propiedad issuedBy.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuedBy() {
        return issuedBy;
    }

    /**
     * Define el valor de la propiedad issuedBy.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuedBy(String value) {
        this.issuedBy = value;
    }

    /**
     * Obtiene el valor de la propiedad latinNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLatinNumber() {
        return latinNumber;
    }

    /**
     * Define el valor de la propiedad latinNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLatinNumber(String value) {
        this.latinNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad nameOnDocument.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameOnDocument() {
        return nameOnDocument;
    }

    /**
     * Define el valor de la propiedad nameOnDocument.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameOnDocument(String value) {
        this.nameOnDocument = value;
    }

    /**
     * Obtiene el valor de la propiedad number.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumber() {
        return number;
    }

    /**
     * Define el valor de la propiedad number.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumber(String value) {
        this.number = value;
    }

    /**
     * Obtiene el valor de la propiedad region.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegion() {
        return region;
    }

    /**
     * Define el valor de la propiedad region.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegion(String value) {
        this.region = value;
    }

    /**
     * Obtiene el valor de la propiedad identificationTypeCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificationTypeCode() {
        return identificationTypeCode;
    }

    /**
     * Define el valor de la propiedad identificationTypeCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificationTypeCode(String value) {
        this.identificationTypeCode = value;
    }

    /**
     * Obtiene el valor de la propiedad identificationTypeDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificationTypeDescription() {
        return identificationTypeDescription;
    }

    /**
     * Define el valor de la propiedad identificationTypeDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificationTypeDescription(String value) {
        this.identificationTypeDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad countryIso2Code.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryIso2Code() {
        return countryIso2Code;
    }

    /**
     * Define el valor de la propiedad countryIso2Code.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryIso2Code(String value) {
        this.countryIso2Code = value;
    }

    /**
     * Obtiene el valor de la propiedad countryDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryDescription() {
        return countryDescription;
    }

    /**
     * Define el valor de la propiedad countryDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryDescription(String value) {
        this.countryDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad regulationLanguage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegulationLanguage() {
        return regulationLanguage;
    }

    /**
     * Define el valor de la propiedad regulationLanguage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegulationLanguage(String value) {
        this.regulationLanguage = value;
    }

    /**
     * Obtiene el valor de la propiedad logicalId.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLogicalId() {
        return logicalId;
    }

    /**
     * Define el valor de la propiedad logicalId.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLogicalId(Integer value) {
        this.logicalId = value;
    }

}
