package gob.bcb.lavado.model;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Index;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.Field.TermVector;
import org.apache.lucene.document.SortedDocValuesField;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.util.BytesRef;
import org.hibernate.search.bridge.LuceneOptions;
import org.hibernate.search.bridge.TwoWayFieldBridge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SwfBicsPKBridge implements TwoWayFieldBridge {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private static final String BICCODBIC = ".bicCodbic";
	private static final String BICCODBRANCH = ".bicCodbranch";

	@Override
	public Object get(String name, Document document) {
		SwfBicsPK id = new SwfBicsPK();
		IndexableField field = document.getField(name + BICCODBIC);
		id.setBicCodbic(field.stringValue());
		field = document.getField(name + BICCODBRANCH);
		id.setBicCodbranch(field.stringValue());
		return id;
	}

	@Override
	public String objectToString(Object o) {
		SwfBicsPK id = (SwfBicsPK) o;
		StringBuilder sb = new StringBuilder();
		sb.append(id.getBicCodbic()).append(" ").append(id.getBicCodbranch());
		return sb.toString();
	}
	
	@Override
	public void set(String name, Object value, Document document, LuceneOptions luceneOptions) {
		SwfBicsPK id = (SwfBicsPK) value;
		// store each property in a unique field
		luceneOptions.addFieldToDocument(name + BICCODBIC, id.getBicCodbic(), document);
		luceneOptions.addFieldToDocument(name + BICCODBRANCH, id.getBicCodbranch(), document);

		// store the unique string representation in the named field
		luceneOptions.addFieldToDocument(name, objectToString(id), document);

		// add doc value fields to allow for sorting
		document.add(new SortedDocValuesField(name + BICCODBIC, new BytesRef(id.getBicCodbic())));
		document.add(new SortedDocValuesField(name + BICCODBRANCH, new BytesRef(id.getBicCodbranch())));
		document.add(new SortedDocValuesField(name, new BytesRef(objectToString(id))));		
		//document.add(new SortedDocValuesField(name, new BytesRef(name) ));
	}
	
}
