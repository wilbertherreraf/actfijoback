//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.05.17 a las 11:37:50 AM BOT 
//


package gob.bcb.lavado.ofac.ue.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}publicationUrl"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="regulationType" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="organisationType" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="publicationDate" type="{http://www.w3.org/2001/XMLSchema}date" /&gt;
 *       &lt;attribute name="entryIntoForceDate" type="{http://www.w3.org/2001/XMLSchema}date" /&gt;
 *       &lt;attribute name="numberTitle" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="programme" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="logicalId" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "publicationUrl"
})
@XmlRootElement(name = "regulation")
public class Regulation {

    @XmlElement(required = true)
    @XmlSchemaType(name = "anyURI")
    protected String publicationUrl;
    @XmlAttribute(name = "regulationType")
    protected String regulationType;
    @XmlAttribute(name = "organisationType")
    protected String organisationType;
    @XmlAttribute(name = "publicationDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar publicationDate;
    @XmlAttribute(name = "entryIntoForceDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar entryIntoForceDate;
    @XmlAttribute(name = "numberTitle")
    protected String numberTitle;
    @XmlAttribute(name = "programme")
    protected String programme;
    @XmlAttribute(name = "logicalId")
    protected Integer logicalId;

    /**
     * Obtiene el valor de la propiedad publicationUrl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicationUrl() {
        return publicationUrl;
    }

    /**
     * Define el valor de la propiedad publicationUrl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicationUrl(String value) {
        this.publicationUrl = value;
    }

    /**
     * Obtiene el valor de la propiedad regulationType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegulationType() {
        return regulationType;
    }

    /**
     * Define el valor de la propiedad regulationType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegulationType(String value) {
        this.regulationType = value;
    }

    /**
     * Obtiene el valor de la propiedad organisationType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganisationType() {
        return organisationType;
    }

    /**
     * Define el valor de la propiedad organisationType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganisationType(String value) {
        this.organisationType = value;
    }

    /**
     * Obtiene el valor de la propiedad publicationDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPublicationDate() {
        return publicationDate;
    }

    /**
     * Define el valor de la propiedad publicationDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPublicationDate(XMLGregorianCalendar value) {
        this.publicationDate = value;
    }

    /**
     * Obtiene el valor de la propiedad entryIntoForceDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEntryIntoForceDate() {
        return entryIntoForceDate;
    }

    /**
     * Define el valor de la propiedad entryIntoForceDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEntryIntoForceDate(XMLGregorianCalendar value) {
        this.entryIntoForceDate = value;
    }

    /**
     * Obtiene el valor de la propiedad numberTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumberTitle() {
        return numberTitle;
    }

    /**
     * Define el valor de la propiedad numberTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumberTitle(String value) {
        this.numberTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad programme.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramme() {
        return programme;
    }

    /**
     * Define el valor de la propiedad programme.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramme(String value) {
        this.programme = value;
    }

    /**
     * Obtiene el valor de la propiedad logicalId.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLogicalId() {
        return logicalId;
    }

    /**
     * Define el valor de la propiedad logicalId.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLogicalId(Integer value) {
        this.logicalId = value;
    }

}
