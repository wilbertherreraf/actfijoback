//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.05.17 a las 11:37:50 AM BOT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://eu.europa.ec/fpi/fsd/export", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package gob.bcb.lavado.ofac.ue.model;
