package gob.bcb.lavado.search.presearcher;

import gob.bcb.lavado.search.QueryMatch;

public class PresearcherMatch<T extends QueryMatch> {

    public final String presearcherMatches;

    public final T queryMatch;

    public final String queryId;

    public PresearcherMatch(String id, String presearcherMatches, T queryMatch) {
        this.presearcherMatches = presearcherMatches;
        this.queryMatch = queryMatch;
        this.queryId = id;
    }
}
