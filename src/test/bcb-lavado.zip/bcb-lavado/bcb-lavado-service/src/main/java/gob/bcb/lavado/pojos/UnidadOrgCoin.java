package gob.bcb.lavado.pojos;

import java.io.Serializable;

public class UnidadOrgCoin implements Serializable{
	private String codUnidadOrg;
	private String descUnidadOrg;
	private boolean seleccionado;
	public UnidadOrgCoin(){
		
	}
	public String getCodUnidadOrg() {
		return codUnidadOrg;
	}
	public void setCodUnidadOrg(String codUnidadOrg) {
		this.codUnidadOrg = codUnidadOrg;
	}
	public String getDescUnidadOrg() {
		return descUnidadOrg;
	}
	public void setDescUnidadOrg(String descUnidadOrg) {
		this.descUnidadOrg = descUnidadOrg;
	}
	public boolean isSeleccionado() {
		return seleccionado;
	}
	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}                                                           
	
}
