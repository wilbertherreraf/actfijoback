/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.lavado.pojos;

import java.io.Serializable;

import java.util.Date;

public class Participante implements Serializable {
    private static final long serialVersionUID = 1L;
    private String codPte;
    private String nit;   
    private String nombre;
    private String nombreCorto;
    private String cveTipoPte;
    private Integer codAgencia;
    private String nomAgencia;
    private Integer codPlaza;
    private String nomPlaza;
    private String nomDepto;
    private Date fechaHora;
    private String codUsuario;
    private String estacion;
    public Participante() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombreCorto() {
        return nombreCorto;
    }

    public void setNombreCorto(String nombreCorto) {
        this.nombreCorto = nombreCorto;
    }

    public String getCveTipoPte() {
        return cveTipoPte;
    }

    public void setCveTipoPte(String cveTipoPte) {
        this.cveTipoPte = cveTipoPte;
    }

    public Integer getCodAgencia() {
        return codAgencia;
    }

    public void setCodAgencia(Integer codAgencia) {
        this.codAgencia = codAgencia;
    }

    public String getNomAgencia() {
        return nomAgencia;
    }

    public void setNomAgencia(String nomAgencia) {
        this.nomAgencia = nomAgencia;
    }

    public Integer getCodPlaza() {
        return codPlaza;
    }

    public void setCodPlaza(Integer codPlaza) {
        this.codPlaza = codPlaza;
    }

    public String getNomPlaza() {
        return nomPlaza;
    }

    public void setNomPlaza(String nomPlaza) {
        this.nomPlaza = nomPlaza;
    }

    public String getNomDepto() {
        return nomDepto;
    }

    public void setNomDepto(String nomDepto) {
        this.nomDepto = nomDepto;
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Date fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getEstacion() {
        return estacion;
    }

    public void setEstacion(String estacion) {
        this.estacion = estacion;
    }

    public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (codPte != null ? codPte.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Participante)) {
            return false;
        }
        Participante other = (Participante) object;
        if ((this.codPte == null && other.codPte != null) || (this.codPte != null && !this.codPte.equals(other.codPte))) {
            return false;
        }
        return true;
    }

	public String getCodPte() {
		return codPte;
	}

	public void setCodPte(String codPte) {
		this.codPte = codPte;
	}

}
