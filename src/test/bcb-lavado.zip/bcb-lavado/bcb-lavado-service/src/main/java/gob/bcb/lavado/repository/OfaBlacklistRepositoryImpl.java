package gob.bcb.lavado.repository;

import java.util.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.model.OfaBlacklist;
import gob.bcb.lavado.services.SwiftAdminDaoServiceImpl;

public class OfaBlacklistRepositoryImpl {
	private static final Logger log = LoggerFactory.getLogger(OfaBlacklistRepositoryImpl.class);
	@Autowired
	private OfaBlacklistRepository ofaBlacklistRepository;
	
	public OfaBlacklist actualizarOfaBlacklist(OfaBlacklist ofaBlacklist){
		if (ofaBlacklist.getBlkId() == null){
			Optional<OfaBlacklist> ofaBlacklistMax = ofaBlacklistRepository.findOneMaximo();
			if (ofaBlacklistMax.isPresent()){
				ofaBlacklist.setBlkId(ofaBlacklistMax.get().getBlkId() + 1);
			} else {
				ofaBlacklist.setBlkId(1);
			}
		}
		
		ofaBlacklist.setBlkAuditfho(new Date());
		ofaBlacklistRepository.saveAndFlush(ofaBlacklist);
		log.info("actualizarOfaBlacklist " + ofaBlacklist.getBlkId());
		return ofaBlacklistRepository.findOne(ofaBlacklist.getBlkId());
	}
	
}
