package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the swf_params database table.
 * 
 */
@Entity
@Table(name="swf_params")
public class SwfParams implements Serializable, DomainObject {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="par_codpar")
	private String parCodpar;

	@Column(name="par_descrip")
	private String parDescrip;

	@Column(name="par_valor")
	private String parValor;

	public SwfParams() {
	}

	public String getParCodpar() {
		return this.parCodpar;
	}

	public void setParCodpar(String parCodpar) {
		this.parCodpar = parCodpar;
	}

	public String getParDescrip() {
		return this.parDescrip;
	}

	public void setParDescrip(String parDescrip) {
		this.parDescrip = parDescrip;
	}

	public String getParValor() {
		return this.parValor;
	}

	public void setParValor(String parValor) {
		this.parValor = parValor;
	}

	@Override
	public String toString() {
		return "SwfParams [parCodpar=" + parCodpar + ", parDescrip=" + parDescrip + ", parValor=" + parValor + "]";
	}

}