package gob.bcb.lavado.rest;

import java.net.URISyntaxException;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.lavado.rest.util.HeaderUtil;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;

//@Component
@RestController
@RequestMapping(Constants.PATH_RESOURCE_API_PARAM)
//@Api(tags = { "Parametros" })
public class ParamsResource {
	private final Logger log = LoggerFactory.getLogger(ParamsResource.class);

	@Autowired
	private SwfParamsDao swfParamsDao;

	/**
	 * GET /params : get all the swfparams.
	 *
	 * @return the ResponseEntity with status 200 (OK) and the list of params in
	 *         body
	 */
	@RequestMapping(value = "/params", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Retorna todos los registros de parametros", response=SwfParams.class)	
	// @Timed
	public ResponseEntity<List<SwfParams>> getAllswfParamss() {
		log.debug("REST request to get all SwfParams");
		List<SwfParams> result = swfParamsDao.getAll();
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	/**
	 * PUT /{id} : Updates an existing swfParams.
	 *
	 * @param swfParams
	 *            the swfParams to update
	 * @return the ResponseEntity with status 200 (OK) and with body the updated
	 *         swfParams, or with status 400 (Bad Request) if the swfParams is
	 *         not valid, or with status 500 (Internal Server Error) if the
	 *         swfParams couldnt be updated
	 * @throws URISyntaxException
	 *             if the Location URI syntax is incorrect
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Actualiza un registro de parametros", response=SwfParams.class)	
	// @Timed
	public ResponseEntity<SwfParams> updateswfParams(@PathVariable String id, @Valid @RequestBody SwfParams swfParams) throws URISyntaxException {
		log.info("REST request to update swfParams : {}", swfParams);
		if (swfParams.getParCodpar() == null) {
			return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("swfParams", "idexists", "No se puede modificar con id nulo"))
					.body(null);
		}
		SwfParams result = swfParamsDao.saveOrUpdate(swfParams);
		return ResponseEntity.ok().headers(HeaderUtil.createEntityUpdateAlert("swfParams", swfParams.getParCodpar())).body(result);
	}
}
