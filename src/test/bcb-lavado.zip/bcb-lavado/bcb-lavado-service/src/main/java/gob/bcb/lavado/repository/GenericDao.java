package gob.bcb.lavado.repository;

import java.util.List;

import gob.bcb.lavado.model.DomainObject;
import gob.bcb.lavado.pojos.GenUsuario;

public interface GenericDao<T extends DomainObject> {

    public T get(Long id);

    public List<T> getAll();

    public void save(T object);
    public T update(T object);    

    public void delete(T object);

	void setGenUsuario(GenUsuario genUsuario);
}
