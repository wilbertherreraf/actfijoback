package gob.bcb.lavado.strategy;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.lucene.queryparser.classic.QueryParser.Operator;
import org.apache.lucene.search.BooleanClause;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.search.AnalizersHolder;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.OfacIndexer;
import gob.bcb.lavado.search.analysis.EntityAnalyzer;

public class StrategyBase {
	private static final Logger log = LoggerFactory.getLogger(StrategyBase.class);

	public static final String arch_estrategias = "estrategias.json";
	public static final String arch_estrategias_query = "estrategias_query.json";
	public static final String arch_stopwords = "stop_words.txt";
	public static final String ID_SWIFT_EVERY = "NNA";
	private static final int maximumCacheSize = 150;
	private static final int cacheTtlMillis = 60;
	private final Map<String, QueryTemplate> queryTemplateMap = new HashMap<>();
	private final Map<String, QueryStrategyHolder> queryStrategyMap = new HashMap<>();
	//private Map<String, List<String>> groupsFldStr;
	private String pathDirFilesJson;
	private long lastReloadTime;
	private final LoadingCache<String, Map<String, Map<String, List<FieldQuery>>>> strategiesCache;

	private static class StrategyHolder {
		public static final StrategyBase instance = new StrategyBase();
	}

	private StrategyBase() {
		CacheBuilder<Object, Object> cacheBuilder = CacheBuilder.newBuilder();
		if (maximumCacheSize >= 0) {
			cacheBuilder.maximumSize(maximumCacheSize);
		}
		cacheBuilder.refreshAfterWrite(cacheTtlMillis, TimeUnit.MINUTES);
		
		this.strategiesCache = cacheBuilder.build(new CacheLoader<String, Map<String, Map<String, List<FieldQuery>>>>() {
			@Override
			public Map<String, Map<String, List<FieldQuery>>> load(String key) throws Exception {
//				log.info("	en cache " + key + " " + strategiesCache.size());
				return matchesForFieldswiftCh(key);
			}
		});
		
	}

	public static StrategyBase getInstance() {
		return StrategyHolder.instance;
	}

	public StrategyBase initialize(String pathDirFiles) throws Exception {
		init(pathDirFiles);
		if (queryTemplateMap.size() == 0)
			loadQueries();
		//groupsFldStr = groupsForIdEstrategia();

		return this;
	}

	private void init(String pathDirFiles) {
		if (queryTemplateMap.size() > 0) {
			return;
		}
		log.info("init StrategyBase pathDirFiles: " + pathDirFiles);
		File f = new File(pathDirFiles);
		if (f.exists() && f.isDirectory()) {
			this.pathDirFilesJson = StringUtils.cleanPath(f.getAbsolutePath());
		} else {
			throw new RuntimeException("Directorio inexistente " + pathDirFiles);
		}

		File fileEstra = new File(pathDirFilesJson, arch_estrategias);
		File fileEstraQ = new File(pathDirFilesJson, arch_estrategias_query);
		File filestopwords = new File(pathDirFilesJson, arch_stopwords);

		if (!fileEstra.exists() || !fileEstraQ.exists() || fileEstra.isDirectory() || fileEstraQ.isDirectory()) {
			throw new RuntimeException("Archivo de Estrategias [" + arch_estrategias + "," + arch_estrategias_query + "] inexistentes en: " + pathDirFiles);
		}

		if (!filestopwords.exists()) {
			UtilsFile.grabaEnArchivo("", filestopwords.getAbsolutePath());
			log.warn("New file of stop words create in : " + filestopwords.getAbsolutePath());
		}
		lastReloadTime = (fileEstra.lastModified() > fileEstraQ.lastModified() ? fileEstra.lastModified() : fileEstraQ.lastModified());

		log.warn("New Instance StrategyBase to: " + this.pathDirFilesJson + " at " + lastReloadTime);
	}

	public Map<String, Map<String, List<FieldQuery>>> matchesForFieldswiftCh(String fieldsswf) {
//		log.info("####################### Query " + fieldsswf);
		Map<String, Map<String, List<FieldQuery>>> fieldQueryMapList = new LinkedHashMap<>();

		Map<String, List<String>> groupsFldStr = groupsForIdEstrategia();
		for (String fld : groupsFldStr.keySet()) {
//		groupsFldStr.keySet().stream().filter(k -> k.length() >= fieldsswf.length()).forEach(fld -> {	
			Pattern pattern = Pattern.compile(fld);
			if (fieldsswf.startsWith(fld) || pattern.matcher(fieldsswf).matches()) {
				for (String key : groupsFldStr.get(fld)) {
					fieldQueryMapList.put(key, queryStrategyMap.get(key).fieldQueryMap);
				}
				break;
			}
//			if (fieldsswf.startsWith(fld) || fld.equals(ID_SWIFT_EVERY)) {
//				for (String key : groupsFldStr.get(fld)) {
//					fieldQueryMapList.put(key, queryStrategyMap.get(key).fieldQueryMap);
//				}
//				break;
			// }
		}
		;

//		for (Entry<String, QueryStrategyHolder> queryStrategyEntry : queryStrategyMap.entrySet()) {
//			QueryStrategyHolder queryStrategyHolder = queryStrategyEntry.getValue();
//			
//			Optional<String> fieldSwf = Arrays.asList(queryStrategyHolder.fieldsswf).stream()
//					.filter(s -> (fieldsswf.startsWith(s) || s.equals(ID_SWIFT_EVERY))).findAny();
//			
//			log.info("####################### Query " + fieldsswf + " => " + queryStrategyEntry.getKey() + " PRESENT? " + fieldSwf.isPresent());
//			
//			if (fieldSwf.isPresent()) {
//				fieldQueryMapList.put(queryStrategyEntry.getKey(), queryStrategyHolder.fieldQueryMap);
//			}
//		}
		return fieldQueryMapList;
	}
	
	public Map<String, Map<String, List<FieldQuery>>> matchesForFieldswift(String fieldsswf) throws ExecutionException {
		return strategiesCache.get(fieldsswf);
	}
	
	public Map<String, List<FieldQuery>> matchesForIdEstrategia(String fieldsswf) {
		Map<String, List<FieldQuery>> fieldQueryMapList = new LinkedHashMap<>();
		fieldsswf = fieldsswf.toUpperCase();
		if (queryStrategyMap.containsKey(fieldsswf)) {
			fieldQueryMapList = queryStrategyMap.get(fieldsswf).fieldQueryMap;
		}
		return fieldQueryMapList;
	}

	public Map<String, List<String>> groupsForIdEstrategia() {
		Map<String, List<String>> fieldQueryMapList = new HashMap<>();
		for (Entry<String, QueryStrategyHolder> queryStrategyEntry : queryStrategyMap.entrySet()) {
			QueryStrategyHolder queryStrategyHolder = queryStrategyEntry.getValue();

			Arrays.asList(queryStrategyHolder.fieldsswf).forEach(s -> {
				if (!fieldQueryMapList.containsKey(s)) {
					fieldQueryMapList.put(s, new ArrayList<String>());
				}
				fieldQueryMapList.get(s).add(queryStrategyEntry.getKey());
			});
		}
		return fieldQueryMapList;
	}

	private void loadQueries() throws Exception {
		log.info("Cargando estrategias ...");
		File filestopwords = new File(pathDirFilesJson, arch_stopwords);

		EntityAnalyzer entityAnalyzer = (EntityAnalyzer) AnalizersHolder.getEntityAnalyzer(filestopwords.getAbsolutePath());
		AnalizersHolder.mapAnalizers.put(AnalizersHolder.ANALYZER_NAMES, entityAnalyzer);

		File fileEstra = new File(pathDirFilesJson, arch_estrategias);
		File fileEstraQ = new File(pathDirFilesJson, arch_estrategias_query);

		loadEstrategias(fileEstra.getAbsolutePath());
		loadEstrategiasQuery(fileEstraQ.getAbsolutePath());

		log.info("Cargando estrategias ... hecho filestopwords: " + filestopwords.getAbsolutePath());
	}

	public void loadEstrategias(String pathEstrategias) throws Exception {
		String menPlano = UtilsFile.readFileAsString2(pathEstrategias);
		log.debug("Estrategias: " + menPlano);
		ObjectMapper mapper = new ObjectMapper();

		QueryTemplate[] queryTemplateLista = mapper.readValue(menPlano, QueryTemplate[].class);

		for (QueryTemplate queryTemplate : queryTemplateLista) {
			queryTemplateMap.put(queryTemplate.getId(), queryTemplate);
		}
	}

	public void loadEstrategiasQuery(String pathEstrategiasQ) throws Exception {
		String menPlano2 = UtilsFile.readFileAsString2(pathEstrategiasQ);
		log.debug("Estrategias query: " + menPlano2);

		ObjectMapper mapper = new ObjectMapper();
		QueryStrategy[] queryStrategyLista = mapper.readValue(menPlano2, QueryStrategy[].class);

		for (QueryStrategy queryStrategy : queryStrategyLista) {
			log.info("::: queryStrategy " + queryStrategy.getId());
			QueryStrategyHolder queryStrategyHolder = new QueryStrategyHolder();
			queryStrategyHolder.id = queryStrategy.getId();

			BooleanClause.Occur[] booleanClause = new BooleanClause.Occur[queryStrategy.getIdqueries().length];
			int posi = 0;
			for (String idqueri : queryStrategy.getIdqueries()) {
				QueryTemplate queryTemplate = queryTemplateMap.get(idqueri);
				if (queryTemplate == null) {
					throw new RuntimeException("Error en configuracion estrategias idqueri: " + idqueri + " inexistente en parametrizacion estrategias");
				}
				queryStrategyHolder.queryTemplateMap.put(idqueri, queryTemplate);
				queryStrategyHolder.fieldsswf = queryStrategy.getFieldsswf();

				String junct = queryStrategy.getJunction()[posi];
				String junctionStr = ((junct == null) ? "SHOULD" : junct.trim().toUpperCase());
				booleanClause[posi] = ((junctionStr.equals("MUST") ? BooleanClause.Occur.MUST
						: (junctionStr.equals("NOT MUST") ? BooleanClause.Occur.MUST_NOT : BooleanClause.Occur.SHOULD)));

				log.info("insertando idqueri " + idqueri);
				// verificamos que el valor del campo idqueries este
				// presente en las estrategias
				List<FieldQuery> fieldQueryLista = createFieldsQuery(queryStrategy, idqueri, booleanClause[posi]);
				queryStrategyHolder.fieldQueryMap.put(idqueri, fieldQueryLista);

				posi++;
			}
			queryStrategyHolder.booleanClauseOccur = booleanClause;

			queryStrategyMap.put(queryStrategy.getId(), queryStrategyHolder);
		}

	}

	public List<FieldQuery> createFieldsQuery(QueryStrategy queryStrategy, String idqueri, BooleanClause.Occur occur) {
		QueryTemplate queryTemplate = queryTemplateMap.get(idqueri);
		if (queryTemplate == null) {
			throw new RuntimeException("Error en configuracion estrategias idqueri: " + idqueri + " inexistente en parametrizacion estrategias");
		}

		List<FieldQuery> fieldQueryLista = new LinkedList<>();
		for (String fieldSwiftTable : queryTemplate.getFields()) {
			FieldQuery fieldQuery = createFieldQuery(queryStrategy, queryTemplate, fieldSwiftTable, occur);
			fieldQueryLista.add(fieldQuery);
		}
		return fieldQueryLista;
	}

	public FieldQuery createFieldQuery(QueryStrategy queryStrategy, QueryTemplate queryTemplate, String fieldSwiftTable, BooleanClause.Occur occur) {
		ValidatorStrategy validatorStrategy = new ValidatorStrategy(queryTemplate.getValidator().getExpectedFields(),
				queryTemplate.getValidator().isValidateTerms(), 0.2F);

		validatorStrategy.setType(ValidatorStrategy.ValidatorType.valueOf(queryTemplate.getValidator().getType().toUpperCase()));

		String clazzName = fieldSwiftTable.indexOf(".") == -1 ? queryTemplate.getClazz() : fieldSwiftTable.split("\\.")[0];

		Class<?> cl = OfacIndexer.MAP_CLAZZ_ENTITIES.get(clazzName.toUpperCase()) == null
				? OfacIndexer.MAP_CLAZZ_ENTITIES.get(queryTemplate.getClazz().toUpperCase())
				: OfacIndexer.MAP_CLAZZ_ENTITIES.get(clazzName.toUpperCase());
		log.info("queryTemplate.getAnalyzer() " + queryTemplate.getAnalyzer() + " " + queryTemplate.getTypeQ() + " " + fieldSwiftTable + " => " + clazzName);
		FieldQuery fieldQuery = FieldQuery.builder(queryTemplate.getId()).addField(fieldSwiftTable, AnalizersHolder.getAnalyzer(queryTemplate.getAnalyzer()))
				.addFuzzy(queryTemplate.getDistanceUpTo(), queryTemplate.getPrefixLength()).addSpanPhrase(queryTemplate.getSlop(), queryTemplate.isInOrder())
				.addClazz(cl)//
				.addQueryTemplate(queryTemplate.getQueryTemplate()).build();

		fieldQuery.setValidatorStrategy(validatorStrategy);
		fieldQuery.setIdStrategy(queryStrategy.getId());
		fieldQuery.setMinWordLen(queryTemplate.getMinWordLen());
		fieldQuery.setExceptNumbers(queryTemplate.isExceptNumbers());
		fieldQuery.setTypeQ(queryTemplate.getTypeQ());
		String op = (queryTemplate.getAndOr() == null ? "OR" : queryTemplate.getAndOr().trim().toUpperCase());
		fieldQuery.setOperator((op.equals("AND") ? Operator.AND : Operator.OR));
		fieldQuery.setJunction(occur);

		return fieldQuery;
	}

	public boolean isModified(String path) {
		try {
			File f = new File(path, arch_estrategias);
			File f1 = new File(path, arch_estrategias_query);

			boolean changed = (f.lastModified() > lastReloadTime) || (f1.lastModified() > lastReloadTime)
					|| !(StringUtils.cleanPath(f.getParent()).equals(pathDirFilesJson));

			return changed;
		} catch (Exception ex) {
			log.warn("Could not check resource date", ex);
			return true;
		}
	}

	public List<String> getListStrategies() {
		return queryStrategyMap.keySet().stream().collect(Collectors.toList());
	}

	private static class QueryStrategyHolder {
		String id;
		Map<String, QueryTemplate> queryTemplateMap = new LinkedHashMap<>();
		String[] fieldsswf;
		BooleanClause.Occur[] booleanClauseOccur;
		Map<String, List<FieldQuery>> fieldQueryMap = new LinkedHashMap<>();
	}

	public static void main(String[] args) {
		String[] words = { "20" };
		StringBuilder regexp = new StringBuilder();
		for (String word : words) {
			regexp.append("(?=.*").append(word).append(")");
		}
		Pattern pat = Pattern.compile(regexp.toString());
		// pat.matcher("20").find();

		System.out.println("matches " + regexp.toString() + " " + pat.matcher("20a").find());

		String fld = "(asd/wer).*";
		String stringToSearch = "asd/wer/asdf";
		Pattern pattern = Pattern.compile(fld);
		Matcher m1 = pattern.matcher(stringToSearch);
		System.out.println("matches " + m1.matches());
	}
}
