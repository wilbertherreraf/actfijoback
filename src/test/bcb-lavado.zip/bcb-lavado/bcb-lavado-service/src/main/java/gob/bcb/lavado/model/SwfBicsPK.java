package gob.bcb.lavado.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
//import javax.persistence.Index;

import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Store;

/**
 * The primary key class for the swf_bics database table.
 * 
 */
@Embeddable
public class SwfBicsPK implements Serializable {  
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Field(store=Store.YES)
	@Column(name="bic_codbic")
	private String bicCodbic;

	@Field(store=Store.YES)
	@Column(name="bic_codbranch")
	private String bicCodbranch;

	public SwfBicsPK() {
	}
	public String getBicCodbic() {
		return this.bicCodbic;
	}
	public void setBicCodbic(String bicCodbic) {
		this.bicCodbic = bicCodbic;
	}
	public String getBicCodbranch() {
		return this.bicCodbranch;
	}
	public void setBicCodbranch(String bicCodbranch) {
		this.bicCodbranch = bicCodbranch;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SwfBicsPK)) {
			return false;
		}
		SwfBicsPK castOther = (SwfBicsPK)other;
		return 
			this.bicCodbic.equals(castOther.bicCodbic)
			&& this.bicCodbranch.equals(castOther.bicCodbranch);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.bicCodbic.hashCode();
		hash = hash * prime + this.bicCodbranch.hashCode();
		
		return hash;
	}
	@Override
	public String toString() {
		return bicCodbic + " " + bicCodbranch;
	}
	
}