package gob.bcb.lavado.strategy;

public class ValidatorStrategy {
	private final int expectedFields;
	private final boolean validateTerms;
	private float peso = 1.0f;
	private int expectedMatches = 0;
	private ValidatorType type;
	// private final Set<T> expectedMatches;

	public ValidatorStrategy(int expectedFields, boolean validateTerms) {
		this.expectedFields = expectedFields;
		this.validateTerms = validateTerms;
		// this.expectedMatches = expectedMatches;
	}
	public ValidatorStrategy(int expectedFields, boolean validateTerms, float peso ) {
		this(expectedFields, validateTerms);
		this.peso = peso;
	}
	public ValidatorStrategy(int expectedFields, boolean validateTerms, float peso, int expectedMatches ) {
		this(expectedFields, validateTerms,peso);
		this.expectedMatches = expectedMatches;
	}	
	public int getExpectedFields() {
		return expectedFields;
	}

	public boolean isValidateTerms() {
		return validateTerms;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}
	public int getExpectedMatches() {
		return expectedMatches;
	}
	public void setExpectedMatches(int expectedMatches) {
		this.expectedMatches = expectedMatches;
	}

	public ValidatorType getType() {
		return type;
	}
	public void setType(ValidatorType type) {
		this.type = type;
	}

	public enum ValidatorType {
	    SIMPLE("simple"), MEDIUM("medium"), EXACT("exact");

	    private String type;

	    ValidatorType(String type) {
	        this.type = type;
	    }
	    
		public void setType(String type) {
			this.type = type;
		}
		public String getType() {
			return this.type;
		}		
	    public String toString() {
	        return this.type;
	    }
	}	
}