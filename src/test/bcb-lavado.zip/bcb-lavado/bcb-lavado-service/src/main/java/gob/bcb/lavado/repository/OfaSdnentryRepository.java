package gob.bcb.lavado.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaSdnentry;

@Repository
public interface OfaSdnentryRepository extends JpaRepository<OfaSdnentry,Integer> {
	@Query("select ofaSdnentry from OfaSdnentry ofaSdnentry where ofaSdnentry.sdnSdntype = :sdnSdntype and trim(ofaSdnentry.sdnLastname) like '% %'")
	Set<OfaSdnentry> findOfaSdnentryWithMoreOneName(@Param("sdnSdntype") String sdnSdntype);
	List<OfaSdnentry> findBySdnNrolote(@Param("sdnNrolote") Integer sdnNrolote);
	@Query("select ofaSdnentry from OfaSdnentry ofaSdnentry where ofaSdnentry.sdnEntryuid = :sdnEntryuid and ofaSdnentry.sdnIdlista = :sdnIdList ")
	List<OfaSdnentry> findBySdnEntryuidAndSdnIdlista(@Param("sdnEntryuid") Integer sdnEntryuid, @Param("sdnIdList") String sdnIdList);
}
