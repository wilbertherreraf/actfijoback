package gob.bcb.swift.pojos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfTipomensaje;
import gob.bcb.swift.SwiftMessageBcb;

public class SwiftDatos {
	private SwfMensaje swfMensaje;
	private SwfBics swfBicsSender;
	private SwfBics swfBicsReceiver;
	private SwfTipomensaje swfTipomensaje;
	private SwiftMessageBcb swiftMessageBcb;
	private SwiftMessageAbstract swiftMessageAbs; 
	private String auditwst;
	private String auditusr;
	private Map<String, Object> parametro = new HashMap<String, Object>();

	public void setParametro(String key, Object valor) {
		if (this.parametro == null) {
			parametro = new HashMap<String, Object>();
		}
		if (valor == null) {
			if (parametro.containsKey(key))
				parametro.remove(key);
		} else {
			if (key != null) {
				parametro.put(key, valor);
			}
		}
	}

	public Object getParametro(String key) {
		return parametro.get(key);
	}

	public void removeParametro(String key) {
		try {
			parametro.remove(key);
		} catch (Exception e) {
		}
	}

	public void limpiarParametros() {
		parametro.clear();
	}

	public void setParametro(Map<String, Object> parametro) {
		this.parametro = parametro;
	}

	public Map<String, Object> getParametro() {
		return parametro;
	}

	public SwfMensaje getSwfMensaje() {
		return swfMensaje;
	}

	public void setSwfMensaje(SwfMensaje swfMensaje) {
		this.swfMensaje = swfMensaje;
	}

	public String getAuditwst() {
		return auditwst;
	}

	public void setAuditwst(String auditwst) {
		this.auditwst = auditwst;
	}

	public String getAuditusr() {
		return auditusr;
	}

	public void setAuditusr(String auditusr) {
		this.auditusr = auditusr;
	}

	public SwfBics getSwfBicsSender() {
		return swfBicsSender;
	}

	public void setSwfBicsSender(SwfBics swfBicsSender) {
		this.swfBicsSender = swfBicsSender;
	}

	public SwfBics getSwfBicsReceiver() {
		return swfBicsReceiver;
	}

	public void setSwfBicsReceiver(SwfBics swfBicsReceiver) {
		this.swfBicsReceiver = swfBicsReceiver;
	}

	public SwfBics newSwfBicsSender(String bicCodbic, String bicCodbranch, String bicDescrip, String bicDirecc1, String bicCiudad, String bicPais) {
		swfBicsSender = new SwfBics(bicCodbic, bicCodbranch, bicDescrip, bicDirecc1, bicCiudad, bicPais);
		return swfBicsSender;
	}

	public SwfBics newSwfBicsReceiver(String bicCodbic, String bicCodbranch, String bicDescrip, String bicDirecc1, String bicCiudad, String bicPais) {
		swfBicsReceiver = new SwfBics(bicCodbic, bicCodbranch, bicDescrip, bicDirecc1, bicCiudad, bicPais);
		return swfBicsReceiver;
	}

	public SwfTipomensaje getSwfTipomensaje() {
		return swfTipomensaje;
	}

	public void setSwfTipomensaje(SwfTipomensaje swfTipomensaje) {
		this.swfTipomensaje = swfTipomensaje;
	}

	public SwiftMessageBcb getSwiftMessageBcb() {
		return swiftMessageBcb;
	}

	public void setSwiftMessageBcb(SwiftMessageBcb swiftMessageBcb) {
		this.swiftMessageBcb = swiftMessageBcb;
	}

	public SwiftMessageAbstract getSwiftMessageAbs() {
		return swiftMessageAbs;
	}

	public void setSwiftMessageAbs(SwiftMessageAbstract swiftMessageAbs) {
		this.swiftMessageAbs = swiftMessageAbs;
	}

	public static List<Block4> block4ToBlock4Ldv(List<gob.bcb.iso20022.pojo.Block4> block4List) {
		return block4List.stream().map(block4ToBlock4Ldv()).collect(Collectors.toList());
	}

	public static Function<gob.bcb.iso20022.pojo.Block4, Block4> block4ToBlock4Ldv() {
		return block4 -> {
			Block4 block4lvd = new Block4();
			block4lvd.setName(block4.getName());
			block4lvd.setReference(block4.getReference());
			block4lvd.setValue(block4.getValue());
			block4lvd.setValueDescrip(block4.getValueDescrip());

			return block4lvd;
		};
	}
}
