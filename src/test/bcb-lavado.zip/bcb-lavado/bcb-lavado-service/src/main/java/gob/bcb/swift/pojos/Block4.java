package gob.bcb.swift.pojos;

import java.io.Serializable;

public class Block4 implements Serializable {
	private String name;
	private String reference;
	private String value;
	private String valueDescrip;	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValueDescrip() {
		return valueDescrip;
	}

	public void setValueDescrip(String valueDescrip) {
		this.valueDescrip = valueDescrip;
	}

}
