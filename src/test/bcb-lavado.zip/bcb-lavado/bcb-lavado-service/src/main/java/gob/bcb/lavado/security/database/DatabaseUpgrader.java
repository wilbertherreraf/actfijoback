package gob.bcb.lavado.security.database;

/**
 * Service interface for a Database migrator or upgrader.
 */
public interface DatabaseUpgrader {

	/**
	 * The current version of the Database.
	 * Returns {@link DatabaseVersion#zero()} if no database has been installed.
	 */
	public DatabaseVersion getCurrentDatabaseVersion();
	

}
