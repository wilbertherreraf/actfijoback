package gob.bcb.lavado.services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.mx.AbstractMX;

import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.iso20022.lau.AuthParameters;
import gob.bcb.iso20022.lau.LAU;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.saa.DataPDUWriter;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.swift.saa.model.Message;
import gob.bcb.lavado.client.HandlerGeneratorLauSrv;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfBicsDao;
import gob.bcb.swift.ParserSwiftMessage;
import gob.bcb.swift.SwiftMessageBcb;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

/**
 * Componente de desparseo de mensajes swift
 * 
 * @author wherrera
 *
 */

@Component("swiftBcbParserService")
public class SwiftBcbParserServiceImpl implements SwiftBcbParserService {
	private static final Logger log = LoggerFactory.getLogger(SwiftBcbParserServiceImpl.class);
	public static final String SWIFT_EOL = "\r\n";

	@Autowired
	private SwfBicsDao swfBicsDao;
	@Autowired
	private CryptoSwiftService cryptoSwiftService;

	static final Locale locale = new Locale("es");

	public String decryptPlano(String menPlano) {
		menPlano = cryptoSwiftService.decryptPlain(menPlano);
		return ArchivoUtil.decodeFromUri(menPlano);

	}

	/**
	 * retorna el mensaje swift BCB desde un archivo en formato plano
	 * 
	 * @param menPlano mensaje en formato plano
	 * @return {@link SwiftMessageBcb} estructura desparceada de swift
	 */
	private SwiftMessageBcb swiftMessageBcbFromString(String menPlano, boolean doDecrypt) {

		try {
			if (menPlano == null)
				throw new SwiftAdminException("Mensaje swift RJE nulo");

			if (doDecrypt)
				menPlano = decryptPlano(menPlano);
			else {
				menPlano = ArchivoUtil.decodeFromUri(menPlano);
			}

			SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb(menPlano);
			swiftMessageBcb.fromString(menPlano);

			return swiftMessageBcb;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			throw new SwiftAdminException("Error al parsear mensaje swift NULO", e);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SwiftAdminException("Error: " + e.getMessage(), e);
		}

	}

	private SwiftMessageBcb swiftMessageBcbFromString(String menPlano) {
		try {
			if (menPlano == null)
				throw new SwiftAdminException("Mensaje swift RJE nulo");

			SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb(menPlano);
			swiftMessageBcb.fromString(menPlano);

			return swiftMessageBcb;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			throw new SwiftAdminException("Error al parsear mensaje swift NULO", e);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SwiftAdminException("Error: " + e.getMessage(), e);
		}

	}

	public List<Block4> block4FromString(String menPlano) {
		try {
			SwiftMessageBcb swiftMessageBcb = swiftMessageBcbFromString(menPlano);
			return createListBlock4(swiftMessageBcb, true);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public SwiftDatos swiftDatosFromString(String menPlano) {
		try {
			SwiftMessageBcb swiftMessageBcb = swiftMessageBcbFromString(menPlano);

			if (swiftMessageBcb.getSwiftMessage().getDirection() != null && swiftMessageBcb.getSwiftMessage().isOutgoing())
				if (!swiftMessageBcb.isValid()) {
					log.error("Mensaje PLANO invalido: " + UtilsGeneric.getShortText(swiftMessageBcb.getMenPlano(), 288));
					throw new SwiftAdminException("Mensaje Swift con formato invalido");
				}

			SwfMensaje swfMensaje = new SwfMensaje();
			newSwfMensajeFrom(swiftMessageBcb, swfMensaje, null, false);

			SwiftDatos swiftDatos = new SwiftDatos();
			swiftDatos.setSwiftMessageBcb(swiftMessageBcb);
			swiftDatos.setSwfMensaje(swfMensaje);

			return swiftDatos;
		} catch (Exception e) {
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public SwiftDatos actualizarSwfMensajeFromPlano0(SwfMensaje swfMensaje, String menplano, boolean doDecrypt, String menHash, boolean addOrReplaceCodeLau) {
		// el objeto es mantener el principio que el mensaje debe ser
		// actualizado a partir de las fuentes
		try {
			SwiftMessageBcb swiftMessageBcb = swiftMessageBcbFromString(menplano);

			if (!StringUtils.isBlank(menHash) && addOrReplaceCodeLau)
				swiftMessageBcb.addBlockLAU0(menHash, addOrReplaceCodeLau);

			newSwfMensajeFrom(swiftMessageBcb, swfMensaje, menHash, addOrReplaceCodeLau);

			SwiftDatos swiftDatos = new SwiftDatos();
			swiftDatos.setSwiftMessageBcb(swiftMessageBcb);
			swiftDatos.setSwfMensaje(swfMensaje);

			return swiftDatos;
		} catch (Exception e) {
			log.error("===== RJE =====");
			log.error(menplano);
			log.error("===== === =====");
			log.error("Error al actualizar mensaje swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar mensaje swift " + e.getMessage(), e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.lavado.services.SwiftBcbParserService#swfMensajeFromLote(java
	 * .lang.String)
	 */
	public List<MensajesDatos> swfMensajeFromLote(String planoLote) {
		List<MensajesDatos> mensajesDatosLista = new ArrayList<>();
		if (!ParserSwiftMessage.isFormatSwift(planoLote)) {
			log.error("Formato de archivo invalido");
			throw new RuntimeException("Formato de archivo invalido");
		}

		String[] splitSwift = ParserSwiftMessage.splitSwift(planoLote);
		int conta = 1;
		for (String swiftPlano : splitSwift) {
			MensajesDatos mensajesDatos = new MensajesDatos();
			SwiftDatos swiftDatos = swiftDatosFromString(swiftPlano);
			swiftDatos.getSwfMensaje().setBlock4List(createListBlock4(swiftDatos.getSwiftMessageBcb(), true));

			if (swiftDatos.getSwiftMessageBcb().getBlock2() != null) {
				swiftDatos.getSwfMensaje().setMenCodmen(conta);

				mensajesDatos.setMenCodmen(conta);
				mensajesDatos.setSwfMensaje(swiftDatos.getSwfMensaje());
				mensajesDatos.setBlock4List(swiftDatos.getSwfMensaje().getBlock4List());
				mensajesDatosLista.add(mensajesDatos);
				conta++;
			}
		}
		log.info("Mensajes desparseados de lote " + mensajesDatosLista.size());
		return mensajesDatosLista;
	}

	private static SwfMensaje newSwfMensajeFrom(SwiftMessageBcb swiftMessageBcb, SwfMensaje swfMensaje, String menHash, boolean addOrReplaceCodeLau) {
		// log.info("Creando SwfMensaje de SwiftMessageBcb");
		swfMensaje.setMenCodmt(swiftMessageBcb.getSwiftMessage().getType());
		swfMensaje.setMenPlano(swiftMessageBcb.getMenPlano());

		if (!StringUtils.isBlank(menHash) && addOrReplaceCodeLau)
			swfMensaje.setMenHash(menHash);
		else {
			String clau = swiftMessageBcb.getTagCodeLau();
			if (!StringUtils.isBlank(clau)) {
				swfMensaje.setMenHash(clau);
			} else {
				swfMensaje.setMenHash(swiftMessageBcb.checkSum());
			}
		}

		if (swiftMessageBcb.getSwiftMessage().isIncoming()) {
			swfMensaje.setMenCodapp((!StringUtils.isBlank(swfMensaje.getMenCodapp()) ? swfMensaje.getMenCodapp() : Constants.COD_APP_NEMO));
			swfMensaje.setMenRefer(!StringUtils.isBlank(swfMensaje.getMenRefer()) ? swfMensaje.getMenRefer() : swfMensaje.getMenHash());

			swfMensaje.setMenEmisor(swiftMessageBcb.getSwiftMessage().getSender());
			swfMensaje.setMenReceiver(swiftMessageBcb.getSwiftMessage().getReceiver());

			if (swiftMessageBcb.getBlock2() != null) {
				SwiftBlock2Output swiftBlock2Output = (SwiftBlock2Output) swiftMessageBcb.getBlock2();
				swfMensaje.setMenCodswift(swiftBlock2Output.getMIR());
				swfMensaje.setMenRefer(swiftBlock2Output.getMIR());
			}

			swfMensaje.setMenInout(Constants.TIPO_MENSAJE_IN);

			BIC bic = new BIC(swfMensaje.getMenEmisor());
			swfMensaje.setMenBic(bic.getBic8());
			swfMensaje.setMenBicbranch(bic.getBranch());
		} else if (swiftMessageBcb.getSwiftMessage().isOutgoing()) {
			swfMensaje.setMenReceiver(swiftMessageBcb.getSwiftMessage().getReceiver());
			swfMensaje.setMenEmisor(swiftMessageBcb.getSwiftMessage().getSender());

			Field20 f20 = (Field20) swiftMessageBcb.getField(Constants.CAMPO_SWIFT_20);
			if (f20 != null) {
				String[] cmp20 = f20.getValue().split("/");
				if (StringUtils.isBlank(swfMensaje.getMenCodusrswf()))
					swfMensaje.setMenCodusrswf((cmp20.length == 3 ? cmp20[2] : swfMensaje.getMenCodusrswf()));
				swfMensaje.setMenCodswift(f20.getValue());
			} else {
				log.warn("Mensaje swift sin campo 20 " + swfMensaje.getMenHash() + " sera el codigo de operaion");
				swfMensaje.setMenCodswift(swfMensaje.getMenRefer());
			}

			swfMensaje.setMenInout(Constants.TIPO_MENSAJE_OUT);

			BIC bic = new BIC(swfMensaje.getMenReceiver());
			swfMensaje.setMenBic(bic.getBic8());
			swfMensaje.setMenBicbranch(bic.getBranch());
		}

		return swfMensaje;
	}

	private Block4 getBlock4FromField(Field field, String mt, boolean requireDescrip) {

		if (field == null || field.isEmpty()) {
			return null;
		}
		Block4 block4 = new Block4();
		block4.setName(field.getName());
		String valorCampo = field.getValue();
		block4.setValue(valorCampo);

		if (!requireDescrip)
			return block4;

		String label = StringEscapeUtils.unescapeHtml(field.getLabel(field.getName(), mt, null, locale));
		log.debug(" => label " + field.getName() + "[" + mt + "] : " + label + " : " + field.getValue());

		StringBuilder valueDescrip = new StringBuilder();
		for (int i = 1; i <= field.componentsSize(); i++) {
			String labelComp = field.getComponentLabel(i);
			if (StringUtils.isBlank(labelComp)) {
				labelComp = field.getName();
			}
			String component = field.getComponent(i);
			String valueDisplay = field.getValueDisplay(i, locale);
			if (!StringUtils.isBlank(component)) {
				if (labelComp.equals("BIC")) {
					BIC bic = new BIC(component);
					String branch = bic.getBranch();
					if (StringUtils.isBlank(bic.getBranch())) {
						branch = "XXX";
					}
					// log.debug("BIC " + field.getComponent(i) + " valid? " + bic.isValid());
					if (bic.isValid()) {
						SwfBics swfBics = swfBicsDao.findByBicBranch(bic.getBic8(), branch);
						if (swfBics != null) {
							component = component + SWIFT_EOL + StringUtils.trimToEmpty(swfBics.getBicDescrip());
							component = component + SWIFT_EOL + StringUtils.trimToEmpty(swfBics.getBicPais()) + ", "
									+ StringUtils.trimToEmpty(swfBics.getBicCiudad());
						}
						valueDisplay = component;
					}
				}

				valueDescrip.append(labelComp + " : " + valueDisplay);
				if (i < field.componentsSize() && !StringUtils.isBlank(field.getComponent(i + 1)))
					valueDescrip.append(SWIFT_EOL);
			}
		}

		block4.setReference(label);
		block4.setValueDescrip(valueDescrip.toString());
		return block4;
	}

	public List<Block4> createListBlock4(SwiftMessageBcb swiftMessageBcb, boolean requireDescrip) {
		List<Block4> block4Lista = new ArrayList<>();
		final SwiftBlock4 b4 = swiftMessageBcb.getSwiftMessage().getBlock4();

		if (b4 != null && !b4.isEmpty()) {
			for (Tag t : b4.getTags()) {
				final Field field = t.asField();
				Block4 block = getBlock4FromField(field, swiftMessageBcb.getSwiftMessage().getType(), requireDescrip);
				if (block == null) {
					// el campo no implementa el swift provide
					block = new Block4();
					block.setName(t.getName());
					block.setValue(t.getValue());
					block.setReference("Campo: " + t.getName());
					block.setValueDescrip("");
				}
				block4Lista.add(block);
			}
		}
		return block4Lista;
	}

	public static String decodeMensaje(String menPlano) {
		boolean isEncoded = true;
		try {
			new URI(menPlano);
		} catch (URISyntaxException e) {
			isEncoded = false;
		}

		if (isEncoded) {
			try {
				menPlano = URLDecoder.decode(menPlano, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				throw new SwiftAdminException("Error en URLDecoder.decode " + e.getMessage(), e);
			}
		}
		return menPlano;
	}

	/****************************/
	public static SwiftDatos actualizarSwfMensajeFromPlano(String menPlano) {
		return actualizarSwfMensajeFromPlano(new SwfMensaje(), menPlano);
	}

	public static SwiftDatos actualizarSwfMensajeFromPlano(SwfMensaje swfMensaje, String menplano) {
		// el objeto es mantener el principio que el mensaje debe ser
		// actualizado a partir de las fuentes
		try {						
			SwiftMessageAbstract sma = FactoryParser.createParser(menplano)//
					.extractMetadata();//
			;
			log.info("Mensaje Parser typeMessage: {} - {}", sma.getTypeMessage(), sma.getSwfMsgParam().getMenIdTMessageTx());

			updSwfMensajeFromPlano(sma, swfMensaje);

			SwiftDatos swiftDatos = new SwiftDatos();
			swiftDatos.setSwfMensaje(swfMensaje);
			swiftDatos.setSwiftMessageAbs(sma);

			return swiftDatos;
		} catch (Exception e) {
			log.error("=====  =====");
			log.error(menplano);
			log.error("===== === =====");
			log.error("Error al actualizar mensaje swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar mensaje swift " + e.getMessage(), e);
		}
	}

	public static SwfMensaje updSwfMensajeFromPlano(SwiftMessageAbstract sma, SwfMensaje swfMensaje) {

		// log.info("Creando SwfMensaje de SwiftMessageBcb");
		swfMensaje.setMenCodmt(sma.getSwfMsgParam().getMenTypemessage());
		swfMensaje.setMenIdtmessagetx(sma.getSwfMsgParam().getMenIdTMessageTx());
		swfMensaje.setMenPlano(sma.getMenPlano());
		swfMensaje.setMenReceiver(sma.getSwfMsgParam().getMenReceiver());
		swfMensaje.setMenEmisor(sma.getSwfMsgParam().getMenEmisor());
		swfMensaje.setMenCodswift(sma.getSwfMsgParam().getMenCodswift());
		swfMensaje.setMenMonswift(sma.getSwfMsgParam().getMenCodmon());
		swfMensaje.setMenFormato(sma.getSwfMsgParam().getMenFormato());
		BIC bic = new BIC(swfMensaje.getMenReceiver());
		swfMensaje.setMenBic(bic.getBic11());

		return swfMensaje;
	}

	public static void updSign(SwiftDatos swiftDatos, String codelau, Message messagePdu) {
		try {
			// log.info("plano " + sma.getMenPlano());
			SwiftMessageAbstract sma = swiftDatos.getSwiftMessageAbs();

			if (!StringUtils.isBlank(codelau))
				HandlerGeneratorLauSrv.getCurrentInstanceHGen().validateCodeLauForMsg(sma.getMenPlanoOrig(), codelau);
			
			if (HandlerGeneratorLauSrv.getCurrentInstanceHGen().existsLau()) {
				AuthParameters authParameters = new AuthParameters((SecretKeySpec) HandlerGeneratorLauSrv.getGeneratorLAU().getKeyMac());				
				if (sma.isMt()) {
					sma.updMsgForSign().addBlockLAU(authParameters);
				} else if (sma.isMx()) {
					DataPDU pdu = sma.getdPDUWriter().getDataPDU();	

					pdu.getHeader().getMessage().getInterfaceInfo().setServiceURI(messagePdu.getInterfaceInfo().getServiceURI());
					pdu.getHeader().getMessage().getInterfaceInfo().setMessageTypeURI(messagePdu.getInterfaceInfo().getMessageTypeURI());
					pdu.getHeader().getMessage().getNetworkInfo().setService(messagePdu.getNetworkInfo().getService());
					pdu.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo()
							.setRequestSubtype(messagePdu.getNetworkInfo().getSWIFTNetNetworkInfo().getRequestSubtype());
					
					sma.updMsgForSign().addBlockLAU(authParameters);
				} else {
					throw new SwiftAdminException("Swift con formato no reconocido, se esperaba MT o MX");
				}
			
				swiftDatos.getSwfMensaje().setMenPlano(sma.getMenPlano());
				swiftDatos.getSwfMensaje().setMenHash(sma.getSwfMsgParam().getMenHash());

				log.info("Mensaje {} actualizado con LAU {} ", swiftDatos.getSwfMensaje().getMenCodmen(), swiftDatos.getSwfMensaje().getMenHash());
			} else {
				log.warn("Lvd no implementa LAU!! (no se que paso, pero esto no deberia pasar ... pero paso!!) ", swiftDatos.getSwfMensaje().getMenCodmen(),
						swiftDatos.getSwfMensaje().getMenHash());
				swiftDatos.getSwfMensaje().setMenPlano(sma.getMenPlano());
				swiftDatos.getSwfMensaje().setMenHash(null);
			}
		} catch (Exception e) {
			log.error("Error mensaje " + swiftDatos.getSwfMensaje().getMenCodmen() + " : " + e.getMessage());
			throw new SwiftAdminException("Actualizando Firma: " + swiftDatos.getSwfMensaje().getMenCodmen() + ": " + e.getMessage(), e);
		}
	}

	public static String usingByteArrayOutputStreamClass(String input) throws IOException {
		if (input == null) {
			return null;
		}

		String output;
		try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream(); PrintStream printStream = new PrintStream(outputStream)) {
			printStream.print(input);

			output = outputStream.toString();
		}

		return output;
	}

}
