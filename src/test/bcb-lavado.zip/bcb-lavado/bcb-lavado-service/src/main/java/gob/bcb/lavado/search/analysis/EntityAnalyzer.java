package gob.bcb.lavado.search.analysis;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.core.LowerCaseFilter;
import org.apache.lucene.analysis.core.StopFilter;
import org.apache.lucene.analysis.es.SpanishAnalyzer;
import org.apache.lucene.analysis.es.SpanishLightStemFilter;
import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
import org.apache.lucene.analysis.snowball.SnowballFilter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.util.CharArraySet;
import org.apache.lucene.analysis.util.StopwordAnalyzerBase;
import org.apache.lucene.analysis.util.WordlistLoader;
import org.apache.lucene.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EntityAnalyzer extends StopwordAnalyzerBase {
	private static final Logger log = LoggerFactory.getLogger(EntityAnalyzer.class);
	private final CharArraySet stemExclusionSet;

	/** File containing default Spanish stopwords. */
	public final static String DEFAULT_STOPWORD_FILE = "spanish_stop.txt";

	/**
	 * Returns an unmodifiable instance of the default stop words set.
	 * 
	 * @return default stop words set.
	 */
	public static CharArraySet getDefaultStopSet() {
		return DefaultSetHolder.DEFAULT_STOP_SET;
	}

	private static class DefaultSetHolderEnglish {
		static final CharArraySet DEFAULT_STOP_SET_ENGLISH = StandardAnalyzer.STOP_WORDS_SET;
	}

	/**
	 * Atomically loads the DEFAULT_STOP_SET_ENGLISH more words stops spanish in a lazy fashion once the outer
	 * class accesses the static final set the first time.;
	 */
	private static class DefaultSetHolder {
		static final CharArraySet DEFAULT_STOP_SET;

		static {
			try {
				DEFAULT_STOP_SET = newCharArraySetFrom(DefaultSetHolderEnglish.DEFAULT_STOP_SET_ENGLISH, SpanishAnalyzer.getDefaultStopSet());
				log.info("Load of stopWords done... " + DEFAULT_STOP_SET.size());
			} catch (Exception ex) {
				// default set should always be present as it is part of the
				// distribution (JAR)
				throw new RuntimeException("Unable to load default stopword set");
			}
		}
	}

	/**
	 * Builds an analyzer with the default stop words:
	 * {@link #DEFAULT_STOPWORD_FILE}.
	 */
	public EntityAnalyzer() {
		this(DefaultSetHolder.DEFAULT_STOP_SET);
	}

	public EntityAnalyzer(String p) {
		this(newCharArraySetFrom(DefaultSetHolder.DEFAULT_STOP_SET, charSetFromFile(p)));
	}

	/**
	 * Builds an analyzer with the given stop words.
	 * 
	 * @param stopwords
	 *            a stopword set
	 */
	public EntityAnalyzer(CharArraySet stopwords) {
		this(stopwords, CharArraySet.EMPTY_SET);
	}

	/**
	 * Builds an analyzer with the given stop words. If a non-empty stem
	 * exclusion set is provided this analyzer will add a
	 * {@link SetKeywordMarkerFilter} before stemming.
	 * 
	 * @param stopwords
	 *            a stopword set
	 * @param stemExclusionSet
	 *            a set of terms not to be stemmed
	 */
	public EntityAnalyzer(CharArraySet stopwords, CharArraySet stemExclusionSet) {
		super(stopwords);
		this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(stemExclusionSet));
	}

	/**
	 * Creates a
	 * {@link org.apache.lucene.analysis.Analyzer.TokenStreamComponents} which
	 * tokenizes all the text in the provided {@link Reader}.
	 * 
	 * @return A
	 *         {@link org.apache.lucene.analysis.Analyzer.TokenStreamComponents}
	 *         built from an {@link StandardTokenizer} filtered with
	 *         {@link StandardFilter}, {@link LowerCaseFilter},
	 *         {@link StopFilter} , {@link SetKeywordMarkerFilter} if a stem
	 *         exclusion set is provided and {@link SpanishLightStemFilter}.
	 */
	@Override
	protected TokenStreamComponents createComponents(String fieldName) {
		final Tokenizer source = new StandardTokenizer();
		TokenStream result = new StandardFilter(source);
		result = new LowerCaseFilter(result);
		result = new StopFilter(result, stopwords);
		if (!stemExclusionSet.isEmpty())
			result = new SetKeywordMarkerFilter(result, stemExclusionSet);
		// result = new SpanishLightStemFilter(result);
		return new TokenStreamComponents(source, result);
	}

	public static CharArraySet newCharArraySetFrom(CharArraySet... charArraySets) {
		log.info("charArraySets.length " + charArraySets.length);
		if (charArraySets.length == 0) {
			return StandardAnalyzer.STOP_WORDS_SET;
		}
		
		CharArraySet set = new CharArraySet(charArraySets[0].size(), true);
		for (CharArraySet charArraySet : charArraySets) {
			log.debug("charArraySets.size() " + charArraySet.size() + " " + charArraySet);
			set.addAll(charSetToList(charArraySet));
		}
		set = CharArraySet.unmodifiableSet(set);
		return set;
	}

	public static List<String> charSetToList(CharArraySet cs) {
		final List<String> stopwords = new ArrayList<>();

		for (Object item : cs) {
			if (item instanceof char[]) {
				String s = String.valueOf((char[]) item);
				stopwords.add(s);
			} else {
				stopwords.add((String) item);
			}
		}
		return stopwords;
	}

	public static CharArraySet charSetFromFile(String p) {
		InputStream is;
		try {
			File h = new File(p);
			if (!h.exists() || h.isDirectory()) {
				CharArraySet set = new CharArraySet(0, true);
				log.error("File stop words not found!! " + p);
				return set;
			}
			is = new FileInputStream(p);
			CharArraySet cs = WordlistLoader.getSnowballWordSet(IOUtils.getDecodingReader(is, StandardCharsets.UTF_8));
			log.info("Stop words loaded: " + cs.size() + " from " + h.getAbsolutePath());
			return cs;
		} catch (FileNotFoundException e) {
			throw new RuntimeException("Unable to load default stopword set from file " + p + " " + e.getMessage(), e);
		} catch (IOException e) {
			throw new RuntimeException("Error al cargar archivo " + p + " " + e.getMessage(), e);
		}
	}
}
