package gob.bcb.lavado.repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import gob.bcb.lavado.commons.Constants;


public class GenTablasDaoImpl implements GenTablasDao {
	private static final Logger log = LoggerFactory.getLogger(GenTablasDaoImpl.class);
	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;
	
	@Autowired
	@Qualifier("entityManagerFactory")	
	private EntityManagerFactory entityManagerFactory;
	
}
