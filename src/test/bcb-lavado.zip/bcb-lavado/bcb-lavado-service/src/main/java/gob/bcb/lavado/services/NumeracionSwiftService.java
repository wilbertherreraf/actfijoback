package gob.bcb.lavado.services;

import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.web.util.UriComponentsBuilder;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.WebUtils;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfNumeraswf;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.pojos.Asignacion;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfNumeraswfDaoImpl;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.lavado.repository.SwfPersonaDao;

@Service(value = "numeracionSwiftService")
public class NumeracionSwiftService {
	private static final Logger log = LoggerFactory.getLogger(NumeracionSwiftService.class);

	@Autowired
	private MailService mailService;
	@Autowired
	private SwfPersonaDao swfPersonaDao;
	@Autowired
	private SwfNumeraswfDaoImpl swfNumeraswfDao;
	@Autowired
	private SessionsSearcherService sessionsSearcherService;
	@Autowired
	private SwfParamsDao swfParamsDao;

	public void solicitudManual(Integer perCodemp, String codUser, String estacion, String url) {
		String idSession = UUID.randomUUID().toString().replace("-", "");
		try {
			log.info("Inicio solicitud nro SWIFT  codemp: {} url: {}", perCodemp, url);
			Optional<SwfPersona> swfPersonaOpt = swfPersonaDao.findByCodEmail(perCodemp);
			if (!swfPersonaOpt.isPresent()) {
				throw new SwiftAdminException("Codigo o correo de solicitante inexistente " + perCodemp );
			}

			SwfPersona swfPersona = swfPersonaOpt.get();

			SwfNumeraswf swfNumeraswf = SwfNumeraswfDaoImpl.crearNuevo(perCodemp, Constants.TAB_TIPONRO_MANUAL, codUser);
			swfNumeraswf.setNroIdverifica(idSession);
			swfNumeraswf.setNroAuditwst(estacion);

			swfNumeraswfDao.invalidarSolic(perCodemp, swfNumeraswf.getNroGestion());

			swfPersona.setPerIdverifica(idSession);
			swfPersonaDao.saveorupdate(swfPersona);

			swfNumeraswfDao.saveOrUpdate(swfNumeraswf);

			sessionsSearcherService.createSession(idSession, perCodemp.toString());

			MensajesDatos mensajesDatos = new MensajesDatos();
			mensajesDatos.setAsignacion(new Asignacion());
			mensajesDatos.getAsignacion().setSwfPersona(swfPersona);

			String urlreq = UriComponentsBuilder.fromUriString(url + "/public/nroswift/confirmar.xhtml").queryParam("codper", perCodemp.toString())
					.queryParam("idver", idSession).toUriString();

			EmailDetalle emailDetalle = inicializaCorreos();
			emailDetalle.setFrom("");
			emailDetalle.setTo(new String[] { swfPersona.getPerEmail() });
			emailDetalle.setSubject("Solicitud de correlativo swift");
			emailDetalle.getParams().put("urlreq", urlreq);

			sendMailForConfirmacion(mensajesDatos, emailDetalle);
			log.info("==>FIN Solicitud de Correlativo SWIFT generado emp: {} session: {} URL: {}", perCodemp, idSession, urlreq);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			sessionsSearcherService.closeSession(idSession);
			throw new SwiftAdminException("Error " + e.getMessage());
		}
	}

	public void solicitudManualAdm(Integer perCodemp, String codUser, String estacion) {
		try {
			log.info("Inicio solicitud nro SWIFT  codemp: {} corre: {} url: {}", perCodemp);
			SwfNumeraswf swfNumeraswf = SwfNumeraswfDaoImpl.crearNuevo(perCodemp, Constants.TAB_TIPONRO_SOLICXADM, codUser);
			swfNumeraswf.setNroAuditwst(estacion);

			Integer gestion = UtilsDate.gestionActual();
			Integer nroSwift = swfNumeraswfDao.sigNroSwift(gestion);
			swfNumeraswf.setNroNroswift(nroSwift);
			
			swfNumeraswfDao.saveOrUpdate(swfNumeraswf);
			
			Optional<SwfNumeraswf> swfNumeraswfNew = swfNumeraswfDao.findByGestionNro(gestion, nroSwift);
			if (!swfNumeraswfNew.isPresent()) {
				throw new SwiftAdminException("Error al generar Correlativo swift " + nroSwift + " no pudo ser generado.");
			}			
			log.info("==>FIN Solicitud de Correlativo SWIFT generado emp: {} session: {} URL: {}", perCodemp);

		} catch (Exception e) {
			throw new SwiftAdminException("Error " + e.getMessage());
		}
	}	
	public SwfNumeraswf obtenerSolicitudVig(Integer perCodemp, String idsession) {
		log.info("obtenerSolicitud Vigente id: {} ", idsession);
		if (StringUtils.isBlank(idsession)) {
			return new SwfNumeraswf();
		}

		Optional<SwfPersona> swfPersonaOpt = swfPersonaDao.findByTokenVerifica(perCodemp, idsession);
		if (!swfPersonaOpt.isPresent()) {
			sessionsSearcherService.closeSession(idsession);
			throw new SwiftAdminException("Sesión inválida o vencida, genere nuevamente una nueva solicitud.");
		}
		Integer gestion = UtilsDate.gestionActual();

		sessionsSearcherService.validateSession(idsession, perCodemp.toString());
		Optional<SwfNumeraswf> swfNumeraswfOpt = swfNumeraswfDao.findByToken(gestion, perCodemp, idsession);

		if (!swfNumeraswfOpt.isPresent()) {
			sessionsSearcherService.closeSession(idsession);
			throw new SwiftAdminException("Solicitud inexistente con session " + idsession);
		}

		SwfNumeraswf swfNumeraswf = SwfNumeraswfDaoImpl.cloneSwfNumeraswf(swfNumeraswfOpt.get());
		if (swfNumeraswf.getNroNroswift() != null && swfNumeraswf.getNroNroswift().compareTo(0) > 0) {
			sessionsSearcherService.closeSession(idsession);
			throw new SwiftAdminException("Solicitud ya fue asignado con session " + idsession + " con id " + swfNumeraswf.getNroCodnro());
		}

		Integer nroSwift = swfNumeraswfDao.sigNroSwift(gestion);
		swfNumeraswf.setNroNroswift(nroSwift);

		sessionsSearcherService.revalidateSession(idsession, perCodemp.toString());

		return swfNumeraswf;
	}

	public void confirmacionSolicitud(Integer nroCodnro, String idsession, Integer nroSwiftAsig) {
		log.info("confirmacionSolicitud id: {} : {}", idsession, nroSwiftAsig);
		if (nroSwiftAsig == null || nroSwiftAsig.compareTo(0) <= 0) {
			sessionsSearcherService.closeSession(idsession);
			throw new SwiftAdminException("En confirmación parámetro de Correlativo swift debe ser mayor a 0.");
		}

		//SwfNumeraswf swfNumeraswf = obtenerSolicitudVig(idsession);
		SwfNumeraswf swfNumeraswf = swfNumeraswfDao.findByCodigo(nroCodnro);
		if (swfNumeraswf == null) {
			sessionsSearcherService.closeSession(idsession);
			throw new SwiftAdminException("Solicitud inexistente con id " + nroCodnro);
		}
		
		if (swfNumeraswf.getNroNroswift() != null && swfNumeraswf.getNroNroswift().compareTo(0) > 0) {
			sessionsSearcherService.closeSession(idsession);
			throw new SwiftAdminException("Solicitud ya fue asignado con session " + idsession + " con id " + swfNumeraswf.getNroCodnro());
		}
		
		asignacionCorrelativo(swfNumeraswf, nroSwiftAsig);

		invalidaSession(idsession, swfNumeraswf.getNroCodemp());
	}

	public void rechazarSolicitud(SwfNumeraswf swfNumeraswfIn) {
		SwfNumeraswf swfNumeraswf = swfNumeraswfDao.findByCodigo(swfNumeraswfIn.getNroCodnro());
		if (swfNumeraswf == null) {
			throw new SwiftAdminException("Solicitud inexistente con id " + swfNumeraswfIn.getNroCodnro());
		}
		swfNumeraswf.setNroEstadonro(Constants.TAB_ESTNRO_RECHAZADO);
		swfNumeraswf.setNroAuditfho(new Date());
		swfNumeraswf.setNroAuditwst(swfNumeraswfIn.getNroAuditwst());
		swfNumeraswf.setNroAuditusr(swfNumeraswfIn.getNroAuditusr());
		swfNumeraswf.setNroDescrip(swfNumeraswfIn.getNroDescrip());
		
		log.info("Rechazando solicitud " + swfNumeraswf.toString());
		swfNumeraswfDao.updateReg(swfNumeraswf);
	}
	
	synchronized public Integer asignacionCorrelativo(SwfNumeraswf swfNumeraswf, Integer nroSwiftAsig) {

		Integer gestion = UtilsDate.gestionActual();
		Integer nroSwift = swfNumeraswfDao.sigNroSwift(gestion);
		
		if (nroSwiftAsig == null && swfNumeraswf.getNroTipnroswf().compareTo(Constants.TAB_TIPONRO_AUTOMATICO) == 0) {
			swfNumeraswf.setNroNroswift(nroSwift);
			swfNumeraswf.setNroEstadonro(Constants.TAB_ESTNRO_ASIGNADO);
			
			swfNumeraswfDao.saveOrUpdate(swfNumeraswf);			
		} else {
			if (nroSwiftAsig == null || nroSwift.compareTo(nroSwiftAsig) != 0) {
				sessionsSearcherService.closeSession(swfNumeraswf.getNroIdverifica());
				throw new SwiftAdminException("Correlativo swift " + nroSwiftAsig + " inválido, posiblemente ya fue asignado, genere una nueva solicitud.");
			}
			swfNumeraswfDao.asignarNumero(swfNumeraswf.getNroCodnro(), swfNumeraswf.getNroGestion(), swfNumeraswf.getNroIdverifica(), nroSwiftAsig);			
		}
		
		Optional<SwfNumeraswf> swfNumeraswfNew = swfNumeraswfDao.findByGestionNro(gestion, nroSwift);
		if (!swfNumeraswfNew.isPresent()) {
			throw new SwiftAdminException("Error al generar Correlativo swift " + nroSwift + " no pudo ser generado.");
		}
		log.info("==> ASIGNACION Numero SWIFT: {} : {}, tipo: [{}]", swfNumeraswfNew.get().getNroCodnro(), nroSwift, swfNumeraswfNew.get().getNroTipnroswf());
		return nroSwift;
	}
	
	private void invalidaSession(String idsession, Integer codUser) {
		sessionsSearcherService.closeSession(idsession);
		swfPersonaDao.closeSession(codUser);
	}

	private void sendMailForConfirmacion(MensajesDatos mensajesDatos, EmailDetalle emailDetalle) {
		// correos para alerta
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CORREOREMITENTENSWF);
		if (swfParams == null){
			throw new RuntimeException("Parametro {" + Constants.PARAM_CORREOREMITENTENSWF + "} de correo remitente en Asiganciones nro swift nulo");
		}
		String from = swfParams.getParValor();
		emailDetalle.setFrom(from);
		
		mailService.sendConfirmaSolicNroSwiftEmail(mensajesDatos, emailDetalle);
		// log.info("Envio de correo de ALERTA hecho... " );
	}

	public static URI createURI(final Serializable id) {
		// Assert.notNull(id);
		if (id == null)
			throw new SwiftAdminException("Serializable id nulo!");
		URI uri;
		try {
			uri = new URI(ServletUriComponentsBuilder.fromCurrentServletMapping().path("/{token}").buildAndExpand(id).toString());
		} catch (final URISyntaxException e) {
			log.error("Cannot create URI for given id:" + id, e);
			throw new SwiftAdminException("Error fatal " + e.getMessage(), e);
		}
		return uri;
	}

	private EmailDetalle inicializaCorreos() {
		EmailDetalle emailDetalle = new EmailDetalle();
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CORRMONITORSWF);
		if (swfParams == null) {
			return emailDetalle;
		}
		String correo = swfParams.getParValor();
		emailDetalle.setFrom(correo);
		return emailDetalle;
	}

}
