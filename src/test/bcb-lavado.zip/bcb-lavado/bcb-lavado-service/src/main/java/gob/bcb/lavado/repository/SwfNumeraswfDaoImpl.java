package gob.bcb.lavado.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfNumeraswf;

@Repository("swfNumeraswfDao")
@Transactional
public class SwfNumeraswfDaoImpl {
	private static final Logger log = LoggerFactory.getLogger(SwfNumeraswfDaoImpl.class);

	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;

	@Autowired
	@Qualifier("entityManagerFactory")
	private EntityManagerFactory entityManagerFactory;

	public SwfNumeraswf findByCodigo(Integer nroCodnro) {
		if (nroCodnro == null)
			return null;
		String jpql = "SELECT t FROM SwfNumeraswf t WHERE t.nroCodnro = :nroCodnro ";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("nroCodnro", nroCodnro);
		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfNumeraswf) lista.get(0);
		}
		return null;
	}

	public List<SwfNumeraswf> getAll() {
		String jpql = "SELECT t FROM SwfNumeraswf t ";
		Query query = entityManager.createQuery(jpql);

		List lista = query.getResultList();
		return lista;
	}

	public Optional<SwfNumeraswf> findByToken(Integer nroGestion, Integer nroCodemp, String nroIdverifica) {
		if (nroIdverifica == null)
			return Optional.empty();

		StringBuilder jpql = new StringBuilder("SELECT t ");
		jpql.append("FROM SwfNumeraswf t ");
		jpql.append("WHERE t.nroIdverifica = :nroIdverifica ");
		jpql.append("AND t.nroGestion = :nroGestion ");
		jpql.append("AND t.nroCodemp = :nroCodemp ");

		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("nroIdverifica", nroIdverifica);
		query.setParameter("nroGestion", nroGestion);
		query.setParameter("nroCodemp", nroCodemp);

		List lista = query.getResultList();
		if (lista.size() == 1) {
			return Optional.of((SwfNumeraswf) lista.get(0));
		}
		return Optional.empty();
	}

	public Optional<SwfNumeraswf> findByGestionNro(Integer nroGestion, Integer nroNroswift) {
		if (nroNroswift == null || nroGestion == null)
			return Optional.empty();

		StringBuilder jpql = new StringBuilder("SELECT t ");
		jpql.append("FROM SwfNumeraswf t ");
		jpql.append("WHERE t.nroGestion = :nroGestion ");
		jpql.append("AND t.nroNroswift = :nroNroswift ");
		jpql.append("AND t.nroNroswift > 0 ");

		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("nroNroswift", nroNroswift);
		query.setParameter("nroGestion", nroGestion);

		List lista = query.getResultList();
		if (lista.size() == 1) {
			return Optional.of((SwfNumeraswf) lista.get(0));
		}
		return Optional.empty();
	}

	public Optional<SwfNumeraswf> solicitudesPend0(Integer nroCodemp, Integer nroGestion, Date nroFecha) {
		if (nroCodemp == null)
			return Optional.empty();

		StringBuilder jpql = new StringBuilder("SELECT t ");
		jpql.append("FROM SwfNumeraswf t ");
		jpql.append("WHERE t.nroGestion = :nroGestion ");
		jpql.append("AND t.nroCodemp = :nroCodemp ");
		jpql.append("AND t.nroFecha = :nroFecha ");
		jpql.append("AND t.nroNroswift = 0 ");
		jpql.append("AND t.nroTipnroswf = :nroTipnroswf ");
		jpql.append("AND t.nroEstadonro = :nroEstadonrosol ");

		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("nroCodemp", nroCodemp);
		query.setParameter("nroGestion", nroGestion);
		query.setParameter("nroFecha", nroFecha, TemporalType.DATE);
		query.setParameter("nroTipnroswf", Constants.TAB_TIPONRO_MANUAL);
		query.setParameter("nroEstadonrosol", Constants.TAB_ESTNRO_SOLIC);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return Optional.of((SwfNumeraswf) lista.get(0));
		}
		return Optional.empty();
	}

	public List<SwfNumeraswf> searchAsignaciones(SwfNumeraswf swfNumeraswf, Date fechaini, Date fechafin) {
		fechaini = fechaini == null ? UtilsDate.dateFromString("01/01/1980", "dd/MM/yyyy") : fechaini;
		fechafin = fechafin == null ? UtilsDate.dateFromString("01/01/3000", "dd/MM/yyyy") : fechafin;

		StringBuilder jpql = new StringBuilder("SELECT t ");
		jpql.append("FROM SwfNumeraswf t ");
		jpql.append("WHERE t.nroFecha between :fechaini and :fechafin ");
		if (swfNumeraswf.getNroTipnroswf() != null && swfNumeraswf.getNroTipnroswf().compareTo(0)  > 0 )
			jpql.append("AND t.nroTipnroswf = :nroTipnroswf ");
		if (swfNumeraswf.getNroEstadonro() != null && swfNumeraswf.getNroEstadonro().compareTo(0) > 0)
			jpql.append("AND t.nroEstadonro = :nroEstadonrosol ");
		jpql.append("order by t.nroCodnro, t.nroFechsolic ");
		
		//log.info("fec ini {} - {} tipo {} est {} => {}", fechaini, fechafin, swfNumeraswf.getNroTipnroswf(), swfNumeraswf.getNroEstadonro(), jpql.toString());
		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("fechaini", fechaini, TemporalType.DATE);
		query.setParameter("fechafin", fechafin, TemporalType.DATE);
		if (swfNumeraswf.getNroTipnroswf() != null && swfNumeraswf.getNroTipnroswf().compareTo(0)  > 0 )
			query.setParameter("nroTipnroswf", swfNumeraswf.getNroTipnroswf());
		if (swfNumeraswf.getNroEstadonro() != null && swfNumeraswf.getNroEstadonro().compareTo(0) > 0)
			query.setParameter("nroEstadonrosol", swfNumeraswf.getNroEstadonro());

		List lista = query.getResultList();
		return lista;
	}

	public Optional<SwfNumeraswf> maxNroSwift(Integer nroGestion) {
		if (nroGestion == null)
			return Optional.empty();

		StringBuilder jpql = new StringBuilder("SELECT a ");
		jpql.append("FROM SwfNumeraswf a ");
		jpql.append("where a.nroGestion = :nroGestion ");
		jpql.append("and a.nroNroswift > 0 ");
		jpql.append("and a.nroNroswift = (select max(b.nroNroswift) ");
		jpql.append("from SwfNumeraswf b ");
		jpql.append("where b.nroGestion = a.nroGestion ");
		jpql.append("and a.nroNroswift > 0 ");
		jpql.append(") ");

		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("nroGestion", nroGestion);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return Optional.of((SwfNumeraswf) lista.get(0));
		}
		return Optional.empty();
	}

	public void invalidarSolic(Integer nroCodemp, Integer nroGestion) {
		StringBuilder jpql = new StringBuilder("delete from SwfNumeraswf t ");
//		jpql.append("set t.nroEstadonro = :nroEstadonro ");
		jpql.append("WHERE t.nroGestion = :nroGestion ");
		jpql.append("AND t.nroCodemp = :nroCodemp ");
		jpql.append("AND t.nroNroswift = 0 ");
		jpql.append("AND t.nroTipnroswf = :nroTipnroswf ");
//		jpql.append("AND t.nroEstadonro = :nroEstadonrosol ");

		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("nroCodemp", nroCodemp);
		query.setParameter("nroGestion", nroGestion);
		query.setParameter("nroTipnroswf", Constants.TAB_TIPONRO_MANUAL);
//		query.setParameter("nroEstadonro", Constants.TAB_ESTNRO_VENC);
//		query.setParameter("nroEstadonrosol", Constants.TAB_ESTNRO_SOLIC);

		Integer result = query.executeUpdate();
		log.info("Solicitudes invalidas {} regs: {} ", nroCodemp, result);
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void asignarNumero(Integer nroCodnro, Integer nroGestion, String nroIdverifica, Integer nroNroswift) {
		log.info("=== ASIGNANDO CORRELATIVO {} - {}", nroGestion, nroNroswift);

		StringBuilder jpql = new StringBuilder("update SwfNumeraswf t ");
		jpql.append("set t.nroNroswift = :nroNroswift, ");
		jpql.append("t.nroEstadonro = :nroEstadonro, ");
		jpql.append("t.nroIdverifica = t.nroIdverifica || '_x', ");
		jpql.append("t.nroFechsolic = current, ");		
		jpql.append("t.nroFecha = current, ");
		jpql.append("t.nroAuditfho = current ");
		jpql.append("WHERE t.nroCodnro = :nroCodnro ");
//		jpql.append("WHERE t.nroGestion = :nroGestion ");
		// jpql.append("AND t.nroCodemp = :nroCodemp ");
//		jpql.append("AND t.nroIdverifica = :nroIdverifica ");
		jpql.append("AND t.nroNroswift = 0 ");

		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("nroCodnro", nroCodnro);
//		query.setParameter("nroGestion", nroGestion);
//		query.setParameter("nroIdverifica", nroIdverifica);
		query.setParameter("nroNroswift", nroNroswift);
		// query.setParameter("nroTipnroswf", Constants.TAB_TIPONRO_MANUAL);
		query.setParameter("nroEstadonro", Constants.TAB_ESTNRO_ASIGNADO);
		// query.setParameter("nroEstadonroold", Constants.TAB_ESTNRO_SOLIC);
		// query.setParameter("nroAuditfho", new Date(), TemporalType.TIMESTAMP);

		Integer result = query.executeUpdate();
		if (result.compareTo(1) != 0) {
			log.error("Error al ASIGNAR nro swift, nro de registros actualizados difiere del esperado {} - {}", nroGestion, nroNroswift);
			throw new RuntimeException("Hubo un error al registrar, registros actualizados difiere del esperado.");
		}
		log.info("==>>> Ultimo Numero Swift asignado {}", nroNroswift);
	}

	public int sigNroSwift0(Integer nroGestion) {
		Optional<SwfNumeraswf> swfNumeraswfOpt = maxNroSwift(nroGestion);
		if (swfNumeraswfOpt.isPresent())
			return swfNumeraswfOpt.get().getNroNroswift() + 1;
		else
			return 1;
	}

	public int sigNroSwift(Integer nroGestion) {

		StringBuilder jpql = new StringBuilder("SELECT max(a.nroNroswift) ");
		jpql.append("FROM SwfNumeraswf a ");
		jpql.append("where a.nroGestion = :nroGestion ");
		jpql.append("and a.nroNroswift > 0 ");

		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("nroGestion", nroGestion);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			Integer maximo = lista.get(0) != null ? (Integer) lista.get(0) : 0;
			return (maximo == null ? Integer.valueOf(1) : ++maximo);
		}

		return Integer.valueOf(1);
	}

	public void saveOrUpdate(SwfNumeraswf swfNumeraswf) {
		swfNumeraswf.setNroAuditfho(new Date());

		entityManager.persist(swfNumeraswf);
		log.info("Creando nueva swfNumeraswf " + swfNumeraswf.toString());
	}
	public void updateReg(SwfNumeraswf swfNumeraswf) {
		swfNumeraswf.setNroAuditfho(new Date());

		entityManager.merge(swfNumeraswf);
		log.info("Actualizado " + swfNumeraswf.toString());
	}

	public static SwfNumeraswf crearNuevo(Integer codEmp, Integer tipnroswf, String codSolic) {
		SwfNumeraswf swfNumeraswf = new SwfNumeraswf();

		swfNumeraswf.setNroCodemp(codEmp);
		swfNumeraswf.setNroCodsolic(codSolic);
		swfNumeraswf.setNroGestion(UtilsDate.gestionActual());
		swfNumeraswf.setNroTabtipnroswf(Constants.TAB_TIPONRO);
		swfNumeraswf.setNroTipnroswf(tipnroswf);
		swfNumeraswf.setNroTabestadonro(Constants.TAB_ESTNRO);
		swfNumeraswf.setNroEstadonro(Constants.TAB_ESTNRO_SOLIC);
		swfNumeraswf.setNroNroswift(0);
		swfNumeraswf.setNroFecha(new Date());
		swfNumeraswf.setNroFechsolic(new Date());
		swfNumeraswf.setNroAuditusr(codEmp != null ? codEmp.toString() : codSolic);

		return swfNumeraswf;
	}

	public static SwfNumeraswf cloneSwfNumeraswf(SwfNumeraswf swfNumeraswfOld) {
		SwfNumeraswf swfNumeraswf = new SwfNumeraswf();
		swfNumeraswf.setNroCodnro(swfNumeraswfOld.getNroCodnro());
		swfNumeraswf.setNroCodemp(swfNumeraswfOld.getNroCodemp());
		swfNumeraswf.setNroCodsolic(swfNumeraswfOld.getNroCodsolic());
		swfNumeraswf.setNroGestion(swfNumeraswfOld.getNroGestion());
		swfNumeraswf.setNroTabtipnroswf(swfNumeraswfOld.getNroTabtipnroswf());
		swfNumeraswf.setNroTipnroswf(swfNumeraswfOld.getNroTipnroswf());
		swfNumeraswf.setNroTabestadonro(swfNumeraswfOld.getNroTabestadonro());
		swfNumeraswf.setNroEstadonro(swfNumeraswfOld.getNroEstadonro());
		swfNumeraswf.setNroNroswift(swfNumeraswfOld.getNroNroswift());
		swfNumeraswf.setNroFecha(swfNumeraswfOld.getNroFecha());
		swfNumeraswf.setNroFechsolic(swfNumeraswfOld.getNroFechsolic());
		swfNumeraswf.setNroAuditusr(swfNumeraswfOld.getNroAuditusr());
		swfNumeraswf.setNroDescrip(swfNumeraswfOld.getNroDescrip());
		swfNumeraswf.setNroIdverifica(swfNumeraswfOld.getNroIdverifica());
		swfNumeraswf.setNroAuditwst(swfNumeraswfOld.getNroAuditwst());

		return swfNumeraswf;
	}
}
