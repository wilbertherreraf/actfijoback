package gob.bcb.lavado.security.crypto;

public enum KeyHive
{
	ORIGINAL, 
//	CONVERTED, 
//	SEALED_256, 
	SYSTEM
}
