package gob.bcb.lavado.ofac.dto;

import java.util.Set;

import gob.bcb.lavado.model.OfaAddresslist;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaCitizenship;
import gob.bcb.lavado.model.OfaDateofbirth;
import gob.bcb.lavado.model.OfaIdlist;
import gob.bcb.lavado.model.OfaNationality;
import gob.bcb.lavado.model.OfaPlaceofbirth;
import gob.bcb.lavado.model.OfaVesselinfo;

public class OfacListas {
	private final Set<OfaDateofbirth> listaOfaDateofbirth;
	private final Set<OfaAddresslist> listaOfaAddresslist;
	private final Set<OfaNationality> listaOfaNationality;
	private final Set<OfaCitizenship> listaOfaCitizenship;
	private final Set<OfaPlaceofbirth> listaOfaPlaceofbirth;
	private final Set<OfaIdlist> listaOfaIdlist;
	private final Set<OfaAkalist> listaOfaAkalist;
	private final OfaVesselinfo ofaVesselinfo;
	private final int position;
	public OfacListas(Set<OfaDateofbirth> listaOfaDateofbirth, Set<OfaAddresslist> listaOfaAddresslist, Set<OfaNationality> listaOfaNationality,
			Set<OfaCitizenship> listaOfaCitizenship, Set<OfaPlaceofbirth> listaOfaPlaceofbirth, Set<OfaIdlist> listaOfaIdlist, Set<OfaAkalist> listaOfaAkalist,
			OfaVesselinfo ofaVesselinfo, int position) {
		this.listaOfaDateofbirth = listaOfaDateofbirth;
		this.listaOfaAddresslist = listaOfaAddresslist;
		this.listaOfaNationality = listaOfaNationality;
		this.listaOfaCitizenship = listaOfaCitizenship;
		this.listaOfaPlaceofbirth = listaOfaPlaceofbirth;
		this.listaOfaIdlist = listaOfaIdlist;
		this.listaOfaAkalist = listaOfaAkalist;
		this.ofaVesselinfo = ofaVesselinfo;
		this.position = position;
	}
	public Set<OfaDateofbirth> getListaOfaDateofbirth() {
		return listaOfaDateofbirth;
	}
	public Set<OfaAddresslist> getListaOfaAddresslist() {
		return listaOfaAddresslist;
	}
	public Set<OfaNationality> getListaOfaNationality() {
		return listaOfaNationality;
	}
	public Set<OfaCitizenship> getListaOfaCitizenship() {
		return listaOfaCitizenship;
	}
	public Set<OfaPlaceofbirth> getListaOfaPlaceofbirth() {
		return listaOfaPlaceofbirth;
	}
	public Set<OfaIdlist> getListaOfaIdlist() {
		return listaOfaIdlist;
	}
	public Set<OfaAkalist> getListaOfaAkalist() {
		return listaOfaAkalist;
	}
	public OfaVesselinfo getOfaVesselinfo() {
		return ofaVesselinfo;
	}
	public int getPosition() {
		return position;
	}
	
}
