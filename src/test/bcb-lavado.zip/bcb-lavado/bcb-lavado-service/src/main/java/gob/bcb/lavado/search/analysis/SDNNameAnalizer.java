package gob.bcb.lavado.search.analysis;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.core.LowerCaseFilter;
import org.apache.lucene.analysis.core.StopAnalyzer;
import org.apache.lucene.analysis.core.StopFilter;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.util.CharArraySet;
import org.apache.lucene.util.Version;

/**
 * Filters {@link StandardTokenizer} with {@link StandardFilter},
 * {@link LowerCaseFilter} and {@link StopFilter}, using a list of English stop
 * words.
 */
//@Service
public class SDNNameAnalizer extends Analyzer {
	private static final Logger log = LoggerFactory.getLogger(SDNNameAnalizer.class);
	private Version matchVersion;
	public static final CharArraySet STOP_WORDS_SET = StopAnalyzer.ENGLISH_STOP_WORDS_SET;

	public static final int DEFAULT_MAX_TOKEN_LENGTH = 255;

	private int maxTokenLength = DEFAULT_MAX_TOKEN_LENGTH;

	public SDNNameAnalizer(Version matchVersion) {
		this.matchVersion = matchVersion;
	}

	@Override
	protected TokenStreamComponents createComponents(String fieldName) {
		// return new TokenStreamComponents(new WhitespaceTokenizer());
		log.info("createComponents fieldName: " + fieldName);
		final Tokenizer source = new StandardTokenizer();

		final CharArraySet phraseSets = new CharArraySet(Arrays.asList("Ibrahim Hassan", "tax refund", "ibrahim hassani"), true);

		TokenStream sink = new StandardFilter(source);

		// TokenStream sink = new WhitespaceTokenizer();
		sink = new LowerCaseFilter(sink);
		//sink = new StopFilter(sink, phraseSets);
//		AutoPhrasingTokenFilter aptf = new AutoPhrasingTokenFilter(sink, phraseSets, false);
//		aptf.setReplaceWhitespaceWith(new Character('_'));

		// CharTermAttribute term = aptf.addAttribute(CharTermAttribute.class);
		// try {
		// //aptf.reset();
		// aptf.incrementToken();
		// log.info(term.toString());
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		// sink = new AutoPhrasingTokenFilter(sink, phraseSets, true);
		//sink = aptf;
		// return new TokenStreamComponents(source, sink) ;
		TokenStreamComponents createComponents = new TokenStreamComponents(source, sink);
//		TokenStreamComponents createComponents = new TokenStreamComponents(source, sink) {
//			@Override
//			protected void setReader(final Reader reader) {
//				// try {
//				// source.setReader(reader);
//				// } catch (IOException e1) {
//				// // TODO Auto-generated catch block
//				// e1.printStackTrace();
//				// }
//				int m = SDNNameAnalizer.this.maxTokenLength;
//				log.info("setReader fieldName: " + fieldName + " " + reader.toString());
//
//				if (source instanceof StandardTokenizer) {
//					((StandardTokenizer) source).setMaxTokenLength(m);
//				} else {
//					((StandardTokenizer40) source).setMaxTokenLength(m);
//				}
//				try {
//					super.setReader(reader);
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		};
		
		AutoPhrasingTokenFilter aptf = new AutoPhrasingTokenFilter(sink, phraseSets, true);
		aptf.setReplaceWhitespaceWith(new Character('_'));

        TokenStream stream = aptf; 
        TokenStreamComponents tsc = new TokenStreamComponents(createComponents.getTokenizer(), stream);
        return tsc;
	}
}
