package gob.bcb.lavado.pojos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class GenUsuario implements Serializable {
	private static final long serialVersionUID = 1L;
	private String usrCoduser;
	private String usrAuditusr;
	private String usrAuditwst;
	private Integer usrCodage;
	private String usrArecod;
	private String usrCodemp;
	private String usrEmail;
	private String usrLogin;
	private String usrNombres;
	private Integer usrStatreg;
	private Integer usrTabstatreg;
	private Integer usrTabtipousr;
	private Integer usrTipousr;
	private Participante participante = new Participante();
	private List<String> recursos = new ArrayList<>();
	private List<String> roles = new ArrayList<>();	
	public GenUsuario() {
	}

	public String getUsrCoduser() {
		return this.usrCoduser;
	}

	public void setUsrCoduser(String usrCoduser) {
		this.usrCoduser = usrCoduser;
	}

	public String getUsrAuditusr() {
		return this.usrAuditusr;
	}

	public void setUsrAuditusr(String usrAuditusr) {
		this.usrAuditusr = usrAuditusr;
	}

	public String getUsrAuditwst() {
		return this.usrAuditwst;
	}

	public void setUsrAuditwst(String usrAuditwst) {
		this.usrAuditwst = usrAuditwst;
	}

	public Integer getUsrCodage() {
		return this.usrCodage;
	}

	public void setUsrCodage(Integer usrCodage) {
		this.usrCodage = usrCodage;
	}

	public String getUsrCodemp() {
		return this.usrCodemp;
	}

	public void setUsrCodemp(String usrCodemp) {
		this.usrCodemp = usrCodemp;
	}

	public String getUsrEmail() {
		return this.usrEmail;
	}

	public void setUsrEmail(String usrEmail) {
		this.usrEmail = usrEmail;
	}

	public String getUsrLogin() {
		return this.usrLogin;
	}

	public void setUsrLogin(String usrLogin) {
		this.usrLogin = usrLogin;
	}

	public String getUsrNombres() {
		return this.usrNombres;
	}

	public void setUsrNombres(String usrNombres) {
		this.usrNombres = usrNombres;
	}

	public Integer getUsrStatreg() {
		return this.usrStatreg;
	}

	public void setUsrStatreg(Integer usrStatreg) {
		this.usrStatreg = usrStatreg;
	}

	public Integer getUsrTabstatreg() {
		return this.usrTabstatreg;
	}

	public void setUsrTabstatreg(Integer usrTabstatreg) {
		this.usrTabstatreg = usrTabstatreg;
	}

	public Integer getUsrTabtipousr() {
		return this.usrTabtipousr;
	}

	public void setUsrTabtipousr(Integer usrTabtipousr) {
		this.usrTabtipousr = usrTabtipousr;
	}

	public Integer getUsrTipousr() {
		return this.usrTipousr;
	}

	public void setUsrTipousr(Integer usrTipousr) {
		this.usrTipousr = usrTipousr;
	}

	public String getUsrArecod() {
		return usrArecod;
	}

	public void setUsrArecod(String usrArecod) {
		this.usrArecod = usrArecod;
	}

	public Participante getParticipante() {
		return participante;
	}

	public void setParticipante(Participante participante) {
		this.participante = participante;
	}

	public List<String> getRecursos() {
		return recursos;
	}

	public void setRecursos(List<String> recursos) {
		this.recursos = recursos;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

}
