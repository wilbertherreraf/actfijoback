package gob.bcb.lavado.search;

public class MatchError {

    /** The query running when the exception happened */
    public final String queryId;

    /** The exception */
    public final Exception error;

    /**
     * Create a new MatchError
     * @param queryId the query id
     * @param error the error
     */
    public MatchError(String queryId, Exception error) {
        this.queryId = queryId;
        this.error = error;
    }

    @Override
    public String toString() {
        return queryId + ":" + error.getMessage();
    }
}
