package gob.bcb.lavado.QL.contbcb;

import java.util.Date;
import java.util.List;

import gob.bcb.lavado.pojos.UnidadOrgCoin;
public interface CoinQLBean {

	List<UnidadOrgCoin> unidadesOrg();

	boolean isHabil(Date fecha);



}
