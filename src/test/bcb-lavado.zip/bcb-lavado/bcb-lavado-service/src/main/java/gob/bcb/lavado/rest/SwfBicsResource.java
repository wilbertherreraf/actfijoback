package gob.bcb.lavado.rest;

import java.net.URISyntaxException;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.repository.SwfBicsDao;
import gob.bcb.lavado.rest.util.HeaderUtil;
import gob.bcb.lavado.services.SwiftBcbSearcherService;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping(Constants.PATH_RESOURCE_API_BIC)
//@Api(tags = { "Bics" })
public class SwfBicsResource {
	private final Logger log = LoggerFactory.getLogger(SwfBicsResource.class);

	@Autowired
	private SwfBicsDao swfBicsDao;
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;

	@RequestMapping(value = "/{codbic}/{codbranch}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Servicio de actualización de un registro", response = SwfBics.class)
	// @Timed
	public ResponseEntity<SwfBics> updateSwfBics(@PathVariable(value = "codbic") String codbic, @PathVariable(value = "codbranch") String codbranch,
			@Valid @RequestBody SwfBics swfBics) throws URISyntaxException {
		log.info("REST request to update updateSwfBics : {}", swfBics);
		if (swfBics.getId() == null) {
			return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("swfBics", "idexists", "No se puede modificar con id nulo")).body(null);
		}
		SwfBics result = swfBicsDao.actualizar(swfBics);
		return ResponseEntity.ok().headers(HeaderUtil.createEntityUpdateAlert("swfBics", swfBics.getId().getBicCodbic() + " " + swfBics.getId().getBicCodbranch())).body(result);
	}

	@RequestMapping(value = "/{codbic}/{codbranch}", method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	//@ApiOperation(value = "Elimina un registro swfBics", notes = "Deletes one swfBics")
	public void delete(@PathVariable(value = "codbic") String codbic, @PathVariable(value = "codbranch") String codbranch) {
		log.info("REST request to delete : {}{}", codbic, codbranch);
		swfBicsDao.eliminar(codbic, codbranch);
	}

	@RequestMapping(value = "/{codbic}/{codbranch}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Retorna un registro swfBics", notes = "REturn one swfBics")
	public ResponseEntity<SwfBics> getSwfBic(@PathVariable(value = "codbic") String codbic,
			@PathVariable(value = "codbranch") String codbranch) {
		log.info("REST GET request to : {}{}", codbic, codbranch);

		SwfBics swfBics = swfBicsDao.findByBicBranch(codbic, codbranch);
		if (swfBics == null) {
			return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("swfBics", "idexists", "No existe")).body(null);
		}
		log.info("found: for searchScanSwifts query : {}{}", codbic, codbranch);
		return ResponseEntity.ok().headers(HeaderUtil.createEntityUpdateAlert("swfBics", swfBics.getId().getBicCodbic() + " " + swfBics.getId().getBicCodbranch())).body(swfBics);
	}

	@RequestMapping(value = "/search/bics", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, params = { "query" })
	//@ApiOperation(value = "Busqueda de registros de bics", notes = "REturn list of swfBics")
	public ResponseEntity<List<SwfBics>> searchScanSwifts(@RequestParam(value = "query") String query) {
		log.info("searchScanSwif BICS query {} ", query);

		List<SwfBics> searchResponse = (List<SwfBics>) swiftBcbSearcherService.searchForQueryInSwfBics(query, Constants.BICS_CODESTRATEGIA_DEFAULT);

		log.info("found: " + searchResponse.size() + " recs for searchScanSwifts query {} ", query);
		return new ResponseEntity<>(searchResponse, HttpStatus.OK);
	}

}
