package gob.bcb.lavado.config;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import gob.bcb.lavado.QL.rrhh.PlafinQLBean;
import gob.bcb.lavado.commons.Constants;

@Configuration
@ComponentScan(basePackageClasses={PlafinQLBean.class})
@ConfigurationProperties(prefix = Constants.PROP_PREFIX_RRHH)
public class DomainAndPersistenceSap extends HikariConfig {
	private static final Logger log = LoggerFactory.getLogger(DomainAndPersistenceSap.class);
	
	public JpaVendorAdapter jpaVendorAdapter() {
		log.info("sap2000DS config jpaVendorAdapter sap2000DS");
		HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
		hibernateJpaVendorAdapter.setShowSql(false);
		hibernateJpaVendorAdapter.setDatabase(Database.INFORMIX);
		hibernateJpaVendorAdapter.setDatabasePlatform("org.hibernate.dialect.InformixDialect");
		return hibernateJpaVendorAdapter;
	}

//	@Bean(name = "dataSourceSap",destroyMethod = "close")
//	public DataSource dataSourceSap() throws IllegalArgumentException, NamingException {
//		log.info("dataSourceSap " + getDataSourceJNDI());
//		
//        JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
//        bean.setJndiName(getDataSourceJNDI());
//        bean.setProxyInterface(DataSource.class);
//        bean.setLookupOnStartup(false);
//        bean.afterPropertiesSet();
//        
//		HikariDataSource ds = new HikariDataSource();
//		ds.setDataSource((DataSource) bean.getObject());
//		ds.addDataSourceProperty("cachePrepStmts", "true");
//		ds.addDataSourceProperty("useServerPrepStmts", "true");
//		ds.setAutoCommit(false);
//		ds.setPoolName(Constants.PUNIT_RRHH);
//
//		return ds;
//	}	
	
	@Bean(name = "dataSourceSap")
	public DataSource dataSourceSap()  throws NamingException {
		log.info("dataSourceSap ");
        JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
        bean.setJndiName(getDataSourceJNDI());
        bean.setProxyInterface(DataSource.class);
        bean.setLookupOnStartup(false);
        bean.afterPropertiesSet();
        return (DataSource) bean.getObject();
	}	
	
	@Bean(name = "entityManagerFactorySap")
	public LocalContainerEntityManagerFactoryBean entityManagerFactorySap(@Qualifier("dataSourceSap") DataSource dataSourceSap) {
		log.info("Sap:::: entityManagerFactorysap " + (dataSourceSap == null));
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource( dataSourceSap);
        em.setPackagesToScan(PlafinQLBean.class.getPackage().getName());
        em.setJpaVendorAdapter(jpaVendorAdapter());
        em.setPersistenceUnitName(Constants.PUNIT_RRHH);
        
		em.afterPropertiesSet();
		
        return em;		
	}	

}
