package gob.bcb.lavado.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.web.cors.CorsConfiguration;

import gob.bcb.lavado.commons.Constants;

@ConfigurationProperties(prefix = AppProperties.PREFIX, ignoreUnknownFields = false)
public class AppProperties {
	public static final String PREFIX = "myapp";
	private String requestURL;
	private String idApplication;
	private final Async async = new Async();
	private final Http http = new Http();
	private final Cache cache = new Cache();
	private final Mail mail = new Mail();
	private final Security security = new Security();
	private final Swagger swagger = new Swagger();
	private final Metrics metrics = new Metrics();
	private final CorsConfiguration cors = new CorsConfiguration();
	private final Ribbon ribbon = new Ribbon();
	private final Lavado lavado = new Lavado();
	
	public AppProperties() {
		System.out.println("creando AppProperties...");
	}

	public Async getAsync() {
		return async;
	}

	public Http getHttp() {
		return http;
	}

	public Cache getCache() {
		return cache;
	}

	public Mail getMail() {
		return mail;
	}

	public Security getSecurity() {
		return security;
	}

	public Swagger getSwagger() {
		return swagger;
	}

	public Metrics getMetrics() {
		return metrics;
	}

	public CorsConfiguration getCors() {
		return cors;
	}

	public Ribbon getRibbon() {
		return ribbon;
	}

	public Lavado getLavado() {
		return lavado;
	}
	
	public static class Async {
		private int corePoolSize = 2;
		private int maxPoolSize = 50;
		private int queueCapacity = 10000;

		public int getCorePoolSize() {
			return corePoolSize;
		}

		public void setCorePoolSize(int corePoolSize) {
			this.corePoolSize = corePoolSize;
		}

		public int getMaxPoolSize() {
			return maxPoolSize;
		}

		public void setMaxPoolSize(int maxPoolSize) {
			this.maxPoolSize = maxPoolSize;
		}

		public int getQueueCapacity() {
			return queueCapacity;
		}

		public void setQueueCapacity(int queueCapacity) {
			this.queueCapacity = queueCapacity;
		}
	}

	public static class Http {
		private final Cache cache = new Cache();

		public Cache getCache() {
			return cache;
		}

		public static class Cache {
			private int timeToLiveInDays = 1461;

			public int getTimeToLiveInDays() {
				return timeToLiveInDays;
			}

			public void setTimeToLiveInDays(int timeToLiveInDays) {
				this.timeToLiveInDays = timeToLiveInDays;
			}
		}
	}

	public static class Cache {
		private int timeToLiveSeconds = 3600;

		public int getTimeToLiveSeconds() {
			return timeToLiveSeconds;
		}

		public void setTimeToLiveSeconds(int timeToLiveSeconds) {
			this.timeToLiveSeconds = timeToLiveSeconds;
		}
	}

	public static class Mail {
		private String from = "myapp@localhost";
		private String fromAlert;
		private String toAlert;
		public String getFrom() {
			return from;
		}

		public void setFrom(String from) {
			this.from = from;
		}

		public String getFromAlert() {
			return fromAlert;
		}

		public void setFromAlert(String fromAlert) {
			this.fromAlert = fromAlert;
		}

		public String getToAlert() {
			return toAlert;
		}

		public void setToAlert(String toAlert) {
			this.toAlert = toAlert;
		}
	}

	public static class Security {
		private final Authentication authentication = new Authentication();
		private final Encryptor encryptor = new Encryptor();

		public Authentication getAuthentication() {
			return authentication;
		}

		public Encryptor getEncryptor() {
			return encryptor;
		}

		public static class Encryptor {
			private String pathFileConfig;
			private String encryptSalt;
			private String encryptPassword;
			private String encryptPasswordNew;
			private String encryptVersion = "0";

			public String getEncryptSalt() {
				return encryptSalt;
			}

			public void setEncryptSalt(String encryptSalt) {
				this.encryptSalt = encryptSalt;
			}

			public String getEncryptPassword() {
				return encryptPassword;
			}

			public void setEncryptPassword(String encryptPassword) {
				this.encryptPassword = encryptPassword;
			}

			public String getEncryptVersion() {
				return encryptVersion;
			}

			public void setEncryptVersion(String encryptVersion) {
				this.encryptVersion = encryptVersion;
			}

			public String getEncryptPasswordNew() {
				return encryptPasswordNew;
			}

			public void setEncryptPasswordNew(String encryptPasswordNew) {
				this.encryptPasswordNew = encryptPasswordNew;
			}

			public String getPathFileConfig() {
				return pathFileConfig;
			}

			public void setPathFileConfig(String pathFileConfig) {
				this.pathFileConfig = pathFileConfig;
			}

		}

		public static class Authentication {
			private final Jwt jwt = new Jwt();
			private final Saml saml = new Saml();

			public Jwt getJwt() {
				return jwt;
			}

			public Saml getSaml() {
				return saml;
			}

			public static class Jwt {
				private String secret;
				private long tokenValidityInSeconds = 1800;
				private long tokenValidityInSecondsForRememberMe = 2592000;

				public String getSecret() {
					return secret;
				}

				public void setSecret(String secret) {
					this.secret = secret;
				}

				public long getTokenValidityInSeconds() {
					return tokenValidityInSeconds;
				}

				public void setTokenValidityInSeconds(long tokenValidityInSeconds) {
					this.tokenValidityInSeconds = tokenValidityInSeconds;
				}

				public long getTokenValidityInSecondsForRememberMe() {
					return tokenValidityInSecondsForRememberMe;
				}

				public void setTokenValidityInSecondsForRememberMe(long tokenValidityInSecondsForRememberMe) {
					this.tokenValidityInSecondsForRememberMe = tokenValidityInSecondsForRememberMe;
				}
			}

			public static class Saml {
				private final Keymanager keymanager = new Keymanager();
				// http://swfapp.bcb.com:8881/swfadmapp
				private String entityid;
				// http://sso.bcb.com:8808/openam
				private String idpUrl;
				// idpSSOCircleMetadataURL =
				// "http://sso.bcb.com:8808/openam/saml2/jsp/exportmetadata.jsp";
				private String idpSSOCircleMetadataURL;

				public String getEntityid() {
					return entityid;
				}

				public void setEntityid(String entityid) {
					this.entityid = entityid;
				}

				public String getIdpSSOCircleMetadataURL() {
					return idpSSOCircleMetadataURL;
				}

				public void setIdpSSOCircleMetadataURL(String idpSSOCircleMetadataURL) {
					this.idpSSOCircleMetadataURL = idpSSOCircleMetadataURL;
				}

				public Keymanager getKeymanager() {
					return keymanager;
				}

				public String getIdpUrl() {
					return idpUrl;
				}

				public void setIdpUrl(String idpUrl) {
					this.idpUrl = idpUrl;
				}

				public static class Keymanager {
					private String keystore;
					private String storepass;
					private String defaultkey;

					public String getKeystore() {
						return keystore;
					}

					public void setKeystore(String keystore) {
						this.keystore = keystore;
					}

					public String getStorepass() {
						return storepass;
					}

					public void setStorepass(String storepass) {
						this.storepass = storepass;
					}

					public String getDefaultkey() {
						return defaultkey;
					}

					public void setDefaultkey(String defaultkey) {
						this.defaultkey = defaultkey;
					}
				}
			}

		}
	}

	public static class Swagger {

		private String title = "myapp API";

		private String description = "myapp API documentation";

		private String version = "0.0.1";

		private String termsOfServiceUrl;

		private String contactName;

		private String contactUrl;

		private String contactEmail;

		private String license;

		private String licenseUrl;

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getVersion() {
			return version;
		}

		public void setVersion(String version) {
			this.version = version;
		}

		public String getTermsOfServiceUrl() {
			return termsOfServiceUrl;
		}

		public void setTermsOfServiceUrl(String termsOfServiceUrl) {
			this.termsOfServiceUrl = termsOfServiceUrl;
		}

		public String getContactName() {
			return contactName;
		}

		public void setContactName(String contactName) {
			this.contactName = contactName;
		}

		public String getContactUrl() {
			return contactUrl;
		}

		public void setContactUrl(String contactUrl) {
			this.contactUrl = contactUrl;
		}

		public String getContactEmail() {
			return contactEmail;
		}

		public void setContactEmail(String contactEmail) {
			this.contactEmail = contactEmail;
		}

		public String getLicense() {
			return license;
		}

		public void setLicense(String license) {
			this.license = license;
		}

		public String getLicenseUrl() {
			return licenseUrl;
		}

		public void setLicenseUrl(String licenseUrl) {
			this.licenseUrl = licenseUrl;
		}
	}

	public static class Metrics {

		private final Jmx jmx = new Jmx();

		private final Spark spark = new Spark();

		private final Graphite graphite = new Graphite();

		private final Logs logs = new Logs();

		public Jmx getJmx() {
			return jmx;
		}

		public Spark getSpark() {
			return spark;
		}

		public Graphite getGraphite() {
			return graphite;
		}

		public Logs getLogs() {
			return logs;
		}

		public static class Jmx {

			private boolean enabled = true;

			public boolean isEnabled() {
				return enabled;
			}

			public void setEnabled(boolean enabled) {
				this.enabled = enabled;
			}
		}

		public static class Spark {

			private boolean enabled = false;

			private String host = "localhost";

			private int port = 9999;

			public boolean isEnabled() {
				return enabled;
			}

			public void setEnabled(boolean enabled) {
				this.enabled = enabled;
			}

			public String getHost() {
				return host;
			}

			public void setHost(String host) {
				this.host = host;
			}

			public int getPort() {
				return port;
			}

			public void setPort(int port) {
				this.port = port;
			}
		}

		public static class Graphite {

			private boolean enabled = false;

			private String host = "localhost";

			private int port = 2003;

			private String prefix = "myapp";

			public boolean isEnabled() {
				return enabled;
			}

			public void setEnabled(boolean enabled) {
				this.enabled = enabled;
			}

			public String getHost() {
				return host;
			}

			public void setHost(String host) {
				this.host = host;
			}

			public int getPort() {
				return port;
			}

			public void setPort(int port) {
				this.port = port;
			}

			public String getPrefix() {
				return prefix;
			}

			public void setPrefix(String prefix) {
				this.prefix = prefix;
			}
		}

		public static class Logs {

			private boolean enabled = false;

			private long reportFrequency = 60;

			public long getReportFrequency() {
				return reportFrequency;
			}

			public void setReportFrequency(int reportFrequency) {
				this.reportFrequency = reportFrequency;
			}

			public boolean isEnabled() {
				return enabled;
			}

			public void setEnabled(boolean enabled) {
				this.enabled = enabled;
			}
		}
	}

	private final Logging logging = new Logging();

	public Logging getLogging() {
		return logging;
	}

	public String getRequestURL() {
		return requestURL;
	}

	public void setRequestURL(String requestURL) {
		this.requestURL = requestURL;
	}

	public String getIdApplication() {
		return idApplication;
	}

	public void setIdApplication(String idApplication) {
		this.idApplication = idApplication;
	}

	public static class Logging {

		private final Logstash logstash = new Logstash();

		public Logstash getLogstash() {
			return logstash;
		}

		public static class Logstash {

			private boolean enabled = false;

			private String host = "localhost";

			private int port = 5000;

			private int queueSize = 512;

			public boolean isEnabled() {
				return enabled;
			}

			public void setEnabled(boolean enabled) {
				this.enabled = enabled;
			}

			public String getHost() {
				return host;
			}

			public void setHost(String host) {
				this.host = host;
			}

			public int getPort() {
				return port;
			}

			public void setPort(int port) {
				this.port = port;
			}

			public int getQueueSize() {
				return queueSize;
			}

			public void setQueueSize(int queueSize) {
				this.queueSize = queueSize;
			}
		}

		private final SpectatorMetrics spectatorMetrics = new SpectatorMetrics();

		public SpectatorMetrics getSpectatorMetrics() {
			return spectatorMetrics;
		}

		public static class SpectatorMetrics {

			private boolean enabled = false;

			public boolean isEnabled() {
				return enabled;
			}

			public void setEnabled(boolean enabled) {
				this.enabled = enabled;
			}
		}
	}

	public static class Ribbon {

		private String[] displayOnActiveProfiles;

		public String[] getDisplayOnActiveProfiles() {
			return displayOnActiveProfiles;
		}

		public void setDisplayOnActiveProfiles(String[] displayOnActiveProfiles) {
			this.displayOnActiveProfiles = displayOnActiveProfiles;
		}
	}

	public static class Lavado {
		private String appdir = Constants.BASE_DIR_APP;
		private final Search search = new Search();

		public Search getSearch() {
			return search;
		}

		public String getAppdir() {
			return appdir;
		}

		public void setAppdir(String appdir) {
			this.appdir = appdir;
		}

		public static class Search {
			private String indexdir = Constants.BASE_DIR_APP + "indexes/";
			private String idEstrategiaplano = "REGISTRADOS";

			public String getIndexdir() {
				return indexdir;
			}

			public void setIndexdir(String indexdir) {
				this.indexdir = indexdir;
			}

			public String getIdEstrategiaplano() {
				return idEstrategiaplano;
			}

			public void setIdEstrategiaplano(String idEstrategiaplano) {
				this.idEstrategiaplano = idEstrategiaplano;
			}

		}
	}
}
