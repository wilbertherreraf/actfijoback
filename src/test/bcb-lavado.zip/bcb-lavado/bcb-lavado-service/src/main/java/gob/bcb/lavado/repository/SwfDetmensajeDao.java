package gob.bcb.lavado.repository;

import java.util.List;

import gob.bcb.lavado.model.SwfDetmensaje;

public interface SwfDetmensajeDao {

	SwfDetmensaje findByCodigo(Integer demCodmen, String demCodmt, String demCodcampo);

	List<SwfDetmensaje> findByCodMen(Integer demCodmen);

	SwfDetmensaje saveOrUpdate(SwfDetmensaje swfDetmensaje);

	SwfDetmensaje findByCodigo(Integer demCodmen, Integer demNrocorr);

}
