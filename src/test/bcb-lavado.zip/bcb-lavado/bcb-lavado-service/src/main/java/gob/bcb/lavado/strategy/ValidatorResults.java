package gob.bcb.lavado.strategy;

import java.util.Collection;
import java.util.Set;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;

import gob.bcb.lavado.search.DocumentMatches;
import gob.bcb.lavado.search.Matches;
import gob.bcb.lavado.search.QueryMatch;

public class ValidatorResults<T extends QueryMatch>  {
    private int correctMatches;
    private int total;
    private int missingMatchesR;
    private int extraMatchesR;
    private Multimap<String, T> missingMatches = HashMultimap.create();
    private Multimap<String, T> extraMatches = HashMultimap.create();

    public void add(Matches<T> matches, String docId, Set<T> expectedMatches) {
        total++;
        DocumentMatches<T> docMatches = matches.getMatches(docId);
        if (docMatches == null) {
            missingMatches.putAll(docId, expectedMatches);
            return;
        }

        Set<T> actualMatches = Sets.newHashSet(docMatches);
        Sets.SetView<T> extras = Sets.difference(expectedMatches, actualMatches);
        Sets.SetView<T> missing = Sets.difference(actualMatches, expectedMatches);

        if (extras.isEmpty() && missing.isEmpty())
            correctMatches++;
        else {
            missingMatches.putAll(docMatches.getDocId(), missing);
            extraMatches.putAll(docMatches.getDocId(), extras);
        }
    }
    
    public void add(Matches<T> matches, String docId, int expectedMatches) {
        total++;
        DocumentMatches<T> docMatches = matches.getMatches(docId);
        if (docMatches == null) {
            missingMatchesR = expectedMatches;
            return;
        }

        int actualMatches = docMatches.getMatches().size();
        int extras = expectedMatches - actualMatches;
        int missing = actualMatches - expectedMatches;

        if (extras == 0 && missing == 0)
            correctMatches++;
        else {
            missingMatchesR = missing;
            extraMatchesR = extras;
        }
    }

    public int getCorrectMatchCount() {
        return correctMatches;
    }

    public int getTotalMatchCount() {
        return total;
    }

    public Collection<String> getBadDocuments() {
        return Sets.union(missingMatches.keySet(), extraMatches.keySet());
    }

    public Collection<T> getMissingMatches(String docId) {
        return missingMatches.get(docId);
    }

    public Collection<T> getExtraMatches(String docId) {
        return extraMatches.get(docId);
    }
    
    public boolean continueSearch(){
    	return (correctMatches > 0 && extraMatchesR > 0);
    }
}
