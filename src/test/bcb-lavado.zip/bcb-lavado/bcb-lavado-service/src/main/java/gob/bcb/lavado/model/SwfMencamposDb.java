package gob.bcb.lavado.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the swf_mencampos database table.
 * 
 */
@Entity
@Table(name = "swf_mencampos")
public class SwfMencamposDb implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "mtf_id")
	private Integer mtfId;
    
    @Column(name = "mtf_codcampo")
	private String mtfCodcampo;
    @Column(name = "mtf_codmt")
	private String mtfCodmt;
    @Column(name = "mtf_nro")
	private Integer mtfNro;
    @Column(name = "mtf_grpopt")
	private Integer mtfGrpopt;
	
	@Column(name = "mtf_nemo")
	private String mtfNemo;

	@Column(name = "mtf_descrip")
	private String mtfDescrip;

	@Column(name = "mtf_reglavalid")
	private String mtfReglavalid;

	@Column(name = "mtf_status")
	private String mtfStatus;

	@Column(name = "mtf_tipocampo")
	private String mtfTipocampo;

	@Column(name = "mtf_condicion")
	private String mtfCondicion;

	@Column(name = "mtf_expresion")
	private String mtfExpresion;

	@Column(name = "mtf_secpadre")
	private String mtfSecpadre;

	@Column(name = "mtf_bloque")
	private String mtfBloque;

	@Column(name = "mtf_formato")
	private String mtfFormato;

	@Column(name = "mtf_reglaswf")
	private String mtfReglaswf;

	@Column(name = "mtf_datoadic")
	private String mtfDatoadic;

	@Column(name = "mtf_default")
	private String mtfDefault;

	@Column(name = "mtf_estado")
	private String mtfEstado;

	@Column(name = "mtf_indexiso")
	private String mtfIndexiso;
	@Column(name = "mtf_nivel")
	private Integer mtfNivel;
	@Column(name = "mtf_xmltag")
	private String mtfXmltag;
	@Column(name = "mtf_cardinal")
	private String mtfCardinal;	
	@Column(name = "mtf_cambiavalor")
	private String mtfCambiavalor;
	@Column(name = "mtf_minimo")
	private String mtfMinimo;
	@Column(name = "mtf_validacionerror")
	private String mtfValidacionerror;
	@Column(name = "mtf_cambiatipousr")
	private String mtfCambiatipousr;
	@Column(name = "mtf_cardinalmult")
	private String mtfCardinalmult;
	@Column(name = "mtf_sinonimos")
	private String mtfSinonimos;
	@Column(name = "mtf_convalornoreq")
	private String mtfConvalornoreq;
	@Column(name = "mtf_esopcional")
	private String mtfEsopcional;
	@Column(name = "mtf_esadicional")
	private String mtfEsadicional;
	@Column(name = "mtf_subaction")
	private String mtfSubaction;	
	@Column(name = "mtf_subaction2")
	private String mtfSubaction2;
	@Column(name = "mtf_subaction3")
	private String mtfSubaction3;
	@Column(name = "mtf_subaction4")
	private String mtfSubaction4;
	@Column(name = "mtf_subaction5")
	private String mtfSubaction5;

	@Column(name = "mtf_auditusr")
	private String mtfAuditusr;

	@Column(name = "mtf_auditfho")
	@Temporal(TemporalType.TIMESTAMP)
	private Date mtfAuditfho;

	@Column(name = "mtf_auditwst")
	private String mtfAuditwst;

	public SwfMencamposDb() {
	}

	public Integer getMtfId() {
		return mtfId;
	}

	public void setMtfId(Integer mtfId) {
		this.mtfId = mtfId;
	}

	public String getMtfCodcampo() {
		return this.mtfCodcampo;
	}
	public void setMtfCodcampo(String mtfCodcampo) {
		this.mtfCodcampo = mtfCodcampo;
	}
	public String getMtfCodmt() {
		return this.mtfCodmt;
	}
	public void setMtfCodmt(String mtfCodmt) {
		this.mtfCodmt = mtfCodmt;
	}
	public Integer getMtfNro() {
		return this.mtfNro;
	}
	public void setMtfNro(Integer mtfNro) {
		this.mtfNro = mtfNro;
	}
	
	public Integer getMtfGrpopt() {
		return mtfGrpopt;
	}
	public void setMtfGrpopt(Integer mtfGrpopt) {
		this.mtfGrpopt = mtfGrpopt;
	}
	
	public String getMtfDescrip() {
		return this.mtfDescrip;
	}

	public void setMtfDescrip(String mtfDescrip) {
		this.mtfDescrip = mtfDescrip;
	}

	public String getMtfReglavalid() {
		return this.mtfReglavalid;
	}

	public void setMtfReglavalid(String mtfReglavalid) {
		this.mtfReglavalid = mtfReglavalid;
	}

	public String getMtfStatus() {
		return this.mtfStatus;
	}

	public void setMtfStatus(String mtfStatus) {
		this.mtfStatus = mtfStatus;
	}

	public String getMtfTipocampo() {
		return mtfTipocampo;
	}

	public void setMtfTipocampo(String mtfTipocampo) {
		this.mtfTipocampo = mtfTipocampo;
	}

	public String getMtfCondicion() {
		return mtfCondicion;
	}

	public void setMtfCondicion(String mtfCondicion) {
		this.mtfCondicion = mtfCondicion;
	}

	public String getMtfExpresion() {
		return mtfExpresion;
	}

	public void setMtfExpresion(String mtfExpresion) {
		this.mtfExpresion = mtfExpresion;
	}

	public String getMtfSecpadre() {
		return mtfSecpadre;
	}

	public void setMtfSecpadre(String mtfSecpadre) {
		this.mtfSecpadre = mtfSecpadre;
	}

	public String getMtfBloque() {
		return mtfBloque;
	}

	public void setMtfBloque(String mtfBloque) {
		this.mtfBloque = mtfBloque;
	}

	public String getMtfFormato() {
		return mtfFormato;
	}

	public void setMtfFormato(String mtfFormato) {
		this.mtfFormato = mtfFormato;
	}

	public String getMtfReglaswf() {
		return mtfReglaswf;
	}

	public void setMtfReglaswf(String mtfReglaswf) {
		this.mtfReglaswf = mtfReglaswf;
	}

	public String getMtfDatoadic() {
		return mtfDatoadic;
	}

	public void setMtfDatoadic(String mtfDatoadic) {
		this.mtfDatoadic = mtfDatoadic;
	}

	public String getMtfDefault() {
		return mtfDefault;
	}

	public void setMtfDefault(String mtfDefault) {
		this.mtfDefault = mtfDefault;
	}

//	public String getMtfAuditusr() {
//		return mtfAuditusr;
//	}
//
//	public void setMtfAuditusr(String mtfAuditusr) {
//		this.mtfAuditusr = mtfAuditusr;
//	}
//
//	public String getMtfAuditwst() {
//		return mtfAuditwst;
//	}
//
//	public void setMtfAuditwst(String mtfAuditwst) {
//		this.mtfAuditwst = mtfAuditwst;
//	}
//
//	public Date getMtfAuditfho() {
//		return mtfAuditfho;
//	}
//
//	public void setMtfAuditfho(Date mtfAuditfho) {
//		this.mtfAuditfho = mtfAuditfho;
//	}

	public String getMtfNemo() {
		return mtfNemo;
	}

	public void setMtfNemo(String mtfNemo) {
		this.mtfNemo = mtfNemo;
	}

	public String getMtfEstado() {
		return mtfEstado;
	}

	public void setMtfEstado(String mtfEstado) {
		this.mtfEstado = mtfEstado;
	}

	
	public String getMtfIndexiso() {
		return mtfIndexiso;
	}

	public void setMtfIndexiso(String mtfIndexiso) {
		this.mtfIndexiso = mtfIndexiso;
	}

	public Integer getMtfNivel() {
		return mtfNivel;
	}

	public void setMtfNivel(Integer mtfNivel) {
		this.mtfNivel = mtfNivel;
	}

	public String getMtfXmltag() {
		return mtfXmltag;
	}

	public void setMtfXmltag(String mtfXmltag) {
		this.mtfXmltag = mtfXmltag;
	}

	public String getMtfCardinal() {
		return mtfCardinal;
	}

	public void setMtfCardinal(String mtfCardinal) {
		this.mtfCardinal = mtfCardinal;
	}

	public String getMtfCambiavalor() {
		return mtfCambiavalor;
	}

	public void setMtfCambiavalor(String mtfCambiavalor) {
		this.mtfCambiavalor = mtfCambiavalor;
	}

	public String getMtfMinimo() {
		return mtfMinimo;
	}

	public void setMtfMinimo(String mtfMinimo) {
		this.mtfMinimo = mtfMinimo;
	}

	public String getMtfValidacionerror() {
		return mtfValidacionerror;
	}

	public void setMtfValidacionerror(String mtfValidacionerror) {
		this.mtfValidacionerror = mtfValidacionerror;
	}

	public String getMtfCambiatipousr() {
		return mtfCambiatipousr;
	}

	public void setMtfCambiatipousr(String mtfCambiatipousr) {
		this.mtfCambiatipousr = mtfCambiatipousr;
	}

	public String getMtfCardinalmult() {
		return mtfCardinalmult;
	}

	public void setMtfCardinalmult(String mtfCardinalmult) {
		this.mtfCardinalmult = mtfCardinalmult;
	}

	public String getMtfSinonimos() {
		return mtfSinonimos;
	}

	public void setMtfSinonimos(String mtfSinonimos) {
		this.mtfSinonimos = mtfSinonimos;
	}

	public String getMtfConvalornoreq() {
		return mtfConvalornoreq;
	}

	public void setMtfConvalornoreq(String mtfConvalornoreq) {
		this.mtfConvalornoreq = mtfConvalornoreq;
	}

	public String getMtfEsopcional() {
		return mtfEsopcional;
	}

	public void setMtfEsopcional(String mtfEsopcional) {
		this.mtfEsopcional = mtfEsopcional;
	}

	public String getMtfEsadicional() {
		return mtfEsadicional;
	}

	public void setMtfEsadicional(String mtfEsadicional) {
		this.mtfEsadicional = mtfEsadicional;
	}

	public String getMtfSubaction() {
		return mtfSubaction;
	}

	public void setMtfSubaction(String mtfSubaction) {
		this.mtfSubaction = mtfSubaction;
	}

	public String getMtfSubaction2() {
		return mtfSubaction2;
	}

	public void setMtfSubaction2(String mtfSubaction2) {
		this.mtfSubaction2 = mtfSubaction2;
	}

	public String getMtfSubaction3() {
		return mtfSubaction3;
	}

	public void setMtfSubaction3(String mtfSubaction3) {
		this.mtfSubaction3 = mtfSubaction3;
	}

	public String getMtfSubaction4() {
		return mtfSubaction4;
	}

	public void setMtfSubaction4(String mtfSubaction4) {
		this.mtfSubaction4 = mtfSubaction4;
	}

	public String getMtfSubaction5() {
		return mtfSubaction5;
	}

	public void setMtfSubaction5(String mtfSubaction5) {
		this.mtfSubaction5 = mtfSubaction5;
	}

	public Date getMtfAuditfho() {
		return mtfAuditfho;
	}

	public void setMtfAuditfho(Date mtfAuditfho) {
		this.mtfAuditfho = mtfAuditfho;
	}

	public String getMtfAuditwst() {
		return mtfAuditwst;
	}

	public void setMtfAuditwst(String mtfAuditwst) {
		this.mtfAuditwst = mtfAuditwst;
	}

	public String getMtfAuditusr() {
		return mtfAuditusr;
	}

	public void setMtfAuditusr(String mtfAuditusr) {
		this.mtfAuditusr = mtfAuditusr;
	}	
	
	// public SwfTipomensaje getSwfTipomensaje() {
	// return this.swfTipomensaje;
	// }
	//
	// public void setSwfTipomensaje(SwfTipomensaje swfTipomensaje) {
	// this.swfTipomensaje = swfTipomensaje;
	// }

	
}