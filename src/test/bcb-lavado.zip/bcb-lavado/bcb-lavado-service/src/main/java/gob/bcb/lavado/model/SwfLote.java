package gob.bcb.lavado.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the swf_lote database table.
 * 
 */
@Entity
@Table(name="swf_lote")
public class SwfLote implements Serializable, gob.bcb.lavado.model.DomainObject {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="lot_nrolote")
	private Integer lotNrolote;

	@Column(name="lot_fechora")
	private Date lotFechora;

	@Column(name="lot_nomorig")
	private String lotNomorig;

	@Column(name="lot_pathfile")
	private String lotPathfile;

	@Column(name="lot_hash")
	private String lotHash;

	@Column(name = "lot_tipolote")
	private String lotTipolote;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "lot_auditfho")
	private Date lotAuditfho;

	@Column(name = "lot_auditusr")
	private String lotAuditusr;

	@Column(name = "lot_auditwst")
	private String lotAuditwst;
	
	public SwfLote() {
	}

	public Integer getLotNrolote() {
		return this.lotNrolote;
	}

	public void setLotNrolote(Integer lotNrolote) {
		this.lotNrolote = lotNrolote;
	}

	public Date getLotFechora() {
		return this.lotFechora;
	}

	public void setLotFechora(Date lotFechora) {
		this.lotFechora = lotFechora;
	}

	public String getLotNomorig() {
		return this.lotNomorig;
	}

	public void setLotNomorig(String lotNomorig) {
		this.lotNomorig = lotNomorig;
	}

	public String getLotPathfile() {
		return this.lotPathfile;
	}

	public void setLotPathfile(String lotPathfile) {
		this.lotPathfile = lotPathfile;
	}

	public String getLotHash() {
		return lotHash;
	}

	public void setLotHash(String lotHash) {
		this.lotHash = lotHash;
	}

	public Date getLotAuditfho() {
		return lotAuditfho;
	}

	public void setLotAuditfho(Date lotAuditfho) {
		this.lotAuditfho = lotAuditfho;
	}

	public String getLotAuditusr() {
		return lotAuditusr;
	}

	public void setLotAuditusr(String lotAuditusr) {
		this.lotAuditusr = lotAuditusr;
	}

	public String getLotAuditwst() {
		return lotAuditwst;
	}

	public void setLotAuditwst(String lotAuditwst) {
		this.lotAuditwst = lotAuditwst;
	}

	public String getLotTipolote() {
		return lotTipolote;
	}

	public void setLotTipolote(String lotTipolote) {
		this.lotTipolote = lotTipolote;
	}

}