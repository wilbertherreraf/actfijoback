//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.05.19 a las 01:11:31 AM BOT 
//


package gob.bcb.lavado.ofac.ue.model;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="remark" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}regulation"/&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}subjectType"/&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}nameAlias" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}citizenship"/&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}birthdate" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}identification" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}address" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="designationDetails" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="unitedNationId" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="euReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="logicalId" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "remark",
    "regulation",
    "subjectType",
    "nameAlias",
    "citizenship",
    "birthdate",
    "identification",
    "address"
})
@XmlRootElement(name = "sanctionEntity")
public class SanctionEntity {

    protected String remark;
    @XmlElement(required = true)
    protected Regulation regulation;
    @XmlElement(required = true)
    protected SubjectType subjectType;
    protected List<NameAlias> nameAlias;
    @XmlElement(required = true)
    protected Citizenship citizenship;
    protected List<Birthdate> birthdate;
    protected List<Identification> identification;
    protected List<Address> address;
    @XmlAttribute(name = "designationDetails")
    protected String designationDetails;
    @XmlAttribute(name = "unitedNationId")
    protected String unitedNationId;
    @XmlAttribute(name = "euReferenceNumber")
    protected String euReferenceNumber;
    @XmlAttribute(name = "logicalId")
    protected Integer logicalId;

    /**
     * Obtiene el valor de la propiedad remark.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemark() {
        return remark;
    }

    /**
     * Define el valor de la propiedad remark.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemark(String value) {
        this.remark = value;
    }

    /**
     * Obtiene el valor de la propiedad regulation.
     * 
     * @return
     *     possible object is
     *     {@link Regulation }
     *     
     */
    public Regulation getRegulation() {
        return regulation;
    }

    /**
     * Define el valor de la propiedad regulation.
     * 
     * @param value
     *     allowed object is
     *     {@link Regulation }
     *     
     */
    public void setRegulation(Regulation value) {
        this.regulation = value;
    }

    /**
     * Obtiene el valor de la propiedad subjectType.
     * 
     * @return
     *     possible object is
     *     {@link SubjectType }
     *     
     */
    public SubjectType getSubjectType() {
        return subjectType;
    }

    /**
     * Define el valor de la propiedad subjectType.
     * 
     * @param value
     *     allowed object is
     *     {@link SubjectType }
     *     
     */
    public void setSubjectType(SubjectType value) {
        this.subjectType = value;
    }

    /**
     * Gets the value of the nameAlias property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nameAlias property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNameAlias().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NameAlias }
     * 
     * 
     */
    public List<NameAlias> getNameAlias() {
        if (nameAlias == null) {
            nameAlias = new ArrayList<NameAlias>();
        }
        return this.nameAlias;
    }

    /**
     * Obtiene el valor de la propiedad citizenship.
     * 
     * @return
     *     possible object is
     *     {@link Citizenship }
     *     
     */
    public Citizenship getCitizenship() {
        return citizenship;
    }

    /**
     * Define el valor de la propiedad citizenship.
     * 
     * @param value
     *     allowed object is
     *     {@link Citizenship }
     *     
     */
    public void setCitizenship(Citizenship value) {
        this.citizenship = value;
    }

    /**
     * Gets the value of the birthdate property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the birthdate property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBirthdate().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Birthdate }
     * 
     * 
     */
    public List<Birthdate> getBirthdate() {
        if (birthdate == null) {
            birthdate = new ArrayList<Birthdate>();
        }
        return this.birthdate;
    }

    /**
     * Gets the value of the identification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the identification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Identification }
     * 
     * 
     */
    public List<Identification> getIdentification() {
        if (identification == null) {
            identification = new ArrayList<Identification>();
        }
        return this.identification;
    }

    /**
     * Gets the value of the address property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the address property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Address }
     * 
     * 
     */
    public List<Address> getAddress() {
        if (address == null) {
            address = new ArrayList<Address>();
        }
        return this.address;
    }

    /**
     * Obtiene el valor de la propiedad designationDetails.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesignationDetails() {
        return designationDetails;
    }

    /**
     * Define el valor de la propiedad designationDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesignationDetails(String value) {
        this.designationDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad unitedNationId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnitedNationId() {
        return unitedNationId;
    }

    /**
     * Define el valor de la propiedad unitedNationId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnitedNationId(String value) {
        this.unitedNationId = value;
    }

    /**
     * Obtiene el valor de la propiedad euReferenceNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEuReferenceNumber() {
        return euReferenceNumber;
    }

    /**
     * Define el valor de la propiedad euReferenceNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEuReferenceNumber(String value) {
        this.euReferenceNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad logicalId.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLogicalId() {
        return logicalId;
    }

    /**
     * Define el valor de la propiedad logicalId.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLogicalId(Integer value) {
        this.logicalId = value;
    }

}
