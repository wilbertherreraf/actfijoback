package gob.bcb.lavado.search.presearcher;

import java.util.Iterator;
import java.util.Map;

import gob.bcb.lavado.search.Matches;
import gob.bcb.lavado.search.QueryMatch;

public class PresearcherMatches<T extends QueryMatch> implements Iterable<PresearcherMatch<T>> {

    private final Map<String, StringBuilder> matchingTerms;
    public final Matches<T> matcher;

    public PresearcherMatches(Map<String, StringBuilder> matchingTerms, Matches<T> matcher) {
        this.matcher = matcher;
        this.matchingTerms = matchingTerms;
    }

    public PresearcherMatch<T> match(String queryId, String docId) {
        if (matchingTerms.containsKey(queryId))
            return new PresearcherMatch<>(queryId, matchingTerms.get(queryId).toString(), matcher.matches(queryId, docId));
        return null;
    }

    public int getPresearcherMatchCount() {
        return matcher.getPresearcherHits().size();
    }

    @Override
    public Iterator<PresearcherMatch<T>> iterator() {
        final Iterator<String> ids = matchingTerms.keySet().iterator();
        return new Iterator<PresearcherMatch<T>>() {
            @Override
            public boolean hasNext() {
                return ids.hasNext();
            }

            @Override
            public PresearcherMatch<T> next() {
                String id = ids.next();
                return new PresearcherMatch<>(id, matchingTerms.get(id).toString(), matcher.matches(id, ""));
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
}
