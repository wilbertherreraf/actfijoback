package gob.bcb.lavado.search.facet;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.facet.FacetQueryOfac.QueryCollector;

import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.transform.ResultTransformer;

public class ProjectionSimpleToSearchResultTransformer implements ResultTransformer {
	private static final Logger log = LoggerFactory.getLogger(ProjectionSimpleToSearchResultTransformer.class);
	private String idQuery = "";
	private Query queryLucene;
	@Override
	public Object transformTuple(Object[] tuple, String[] aliases) {

		Map result = new HashMap(tuple.length);		
		for (int i = 0; i < tuple.length; i++) {
			String key = aliases[i];
			if (key != null) {
				result.put(key, tuple[i]);				
			}
		}
		String docid = String.valueOf(result.get(FullTextQuery.ID));

		OfacQuery ofacQueryNew = new OfacQuery(idQuery, docid, idQuery, queryLucene);
		ofacQueryNew.setScore((float) result.get(FullTextQuery.SCORE));
		ofacQueryNew.setType(OfacQuery.Type.CUSTOM);
		if (result.containsKey(ofacQueryNew.getField()))
			ofacQueryNew.setTerm(String.valueOf(result.get(ofacQueryNew.getField())));
		
		SearchResultOfac searchResultOfac = new SearchResultOfac(idQuery,String.valueOf(result.get(FullTextQuery.ID)));
		searchResultOfac.setDocumentMatch(result.get(FullTextQuery.THIS));
		searchResultOfac.setScore(ofacQueryNew.getScore());
		searchResultOfac.setOfacQuery(ofacQueryNew);
		
		return searchResultOfac;
	}

	@Override
	public List transformList(List collection) {
		return collection;
	}

	public String getIdQuery() {
		return idQuery;
	}

	public void setIdQuery(String idQuery) {
		this.idQuery = idQuery;
	}

	public Query getQueryLucene() {
		return queryLucene;
	}

	public void setQueryLucene(Query queryLucene) {
		this.queryLucene = queryLucene;
	}

}
