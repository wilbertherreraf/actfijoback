package gob.bcb.lavado.search;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;

import gob.bcb.lavado.search.facet.FacetQueryOfac;

public class DocumentBatch<T> implements Iterable<T>  {
	private final List<T> documents = new ArrayList<>();
	
	public DocumentBatch() {
	}
    /** Add an InputDocument */
    public void add(T doc) {
        documents.add(doc);
    }

    /** Add a collection of InputDocuments */
    public void addAll(Collection<T> docs) {
        documents.addAll(docs);
    }

	@Override
	public Iterator<T> iterator() {
		return documents.iterator();
	}

    public int getBatchSize() {
        return documents.size();
    }
    
    public List<T> getDocuments(){
    	return documents;
    }
}
