package gob.bcb.lavado.search.presearcher;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.Presearcher;
import gob.bcb.lavado.search.analysis.ShingleAnalyzer;
import gob.bcb.lavado.search.indexer.JPASearchFactoryController;
import gob.bcb.lavado.search.presearcher.HighlightsMatch.Hit;
import gob.bcb.lavado.search.queryparsers.OfacQueryBuilder;
import gob.bcb.lavado.search.queryparsers.QueryParsersBuilder;

import org.apache.lucene.queryparser.classic.QueryParser.Operator;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.Query;

public class TermsPreseacher implements Presearcher {
	private static final Logger log = LoggerFactory.getLogger(TermsPreseacher.class);
	// private final FacetQueryOfac facetQueryOfac;
	private final List<OfacQuery> ofacQueryList = new ArrayList<>();
	private final JPASearchFactoryController jPASearchFactoryController;

	public TermsPreseacher(final JPASearchFactoryController jPASearchFactoryController) {
		this.jPASearchFactoryController = jPASearchFactoryController;
	}

	@Override
	public List<OfacQuery> buildQuery(String query, List<FieldQuery> fieldQueryList) {
		if (fieldQueryList.size() == 0) {
			throw new RuntimeException("Campos consulta sin parametros");
		}

		for (FieldQuery fieldQuery : fieldQueryList) {
			buildQuery(query, fieldQuery);
		}
		return ofacQueryList;
	}

	@Override
	public List<OfacQuery> buildQuery(String query, FieldQuery fieldQuery) {
		List<OfacQuery> ofacQueryLista = new ArrayList<>();
		OfacQueryBuilder ofacQueryBuilder = new OfacQueryBuilder();
		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, fieldQuery.getClazz());

		List<Hit> hitsh = ShingleAnalyzer.retrieveCandidatesTermsHit(query, fieldQuery.getMinWordLen(), fieldQuery.isExceptNumbers(), fieldQuery.getAnalyzer());

		if (hitsh.size() == 0)
			return new ArrayList<>();

		for (Hit hit : hitsh) {
			String word = hit.text;
			Query queryLuceneWord = null;
			
			if (fieldQuery.getDistanceUpTo() >= 1) {
				queryLuceneWord = queryParsersBuilder.createQueryFuzzyField(fieldQuery.getField(), word, fieldQuery.getDistanceUpTo(),
						fieldQuery.getPrefixLength(), fieldQuery.getBoost());
			} else {
				try {
					queryLuceneWord = queryParsersBuilder.createQueryParse(fieldQuery.getField(), word, Operator.OR, fieldQuery.getBoost(),
							fieldQuery.getAnalyzer());
				} catch (Exception e) {
					throw new RuntimeException("Error en consulta parsear consulta, " + e.getMessage(),  e);
				}				
			}

			if (queryLuceneWord == null)
				continue;

			Query queryLucene = null;

			if (fieldQuery.getQueryTemplate() != null && fieldQuery.getQueryTemplate().trim().length() > 0) {
				Query queryLuceneTemplate;
				try {
					queryLuceneTemplate = queryParsersBuilder.createQueryParse(fieldQuery.getField(), fieldQuery.getQueryTemplate(), Operator.AND, 0,
							fieldQuery.getAnalyzer());
					queryLucene = queryParsersBuilder.joinQueries(queryLuceneWord, BooleanClause.Occur.MUST, queryLuceneTemplate, BooleanClause.Occur.MUST);					
				} catch (Exception e) {
					throw new RuntimeException("Error en consulta "  + fieldQuery.getQueryTemplate() + " " + e.getMessage(),  e);
				}
			} else {
				queryLucene = queryLuceneWord;
			}

			OfacQuery ofacQuery = ofacQueryBuilder.createOfacQuery(word, fieldQuery, queryLucene);
			if (fieldQuery.getDistanceUpTo() >= 1) {
				ofacQuery.setType(OfacQuery.Type.ANY);
			}
			ofacQuery.addHit(ofacQuery.getField(), hit.startPosition, hit.endPosition, hit.startOffset, hit.endOffset);			
			ofacQueryLista.add(ofacQuery);
		}

		ofacQueryList.addAll(Collections.unmodifiableCollection(ofacQueryLista));
		return ofacQueryList;
	}
	
	public List<OfacQuery> getOfacQueryList() {
		return ofacQueryList;
	}

}
