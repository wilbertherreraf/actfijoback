package gob.bcb.lavado.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.apache.commons.lang.CharEncoding;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.messageresolver.StandardMessageResolver;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

@Configuration
public class ThymeleafConfiguration {
	private final Logger log = LoggerFactory.getLogger(ThymeleafConfiguration.class);

	@Autowired
	private MessageSource messageSource;

	@Bean
	@Description("Thymeleaf template resolver serving HTML 5 emails")
	public ClassLoaderTemplateResolver emailTemplateResolver() {
		ClassLoaderTemplateResolver emailTemplateResolver = new ClassLoaderTemplateResolver();
		emailTemplateResolver.setPrefix("mails/");
		emailTemplateResolver.setSuffix(".html");
		emailTemplateResolver.setTemplateMode("HTML");
		emailTemplateResolver.setCharacterEncoding(CharEncoding.UTF_8);
		emailTemplateResolver.setOrder(1);
		log.info("Thymeleaf template configuration done...");
		return emailTemplateResolver;
	}

	@Bean
	public TemplateEngine templateEngine(ClassLoaderTemplateResolver emailTemplateResolver) {
		log.info("templateEngine init config...");
		TemplateEngine templateEngine = new TemplateEngine();

		templateEngine.setTemplateResolver(emailTemplateResolver);
		templateEngine.getConfiguration();
		log.info("templateEngine init done...{}", templateEngine.isInitialized());		
		return templateEngine;
	}
}
