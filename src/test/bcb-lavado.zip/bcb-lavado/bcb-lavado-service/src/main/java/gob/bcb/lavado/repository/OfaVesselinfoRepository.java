package gob.bcb.lavado.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaVesselinfo;

@Repository
public interface OfaVesselinfoRepository extends JpaRepository<OfaVesselinfo,Integer>{

}
