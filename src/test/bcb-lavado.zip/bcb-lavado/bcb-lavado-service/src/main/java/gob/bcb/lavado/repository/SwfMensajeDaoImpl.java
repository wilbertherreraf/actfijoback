package gob.bcb.lavado.repository;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.saa.model.AddressFullName;
import gob.bcb.iso20022.swift.saa.model.AddressInfo;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.swift.saa.model.Header;
import gob.bcb.iso20022.swift.saa.model.InterfaceInfo;
import gob.bcb.iso20022.swift.saa.model.Message;
import gob.bcb.iso20022.swift.saa.model.NetworkInfo;
import gob.bcb.iso20022.swift.saa.model.SWIFTNetNetworkInfo;
import gob.bcb.lavado.client.HandlerGeneratorLauSrv;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfBicsPK;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfNumeraswf;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.model.SwfTipomensaje;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.services.CryptoSwiftService;
import gob.bcb.lavado.services.NumeracionSwiftService;
import gob.bcb.lavado.services.SwiftBcbParserServiceImpl;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

@Repository("swfMensajeDao")
@Transactional
public class SwfMensajeDaoImpl implements SwfMensajeDao {
	private static final Logger log = LoggerFactory.getLogger(SwfMensajeDaoImpl.class);
	private static final String DIR_BACKUP_IMPORTADOS = "_Back/";
	@Autowired
	private SwfTipomensajeDao swfTipomensajeDao;
	@Autowired
	private SwfBicsDao swfBicsDao;
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private CryptoSwiftService cryptoSwiftService;
	@Autowired
	private NumeracionSwiftService numeracionSwiftService;

	@Autowired
	private AppProperties appProperties;
	private static final DataPDU pduInfo = new DataPDU()//
			.setHeader((new Header())//
					.setMessage(new Message()//
							.setNetworkInfo(new NetworkInfo().setSWIFTNetNetworkInfo(new SWIFTNetNetworkInfo()))//
							.setSender(new AddressInfo().setFullName(new AddressFullName()))//
							.setReceiver(new AddressInfo().setFullName(new AddressFullName()))//
							.setInterfaceInfo(new InterfaceInfo()))//
			);
	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;

	@Autowired
	@Qualifier("entityManagerFactory")
	private EntityManagerFactory entityManagerFactory;

	private static String PATH_DIR_SWIFT_MT;
	private static String PATH_DIR_SWIFT_MX;

	@Transactional(readOnly = true)
	public SwfMensaje findByCodigo(Integer menCodmen) {
		if (menCodmen == null)
			return null;
		String jpql = "SELECT t FROM SwfMensaje t ";
		jpql = jpql.concat("WHERE t.menCodmen = :menCodmen ");
		Query query = entityManager.createQuery(jpql);
		query.setParameter("menCodmen", menCodmen);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfMensaje) lista.get(0);
		}
		return null;
	}

	@Transactional(readOnly = true)
	public SwfMensaje findByHash(String menHash, String menInout) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menHash = :menHash ");
		jpql = jpql.concat("and t.menInout = :menInout ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("menHash", menHash);
		query.setParameter("menInout", menInout);

		List lista = query.getResultList();

		if (lista.size() > 0) {
			return (SwfMensaje) lista.get(0);
		}
		return null;
	}

	@Transactional(readOnly = true)
	public List<SwfMensaje> findByCodOperacion(String menRefer, String menCodapp) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menRefer = :menRefer ");
		jpql = jpql.concat("and t.menCodapp = :menCodapp ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("menRefer", menRefer);
		query.setParameter("menCodapp", menCodapp);

		List<SwfMensaje> lista = query.getResultList();

		return lista;
	}

	@Transactional(readOnly = true)
	public List<SwfMensaje> findObservados(Integer menEstverifica) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menNrolote is null ");
		jpql = jpql.concat("and t.menEstverifica = :menEstverifica ");
		// jpql = jpql.concat("and m.menInout = 'O' ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("menEstverifica", menEstverifica);

		List<SwfMensaje> lista = query.getResultList();

		return lista;
	}

	@Transactional(readOnly = true)
	public List<SwfMensaje> findByEstautoriza(Integer menEstautoriza, Integer menEstmensaje) {
		// registros para autorizar al servidor swift
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menEstautoriza = :menEstautoriza ");
		jpql = jpql.concat("and t.menInout = :menInout ");
		jpql = jpql.concat("and t.menEstmensaje = :menEstmensaje ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("menEstautoriza", menEstautoriza);
		query.setParameter("menInout", Constants.TIPO_MENSAJE_OUT);
		query.setParameter("menEstmensaje", menEstmensaje);

		List<SwfMensaje> lista = query.getResultList();
		log.info("[{} regs.] de Consulta mens. por autorizar est: {}, query: {} ", lista.size(), menEstautoriza, jpql);

		return lista;
	}

	@Transactional(readOnly = true)
	public List<SwfMensaje> findByNroLote(Integer menNrolote) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menNrolote = :menNrolote ");
		jpql = jpql.concat("and t.menInout = :menInout ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("menNrolote", menNrolote);
		query.setParameter("menInout", Constants.TIPO_MENSAJE_IN);
		List lista = query.getResultList();

		return lista;
	}

	@Transactional(readOnly = true)
	public List<MensajesDatos> buscarMensajesEntrantes(SwfMensaje swfMensaje, Integer resCodempasig, Integer resCodemp, Integer resEstrevision,
			Date conFecinicio, Date conFecfin, Integer codEmpleadoFiltro) {
		List<MensajesDatos> mensajesDatosLista = new ArrayList<MensajesDatos>();
		List<SwfMensaje> swfMensajeLista = buscarMensajesEntrantes(swfMensaje, resCodempasig, codEmpleadoFiltro, resEstrevision, conFecinicio, conFecfin);
		Map<String, SwfBics> mapCtrlSwfBics = new HashMap<String, SwfBics>();
		Map<String, SwfTipomensaje> mapCtrlSwfTipomensaje = new HashMap<String, SwfTipomensaje>();

		int countRegs = 0;
		for (SwfMensaje swfMensajeRet : swfMensajeLista) {
			String menBicBranch = swfMensajeRet.getMenBic() + swfMensajeRet.getMenBicbranch();
			// solo para performance buscamos en el mapa
			SwfBics swfBics = mapCtrlSwfBics.get(menBicBranch);
			SwfTipomensaje swfTipomensaje = mapCtrlSwfTipomensaje.get(swfMensajeRet.getMenCodmt());

			MensajesDatos mensajesDatos = mensajeDatosFromSwfMensaje(swfMensajeRet, swfBics, swfTipomensaje, resCodemp, null, true);
			if (!mapCtrlSwfBics.containsKey(menBicBranch)) {
				// si no esta en el mapa lo insertamos
				mapCtrlSwfBics.put(menBicBranch, mensajesDatos.getSwfBics());
			}

			if (swfTipomensaje != null && !mapCtrlSwfTipomensaje.containsKey(swfMensajeRet.getMenCodmt())) {
				// si no esta en el mapa lo insertamos
				mapCtrlSwfTipomensaje.put(swfMensajeRet.getMenCodmt(), swfTipomensaje);
			}
			mensajesDatosLista.add(mensajesDatos);
			if (++countRegs >= Constants.SEARCH_LIMIT_REGS)
				break;
		}
		return mensajesDatosLista;
	}

	@Transactional(readOnly = true)
	public List<SwfMensaje> buscarMensajesEntrantes(SwfMensaje swfMensaje, Integer resCodempasig, Integer resCodemp, Integer resEstrevision,
			Date conFecinicio, Date conFecfin) {

		String jpql = "SELECT m ";
		jpql = jpql.concat("FROM SwfMensaje m ");
		jpql = jpql.concat("WHERE m.menEstmensaje != 9 ");

		if (swfMensaje != null) {
			if (swfMensaje.getMenCodmen() != null && swfMensaje.getMenCodmen().compareTo(0) > 0)
				jpql = jpql.concat("and m.resCodmen = :resCodmen ");

			if (swfMensaje.getMenEstverifica() != null && swfMensaje.getMenEstverifica().compareTo(0) > 0)
				jpql = jpql.concat("and m.menEstverifica = :menEstverifica ");

			if (!StringUtils.isBlank(swfMensaje.getMenEmisor()))
				jpql = jpql.concat("and upper(m.menBic || m.menBicbranch) like :menEmisor ");

			if (!StringUtils.isBlank(swfMensaje.getMenInout()))
				jpql = jpql.concat("and m.menInout = :menInout ");

			if (swfMensaje.getMenEstmensaje() != null)
				jpql = jpql.concat("and m.menEstmensaje = :menEstmensaje ");

		}

		if (conFecinicio != null && conFecfin != null) {
			jpql = jpql.concat("and date(m.menFecreg) between :conFecinicio and :conFecfin ");
		}

		log.info("Consulta de busqueda: resCodemp " + resCodemp + " resEstrevision:" + resEstrevision + " conFecinicio:" + conFecinicio + " conFecfin:"
				+ conFecfin);
		log.info("=>" + jpql);
		Query query = entityManager.createQuery(jpql);

		if (swfMensaje != null) {
			if (swfMensaje.getMenCodmen() != null && swfMensaje.getMenCodmen().compareTo(0) > 0)
				query.setParameter("resCodmen", swfMensaje.getMenCodmen());

			if (swfMensaje.getMenEstverifica() != null && swfMensaje.getMenEstverifica().compareTo(0) > 0)
				query.setParameter("menEstverifica", swfMensaje.getMenEstverifica());

			if (!StringUtils.isBlank(swfMensaje.getMenEmisor()))
				query.setParameter("menEmisor", swfMensaje.getMenEmisor().toUpperCase() + "%");

			if (!StringUtils.isBlank(swfMensaje.getMenInout()))
				query.setParameter("menInout", swfMensaje.getMenInout());

			if (swfMensaje.getMenEstmensaje() != null)
				query.setParameter("menEstmensaje", swfMensaje.getMenEstmensaje());

		}
		if (conFecinicio != null && conFecfin != null) {
			query.setParameter("conFecinicio", conFecinicio, TemporalType.DATE);
			query.setParameter("conFecfin", conFecfin, TemporalType.DATE);
		}

		List<SwfMensaje> swfMensajeLista = query.getResultList();

		log.info("Encontrados " + swfMensajeLista.size() + " regs.");
		return swfMensajeLista;
	}

	@Transactional(readOnly = true)
	public MensajesDatos mensajeDatosFromSwfMensaje(SwfMensaje swfMensaje, SwfBics swfBics, SwfTipomensaje swfTipomensaje, Integer codempleado,
			Integer estRevision, boolean recuperaAsignacion) {
		MensajesDatos mensajesDatos = new MensajesDatos();

		mensajesDatos.setSeleccionado(false);
		mensajesDatos.setSecuencia(0);
		mensajesDatos.setMenCodmen(swfMensaje.getMenCodmen());
		mensajesDatos.setMenCodmt(swfMensaje.getMenCodmt());
		mensajesDatos.setMenEmisor(swfMensaje.getMenEmisor());
		mensajesDatos.setSwfMensaje(swfMensaje);

		if (swfBics == null) {
			swfBics = swfBicsDao.findByBicBranch(swfMensaje.getMenBic(), swfMensaje.getMenBicbranch());
		}

		if (swfBics == null) {
			SwfBicsPK swfBicsPK = new SwfBicsPK();
			swfBicsPK.setBicCodbic(swfMensaje.getMenBic());
			swfBicsPK.setBicCodbranch(swfMensaje.getMenBicbranch());

			swfBics = new SwfBics();
			swfBics.setId(swfBicsPK);
			swfBics.setBicDescrip("NO REGISTRADO: " + swfMensaje.getMenBic() + "" + swfMensaje.getMenBicbranch());
			swfBics.setBicCiudad("");
			swfBics.setBicDirecc1("");
			swfBics.setBicPais("");
			log.debug("ATENCION! BIC SIN REGISTRO en tabla swfBics  " + swfMensaje.getMenEmisor());
		}

		mensajesDatos.setSwfBics(swfBics);

		if (swfTipomensaje == null) {
			swfTipomensaje = swfTipomensajeDao.getByCodigo(swfMensaje.getMenCodmt());
		}

		if (swfTipomensaje != null) {
			mensajesDatos.setMenCodmtdescrip(swfTipomensaje.getTimDescrip());
		} else {
			log.debug("ATENCION! TIPO " + swfMensaje.getMenCodmt() + " NO PARAMETRIZADO");
			mensajesDatos.setMenCodmtdescrip("ATENCION! TIPO " + swfMensaje.getMenCodmt() + " NO PARAMETRIZADO");
		}

		return mensajesDatos;
	}

	/**
	 * Asignaciones realizadas por un empleado de un mensaje
	 */
	public List<SwfAsignamensaje> asignacionesByCodEmpEstRev(Integer resCodmen, Integer resCodemp, Integer estRevision) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfAsignamensaje t ");
		jpql = jpql.concat("WHERE t.id.resCodmen = :resCodmen ");
		jpql = jpql.concat("and t.id.resCodemp != t.resCodemppadre ");

		if (estRevision != null) {
			jpql = jpql.concat("and t.resEstrevision = :estRevision ");
		}
		if (resCodemp != null) {
			jpql = jpql.concat("and t.resCodemppadre = :resCodemp ");
		}

		jpql = jpql.concat("order by t.resCorrasigna ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodmen", resCodmen);

		if (estRevision != null) {
			query.setParameter("estRevision", estRevision);
		}

		if (resCodemp != null) {
			query.setParameter("resCodemp", resCodemp);
		}
		List lista = query.getResultList();
		return lista;
	}

	/**
	 * determina si el mensaje es una asignacion de un tercero
	 */
	public List<SwfAsignamensaje> asignacionesDeATerceros(Integer resCodmen, Integer resCodemp, Integer estRevision) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfAsignamensaje t ");
		jpql = jpql.concat("WHERE t.id.resCodmen = :resCodmen ");
		jpql = jpql.concat("and t.id.resCodemp != t.resCodemppadre ");

		if (estRevision != null) {
			jpql = jpql.concat("and t.resEstrevision = :estRevision ");
		}

		jpql = jpql.concat("and t.id.resCodemp = :resCodemp ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodmen", resCodmen);
		query.setParameter("resCodemp", resCodemp);
		if (estRevision != null) {
			query.setParameter("estRevision", estRevision);
		}

		List lista = query.getResultList();
		return lista;
	}

	public List<SwfAsignamensaje> asignacionesByEmpMasHijos(Integer resCodmen, Integer resCodemp, Integer estRevision) {
		log.debug("en asignacionesByEmpMasHijos resCodmen " + resCodmen + " resCodemp: " + resCodemp);
		List<SwfAsignamensaje> swfAsignamensajeListResp = new ArrayList<SwfAsignamensaje>();
		List<SwfAsignamensaje> swfAsignamensajeList = asignacionesByCodEmpEstRev(resCodmen, resCodemp, estRevision);

		if (swfAsignamensajeList.size() > 0) {
			swfAsignamensajeListResp.addAll(swfAsignamensajeList);
		} else {
			return swfAsignamensajeListResp;
		}

		for (SwfAsignamensaje swfAsignamensaje : swfAsignamensajeList) {
			// recursivamente llamamos
			List<SwfAsignamensaje> swfAsignamensajeListHijo = asignacionesByEmpMasHijos(resCodmen, swfAsignamensaje.getId().getResCodemp(), estRevision);
			if (swfAsignamensajeListHijo.size() > 0) {
				swfAsignamensajeListResp.addAll(swfAsignamensajeListHijo);
			}
		}
		return swfAsignamensajeListResp;
	}

	public SwfAsignamensaje swfAsignamensajeCodigo(Integer resCodmen, Integer resCodemp) {
		String jpql = "SELECT t FROM SwfAsignamensaje t ";
		jpql = jpql.concat("WHERE t.id.resCodmen = :resCodmen ");
		jpql = jpql.concat("and t.id.resCodemp = :resCodemp ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodmen", resCodmen);
		query.setParameter("resCodemp", resCodemp);
		List lista = query.getResultList();

		if (lista.size() > 0) {
			return (SwfAsignamensaje) lista.get(0);
		}
		return null;
	}

	// @Transactional()
	public SwfMensaje registrarNuevo(SwfMensaje swfMensaje) {
		log.debug("Nuevo registro SwfMensaje " + swfMensaje.getMenHash());

		if (swfMensaje.getMenPlano() == null || StringUtils.isEmpty(swfMensaje.getMenPlano()))
			throw new SwiftAdminException("Mensaje " + swfMensaje.getMenHash() + " con parametro swfMensaje.MenPlano invalido");

		String decPlano = cryptoSwiftService.encryptPlain(swfMensaje.getMenPlano());
		if (decPlano == null) {
			log.error("Error en proceso de encriptacion " + swfMensaje.getMenHash() + " con mensaje \n" + swfMensaje.getMenPlano());
			throw new SwiftAdminException(
					"Error en proceso de encriptacion " + swfMensaje.getMenHash() + " en mensaje " + UtilsGeneric.getShortText(swfMensaje.getMenPlano(), 88));
		}

		swfMensaje.setMenPlano(decPlano);

		Integer perCodigo = getCodigo();

		swfMensaje.setMenTabestmensaje(Constants.TAB_ESTMENSAJE);
		swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_REGISTRADO);
		swfMensaje.setMenTabestverifica(Constants.TAB_ESTVERIFICA);
		swfMensaje.setMenEstverifica(Constants.TAB_ESTVERIFICA_REGISTRADO);
		swfMensaje.setMenTabestautoriza(Constants.TAB_ESTAUTORIZA);
		swfMensaje.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_PENDIENTEAUTORIZA);
		swfMensaje.setMenCodmen(perCodigo);
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenGestion(GregorianCalendar.getInstance().get(Calendar.YEAR));
		swfMensaje.setMenAuditfho(new Date());

		List<Block4> block4List = swfMensaje.getBlock4List();
		entityManager.persist(swfMensaje);
		log.info("Creado mensaje swift " + swfMensaje.toString());

		swfMensaje = findByCodigo(swfMensaje.getMenCodmen());
		swfMensaje.setBlock4List(block4List);
		return swfMensaje;
	}

	private SwfMensaje updateReg(SwfMensaje swfMensaje) {
		log.info("Actualizando {} tipo: {}", swfMensaje.getMenCodmen(), swfMensaje.getMenFormato());
		String encryptPlano = cryptoSwiftService.encryptPlain(swfMensaje.getMenPlano());
		if (encryptPlano == null) {
			log.error("UPD SWF: Error en proceso de encriptacion " + swfMensaje.getMenHash() + " con mensaje \n" + swfMensaje.getMenPlano());
			throw new SwiftAdminException("UPD SWF: Error en proceso de encriptacion " + swfMensaje.getMenHash() + " en mensaje "
					+ UtilsGeneric.getShortText(swfMensaje.getMenPlano(), 88));
		}
		swfMensaje.setMenPlano(encryptPlano);
		swfMensaje.setMenAuditfho(new Date());
		List<Block4> block4List = swfMensaje.getBlock4List();

		SwfMensaje swfMensajeNew = entityManager.merge(swfMensaje);
		swfMensajeNew.setBlock4List(block4List);
		log.info("Mensaje actualizado " + swfMensajeNew.toString());

		return swfMensajeNew;
	}

	public SwfMensaje updateRegSinEnc(SwfMensaje swfMensaje) {
		// log.info("Actualizando updateRegSinEnc " + swfMensaje.getMenCodmen());
		swfMensaje.setMenAuditfho(new Date());
		List<Block4> block4List = swfMensaje.getBlock4List();

		SwfMensaje swfMensajeNew = entityManager.merge(swfMensaje);
		swfMensajeNew.setBlock4List(block4List);
		log.info("Mensaje actualizado " + swfMensajeNew.toString());

		return swfMensajeNew;
	}

	/**
	 * Verifica si el mensaje fue escaneado, registra si el mismo no se encuentra en
	 * base de datos
	 * 
	 * @param swfMensaje
	 * @return retorna {@link SwfMensaje} objeto en base de datos
	 */
	private static Integer verificarEstadoScan(SwfMensaje swfMensajeOld, String secRegister, String secExpected) {

		if (!swfMensajeOld.getMenInout().equals(Constants.TIPO_MENSAJE_OUT)) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con tipo de mensaje " + swfMensajeOld.getMenInout() + " invalido");
		}

		if ((swfMensajeOld.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con estado incorrecto de autorizacion "
					+ swfMensajeOld.getMenEstautoriza() + " no puede continuar");
		}

		if ((swfMensajeOld.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR) == 0)) {
			if ((swfMensajeOld.getMenNrocorr() == null) || swfMensajeOld.getMenNrocorr().compareTo(0) == 0) {
				throw new SwiftAdminException("INCONSISTENCIA: Mensaje " + swfMensajeOld.getMenCodmen() + ", con estado pre autorizado "
						+ swfMensajeOld.getMenEstautoriza() + " y correlativo invalido[correlativo: " + swfMensajeOld.getMenNrocorr()
						+ "] no puede continuar, comunique al administrador");
			}
		}
		boolean isEqSecs = secRegister != null && secExpected != null && secRegister.equalsIgnoreCase(secExpected);

		if (swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0) {
			log.info("Mensaje anteriormente registrado " + swfMensajeOld.getMenCodmen() + " se cambia de estado a " + Constants.TAB_ESTVERIFICA_REGISTRADO
					+ " para scaneo");

			return Constants.TAB_ESTVERIFICA_REGISTRADO;
		} else if (swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0) {
			if (isEqSecs) {
				return Constants.TAB_ESTVERIFICA_VERIFICADO;
			}
			log.info("Mensaje scaneado registrado " + swfMensajeOld.getMenCodmen() + " con estado " + swfMensajeOld.getMenEstverifica()
					+ " con diferentes hash " + secRegister);

			return Constants.TAB_ESTVERIFICA_REGISTRADO;

		} else if ((swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0)) {
			log.info("Mensaje registrado anteriormente se debe esperar accion del administrador " + swfMensajeOld.getMenCodmen());
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con estado bloqueado " + swfMensajeOld.getMenEstverifica()
					+ " se espera accion del administrador del sistema. " + swfMensajeOld.getMenRefer());
		} else if ((swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO) == 0)) {
			if (isEqSecs) {
				log.info("Mensaje registrado [" + swfMensajeOld.getMenCodmen() + "] anteriormente fue verificado y habilitado por administrador "
						+ swfMensajeOld.getMenUsrlvdverifica());

				return Constants.TAB_ESTVERIFICA_FALSO_POSITIVO;
			} else {
				log.warn("Atencion!!: Mensaje registrado [" + swfMensajeOld.getMenCodmen() + ", hash: " + secRegister
						+ "] anteriormente fue verificado y habilitado por administrador " + swfMensajeOld.getMenUsrlvdverifica()
						+ " pero difiere del original hash nuevo: " + secExpected);

				return Constants.TAB_ESTVERIFICA_FALSO_POSITIVO;
			}
		} else if ((swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0)) {
			log.info("Mensaje Bloqueado " + swfMensajeOld.getMenCodmen() + " por el  administrador [" + swfMensajeOld.getMenUsrlvdverifica()
					+ "] del sistema.");
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con estado bloqueado " + swfMensajeOld.getMenEstverifica()
					+ " consulte con el administrador[" + swfMensajeOld.getMenUsrlvdverifica() + "] del sistema.");
		}

		throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con estado de verificación NO VALIDO en sistema "
				+ swfMensajeOld.getMenEstverifica() + " solicite asistencia técnica.");
	}

	public SwiftDatos actualizarConPlano(String menPlano, String codapp, Integer menCodmen, Integer nroCorrelativo, String codoperacion, String coduser,
			String estacion, String idsession, String codelau) {
		log.info("actualizarConPlano codapp {}, menCodmen {}, nroCorrelativo {}, codoperacion {}, coduser {}, estacion {} idsession {}", codapp, menCodmen,
				nroCorrelativo, codoperacion, coduser, estacion, idsession);
		initDataPDU();
		
		String paramsAdic = new String(Base64.decodeBase64(codoperacion == null ? "" : codoperacion));
		Map<String, String> mapParms = UtilsGeneric.paramsLista(paramsAdic);
		String menIdTMessageTx = mapParms.getOrDefault("menIdTMessageTx", "");
		
		SwfMensaje swfMensajeOld = verificaEstadoOld(menCodmen, codapp, nroCorrelativo);

		String menHash = swfMensajeOld.getMenHash();

		SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(swfMensajeOld, menPlano);

		SwiftBcbParserServiceImpl.updSign(swiftDatos, codelau, pduInfo.getHeader().getMessage());

		Integer menEstadoverificacion = verificarEstadoScan(swfMensajeOld, menHash, swiftDatos.getSwfMensaje().getMenHash());
		swfMensajeOld.setMenEstverifica(menEstadoverificacion);

		log.info("=====> {} [{} - {}] <=====", swfMensajeOld.getMenCodapp(), swfMensajeOld.getMenFormato(), swfMensajeOld.getMenIdtmessagetx());
		log.info(swfMensajeOld.getMenPlano());
		log.info("===== === =====");

		// swfMensajeOld.setMenRefer(codoperacion);
		swfMensajeOld.setMenAuditusr(coduser);
		swfMensajeOld.setMenAuditwst(estacion);
		swfMensajeOld.setMenFirmaorigen(idsession);
		
		if (!StringUtils.isBlank(menIdTMessageTx)) {
			swfMensajeOld.setMenIdtmessagetx(menIdTMessageTx);
		}
		
		swfMensajeOld.setMenEstmensaje(Constants.TAB_ESTMENSAJE_REGISTRADO);
		if (!StringUtils.isBlank(swfMensajeOld.getMenFirmaorigen())) {
			// si existe session se marca con estado en proceso
			swfMensajeOld.setMenEstmensaje(Constants.TAB_ESTMENSAJE_EN_PROCESO);
		}

		// swiftDatos.getSwfMensaje().setBlock4List(swiftBcbParserService.createListBlock4(swiftDatos.getSwiftMessageBcb(),
		// false));
		swiftDatos.getSwiftMessageAbs().isValidMsg(true);

		SwfMensaje swfMensajeNew = updateReg(swfMensajeOld);
		swiftDatos.setSwfMensaje(swfMensajeNew);

		return swiftDatos;
	}

	synchronized private Integer getCodigo() {
		Integer codigo = null;
		StringBuilder query = new StringBuilder();
		query.append("select max(m.menCodmen) from SwfMensaje m ");

		List result = entityManager.createQuery(query.toString()).getResultList();
		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
//		log.debug("Nuevo codigo : " + codigo);
		return codigo;

	}

	private SwfMensaje verificaEstadoOld(Integer menCodmen, String codapp, Integer nroCorrelativo) {
		SwfMensaje swfMensajeOld = findByCodigo(menCodmen);
		if (swfMensajeOld == null) {
			log.error("Mensaje inexistente " + menCodmen);
			throw new SwiftAdminException("Mensaje inexistente " + menCodmen);
		}

		if (StringUtils.isBlank(swfMensajeOld.getMenCodapp()) || !swfMensajeOld.getMenCodapp().equalsIgnoreCase(codapp)) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con codigo de aplicacion [" + swfMensajeOld.getMenCodapp()
					+ "] swift diferente al enviado [" + codapp + "] ");
		}

		if ((swfMensajeOld.getMenNrocorr() == null) || swfMensajeOld.getMenNrocorr().compareTo(0) == 0) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", sin correlativo");
		}

		if (nroCorrelativo != null && swfMensajeOld.getMenNrocorr().compareTo(nroCorrelativo) != 0) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con correlativo [" + swfMensajeOld.getMenNrocorr()
					+ "] swift diferente al enviado [" + nroCorrelativo + "] ");
		}

		if (swfMensajeOld.getMenNrocorr().compareTo(nroCorrelativo) != 0) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con correlativo [" + swfMensajeOld.getMenNrocorr()
					+ "] swift diferente al enviado [" + nroCorrelativo + "] ");
		}
		return swfMensajeOld;
	}

	public void verificaEstado(SwfMensaje swfMensaje) {
		log.info("verificando estado mensaje " + swfMensaje.getMenCodmen());
		if (swfMensaje.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_ELIMINADO) == 0) {
			throw new SwiftAdminException("Mensaje con estado " + swfMensaje.getMenEstmensaje() + ", no puede continuar.");
		}

		if (swfMensaje.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_PROCESADO) == 0) {
			throw new SwiftAdminException("Mensaje con estado " + swfMensaje.getMenEstmensaje() + ", no puede continuar.");
		}
	}

	public SwfMensaje cambiarEstadoAsignacion(SwfMensaje swfMensaje, Integer nuevoEstado) {
		SwfMensaje swfMensajeOld = findByCodigo(swfMensaje.getMenCodmen());
		if (swfMensajeOld == null) {
			throw new SwiftAdminException("Mensaje " + swfMensaje.getMenCodmen() + ", inexistente. ");
		}

		Integer estadoMenasignacionOld = swfMensajeOld.getMenEstmensaje();

		log.info("MENSAJE: cambio de estado " + swfMensajeOld.getMenCodmen() + " de:" + estadoMenasignacionOld + " => " + nuevoEstado);
		if (estadoMenasignacionOld.compareTo(Constants.TAB_ESTMENSAJE_ELIMINADO) == 0) {
			throw new SwiftAdminException("Mensaje con estado " + swfMensajeOld.getMenEstmensaje() + ", no puede continuar.");
		}

		if (estadoMenasignacionOld.compareTo(Constants.TAB_ESTMENSAJE_REGISTRADO) == 0 && nuevoEstado.compareTo(Constants.TAB_ESTMENSAJE_ASIGNADO) == 0) {
			// si el estado es de 1 a tres se genera un correlativo
			if (swfMensajeOld.getMenNrocorr() == null) {
				Integer corr = getCorrelativoAsignacion(swfMensajeOld.getMenGestion(), null, Constants.TIPO_MENSAJE_IN);
				swfMensajeOld.setMenNrocorr(corr);
			}
		}
		swfMensajeOld.setMenEstmensaje(nuevoEstado);
		swfMensajeOld.setMenAuditusr(swfMensaje.getMenAuditusr());
		swfMensajeOld.setMenAuditwst(swfMensaje.getMenAuditwst());

		return updateRegSinEnc(swfMensajeOld);
	}

	/**
	 * Proceso para cambiar el estado de la verificacion de un mensaje por parte del
	 * administrador de lavado
	 */
	public SwfMensaje cambiarEstadoVerificacion(Integer codMen, String codUsuario, Integer newEstado, String estacion) {
		log.info("cambiarEstadoVerificacion codMen {},  codUsuario {}, newEstado {}, estacion {}", codMen, codUsuario, newEstado, estacion);
		SwfMensaje swfMensaje = findByCodigo(codMen);
		if (swfMensaje == null) {
			throw new SwiftAdminException("Mensaje " + codMen + ", inexistente. ");
		}

		// control de estados no permitidos de estado de autorizacion
		if ((swfMensaje.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)) {
			throw new SwiftAdminException(
					"Mensaje " + swfMensaje.getMenCodmen() + ", con estado incorrecto de autorizacion " + swfMensaje.getMenEstautoriza());
		}

		Integer menEstverificaOld = swfMensaje.getMenEstverifica();
		swfMensaje.setMenEstverifica(newEstado);
		swfMensaje.setMenUsrlvdverifica(codUsuario);
		swfMensaje.setMenAuditusr(codUsuario);
		swfMensaje.setMenAuditwst(estacion);

		log.info("MENSAJE: cambio de estado verificacion " + swfMensaje.getMenCodmen() + " de " + menEstverificaOld + "   => " + newEstado);
		return updateRegSinEnc(swfMensaje);
	}

	public SwfMensaje cambiarEstadoPostScan(Integer codMen, Integer countRegs, String accionScan) {
		log.info("inicio cambiarEstadoPostScan cod:{} regs:{} accion: {}", codMen, countRegs, accionScan);
		SwfMensaje swfMensajeNew = findByCodigo(codMen);
		if (swfMensajeNew == null) {
			throw new SwiftAdminException("Post scan: Mensaje " + codMen + ", inexistente. ");
		}

		if ((swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)
				|| (swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_RECHAZADOPORADMINSWFT) == 0)) {
			throw new SwiftAdminException("PostScan: Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de autorizacion "
					+ swfMensajeNew.getMenEstautoriza() + " no puede continuar");
		}

		if ((swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0)
				|| (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0)) {
			throw new SwiftAdminException("PostScan: Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de scaneo "
					+ swfMensajeNew.getMenEstverifica() + " no puede continuar");
		}

		// cambiamos el estado segun el resultado del scan
		if (countRegs.compareTo(0) == 0) {
			// el mensaje no tiene observaciones
			if (swfMensajeNew.getMenInout().equals(Constants.TIPO_MENSAJE_OUT)
					&& (swfMensajeNew.getMenNrocorr() == null || swfMensajeNew.getMenNrocorr().compareTo(0) == 0)) {
				// en mensajes de salida se genera el correlativo
				// Integer corr = getCorrelativo(swfMensajeNew.getMenGestion(),
				// null, swfMensajeNew.getMenInout());
				Integer corr = getCorrelativoSwift(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditwst(), swfMensajeNew.getMenAuditusr());
				log.info("Nuevo correlativo[" + swfMensajeNew.getMenCodmen() + " - " + swfMensajeNew.getMenHash() + "] : " + corr);

				swfMensajeNew.setMenNrocorr(corr);
			}
			swfMensajeNew.setMenEstverifica(Constants.TAB_ESTVERIFICA_VERIFICADO);
			swfMensajeNew = updateRegSinEnc(swfMensajeNew);
			log.info("PostScan: Mensaje verificado sin observacion [" + swfMensajeNew.getMenCodmen() + "] con estado " + swfMensajeNew.getMenEstverifica()
					+ " Nrocorr:" + swfMensajeNew.getMenNrocorr());
		} else {
			if (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0) {
				if (accionScan == null) {
					SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_ACCIONSCAN);
					accionScan = swfParams.getParValor();
				}
				if (accionScan.trim().equalsIgnoreCase(Constants.PARAM_ACCIONSCAN_BLQ) && swfMensajeNew.getMenInout().equals(Constants.TIPO_MENSAJE_OUT)) {
					// solo los mensajes de salida se bloquean
					swfMensajeNew.setMenEstverifica(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ);
					log.info("PostScan: Mensaje bloqueado [" + swfMensajeNew.getMenCodmen() + "] scaneado con estado " + swfMensajeNew.getMenEstverifica());
				} else {
					// no se bloquea el mensaje y el estado se cambia a falso
					// positivo
					if (swfMensajeNew.getMenInout().equals(Constants.TIPO_MENSAJE_OUT)
							&& (swfMensajeNew.getMenNrocorr() == null || swfMensajeNew.getMenNrocorr().compareTo(0) == 0)) {
						// en mensajes de salida se genera el correlativo
						// Integer corr =
						// getCorrelativo(swfMensajeNew.getMenGestion(), null,
						// swfMensajeNew.getMenInout());
						Integer corr = getCorrelativoSwift(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditwst(), swfMensajeNew.getMenAuditusr());
						log.info("Nuevo correlativo[" + swfMensajeNew.getMenCodmen() + " - " + swfMensajeNew.getMenHash() + "] : " + corr);

						swfMensajeNew.setMenNrocorr(corr);
					}
					log.warn("AVISO!!! Mensaje [" + swfMensajeNew.getMenCodmen() + "] marcado como falso positivo por el sistema "
							+ Constants.TAB_ESTVERIFICA_FALSO_POSITIVO);
					swfMensajeNew.setMenEstverifica(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO);
				}
				swfMensajeNew = updateRegSinEnc(swfMensajeNew);
			}
		}

		log.info("PostScan: MENSAJE cambio de estado SCAN " + swfMensajeNew.getMenCodmen() + " nuevo estado=> " + swfMensajeNew.getMenEstverifica());
		return swfMensajeNew;
	}

	public static void actEstadoVerificaPostScan(SwfMensaje swfMensajeNew, Integer countRegs) {
		if ((swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)
				|| (swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_RECHAZADOPORADMINSWFT) == 0)) {
			throw new SwiftAdminException("PostScan: Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de autorizacion "
					+ swfMensajeNew.getMenEstautoriza() + " no puede continuar");
		}

		if ((swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0)
				|| (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0)) {
			throw new SwiftAdminException("PostScan: Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de scaneo "
					+ swfMensajeNew.getMenEstverifica() + " no puede continuar");
		}

		// cambiamos el estado segun el resultado del scan
		if (countRegs.compareTo(0) == 0) {
			// el mensaje no tiene observaciones
			swfMensajeNew.setMenEstverifica(Constants.TAB_ESTVERIFICA_VERIFICADO);
			log.info("PostScan: Mensaje verificado sin observacion [" + swfMensajeNew.getMenCodmen() + "] con estado " + swfMensajeNew.getMenEstverifica()
					+ " Nrocorr:" + swfMensajeNew.getMenNrocorr());
		} else {
			if (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0) {
				if (swfMensajeNew.getMenInout().equals(Constants.TIPO_MENSAJE_OUT)) {
					// solo los mensajes de salida se bloquean
					swfMensajeNew.setMenEstverifica(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ);
					log.info("PostScan: Mensaje bloqueado [" + swfMensajeNew.getMenCodmen() + "] scaneado con estado " + swfMensajeNew.getMenEstverifica());
				} else {
					// no se bloquea el mensaje y el estado se cambia a falso
					// positivo
					log.warn("AVISO!!! Mensaje [" + swfMensajeNew.getMenCodmen() + "] marcado como falso positivo por el sistema "
							+ Constants.TAB_ESTVERIFICA_FALSO_POSITIVO);
					swfMensajeNew.setMenEstverifica(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO);
				}
			}
		}

		log.info("PostScan: MENSAJE cambio de estado SCAN " + swfMensajeNew.getMenCodmen() + " nuevo estado=> " + swfMensajeNew.getMenEstverifica());

	}

	public SwfMensaje cambiarEstadoAutorizacion(Integer codMen, String codUsuario, Integer newEstado, String estacion) {
		log.info("cambiarEstadoAutorizacion codMen {},  codUsuario {}, newEstado {}, estacion {}", codMen, codUsuario, newEstado, estacion);
		SwfMensaje swfMensaje = findByCodigo(codMen);
		if (swfMensaje == null) {
			throw new SwiftAdminException("Mensaje " + codMen + ", inexistente. ");
		}

		// control de estados no permitidos de estado de autorizacion
		if ((swfMensaje.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)) {
			throw new SwiftAdminException(
					"Mensaje " + swfMensaje.getMenCodmen() + ", con estado incorrecto de autorizacion " + swfMensaje.getMenEstautoriza());
		}

		Integer menEstverificaOld = swfMensaje.getMenEstverifica();
		swfMensaje.setMenEstautoriza(newEstado);
		swfMensaje.setMenAuditusr(codUsuario);
		swfMensaje.setMenAuditwst(estacion);

		log.info("MENSAJE: cambio de estado autorizacion " + swfMensaje.getMenCodmen() + " de " + menEstverificaOld + "   => " + newEstado);
		return updateReg(swfMensaje);
	}

	public SwiftDatos preAutorizarSwift(Integer codlvd, String codapp, String coduser, String codoperacion, String idSession, String menPlano,
			String estacion, String codelau) {

		SwiftDatos swiftDatos = preAutorizaSwift(codlvd, codapp, coduser, codoperacion, idSession, menPlano, estacion, codelau);
		// boolean withlau = swiftDatos.getSwiftMessageAbs().getTagCodeLau() != null &&
		// swiftDatos.getSwiftMessageAbs().getTagCodeLau().length() > 0;

//		String dirpath = getDirectorySwiftFromMsg(swiftDatos.getSwiftMessageAbs().messageStandardType());
//		guardarEnImportados(codlvd, coduser, dirpath, estacion);

		return swiftDatos;
	}

	@Transactional()
	public SwiftDatos preAutorizaSwift(Integer menCodmen, String codapp, String coduser, String codoperacion, String idsession, String menPlano,
			String estacion, String codelau) {
		log.info("Pre autorizacion menCodmen: {}, codapp: {}, coduser: {}, codoperacion: {}, idsession: {}, estacion: {}", menCodmen, codapp, coduser,
				codoperacion, idsession, estacion);

		SwfMensaje swfMensajeNew = findByCodigo(menCodmen);
		if (swfMensajeNew == null) {
			throw new SwiftAdminException("Mensaje " + menCodmen + " inexistente");
		}

		if (StringUtils.isBlank(swfMensajeNew.getMenCodapp()) || !swfMensajeNew.getMenCodapp().equals(codapp)
				|| StringUtils.isBlank(swfMensajeNew.getMenRefer()) || !swfMensajeNew.getMenRefer().equals(codoperacion)) {
			throw new SwiftAdminException("La información no corresponde al registrado para Mensaje: " + menCodmen);
		}

		// control de estados no permitidos de estado de autorizacion
		if ((swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)) {
			log.error("Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de autorizacion " + swfMensajeNew.getMenEstautoriza());
			throw new SwiftAdminException(
					"Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de autorizacion " + swfMensajeNew.getMenEstautoriza());
		}

		if (swfMensajeNew.getMenNrocorr() == null || swfMensajeNew.getMenNrocorr().compareTo(0) == 0) {
			log.error("Error al aprobar mensaje " + swfMensajeNew.getMenCodmen() + " sin nro correlativo");
			throw new SwiftAdminException("Error al aprobar mensaje " + swfMensajeNew.getMenCodmen() + " sin nro correlativo");
		}

		if ((swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0)
				|| (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0)
				|| (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0)) {
			throw new SwiftAdminException("Autorizacion: Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de scaneo "
					+ swfMensajeNew.getMenEstverifica() + " no puede continuar");
		}

//		SwiftDatos swiftDatosIn = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menPlano);
//		SwiftBcbParserServiceImpl.updSign(swiftDatosIn, codelau);
//		SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(swfMensajeNew.getMenPlano());

		try {
			if (!StringUtils.isBlank(codelau) && !StringUtils.isBlank(idsession) && idsession.endsWith(HandlerGeneratorLauSrv.TIPOCLI_CONLAU)) {
				// verificacion del lau
				String secExpected = HandlerGeneratorLauSrv.getGeneratorLAU().signLau(menPlano);
				String secRegister = swfMensajeNew.getMenHash();
				String secReceiver = codelau;

				log.info("Pre autorización {} CON LAU, recibido: {}, registrado: {}, esperado: {}", swfMensajeNew.getMenCodmen(), secReceiver, secRegister,
						secExpected);
				HandlerGeneratorLauSrv.getCurrentInstanceHGen().validateCodeLauForMsg(menPlano, codelau);

			} else if (StringUtils.isBlank(codelau) && !StringUtils.isBlank(idsession) && idsession.endsWith(HandlerGeneratorLauSrv.TIPOCLI_SINLAU)) {
				log.info("Pre autorización SIN LAU en cliente, mensaje {}  ", swfMensajeNew.getMenCodmen());
			}

		} catch (Exception e) {
			log.error("Error al pre autorizar código lau de mensaje " + swfMensajeNew.getMenCodmen() + ": " + e.getMessage());
			throw new SwiftAdminException("Mensaje " + swfMensajeNew.getMenCodmen() + ": " + e.getMessage(), e);
		}

		swfMensajeNew.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR);
		swfMensajeNew.setMenAuditusr(coduser);
		swfMensajeNew.setMenAuditwst(estacion);
		swfMensajeNew.setMenFirmaorigen(idsession);
		swfMensajeNew.setMenEstmensaje(Constants.TAB_ESTMENSAJE_PROCESADO);

		if (!StringUtils.isBlank(swfMensajeNew.getMenFirmaorigen())) {
			// si existe session se marca con estado en proceso
			swfMensajeNew.setMenEstmensaje(Constants.TAB_ESTMENSAJE_EN_PROCESO);
		}

		swfMensajeNew.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT);
		swfMensajeNew.setMenFecauto(new Date());

		SwfMensaje swfMensajeupd = updateRegSinEnc(swfMensajeNew);
		salvarEnImportados(swfMensajeupd, coduser);

		SwiftDatos swiftDatos = new SwiftDatos();
		swiftDatos.setSwfMensaje(swfMensajeupd);
		log.info("SWIFT PRE autorizado... " + swfMensajeupd.getMenCodmen() + " hash:" + swfMensajeupd.getMenHash());
		return swiftDatos;
	}

	private void salvarEnImportados(SwfMensaje swfMensajeNew, String codUsuario) {
		log.info("Inicio Salvado en IMPORTADOS " + swfMensajeNew.getMenCodmen());

		if ((swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) != 0)) {
			throw new SwiftAdminException("Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de estado de pre autorizacion "
					+ swfMensajeNew.getMenEstautoriza() + " el mismo debe ser " + Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT + " para continuar");
		}

		String pathDirSwift = getDirectorySwiftFromMsg(FileFormat.valueOf(swfMensajeNew.getMenFormato()));
		String nombreArchivo = nombreArchivo(swfMensajeNew);
		String planoDecrypt = swfMensajeNew.getMenPlano();

		log.info("-->>>>oo00OO Autorizando [{}]OO00oo<<<<--", nombreArchivo);
		File h = new File(pathDirSwift + DIR_BACKUP_IMPORTADOS, nombreArchivo);

		if (h.exists() && !h.isDirectory()) {
			log.warn("=====%%% ATENCION!!! ATENCION!!!%%%=======");
			log.warn("=====%%% ATENCION!!! %%%=======");
			log.warn("SWIFT [" + swfMensajeNew.getMenCodmen() + "] autorizado en archivo " + h.getAbsolutePath());
			log.warn("SE RE - INTENTO AUTORIZAR EL MENSAJE, REVISAR MENSAJES ANTERIORES, POSIBLES ERROR EN AUTORIZACION ANTERIOR");
			log.warn("=====%%% ATENCION!!! %%%=======");

		}

		String pathDirSwiftDec = pathDirSwift + "/" + nombreArchivo;
		String pathDirSwiftEnc = pathDirSwift + DIR_BACKUP_IMPORTADOS + nombreArchivo;

		log.info(planoDecrypt);

		String p = UtilsFile.grabaEnArchivo(planoDecrypt, pathDirSwiftDec);
		log.info("Mensaje {} en IMPORTADOS {} por {}", swfMensajeNew.getMenCodmen(), p, codUsuario);

		String p_back = UtilsFile.grabaEnArchivo(planoDecrypt, pathDirSwiftEnc);
		log.info("Mensaje {} en BACKUP {} por {}", swfMensajeNew.getMenCodmen(), p_back, codUsuario);
	}

	@Transactional()
	public SwfMensaje guardarEnImportados(Integer codMen, String codUsuario, String pathDirSwift, String estacion) {
		log.info("Inicio Salvado en IMPORTADOS " + codMen + " por: " + codUsuario);
		SwfMensaje swfMensajeNew = findByCodigo(codMen);
		if (swfMensajeNew == null) {
			throw new SwiftAdminException("guardarEnImportados: Mensaje " + codMen + ", inexistente. ");
		}

		if ((swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR) != 0)) {
			throw new SwiftAdminException("Mensaje " + codMen + ", con estado incorrecto de estado de pre autorizacion " + swfMensajeNew.getMenEstautoriza()
					+ " el mismo debe ser " + Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR + " para continuar");
		}

		swfMensajeNew.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT);
		// swfMensajeNew.setMenUsrlvdverifica(codUsuario);
		swfMensajeNew.setMenAuditusr(codUsuario);
		swfMensajeNew.setMenAuditwst(estacion);

		SwfMensaje swfMensaje = updateRegSinEnc(swfMensajeNew);
		String nombreArchivo = nombreArchivo(swfMensaje);

		// String planoDecrypt =
		// cryptoSwiftService.decryptPlain(swfMensaje.getMenPlano());
		String planoDecrypt = swfMensaje.getMenPlano();
		log.info("-->>>>oo00OO Autorizando [{}]OO00oo<<<<--", nombreArchivo);
		log.info(planoDecrypt);

		File h = new File(pathDirSwift + DIR_BACKUP_IMPORTADOS, nombreArchivo);

		if (h.exists() && !h.isDirectory()) {
			log.warn("=====%%% ATENCION!!! ATENCION!!!%%%=======");
			log.warn("=====%%% ATENCION!!! %%%=======");
			log.warn("SWIFT [" + swfMensaje.getMenCodmen() + "] autorizado en archivo " + h.getAbsolutePath());
			log.warn("SE RE - INTENTO AUTORIZAR EL MENSAJE, REVISAR MENSAJES ANTERIORES, POSIBLES ERROR EN AUTORIZACION ANTERIOR");
			log.warn("=====%%% ATENCION!!! %%%=======");

		} else {

			String pathDirSwiftDec = pathDirSwift + "/" + nombreArchivo;
			String pathDirSwiftEnc = pathDirSwift + DIR_BACKUP_IMPORTADOS + nombreArchivo;

			String p = UtilsFile.grabaEnArchivo(planoDecrypt, pathDirSwiftDec);
			log.info("Mensaje salvado en IMPORTADOS " + codMen + " por: " + codUsuario + " en: " + p);

			// se copia en el backup posterior a swift para demostrar que el
			// archivo
			// fue guardado en importados
			String p_back = UtilsFile.grabaEnArchivo(planoDecrypt, pathDirSwiftEnc);
			log.info("Mensaje BACKUP salvado en " + codMen + " por: " + codUsuario + " en: " + p_back);
		}
		return swfMensaje;
	}

	private static String nombreArchivo(SwfMensaje swfMensaje) {
		return StringUtils.trim(swfMensaje.getMenCodapp() + swfMensaje.getMenGestion()) + "_" + swfMensaje.getMenCodmen() + "_"
				+ StringUtils.trim(swfMensaje.getMenRefer()) + "_" + String.format("%06d", swfMensaje.getMenNrocorr()) + swfMensaje.getMenCodusrswf()
				+ ".dos";
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public Integer cerrarTransaccion(String idsession) {
//		log.info("=== CERRANDO SESSION ===== " + idsession);
		if (StringUtils.isBlank(idsession)) {
			return 0;
		}
		String jpqlQL = "update SwfMensaje t ";
		jpqlQL = jpqlQL.concat("set t.menEstmensaje = :menEstmensajeupd, ");
		jpqlQL = jpqlQL.concat("t.menFirmaorigen = :menFirmaorigenupd ");
		jpqlQL = jpqlQL.concat("WHERE t.menFirmaorigen = :menFirmaorigen ");
		jpqlQL = jpqlQL.concat("and t.menInout = :menInout ");
		// jpqlQL = jpqlQL.concat("and t.menEstmensaje = :menEstmensaje ");

		Query query = entityManager.createQuery(jpqlQL);
		query.setParameter("menFirmaorigenupd", idsession + "+");
		query.setParameter("menEstmensajeupd", Constants.TAB_ESTMENSAJE_PROCESADO);

		query.setParameter("menFirmaorigen", idsession);
		query.setParameter("menInout", Constants.TIPO_MENSAJE_OUT);
		// query.setParameter("menEstmensaje",
		// Constants.TAB_ESTMENSAJE_EN_PROCESO);

		Integer result = query.executeUpdate();
		log.info("cerrar Transaccion hecho ... idsession {} regs: {} ", idsession, result);
		return result;
	}

	/**
	 * Genera el correlativo del mensaje
	 * 
	 * @param menGestion
	 * @param estMensaje
	 * @param menInout
	 * @return
	 */
	private Integer getCorrelativoAsignacion(Integer menGestion, Integer estMensaje, String menInout) {
		Integer codigo = null;
		StringBuilder jpql = new StringBuilder();
		jpql.append("select max(m.menNrocorr) ");
		jpql.append("from SwfMensaje m ");
		jpql.append("where m.menGestion = :menGestion ");
		jpql.append("and m.menInout = :menInout ");

		Query query = entityManager.createQuery(jpql.toString());

		query.setParameter("menGestion", menGestion);
		query.setParameter("menInout", menInout);

		List result = query.getResultList();
		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.info("Nuevo correlativo[" + menInout + "] : " + codigo);
		return codigo;
	}

	private Integer getCorrelativoSwift(String idSistema, String auditWst, String auditUsr) {
		SwfNumeraswf swfNumeraswf = SwfNumeraswfDaoImpl.crearNuevo(null, Constants.TAB_TIPONRO_AUTOMATICO, idSistema);
		swfNumeraswf.setNroAuditwst(auditWst);
		swfNumeraswf.setNroAuditusr(auditUsr);

		Integer nroSwift = numeracionSwiftService.asignacionCorrelativo(swfNumeraswf, null);

		return nroSwift;
	}

	synchronized public SwfMensaje solicitarCorrelativo(String codapp, String codUsuario, String codoperacion, String estacion, String idSession) {
		log.info("Inicio solicitar correlativo codapp {}, codUsuario {}, codoperacion {}, estacion {}, idSession {}", codapp, codUsuario, codoperacion,
				estacion, idSession);

		if (StringUtils.isBlank(codapp)) {
			log.error("Valor codigo de aplicacion invalido ");
			throw new SwiftAdminException("Valor codigo de aplicacion invalido ");
		}
		SwfMensaje swfMensaje = null;
		if (!StringUtils.isBlank(codoperacion)) {
			List<SwfMensaje> swfMensajeLista = findByCodOperacion(codoperacion, codapp);

			for (SwfMensaje swfMensajeOld : swfMensajeLista) {
				// si ya fue registrado se verifica si sus estados
				if (swfMensajeOld.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0) {
					log.error("Mensaje " + swfMensajeOld.getMenCodmen() + ", con codigo operacion [" + codoperacion + "] autorizado "
							+ swfMensajeOld.getMenEstautoriza() + " correlativo " + swfMensajeOld.getMenNrocorr());
					throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con codigo operacion [" + codoperacion + "] autorizado "
							+ swfMensajeOld.getMenEstautoriza() + " correlativo " + swfMensajeOld.getMenNrocorr());
				}

				if ((swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0)) {
					// bloqueado por administrador lavado
					log.info("Mensaje " + swfMensajeOld.getMenCodmen() + " con codigo operacion [" + codoperacion + "] bloqueado "
							+ swfMensajeOld.getMenEstverifica() + " consulte con el administrador [" + swfMensajeOld.getMenUsrlvdverifica()
							+ "] del sistema.");
					throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + " con codigo operacion [" + codoperacion
							+ "] bloqueado consulte con el administrador[usuario: " + swfMensajeOld.getMenUsrlvdverifica() + "] del sistema.");
				}

				if (swfMensajeOld.getMenNrocorr() != null && swfMensajeOld.getMenNrocorr().compareTo(0) >= 0)
					if ((swfMensajeOld.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_REGISTRADO) == 0)
							|| (swfMensajeOld.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_EN_PROCESO) == 0)
							|| (swfMensajeOld.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_PROCESADO) == 0)) {
						log.info("CORRELATIVO: Mensaje registrado {} oper: ", swfMensajeOld.getMenCodmen(), swfMensajeOld.getMenRefer());
						swfMensaje = swfMensajeOld;
						break;
					}
			}
		}
		if (swfMensaje == null) {
			swfMensaje = new SwfMensaje();
			log.info("CORRELATIVO: registrar: mensaje inexistente Codapp: " + codapp + " codoperacion: " + codoperacion);
			Integer perCodigo = getCodigo();
			swfMensaje.setMenCodmen(perCodigo);
			Integer corrNroswift = getCorrelativoSwift(codapp, estacion, codUsuario);

			swfMensaje.setMenNrocorr(corrNroswift);
			swfMensaje.setMenCodapp(codapp);
			swfMensaje.setMenRefer(codoperacion);
			swfMensaje.setMenCodusrswf(codUsuario);
			swfMensaje.setMenFirmaorigen(idSession);
			swfMensaje.setMenInout(Constants.TIPO_MENSAJE_OUT);
			swfMensaje.setMenGestion(GregorianCalendar.getInstance().get(Calendar.YEAR));
			swfMensaje.setMenTabestmensaje(Constants.TAB_ESTMENSAJE);
			swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_REGISTRADO);
			if (!StringUtils.isBlank(swfMensaje.getMenFirmaorigen())) {
				// si existe session se marca con estado en proceso
				swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_EN_PROCESO);
			}
			swfMensaje.setMenTabestverifica(Constants.TAB_ESTVERIFICA);
			swfMensaje.setMenEstverifica(Constants.TAB_ESTVERIFICA_REGISTRADO);
			swfMensaje.setMenTabestautoriza(Constants.TAB_ESTAUTORIZA);
			swfMensaje.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR);
			swfMensaje.setMenAuditusr(codUsuario);
			swfMensaje.setMenAuditfho(new Date());
			swfMensaje.setMenAuditwst(estacion);
			swfMensaje.setMenFecreg(new Date());
			entityManager.persist(swfMensaje);
		} else {
			log.info("CORRELATIVO: actualizar: mensaje existente Codapp: " + codapp + " codoperacion: " + codoperacion);
			swfMensaje.setMenCodusrswf(codUsuario);
			swfMensaje.setMenFirmaorigen(idSession);
			swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_REGISTRADO);
			if (!StringUtils.isBlank(swfMensaje.getMenFirmaorigen())) {
				// si existe session se marca con estado en proceso
				swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_EN_PROCESO);
			}
			swfMensaje.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR);

			swfMensaje.setMenAuditusr(codUsuario);
			swfMensaje.setMenAuditfho(new Date());
			swfMensaje.setMenAuditwst(estacion);
			entityManager.merge(swfMensaje);
		}

		log.info("CORRELATIVO: Creado mensaje swift registrado:{} ", swfMensaje.toString());
		swfMensaje = findByCodigo(swfMensaje.getMenCodmen());
		return swfMensaje;
	}

	public String getDirectorySwiftFromMsg(FileFormat standard) {
		if (PATH_DIR_SWIFT_MT == null || PATH_DIR_SWIFT_MX == null) {
//			SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_PATHDIRSWIFT);
//			if (swfParams == null) {
//				throw new DataException("Parámetro de sistema '" + Constants.PARAM_PATHDIRSWIFT + "' no definido.");
//			}
			SwfParams swfParamsLau = swfParamsDao.findByCod(Constants.PARAM_PATHDIRSWIFTLAU);

			if (swfParamsLau == null) {
				throw new DataException("Parámetro de sistema '" + Constants.PARAM_PATHDIRSWIFTLAU + "' no definido.");
			}
			String dirPath = swfParamsLau.getParValor();

			String pathDirSwift = new File(appProperties.getLavado().getAppdir(), dirPath).getAbsolutePath();

			File f = new File(pathDirSwift);
			if (!f.exists() || !f.isDirectory()) {
				throw new DataException("Directorio swift para MTs inexistente " + pathDirSwift);
			}

			SwfParams swfParamsMx = swfParamsDao.findByCod(Constants.PARAM_PATHDIRSWIFTMX);
			if (swfParamsMx == null) {
				throw new DataException("Parámetro de sistema '" + Constants.PARAM_PATHDIRSWIFTMX + "' no definido.");
			}
			String dirPathMx = swfParamsMx.getParValor();
			String pathDirSwiftMx = new File(appProperties.getLavado().getAppdir(), dirPathMx).getAbsolutePath();

			f = new File(pathDirSwiftMx);
			if (!f.exists() || !f.isDirectory()) {
				throw new DataException("Directorio swift para MXs inexistente " + pathDirSwiftMx);
			}

			PATH_DIR_SWIFT_MT = pathDirSwift;
			PATH_DIR_SWIFT_MX = pathDirSwiftMx;
			log.info("Seteo de dir Swift MTs: {} MXs: {} Hecho!!!", PATH_DIR_SWIFT_MT, PATH_DIR_SWIFT_MX);
		}

		if (standard == FileFormat.MX) {
			return PATH_DIR_SWIFT_MX;
		} else if (standard == FileFormat.MT) {
			return PATH_DIR_SWIFT_MT;
		} else {
			throw new DataException("Formato de mensaje Swift no implementado " + standard.toString());
		}
	}
	
	public void initDataPDU() {
		if (StringUtils.isBlank(pduInfo.getHeader().getMessage().getNetworkInfo().getService())) {
			SwfParams swfParams = swfParamsDao.findByCod("ServiceURI");
			pduInfo.getHeader().getMessage().getInterfaceInfo().setServiceURI(swfParams != null ? swfParams.getParValor() : null);
			swfParams = swfParamsDao.findByCod("MessageTypeURI");
			pduInfo.getHeader().getMessage().getInterfaceInfo().setMessageTypeURI(swfParams != null ? swfParams.getParValor() : null);
			swfParams = swfParamsDao.findByCod("Service");
			pduInfo.getHeader().getMessage().getNetworkInfo().setService(swfParams != null ? swfParams.getParValor() : null);
			swfParams = swfParamsDao.findByCod("RequestSubtype");
			pduInfo.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo().setRequestSubtype(swfParams != null ? swfParams.getParValor() : null);
			log.info("Seteo de info PDUs inicializado: {} {} Hecho!!!", pduInfo.getHeader().getMessage().getNetworkInfo().getService(),
					pduInfo.getHeader().getMessage().getInterfaceInfo().getServiceURI());
		}
	}
	
	public static void main(String[] args) {
		String paramsAdic = new String(Base64.decodeBase64("12345678"));
		System.out.println(paramsAdic);
		Map<String, String> mapParms = UtilsGeneric.paramsLista(paramsAdic);
		System.out.println(mapParms);
	}
}
