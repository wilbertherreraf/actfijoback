package gob.bcb.lavado.strategy;

public class QueryStrategy {
	private String id;
	private String[] junction;	
	private String[] fieldsswf;
	private String[] idqueries;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String[] getFieldsswf() {
		return fieldsswf;
	}
	public void setFieldsswf(String[] fieldsswf) {
		this.fieldsswf = fieldsswf;
	}
	public String[] getIdqueries() {
		return idqueries;
	}
	public void setIdqueries(String[] idqueries) {
		this.idqueries = idqueries;
	}
	public String[] getJunction() {
		return junction;
	}
	public void setJunction(String[] junction) {
		this.junction = junction;
	}	
}
