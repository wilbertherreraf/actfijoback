package gob.bcb.lavado.services;

import gob.bcb.core.utils.ArchivoSinple;

public interface ReporteSwiftService {

	ArchivoSinple generarReportePDFFromPlano(String menPlano, String codUsuario, Integer menCodmen);

}