package gob.bcb.lavado.search;

import gob.bcb.lavado.search.facet.FacetQueryOfac;

/**
 * Interface for the creation of new CandidateMatcher objects
 * @param <T> a subclass of {@link uk.co.flax.luwak.CandidateMatcher}
 */
public interface MatcherFactory<T extends QueryMatch> {

    /**
     * Create a new {@link CandidateMatcher} object
     * @param doc an {@link DocumentBatch} to match.
     * @return the CandidateMatcher
     */
    CandidateMatcher<T> createMatcher(DocumentBatch doc, FacetQueryOfac facetQueryOfac);
}
