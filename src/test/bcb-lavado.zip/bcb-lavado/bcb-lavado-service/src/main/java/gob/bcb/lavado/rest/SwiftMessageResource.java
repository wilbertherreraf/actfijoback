package gob.bcb.lavado.rest;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.lavado.client.HandlerGeneratorLauSrv;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.services.SessionsSearcherService;
import gob.bcb.lavado.services.SwiftBcbSearcherService;
import gob.bcb.lavado.services.SwiftBcbSearcherServiceImpl;

@RestController
@RequestMapping(Constants.PATH_RESOURCE_API_SEARCH)

public class SwiftMessageResource {
	private final Logger log = LoggerFactory.getLogger(SwiftMessageResource.class);
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;

	@Autowired
	private SessionsSearcherService sessionsSearcherService;

	@RequestMapping(value = "/lvd-inisesion", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SearchResponse> getSessionLavado(@RequestParam(value = "codapp") String codapp, @RequestParam(value = "coduser") String coduser,
			@RequestParam(value = "tenc") String tenc, @RequestParam(value = "ctrlcode") String ctrlcode, @RequestParam(value = "ctrldata") String ctrldata,
			HttpServletRequest request) {
		log.info("REST request lvd-inisesion:=> para solicitar SESSION codapp {} coduser {}", codapp, coduser);
		SearchResponse searchResponse = beginSession(codapp, coduser, tenc, ctrlcode, ctrldata, request.getRemoteAddr());

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	@RequestMapping(value = "/lvd-inicia", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SearchResponse> getSessionLavado(@RequestParam(value = "codapp") String codapp, @RequestParam(value = "coduser") String coduser,
			HttpServletRequest request) {
		log.info("REST request lvd-ini:=> para solicitar SESSION codapp {} coduser {}", codapp, coduser);
		SearchResponse searchResponse = beginSession(codapp, coduser, null, null, null, request.getRemoteAddr());

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	@RequestMapping(value = "/scan-correlativo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SearchResponse> solicitarCorrelativo(@RequestParam(value = "codapp") String codapp,
			@RequestParam(value = "idop") String codoperacion, @RequestParam(value = "coduser") String coduser,
			@RequestParam(value = "idsession") String idsession, HttpServletRequest request) {

		log.info("REST request:=> para solicitar correlativo codapp {} codoperacion {} user {} idsession {}", codapp, codoperacion, coduser, idsession);
		try {
			sessionsSearcherService.validateSession(idsession, codapp);
			SearchResponse searchResponse = swiftBcbSearcherService.solicitarCorrelativo(codapp, codoperacion, coduser, idsession, request.getRemoteAddr());
			sessionsSearcherService.revalidateSession(idsession, codapp);
			
			return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
					.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			SearchResponse searchResponseEx = SwiftBcbSearcherServiceImpl.getSearchResultFromException(e);
			return Optional.ofNullable(searchResponseEx).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
					.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		}
	}

	@RequestMapping(value = "/scan-registro", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SearchResponse> scanSwift(@RequestParam(value = "codapp") String codapp, @RequestParam(value = "coduser") String coduser,
			@RequestParam(value = "codlvd") String codlvd, @RequestParam(value = "nroswf") String nroCorrelativo,
			@RequestParam(value = "idop") String codoperacion, @RequestParam(value = "idsession") String idSession,
			@RequestParam(value = "swfp") String menPlanoIn, @RequestParam(value = "clau", required = false) String clau, HttpServletRequest request) {

		String menPlano = ArchivoUtil.decodeFromUri(menPlanoIn);
		SearchResponse searchResponseError = SwiftBcbSearcherServiceImpl.createResponse(Constants.COD_RESP_ERR_02, 1, null, null);

		log.info("REST scan-registro:=> app {} usr {} codlvd {} idoperacion {} session {} clau {}", codapp, coduser, codlvd, codoperacion, idSession, clau);

		if (StringUtils.isBlank(codlvd) || !NumberUtils.isNumber(codlvd)) {
			searchResponseError.setDescripResp("Parámetro codlvd debe ser un valor entero");
			return Optional.ofNullable(searchResponseError).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
					.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		}
		if (StringUtils.isBlank(nroCorrelativo) || !NumberUtils.isNumber(nroCorrelativo)) {
			searchResponseError.setDescripResp("Parámetro nroCorrelativo debe ser un valor entero");
			return Optional.ofNullable(searchResponseError).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
					.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		}
		try {
			sessionsSearcherService.validateSession(idSession, codapp);
			Integer codlvdInt = Integer.valueOf(codlvd);
			Integer nroCorrelativoInt = Integer.valueOf(nroCorrelativo);

			SearchResponse searchResponse = swiftBcbSearcherService.scanMensajePlanoConCorrSolicitado(menPlano, codapp, codlvdInt, nroCorrelativoInt,
					codoperacion, coduser, request.getRemoteAddr(), idSession, clau);

			sessionsSearcherService.revalidateSession(idSession, codapp);

			log.info("### ANTES DE RETORNO scan-registro [" + searchResponse.getCountRegs() + "]###");

			return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
					.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			SearchResponse searchResponseEx = SwiftBcbSearcherServiceImpl.getSearchResultFromException(e);
			return Optional.ofNullable(searchResponseEx).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
					.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		}
	}

	@RequestMapping(value = "/scan-preaut", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SearchResponse> preautorizarSwift(@RequestParam(value = "codapp") String codapp, @RequestParam(value = "coduser") String coduser,
			@RequestParam(value = "codlvd") String codlvd, @RequestParam(value = "nroswf") String nroCorrelativo,
			@RequestParam(value = "idop") String codoperacion, @RequestParam(value = "idsession") String idSession,
			@RequestParam(value = "swfp") String menPlanoIn, @RequestParam(value = "clau", required = false) String clau, HttpServletRequest request) {

		String menPlano = ArchivoUtil.decodeFromUri(menPlanoIn);
		SearchResponse searchResponseError = SwiftBcbSearcherServiceImpl.createResponse(Constants.COD_RESP_ERR_02, 1, null, null);

		log.info("REST request preautoriza:=> pre autorizar swift scaneado app {} usr {} codlvd {} idoperacion {} session {} clau {}", codapp, coduser,
				codlvd, codoperacion, idSession, clau);

		if (StringUtils.isBlank(codlvd) || !NumberUtils.isNumber(codlvd)) {
			searchResponseError.setDescripResp("Parámetro codlvd debe ser un valor entero");
			return Optional.ofNullable(searchResponseError).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
					.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		}
		try {
			sessionsSearcherService.validateSession(idSession, codapp);
			Integer codlvdInt = Integer.valueOf(codlvd);
			SearchResponse searchResponse = swiftBcbSearcherService.preAutorizaSwift(codlvdInt, codapp, coduser, codoperacion, idSession, menPlano,
					request.getRemoteAddr(), clau);

			sessionsSearcherService.revalidateSession(idSession, codapp);

			log.info("### ANTES DE RETORNO preautoriza [" + searchResponse.getCountRegs() + "]###");
//			if (searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
//				swfMensajeDao.guardarEnImportados(codlvdInt, coduser, null, request.getRemoteAddr());
//			}

			return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
					.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			SearchResponse searchResponseEx = SwiftBcbSearcherServiceImpl.getSearchResultFromException(e);
			return Optional.ofNullable(searchResponseEx).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
					.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
		}
	}

	@RequestMapping(value = "/lvd-fin", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SearchResponse> endSession(@RequestParam(value = "codapp") String codapp, @RequestParam(value = "coduser") String coduser,
			@RequestParam(value = "idsession") String idSession, HttpServletRequest request) {

		log.info("REST request lvd-fin:=> fin session app {} usr {} session {}", codapp, coduser, idSession);

		sessionsSearcherService.validateSession(idSession, codapp);
		sessionsSearcherService.closeSession(idSession);
		
		SearchResponse searchResponse = swiftBcbSearcherService.endSession(codapp, idSession, coduser, request.getRemoteAddr());

		log.info("### ANTES DE RETORNO lvd-fin [" + searchResponse.getCountRegs() + "]###");

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	/**
	 * SEARCH /_search/scan-single?query=:query : search for swift in the text plain
	 * corresponding to the query. Not send mail and not save in DB
	 *
	 * @param query text swift
	 * @return the result of the search
	 */
	@RequestMapping(value = "/scan-single", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, params = { "query" })
	public ResponseEntity<SearchResponse> searchScanSingle(@RequestParam(value = "query") String menPlano, HttpServletRequest request) {
		log.info("REST request:=> to search searchScanSingle for query " + request.getRemoteAddr());
		log.info(menPlano);
		SearchResponse searchResponse = swiftBcbSearcherService.searchScanSingle(menPlano, true);

		log.info("### ### ### ANTES DE RETORNO [" + searchResponse.getCountRegs() + "]### ### ###");

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	/**
	 * SEARCH /_search/scan-field?query=:query&field=:field : search for swift in
	 * the text plain corresponding to the query.
	 * 
	 * @param query      texto a buscar
	 * @param fieldSwift codigo de consulta
	 * @return
	 */
	@RequestMapping(value = "/scan-field", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, params = { "query", "field" })
	public ResponseEntity<SearchResponse> searchScanField(@RequestParam(value = "query") String query, @RequestParam(value = "field") String fieldSwift,
			HttpServletRequest request) {
		log.info("REST request:=> to search for searchScanField query {} field{}", query, fieldSwift);

		SearchResponse searchResponse = swiftBcbSearcherService.verificarMensaje(query, fieldSwift);

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	public SearchResponse beginSession(String codapp, String coduser, String typeEnc, String ctrlcode, String ctrldata, String estacion) {
		try {
			SearchResponse searchResponse = HandlerGeneratorLauSrv.getCurrentInstanceHGen().validateAndReponse(codapp, ctrldata, ctrlcode, typeEnc);

			if (!StringUtils.isBlank(searchResponse.getCodoperacion()) && searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)) {
				sessionsSearcherService.createSession(searchResponse.getCodoperacion(), codapp);
				log.info("INICIO SESSION codapp {} coduser {} estacion {} session {}", codapp, coduser, estacion, searchResponse.getCodoperacion());
			}

			return searchResponse;
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			return SwiftBcbSearcherServiceImpl.getSearchResultFromException(e);
		}
	}
}
