package gob.bcb.lavado.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaNationality;

@Repository
public interface OfaNationalityRepository extends JpaRepository<OfaNationality,Integer>{

}
