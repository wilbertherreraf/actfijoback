package gob.bcb.lavado.model;

import java.io.Serializable;

public interface DomainObject extends Serializable {

}
