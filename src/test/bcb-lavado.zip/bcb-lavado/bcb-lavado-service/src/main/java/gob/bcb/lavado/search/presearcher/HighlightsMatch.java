package gob.bcb.lavado.search.presearcher;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.lucene.analysis.standard.StandardAnalyzer;

import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.QueryMatch;
import gob.bcb.lavado.search.analysis.ShingleAnalyzer;

/**
 * QueryMatch object that contains the hit positions of a matching Query
 *
 * If the Query does not support interval iteration (eg, if it gets re-written to
 * a Filter), then no hits will be reported, but an IntervalsQueryMatch will still
 * be returned from an IntervalsMatcher to indicate a match.
 */
public class HighlightsMatch extends QueryMatch {

    private final Map<String, Set<Hit>> hits;
    public String error;

    /**
     * Create a new QueryMatch object for a query
     *
     * @param queryId the ID of the query
     * @param hits the hits recorded for this query
     */
    public HighlightsMatch(String queryId, String docId, Map<String, Set<Hit>> hits) {
        super(queryId, docId);
        this.hits = new TreeMap<>(hits);
    }

    public HighlightsMatch(String queryId, String docId) {
        super(queryId, docId);
        this.hits = new TreeMap<>();
    }

    /**
     * @return the fields in which matches have been found
     */
    public Set<String> getFields() {
        return hits.keySet();
    }

    /**
     * Get the hits for a specific field
     * @param field the field
     * @return the Hits found in this field
     */
    public Collection<Hit> getHits(String field) {
        if (hits.containsKey(field))
            return Collections.unmodifiableCollection(hits.get(field));
        return new LinkedList<>();
    }

    /**
     * @return the total number of hits for the query
     */
    public int getHitCount() {
        int c = 0;
        for (Set<Hit> fieldhits : hits.values()) {
            c += fieldhits.size();
        }
        return c;
    }

    public static HighlightsMatch merge(String queryId, String docId, HighlightsMatch... matches) {
        HighlightsMatch newMatch = new HighlightsMatch(queryId, docId);
        for (HighlightsMatch match : matches) {
            assert newMatch.getDocId().equals(match.getDocId());
            for (String field : match.getFields()) {
                if (!newMatch.hits.containsKey(field))
                    newMatch.hits.put(field, new TreeSet<Hit>());
                newMatch.hits.get(field).addAll(match.getHits(field));
            }
        }
        return newMatch;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HighlightsMatch)) return false;
        if (!super.equals(o)) return false;

        HighlightsMatch that = (HighlightsMatch) o;

        if (hits != null ? !hits.equals(that.hits) : that.hits != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (hits != null ? hits.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        if (error == null)
            return super.toString() + "{hits=" + hits + "}";
        return super.toString() + "{error=" + error + "}";
    }

    public Hit addHit(String field, int startPos, int endPos, int startOffset, int endOffset) {
        if (!hits.containsKey(field))
            hits.put(field, new TreeSet<Hit>());
        Hit hit = new Hit(startPos, startOffset, endPos, endOffset);
        hits.get(field).add(hit);
        return hit;
    }

    /**
     * Represents an individual hit
     */
    public static class Hit implements Comparable<Hit> {
    	public String text;
        /** The start position */
        public final int startPosition;

        /** The start offset */
        public final int startOffset;

        /** The end positions */
        public final int endPosition;

        /** The end offset */
        public final int endOffset;

        public Hit(int startPosition, int startOffset, int endPosition, int endOffset) {
            this(null, startPosition, startOffset, endPosition, endOffset);
        }
        public Hit(String text, int startPosition, int startOffset, int endPosition, int endOffset) {
            this.startPosition = startPosition;
            this.startOffset = startOffset;
            this.endPosition = endPosition;
            this.endOffset = endOffset;
            this.text = text;
        }
        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (!(obj instanceof Hit))
                return false;
            Hit other = (Hit) obj;
            return this.startOffset == other.startOffset &&
                    this.endOffset == other.endOffset &&
                    this.startPosition == other.startPosition &&
                    this.endPosition == other.endPosition;
        }

        @Override
        public int hashCode() {
            int result = startPosition;
            result = 31 * result + startOffset;
            result = 31 * result + endPosition;
            result = 31 * result + endOffset;
            return result;
        }

        @Override
        public String toString() {
            return String.format(Locale.ROOT, "%d(%d)->%d(%d)", startPosition, startOffset, endPosition, endOffset);
        }

        @Override
        public int compareTo(Hit other) {
            if (this.startPosition != other.startPosition)
                return Integer.compare(this.startPosition, other.startPosition);
            return Integer.compare(this.endPosition, other.endPosition);
        }

		public String getText() {
			return text;
		}

		public void setText(String text) {
			this.text = text;
		}
    }
}
