package gob.bcb.lavado.repository;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.core.utils.AccessorsUtil;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.DomainObject;
import gob.bcb.lavado.pojos.GenUsuario;

public abstract class GenericDaoJpa<T extends DomainObject> implements GenericDao<T> {
	private static final Logger log = LoggerFactory.getLogger(GenericDaoJpa.class);
	private Class<T> type;

	protected EntityManager entityManager;
	
	private String fieldAuditAuditfho;
	private String fieldAuditAuditusr;
	private String fieldAuditAuditwst;
	private GenUsuario genUsuario;

	public GenericDaoJpa(Class<T> type) {
		super();
		this.type = type;
		log.info("Creando DAO SWF " + type.getName());
	}

	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)	
	public void setEntityManager(EntityManager entityManager) {
		log.info("inject EntityManager en swift ...");
		this.entityManager = entityManager;
	}
	public T get(Long id) {
		return (T) entityManager.find(type, id);
	}

	public List<T> getAll() {
		return entityManager.createQuery("select obj from " + type.getName() + " obj").getResultList();
	}

	public void save(T object) {
		audit(object);
		entityManager.persist(object);
		log.debug("::Nuevo registro " + object.getClass().getSimpleName() + "=>" + object.toString());
	}

	public T update(T object) {
		audit(object);
		log.debug("::Modificacion registro " + object.getClass().getSimpleName() + "=>" + object.toString());
		return (T) entityManager.merge(object);

	}

	public void delete(T object) {
		log.warn("Eliminando " + object.toString() + " AuditAuditfho "
				+ UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy H:mm:ss") + (genUsuario != null ? " AuditAuditusr "
						+ genUsuario.getUsrAuditusr() + " AuditAuditwst " + genUsuario.getUsrAuditwst() : ""));
		entityManager.remove(object);
	}

	private void audit(T object) {

		if (fieldAuditAuditusr == null) {
			List<String> fieldsAudit0 = AccessorsUtil.extractFieldsList(type);
			for (String field : fieldsAudit0) {
				if (field.contains("Auditfho")) {
					fieldAuditAuditfho = "set" + Character.toUpperCase(field.charAt(0)) + field.substring(1);
				} else if (field.contains("Auditusr")) {
					fieldAuditAuditusr = "set" + Character.toUpperCase(field.charAt(0)) + field.substring(1);
				} else if (field.contains("Auditwst")) {
					fieldAuditAuditwst = "set" + Character.toUpperCase(field.charAt(0)) + field.substring(1);
				}
			}

			log.info("Campos AUDIT seteado " + type.getName() + " " + fieldAuditAuditfho + " " + fieldAuditAuditusr
					+ " " + fieldAuditAuditwst);
		}
		if (fieldAuditAuditfho != null) {
			try {
				Method method = type.getMethod(fieldAuditAuditfho, Date.class);
				method.invoke(object, new Date());
			} catch (Exception ex) {
				;
			}
		}

		if (genUsuario != null) {
			if (fieldAuditAuditusr != null) {
				try {
					Method method = type.getMethod(fieldAuditAuditusr, String.class);
					method.invoke(object, genUsuario.getUsrAuditusr());
				} catch (Exception ex) {
					;
				}

			}
			if (fieldAuditAuditwst != null) {
				try {
					Method method = type.getMethod(fieldAuditAuditwst, String.class);
					method.invoke(object, genUsuario.getUsrAuditwst());
				} catch (Exception ex) {
					;
				}
			}

		}
	}

	public GenUsuario getGenUsuario() {
		return genUsuario;
	}

	public void setGenUsuario(GenUsuario genUsuario) {
		this.genUsuario = genUsuario;
	}
}
