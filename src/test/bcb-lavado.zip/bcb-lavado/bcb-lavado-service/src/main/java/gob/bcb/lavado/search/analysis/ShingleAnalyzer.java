package gob.bcb.lavado.search.analysis;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.shingle.ShingleAnalyzerWrapper;
import org.apache.lucene.analysis.shingle.ShingleFilter;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.presearcher.HighlightsMatch.Hit;

public class ShingleAnalyzer {
	private static final Logger log = LoggerFactory.getLogger(ShingleAnalyzer.class);
	public static final int DEFAULT_MIN_WORD_LENGTH = 1; 
	public static final int DEFAULT_MAX_WORD_LENGTH = 0;
	public static final int DEFAULT_MAX_QUERY_TERMS = 25;
	public static final int DEFAULT_MAX_NUM_TOKENS_PARSED = 88;

	public static int minWordLen = DEFAULT_MIN_WORD_LENGTH;
	public static int maxWordLen = DEFAULT_MAX_WORD_LENGTH;

	public static String[] termFrequencies(String field, String query, int minShingleSize, int maxShingleSize, int maxShingleStop, int minWordLen, boolean exceptNumbers,
			Analyzer analyzer) {
		List<Hit> hits = termFrequenciesHit(field, query, minShingleSize, maxShingleSize, maxShingleStop, minWordLen, exceptNumbers, analyzer);
		String[] res = new String[hits.size()];
		return hits.stream().map(Hit::getText).collect(Collectors.toList()).toArray(res);
	}

	public static List<Hit> termFrequenciesHit(String field, String query, int minShingleSize, int maxShingleSize, int maxShingleStop, int minWordLen, boolean exceptNumbers,
			Analyzer analyzer) {
		List<Hit> hits = new ArrayList<>();

		try {
			query = StringUtils.trimToEmpty(query);
			ShingleAnalyzerWrapper shingleAnalyzerWrapper = new ShingleAnalyzerWrapper(analyzer, (minShingleSize <= 1 ? 2 : minShingleSize), maxShingleSize,
					ShingleFilter.DEFAULT_TOKEN_SEPARATOR, false, false, null);

			try (TokenStream ts = shingleAnalyzerWrapper.tokenStream(field, query)) {
				CharTermAttribute termAtt = ts.addAttribute(CharTermAttribute.class);
				OffsetAttribute offsets = ts.addAttribute(OffsetAttribute.class);
				PositionIncrementAttribute posIncrAtt = ts.addAttribute(PositionIncrementAttribute.class);
				ts.reset();
				int j = -1;
				int tokenCount = 0;
				while (ts.incrementToken()) {
					tokenCount++;
					if (tokenCount > DEFAULT_MAX_NUM_TOKENS_PARSED) {
						break;
					}
					String termText = termAtt.toString();
					j += posIncrAtt.getPositionIncrement();

					if (maxShingleStop > 0 && j > maxShingleStop) {
						// la posicion del token inicial es mayor a maximo
						// permitido
						break;
					}

					if (exceptNumbers && isNumber(termText))
						continue;

					if (isNoiseWord(termText, minWordLen))
						continue;

					hits.add(new Hit(termText, j, offsets.startOffset(), j, offsets.endOffset()));
				}
				ts.end();
			}
			shingleAnalyzerWrapper.close();

			if (hits.size() == 0) {
				hits = retrieveCandidatesTermsHit(query, minWordLen, exceptNumbers, analyzer);
			}
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return hits;
	}

	public static String[] retrieveCandidatesTerms(String query, int minWordLen, boolean exceptNumbers, Analyzer analyzer) {
		List<Hit> hits = retrieveCandidatesTermsHit(query, minWordLen, exceptNumbers, analyzer);
		String[] res = new String[hits.size()];
		return hits.stream().map(Hit::getText).collect(Collectors.toList()).toArray(res);
	}

	public static List<Hit> retrieveCandidatesTermsHit(String query, int minWordLen, boolean exceptNumbers, Analyzer analyzer) {
		List<Hit> hits = new ArrayList<>();
		try {
			log.debug("retrieveCandidatesTermsHit minWordLen {}, exceptNumbers? {} ",minWordLen, exceptNumbers);
			query = StringUtils.trimToEmpty(query);
			try (TokenStream ts = analyzer.tokenStream("field", query)) {
				CharTermAttribute termAtt = ts.addAttribute(CharTermAttribute.class);
				OffsetAttribute offsets = ts.addAttribute(OffsetAttribute.class);
				PositionIncrementAttribute posIncrAtt = ts.addAttribute(PositionIncrementAttribute.class);
				ts.reset();
				int j = -1;
				while (ts.incrementToken()) {
					String termText = termAtt.toString();
					log.debug("termText " + termText);
					j += posIncrAtt.getPositionIncrement();
					if (exceptNumbers && isNumber(termText))
						continue;

					if (isNoiseWord(termText, minWordLen))
						continue;

					hits.add(new Hit(termText, j, offsets.startOffset(), j, offsets.endOffset()));
				}
				ts.end();
			}

		} catch (IOException e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return hits;
	}

	private static boolean isNoiseWord(String term, int minWordLen) {
		int len = term.length();
		return (minWordLen > 0 && len < minWordLen);
	}

	public static boolean isNumber(String term) {
		//StringTokenizer st = new StringTokenizer(term, ";,");
		String[] st = StringUtils.splitByWholeSeparator(term, ";|,");
		st = term.split(";|,");
		for (int i = 0; i < st.length; i++) {
			String token = st[i].trim();
			log.debug("token  " + token + " " + NumberUtils.isNumber(token)  + " " + token.matches(".*\\d.*"));
			if (NumberUtils.isNumber(token) || token.matches(".*\\d.*")) {
				return true;
			}
		}
		return false;
	}

}
