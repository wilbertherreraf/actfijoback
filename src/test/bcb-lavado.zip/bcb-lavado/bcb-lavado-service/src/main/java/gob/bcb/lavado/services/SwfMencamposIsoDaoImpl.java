package gob.bcb.lavado.services;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import gob.bcb.iso20022.dao.SwfMencamposIsoDao;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.lavado.model.SwfMencamposDb;
import gob.bcb.lavado.repository.SwfMencamposDbDao;

public class SwfMencamposIsoDaoImpl implements SwfMencamposIsoDao {
	private SwfMencamposDbDao swfMencamposDbDao;
	
	public SwfMencamposIsoDaoImpl(SwfMencamposDbDao swfMencamposDbDao) {
		this.swfMencamposDbDao = swfMencamposDbDao;
	}

	public List<SwfMencampos> opcionesDeCampo(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		return swfMencamposDbDao.opcionesDeCampo(mtfCodmt, mtfNro, mtfGrpopt, mtfBloque).stream().map(cloneSwfMencamposDb()).collect(Collectors.toList());
	}

	public List<SwfMencampos> findByMtCampo(String mtfCodmt, String mtfCodcampo) {
		return swfMencamposDbDao.findByMtCampo(mtfCodmt, mtfCodcampo).stream().map(cloneSwfMencamposDb()).collect(Collectors.toList());
	}
	
	public Optional<SwfMencampos> nextGrpoptSwfMencampos(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfCodcampo, String mtfBloque) {
		Optional<SwfMencamposDb> tOpt = swfMencamposDbDao.nextGrpoptSwfMencamposDb(mtfCodmt, mtfNro, mtfGrpopt, mtfCodcampo, mtfBloque);
		return tOpt.flatMap(tt -> Optional.of(cloneSwfMencamposDb().apply(tt)));
	}

	public Optional<SwfMencampos> nextNroSwfMencampos(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		Optional<SwfMencamposDb> tOpt = swfMencamposDbDao.nextNroSwfMencamposDb(mtfCodmt, mtfNro, mtfGrpopt, mtfBloque);
		return tOpt.flatMap(tt -> Optional.of(cloneSwfMencamposDb().apply(tt)));
	}

	public Optional<SwfMencampos> nextNroSwfMencampos(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque, Integer mtfNivel) {
		Optional<SwfMencamposDb> tOpt = swfMencamposDbDao.nextNroSwfMencamposDb(mtfCodmt, mtfNro, mtfGrpopt, mtfBloque, mtfNivel);
		return tOpt.flatMap(tt -> Optional.of(cloneSwfMencamposDb().apply(tt)));
	}

	public List<SwfMencampos> findByMT(String mtfCodmt, String mtfBloque) {
		return swfMencamposDbDao.findByMT(mtfCodmt, mtfBloque).stream().map(cloneSwfMencamposDb()).collect(Collectors.toList());
	}

	public List<SwfMencampos> findByCodigoBlk(String mtfCodmt, String mtfCodcampo, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		return swfMencamposDbDao.findByCodigoBlk(mtfCodmt, mtfCodcampo, mtfNro, mtfGrpopt, mtfBloque).stream().map(cloneSwfMencamposDb())
				.collect(Collectors.toList());
	}

	@Override
	public List<SwfMencampos> findById(Integer mtfId) {
		// TODO Auto-generated method stub
		return null;
	}

	public static Function<SwfMencamposDb, SwfMencampos> cloneSwfMencamposDb() {
		return (swfMencamposDbOld) -> {
			if (swfMencamposDbOld == null) {
				return null;
			}

			SwfMencampos swfMencamposDbNew = new SwfMencampos();
			swfMencamposDbNew.setMtfId(swfMencamposDbOld.getMtfId());
			swfMencamposDbNew.setMtfCodmt(swfMencamposDbOld.getMtfCodmt());
			swfMencamposDbNew.setMtfNro(swfMencamposDbOld.getMtfNro());
			swfMencamposDbNew.setMtfGrpopt(swfMencamposDbOld.getMtfGrpopt());
			swfMencamposDbNew.setMtfCodcampo(swfMencamposDbOld.getMtfCodcampo());
			swfMencamposDbNew.setMtfNemo(swfMencamposDbOld.getMtfNemo());
			swfMencamposDbNew.setMtfBloque(swfMencamposDbOld.getMtfBloque());
			swfMencamposDbNew.setMtfCondicion(swfMencamposDbOld.getMtfCondicion());
			swfMencamposDbNew.setMtfDatoadic(swfMencamposDbOld.getMtfDatoadic());
			swfMencamposDbNew.setMtfDefault(swfMencamposDbOld.getMtfDefault());
			swfMencamposDbNew.setMtfDescrip(swfMencamposDbOld.getMtfDescrip());
			swfMencamposDbNew.setMtfExpresion(swfMencamposDbOld.getMtfExpresion());
			swfMencamposDbNew.setMtfFormato(swfMencamposDbOld.getMtfFormato());
			swfMencamposDbNew.setMtfReglaswf(swfMencamposDbOld.getMtfReglaswf());
			swfMencamposDbNew.setMtfReglavalid(swfMencamposDbOld.getMtfReglavalid());
			swfMencamposDbNew.setMtfSecpadre(swfMencamposDbOld.getMtfSecpadre());
			swfMencamposDbNew.setMtfStatus(swfMencamposDbOld.getMtfStatus());
			swfMencamposDbNew.setMtfTipocampo(swfMencamposDbOld.getMtfTipocampo());
			swfMencamposDbNew.setMtfEstado(swfMencamposDbOld.getMtfEstado());
			swfMencamposDbNew.setMtfIndexiso(swfMencamposDbOld.getMtfIndexiso());
			swfMencamposDbNew.setMtfNivel(swfMencamposDbOld.getMtfNivel());
			swfMencamposDbNew.setMtfXmltag(swfMencamposDbOld.getMtfXmltag());
			swfMencamposDbNew.setMtfCardinal(swfMencamposDbOld.getMtfCardinal());
			swfMencamposDbNew.setMtfCambiavalor(swfMencamposDbOld.getMtfCambiavalor());
			swfMencamposDbNew.setMtfMinimo(swfMencamposDbOld.getMtfMinimo());
			swfMencamposDbNew.setMtfValidacionerror(swfMencamposDbOld.getMtfValidacionerror());
			swfMencamposDbNew.setMtfCambiatipousr(swfMencamposDbOld.getMtfCambiatipousr());
			swfMencamposDbNew.setMtfCardinalmult(swfMencamposDbOld.getMtfCardinalmult());
			swfMencamposDbNew.setMtfSinonimos(swfMencamposDbOld.getMtfSinonimos());
			swfMencamposDbNew.setMtfConvalornoreq(swfMencamposDbOld.getMtfConvalornoreq());
			swfMencamposDbNew.setMtfEsopcional(swfMencamposDbOld.getMtfEsopcional());
			swfMencamposDbNew.setMtfEsadicional(swfMencamposDbOld.getMtfEsadicional());
			swfMencamposDbNew.setMtfSubaction1(swfMencamposDbOld.getMtfSubaction());
			swfMencamposDbNew.setMtfSubaction2(swfMencamposDbOld.getMtfSubaction2());
			swfMencamposDbNew.setMtfSubaction3(swfMencamposDbOld.getMtfSubaction3());
			swfMencamposDbNew.setMtfSubaction4(swfMencamposDbOld.getMtfSubaction4());
			swfMencamposDbNew.setMtfSubaction5(swfMencamposDbOld.getMtfSubaction5());

			return swfMencamposDbNew;
		};
	}

}
