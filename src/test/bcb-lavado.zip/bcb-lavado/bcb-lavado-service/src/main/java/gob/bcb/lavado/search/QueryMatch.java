package gob.bcb.lavado.search;

import java.util.Objects;

/**
 * Represents a match for a specific query and document
 *
 * Derived classes may contain more information (such as scores, highlights, etc)
 *
 */
public class QueryMatch {

    private final String queryId;

    private final String docId;

    /**
     * Creates a new QueryMatch for a specific query and document
     * @param queryId the query id
     * @param docId the document id
     */
    public QueryMatch(String queryId, String docId) {
        this.queryId = Objects.requireNonNull(queryId);
        this.docId = Objects.requireNonNull(docId);
    }

    /**
     * @return the queryid of this match
     */
    public String getQueryId() {
        return queryId;
    }

    /**
     * @return the docid of this match
     */
    public String getDocId() {
        return docId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof QueryMatch)) return false;
        QueryMatch that = (QueryMatch) o;
        return Objects.equals(queryId, that.queryId) && Objects.equals(docId, that.docId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(queryId, docId);
    }

    @Override
    public String toString() {
        return "Match(doc=" + docId + ",query=" + queryId + ")";
    }
}
