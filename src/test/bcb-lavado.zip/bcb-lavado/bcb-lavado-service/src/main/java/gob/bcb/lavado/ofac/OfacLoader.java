package gob.bcb.lavado.ofac;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;

import javax.xml.transform.Source;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.oxm.Unmarshaller;
import org.springframework.oxm.XmlMappingException;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.model.OfaAddresslist;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaCitizenship;
import gob.bcb.lavado.model.OfaDateofbirth;
import gob.bcb.lavado.model.OfaIdlist;
import gob.bcb.lavado.model.OfaNationality;
import gob.bcb.lavado.model.OfaPlaceofbirth;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.model.OfaVesselinfo;
import gob.bcb.lavado.ofac.dto.OfacListas;
import gob.bcb.lavado.ofac.dto.SdnListDTO;
import gob.bcb.lavado.ofac.ue.dto.SanctionEntityToOfacEntryDto;
import gob.bcb.lavado.ofac.ue.model.SanctionEntity;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry;

@Component
public class OfacLoader {
	private static final Logger log = LoggerFactory.getLogger(OfacLoader.class);

	static final String cad_sdnList = "sdnList";
	static final String cad_sanctionEntity = "sanctionEntity";

	public static Integer numitems = 250;

	public static List<ImmutablePair<Integer, List<OfaSdnentry>>> convertFileXMLInmutable(Integer nroLote, String fileSdn) {

		List<OfaSdnentry> sdnEntryList = readFileToOfaSdnentryToLista(nroLote, fileSdn);
		List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableList = splitLista(sdnEntryList, numitems);
		return immutableList;
	}

	public static List<OfaSdnentry> readFileToOfaSdnentryToLista(Integer nroLote, String pathFile) {
		boolean isOFAC = existString(pathFile, cad_sdnList);

		log.info("readFileToOfaSdnentry: Cargando LISTA OFAC {} {}", pathFile, isOFAC);
		List<OfaSdnentry> ofaSdnentryList = new ArrayList<>();

		try (FileInputStream fis = new FileInputStream(new File(pathFile));) {
			String result = IOUtils.toString(fis, "UTF-8"); // "ISO-8859-1"
			result = result.replaceAll("’", "'").replaceAll("‘", "'").replaceAll("“", " ").replaceAll("”", " ");
			result = stripAccents(result);
			// convertimos a utf-8 para asegurar el salvado en bdd

			InputStream is = new ByteArrayInputStream(result.getBytes());
			Resource inputSDNXML = new InputStreamResource(is);

			StaxEventItemReader<OfaSdnentry> itemReaderxml = null;
			if (isOFAC) {
				itemReaderxml = (StaxEventItemReader<OfaSdnentry>) createItemReaderXml(inputSDNXML);
			} else {
				itemReaderxml = (StaxEventItemReader<OfaSdnentry>) createItemReaderXmlUE(inputSDNXML);
			}

			itemReaderxml.open(new ExecutionContext());
			OfaSdnentry ofaSdnentry = null;
			while ((ofaSdnentry = itemReaderxml.read()) != null) {
				ofaSdnentry.setSdnIdlista(isOFAC ? "OFAC" : "UE");
				ofaSdnentry.setSdnNrolote(nroLote);
				ofaSdnentryList.add(ofaSdnentry);
			}
			log.info("end read con {}", ofaSdnentryList.size());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return ofaSdnentryList;
	}

	public static ItemReader<OfaSdnentry> createItemReaderXml(Resource inputSDNXML) {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setClassesToBeBound(SdnEntry.class);
		jaxb2Marshaller.setMappedClass(SdnEntry.class);

		// Create JAXB Context
		StaxEventItemReader<OfaSdnentry> staxEventItemReader = new StaxEventItemReader<OfaSdnentry>();
		staxEventItemReader.setFragmentRootElementNames("publshInformation,sdnEntry".split(","));
		staxEventItemReader.setFragmentRootElementName("sdnEntry");
		staxEventItemReader.setResource(inputSDNXML);

		staxEventItemReader.setUnmarshaller(new Unmarshaller() {
			@Override
			public Object unmarshal(Source source) throws XmlMappingException, IOException {
				SdnEntry sdnEntry = (SdnEntry) jaxb2Marshaller.unmarshal(source);
				OfaSdnentry ofaSdnentry = convertOfaSdnentry(sdnEntry);
				return ofaSdnentry;
			}

			@Override
			public boolean supports(Class<?> clazz) {
				return true;
			}

		});

		return staxEventItemReader;
	}

	public static ItemReader<OfaSdnentry> createItemReaderXmlUE(Resource inputSDNXML) {
		final Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setClassesToBeBound(SanctionEntity.class);
		jaxb2Marshaller.setMappedClass(SanctionEntity.class);

		StaxEventItemReader staxEventItemReader = new StaxEventItemReader();

		staxEventItemReader.setFragmentRootElementNames(cad_sanctionEntity.split(","));
		staxEventItemReader.setFragmentRootElementName(cad_sanctionEntity);
		staxEventItemReader.setResource(inputSDNXML);

		staxEventItemReader.setUnmarshaller(new Unmarshaller() {
			@Override
			public Object unmarshal(Source source) throws XmlMappingException, IOException {
				SanctionEntity sdnEntry = (SanctionEntity) jaxb2Marshaller.unmarshal(source);
				// guardando el registro parseado
				OfaSdnentry ofaSdnentry = convertOfaSdnentryUE(sdnEntry);
				return ofaSdnentry;
			}

			@Override
			public boolean supports(Class<?> clazz) {
				return true;
			}

		});

		return staxEventItemReader;
	}
	
	public static Supplier<List<ImmutablePair<OfaSdnentry, OfacListas>>> getListaOfaSdnentry(List<OfaSdnentry> ofaSdnentryList, int position) {
		return () -> {
			List<ImmutablePair<OfaSdnentry, OfacListas>> ofaSdnentryList0 = new ArrayList<>();
			ofaSdnentryList.stream().forEach(ofaSdnentry -> {
				Set<OfaDateofbirth> listaOfaDateofbirth = ofaSdnentry.getOfaDateofbirth();
				Set<OfaAddresslist> listaOfaAddresslist = ofaSdnentry.getOfaAddresslist();
				Set<OfaNationality> listaOfaNationality = ofaSdnentry.getOfaNationality();
				Set<OfaCitizenship> listaOfaCitizenship = ofaSdnentry.getOfaCitizenship();
				Set<OfaPlaceofbirth> listaOfaPlaceofbirth = ofaSdnentry.getOfaPlaceofbirth();
				Set<OfaIdlist> listaOfaIdlist = ofaSdnentry.getOfaIdlist();
				Set<OfaAkalist> listaOfaAkalist = ofaSdnentry.getOfaAkalist();
				OfaVesselinfo ofaVesselinfo = ofaSdnentry.getOfaVesselinfo();
				
				OfacListas ofacListas = new OfacListas(listaOfaDateofbirth, listaOfaAddresslist, listaOfaNationality, listaOfaCitizenship, listaOfaPlaceofbirth, listaOfaIdlist,
						listaOfaAkalist, ofaVesselinfo, position);
				
				ofaSdnentryList0.add(new ImmutablePair<OfaSdnentry, OfacListas>(ofaSdnentry, ofacListas));
			});

			return ofaSdnentryList0;
		};
	}
	
	public static Integer readFileToOfaSdnentry(String pathFile, Integer nrolote) throws UnexpectedInputException, ParseException, Exception {
		List<OfaSdnentry> ofaSdnentryList = readFileToOfaSdnentryToLista(nrolote, pathFile);
		return ofaSdnentryList.size();
	}

	public static boolean existString(String pathFile, String tag) {
		try {
			String cad = UtilsFile.readFileAsString(pathFile, 1000);
			return cad.indexOf(tag) > 0;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static List<ImmutablePair<Integer, List<OfaSdnentry>>> splitLista(List<OfaSdnentry> ofaSdnentryList, int size) {
		return ofaSdnentryList.stream().collect(() -> {
			// System.out.println("en supplier");
			List<ImmutablePair<Integer, List<OfaSdnentry>>> list = new ArrayList<>();
			ImmutablePair<Integer, List<OfaSdnentry>> itemlist = new ImmutablePair<Integer, List<OfaSdnentry>>(1, new ArrayList<>());
			list.add(itemlist);
			return list;
		}, (list, s) -> {
			if (list.get(list.size() - 1).right.size() >= size) {
				ImmutablePair<Integer, List<OfaSdnentry>> itemlist = new ImmutablePair<Integer, List<OfaSdnentry>>(list.size() + 1, new ArrayList<>());
				list.add(itemlist);
			}

			if (list.get(list.size() - 1).right.size() < size) {
				list.get(list.size() - 1).right.add(s);
			}

		}, (list1, list2) -> {
			list1.get(list1.size() - 1);
		});
	}

	public static void printpru(List<ImmutablePair<OfaSdnentry, OfacListas>> imreg) {
		log.info(System.nanoTime() + " : " + Thread.currentThread().getName() + " ----- Fin apply -----" + imreg.get(0).right.getPosition());
	}

	public static OfaSdnentry convertOfaSdnentry(SdnEntry sdnEntry) {

		OfaSdnentry ofaSdnentry = SdnListDTO.sdnEntryToOfaSdnentry(sdnEntry);
		//ofaSdnentry.setSdnEntryuid(ofaSdnentry.getSdnEntryuid());
		//ofaSdnentry.setSdnNrolote(nrolote);

		Set<OfaDateofbirth> listaOfaDateofbirth = SdnListDTO.dateOfBirthListToOfaDateofbirth(sdnEntry);
		//log.info("Salvando SdnEntryuid: " + ofaSdnentry.getSdnEntryuid());
		if (listaOfaDateofbirth != null)
			ofaSdnentry.setOfaDateofbirth(listaOfaDateofbirth);

		Set<OfaAddresslist> listaOfaAddresslist = SdnListDTO.addressListToOfaAddresslist(sdnEntry);
		if (listaOfaAddresslist != null)
			ofaSdnentry.setOfaAddresslist(listaOfaAddresslist);

		Set<OfaNationality> listaOfaNationality = SdnListDTO.nationalityListToOfaNationality(sdnEntry);
		if (listaOfaNationality != null)
			ofaSdnentry.setOfaNationality(listaOfaNationality);

		Set<OfaCitizenship> listaOfaCitizenship = SdnListDTO.citizenshipListToOfaCitizenship(sdnEntry);
		if (listaOfaCitizenship != null)
			ofaSdnentry.setOfaCitizenship(listaOfaCitizenship);

		Set<OfaPlaceofbirth> listaOfaPlaceofbirth = SdnListDTO.placeOfBirthListToOfaPlaceofbirth(sdnEntry);
		if (listaOfaPlaceofbirth != null)
			ofaSdnentry.setOfaPlaceofbirth(listaOfaPlaceofbirth);

		Set<OfaIdlist> listaOfaIdlist = SdnListDTO.idListToOfaIdlist(sdnEntry);
		if (listaOfaIdlist != null)
			ofaSdnentry.setOfaIdlist(listaOfaIdlist);

		Set<OfaAkalist> listaOfaAkalist = SdnListDTO.akaListToOfaAkalist(sdnEntry);
		if (listaOfaAkalist != null)
			ofaSdnentry.setOfaAkalist(listaOfaAkalist);

//		OfaVesselinfo ofaVesselinfo = SdnListDTO.vesselInfoToOfaVesselinfo(sdnEntry);
//		if (ofaVesselinfo != null)
//			ofaSdnentry.setOfaVesselinfo(ofaVesselinfo);

		return ofaSdnentry;
	}

	public static OfaSdnentry convertOfaSdnentryUE(SanctionEntity sdnEntry) {

		OfaSdnentry ofaSdnentry = SanctionEntityToOfacEntryDto.sdnEntryToOfaSdnentry(sdnEntry);
		//ofaSdnentry.setSdnEntryuid(ofaSdnentry.getSdnEntryuid());
		//ofaSdnentry.setSdnNrolote(nrolote);

		Set<OfaDateofbirth> listaOfaDateofbirth = SanctionEntityToOfacEntryDto.dateOfBirthListToOfaDateofbirth(sdnEntry);
		//log.info("Salvando SdnEntryuid: " + ofaSdnentry.getSdnEntryuid());
		if (listaOfaDateofbirth != null)
			ofaSdnentry.setOfaDateofbirth(listaOfaDateofbirth);

		Set<OfaAddresslist> listaOfaAddresslist = SanctionEntityToOfacEntryDto.addressListToOfaAddresslist(sdnEntry);
		if (listaOfaAddresslist != null)
			ofaSdnentry.setOfaAddresslist(listaOfaAddresslist);

//		Set<OfaNationality> listaOfaNationality = SanctionEntityToOfacEntryDto.nationalityListToOfaNationality(sdnEntry);
//		if (listaOfaNationality != null)
//			ofaNationalityRepository.save(listaOfaNationality);
//		ofaSdnentry.setOfaNationality(listaOfaNationality);

//		Set<OfaCitizenship> listaOfaCitizenship = SanctionEntityToOfacEntryDto.citizenshipListToOfaCitizenship(sdnEntry);
//		if (listaOfaCitizenship != null)
//			ofaCitizenshipRepository.save(listaOfaCitizenship);
//		ofaSdnentry.setOfaCitizenship(listaOfaCitizenship);

		Set<OfaPlaceofbirth> listaOfaPlaceofbirth = SanctionEntityToOfacEntryDto.placeOfBirthListToOfaPlaceofbirth(sdnEntry);
		if (listaOfaPlaceofbirth != null)
			ofaSdnentry.setOfaPlaceofbirth(listaOfaPlaceofbirth);

		Set<OfaIdlist> listaOfaIdlist = SanctionEntityToOfacEntryDto.identificationListToOfaIdlist(sdnEntry);
		if (listaOfaIdlist != null)
			ofaSdnentry.setOfaIdlist(listaOfaIdlist);

		Set<OfaAkalist> listaOfaAkalist = SanctionEntityToOfacEntryDto.akaListToOfaAkalist(sdnEntry);
		if (listaOfaAkalist != null)
			ofaSdnentry.setOfaAkalist(listaOfaAkalist);

		return ofaSdnentry;
	}

	public static String stripAccents(String s)	{
	    s = Normalizer.normalize(s, Normalizer.Form.NFD);
	    s = s.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
	    return s;
	}	
}
