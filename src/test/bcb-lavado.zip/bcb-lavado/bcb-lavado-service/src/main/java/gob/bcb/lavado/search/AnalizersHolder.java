package gob.bcb.lavado.search;

import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.Analyzer.TokenStreamComponents;
import org.apache.lucene.analysis.core.DecimalDigitFilter;
import org.apache.lucene.analysis.core.LowerCaseFilter;
import org.apache.lucene.analysis.core.StopFilter;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.es.SpanishAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.analysis.EntityAnalyzer;
import gob.bcb.lavado.strategy.StrategyBase;

public class AnalizersHolder {
	private static final Logger log = LoggerFactory.getLogger(AnalizersHolder.class);
	
	public static Analyzer getEntityAnalyzer() {
		Analyzer analyzer = new EntityAnalyzer();
		return analyzer;
	}
	
	public static Analyzer getEntityAnalyzer(String path) {
		Analyzer analyzer = new EntityAnalyzer(path);
		return analyzer;
	}

	public static Analyzer getAnalyzerSpanish() {
		Analyzer analyzer = new SpanishAnalyzer();
		return analyzer;
	}

	public static Analyzer getAnalyzerStandard() {
		Analyzer analyzer = new StandardAnalyzer();
		return analyzer;

	}

	public static Analyzer getAnalyzerWords() {
		Analyzer keyword = new Analyzer() {
			@Override
			protected TokenStreamComponents createComponents(String fieldName) {
				Tokenizer tokenizer = new StandardTokenizer();
				TokenStream sink = new StandardFilter(tokenizer);
				sink = new LowerCaseFilter(sink);
				sink = new DecimalDigitFilter(sink);
				sink = new StopFilter(sink, EnglishAnalyzer.getDefaultStopSet());

				return new TokenStreamComponents(tokenizer, sink);
			}
		};
		return keyword; // new StandardAnalyzer();
	}

	public static final String ANALYZER_STANDARD = "standard";
	public static final String ANALYZER_WORDS = "words";
	public static final String ANALYZER_SPANISH = "spanish";
	public static final String ANALYZER_NAMES = "names";
	//public static final String ANALYZER_ENTITIES = "banks";
	public static final String ANALYZER_BICS = "bics";

	public static final Map<String, Analyzer> mapAnalizers = new HashMap<>();

	static {
		//mapAnalizers.put(ANALYZER_ENTITIES, getEntityAnalyzer());
		//mapAnalizers.put(ANALYZER_NAMES, getEntityAnalyzer());
		mapAnalizers.put(ANALYZER_SPANISH, getAnalyzerSpanish());
		mapAnalizers.put(ANALYZER_WORDS, getAnalyzerWords());
		mapAnalizers.put(ANALYZER_STANDARD, getAnalyzerStandard());
		mapAnalizers.put(ANALYZER_BICS, getAnalyzerStandard());
		log.info("Analyzers cargados ... " + mapAnalizers.size());
	}

	public static Analyzer getAnalyzer(String idAnalyzer) {
		if (mapAnalizers.containsKey(idAnalyzer))
			return mapAnalizers.get(idAnalyzer);
		return mapAnalizers.get(ANALYZER_STANDARD);
	}

}
