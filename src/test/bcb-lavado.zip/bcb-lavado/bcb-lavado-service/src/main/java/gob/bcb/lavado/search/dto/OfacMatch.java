package gob.bcb.lavado.search.dto;

import gob.bcb.lavado.search.QueryMatch;

public class OfacMatch extends QueryMatch {
    private final float score;

    public OfacMatch(String queryId, String docId) {
        super(queryId, docId);
        this.score = 1.0f;
    }
    
    public OfacMatch(String queryId, String docId, float score) {
        super(queryId, docId);
        this.score = score;
    }

    public float getScore() {
        return score;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OfacMatch)) return false;
        if (!super.equals(o)) return false;

        OfacMatch that = (OfacMatch) o;

        if (Float.compare(that.score, score) != 0) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (score != +0.0f ? Float.floatToIntBits(score) : 0);
        return result;
    }

}
