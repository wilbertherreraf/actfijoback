package gob.bcb.lavado.search;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import javax.persistence.EntityTransaction;

import org.hibernate.CacheMode;
import org.hibernate.search.batchindexing.MassIndexerProgressMonitor;
import org.hibernate.search.batchindexing.impl.SimpleIndexingProgressMonitor;
import org.hibernate.search.cfg.SearchMapping;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaBlacklist;
import gob.bcb.lavado.model.OfaBlanklist;
import gob.bcb.lavado.model.OfaIdlist;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.search.indexer.JPASearchFactoryController;
import gob.bcb.lavado.search.indexer.JPASearchFactoryControllerImpl;
import gob.bcb.lavado.search.indexer.JPASearchFactoryHolder;

@Service
public class OfacIndexer {
	private static final Logger log = LoggerFactory.getLogger(OfacIndexer.class);

	private static final List<Class<?>> ENTITIES_OFAC_LIST = Arrays.asList(OfaSdnentry.class, OfaAkalist.class, OfaBlacklist.class, OfaBlanklist.class);
	private static final List<Class<?>> ENTITIES_LVD_LIST = Arrays.asList(SwfMensaje.class, SwfBics.class); //, SwfBics.class
	public static final Map<String, Class<?>> MAP_CLAZZ_ENTITIES = new HashMap<>();

	public static final List<String> fieldsAllfields = Arrays.asList("sdnLastname", "sdnFirstname", "sdnRemarks", "sdnTitle", "sdnProgramlist",
			"ofaAkalist.akaLastname", "ofaAkalist.akaFirstname", "blkContent",
			"blkType", "blcContent", "blcType","menPlano", "akaLastname", "akaFirstname","id.bicCodbic", "id.bicCodbranch", "bicCiudad", "bicDescrip", "bicPais");
	//, "swfBics.bicCodbic", "swfBics.bicCodbranch", "bicCiudad", "bicDescrip", "bicPais"

	static {
		ENTITIES_OFAC_LIST.forEach(e -> {
			MAP_CLAZZ_ENTITIES.put(e.getSimpleName().toUpperCase(), e);
			log.info("loaded class " + e.getSimpleName());
		});
		ENTITIES_LVD_LIST.forEach(e -> {
			MAP_CLAZZ_ENTITIES.put(e.getSimpleName().toUpperCase(), e);
			log.info("loaded class " + e.getSimpleName());
		});
	}

	@Autowired
	private Environment env;
	
	@Autowired
	private JPASearchFactoryHolder jPASearchFactoryHolder;
	
	public void indexOfaSdnentry() throws Exception {
		indexOfaSdnentry(ENTITIES_OFAC_LIST);
	}

	public void indexLvdEntities() throws Exception {
		indexOfaSdnentry(ENTITIES_LVD_LIST);
	}

	@Transactional(propagation = Propagation.NEVER)
	public void indexOfaSdnentry(List<Class<?>> entitiesList) throws Exception {
		
		JPASearchFactoryControllerImpl jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());		
		jPASearchFactoryController.init();
		FullTextEntityManager fullTextEntityManager = jPASearchFactoryController.getFullTextEntityManager();
		fullTextEntityManager.getTransaction().begin();
		try {
			log.info("==> Inicio indexacion de " + entitiesList.size() + " entidades");
			long startTime = System.currentTimeMillis();

			//FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
			for (Class entidade : entitiesList) {
				massiveIndexer(entidade, fullTextEntityManager);
			}
			log.info("antes de coooooooooooooooooooooooomit");
			fullTextEntityManager.getTransaction().commit();
			log.info("==> Process index ... done!!! in (" + (System.currentTimeMillis() - startTime) + " ms.)");
		} catch (InterruptedException e) {
			log.error("An error occurred trying to build the serach index: " + e.getMessage(), e);
			throw e;
		} finally {
			jPASearchFactoryController.close();				
		}

	}

	private void massiveIndexer(Class clazz, FullTextEntityManager fullTextEntityManager) throws InterruptedException {
		log.info("Running Indexing class: " + clazz.getSimpleName());

		org.hibernate.search.MassIndexer indexer = fullTextEntityManager.createIndexer(clazz)//
				.batchSizeToLoadObjects(12)//
				.threadsToLoadObjects(5)//
				.idFetchSize(100) //
				.transactionTimeout(1800)//
				.cacheMode(CacheMode.IGNORE);//
				//.progressMonitor(progress()); // a MassIndexerProgressMonitor
		try {
			log.info("Iniciado!!! Indexing class: " + clazz.getSimpleName());
			indexer.startAndWait();
		} catch (Exception e) {
			log.error("Error al indexar: " + e.getMessage(), e);
			throw e;
		}
	}

	@Transactional(propagation = Propagation.NEVER)
	public void indexerClassSync(Class clazz) throws InterruptedException {
		log.info("indexerClassSync: Running Indexing Sync class: " + clazz.getSimpleName());
		long startTime = System.currentTimeMillis();
		JPASearchFactoryControllerImpl jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());		
		jPASearchFactoryController.init();
		FullTextEntityManager fullTextEntityManager = jPASearchFactoryController.getFullTextEntityManager();
		EntityTransaction entityTransaction = fullTextEntityManager.getTransaction();
		entityTransaction.begin();
		
		org.hibernate.search.MassIndexer indexer = fullTextEntityManager.createIndexer(clazz)//
				.batchSizeToLoadObjects(10)//
				.cacheMode(CacheMode.IGNORE)//
				.progressMonitor(progress()); // a MassIndexerProgressMonitor
		try {
			indexer.startAndWait();
			entityTransaction.commit();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		} finally{
			jPASearchFactoryController.close();				
		}
		long endTime = System.currentTimeMillis();
		log.info("==> Process index(" + clazz.getSimpleName() + ") ... done!!! in (" + (endTime - startTime) + " ms.)");
	}

	private void massiveIndexerAsync(FullTextEntityManager fullTextEntityManager) throws InterruptedException {
		log.info("Running Indexing class: " + ENTITIES_OFAC_LIST.size());

		int threadsToLoadObjects = 1;
		InnerIndexerProgressMonitor monitor = new InnerIndexerProgressMonitor();
		org.hibernate.search.MassIndexer indexer = fullTextEntityManager.createIndexer((Class<?>[]) ENTITIES_OFAC_LIST.toArray())//
				.batchSizeToLoadObjects(1)//
				.cacheMode(CacheMode.IGNORE)//
				.threadsToLoadObjects(threadsToLoadObjects)//
				.purgeAllOnStart(true)//
				.optimizeOnFinish(false)//
				.progressMonitor(monitor); // a MassIndexerProgressMonitor
		// .idFetchSize(Integer.MIN_VALUE);
		try {
			// indexer.startAndWait();
			Future task = indexer.start();
			log.info("Iniciado!!! Indexing class: " + ENTITIES_OFAC_LIST.size());
			// monitor.waitUntilBusyThreads( threadsToLoadObjects);

			// cancel indexing job
			// task.cancel( true );

			// wait a bit to let indexing threads correctly end
			monitor.waitUntilBusyThreads(0);
			log.info("::> Fin Async class: " + ENTITIES_OFAC_LIST.size());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}
	}

	public static SearchMapping buildProgrammaticSearchMapping() {
		SearchMapping mapping = new SearchMapping();
		for (Class entidade : MAP_CLAZZ_ENTITIES.values()) {
			log.info("mapping build Indexing class: " + entidade.getSimpleName());
			mapping.entity(entidade).indexed();// .property("sdnId",
												// ElementType.FIELD).documentId()//
		}
		
		return mapping;
	}

	private MassIndexerProgressMonitor progress() {
		return new MassIndexerProgressMonitor() {
			private final AtomicLong totalCount = new AtomicLong();
			private final AtomicLong finishedCount = new AtomicLong();

			@Override
			public void documentsAdded(long arg0) {
			}

			@Override
			public void addToTotalCount(long count) {
				totalCount.addAndGet(count);
				log.debug(" TotalCount: " + count);
			}

			@Override
			public void documentsBuilt(int arg0) {
				log.debug(" documentsBuilt: " + arg0);
			}

			@Override
			public void entitiesLoaded(int arg0) {
				log.debug("Entities Loaded: " + arg0);
			}

			@Override
			public void indexingCompleted() {
				finishedCount.incrementAndGet();
				log.info("Indexing Completed... " + finishedCount.get() + " totalCount:" + totalCount.get());
			}
		};
	}

	class InnerIndexerProgressMonitor extends SimpleIndexingProgressMonitor {

		public final List<Thread> threads = Collections.synchronizedList(new ArrayList<Thread>());
		private final AtomicInteger busyThreads = new AtomicInteger();

		public InnerIndexerProgressMonitor() {
			super();
		}

		@Override
		public void documentsBuilt(int number) {
			super.documentsBuilt(number);
			log.info("enlist EntityLoader thread [" + Thread.currentThread() + "] and simulate document producer activity");
			threads.add(Thread.currentThread());

			busyThreads.incrementAndGet();
			while (true) {
				// simulate activity until thread interrupted
				if (Thread.currentThread().isInterrupted()) {
					log.info("Indexing thread is interrupted : end activity simulation ");
					break;
				}
			}
			busyThreads.decrementAndGet();
		}

		void waitUntilBusyThreads(int expectedNumberBusyThreads) {
			while (busyThreads.get() != expectedNumberBusyThreads) {
				Thread.yield();
			}
		}

		public boolean massIndexerThreadsAreInterruptedOrDied() {
			for (Thread th : threads) {
				if (th.isAlive()) {
					if (!th.isInterrupted()) {
						log.info("Thread [" + th + "] is not interrupted or alive");
						return false;
					}
				}
			}
			return true;
		}

		public int getThreadNumber() {
			return threads.size();
		}

		@Override
		public void indexingCompleted() {
			log.info("Indexing Completed... " + busyThreads.get());
		}
	}

	public static void main(String[] args) {
		Boolean isDev = Arrays.asList(new String[] {"enf","dev"}).contains("adev");
		System.out.println(isDev);
		
	}
}
