package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the swf_detmensaje database table.
 * 
 */
@Entity
@Table(name="swf_detmensaje")
public class SwfDetmensaje implements Serializable, gob.bcb.lavado.model.DomainObject {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SwfDetmensajePK id;

	@Column(name="dem_bloque")
	private Integer demBloque;
	
	@Column(name="dem_codcampo")
	private String demCodcampo;

	@Column(name="dem_codmt")
	private String demCodmt;
	
	@Column(name="dem_valor")
	private String demValor;

	@ManyToOne()
	@JoinColumn(name="dem_codmen", nullable=true, insertable=false, updatable=false,referencedColumnName="men_codmen")
	private SwfMensaje swfMensaje;
	
	public SwfDetmensaje() {
	}

	public SwfDetmensajePK getId() {
		return this.id;
	}

	public void setId(SwfDetmensajePK id) {
		this.id = id;
	}

	public String getDemValor() {
		return this.demValor;
	}

	public void setDemValor(String demValor) {
		this.demValor = demValor;
	}

	public String getDemCodcampo() {
		return demCodcampo;
	}

	public void setDemCodcampo(String demCodcampo) {
		this.demCodcampo = demCodcampo;
	}

	public String getDemCodmt() {
		return demCodmt;
	}

	public void setDemCodmt(String demCodmt) {
		this.demCodmt = demCodmt;
	}

	public Integer getDemBloque() {
		return demBloque;
	}

	public void setDemBloque(Integer demBloque) {
		this.demBloque = demBloque;
	}

}