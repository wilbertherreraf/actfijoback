package gob.bcb.lavado.QL.contbcb;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.pojos.UnidadOrgCoin;

@Repository("coinQLBean")
public class CoinQLBeanImpl implements CoinQLBean{
	private static final Logger log = LoggerFactory.getLogger(CoinQLBeanImpl.class);

	@PersistenceContext(unitName = Constants.PUNIT_CONTBCB)
	private EntityManager em;
	
	@Autowired
	@Qualifier("entityManagerFactoryCoin")	
	private EntityManagerFactory entityManagerFactoryCoin;
	
	public List<UnidadOrgCoin> unidadesOrg(){
		String jsql = "SELECT cod_unidad_org, desc_unidad_org ";
		jsql = jsql.concat("FROM unidad_org ");
		
		Query query = em.createNativeQuery(jsql);
		
		List<UnidadOrgCoin> unidadOrgCoinLista = new ArrayList<UnidadOrgCoin>(); 
		try {
			List<Object[]> result = query.getResultList();

			for (Object[] resultObj : result) {
				UnidadOrgCoin unidadOrgCoin = new UnidadOrgCoin();
				unidadOrgCoin.setCodUnidadOrg((String) resultObj[0]);
				unidadOrgCoin.setDescUnidadOrg((String) resultObj[1]);
				
				unidadOrgCoinLista.add(unidadOrgCoin);
			}

		} catch (Exception e) {
			log.error("Error al sumar : " + e.getMessage(), e);
			throw new DataException("Error al sumar : " + e.getMessage());
		}
		
		return unidadOrgCoinLista;
	}
	
	/**
	 * Determina si una fecha es habil o no
	 * 
	 * @param fecha
	 *            fecha a evaluar en contbcb
	 * @return true si es habil, falso de lo contrario
	 */
	public boolean isHabil(Date fecha) {
		boolean resp = true;

		String jsql = "select count(*) from feriado where fecha_feriado = :fecha";
		Query consulta = em.createNativeQuery(jsql);
		consulta.setParameter("fecha", fecha);

		Long codigo = null;
		BigDecimal maxi = BigDecimal.ZERO;
		List result = consulta.getResultList();
		if (result.size() > 0)
			maxi = (BigDecimal) result.get(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
		} else {
			codigo = Long.valueOf(0);
		}
		
		if (codigo.compareTo(Long.valueOf(0)) == 0) {
			Calendar fec = Calendar.getInstance();
			fec.setTime(fecha);

			if (fec.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
				resp = false;
			} else if (fec.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
				resp = false;
			}
		} else {
			resp = false;
		}
		log.info("Fecha [" + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy")+ "] habil : " + resp);
		return resp;
	}

	/**
	 * Calcula o cuenta los dï¿½as habiles antes(- negativo) o despues (+
	 * positivo) de una fecha
	 * 
	 * @param fecha
	 *            fecha a partir de la cual se calcula
	 * @param diasAntes
	 *            dias habiles que se debe contar si es negativo es dias antes,
	 *            positivo dias despues
	 * @return
	 */
	public Date fecHabilAntesDespuesDe(Date fecha, int diasAntes) {
		if (diasAntes == 0) {
			return fecha;
		}

		if (diasAntes > 365) {
			throw new RuntimeException("El numero de dias para calcular fecha habil antes de " + diasAntes + " dias es mayor al permitido 365.");
		}

		int diasAbs = (diasAntes < 0 ? -diasAntes : diasAntes);
		int signo = (diasAntes < 0 ? -1 : 1);

		int contDias = 1;
		int cont = 1;

		Calendar fecEval = null;
		fecEval = Calendar.getInstance();
		fecEval.setTime(fecha);

		while (cont <= diasAbs && contDias <= 365) {
			fecEval.setTime(fecha);
			fecEval.add(Calendar.DAY_OF_YEAR, signo * contDias);

			if (isHabil(fecEval.getTime())) {
				cont++;
			}
			contDias++;
		}

		if ((cont > diasAntes) && (fecEval.getTime().before(fecha) || fecEval.getTime().after(fecha))) {
			return fecEval.getTime();
		} else {
			return null;
		}
	}	
}
