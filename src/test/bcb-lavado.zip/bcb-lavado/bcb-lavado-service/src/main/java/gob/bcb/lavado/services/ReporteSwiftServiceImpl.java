package gob.bcb.lavado.services;

import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.report.SwiftMessageReport;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfTipomensaje;
import gob.bcb.lavado.repository.SwfBicsDao;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.repository.SwfTipomensajeDao;

@Service(value = "reporteSwiftService")
public class ReporteSwiftServiceImpl implements ReporteSwiftService {
	private static final Logger log = LoggerFactory.getLogger(ReporteSwiftServiceImpl.class);
	//private ReporteSwift reporteSwift = new ReporteSwift();

	@Autowired
	private SwfTipomensajeDao swfTipomensajeDao;
	@Autowired
	private SwfBicsDao swfBicsDao;
	@Autowired
	private SwfMensajeDao swfMensajeDao;

	@PostConstruct
	public void init() {
		log.info("=== init ReporteSwift ==== PostConstruct " + this.getClass().getSimpleName());
		//reporteSwift.initReporteSwift();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.lavado.services.ReporteSwiftService#
	 * generarReportePDFFromPlano(java.lang.String, java.lang.String)
	 */

	public ArchivoSinple generarReportePDFFromPlano(String menPlano, String codUsuario, Integer menCodmen) {
		log.info("Inicio generarReportePDFFromPlano ");
		
		try {
			SwiftMessageReport swiftMessageReport = new SwiftMessageReport();
			swiftMessageReport.getProps().put("appSubgcia", "SUBGERENCIA DE OPERACIONES EXTERNAS");
			swiftMessageReport.getProps().put("appAppnombre", "SISTEMA DE CONTROL Y LAVADO DE DINERO");

			SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(menCodmen);
			if (swfMensaje != null) {
				swiftMessageReport.initReport(menPlano, mp -> {
					mp.setMenCodapp(swfMensaje.getMenCodapp());
					mp.setMenCodmen(swfMensaje.getMenCodmen());
					mp.setMenNrocorr(swfMensaje.getMenNrocorr());
					mp.setMenFecreg(swfMensaje.getMenFecreg());
					mp.setMenCodusr(codUsuario);
					//mp.setVerifica(true);
					mp.setMenIdoperacion(swfMensaje.getMenRefer());
				});
			} else {
				swiftMessageReport.initReport(menPlano, mp -> {
					mp.setMenCodapp(Constants.COD_APP);
//					mp.setMenCodmen(swfMensaje.getMenCodmen());
//					mp.setMenNrocorr(swfMensaje.getMenNrocorr());
					mp.setMenFecreg(new Date());
					mp.setMenCodusr(codUsuario);
					//mp.setMenIdoperacion(swfMensaje.getMenRefer());
				});
			}
			
			SwfTipomensaje swfTipomensaje = swfTipomensajeDao.getByCodigo(swiftMessageReport.getSwfMsgParam().getMenTypemessage());
			if (swfTipomensaje != null) {
				swiftMessageReport.getProps().put("msgTipodescrip", swfTipomensaje.getTimDescrip());
			}
			
			SwfBics swfBicsSender = swfBicsDao.findByBIC8(swiftMessageReport.getSwfMsgParam().getMenEmisor());
			if (swfBicsSender != null) {
				swiftMessageReport.getSwfMsgParam().setEmisorDescrip(swfBicsSender.getBicDescrip());
			}
			SwfBics swfBicsReceiver = swfBicsDao.findByBIC8(swiftMessageReport.getSwfMsgParam().getMenReceiver());
			if (swfBicsReceiver != null) {
				swiftMessageReport.getSwfMsgParam().setReceiverDescrip(swfBicsReceiver.getBicDescrip());
			}
			
			String nameFile = swiftMessageReport.getSwfMsgParam().getMenCodapp() + "_" + swiftMessageReport.getSwfMsgParam().getMenTypemessage() + "_" + swiftMessageReport.getSwfMsgParam().getMenCodmen() + ".pdf";
			
			gob.bcb.iso20022.pojo.ArchivoSinple archivoSinple = swiftMessageReport.createReportFile(null);
			
			ArchivoSinple archivoSinplePDF = new ArchivoSinple();
			archivoSinplePDF.setData(archivoSinple.getData());
			archivoSinplePDF.setName(nameFile);
			archivoSinplePDF.setNameOriginal(nameFile);
			
			log.info("reportSwift reporte PDF generado " + archivoSinplePDF.getNameOriginal());

			return archivoSinplePDF;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			throw new RuntimeException("Error al generar reporte " + e.getMessage(), e); 
		}

	}

//	public ArchivoSinple generarReportePDFFromPlano0(String menPlano, String codUsuario, Integer menCodmen) {
//		log.info("Inicio generarReportePDFFromPlano ");
//		log.debug(menPlano);
//		try {
//			SwiftDatos swiftDatos = swiftBcbParserService.swiftDatosFromString(menPlano);
//			if (menCodmen != null && menCodmen.compareTo(0) > 0) {
//				SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(menCodmen);
//				if (swfMensaje != null) {
//					swiftDatos.getSwfMensaje().setMenCodmen(menCodmen);
//					swiftDatos.getSwfMensaje().setMenFecauto(swfMensaje.getMenFecauto());
//					swiftDatos.getSwfMensaje().setMenFecreg(swfMensaje.getMenFecreg());
//					swiftDatos.getSwfMensaje().setMenNrocorr(swfMensaje.getMenNrocorr());
//					swiftDatos.getSwfMensaje().setMenCodapp(swfMensaje.getMenCodapp());
//					swiftDatos.getSwfMensaje().setMenRefer(swfMensaje.getMenRefer());
//					swiftDatos.getSwfMensaje().setMenCodswift(swfMensaje.getMenCodswift());
//				}
//			}
//
//			swiftDatos.getSwfMensaje().setBlock4List(swiftBcbParserService.createListBlock4(swiftDatos.getSwiftMessageBcb(), true));
//
//			log.info("swfMensaje " + swiftDatos.getSwfMensaje().getMenBic() + " " + (swiftDatos.getSwiftMessageBcb().getBlock2() == null));
//			swiftDatos.setAuditusr(codUsuario);
//
//			SwfTipomensaje swfTipomensaje = swfTipomensajeDao.getByCodigo(swiftDatos.getSwfMensaje().getMenCodmt());
//			swiftDatos.setSwfTipomensaje(swfTipomensaje);
//
//			SwfBics swfBicsSender = swfBicsDao.findByBIC8(swiftDatos.getSwfMensaje().getMenEmisor());
//			swiftDatos.setSwfBicsSender(swfBicsSender);
//
//			if (swfBicsSender == null) {
//				if (swiftDatos.getSwfMensaje().getMenEmisor() == null)
//					swiftDatos.getSwfMensaje().setMenEmisor("");
//				swiftDatos.newSwfBicsSender(swiftDatos.getSwfMensaje().getMenEmisor(), swiftDatos.getSwfMensaje().getMenEmisor(), "NN", "", "", "");
//			}
//
//			SwfBics swfBicsReceiver = swfBicsDao.findByBIC8(swiftDatos.getSwfMensaje().getMenReceiver());
//			swiftDatos.setSwfBicsReceiver(swfBicsReceiver);
//			if (swfBicsReceiver == null) {
//				if (swiftDatos.getSwfMensaje().getMenReceiver() == null)
//					swiftDatos.getSwfMensaje().setMenReceiver("");
//				swiftDatos.newSwfBicsReceiver(swiftDatos.getSwfMensaje().getMenReceiver(), swiftDatos.getSwfMensaje().getMenReceiver(), "NN", "", "", "");
//			}
//
//			reporteSwift.populateReport(swiftDatos, swiftDatos.getSwfMensaje().getBlock4List());
//
//			reporteSwift.render();
//
//			String nameFile = "reportSwf_" + swiftDatos.getSwfMensaje().getMenCodmt() + "_" + swiftDatos.getSwfMensaje().getMenCodmen() + ".pdf";
//			ArchivoSinple archivoSinplePDF = reporteSwift.convertToPDF(reporteSwift.getArchivoSinple(), nameFile);
//			log.info("reportSwift reporte PDF generado " + archivoSinplePDF.getNameOriginal());
//
//			return archivoSinplePDF;
//		} catch (Exception e) {
//			log.error("error " + e.getMessage(), e);
//			reporteSwift.populateReportError(e.getMessage(), e.toString());
//			reporteSwift.render();
//
//			String nameFile = "reportSwf_Error.pdf";
//			ArchivoSinple archivoSinplePDF = reporteSwift.convertToPDF(reporteSwift.getArchivoSinple(), nameFile);
//			return archivoSinplePDF;
//		}
//
//	}

}
