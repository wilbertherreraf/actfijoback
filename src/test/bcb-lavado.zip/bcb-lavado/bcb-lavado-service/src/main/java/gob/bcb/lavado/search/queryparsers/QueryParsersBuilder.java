package gob.bcb.lavado.search.queryparsers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.index.Term;
import org.apache.lucene.queries.TermsQuery;
import org.apache.lucene.queries.function.BoostedQuery;
import org.apache.lucene.queries.function.valuesource.ConstValueSource;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.QueryParser.Operator;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleFragmenter;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.search.spans.SpanMultiTermQueryWrapper;
import org.apache.lucene.search.spans.SpanNearQuery;
import org.apache.lucene.search.spans.SpanOrQuery;
import org.apache.lucene.search.spans.SpanQuery;
import org.apache.lucene.search.spans.SpanTermQuery;
import org.hibernate.search.SearchFactory;
import org.hibernate.search.query.dsl.BooleanJunction;
import org.hibernate.search.query.dsl.PhraseMatchingContext;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.analysis.ShingleAnalyzer;
import gob.bcb.lavado.search.indexer.JPASearchFactoryController;

/**
 * Construye objetos query lucene para casos de uso
 * 
 * @author wherrera
 *
 */
public class QueryParsersBuilder {
	private static final Logger log = LoggerFactory.getLogger(QueryParsersBuilder.class);
	private QueryBuilder queryBuilder;
	public static final int MAX_TERMS_LIMIT = 50;
	
	public QueryParsersBuilder() {
	}
	
	public QueryParsersBuilder(final JPASearchFactoryController jPASearchFactoryController, Class clazz) {
		this(jPASearchFactoryController.getSearchFactory(), clazz);
	}
	public QueryParsersBuilder(SearchFactory searchFactory, Class clazz) {
		if (searchFactory == null)
			throw new RuntimeException("Parametro searchFactory nulo");
		this.queryBuilder = searchFactory.buildQueryBuilder().forEntity(clazz).get();
	}
	public Query createQueryParse(String field, String query, Operator operator, float boost, Analyzer analyzer) throws Exception {
		QueryParser parser = new QueryParser(field, analyzer);
		parser.setDefaultOperator(operator);
		Query luceneQuery;
		try {
			luceneQuery = parser.parse(query);
		} catch (ParseException e) {
			throw new Exception("Unable to parse query", e);
		}

		if (boost != 1.0 && boost != 0.0) {
			Query boostedQ = new BoostedQuery(luceneQuery, new ConstValueSource(boost));
			return boostedQ;
		}
		return luceneQuery;
	}

	public Query createQueryFuzzyField(String field, String term, int distanceUpTo, int prefixLength, float boost) {
		return createQueryFuzzyFields(new String[] { field }, term, distanceUpTo, prefixLength, boost);
	}

	public Query createQueryFuzzyFields(String[] fields, String term, int distanceUpTo, int prefixLength, float boost) {
		if (distanceUpTo < 1)
			distanceUpTo = 1;
		Query luceneQuery = queryBuilder//
				.keyword()//
				.fuzzy()//
				.withEditDistanceUpTo(distanceUpTo)//
				.withPrefixLength(prefixLength)//
				.onFields(fields)//
				// .boostedTo(boost)//
				.matching(term)//
				.createQuery();

		return luceneQuery;
	}

	public Query createQueryFuzzyQueryField(String field, String term, int distanceUpTo, int prefixLength, float boost) {
		FuzzyQuery query = new FuzzyQuery(new Term(field, term), distanceUpTo, prefixLength);
		query.setBoost(boost);
		return query;
	}

	public Query createQueryTerms(String field, String term, int minWordLen, boolean exceptNumbers, Analyzer analyzer) {
		String[] termsList = ShingleAnalyzer.retrieveCandidatesTerms(term, minWordLen, exceptNumbers, analyzer);
		List<Term> terms = new ArrayList<>();
		for (String word : termsList) {
			terms.add(new Term(field, word));
		}
		Query q = new TermsQuery(terms);
		return q;
	}

	public Query createQueryPhrase(String[] fields, String termq, Integer slop) {
		PhraseMatchingContext phrase = queryBuilder.phrase()//
				.withSlop(slop)//
				.onField(fields[0]);

		for (int i = 1; i < fields.length; i++)
			phrase.andField(fields[i]);

		Query query = phrase.sentence(termq).createQuery();

		return query;
	}

	public Query createQueryFuzzyShingles(String[] fields, String term, int minShingleSize, int maxShingleSize, int minWordLen, boolean exceptNumbers, int maxShingleStop,
			int distanceUpTo, int prefixLength, float boost, Analyzer analyzer) throws Exception {
		// log.info("==>createQueryFuzzyShingles<==");
		BooleanQuery.Builder bQueryBuilder = new BooleanQuery.Builder();

		String[] phrasesShingles = ShingleAnalyzer.termFrequencies("", term, minShingleSize, maxShingleSize,
				maxShingleStop, minWordLen, exceptNumbers, analyzer);

		if (phrasesShingles.length == 0) {
			return null;
		}

		for (int i = 0; i < fields.length; i++) {
			for (String phraseTerm : phrasesShingles) {
				BooleanJunction<BooleanJunction> booleanJunction = queryBuilder.bool();
				Query query = createQueryParse(fields[i], phraseTerm, Operator.AND, boost, analyzer);
				booleanJunction.should(query);
				bQueryBuilder.add(query, BooleanClause.Occur.SHOULD);
			}
		}

		return bQueryBuilder.build();
	}

	public Query createQueryBoolOneQueryForManyFields(String query, String fields[], BooleanClause.Occur[] flags, Analyzer analyzer) {
		BooleanQuery.Builder bQueryBuilder = new BooleanQuery.Builder();

		for (int i = 0; i < fields.length; i++) {
			QueryParser qp = new QueryParser(fields[i], analyzer);
			Query q = null;
			try {
				q = qp.parse(query);
			} catch (ParseException e) {
				throw new RuntimeException("Unable to parse query", e);
			}

			if (q != null && (!(q instanceof BooleanQuery) || ((BooleanQuery) q).clauses().size() > 0)) {
				if (flags != null && flags.length > i)
					bQueryBuilder.add(q, flags[i]);
				else
					bQueryBuilder.add(q, BooleanClause.Occur.SHOULD);
			}
		}
		// bQueryBuilder.setDisableCoord(true);
		return bQueryBuilder.build();
	}

	public Query createQuerySpanPhrase(String field, String term, float boost, int slop, int minWordLen, boolean exceptNumbers, boolean inOrder, Analyzer analyzer) {
		List<SpanQuery> myParts = new ArrayList<>();

		String[] termList = ShingleAnalyzer.retrieveCandidatesTerms(term, minWordLen, exceptNumbers, analyzer);
		if (termList.length == 0) {
			return null;
		}
		for (String word : termList) {
			SpanQuery spanQuery = new SpanTermQuery(new Term(field, word));
			spanQuery.setBoost(boost);
			myParts.add(spanQuery);
		}

		if (myParts.size() < 2) {
			return myParts.get(0);
		}
		SpanNearQuery query = new SpanNearQuery(myParts.toArray(new SpanQuery[myParts.size()]), slop, inOrder);

		return query;
	}

	public Query createSpanOrQuery(String field, String query, int distanceUpTo, int prefixLength, float boost, Analyzer analyzer) {
		FuzzyQuery fuzzyQuery = new FuzzyQuery(new Term(field, query), distanceUpTo, prefixLength);
		SpanQuery spanQuery = new SpanMultiTermQueryWrapper<>(fuzzyQuery);
		Query queryLucene = new SpanOrQuery(new SpanQuery[] { spanQuery });

		return queryLucene;
	}

	public Query createQuerySpanNearFuzzy(String field, String query, int distanceUpTo, int prefixLength, float boost, int slop, boolean inOrder,
			int minWordLen, boolean exceptNumbers, Analyzer analyzer) {

		String[] termList = ShingleAnalyzer.retrieveCandidatesTerms(query, minWordLen, exceptNumbers, analyzer);
		if (termList.length == 0) {
			return null;
		}

		List<SpanOrQuery> terms = new ArrayList<>();
		int cont = 0;
		for (String word : termList) {
			log.debug("TTTTTT " + word);
			if (cont++ > MAX_TERMS_LIMIT)
				break;
			Query spanOrQuery = createSpanOrQuery(field, word, distanceUpTo, prefixLength, boost, analyzer);
			terms.add((SpanOrQuery) spanOrQuery);
		}

		if (terms.size() < 2)
			return terms.get(0);
		Query queryLucene = new SpanNearQuery(terms.toArray(new SpanQuery[0]), slop, inOrder);

		return queryLucene;
	}

	public Query createQuerySpanOrQueryFuzzy(String field, String query, int distanceUpTo, int prefixLength, float boost, int slop, boolean inOrder,
			int minWordLen, boolean exceptNumbers, Analyzer analyzer) {

		String[] termList = ShingleAnalyzer.retrieveCandidatesTerms(query, minWordLen, exceptNumbers, analyzer);
		//log.info(Arrays.toString(termList));
		if (termList.length == 0) {
			return null;
		}

		List<SpanOrQuery> terms = new ArrayList<>();
		int cont = 0;
		for (String word : termList) {
			if (cont++ > MAX_TERMS_LIMIT)
				break;			
			Query spanOrQuery = createSpanOrQuery(field, word, distanceUpTo, prefixLength, boost, analyzer);
			terms.add((SpanOrQuery) spanOrQuery);
		}

		Query queryLucene = new SpanOrQuery(terms.toArray(new SpanQuery[0]));
		return queryLucene;
	}

	public Query spanOrQuery(SpanQuery... subqueries) {
		Query queryLucene = new SpanOrQuery(subqueries);
		return queryLucene;
	}

	public Query joinQueries(Query queryLucene, BooleanClause.Occur occur, Query queryLucene1, BooleanClause.Occur occur1) {
		BooleanQuery.Builder bQueryBuilder = new BooleanQuery.Builder();
		bQueryBuilder.add(queryLucene, occur);
		bQueryBuilder.add(queryLucene1, occur1);
		return bQueryBuilder.build();
	}

	public String highlightFieldSpanOrQueryFuzzy(String field, String query, String text, int distanceUpTo, int prefixLength, float boost, int slop,
			boolean inOrder, int minWordLen, boolean exceptNumbers, Analyzer analyzer) throws IOException, InvalidTokenOffsetsException {
		Query queryLucene = createQuerySpanOrQueryFuzzy(field, query, distanceUpTo, prefixLength, boost, slop, inOrder, minWordLen, exceptNumbers, analyzer);
		
		return highlightField(queryLucene, field, text,analyzer);
	}
	
	public String highlightFieldSpanOrQueryFuzzy(String field, List<String> queryList, String text, int distanceUpTo, int prefixLength, float boost, int slop,
			boolean inOrder, int minWordLen, boolean exceptNumbers, Analyzer analyzer) throws IOException, InvalidTokenOffsetsException {
		String query = "";
		for(String q : queryList){
			query = query + " " + q;
		}
		Query queryLucene = createQuerySpanOrQueryFuzzy(field, query, distanceUpTo, prefixLength, boost, slop, inOrder, minWordLen, exceptNumbers, analyzer);
		
		return highlightField(queryLucene, field, text,analyzer);
	}
	
	public String highlightFieldSpanNearFuzzy(String field, String query, String text, int distanceUpTo, int prefixLength, float boost, int slop,
			boolean inOrder, int minWordLen, boolean exceptNumbers, Analyzer analyzer) throws IOException, InvalidTokenOffsetsException {
		Query queryLucene = createQuerySpanNearFuzzy(field, query, distanceUpTo, prefixLength, boost, slop, inOrder, minWordLen, exceptNumbers, analyzer);
		String observed = highlightField(queryLucene, field, text,analyzer);
		return observed;
	}	
	
	public String highlightFieldSpanNearFuzzy(String field, List<String> queryList, String text, int distanceUpTo, int prefixLength, float boost, int slop,
			boolean inOrder, int minWordLen, boolean exceptNumbers, Analyzer analyzer) throws IOException, InvalidTokenOffsetsException {
		String query = "";
		for(String q : queryList){
			query = query + " " + q;
		}
			
		Query queryLucene = createQuerySpanNearFuzzy(field, query, distanceUpTo, prefixLength, boost, slop, inOrder, minWordLen, exceptNumbers, analyzer);
		String observed = highlightField(queryLucene, field, text,analyzer);
		return observed;
	}
	
	public String highlightField(Query query, String fieldName, String text,Analyzer analyzer) throws IOException, InvalidTokenOffsetsException {
		if (analyzer == null)
			return null;
		TokenStream tokenStream = analyzer.tokenStream(fieldName, text);
		Highlighter highlighter = getHighlighter(query, fieldName);
		
		String rv = highlighter.getBestFragments(tokenStream, text, 8, "...");
		return rv.length() == 0 ? null : rv;
	}
	
	public QueryScorer highlightFieldFragmentScorer(Query query, String fieldName, String text,Analyzer analyzer) throws IOException, InvalidTokenOffsetsException {
		TokenStream tokenStream = analyzer.tokenStream(fieldName, text);
		Highlighter highlighter = getHighlighter(query, fieldName);
		
		highlighter.getBestFragments(tokenStream, text, 8, "...");
		return (QueryScorer) highlighter.getFragmentScorer();
	}
	
	public Highlighter getHighlighter(Query query, String fieldName) throws IOException{
		// Assuming "<B>", "</B>" used to highlight
		SimpleHTMLFormatter formatter = new SimpleHTMLFormatter();
		QueryScorer scorer = new QueryScorer(query, fieldName, "FIELD_NAME");
		
		Highlighter highlighter = new Highlighter(formatter, scorer);
		highlighter.setTextFragmenter(new SimpleFragmenter(Integer.MAX_VALUE));
		return highlighter; 
	}
}
