package gob.bcb.lavado.search;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.Fields;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.LeafReader;
import org.apache.lucene.index.MultiFields;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.BytesRefHash;

import gob.bcb.lavado.search.analysis.ShingleAnalyzer;

/**
 * Class for recording terms stored in the query index.
 *
 * An instance of QueryTermFilter is passed to
 * {@link Presearcher#buildQuery(LeafReader, QueryTermFilter)}, and can be used
 * to restrict the presearcher's disjunction query to terms in the index.
 *
 * @see uk.co.flax.luwak.analysis.BytesRefFilteredTokenFilter
 */
public class QueryTermFilter {
	public static final String ANYTOKEN_FIELD = "__anytokenfield";
	public static final String ANYTOKEN = "__ANYTOKEN__";

	private final Map<String, BytesRefHash> termsHash = new HashMap<>();

	/**
	 * Create a QueryTermFilter for an IndexReader
	 * 
	 * @param reader
	 *            the {@link IndexReader}
	 * @throws IOException
	 *             on error
	 */
	public QueryTermFilter(IndexReader reader) throws IOException {
		Fields mf = MultiFields.getFields(reader);
		for (String field : mf) {
			BytesRefHash terms = new BytesRefHash();
			Terms t = mf.terms(field);
			if (t != null) {
				TermsEnum te = t.iterator();
				BytesRef term;
				while ((term = te.next()) != null) {
					terms.add(term);
				}
			}
			termsHash.put(field, terms);
		}

	}

	public QueryTermFilter(String[] fields, Map<String, Terms> termsMap) throws IOException {
		for (String field : fields) {
			BytesRefHash terms = new BytesRefHash();
			Terms t = termsMap.get(field);
			if (t != null) {
				TermsEnum te = t.iterator();
				BytesRef term;
				while ((term = te.next()) != null) {
					terms.add(term);
				}
			}
			termsHash.put(field, terms);
		}

	}

	public QueryTermFilter(String[] fields, String term, int minWordLen, boolean exceptNumbers, Analyzer analyzer) throws IOException {
		String[] termList = ShingleAnalyzer.retrieveCandidatesTerms(term,minWordLen, exceptNumbers, analyzer);

		for (int i = 0; i < fields.length; i++) {
			for (String word : termList) {
				Term t = new Term(fields[i], word);
				
				if (!termsHash.containsKey(t.field()))
					termsHash.put(t.field(), new BytesRefHash());

				BytesRefHash termslist = termsHash.get(t.field());
				termslist.add(t.bytes());
			}
		}
	}
	public QueryTermFilter(String field, String term, int minWordLen, boolean exceptNumbers, Analyzer analyzer) throws IOException {
		this(new String[]{field}, term, minWordLen, exceptNumbers, analyzer);
	}
	/**
	 * Get a BytesRefHash containing all terms for a particular field
	 * 
	 * @param field
	 *            the field
	 * @return a {@link BytesRefHash} containing all terms for the specified
	 *         field
	 */
	public BytesRefHash getTerms(String field) {
		if (termsHash.containsKey(field))
			return termsHash.get(field);
		return new BytesRefHash();
	}
}
