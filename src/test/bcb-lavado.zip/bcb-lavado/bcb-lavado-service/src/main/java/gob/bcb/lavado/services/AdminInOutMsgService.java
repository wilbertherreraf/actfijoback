package gob.bcb.lavado.services;

import java.util.List;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.GenUsuario;
import gob.bcb.lavado.pojos.MensajesDatos;

public interface AdminInOutMsgService {
	List<Empleado> findEmpleadosByCodempCodPte(String usrCodemp, String codPte, String login, String estacion);

	SwfLote guardarLote(Integer codEmpleado, SwfLote swfLoteNew, ArchivoSinple archivoSinple, List<MensajesDatos> mensajesDatosLista);

	List<MensajesDatos> desparsearLoteFromArchivoSinple(ArchivoSinple archivoSinple, String codUsr);

	void asignarYEnviarMailDeNotificacion(MensajesDatos mensajesDatos, Integer codEmp, String codusuario, String estacion);


}