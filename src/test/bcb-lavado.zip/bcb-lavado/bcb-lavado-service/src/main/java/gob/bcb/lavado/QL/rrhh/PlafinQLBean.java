package gob.bcb.lavado.QL.rrhh;

import java.util.List;

import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.UnidadOrgCoin;

public interface PlafinQLBean {

	List<Empleado> findEmpleadosPorUnid(String codUnidad);

	List<UnidadOrgCoin> unidadesOrg();

	UnidadOrgCoin unidadOrgByCodigo(Integer are_cod);

	Empleado findEmpleado(Integer nroEmpleado, boolean filtrarVigente);

	Empleado findEmpleado(Integer nroEmpleado);

}
