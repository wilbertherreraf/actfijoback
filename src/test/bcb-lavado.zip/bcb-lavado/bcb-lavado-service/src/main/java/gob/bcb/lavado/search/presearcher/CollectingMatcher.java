package gob.bcb.lavado.search.presearcher;

import java.io.IOException;
import java.util.Map;

import org.apache.lucene.index.LeafReaderContext;
import org.apache.lucene.search.Collector;
import org.apache.lucene.search.LeafCollector;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Scorer;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.transform.ResultTransformer;

import gob.bcb.lavado.search.CandidateMatcher;
import gob.bcb.lavado.search.DocumentBatch;
import gob.bcb.lavado.search.QueryMatch;
import gob.bcb.lavado.search.dto.OfacMatch;
import gob.bcb.lavado.search.dto.SearchResultOfac;

/**
 * Extend this class to create matches that require a Scorer
 *
 * @param <T> the type of QueryMatch that this class returns
 */
public abstract class CollectingMatcher<T extends QueryMatch> extends CandidateMatcher<T>{

    /**
     * Creates a new CollectingMatcher for the supplied DocumentBatch
     *
     * @param docs the documents to run queries against
     */
    public CollectingMatcher(DocumentBatch docs) {
        super(docs);
    }

    protected MatchCollector buildMatchCollector(String queryId) {
        return new MatchCollector(queryId);
    }

    /**
     * Called when a query matches an InputDocument
     * @param queryId the query ID
     * @param docId the docId for the InputDocument in the DocumentBatch
     * @param scorer the Scorer for this query
     * @return a match object
     * @throws IOException on IO error
     */
    protected abstract T doMatch(String queryId, String docId, Scorer scorer) throws IOException;

    protected class MatchCollector implements Collector {

        T match = null;

        private Scorer scorer;
        private final String queryId;

        public MatchCollector(String queryId) {
            this.queryId = queryId;
        }


        @Override
        public boolean needsScores() {
            return true;
        }


		@Override
		public LeafCollector getLeafCollector(LeafReaderContext context) throws IOException {
			// TODO Auto-generated method stub
			return null;
		}

    }
}
