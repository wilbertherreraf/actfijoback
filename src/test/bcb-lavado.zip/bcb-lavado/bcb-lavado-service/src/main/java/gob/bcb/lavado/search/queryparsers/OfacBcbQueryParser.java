package gob.bcb.lavado.search.queryparsers;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.SimpleAnalyzer;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.Query;

public class OfacBcbQueryParser extends QueryParser {

	//protected static float SuffixedTermBoost = 2.0F;

	public OfacBcbQueryParser(String f, Analyzer a) {
		super(f, a);
	}

	@Override
	public org.apache.lucene.search.Query parse(String query) throws ParseException {

		String q = "";
		for (int i = 0; i < query.length(); i++) {
			if (query.charAt(i) == '"' && i + 1 < query.length() && !Character.isWhitespace(query.charAt(i + 1))) {
				if (i > 0 && !Character.isWhitespace(query.charAt(i - 1))) {
					q += '\\';
				}
			}
			q += query.charAt(i);
		}
		
		return super.parse(q);
	}
	
//	public static void main(String[] args) {
//        QueryParser qp = new OfacBcbQueryParser("f", new SimpleAnalyzer());
//        try {
//        	Query luceneQuery = qp.parse("hola mundo");
//        	System.out.println(luceneQuery);
//        	luceneQuery = qp.parse("\"hola mundo\"");
//        	System.out.println(luceneQuery);        	
//        	luceneQuery = qp.parse("hoooo \"hola mundo\" wil");
//        	System.out.println(luceneQuery);        	
//        	luceneQuery = qp.parse("\"hola mundo\" wil\"herr");
//        	System.out.println(luceneQuery);        	
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
}
