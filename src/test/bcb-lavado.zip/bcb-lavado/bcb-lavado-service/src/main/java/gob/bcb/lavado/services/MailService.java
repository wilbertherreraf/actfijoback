package gob.bcb.lavado.services;

import java.util.List;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.lavado.client.pojos.GenLauDto;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.pojos.Asignacion;
import gob.bcb.lavado.pojos.MensajesDatos;

public interface MailService {

	//void sendEmail(String[] to, String subject, String content, boolean isMultipart, ArchivoSinple archivoSinple, boolean isHtml);

	void sendSwiftAsignForProcessWithAttachEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle, ArchivoSinple archivoSinple);

	void sendAlertSwiftForRevisionEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle, ArchivoSinple archivoSinple);

	void sendAlertSwiftAutorizadoEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle, ArchivoSinple archivoSinple);

	void sendAlertCodeLauEmail(GenLauDto genLauDto, EmailDetalle emailDetalle);
	
	void sendConfirmaSolicNroSwiftEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle);
}
