package gob.bcb.lavado.services;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.QL.rrhh.PlafinQLBean;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfAsignamensajePK;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.pojos.Asignacion;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.GenUsuario;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfAsignamensajeDao;
import gob.bcb.lavado.repository.SwfLoteDao;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.repository.SwfPersonaDao;

@Service("adminInOutMsgService")
public class AdminInOutMsgServiceImpl implements AdminInOutMsgService {
	private static final Logger log = LoggerFactory.getLogger(AdminInOutMsgServiceImpl.class);

	@Autowired
	private SwfAsignamensajeDao swfAsignamensajeDao;
	@Autowired
	private SwfPersonaDao swfPersonaDao;
	@Autowired
	private SwfLoteDao swfLoteDao;
	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private PlafinQLBean plafinQLBean;
	@Autowired
	private SwiftBcbParserService swiftBcbParserService;
	@Autowired
	private ReporteSwiftService reporteSwiftService;
	@Autowired
	private MailService mailService;
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;

	public List<Empleado> findEmpleadosByCodempCodPte(String usrCodemp, String codPte, String login, String estacion) {
		// selecciona los empleados de las unidades con las que trabaja el
		// usuario

		List<Empleado> empleadoLista = new ArrayList<Empleado>();
		Integer codempleado = Integer.valueOf(usrCodemp);

		SwfPersona swfPersonaUser = swfPersonaDao.findOrCreateSwfPersonaFromRRHH(codempleado, null, login, estacion);

		log.debug("En filtrarEmpleados " + usrCodemp + " codPte: " + swfPersonaUser.getPerArecod());
		// empleados asignados en el año
		List<SwfPersona> swfPersonaLista = swfPersonaDao.empleadosAsignados(codempleado, null, GregorianCalendar.getInstance().get(Calendar.YEAR));

		Map<Integer, Empleado> mapCtrlCodEmp = new HashMap<Integer, Empleado>();
		for (SwfPersona swfPersona : swfPersonaLista) {
			Empleado empleado = new Empleado();
			empleado.setNroEmpleado(swfPersona.getPerCodemp());
			empleado.setNombre(swfPersona.getPerNombre());
			// se asigna la unidad registrada en bdd swift
			empleado.setCodUnidadOrg(swfPersona.getPerArecod());
			empleado.setEmail(swfPersona.getPerEmail());
			empleado.setDescUnidadOrg("UNIDAD SIN DESCRIPCION " + swfPersona.getPerArecod());
			if (!mapCtrlCodEmp.containsKey(empleado.getNroEmpleado()))
				mapCtrlCodEmp.put(swfPersona.getPerCodemp(), empleado);
		}

		List<SwfPersona> swfPersonaListaLvd = swfPersonaDao.empleadosCreadosEnLvd();
		for (SwfPersona swfPersona : swfPersonaListaLvd) {
			Empleado empleado = new Empleado();
			empleado.setNroEmpleado(swfPersona.getPerCodemp());
			empleado.setNombre(swfPersona.getPerNombre());
			empleado.setCodUnidadOrg(swfPersona.getPerArecod());
			empleado.setEmail(swfPersona.getPerEmail());
			empleado.setDescUnidadOrg("UNIDAD SIN DESCRIPCION " + swfPersona.getPerArecod());
			if (!mapCtrlCodEmp.containsKey(empleado.getNroEmpleado()))
				mapCtrlCodEmp.put(swfPersona.getPerCodemp(), empleado);
		}

		// por defecto se agrega los empleados del area del usuario
		if (!StringUtils.isBlank(swfPersonaUser.getPerArecod())) {
			List<Empleado> empleadosUnidsLista = plafinQLBean.findEmpleadosPorUnid(swfPersonaUser.getPerArecod());
			for (Empleado empleado : empleadosUnidsLista) {
				if (!mapCtrlCodEmp.containsKey(empleado.getNroEmpleado())) {
					mapCtrlCodEmp.put(empleado.getNroEmpleado(), empleado);
				}
			}
		}

		List<String> codAreaLista = swfAsignamensajeDao.areasPorEmpEstado(codempleado, null);
		for (String codArea : codAreaLista) {
			if (!StringUtils.isBlank(swfPersonaUser.getPerArecod()) && swfPersonaUser.getPerArecod().equals(codArea)) {
				continue;
			}
			List<Empleado> empleadosUnidsLista = plafinQLBean.findEmpleadosPorUnid(codArea);

			for (Empleado empleado : empleadosUnidsLista) {
				if (!mapCtrlCodEmp.containsKey(empleado.getNroEmpleado())) {
					mapCtrlCodEmp.put(empleado.getNroEmpleado(), empleado);
				}
			}
		}
		empleadoLista = mapCtrlCodEmp.values().stream().collect(Collectors.toList());
		log.debug("empleados filtrados " + empleadoLista.size());
		return empleadoLista;
	}

	/**
	 * Guarda el lote y lo scanea de forma asyncronica
	 */
	public SwfLote guardarLote(Integer codEmpleado, SwfLote swfLoteNew, ArchivoSinple archivoSinple, List<MensajesDatos> mensajesDatosLista) {
		SwfLote swfLote = guardarLoteSinScan(codEmpleado, swfLoteNew, archivoSinple, mensajesDatosLista);
		swiftBcbSearcherService.scanLoteAsync(swfLote.getLotNrolote());
		log.info("@@@@@@@@@@@@@@ FIIIIIIIIIIIIIIIIN... @@@@@@@@@@@@@@@@");
		return swfLote;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	private SwfLote guardarLoteSinScan(Integer codEmpleado, SwfLote swfLoteNew, ArchivoSinple archivoSinple, List<MensajesDatos> mensajesDatosLista) {
		if (mensajesDatosLista == null || mensajesDatosLista.size() == 0)
			throw new SwiftAdminException("Lote sin registros de mensajes, parametro mensajesDatosLista invalido");

		log.info("En guardarLote Swifts " + codEmpleado + " regs: " + mensajesDatosLista.size());

		SwfLote swfLote = swfLoteDao.guardarLote(codEmpleado, swfLoteNew, archivoSinple);

		for (MensajesDatos mensajesDatos : mensajesDatosLista) {
			SwfMensaje swfMensaje = mensajesDatos.getSwfMensaje();
			swfMensaje.setMenCodapp(Constants.COD_APP_NEMO);
			swfMensaje.setMenNrolote(swfLote.getLotNrolote());
			swfMensaje.setMenAuditusr(swfLoteNew.getLotAuditusr());
			swfMensaje.setMenAuditwst(swfLoteNew.getLotAuditwst());

			swfMensaje = swfMensajeDao.registrarNuevo(swfMensaje);

			// el codigo de empleado y el padre son los mismos
			swfAsignamensajeDao.crearAsignacion(swfMensaje, codEmpleado, codEmpleado, Constants.AREA_ADM, Constants.TAB_ESTREVISION_PEND, swfLoteNew.getLotAuditusr(),
					swfLoteNew.getLotAuditwst());
		}

		String p = UtilsFile.grabaEnArchivo(archivoSinple.getStream(), archivoSinple.getPathFile());

		log.info("archivo lote swifts[" + swfLote.getLotNrolote() + "] salvado " + p);
		log.info("@@@@@@@@@@@@@@OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO@@@@@@@@@@@@@@@@");
		return swfLote;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void asignarYEnviarMailDeNotificacion(MensajesDatos mensajesDatos, Integer codEmp, String codusuario, String estacion) {
		log.info("-->asignarYEnviarMailDeNotificacion Asignando [" + mensajesDatos.getSecuencia() + "] " + mensajesDatos.getSwfMensaje().getMenCodmen());

		// busvamos todos las asignaciones de mencodmen por codEmp
		List<Asignacion> asignacionLista = swfAsignamensajeDao.asignar(mensajesDatos.getSwfMensaje().getMenCodmen(), codEmp, codusuario, estacion);
		if (asignacionLista.size() == 0) {
			return;
		}
		mensajesDatos.setAsignacionLista(asignacionLista);

		SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(mensajesDatos.getSwfMensaje().getMenCodmen());
		mensajesDatos.setSwfMensaje(swfMensaje);

		ArchivoSinple archivoSinplePDF = null;
		try {
			archivoSinplePDF = reporteSwiftService.generarReportePDFFromPlano(swfMensaje.getMenPlano(), codusuario, mensajesDatos.getSwfMensaje().getMenCodmen());
			log.info("reportSwift reporte PDF generado " + archivoSinplePDF.getNameOriginal());

		} catch (Exception e) {
			log.error("Error al geernar reporte pdf: " + e.getMessage(), e);
		}
		List<String> correos = new ArrayList<>();
		EmailDetalle emailDetalle = new EmailDetalle();
		if (mensajesDatos.getAsignacionLista() != null) {
			for (Asignacion asignacion : mensajesDatos.getAsignacionLista()) {
				SwfPersona swfPersona = asignacion.getSwfPersona();

				if (swfPersona != null && !StringUtils.isBlank(swfPersona.getPerEmail())) {
					String email = swfPersona.getPerEmail();
					correos.add(email);
				}
			}
		}

		emailDetalle.setTo(correos.toArray(new String[correos.size()]));
		mailService.sendSwiftAsignForProcessWithAttachEmail(mensajesDatos, emailDetalle, archivoSinplePDF);
	}

	public List<MensajesDatos> desparsearLoteFromArchivoSinple(ArchivoSinple archivoSinple, String codUsr) {
		log.info("En desparseo usuario {} archivo lote {} ", codUsr, archivoSinple.getNameOriginal());
		List<MensajesDatos> mensajesDatosLista = new ArrayList<MensajesDatos>();
		try {
			String fileAsString = IOUtils.toString(archivoSinple.getStream(), "ISO-8859-1");
			mensajesDatosLista = swiftBcbParserService.swfMensajeFromLote(fileAsString);
		} catch (Exception e) {
			log.error("Error al desparsear lote " + e.getMessage(), e);
			throw new SwiftAdminException(e);
		}

		return mensajesDatosLista;
	}
}
