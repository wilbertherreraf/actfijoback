package gob.bcb.lavado.services;

public interface OfacScanService {
}