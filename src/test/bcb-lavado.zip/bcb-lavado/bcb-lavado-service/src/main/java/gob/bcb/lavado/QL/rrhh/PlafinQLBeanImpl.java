package gob.bcb.lavado.QL.rrhh;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.UnidadOrgCoin;

@Repository("plafinQLBean")
public class PlafinQLBeanImpl implements PlafinQLBean {
	private static final Logger log = LoggerFactory.getLogger(PlafinQLBeanImpl.class);

	@PersistenceContext(unitName = Constants.PUNIT_RRHH)
	private EntityManager em;
	
	@Autowired
	@Qualifier("entityManagerFactorySap")
	private EntityManagerFactory entityManagerFactorySap;
	
	public List<Empleado> findEmpleadosPorUnid(String codUnidad) {
		String jsql = "SELECT distinct e.emp_cod, a.are_cod, ";
		jsql = jsql.concat("nvl(trim(e.emp_ape_pat), '') ||' '|| nvl(trim(e.emp_ape_mat),'') ||' '||trim(e.emp_nom) nombre, ");
		jsql = jsql.concat("a.are_uni, nvl(trim(e.emp_mail),'') correo ");
		jsql = jsql.concat("from empleado e, item i, area a ");
		jsql = jsql.concat("where e.emp_cod = i.ite_emp ");
		jsql = jsql.concat("and i.ite_pro = a.are_cod ");
		jsql = jsql.concat("and i.ite_est = 'v' ");
		jsql = jsql.concat("AND a.are_est = 'v' ");

		if (!StringUtils.isBlank(codUnidad)) {
			jsql = jsql.concat("and a.are_cod = :cod_unidad_org ");
		}
		jsql = jsql.concat("order by nombre ");

		Query query = em.createNativeQuery(jsql);
		if (!StringUtils.isBlank(codUnidad)) {
			query.setParameter("cod_unidad_org", codUnidad);
		}

		List<Empleado> empleadosUnidsLista = new ArrayList<Empleado>();
		try {
			List<Object[]> result = query.getResultList();

			for (Object[] resultObj : result) {
				Empleado empleado = new Empleado();

				Integer codigo = (Integer) resultObj[0];
				empleado.setNroEmpleado(Integer.valueOf(codigo.toString()));
				Integer CodUnidadOrg = (Integer) resultObj[1];
				empleado.setCodUnidadOrg(String.valueOf(CodUnidadOrg));
				empleado.setNombre((String) resultObj[2]);
				empleado.setDescUnidadOrg((String) resultObj[3]);
				empleado.setEmail((String) resultObj[4]);				
				empleadosUnidsLista.add(empleado);
			}

		} catch (Exception e) {
			log.error("Error al sumar : " + e.getMessage(), e);
			throw new DataException("Error al sumar : " + e.getMessage());
		}

		return empleadosUnidsLista;
	}

	public Empleado findEmpleado(Integer nroEmpleado, boolean filtrarVigente) {
		if (nroEmpleado == null){
			log.error("parametro nroempleado nulo");
			return null;
		}
		String jsql = "SELECT distinct e.emp_cod, a.are_cod, ";
		jsql = jsql.concat("nvl(trim(e.emp_ape_pat), '') ||' '|| nvl(trim(e.emp_ape_mat),'') ||' '||trim(e.emp_nom) nombre, ");
		jsql = jsql.concat("a.are_uni, nvl(trim(e.emp_mail),'') correo ");
		jsql = jsql.concat("from empleado e, item i, area a ");
		jsql = jsql.concat("where e.emp_cod = i.ite_emp ");
		jsql = jsql.concat("and i.ite_pro = a.are_cod ");
		jsql = jsql.concat("and e.emp_cod = :nroEmpleado ");

		if (filtrarVigente) {
			jsql = jsql.concat("and i.ite_est = 'v' ");
			jsql = jsql.concat("AND a.are_est = 'v' ");
		}
		Query query = em.createNativeQuery(jsql);
		query.setParameter("nroEmpleado", nroEmpleado);

		List<Empleado> empleadosUnidsLista = new ArrayList<Empleado>();
		try {
			List<Object[]> result = query.getResultList();

			for (Object[] resultObj : result) {
				Empleado empleado = new Empleado();

				Integer codigo = (Integer) resultObj[0];
				empleado.setNroEmpleado(Integer.valueOf(codigo.toString()));
				Integer CodUnidadOrg = (Integer) resultObj[1];
				empleado.setCodUnidadOrg(String.valueOf(CodUnidadOrg));
				empleado.setNombre((String) resultObj[2]);
				empleado.setDescUnidadOrg((String) resultObj[3]);
				empleado.setEmail((String) resultObj[4]);				
				empleadosUnidsLista.add(empleado);
			}

		} catch (Exception e) {
			log.error("Error findEmpleado : " + e.getMessage(), e);
			throw new DataException("Error findEmpleado : " + e.getMessage());
		}
		if (empleadosUnidsLista.size() > 0) {
			return empleadosUnidsLista.get(0);
		}
		return null;
	}
	public Empleado findEmpleado(Integer nroEmpleado) {
		String jsql = "SELECT e.emp_cod, ";
		jsql = jsql.concat("nvl(trim(e.emp_ape_pat), '') ||' '|| nvl(trim(e.emp_ape_mat),'') ||' '||trim(e.emp_nom) nombre, nvl(trim(e.emp_mail),'') correo ");
		jsql = jsql.concat("from empleado e ");
		jsql = jsql.concat("where e.emp_cod = :nroEmpleado ");

		Query query = em.createNativeQuery(jsql);
		query.setParameter("nroEmpleado", nroEmpleado);

		List<Empleado> empleadosUnidsLista = new ArrayList<Empleado>();
		try {
			List<Object[]> result = query.getResultList();

			for (Object[] resultObj : result) {
				Empleado empleado = new Empleado();

				Integer codigo = (Integer) resultObj[0];
				empleado.setNroEmpleado(Integer.valueOf(codigo.toString()));
				empleado.setNombre((String) resultObj[1]);
				empleado.setEmail((String) resultObj[2]);				
				empleadosUnidsLista.add(empleado);
			}

		} catch (Exception e) {
			log.error("Error findEmpleado : " + e.getMessage(), e);
			throw new DataException("Error findEmpleado : " + e.getMessage());
		}
		if (empleadosUnidsLista.size() > 0) {
			return empleadosUnidsLista.get(0);
		}
		return null;
	}
	public List<UnidadOrgCoin> unidadesOrg() {

		String jsql = "select a.are_cod, a.are_uni ";
		jsql = jsql.concat("from area a ");
		jsql = jsql.concat("where a.are_est = 'v' ");
		jsql = jsql.concat("and exists (select 1 ");
		jsql = jsql.concat("from  item i  ");
		jsql = jsql.concat("where i.ite_pro = a.are_cod ");
		jsql = jsql.concat("and i.ite_est = 'v') ");
		jsql = jsql.concat("order by 2 ");
		Query query = em.createNativeQuery(jsql);

		List<UnidadOrgCoin> unidadOrgCoinLista = new ArrayList<UnidadOrgCoin>();
		try {
			List<Object[]> result = query.getResultList();

			for (Object[] resultObj : result) {
				UnidadOrgCoin unidadOrgCoin = new UnidadOrgCoin();
				Integer CodUnidadOrg = (Integer) resultObj[0];
				unidadOrgCoin.setCodUnidadOrg(String.valueOf(CodUnidadOrg));
				unidadOrgCoin.setDescUnidadOrg((String) resultObj[1]);

				unidadOrgCoinLista.add(unidadOrgCoin);
			}

		} catch (Exception e) {
			log.error("Error al recuperar datos : " + e.getMessage(), e);
			throw new DataException("Error al recuperar datos : " + e.getMessage());
		}

		return unidadOrgCoinLista;
	}

	public UnidadOrgCoin unidadOrgByCodigo(Integer are_cod) {

		String jsql = "select distinct a.are_cod, a.are_uni ";
		jsql = jsql.concat("from area a ");
		jsql = jsql.concat("where a.are_cod = :are_cod ");
		jsql = jsql.concat("and exists (select 1 ");
		jsql = jsql.concat("from  item i  ");
		jsql = jsql.concat("where i.ite_pro = a.are_cod) ");

		Query query = em.createNativeQuery(jsql);
		query.setParameter("are_cod", are_cod);

		List<UnidadOrgCoin> unidadOrgCoinLista = new ArrayList<UnidadOrgCoin>();
		try {
			List<Object[]> result = query.getResultList();

			for (Object[] resultObj : result) {
				UnidadOrgCoin unidadOrgCoin = new UnidadOrgCoin();
				Integer CodUnidadOrg = (Integer) resultObj[0];
				unidadOrgCoin.setCodUnidadOrg(String.valueOf(CodUnidadOrg));
				unidadOrgCoin.setDescUnidadOrg((String) resultObj[1]);

				unidadOrgCoinLista.add(unidadOrgCoin);
			}

		} catch (Exception e) {
			log.error("Error al recuperar datos : " + e.getMessage(), e);
			throw new DataException("Error al recuperar datos : " + e.getMessage());
		}

		if (unidadOrgCoinLista.size() > 0) {
			return unidadOrgCoinLista.get(0);
		}
		return null;
	}
	
}
