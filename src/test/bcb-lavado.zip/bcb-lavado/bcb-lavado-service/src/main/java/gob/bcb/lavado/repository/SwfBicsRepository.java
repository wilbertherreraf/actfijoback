package gob.bcb.lavado.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfBicsPK;

public interface SwfBicsRepository {
	//public interface SwfBicsRepository extends CrudRepository<SwfBics, SwfBicsPK>{	
//	@Query("SELECT t FROM SwfBics t WHERE t.id.bicCodbic = :bicCodbic and t.id.bicCodbranch = :bicCodbranch ")
//	SwfBics findByCodigo(@Param("bicCodbic") String bicCodbic, @Param("bicCodbranch") String bicCodbranch);
}
