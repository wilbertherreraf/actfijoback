package gob.bcb.lavado.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "swf_numeraswf")
public class SwfNumeraswf implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "nro_codnro")
	private Integer nroCodnro;

	@Column(name = "nro_gestion")
	private Integer nroGestion;

	@Column(name = "nro_nroswift")
	private Integer nroNroswift;

	@Column(name = "nro_codemp")
	private Integer nroCodemp;

	@Column(name = "nro_codsolic")
	private String nroCodsolic;

	@Column(name = "nro_descrip")
	private String nroDescrip;

	@Column(name = "nro_idverifica")
	private String nroIdverifica;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "nro_fechsolic")
	private Date nroFechsolic;

	@Temporal(TemporalType.DATE)
	@Column(name = "nro_fecha")
	private Date nroFecha;
	
	@Column(name = "nro_tabestadonro")
	private Integer nroTabestadonro;

	@Column(name = "nro_estadonro")
	private Integer nroEstadonro;

	@Column(name = "nro_tabtipnroswf")
	private Integer nroTabtipnroswf;

	@Column(name = "nro_tipnroswf")
	private Integer nroTipnroswf;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "nro_auditfho")
	private Date nroAuditfho;

	@Column(name = "nro_auditusr")
	private String nroAuditusr;

	@Column(name = "nro_auditwst")
	private String nroAuditwst;

	@ManyToOne(fetch = FetchType.EAGER)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumns({ @JoinColumn(updatable = false, insertable = false, name = "nro_tipnroswf", referencedColumnName = "des_codigo"),
			@JoinColumn(updatable = false, insertable = false, name = "nro_tabtipnroswf", referencedColumnName = "des_codtab") })
	private GenDesctabla genDesctablaTiponroswf;

	@ManyToOne(fetch = FetchType.EAGER)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumns({ @JoinColumn(updatable = false, insertable = false, name = "nro_estadonro", referencedColumnName = "des_codigo"),
			@JoinColumn(updatable = false, insertable = false, name = "nro_tabestadonro", referencedColumnName = "des_codtab") })
	private GenDesctabla genDesctablaEstadonro;

	@ManyToOne(fetch = FetchType.EAGER)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(updatable = false, insertable = false, name = "nro_codemp", referencedColumnName = "per_codemp")
	private SwfPersona swfPersona;
	
	public SwfNumeraswf() {
		// TODO Auto-generated constructor stub
	}

	public Integer getNroCodnro() {
		return nroCodnro;
	}

	public void setNroCodnro(Integer nroCodnro) {
		this.nroCodnro = nroCodnro;
	}

	public Integer getNroGestion() {
		return nroGestion;
	}

	public void setNroGestion(Integer nroGestion) {
		this.nroGestion = nroGestion;
	}

	public Integer getNroNroswift() {
		return nroNroswift;
	}

	public void setNroNroswift(Integer nroNroswift) {
		this.nroNroswift = nroNroswift;
	}

	public Integer getNroCodemp() {
		return nroCodemp;
	}

	public void setNroCodemp(Integer nroCodemp) {
		this.nroCodemp = nroCodemp;
	}

	public String getNroCodsolic() {
		return nroCodsolic;
	}

	public void setNroCodsolic(String nroCodsolic) {
		this.nroCodsolic = nroCodsolic;
	}

	public String getNroDescrip() {
		return nroDescrip;
	}

	public void setNroDescrip(String nroDescrip) {
		this.nroDescrip = nroDescrip;
	}

	public String getNroIdverifica() {
		return nroIdverifica;
	}

	public void setNroIdverifica(String nroIdverifica) {
		this.nroIdverifica = nroIdverifica;
	}

	public Date getNroFechsolic() {
		return nroFechsolic;
	}

	public void setNroFechsolic(Date nroFechsolic) {
		this.nroFechsolic = nroFechsolic;
	}

	public Integer getNroTabestadonro() {
		return nroTabestadonro;
	}

	public void setNroTabestadonro(Integer nroTabestadonro) {
		this.nroTabestadonro = nroTabestadonro;
	}

	public Integer getNroEstadonro() {
		return nroEstadonro;
	}

	public void setNroEstadonro(Integer nroEstadonro) {
		this.nroEstadonro = nroEstadonro;
	}

	public Integer getNroTabtipnroswf() {
		return nroTabtipnroswf;
	}

	public void setNroTabtipnroswf(Integer nroTabtipnroswf) {
		this.nroTabtipnroswf = nroTabtipnroswf;
	}

	public Integer getNroTipnroswf() {
		return nroTipnroswf;
	}

	public void setNroTipnroswf(Integer nroTipnroswf) {
		this.nroTipnroswf = nroTipnroswf;
	}

	public Date getNroAuditfho() {
		return nroAuditfho;
	}

	public void setNroAuditfho(Date nroAuditfho) {
		this.nroAuditfho = nroAuditfho;
	}

	public String getNroAuditusr() {
		return nroAuditusr;
	}

	public void setNroAuditusr(String nroAuditusr) {
		this.nroAuditusr = nroAuditusr;
	}

	public String getNroAuditwst() {
		return nroAuditwst;
	}

	public void setNroAuditwst(String nroAuditwst) {
		this.nroAuditwst = nroAuditwst;
	}

	public GenDesctabla getGenDesctablaTiponroswf() {
		return genDesctablaTiponroswf;
	}

	public void setGenDesctablaTiponroswf(GenDesctabla genDesctablaTiponroswf) {
		this.genDesctablaTiponroswf = genDesctablaTiponroswf;
	}

	public GenDesctabla getGenDesctablaEstadonro() {
		return genDesctablaEstadonro;
	}

	public void setGenDesctablaEstadonro(GenDesctabla genDesctablaEstadonro) {
		this.genDesctablaEstadonro = genDesctablaEstadonro;
	}

	@Override
	public String toString() {
		return "SwfNumeraswf [nroCodnro=" + nroCodnro + ", nroGestion=" + nroGestion + ", nroNroswift=" + nroNroswift + ", nroCodemp=" + nroCodemp
				+ ", nroCodsolic=" + nroCodsolic + ", nroDescrip=" + nroDescrip + ", nroIdverifica=" + nroIdverifica + ", nroFechsolic=" + nroFechsolic
				+ ", nroTabestadonro=" + nroTabestadonro + ", nroEstadonro=" + nroEstadonro + ", nroTabtipnroswf=" + nroTabtipnroswf + ", nroTipnroswf="
				+ nroTipnroswf + ", nroAuditfho=" + nroAuditfho + ", nroAuditusr=" + nroAuditusr + ", nroAuditwst=" + nroAuditwst + "]";
	}

	public Date getNroFecha() {
		return nroFecha;
	}

	public void setNroFecha(Date nroFecha) {
		this.nroFecha = nroFecha;
	}

	public SwfPersona getSwfPersona() {
		return swfPersona;
	}

	public void setSwfPersona(SwfPersona swfPersona) {
		this.swfPersona = swfPersona;
	}

}
