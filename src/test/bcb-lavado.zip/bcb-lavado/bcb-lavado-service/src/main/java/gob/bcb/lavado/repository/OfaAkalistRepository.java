package gob.bcb.lavado.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaAkalist;

@Repository
public interface OfaAkalistRepository extends JpaRepository<OfaAkalist,Integer>{
	List<OfaAkalist> findByAkaEntryuid(@Param("akaEntryuid") Integer akaEntryuid);
}
