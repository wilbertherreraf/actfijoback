package gob.bcb.lavado.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfDetmensaje;


@Repository("swfDetmensajeDao")
@Transactional
public class SwfDetmensajeDaoImpl implements SwfDetmensajeDao {
	private static final Logger log = LoggerFactory.getLogger(SwfDetmensajeDaoImpl.class);

	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;
	
	@Autowired
	@Qualifier("entityManagerFactory")	
	private EntityManagerFactory entityManagerFactory;
	
	public SwfDetmensaje findByCodigo(Integer demCodmen, Integer demNrocorr) {
		String jpql = "SELECT t FROM SwfDetmensaje t ";
		jpql = jpql.concat("WHERE t.id.demCodmen = :demCodmen ");		
		jpql = jpql.concat("and t.id.demNrocorr = :demNrocorr ");
	
		
		Query query = entityManager.createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);
		query.setParameter("demNrocorr", demNrocorr);
		
		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfDetmensaje) lista.get(0);
		}
		
		return null;		
	}
	public SwfDetmensaje findByCodigo(Integer demCodmen, String demCodmt, String demCodcampo) {
		String jpql = "SELECT t FROM SwfDetmensaje t ";
		jpql = jpql.concat("WHERE t.id.demCodmen = :demCodmen ");		
		jpql = jpql.concat("and t.demCodmt = :demCodmt ");
		jpql = jpql.concat("and t.demCodcampo = :demCodcampo ");		
		
		Query query = entityManager.createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);
		query.setParameter("demCodmt", demCodmt);
		query.setParameter("demCodcampo", demCodcampo);

		List lista = query.getResultList();
		
		log.debug("XXX: demCodmen " + demCodmen + " demCodmt " + demCodmt + " demCodcampo " + demCodcampo + " jpql " + jpql + " lista " + lista.size());		
		if (lista.size() > 0) {
			return (SwfDetmensaje) lista.get(0);
		}
		
		return null;		
	}

	public List<SwfDetmensaje> findByCodMen(Integer demCodmen) {
		String jpql = "SELECT t FROM SwfDetmensaje t WHERE t.id.demCodmen = :demCodmen ";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);
		List lista = query.getResultList();
		return lista;		
	}

	public SwfDetmensaje saveOrUpdate(SwfDetmensaje swfDetmensaje) {
		Integer codigo = getCodigo(swfDetmensaje.getId().getDemCodmen());
		swfDetmensaje.getId().setDemNrocorr(codigo);
		entityManager.merge(swfDetmensaje);
		return findByCodigo(swfDetmensaje.getId().getDemCodmen(), codigo);
	}
	
	private Integer getCodigo(Integer demCodmen) {
		Integer codigo = null;
		String jpql = "select max(m.id.demNrocorr) ";
		jpql = jpql.concat("from SwfDetmensaje m ");		
		jpql = jpql.concat("where m.id.demCodmen = :demCodmen ");
		
		Query query = entityManager.createQuery(jpql);
		query.setParameter("demCodmen", demCodmen);
		
		List result = query.getResultList();

		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.debug("Nuevo codigo Detmensaje : " + codigo);
		return codigo;
	}
}
