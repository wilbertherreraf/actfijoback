package gob.bcb.lavado.search.presearcher;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.Presearcher;
import gob.bcb.lavado.search.analysis.ShingleAnalyzer;
import gob.bcb.lavado.search.indexer.JPASearchFactoryController;
import gob.bcb.lavado.search.presearcher.HighlightsMatch.Hit;
import gob.bcb.lavado.search.queryparsers.OfacQueryBuilder;
import gob.bcb.lavado.search.queryparsers.QueryParsersBuilder;

import org.apache.lucene.queryparser.classic.QueryParser.Operator;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.Query;

public class PhrasePresearcher implements Presearcher {
	private static final Logger log = LoggerFactory.getLogger(PhrasePresearcher.class);
	private final List<OfacQuery> ofacQueryList = new ArrayList<>();
	private final JPASearchFactoryController jPASearchFactoryController;

	public PhrasePresearcher(final JPASearchFactoryController jPASearchFactoryController) {
		this.jPASearchFactoryController = jPASearchFactoryController;
	}

	@Override
	public List<OfacQuery> buildQuery(String query, List<FieldQuery> fieldQueryList) {
		if (fieldQueryList.size() == 0) {
			throw new RuntimeException("Campos consulta sin parametros");
		}

		for (FieldQuery fieldQuery : fieldQueryList) {
			buildQuery(query, fieldQuery);
		}
		return ofacQueryList;

	}

	@Override
	public List<OfacQuery> buildQuery(String query, FieldQuery fieldQuery) {
		log.debug("buildQuery Phrase " + query + " fieldQuery: " + fieldQuery.toString());
		List<OfacQuery> ofacQueryList = new ArrayList<>();
		OfacQueryBuilder ofacQueryBuilder = new OfacQueryBuilder();
		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, fieldQuery.getClazz());

		Query queryLuceneWord = queryParsersBuilder.createQuerySpanNearFuzzy(fieldQuery.getField(), query, fieldQuery.getDistanceUpTo(),
				fieldQuery.getPrefixLength(), fieldQuery.getBoost(), fieldQuery.getSlop(), fieldQuery.isInOrder(), fieldQuery.getMinWordLen(), fieldQuery.isExceptNumbers(),
				fieldQuery.getAnalyzer());

		if (queryLuceneWord == null)
			return ofacQueryList;

		Query queryLucene = null;

		if (fieldQuery.getQueryTemplate() != null && fieldQuery.getQueryTemplate().trim().length() > 0) {
			Query queryLuceneTemplate;
			try {
				queryLuceneTemplate = queryParsersBuilder.createQueryParse(fieldQuery.getField(), fieldQuery.getQueryTemplate(), Operator.AND, 0,
						fieldQuery.getAnalyzer());
				queryLucene = queryParsersBuilder.joinQueries(queryLuceneWord, BooleanClause.Occur.MUST, queryLuceneTemplate, BooleanClause.Occur.MUST);				
			} catch (Exception e) {
				throw new RuntimeException("Error en consulta "  + fieldQuery.getQueryTemplate() + " " + e.getMessage(),  e);
			}

		} else {
			queryLucene = queryLuceneWord;
		}

		OfacQuery ofacQuery = ofacQueryBuilder.createOfacQuery(query, fieldQuery, queryLucene);
		// ofacQuery.setHit(hit);
		ofacQueryList.add(ofacQuery);

		return ofacQueryList;
	}

	@Override
	public List<OfacQuery> getOfacQueryList() {
		return ofacQueryList;
	}

}
