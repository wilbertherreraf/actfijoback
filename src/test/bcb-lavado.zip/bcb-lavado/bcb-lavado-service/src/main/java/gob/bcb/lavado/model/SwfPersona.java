package gob.bcb.lavado.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;


/**
 * The persistent class for the swf_persona database table.
 * 
 */
@Entity
@Table(name="swf_persona")
public class SwfPersona implements Serializable, gob.bcb.lavado.model.DomainObject {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="per_codemp")
	private Integer perCodemp;

	@Column(name="per_nombre")
	private String perNombre;
	
	@Column(name="per_email")
	private String perEmail;

	@Column(name="per_prefunidadorgs")
	private String perPrefunidadorgs;
	
	@Column(name="per_arecod")
	private String perArecod;	
	
	@Column(name="per_idverifica")
	private String perIdverifica;
	
	@Column(name = "per_tabstatreg")
	private Integer perTabstatreg;

	@Column(name = "per_statreg")
	private Integer perStatreg;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "per_auditfho")
	private Date perAuditfho;

	@Column(name = "per_auditusr")
	private String perAuditusr;

	@Column(name = "per_auditwst")
	private String perAuditwst;
	
	
	@ManyToOne(fetch = FetchType.EAGER)
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumns({ @JoinColumn(updatable = false, insertable = false, name = "per_statreg", referencedColumnName = "des_codigo"),
			@JoinColumn(updatable = false, insertable = false, name = "per_tabstatreg", referencedColumnName = "des_codtab") })
	private GenDesctabla genDesctablaStatreg;
	
	public SwfPersona() {
	}

	public Integer getPerCodemp() {
		return this.perCodemp;
	}

	public void setPerCodemp(Integer perCodemp) {
		this.perCodemp = perCodemp;
	}

	public String getPerEmail() {
		return this.perEmail;
	}

	public void setPerEmail(String perEmail) {
		this.perEmail = perEmail;
	}

	public String getPerPrefunidadorgs() {
		return perPrefunidadorgs;
	}

	public void setPerPrefunidadorgs(String perPrefunidadorgs) {
		this.perPrefunidadorgs = perPrefunidadorgs;
	}

	public Date getPerAuditfho() {
		return perAuditfho;
	}

	public void setPerAuditfho(Date perAuditfho) {
		this.perAuditfho = perAuditfho;
	}

	public String getPerAuditusr() {
		return perAuditusr;
	}

	public void setPerAuditusr(String perAuditusr) {
		this.perAuditusr = perAuditusr;
	}

	public String getPerAuditwst() {
		return perAuditwst;
	}

	public void setPerAuditwst(String perAuditwst) {
		this.perAuditwst = perAuditwst;
	}

	public String getPerNombre() {
		return perNombre;
	}

	public void setPerNombre(String perNombre) {
		this.perNombre = perNombre;
	}

	public String getPerArecod() {
		return perArecod;
	}

	public void setPerArecod(String perArecod) {
		this.perArecod = perArecod;
	}

	@Override
	public String toString() {
		return "SwfPersona [perCodemp=" + perCodemp + ", perNombre=" + perNombre + ", perEmail=" + perEmail + ", perPrefunidadorgs=" + perPrefunidadorgs + ", perArecod="
				+ perArecod + ", perAuditfho=" + perAuditfho + ", perAuditusr=" + perAuditusr + ", perAuditwst=" + perAuditwst + "]";
	}

	public String getPerIdverifica() {
		return perIdverifica;
	}

	public void setPerIdverifica(String perIdverifica) {
		this.perIdverifica = perIdverifica;
	}

	public Integer getPerTabstatreg() {
		return perTabstatreg;
	}

	public void setPerTabstatreg(Integer perTabstatreg) {
		this.perTabstatreg = perTabstatreg;
	}

	public Integer getPerStatreg() {
		return perStatreg;
	}

	public void setPerStatreg(Integer perStatreg) {
		this.perStatreg = perStatreg;
	}

	public GenDesctabla getGenDesctablaStatreg() {
		return genDesctablaStatreg;
	}

	public void setGenDesctablaStatreg(GenDesctabla genDesctablaStatreg) {
		this.genDesctablaStatreg = genDesctablaStatreg;
	}

	
}