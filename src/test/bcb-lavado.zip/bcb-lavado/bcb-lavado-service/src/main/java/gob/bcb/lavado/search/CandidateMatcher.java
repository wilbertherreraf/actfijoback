package gob.bcb.lavado.search;

import java.io.IOException;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class CandidateMatcher<T extends QueryMatch> {
	private static final Logger log = LoggerFactory.getLogger(CandidateMatcher.class);
	private final Set<String> presearcherHits = new HashSet<>();
	protected final DocumentBatch<T> docs;
	private final List<MatchError> errors = new LinkedList<>();

	private long queryBuildTime = -1;
	private long searchTime = System.nanoTime();
	private int queriesRun = -1;
	protected final SlowLog slowlog = new SlowLog();

	protected final Map<String, MatchHolder<T>> matches = new HashMap<>();
	protected final Map<String, T> matchesResult = new HashMap<>();
	int queryCount = 0;

	private float weightSearch = 0.30f;
	private static class MatchHolder<T> {
		Map<String, T> matches = new HashMap<>();
	}

	/**
	 * Creates a new CandidateMatcher for the supplied InputDocument
	 * 
	 * @param docs
	 *            the documents to run queries against
	 */
	public CandidateMatcher(DocumentBatch docs) {
		this.docs = docs;
	}

	/**
	 * Runs the supplied query against this CandidateMatcher's InputDocument,
	 * storing any resulting match, and recording the query in the presearcher
	 * hits
	 *
	 * @param queryId
	 *            the query id
	 * @param matchQuery
	 *            the query to run
	 * @param metadata
	 *            the query metadata
	 * @throws IOException
	 *             on IO errors
	 */
	public final void matchQuery(String queryId, T matchQuery, Map<String, String> metadata) throws IOException {
		presearcherHits.add(queryId);
		doMatchQuery(queryId, matchQuery, metadata);
	}

	/**
	 * Override this method to actually run the query
	 *
	 * @param queryId
	 *            the query id
	 * @param matchQuery
	 *            the query to run
	 * @param metadata
	 *            the query metadata
	 * @throws IOException
	 *             on error
	 */
	protected abstract void doMatchQuery(String queryId, T matchQuery, Map<String, String> metadata) throws IOException;

	protected abstract T doMatch(T match) throws IOException;

	public void addMatch(String queryId, String docId, T match) {
		MatchHolder<T> docMatches = matches.get(docId);

		if (docMatches == null) {
			docMatches = new MatchHolder<>();
			matches.put(docId, docMatches);
		}

		if (docMatches.matches.containsKey(queryId)) {
			T matchNew = resolve(match, docMatches.matches.get(queryId));
			docMatches.matches.put(queryId, matchNew);
			matchesResult.put(docId, matchNew);
		} else {
			docMatches.matches.put(queryId, match);
			matchesResult.put(docId, match);
		}

	}

	/**
	 * Record a match
	 * 
	 * @param match
	 *            a QueryMatch object
	 */
	public void addMatch(T match) {
		addMatch(match.getQueryId(), match.getDocId(), match);
	}

	/**
	 * If two matches from the same query are found (for example, two branches
	 * of a disjunction), combine them.
	 * 
	 * @param match1
	 *            the first match found
	 * @param match2
	 *            the second match found
	 * @return a Match object that combines the two
	 */
	public abstract T resolve(T match1, T match2);

	/**
	 * Adjust component,
	 * 
	 * @param match
	 * @return
	 * @throws IOException 
	 */
	public abstract List<T> adjustComponent(T match) throws IOException;

	/**
	 * Called by the Monitor if running a query throws an Exception
	 * 
	 * @param e
	 *            the MatchError detailing the problem
	 */
	public void reportError(MatchError e) {
		this.errors.add(e);
	}

	/**
	 * Called when matching has finished
	 * 
	 * @param buildTime
	 *            the time taken to construct the document disjunction
	 * @param queryCount
	 *            the number of queries run
	 */
	public void finish(long buildTime, int queryCount) {
		this.queryBuildTime = buildTime;
		this.queriesRun = queryCount;
		this.searchTime = TimeUnit.MILLISECONDS.convert(System.nanoTime() - searchTime, TimeUnit.NANOSECONDS);
	}

	/*
	 * Called by the Monitor to set the {@link SlowLog} limit
	 */
	public void setSlowLogLimit(long t) {
		this.slowlog.setLimit(t);
	}

	/**
	 * Returns the QueryMatch for the given document and query, or null if it
	 * did not match
	 * 
	 * @param docId
	 *            the document id
	 * @param queryId
	 *            the query id
	 * @return the QueryMatch for the given document and query, or null if it
	 *         did not match
	 */
	public T matches(String docId, String queryId) {
		MatchHolder<T> docMatches = matches.get(docId);
		if (docMatches == null)
			return null;
		return docMatches.matches.get(queryId);
	}

	public Map<String, T> matches(String docId) {
		MatchHolder<T> docMatches = matches.get(docId);
		if (docMatches == null)
			return null;
		return docMatches.matches;
	}

	/**
	 * @return the matches from this matcher
	 */
	public Matches<T> getMatches() {
		Map<String, DocumentMatches<T>> results = new HashMap<>();
		for (T searchResultOfac : docs) {
			String id = searchResultOfac.getDocId();
			if (matches.containsKey(id)) {
				results.put(id, new DocumentMatches<>(id, matches.get(id).matches.values()));
			} else {
				results.put(id, DocumentMatches.<T> noMatches(id));
			}
		}
		// log.info("matches.matches. " + matches.size() + " " + results.size()
		// + " " + results.values().size());
		return new Matches<>(results, presearcherHits, errors, queryBuildTime, searchTime, queriesRun, docs.getBatchSize(), slowlog);
	}

	public Matches<T> getMatchesResult() {
		Map<String, DocumentMatches<T>> results = new HashMap<>();
		for (Entry<String, MatchHolder<T>> match : matches.entrySet()) {
			MatchHolder<T> value = match.getValue();
			String id = match.getKey();
			if (matches.containsKey(id)) {
				results.put(id, new DocumentMatches<>(id, matches.get(id).matches.values()));
			} else {
				results.put(id, DocumentMatches.<T> noMatches(id));
			}
		}
		// log.info("matches.matches. " + matches.size() + " " + results.size()
		// + " " + results.values().size());
		return new Matches<>(results, presearcherHits, errors, queryBuildTime, searchTime, queriesRun, docs.getBatchSize(), slowlog);
	}

	public Matches<T> getMatchesUnique() {
		Map<String, DocumentMatches<T>> results = new HashMap<>();
		for (T searchResultOfac : docs) {
			String id = searchResultOfac.getDocId();
			if (matchesResult.containsKey(id)) {
				results.put(id, new DocumentMatches<>(id, Arrays.asList(matchesResult.get(id))));
			} else {
				results.put(id, DocumentMatches.<T> noMatches(id));
			}
		}
		// log.info("matches.matches. " + matches.size() + " " + results.size()
		// + " " + results.values().size());
		return new Matches<>(results, presearcherHits, errors, queryBuildTime, searchTime, queriesRun, docs.getBatchSize(), slowlog);
	}

	public void clearMatches() {
		matches.clear();
	}

	public float getWeightSearch() {
		return weightSearch;
	}

	public void setWeightSearch(float weightSearch) {
		this.weightSearch = weightSearch;
	}
}
