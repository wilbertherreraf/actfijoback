package gob.bcb.lavado.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaPlaceofbirth;

@Repository
public interface OfaPlaceofbirthRepository extends JpaRepository<OfaPlaceofbirth, Integer> {

}
