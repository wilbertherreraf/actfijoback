//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.05.17 a las 11:37:50 AM BOT 
//


package gob.bcb.lavado.ofac.ue.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://eu.europa.ec/fpi/fsd/export}regulationSummary"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="middleName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="lastName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="wholeName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="function" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="title" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="nameLanguage" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="strong" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="regulationLanguage" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="logicalId" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="gender" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "regulationSummary"
})
@XmlRootElement(name = "nameAlias")
public class NameAlias {

    @XmlElement(required = true)
    protected RegulationSummary regulationSummary;
    @XmlAttribute(name = "firstName")
    protected String firstName;
    @XmlAttribute(name = "middleName")
    protected String middleName;
    @XmlAttribute(name = "lastName")
    protected String lastName;
    @XmlAttribute(name = "wholeName")
    protected String wholeName;
    @XmlAttribute(name = "function")
    protected String function;
    @XmlAttribute(name = "title")
    protected String title;
    @XmlAttribute(name = "nameLanguage")
    protected String nameLanguage;
    @XmlAttribute(name = "strong")
    protected String strong;
    @XmlAttribute(name = "regulationLanguage")
    protected String regulationLanguage;
    @XmlAttribute(name = "logicalId")
    protected Integer logicalId;
    @XmlAttribute(name = "gender")
    protected String gender;

    /**
     * Obtiene el valor de la propiedad regulationSummary.
     * 
     * @return
     *     possible object is
     *     {@link RegulationSummary }
     *     
     */
    public RegulationSummary getRegulationSummary() {
        return regulationSummary;
    }

    /**
     * Define el valor de la propiedad regulationSummary.
     * 
     * @param value
     *     allowed object is
     *     {@link RegulationSummary }
     *     
     */
    public void setRegulationSummary(RegulationSummary value) {
        this.regulationSummary = value;
    }

    /**
     * Obtiene el valor de la propiedad firstName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Define el valor de la propiedad firstName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Obtiene el valor de la propiedad middleName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Define el valor de la propiedad middleName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMiddleName(String value) {
        this.middleName = value;
    }

    /**
     * Obtiene el valor de la propiedad lastName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Define el valor de la propiedad lastName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Obtiene el valor de la propiedad wholeName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWholeName() {
        return wholeName;
    }

    /**
     * Define el valor de la propiedad wholeName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWholeName(String value) {
        this.wholeName = value;
    }

    /**
     * Obtiene el valor de la propiedad function.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFunction() {
        return function;
    }

    /**
     * Define el valor de la propiedad function.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFunction(String value) {
        this.function = value;
    }

    /**
     * Obtiene el valor de la propiedad title.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Define el valor de la propiedad title.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Obtiene el valor de la propiedad nameLanguage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameLanguage() {
        return nameLanguage;
    }

    /**
     * Define el valor de la propiedad nameLanguage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameLanguage(String value) {
        this.nameLanguage = value;
    }

    /**
     * Obtiene el valor de la propiedad strong.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrong() {
        return strong;
    }

    /**
     * Define el valor de la propiedad strong.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrong(String value) {
        this.strong = value;
    }

    /**
     * Obtiene el valor de la propiedad regulationLanguage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegulationLanguage() {
        return regulationLanguage;
    }

    /**
     * Define el valor de la propiedad regulationLanguage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegulationLanguage(String value) {
        this.regulationLanguage = value;
    }

    /**
     * Obtiene el valor de la propiedad logicalId.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLogicalId() {
        return logicalId;
    }

    /**
     * Define el valor de la propiedad logicalId.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLogicalId(Integer value) {
        this.logicalId = value;
    }

    /**
     * Obtiene el valor de la propiedad gender.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGender() {
        return gender;
    }

    /**
     * Define el valor de la propiedad gender.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGender(String value) {
        this.gender = value;
    }

}
