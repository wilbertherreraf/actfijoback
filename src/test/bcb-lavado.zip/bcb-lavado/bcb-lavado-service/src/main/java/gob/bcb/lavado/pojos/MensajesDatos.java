package gob.bcb.lavado.pojos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfDetmensaje;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.swift.pojos.Block4;

public class MensajesDatos implements Serializable {
	private Integer menCodmen;
	private String menCodmt;
	private String menCodmtdescrip;
	private String menNroswift;
	private String menCodswift;
	private String menEmisor;
	private Date menFecreg;
	private String menCodmon;
	private String menRefer;
	private Integer menNrolote;
	private String menOrigen;
	private String menCampo20;
	private String menCampoaux1;
	private String menCampoaux1descrip;
	private String menCampoaux2;
	private String menCampoaux2descrip;

	private SwfMensaje swfMensaje;
	private SwfBics swfBics;
	private List<SwfDetmensaje> swfDetmensajeLista;
	private List<Block4> block4List = new ArrayList<>();
	private List<SwfAsignamensaje> swfAsignamensajeLista;
	private List<SwfAsignamensaje> swfAsignamensajeDeATerceros;
	private List<Empleado> empleadoLista;
	private List<Asignacion> asignacionLista;
	private Asignacion asignacion;
	private String receiverDesc;

	private boolean seleccionado;
	private Integer secuencia = 0;

	public Integer getMenCodmen() {
		return menCodmen;
	}

	public void setMenCodmen(Integer menCodmen) {
		this.menCodmen = menCodmen;
	}

	public String getMenCodmt() {
		return menCodmt;
	}

	public void setMenCodmt(String menCodmt) {
		this.menCodmt = menCodmt;
	}

	public String getMenNroswift() {
		return menNroswift;
	}

	public void setMenNroswift(String menNroswift) {
		this.menNroswift = menNroswift;
	}

	public String getMenCodswift() {
		return menCodswift;
	}

	public void setMenCodswift(String menCodswift) {
		this.menCodswift = menCodswift;
	}

	public Integer getMenNrolote() {
		return menNrolote;
	}

	public void setMenNrolote(Integer menNrolote) {
		this.menNrolote = menNrolote;
	}

	public String getMenOrigen() {
		return menOrigen;
	}

	public void setMenOrigen(String menOrigen) {
		this.menOrigen = menOrigen;
	}

	public String getMenCampo20() {
		return menCampo20;
	}

	public void setMenCampo20(String menCampo20) {
		this.menCampo20 = menCampo20;
	}

	public String getMenCampoaux1() {
		return menCampoaux1;
	}

	public String getCampobloque4(String campo) {
		if (campo != null && !campo.trim().isEmpty() && swfMensaje != null) {
			if (swfMensaje.getBlock4List() != null && swfMensaje.getBlock4List().size() > 0) {
				Optional<Block4> fieldSwf = swfMensaje.getBlock4List().stream().filter(s -> (campo.trim().equals(s.getName().trim()))).findFirst();
				if (fieldSwf.isPresent())
					return fieldSwf.get().getValue();
			}
		}
		return "";
	}

	public void setMenCampoaux1(String menCampoaux1) {
		this.menCampoaux1 = menCampoaux1;
	}

	public String getMenCampoaux2() {
		return menCampoaux2;
	}

	public void setMenCampoaux2(String menCampoaux2) {
		this.menCampoaux2 = menCampoaux2;
	}

	public String getMenCampoaux1descrip() {
		return menCampoaux1descrip;
	}

	public void setMenCampoaux1descrip(String menCampoaux1descrip) {
		this.menCampoaux1descrip = menCampoaux1descrip;
	}

	public String getMenCampoaux2descrip() {
		return menCampoaux2descrip;
	}

	public void setMenCampoaux2descrip(String menCampoaux2descrip) {
		this.menCampoaux2descrip = menCampoaux2descrip;
	}

	public String getMenCodmon() {
		return menCodmon;
	}

	public void setMenCodmon(String menCodmon) {
		this.menCodmon = menCodmon;
	}

	public String getMenRefer() {
		return menRefer;
	}

	public void setMenRefer(String menRefer) {
		this.menRefer = menRefer;
	}

	public String getMenEmisor() {
		return menEmisor;
	}

	public void setMenEmisor(String menEmisor) {
		this.menEmisor = menEmisor;
	}

	public Date getMenFecreg() {
		return menFecreg;
	}

	public void setMenFecreg(Date menFecreg) {
		this.menFecreg = menFecreg;
	}

	public SwfMensaje getSwfMensaje() {
		return swfMensaje;
	}

	public void setSwfMensaje(SwfMensaje swfMensaje) {
		this.swfMensaje = swfMensaje;
	}

	public List<SwfDetmensaje> getSwfDetmensajeLista() {
		return swfDetmensajeLista;
	}

	public void setSwfDetmensajeLista(List<SwfDetmensaje> swfDetmensajeLista) {
		this.swfDetmensajeLista = swfDetmensajeLista;
	}

	public String getMenCodmtdescrip() {
		return menCodmtdescrip;
	}

	public void setMenCodmtdescrip(String menCodmtdescrip) {
		this.menCodmtdescrip = menCodmtdescrip;
	}

	public List<SwfAsignamensaje> getSwfAsignamensajeLista() {
		return swfAsignamensajeLista;
	}

	public void setSwfAsignamensajeLista(List<SwfAsignamensaje> swfAsignamensajeLista) {
		this.swfAsignamensajeLista = swfAsignamensajeLista;
	}

	public List<Empleado> getEmpleadoLista() {
		return empleadoLista;
	}

	public void setEmpleadoLista(List<Empleado> empleadoLista) {
		this.empleadoLista = empleadoLista;
	}

	public boolean isSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public List<Asignacion> getAsignacionLista() {
		return asignacionLista;
	}

	public void setAsignacionLista(List<Asignacion> asignacionLista) {
		this.asignacionLista = asignacionLista;
	}

	public SwfBics getSwfBics() {
		return swfBics;
	}

	public void setSwfBics(SwfBics swfBics) {
		this.swfBics = swfBics;
	}

	public String getReceiverDesc() {
		return receiverDesc;
	}

	public void setReceiverDesc(String receiverDesc) {
		this.receiverDesc = receiverDesc;
	}

	public Integer getSecuencia() {
		return secuencia;
	}

	public void setSecuencia(Integer secuencia) {
		this.secuencia = secuencia;
	}

	public Asignacion getAsignacion() {
		return asignacion;
	}

	public void setAsignacion(Asignacion asignacion) {
		this.asignacion = asignacion;
	}

	public List<Block4> getBlock4List() {
		return block4List;
	}

	public void setBlock4List(List<Block4> block4List) {
		this.block4List = block4List;
	}

	public List<SwfAsignamensaje> getSwfAsignamensajeDeATerceros() {
		return swfAsignamensajeDeATerceros;
	}

	public void setSwfAsignamensajeDeATerceros(List<SwfAsignamensaje> swfAsignamensajeDeATerceros) {
		this.swfAsignamensajeDeATerceros = swfAsignamensajeDeATerceros;
	}

}
