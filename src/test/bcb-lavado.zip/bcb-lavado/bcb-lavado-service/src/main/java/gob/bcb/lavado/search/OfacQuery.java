package gob.bcb.lavado.search;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.InputStreamDataInput;
import org.apache.lucene.store.OutputStreamDataOutput;
import org.apache.lucene.util.BytesRef;

import gob.bcb.lavado.search.presearcher.HighlightsMatch.Hit;

/**
 * Defines a query to be stored
 */
public class OfacQuery extends QueryMatch {
	private final String query;
	private String field;
	/** The term type */
	private Type type;
	//private float weightTerm = 0;	
	private float score;
	private final Query luceneQuery;
	private FieldQuery fieldQuery;
	private Hit hit;
	private String term;
	private String termHigh;	
	private Integer pageSize;
	private Integer page;
	private Integer maxResults;
	
	/**
	 * Creates a new OfacQuery
	 * 
	 * @param id
	 *            the ID
	 * @param query
	 *            the query to store
	 */
	public OfacQuery(String id, String docId, String query, Query luceneQuery) {
		super(id, docId);
		this.query = query;
		this.luceneQuery = luceneQuery;
		this.type = Type.CUSTOM;
	}

	/**
	 * Deserialize a OfacQuery from a stream of bytes
	 * 
	 * @param bytes
	 *            a BytesRef pointing to the serialized query
	 * @return the deserialized OfacQuery
	 */
	public static OfacQuery deserialize(BytesRef bytes) {

		ByteArrayInputStream is = new ByteArrayInputStream(bytes.bytes);
		try (InputStreamDataInput data = new InputStreamDataInput(is)) {

			String id = data.readString();
			String query = data.readString();
			return new OfacQuery(id, "", query, null);

		} catch (IOException e) {
			throw new RuntimeException(e); // shouldn't happen, we're reading
											// from a bytearray!
		}

	}

	/**
	 * Serialize a OfacQuery into a BytesRef
	 * 
	 * @param mq
	 *            the OfacQuery
	 * @return the serialized bytes
	 */
	public static BytesRef serialize(OfacQuery mq) {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try (OutputStreamDataOutput data = new OutputStreamDataOutput(os)) {
			data.writeString(mq.getQueryId());
			data.writeString(mq.getQuery());
			return new BytesRef(os.toByteArray());

		} catch (IOException e) {
			throw new RuntimeException(e); // shouldn't happen, we're writing to
											// a bytearray!
		}
	}

	/**
	 * @return this OfacQuery's query
	 */
	public String getQuery() {
		return query;
	}

	public BytesRef hash() {
		try {
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			md5.update(query.getBytes(StandardCharsets.UTF_8));
			return new BytesRef(md5.digest());
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("Can't use MD5 hash on this system", e);
		}
	}

	public Query getLuceneQuery() {
		return luceneQuery;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public void addHit(String field, int startPos, int endPos, int startOffset, int endOffset) {
		hit = new Hit(startPos, startOffset, endPos, endOffset);
		hit.setText(getQueryId());
	}

	public boolean isValidTerms(int actualTerms) {
		int expectedTerms = 0;
		if (fieldQuery.getValidatorStrategy().isValidateTerms()) {
			try {
				QueryTermFilter queryTermFilter = new QueryTermFilter(field, term, fieldQuery.getMinWordLen(), fieldQuery.isExceptNumbers(), fieldQuery.getAnalyzer());
				expectedTerms = queryTermFilter.getTerms(field).size();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		return expectedTerms <= actualTerms;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		OfacQuery that = (OfacQuery) o;

		if (getQueryId() != null ? !getQueryId().equals(that.getQueryId()) : that.getQueryId() != null)
			return false;
		if (query != null ? !query.equals(that.query) : that.query != null)
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result = getQueryId() != null ? getQueryId().hashCode() : 0;
		result = 31 * result + (query != null ? query.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return "OfacQuery [" + super.toString() + " query=" + query + ", field=" + field + ", type=" + type + ", score=" + score + ", luceneQuery="
				+ luceneQuery + ", fieldQuery=" + fieldQuery + ", term=" + term + "]";
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public FieldQuery getFieldQuery() {
		return fieldQuery;
	}

	public void setFieldQuery(FieldQuery fieldQuery) {
		this.fieldQuery = fieldQuery;
	}

	public Hit getHit() {
		return hit;
	}

	public void setHit(Hit hit) {
		this.hit = hit;
	}

	public enum Type {
		EXACT, ANY, CUSTOM
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getMaxResults() {
		return maxResults;
	}

	public void setMaxResults(Integer maxResults) {
		this.maxResults = maxResults;
	}

	public String getTermHigh() {
		return termHigh;
	}

	public void setTermHigh(String termHigh) {
		this.termHigh = termHigh;
	}

}
