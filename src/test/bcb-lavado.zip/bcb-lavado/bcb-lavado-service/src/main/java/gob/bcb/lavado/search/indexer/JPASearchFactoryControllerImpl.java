package gob.bcb.lavado.search.indexer;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.hibernate.search.SearchFactory;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.impl.ImplementationFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * Componente que mantiene los objetos de busqueda y administrador de entidades
 * 
 * @author wherrera
 *
 */

//@Component("jPASearchFactoryController")
public class JPASearchFactoryControllerImpl implements JPASearchFactoryController{
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	private final EntityManagerFactory entityManagerFactory;
	
	private EntityManager entityManager;
	private SearchFactory searchFactory;
	private FullTextEntityManager fullTextEntityManager;
	
	public JPASearchFactoryControllerImpl(EntityManagerFactory entityManagerFactory) {
//		log.info("Creando JPASearchFactoryControllerImpl..." + (entityManagerFactory == null));
		if (entityManagerFactory == null)
			throw new RuntimeException("Objeto entityManagerFactory nulo");
		this.entityManagerFactory = entityManagerFactory;
	}

	public FullTextEntityManager getFullTextEntityManager(EntityManager em) {
		// em may be null for when we don't need an EntityManager
		if (em != null && em instanceof FullTextEntityManager) {
			return (FullTextEntityManager) em;
		} else {
			//log.info("creando FullTextEntityManager");
			return ImplementationFactory.createFullTextEntityManager(em);
		}
	}

	public EntityManager createEntityManager() {
		if (entityManagerFactory == null){
			throw new RuntimeException("Objeto entityManagerFactory nulo");
		}
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//log.info("OOOOO Nuevo entityManager creado " + entityManager.toString());
		return entityManager;
	}
	
	public void init(){
		entityManager = createEntityManager();
		fullTextEntityManager = getFullTextEntityManager(entityManager);
		searchFactory = fullTextEntityManager.getSearchFactory();		
	
	}
	
	public void close() {
		try {
			//log.info("close() entityManager called. null ? " + (entityManager == null));
			if (entityManager != null && entityManager.isOpen()){
				//log.info("close() entityManager called.");				
				entityManager.close();
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	public EntityManagerFactory getEntityManagerFactory() {
		return entityManagerFactory;
	}

	public SearchFactory getSearchFactory() {
		if (searchFactory == null){
			entityManager = createEntityManager();
			if (fullTextEntityManager == null)
				fullTextEntityManager = getFullTextEntityManager(entityManager);
			searchFactory = fullTextEntityManager.getSearchFactory();
		}
		return searchFactory;
	}

	public FullTextEntityManager getFullTextEntityManager() {
		if (fullTextEntityManager == null){
			fullTextEntityManager = getFullTextEntityManager(createEntityManager());
		}
		return fullTextEntityManager;
	}
}
