package gob.bcb.lavado.repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.OfaIdlist;

@Repository("ofaIdlistDao")
@Transactional
public class OfaIdlistDaoImpl implements OfaIdlistDao {
	private final Logger log = LoggerFactory.getLogger(OfaIdlistDaoImpl.class);
	@Autowired
	private OfaIdlistRepository ofaIdlistRepository;
	
	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;

	@Autowired
	@Qualifier("entityManagerFactory")
	private EntityManagerFactory entityManagerFactory;

    //@Override
    /* (non-Javadoc)
	 * @see gob.bcb.lavado.repository.OfaIdlistDao#loadOfaIdlists(java.lang.Integer)
	 */
    @Override
	public Collection<OfaIdlist> loadOfaIdlists(Integer userId) {
        List<OfaIdlist> customersList = ofaIdlistRepository.findByIdlEntryuid(userId);
        ArrayList<OfaIdlist> customers = new ArrayList<OfaIdlist>();
        for (OfaIdlist c : customersList) {
            customers.add(c);
        }
        log.info("OfaIdlist " + customers.size());
        return Collections.unmodifiableList(customers);
    }
	
}
