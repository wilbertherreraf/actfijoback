package gob.bcb.lavado.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import gob.bcb.lavado.model.OfaBlanklist;

@Repository
public interface OfaBlanklistRepository  extends JpaRepository<OfaBlanklist, Integer> {
	@Query("select t from OfaBlanklist t where t.blcId = (select max(m.blcId) from OfaBlanklist m) ")
	Optional<OfaBlanklist> findOneMaximo();
	//@Query("select t from OfaBlacklist t where t.blkId = (select max(m.blkId) from OfaBlacklist m) ")	
	List<OfaBlanklist> findByBlcStatusauto(Integer blcStatusauto);
}
