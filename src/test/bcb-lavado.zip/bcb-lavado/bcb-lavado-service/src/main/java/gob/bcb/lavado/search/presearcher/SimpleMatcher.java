package gob.bcb.lavado.search.presearcher;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.CandidateMatcher;
import gob.bcb.lavado.search.DocumentBatch;
import gob.bcb.lavado.search.DocumentMatches;
import gob.bcb.lavado.search.MatcherFactory;
import gob.bcb.lavado.search.Matches;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.facet.FacetQueryOfac;

public class SimpleMatcher extends CandidateMatcher<SearchResultOfac> {
	private final Logger log = LoggerFactory.getLogger(SimpleMatcher.class);	
	
	public SimpleMatcher(DocumentBatch<?> batch, FacetQueryOfac facetQueryOfac) {
		super(batch);
	}

	@Override
	protected void doMatchQuery(String queryId, SearchResultOfac matchQuery, Map<String, String> metadata) throws IOException {
		if (matchQuery == null)
			return;
		SearchResultOfac searchResultOfac = doMatch(matchQuery);		
		this.addMatch(searchResultOfac);
		//this.addMatch(matchQuery);
	}

	@Override
	protected SearchResultOfac doMatch(SearchResultOfac match) {
		match.addMatch(match.getOfacQuery().getQueryId(), match.getOfacQuery().getField(), match.getOfacQuery());
		return match;		
		//return match;
	}

	@Override
	public SearchResultOfac resolve(SearchResultOfac match1, SearchResultOfac match2) {
        return match1.getScore() < match2.getScore() ? match2 : match1;
	}

	@Override
	public List<SearchResultOfac> adjustComponent(SearchResultOfac match) {
		return null;
	}
	
	@Override
	public Matches<SearchResultOfac> getMatches() {
		return this.getMatchesUnique();
	}

	@Override
	public void addMatch(SearchResultOfac match) {
		Map<String, SearchResultOfac> matches = this.matches(match.getDocId());
		if (matches != null) {
			for (SearchResultOfac searchResultOfac : matches.values()) {
				searchResultOfac.addMatch(match.getOfacQuery().getQueryId(), match.getOfacQuery().getField(), match.getOfacQuery());
				for (OfacQuery ofacQueryPrv : searchResultOfac.getMatches()) {
					match.addMatch(ofacQueryPrv.getQueryId(), ofacQueryPrv.getField(), ofacQueryPrv);
				}
			}
		}
		
		for (SearchResultOfac searchResultOfac : matchesResult.values()) {
			String id = searchResultOfac.getDocId();
			if (match.getDocId().equals(id)) {
				// existe en docs 
				for (OfacQuery ofacQueryPrv : searchResultOfac.getMatches()) {
					match.addMatch(ofacQueryPrv.getQueryId(), ofacQueryPrv.getField(), ofacQueryPrv);					
				}
			} 
		}
		match.setScore(0);
		// actualizamos el score
		for (OfacQuery ofacQueryPrv : match.getMatches()) {
			match.setScore(match.getScore() + ofacQueryPrv.getScore());					
		}		
		super.addMatch(match);
	}	
	/**
	 * Sobreescribe el metodo y retorna todos los resultados
	 */
	@Override
	public Matches<SearchResultOfac> getMatchesUnique() {
		Map<String, DocumentMatches<SearchResultOfac>> results = new HashMap<>();
		for (SearchResultOfac searchResultOfac : matchesResult.values()) {
			String id = searchResultOfac.getDocId();
			DocumentMatches docMatches = new DocumentMatches<>(id, matches(id).values().stream().collect(Collectors.toList()));
			results.put(id, docMatches);
		}
		log.debug("BatchSize: " + docs.getBatchSize());
		Matches<SearchResultOfac> matchesResult = new Matches<SearchResultOfac>(results, new HashSet<>(), new LinkedList<>(), 1, 1, 1, results.size(), slowlog);
		
		return matchesResult;
	}
	
	public static final MatcherFactory<SearchResultOfac> FACTORY = new MatcherFactory<SearchResultOfac>() {
        @Override
        public SimpleMatcher createMatcher(DocumentBatch docs, FacetQueryOfac facetQueryOfac) {
            return new SimpleMatcher(docs, facetQueryOfac);
        }
    };
	
}
