package gob.bcb.lavado.services;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.client.pojos.SearchResponse.ItemsInfo;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.repository.SwfMensajeDaoImpl;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.lavado.search.DocumentBatch;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.indexer.JPASearchFactoryControllerImpl;
import gob.bcb.lavado.search.indexer.JPASearchFactoryHolder;
import gob.bcb.lavado.search.queryparsers.QueryParsersBuilder;
import gob.bcb.lavado.strategy.StrategyBase;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

@Service(value = "swiftBcbSearcherService")
public class SwiftBcbSearcherServiceImpl<T> implements SwiftBcbSearcherService {
	private static final Logger log = LoggerFactory.getLogger(SwiftBcbSearcherServiceImpl.class);
	public static final int MAX_CHARS_LOG = 88;
	@Autowired
	private SwiftBcbParserService swiftBcbParserService;
	@Autowired
	private JPASearchFactoryHolder jPASearchFactoryHolder;
	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private AppProperties appProperties;
	@Autowired
	private MailService mailService;
//	@Autowired
//	private SessionsSearcherService sessionsSearcherService;

	private String pathDirectoryQueries;

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.lavado.services.SwiftBcbSearcherService#verificarMensajePlano
	 * (java.lang.String)
	 */
	@PostConstruct
	public void init() {
		pathDirectoryQueries = new File(appProperties.getLavado().getAppdir(), Constants.DIR_QUERIES).getAbsolutePath();
	}

	public SearchResponse solicitarCorrelativo(String codapp, String codoperacion, String coduser, String idsession, String estacion) {
		log.info("Solicitar correlativo codapp {} codoperacion {} user {} idsession {}", codapp, codoperacion, coduser, idsession);

		try {
			SwfMensaje swfMensaje = swfMensajeDao.solicitarCorrelativo(codapp, coduser, codoperacion, estacion, idsession);
			SearchResponse searchResponse = createResponse(Constants.COD_RESP_EXITO, 0, String.valueOf(swfMensaje.getMenCodmen()),
					swfMensaje.getMenNrocorr());
			searchResponse.setDescripResp("Operacion realizada exitosamente idMensaje: {" + searchResponse.getCodoperacion() + "} correlativo generado {"
					+ swfMensaje.getMenNrocorr() + "}");

			log.info("Respuesta: " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());
			return searchResponse;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		}
	}

	public SearchResponse scanMensajePlanoConCorrSolicitado(String menPlano, String codapp, Integer menCodmen, Integer nroCorrelativo, String codoperacion,
			String coduser, String estacion, String idsession, String codelau) {
		log.info(
				"scanMensajePlanoConCorrSolicitado codapp {}, menCodmen {}, nroCorrelativo {}, codoperacion {}, coduser {}, estacion {}, idsession {} codelau {}",
				codapp, menCodmen, nroCorrelativo, codoperacion, coduser, estacion, idsession, codelau);
		JPASearchFactoryControllerImpl jPASearchFactoryController = null;
		try {
			SwiftDatos swiftDatos = swfMensajeDao.actualizarConPlano(menPlano, codapp, menCodmen, nroCorrelativo, codoperacion, coduser, estacion, idsession,
					codelau);

			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
			jPASearchFactoryController.init();
			
			OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);
			SearchResponse searchResponse = verificarSalienteAndSendMail(swiftDatos, ofacScanServiceImpl);
			searchResponse.setMenPlano(swiftDatos.getSwfMensaje().getMenPlano());
			
			log.info("Respuesta post Scan: " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());
			return searchResponse;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error("Error: " + e.getMessage(), e);
			return getSearchResultFromException(e);
		} finally {
			if (jPASearchFactoryController != null)
				jPASearchFactoryController.close();
		}
	}
	
	//@Transactional()
	public SearchResponse preAutorizaSwift(Integer codlvd, String codapp, String coduser, String codoperacion, String idSession, String menPlano,
			String estacion, String codelau) {
		
		log.info("=======preAutorizaSwift========== codapp {}, menCodmen {}, codoperacion {}, coduser {}, estacion {}, idsession {} codelau {}", codapp,
				codlvd, codoperacion, coduser, estacion, idSession, codelau);
		try {
			SwiftDatos swiftDatos = swfMensajeDao.preAutorizaSwift(codlvd, codapp, coduser, codoperacion, idSession, menPlano,	estacion, codelau);

			SearchResponse searchResponse = createResponse(Constants.COD_RESP_EXITO, 0, String.valueOf(swiftDatos.getSwfMensaje().getMenCodmen()),
					swiftDatos.getSwfMensaje().getMenNrocorr());
			searchResponse.setDescripResp("Operacion realizada exitosamente " + swiftDatos.getSwfMensaje().getMenCodmen());
			searchResponse.setMenPlano(swiftDatos.getSwfMensaje().getMenPlano());
			
			log.info("Respuesta: " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());
			return searchResponse;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		}
	}

	public SearchResponse endSession(String codapp, String idsession, String coduser, String estacion) {
		log.info("FIN SESSION codapp {} idsession {} coduser {} estacion {}", codapp, idsession, coduser, estacion);
		try {
			Integer nroRecs = swfMensajeDao.cerrarTransaccion(idsession);

			SearchResponse searchResponse = createResponse(Constants.COD_RESP_EXITO, nroRecs, idsession, null);
			searchResponse.setDescripResp("Operacion realizada exitosamente con registros actualizados: " + nroRecs);

			log.info("Respuesta: " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());
			return searchResponse;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		}
	}

	private SearchResponse verificarSalienteAndSendMail(SwiftDatos swiftDatos, OfacScanServiceImpl ofacScanServiceImpl) throws Exception {
		boolean exitOnFirstFound = true;
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		SearchResponse searchResponse = new SearchResponse();

		// verificamos si el mensaje esta en verificacion (pendiente) o fue
		// marcado como positivo(bloqueado)
		if ((swfMensaje.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0)) {
			// se scanea
			
			List<Block4> block4List = SwiftDatos.block4ToBlock4Ldv(swiftDatos.getSwiftMessageAbs().createBlock4().getBlock4());

			DocumentBatch<SearchResultOfac> documentBatchResult = searchForSwfMensaje(block4List, ofacScanServiceImpl, exitOnFirstFound);
			searchResponse = fromSearchResultOfacDTO(documentBatchResult, false, ofacScanServiceImpl);
		} else if ((swfMensaje.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0)
				|| (swfMensaje.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO) == 0)) {
			log.info("Mensaje {} REGISTRADO ANTERIORMENTE con est. {}", swfMensaje.getMenCodmen(), swfMensaje.getMenEstverifica());
			searchResponse.setCountRegs(0);
		} else {
			log.info("Mensaje " + swfMensaje.getMenCodmen() + " REGISTRADO ANTERIORMENTE con estado " + swfMensaje.getMenEstverifica());
			searchResponse.setCountRegs(1);
		}

		SwfMensajeDaoImpl.actEstadoVerificaPostScan(swfMensaje, searchResponse.getCountRegs());

		SwfMensaje swfMensajeNew = swfMensajeDao.updateRegSinEnc(swfMensaje);
		searchResponse.setCodoperacion(String.valueOf(swfMensajeNew.getMenCodmen()));
		searchResponse.setNrocorr(swfMensajeNew.getMenNrocorr());
		searchResponse.setCodResplau(swfMensajeNew.getMenHash());
		
		accionPostScan(swfMensajeNew, searchResponse);
		swiftDatos.setSwfMensaje(swfMensajeNew);
		sendMail(swfMensajeNew);
		log.info("~~~~~~~~~~~~~~End verified Message plain ~~~~~~~~~~~~~~[" + searchResponse.getCountRegs() + "]");
		return searchResponse;
	}

	@Async
	public void scanLoteAsync(Integer menNrolote) {
		log.info("@@@@@@@@@@@@@@ Inicio scan async[lote: " + menNrolote + "]... @@@@@@@@@@@@@@@@");
		JPASearchFactoryControllerImpl jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);
		List<SwfMensaje> mensajesDatosLista = swfMensajeDao.findByNroLote(menNrolote);
		for (SwfMensaje swfMensaje : mensajesDatosLista) {
			if (swfMensaje.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) != 0)
				continue;

			/* #### SCANEO #### */
			verificarEntranteAndSendMail(swfMensaje, ofacScanServiceImpl);
		}

		jPASearchFactoryController.close();
		log.info("Scan async lote {} con regs {} ... hecho ", menNrolote, mensajesDatosLista.size());
	}

	private void verificarEntranteAndSendMail(SwfMensaje swfMensaje, OfacScanServiceImpl ofacScanServiceImpl) {
		log.info("=======verificarEntranteAndSendMail========== " + swfMensaje.getMenCodmen());
		SearchResponse searchResponse = new SearchResponse();
		try {
			SwiftDatos swiftDatos = mensajePlanoToSwfMensaje(swfMensaje.getMenPlano(), false);

			List<Block4> block4List = SwiftDatos.block4ToBlock4Ldv(swiftDatos.getSwiftMessageAbs().createBlock4().getBlock4());

			DocumentBatch<SearchResultOfac> documentBatchResult = searchForSwfMensaje(block4List, ofacScanServiceImpl, true);
			searchResponse = fromSearchResultOfacDTO(documentBatchResult, false, ofacScanServiceImpl);

			// cambiarEstadoPostScan(swfMensaje, searchResponse);
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
		}

		log.info("~~~~~~~~~~~~~~Fin verificar Mensaje entrante swift ~~~~~~~~~~~~~~[" + searchResponse.getCountRegs() + "]");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.lavado.services.SwiftBcbSearcherService#searchScanSingle
	 * (java.lang.String)
	 */
	public SearchResponse searchScanSingle(String menPlano, boolean exitOnFirstFound) {
		log.info("=======searchScanSingle==========");
		SearchResponse searchResponse = null;
		JPASearchFactoryControllerImpl jPASearchFactoryController = null;
		try {
			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
			jPASearchFactoryController.init();
			OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);

			SwiftDatos swiftDatos = mensajePlanoToSwfMensaje(menPlano, false);
			SwiftMessageAbstract sma = swiftDatos.getSwiftMessageAbs();
			List<Block4> block4List = SwiftDatos.block4ToBlock4Ldv(sma.createBlock4().getBlock4());

			DocumentBatch<SearchResultOfac> documentBatchResult = searchForSwfMensaje(block4List, ofacScanServiceImpl, exitOnFirstFound);
			searchResponse = fromSearchResultOfacDTO(documentBatchResult, true, ofacScanServiceImpl);

			searchResponse.setQry(sma.getMenPlano());
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			searchResponse = getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			searchResponse = getSearchResultFromException(e);
		} finally {
			jPASearchFactoryController.close();
		}

		log.info("~~~~~~~~~~~~~~End verified Message plain ~~~~~~~~~~~~~~[" + searchResponse.getCountRegs() + "]");
		return searchResponse;
	}

	public SwiftDatos mensajePlanoToSwfMensaje(String menPlano, boolean requireDescrip) {
		SwiftDatos swiftDatos = SwiftBcbParserServiceImpl.actualizarSwfMensajeFromPlano(menPlano);
		return swiftDatos;
	}

	public SearchResponse verificarMensaje(String query, String idEstrategia) {
		log.info("==>> verificarMensaje por estrategia: " + idEstrategia + " : " + query);
		if (idEstrategia == null || idEstrategia.trim().length() == 0) {
			SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CODESTRADEFAULT);
			idEstrategia = swfParams.getParValor().trim().toUpperCase();
		}

		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();
		SearchResponse searchResponse = null;
		JPASearchFactoryControllerImpl jPASearchFactoryController = null;
		try {
			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
			jPASearchFactoryController.init();
			OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);
			documentBatchResult = searchForIdEstrategia(query, idEstrategia, ofacScanServiceImpl);
			searchResponse = fromSearchResultOfacDTO(documentBatchResult, true, ofacScanServiceImpl);
		} catch (NullPointerException e) {
			log.error(e.getMessage());
			searchResponse = getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage());
			searchResponse = getSearchResultFromException(e);
		} finally {
			jPASearchFactoryController.close();
		}
		log.info("==>> Fin scan field: " + idEstrategia + ":" + query + " regs[" + searchResponse.getCountRegs() + "]");
		return searchResponse;
	}

	/**
	 * Proceso de scaneo de items en lista, el proceso es asyncronico
	 * 
	 * @param block4List
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @throws TimeoutException
	 */
	private DocumentBatch<SearchResultOfac> searchForSwfMensaje(List<Block4> block4List, OfacScanServiceImpl ofacScanServiceImpl, boolean exitOnFirstFound)
			throws Exception {
		StrategyBase strategyBase = StrategyBase.getInstance().initialize(pathDirectoryQueries);

		long buildTime = System.currentTimeMillis();
		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();
		if (block4List.size() == 0) {
			log.error("ATENCION: Mensaje sin elementos");
			throw new SwiftAdminException("Mensaje sin elementos para evaluar");
		}

		List<Block4> block4Exists = block4List.stream().filter(b -> {
			Map<String, Map<String, List<FieldQuery>>> matches;
			try {
				matches = strategyBase.matchesForFieldswift(b.getName());
				return matches.size() > 0;
			} catch (ExecutionException e) {
				log.error(e.getMessage());
				return false;
			}

		}).collect(Collectors.toList());

		for (Block4 block4 : block4Exists) {
			DocumentBatch<SearchResultOfac> documentBatchResultR = ofacScanServiceImpl.searchForFieldSwift(block4.getValue(), block4.getName(), strategyBase,
					exitOnFirstFound);
			if (documentBatchResultR.getBatchSize() > 0)
				for (SearchResultOfac searchResultOfac : documentBatchResultR)
					documentBatchResult.add(searchResultOfac);

//			log.info("Resp provisional ==> " + documentBatchResult.getBatchSize());
			if (exitOnFirstFound && documentBatchResult.getBatchSize() > 0) {
				break;
			}
		}

		log.info("Fin scan mensaje (" + (System.currentTimeMillis() - buildTime) + " ms) @ " + documentBatchResult.getBatchSize() + " @");
		return documentBatchResult;
	}

	private DocumentBatch<SearchResultOfac> searchForIdEstrategia(String query, String idEstrategia, OfacScanServiceImpl ofacScanServiceImpl)
			throws Exception {
		StrategyBase strategyBase = StrategyBase.getInstance().initialize(pathDirectoryQueries);

		Map<String, List<FieldQuery>> fieldQueryMap = strategyBase.matchesForIdEstrategia(idEstrategia);

		if (fieldQueryMap.size() == 0) {
//			log.info("==>> field: " + idEstrategia + " Sin estrategias!!! " + pathDirectoryQueries);
			return new DocumentBatch<SearchResultOfac>();
		}
		log.info("===oooO0[Inicio scan Estrategia swift[" + idEstrategia + "] query:\n" + UtilsGeneric.getShortText(query, MAX_CHARS_LOG) + "\n]0Oooo===");

		long buildTime = System.currentTimeMillis();

		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();

		/* ####### process search ###### */
		DocumentBatch<SearchResultOfac> documentBatchResultR = ofacScanServiceImpl.search(query, fieldQueryMap);
		for (SearchResultOfac searchResultOfacR : documentBatchResultR)
			documentBatchResult.add(searchResultOfacR);

		log.info("==>> field: " + idEstrategia + ":" + query + " Con registros!!!" + documentBatchResult.getBatchSize() + "["
				+ (System.currentTimeMillis() - buildTime) + " ms.]");
		return documentBatchResult;
	}

	public String searchForQueryInSwfMensaje(String query, SwfMensaje swfMensaje, String idEstrategia,
			JPASearchFactoryControllerImpl jPASearchFactoryController) throws Exception {
		if (jPASearchFactoryController == null)
			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());

		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, SwfMensaje.class);

		StrategyBase strategyBase = StrategyBase.getInstance().initialize(pathDirectoryQueries);

		Map<String, List<FieldQuery>> fieldQueryMap = strategyBase.matchesForIdEstrategia(idEstrategia);
		if (fieldQueryMap == null || fieldQueryMap.size() == 0) {
			log.info("==>> idEstrategia: " + idEstrategia + " Sin estrategias!!!");
			return null;
		}

		for (List<FieldQuery> fieldQueryEntry : fieldQueryMap.values()) {
			for (FieldQuery fieldQuery : fieldQueryEntry) {
				try {
					String hiqh = queryParsersBuilder.highlightFieldSpanNearFuzzy(fieldQuery.getField(), query,
							swiftBcbParserService.decryptPlano(swfMensaje.getMenPlano()), fieldQuery.getDistanceUpTo(), fieldQuery.getPrefixLength(),
							fieldQuery.getBoost(), fieldQuery.getSlop(), fieldQuery.isInOrder(), fieldQuery.getMinWordLen(), fieldQuery.isExceptNumbers(),
							fieldQuery.getAnalyzer());
					if (hiqh != null) {
						return hiqh;
					}
				} catch (IOException | InvalidTokenOffsetsException e) {
					log.error(e.getMessage(), e);
				}
			}
		}
		return null;
	}

	public List<?> searchForQueryInSwfBics(String query, String idEstrategia) {
		log.info("searchForQueryInSwfBics query {} idEstrategia {}", query, idEstrategia);
		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();
		List<?> searchResponse = new ArrayList<>();
		JPASearchFactoryControllerImpl jPASearchFactoryController = null;
		try {
			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
			jPASearchFactoryController.init();
			OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);
			documentBatchResult = searchForIdEstrategia(query, idEstrategia, ofacScanServiceImpl);
			searchResponse = documentMatchFromSearchResult(documentBatchResult);
		} catch (NullPointerException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Valor nulo al buscar bics");
		} catch (Throwable e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage(), e);
		} finally {
			jPASearchFactoryController.close();
		}
		return searchResponse;
	}

	/**
	 * Convierte los resultados a {@link SearchResponse} con el numero de items
	 * encontrados
	 * 
	 * @param document
	 * @param requireResp true si en la respuesta se devuelve los terminos
	 *                    encontrados marcados
	 * @return
	 */
	private SearchResponse fromSearchResultOfacDTO(DocumentBatch<SearchResultOfac> document, boolean requireResp, OfacScanServiceImpl ofacScanServiceImpl) {

		Map<String, SearchResponse.ItemsInfo> itemsInfoMap = new LinkedHashMap<>();
		log.info("Convert DocumentBatch to SearchResponse " + document.getBatchSize() + " [regs]" + " "
				+ (ofacScanServiceImpl.getjPASearchFactoryController() == null));
		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(ofacScanServiceImpl.getjPASearchFactoryController(), OfaSdnentry.class);

		for (SearchResultOfac searchResultOfac : document) {
			for (OfacQuery ofacQuery : searchResultOfac.getMatches()) {
				ItemsInfo itemsInfo = new ItemsInfo();

				itemsInfo.setScore(ofacQuery.getScore());
				itemsInfo.setIdDoc(searchResultOfac.getDocId());
				if (searchResultOfac.getDocumentMatch() instanceof OfaAkalist) {
					OfaAkalist ofaAkalist = (gob.bcb.lavado.model.OfaAkalist) searchResultOfac.getDocumentMatch();
					itemsInfo.setIdDoc(String.valueOf(ofaAkalist.getAkaEntryuid()));
				}

				itemsInfo.setClazz(ofacQuery.getFieldQuery().getClazz().getSimpleName());
				itemsInfo.setField(ofacQuery.getFieldQuery().getField());

				String idInfo = String.valueOf(Objects.hash(itemsInfo.getClazz(), itemsInfo.getIdDoc()));
				itemsInfo.setId(idInfo);
				String hiqh = "";
				if (requireResp) {
					try {
						if (StringUtils.isBlank(ofacQuery.getTermHigh())) {
							hiqh = queryParsersBuilder.highlightFieldSpanOrQueryFuzzy(itemsInfo.getField(), ofacQuery.getQuery(), ofacQuery.getTerm(),
									ofacQuery.getFieldQuery().getDistanceUpTo(), ofacQuery.getFieldQuery().getPrefixLength(),
									ofacQuery.getFieldQuery().getBoost(), ofacQuery.getFieldQuery().getSlop(), ofacQuery.getFieldQuery().isInOrder(),
									ofacQuery.getFieldQuery().getMinWordLen(), ofacQuery.getFieldQuery().isExceptNumbers(),
									ofacQuery.getFieldQuery().getAnalyzer());
						} else {
							hiqh = ofacQuery.getTermHigh();
						}

						if (hiqh == null) {
							hiqh = ofacQuery.getTerm();
						}
					} catch (IOException | InvalidTokenOffsetsException e) {
						log.error(e.getMessage(), e);
						hiqh = "";
					}
				}
				if (!itemsInfoMap.containsKey(idInfo)) {
					itemsInfo.setContentHighlight(ofacQuery.getFieldQuery().getField() + ": " + hiqh);
					itemsInfoMap.put(idInfo, itemsInfo);
				} else {
					itemsInfoMap.get(idInfo).setContentHighlight(
							itemsInfoMap.get(idInfo).getContentHighlight() + "<br/>" + ofacQuery.getFieldQuery().getField() + ": " + hiqh);
					itemsInfoMap.get(idInfo).setScore(itemsInfoMap.get(idInfo).getScore() + itemsInfo.getScore());
				}
			}
		}

		List<ItemsInfo> itemsInfoList = itemsInfoMap.values().stream().collect(Collectors.toList());

		SearchResponse searchResponse = createResponse(Constants.COD_RESP_EXITO, itemsInfoList.size(), null, null);
		itemsInfoList.sort((u1, u2) -> u1.getScore().compareTo(u2.getScore()));
		Collections.reverse(itemsInfoList);
		searchResponse.setItemsInfo(itemsInfoList.toArray(new SearchResponse.ItemsInfo[0]));
		searchResponse.setDescripResp("Operacion de scaneo realizada exitosamente sin observados");

		if (searchResponse.getCountRegs() > 0) {
			searchResponse.setCodResp(Constants.COD_RESP_ERR_01);
			searchResponse.setDescripResp("Operacion de Scaneo con registros observados " + searchResponse.getCountRegs());
		}
		log.info("Registros encontrados ==> [" + searchResponse.getCountRegs() + "] regs.");
		return searchResponse;
	}

	private List<?> documentMatchFromSearchResult(DocumentBatch<SearchResultOfac> document) {
		Map<String, Object> itemsInfoMap = new LinkedHashMap<>();

		for (SearchResultOfac searchResultOfac : document) {
			for (OfacQuery ofacQuery : searchResultOfac.getMatches()) {
				String idInfo = String.valueOf(Objects.hash(ofacQuery.getFieldQuery().getClazz().getSimpleName(), searchResultOfac.getDocId()));
				if (!itemsInfoMap.containsKey(idInfo)) {
					itemsInfoMap.put(idInfo, searchResultOfac.getDocumentMatch());
				}
				if (itemsInfoMap.size() > Constants.SEARCH_LIMIT_REGS) {
					break;
				}
			}
			if (itemsInfoMap.size() > Constants.SEARCH_LIMIT_REGS) {
				break;
			}
		}

		return itemsInfoMap.values().stream().collect(Collectors.toList());
	}

	/**
	 * retorna el objeto detallando la excepcion
	 * 
	 * @param e
	 * @return
	 */
	public static SearchResponse getSearchResultFromException(Throwable e) {
		log.info("Generando objeto respuesta por exception " + e.getMessage());
		StringBuilder sb = new StringBuilder();
		int count = 0;
		for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
			if (cause instanceof SQLException) {
				count++;
				sb.append(cause.getMessage());
				sb.append(" , ");
			}
		}
		String consent = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));

		SearchResponse searchResponse = createResponse(Constants.COD_RESP_ERR_02, 1, null, null);
		searchResponse.setDescripResp(consent);

		log.info("Respuesta con Error " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());
		return searchResponse;
	}

	private static void accionPostScan(SwfMensaje swfMensajeNew, SearchResponse searchResponse) {
		// acciones de respuesta si es observado
		if (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0
				|| swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0) {
			// mensaje escaneado y bloqueado
			searchResponse.setCodResp(Constants.COD_RESP_ERR_01);
			searchResponse.setDescripResp("Mensaje " + swfMensajeNew.getMenCodmen() + " [" + swfMensajeNew.getMenCodswift()
					+ "] fue bloqueado. Comuníquese con el Administrador de Control de Lavado.");
			log.info("Mensaje bloqueado [" + swfMensajeNew.getMenCodmen() + "] scaneado con estado " + swfMensajeNew.getMenEstverifica());
		} else {
			// mensaje observado pero no se bloquea
			searchResponse.setCountRegs(0);
			searchResponse.setCodResp(Constants.COD_RESP_EXITO);
			searchResponse.setItemsInfo(new SearchResponse.ItemsInfo[0]);
			searchResponse.setDescripResp("Operacion de control de lavado: mensaje swift sin observados.");

			log.info("Mensaje observado sin bloqueo [" + swfMensajeNew.getMenCodmen() + "] scaneado con estado " + swfMensajeNew.getMenEstverifica());
		}
	}

	private void sendMail(SwfMensaje swfMensajeNew) {
		if (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0
				|| swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0) {
			EmailDetalle emailDetalle = inicializaCorreos();
			sendMailForVerify(swfMensajeNew, Constants.COD_APP_NEMO + ": Alerta de mensaje swift observado " + swfMensajeNew.getMenCodmen(), emailDetalle);
		}
	}
	
	private EmailDetalle inicializaCorreos() {
		if (StringUtils.isBlank(appProperties.getMail().getToAlert())) {
			swfParamsDao.updProperties();
		}
		
		//SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CORRALERTAVERIF);
		String correos = StringUtils.trimToEmpty(appProperties.getMail().getToAlert());

		final String[] tokens = StringUtils.split(correos, ",;");
		final ArrayList<String> result = new ArrayList<String>();

		for (int i = 0; i < tokens.length; i++) {
			if (StringUtils.isNotBlank(tokens[i]))
				result.add(tokens[i]);
		}
		EmailDetalle emailDetalle = new EmailDetalle();
		emailDetalle.setTo(result.toArray(new String[result.size()]));
		return emailDetalle;
	}

	private void sendMailForVerify(SwfMensaje swfMensaje, String subject, EmailDetalle emailDetalle) {
		// correos para alerta
		MensajesDatos mensajesDatos = new MensajesDatos();
		mensajesDatos.setSwfMensaje(swfMensaje);

		emailDetalle.setSubject(subject);
		emailDetalle.setFrom(StringUtils.trimToEmpty(appProperties.getMail().getFromAlert()));
		mailService.sendAlertSwiftForRevisionEmail(mensajesDatos, emailDetalle, null);
		//log.info("Envio de correo de ALERTA hecho... " + swfMensaje.getMenCodmen() + " -> " + emailDetalle.getTo());
	}

	public static SearchResponse createResponse(String codResp, Integer countRegs, String codoperacion, Integer nrocorr) {
		SearchResponse searchResponseError = new SearchResponse();
		List<SearchResponse.ItemsInfo> itemsInfoList = new LinkedList<>();
		searchResponseError.setCodResp(codResp);
		searchResponseError.setCodoperacion(codoperacion);
		searchResponseError.setCountRegs(countRegs);
		searchResponseError.setNrocorr(nrocorr);
		searchResponseError.setItemsInfo(itemsInfoList.toArray(new SearchResponse.ItemsInfo[0]));
		searchResponseError.setDescripResp("");

		return searchResponseError;
	}
}
