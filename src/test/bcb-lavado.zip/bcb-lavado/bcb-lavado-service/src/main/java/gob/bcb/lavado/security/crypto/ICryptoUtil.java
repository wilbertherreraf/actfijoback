package gob.bcb.lavado.security.crypto;

import java.security.Key;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

public interface ICryptoUtil {
	public String encryptAndBase64(byte[] data, Key key);

	public byte[] decryptBase64(String base64andEncrypted, Key key) throws IllegalBlockSizeException, BadPaddingException;

	public Key getCryptoKey(String seed);

	void initialize(String fileKeystore, String password, boolean createKeystoreFileIfNotExist) throws Exception;

}
