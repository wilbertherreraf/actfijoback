package gob.bcb.lavado.repository;

import java.util.Date;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.model.OfaBlanklist;

public class OfaBlanklistRepositoryImpl {
	private static final Logger log = LoggerFactory.getLogger(OfaBlacklistRepositoryImpl.class);
	@Autowired
	private OfaBlanklistRepository ofaBlanklistRepository;
	
	public OfaBlanklist actualizarOfaBlanklist(OfaBlanklist ofaBlacklist){
		if (StringUtils.isBlank(ofaBlacklist.getBlcContent()))
			throw new DataException("Contenido de la lista invalido");
		
		if (ofaBlacklist.getBlcId() == null){
			Optional<OfaBlanklist> ofaBlacklistMax = ofaBlanklistRepository.findOneMaximo();
			if (ofaBlacklistMax.isPresent()){
				ofaBlacklist.setBlcId(ofaBlacklistMax.get().getBlcId() + 1);
			} else {
				ofaBlacklist.setBlcId(1);
			}
		}
		
		ofaBlacklist.setBlcAuditfho(new Date());
		ofaBlanklistRepository.saveAndFlush(ofaBlacklist);
		log.info("actualizarOfaBlanklist " + ofaBlacklist.getBlcId());
		return ofaBlanklistRepository.findOne(ofaBlacklist.getBlcId());
	}
	
	public OfaBlanklist autorizarOfaBlanklist(OfaBlanklist ofaBlanklist){
		if (StringUtils.isBlank(ofaBlanklist.getBlcContent()))
			throw new DataException("Contenido de la lista invalido");
		
		ofaBlanklist.setBlcAuditfho(new Date());
		ofaBlanklistRepository.saveAndFlush(ofaBlanklist);
		log.info("autorizarOfaBlanklist " + ofaBlanklist.getBlcId() + " por " + ofaBlanklist.getBlcAuditusr());
		return ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());		
	}
}
