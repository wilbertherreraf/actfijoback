package gob.bcb.lavado.services;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.client.HandlerGeneratorLauSrv;
import gob.bcb.lavado.client.lau.GeneratorLAU;
import gob.bcb.lavado.client.pojos.GenLauDto;
import gob.bcb.lavado.client.utils.GeneradorPassword;
import gob.bcb.lavado.client.utils.UtilsSec;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.model.OfaBlacklist;
import gob.bcb.lavado.model.OfaBlanklist;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.ofac.OfacLoader;
import gob.bcb.lavado.ofac.dto.OfacListas;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.OfaBlacklistRepository;
import gob.bcb.lavado.repository.OfaBlanklistRepository;
import gob.bcb.lavado.repository.SwfBicsDao;
import gob.bcb.lavado.repository.SwfLoteDao;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.lavado.search.OfacIndexer;

@Service("swiftAdminDaoService")
public class SwiftAdminDaoServiceImpl implements SwiftAdminDaoService {
	private static final Logger log = LoggerFactory.getLogger(SwiftAdminDaoServiceImpl.class);

	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private OfaBlacklistRepository ofaBlacklistRepository;
	@Autowired
	private OfaBlanklistRepository ofaBlanklistRepository;
	@Autowired
	private OfacIndexer ofacIndexer;
	@Autowired
	private SwfBicsDao swfBicsDao;
	@Autowired
	private SwfLoteDao swfLoteDao;
	@Autowired
	private OfaListService ofaListService;
	// @Autowired
	// private LavadoProperties lavadoProperties;
	@Autowired
	private AppProperties appProperties;
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private SchedulerService schedulerService;
	@Autowired 
	private OfacLoader ofacLoader;
	@Autowired
	private MailService mailService;

	public List<MensajesDatos> findObservados(Integer estVerifica) {
		List<MensajesDatos> mensajesDatosLista = new ArrayList<MensajesDatos>();

		swfMensajeDao.findObservados(estVerifica).forEach(swfMensaje -> {
			MensajesDatos mensajesDatos = swfMensajeDao.mensajeDatosFromSwfMensaje(swfMensaje, null, null, null, 0, false);
			mensajesDatosLista.add(mensajesDatos);
		});
		log.info("Nro Observados " + mensajesDatosLista.size());
		return mensajesDatosLista;
	}

	public SwfMensaje bloquearMensaje(Integer codMen, String codUsuario, String estacion) {
		log.info("bloquearMensaje " + codMen + " por " + codUsuario);
		return swfMensajeDao.cambiarEstadoVerificacion(codMen, codUsuario, Constants.TAB_ESTVERIFICA_POSITIVO_BLQ, estacion);
	}

	public SwfMensaje habilitarMensaje(Integer codMen, String codUsuario, String estacion) {
		log.info("habilitarMensaje " + codMen + " por " + codUsuario);
		return swfMensajeDao.cambiarEstadoVerificacion(codMen, codUsuario, Constants.TAB_ESTVERIFICA_FALSO_POSITIVO, estacion);
	}

	public SwfMensaje rechazarMensaje(Integer codMen, String codUsuario, String estacion) {
		log.info("eliminarMensaje " + codMen + " por " + codUsuario);
		return swfMensajeDao.cambiarEstadoAutorizacion(codMen, codUsuario, Constants.TAB_ESTAUTORIZA_RECHAZADOPORADMINSWFT, estacion);
	}

	public OfaBlacklist actualizarOfaBlacklist(OfaBlacklist ofaBlacklist, String estacion) {
		if (StringUtils.isBlank(ofaBlacklist.getBlkContent()))
			throw new DataException("Valor ingresado para lista negra inválida");
		if (StringUtils.isBlank(ofaBlacklist.getBlkType()))
			throw new DataException("Valor ingresado para tipo de lista negra inválida");

		if (ofaBlacklist.getBlkId() == null) {
			Optional<OfaBlacklist> ofaBlacklistMax = ofaBlacklistRepository.findOneMaximo();
			if (ofaBlacklistMax.isPresent()) {
				ofaBlacklist.setBlkId(ofaBlacklistMax.get().getBlkId() + 1);
			} else {
				ofaBlacklist.setBlkId(1);
			}
		}

		ofaBlacklist.setBlkAuditfho(new Date());
		ofaBlacklist.setBlkAuditwst(estacion);

		try {
			ofaBlacklist.setBlkContent(UtilsGeneric.convertStringToEncode(ofaBlacklist.getBlkContent(), Constants.ENCODING_ISO));
			ofaBlacklist.setBlkType(UtilsGeneric.convertStringToEncode(ofaBlacklist.getBlkType(), Constants.ENCODING_ISO));
		} catch (UnsupportedEncodingException e1) {
			log.error("eror " + e1.getMessage(), e1);
		}

		ofaBlacklistRepository.saveAndFlush(ofaBlacklist);
		log.info("actualizarOfaBlacklist " + ofaBlacklist.getBlkId());
		try {
			ofacIndexer.indexerClassSync(OfaBlacklist.class);
		} catch (Exception e) {
			log.error("Error al indexar " + e.getMessage(), e);
		}
		return ofaBlacklistRepository.findOne(ofaBlacklist.getBlkId());
	}

	public void eliminarOfaBlacklist(OfaBlacklist ofaBlacklist) {
		Integer id = ofaBlacklist.getBlkId();
		ofaBlacklistRepository.delete(ofaBlacklist);
		log.info("eliminado OfaBlacklist " + id);
		try {
			ofacIndexer.indexerClassSync(OfaBlacklist.class);
		} catch (Exception e) {
			log.error("Error al indexar " + e.getMessage(), e);
		}
	}

	public OfaBlanklist actualizarOfaBlanklist(OfaBlanklist ofaBlanklist) {

		if (ofaBlanklist.getBlcId() == null) {
			Optional<OfaBlanklist> ofaBlanklistMax = ofaBlanklistRepository.findOneMaximo();
			if (ofaBlanklistMax.isPresent()) {
				ofaBlanklist.setBlcId(ofaBlanklistMax.get().getBlcId() + 1);
			} else {
				ofaBlanklist.setBlcId(1);
			}
		} else {
			OfaBlanklist ofaBlanklistOld = ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
			if (ofaBlanklistOld != null) {
				if (ofaBlanklistOld.getBlcStatusauto() != null && ofaBlanklistOld.getBlcStatusauto().compareTo(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE) != 0) {
					throw new DataException("No puede modificar el registro, el estado debe ser pendiente");
				}
			}
		}
		if (StringUtils.isBlank(ofaBlanklist.getBlcContent())) {
			throw new DataException("Valor ingresado para lista blanca inválida");
		}
		if (StringUtils.isBlank(ofaBlanklist.getBlcType())) {
			throw new DataException("Valor ingresado para tipo de lista blanca inválida");
		}

		ofaBlanklist.setBlcTabstatusauto(Constants.TAB_STATUSAUTOLBLANCA);
		ofaBlanklist.setBlcStatusauto(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE);
		ofaBlanklist.setBlcEstadoauto(null);
		ofaBlanklist.setBlcAuditfho(new Date());

		try {
			ofaBlanklist.setBlcContent(UtilsGeneric.convertStringToEncode(ofaBlanklist.getBlcContent(), Constants.ENCODING_ISO));
			ofaBlanklist.setBlcType(UtilsGeneric.convertStringToEncode(ofaBlanklist.getBlcType(), Constants.ENCODING_ISO));
		} catch (UnsupportedEncodingException e1) {
			log.error("eror " + e1.getMessage(), e1);
		}

		ofaBlanklistRepository.saveAndFlush(ofaBlanklist);
		log.info("actualizarfaBlanklist " + ofaBlanklist.getBlcId());
		try {
			ofacIndexer.indexerClassSync(OfaBlanklist.class);
		} catch (Exception e) {
			log.error("Error al indexar " + e.getMessage(), e);
			// throw new DataException("Codigo de empleado nulo no puede
			// registrar: " + swfPersona.getPerNombre());
		}
		return ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
	}

	public void eliminarOfaBlanklist(OfaBlanklist ofaBlanklist) {
		log.info("eliminado OfaBlacklist " + ofaBlanklist.toString());

		OfaBlanklist ofaBlanklistOld = ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
		if (ofaBlanklistOld != null) {
			if (ofaBlanklistOld.getBlcStatusauto() != null && ofaBlanklistOld.getBlcStatusauto().compareTo(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE) != 0) {
				throw new DataException("No puede eliminar el registro, el estado debe ser pendiente");
			}
		}
		ofaBlanklistRepository.delete(ofaBlanklist);
		try {
			ofacIndexer.indexerClassSync(OfaBlanklist.class);
		} catch (Exception e) {
			log.error("Error al indexar " + e.getMessage(), e);
		}
	}

	public OfaBlanklist autorizarOfaBlanklist(OfaBlanklist ofaBlanklist) {
		Integer id = ofaBlanklist.getBlcId();
		log.info("autorizando OfaBlanklist " + id);
		try {
			OfaBlanklist ofaBlanklistOld = ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
			if (ofaBlanklistOld == null) {
				throw new RuntimeException("Registro inexistente");
			}

			if (ofaBlanklistOld.getBlcStatusauto().equals(Constants.TAB_STATUSAUTOLBLANCA_AUTORIZADO)) {
				throw new RuntimeException("El registro autorizado, elija uno con estado no autorizado");
			}

			if (StringUtils.isBlank(ofaBlanklistOld.getBlcContent())) {
				throw new DataException("Valor de contenido de lista inválido");
			}
			if (StringUtils.isBlank(ofaBlanklistOld.getBlcType())) {
				throw new DataException("Valor de tipo contenido de lista inválido");
			}

			ofaBlanklistOld.setBlcAuditfho(new Date());
			ofaBlanklistOld.setBlcTabstatusauto(Constants.TAB_STATUSAUTOLBLANCA);
			ofaBlanklistOld.setBlcStatusauto(Constants.TAB_STATUSAUTOLBLANCA_AUTORIZADO);
			ofaBlanklistOld.setBlcEstadoauto(Constants.TAB_STATUSAUTOLBLANCA_AUTORIZADOSTR);

			ofaBlanklistRepository.saveAndFlush(ofaBlanklistOld);

			ofacIndexer.indexerClassSync(OfaBlanklist.class);
			return ofaBlanklistRepository.findOne(ofaBlanklistOld.getBlcId());
		} catch (Exception e) {
			log.error("Error al autorizar registro " + e.getMessage(), e);
			throw new DataException("Error al autorizar registro: " + e.getMessage());
		}
	}

	public OfaBlanklist cambiarAPendienteOfaBlanklist(OfaBlanklist ofaBlanklist) {
		Integer id = ofaBlanklist.getBlcId();
		OfaBlanklist ofaBlanklistOld = ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
		if (ofaBlanklistOld == null) {
			throw new RuntimeException("Registro inexistente");
		}

		if (ofaBlanklistOld.getBlcStatusauto().equals(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE)) {
			throw new RuntimeException("El registro en estado pendiente, elija uno con estado diferente");
		}

		log.info("cambiarAPendiente OfaBlacklist " + id);
		ofaBlanklist.setBlcAuditfho(new Date());
		ofaBlanklist.setBlcTabstatusauto(Constants.TAB_STATUSAUTOLBLANCA);
		ofaBlanklist.setBlcStatusauto(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE);
		ofaBlanklist.setBlcEstadoauto(null);
		ofaBlanklistRepository.saveAndFlush(ofaBlanklist);

		try {
			ofacIndexer.indexerClassSync(OfaBlanklist.class);
			return ofaBlanklist;
		} catch (Exception e) {
			log.error("Error al autorizar registro " + e.getMessage(), e);
			throw new DataException("Error al autorizar registro: " + ofaBlanklist.getBlcId());
		}
	}

	public SwfBics actualizarSwfBics(SwfBics swfBics) {
		SwfBics swfBicsNew = swfBicsDao.actualizar(swfBics);
		return swfBicsNew;
	}

	/**
	 * Salva un archivo con lista de obsrevados OFAC de formato XML
	 */
	public static Integer numitems = 250;
	public static int numExecutors = 8;
	
	public SwfLote guardarLoteOfac(String codEmpleado, ArchivoSinple archivoSinple, String estacion) {
		log.info("guardarLoteOfac {} {}", codEmpleado, estacion);
		log.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		
		archivoSinple.setDirectory(appProperties.getLavado().getAppdir() + "/" + Constants.DIR_OFAC_FILES_TMP);
		long startTime = System.currentTimeMillis();

		SwfLote swfLoteNew = swfLoteDao.guardarLoteOfac(codEmpleado, archivoSinple, true, estacion);
		
		boolean doContingencia = false;
		List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableListN = OfacLoader.convertFileXMLInmutable(swfLoteNew.getLotNrolote(), swfLoteNew.getLotPathfile());
		List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableList = ofaListService.filterSdnEntryNoRegistrados(immutableListN);
		
		log.info("Lista observador In {} real {}" , immutableListN.size(), immutableList.size());
		try{
			guardarListaOfacFP(immutableList, numitems, numExecutors);
			log.info("Done Save OFAC list at (" + (System.currentTimeMillis() - startTime) + " ms.)");
		} catch (Exception e){
			log.info("Error al guardar por hilos" + e.getMessage(), e);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e1) {
			}
//			doContingencia = true;
			throw new RuntimeException("Error al cargar de lista: " + e.getMessage(), e);
		}
		
		if (doContingencia ) {
			log.warn("CARGA POR CONTINGENCIA!!!!");
			startTime = System.currentTimeMillis();
			
			List<ImmutablePair<Integer, List<OfaSdnentry>>> list = new ArrayList<>();
			
			for( ImmutablePair<Integer, List<OfaSdnentry>> inmu : immutableList) {
				ImmutablePair<Integer, List<OfaSdnentry>> itemlist = new ImmutablePair<Integer, List<OfaSdnentry>>(inmu.left, new ArrayList<>());
				
				inmu.right.forEach(r -> {
//					log.info("reg conti {} {}", r.getSdnId(), r.getSdnEntryuid());
					if (r.getSdnId() == null) {
						itemlist.right.add(r);
					}
				});
				list.add(itemlist);
			}
			
			log.info("Registros restantes por contingencia {}", list.size());
			guardarListaOfacSec(list, swfLoteNew.getLotNrolote());
			log.info("Conting Done Save OFAC list at (" + (System.currentTimeMillis() - startTime) + " ms.)");
		}
		
		return swfLoteNew;
	}

	public SwfLote guardarLoteOfacSec(String codEmpleado, ArchivoSinple archivoSinple, String estacion) {
		log.info("SECUENCIAL guardarLoteOfacSec {} {}", codEmpleado, estacion);
		
		archivoSinple.setDirectory(appProperties.getLavado().getAppdir() + "/" + Constants.DIR_OFAC_FILES_TMP);
		long startTime = System.currentTimeMillis();

		SwfLote swfLoteNew = swfLoteDao.guardarLoteOfac(codEmpleado, archivoSinple, true, estacion);
		
		List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableListN = OfacLoader.convertFileXMLInmutable(swfLoteNew.getLotNrolote(), swfLoteNew.getLotPathfile());
		List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableList = ofaListService.filterSdnEntryNoRegistrados(immutableListN);
		
		log.info("SEC: Lista observador In {} real {}" , immutableListN.size(), immutableList.size());
		startTime = System.currentTimeMillis();
		
		List<ImmutablePair<Integer, List<OfaSdnentry>>> list = new ArrayList<>();
		
		for( ImmutablePair<Integer, List<OfaSdnentry>> inmu : immutableList) {
			ImmutablePair<Integer, List<OfaSdnentry>> itemlist = new ImmutablePair<Integer, List<OfaSdnentry>>(inmu.left, new ArrayList<>());
			
			inmu.right.forEach(r -> {
//					log.info("reg conti {} {}", r.getSdnId(), r.getSdnEntryuid());
				if (r.getSdnId() == null) {
					itemlist.right.add(r);
				}
			});
			
			list.add(itemlist);
		}
		
		log.info("Registros restantes por contingencia {}", list.size());
		guardarListaOfacSec(list, swfLoteNew.getLotNrolote());
		log.info("Conting Done Save OFAC list at (" + (System.currentTimeMillis() - startTime) + " ms.)");
		
		return swfLoteNew;
	}

	private void guardarListaOfacFP(List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableList, Integer numitems, int numExecutors) {
		
		Stream<CompletableFuture<Void>> futureWrite = immutableList.stream().map(immutableListr -> {
			return CompletableFuture.supplyAsync(() -> {
				log.info("{} [{}] En supplyAsync con {} regs", immutableListr.left, Thread.currentThread().getName(), immutableListr.right.size() );
				
				List<ImmutablePair<OfaSdnentry, OfacListas>> imreg = OfacLoader.getListaOfaSdnentry(immutableListr.right, immutableListr.left).get();
				save(imreg);
				return imreg;
			});
		}).map(f0 -> f0.thenAccept(ff -> {
			
			printpru(ff);
		}));
		
		List<CompletableFuture<Void>> priceFutures = futureWrite.collect(Collectors.<CompletableFuture<Void>> toList());
		log.info("-------------IIIIIIIIII------------------- ");
		long count = priceFutures.stream().map(CompletableFuture::join).map(m -> {
			log.info("Completado ... {}",Thread.currentThread().getName()) ;
			return m;
		}).count();// collect(Collectors.toList());
		
		log.info("-------------IIIII[{}]IIIII------------------- ", count);
	}
	
	private void guardarListaOfacSec(List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableList, Integer nrolote) {
		immutableList.stream().map(immutableListr -> {
			List<ImmutablePair<OfaSdnentry, OfacListas>> imreg = OfacLoader.getListaOfaSdnentry(immutableListr.right, nrolote).get();
			return imreg;
		}).forEach(imreg -> {
			save(imreg);
			
		});;
	}
	
	public void save(List<ImmutablePair<OfaSdnentry, OfacListas>> imreg) {
		ofaListService.saveLista(imreg);
	}

	public void loadListsFromDirectory(String codEmpleado, String estacion) throws Throwable {
		log.info("loadListsFromDirectory " + codEmpleado);
		ofaListService.loadListsFromDirectory(codEmpleado, estacion);
	}

	public void truncarListaOfac(String codEmpleado, String estacion) throws Throwable {
		ofaListService.truncateTablesOfac(codEmpleado, estacion);
		indexOfaSdnentry();
	}

	public void indexOfaSdnentry() throws Exception {
		ofacIndexer.indexOfaSdnentry();
	}

	public void indexLvdEntities() throws Exception {
		ofacIndexer.indexLvdEntities();
	}

	public static void printpru(List<ImmutablePair<OfaSdnentry, OfacListas>> imreg) {
		if (imreg.size() == 0 || imreg.get(0).right == null)
			return;
		log.info("{} [{}] Fin apply >>>> {} regs", imreg.get(0).right.getPosition(), Thread.currentThread().getName(), imreg.size());
	}
	
	/**
	 * Graba en el direcotrio swift (importados) los mensajes pendientes
	 */
	public void grabarEnDirectorioSwift(List<SwfMensaje> swfMensajeLista, String codUser, String estacion) {
		log.info("Inicio salvado en carpeta swift... " + codUser + " items: " + swfMensajeLista.size());
		// seleccionamos todos los mensajes pendientes
		for (SwfMensaje swfMensaje : swfMensajeLista) {
			// cambiamos el estado del registro
			log.info("Antes de proceso de salvado mensaje " + swfMensaje.getMenCodmen());
			swfMensajeDao.guardarEnImportados(swfMensaje.getMenCodmen(), codUser, null, estacion);

		}

		// whf 20171211 en conversación con VTindal se quedó, a razón de
		// observación de FLecoña sobre los excesivos correos, que no se
		// requiere los correos al ser autorizados

		// EmailDetalle emailDetalle = new EmailDetalle();
		// emailDetalle.setTo(inicializaCorreos());
		//
		// for (SwfMensaje swfMensaje : swfMensajeListaAutos) {
		// // cambiamos el estado del registro
		// log.info("mensaje autorizado para alerta Autorizacion " +
		// swfMensaje.getMenCodmen());
		// MensajesDatos mensajesDatos = new MensajesDatos();
		// mensajesDatos.setSwfMensaje(swfMensaje);
		// mailService.sendAlertSwiftAutorizadoEmail(mensajesDatos,
		// emailDetalle, null);
		// }
	}

	public void grabarEnDirectorioSwift(String codUser, String estacion) {
		log.info("Inicio salvado CRON SALVADO... " + codUser);

		List<SwfMensaje> swfMensajeLista = swfMensajeDao.findByEstautoriza(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR, Constants.TAB_ESTMENSAJE_PROCESADO);
		grabarEnDirectorioSwift(swfMensajeLista, codUser, estacion);
	}

	public SwfMensaje solicitarCorrelativo(String codapp, String codoperacion, String coduser, String estacion, String idsession) {
		return swfMensajeDao.solicitarCorrelativo(codapp, coduser, codoperacion, estacion, idsession);
	}

	@Transactional
	public SwfParams actualizarSwfParams(SwfParams swfParams, String coduser, String estacion) {
		log.info("Actualizando parametro [{}] por {} - {}", swfParams.toString(), coduser, estacion);
		SwfParams swfParamsNew = swfParamsDao.saveOrUpdate(swfParams);

		if (swfParamsNew.getParCodpar().equals(Constants.PARAM_HORARIOSIMPORT)) {
			log.info("Actualizacion de " + Constants.PARAM_HORARIOSIMPORT + " seejecuta start scheduler " + swfParamsNew.getParValor());
			startScheduling(swfParamsNew.getParValor(), Constants.PARAM_HORARIOSIMPORT, Constants.SCHEDULER_CRON_EXPRESION);
		} else if (swfParamsNew.getParCodpar().equals(Constants.PARAM_HORARIOSINDEXAR)) {
			log.info("Actualizacion de " + Constants.PARAM_HORARIOSINDEXAR + " seejecuta start scheduler " + swfParamsNew.getParValor());
			startScheduling(swfParamsNew.getParValor(), Constants.PARAM_HORARIOSINDEXAR, Constants.SCHEDULER_CRON_EXPRESION);
		} else if (!isParamEditable(swfParamsNew.getParCodpar())) {
			throw new DataException("El parámetro no puede ser actualizado");
		}
		
		return swfParamsNew;
	}

	@Transactional
	public void guardarNuevoLauYNotificarAdmSwift(SwfParams swfParamsCODIGOLAU, SwfParams swfParamsCORREOSCODLAU, GenLauDto genLauDtoCurrent, GenLauDto genLauDtoNew,
			String coduser, String estacion) {
		log.info("guardarNuevoLauYNotificarAdmSwift parametro [{}] por {} - {}", swfParamsCODIGOLAU.toString(), coduser, estacion);

		validaDatosLau(genLauDtoCurrent, genLauDtoNew);

		Date fechaCad = GeneratorLAU.calularFechaCaducidad(genLauDtoNew.getFechaCreacion(), genLauDtoNew.getDiasVigencia());
		genLauDtoNew.setFechaCaducidad(fechaCad);

		if (StringUtils.isBlank(swfParamsCORREOSCODLAU.getParValor())) {
			log.error("Correo destinatario para envio de codigo LAU inválido");
			throw new RuntimeException("Correos no registrados para notificación");
		}
		final String[] tokens = StringUtils.split(swfParamsCORREOSCODLAU.getParValor(), ",;");

		int cont = 0;
		for (int i = 0; i < tokens.length; i++) {
			if (StringUtils.isNotBlank(tokens[i])) {
				UtilsGeneric.validarEmail(tokens[i].trim());
				cont++;
			}
		}

		if (cont == 0) {
			throw new RuntimeException("Correos no registrados para notificación");
		}

		swfParamsCORREOSCODLAU = actualizarSwfParams(swfParamsCORREOSCODLAU, coduser, estacion);

		// guardamos el parametro LAU encoded
		String parValor = "lfp=" + genLauDtoNew.getLauKeyFirstPart() + "&lsp=" + genLauDtoNew.getLauKeySecondPart() + "&ldv=" + genLauDtoNew.getDiasVigencia() + "&lfc="
				+ UtilsDate.stringFromDate(genLauDtoNew.getFechaCreacion(), GeneratorLAU.FECHA_FORMAT_LAU_PROP) + "&lst=" + genLauDtoNew.getLauEstado();
		
//		SwfParams swfParamsCODIGOLAUOld = swfParamsDao.findByCod(Constants.PARAM_CODIGOLAUOLD);
//		GenLauDto genLauDtoOld = GeneratorLAU.getGenLauDtoFromStringEncoded(swfParamsCODIGOLAUOld.getParValor());
//		
//		log.info("CURR fp: " + genLauDtoCurrent.getLauKeyFirstPart() + " sp: " + genLauDtoCurrent.getLauKeySecondPart());		
//		log.info("NEW fp: " + genLauDtoNew.getLauKeyFirstPart() + " sp: " + genLauDtoNew.getLauKeySecondPart());
//		log.info("OLD fp: " + genLauDtoOld.getLauKeyFirstPart() + " sp: " + genLauDtoOld.getLauKeySecondPart());		
//		log.info(parValor);		
		String parValorEnc = Base64.encodeBase64String(UtilsSec.easeyEncrypt(parValor).getBytes());
		swfParamsCODIGOLAU.setParValor(parValorEnc);

		swfParamsCODIGOLAU = swfParamsDao.saveOrUpdate(swfParamsCODIGOLAU);

		// enviamos la notificacion
		EmailDetalle emailDetalle = new EmailDetalle();
		emailDetalle.setTo(tokens);
		emailDetalle.setSubject("Notificación de código LAU generado");

		mailService.sendAlertCodeLauEmail(genLauDtoNew, emailDetalle);
	}

	@Transactional
	public void activarCodigoLauNuevo(String coduser, String estacion) throws Exception {

		SwfParams swfParamsCODIGOLAU = swfParamsDao.findByCod(Constants.PARAM_CODIGOLAU);
		if (swfParamsCODIGOLAU == null) {
			throw new RuntimeException("No existe registro de notificación de correo al administrador del Alliance Swift, guarde y notifique nuevamente.");
		}
		log.info("En activarCodigoLauNuevo [{}] por {} - {}", swfParamsCODIGOLAU.toString(), coduser, estacion);

		if (StringUtils.isBlank(swfParamsCODIGOLAU.getParValor())) {
			throw new RuntimeException("Datos de código LAU inválidos, genere uno nuevo y notifique nuevamente.");
		}

		GenLauDto genLauDtoNew = GeneratorLAU.getGenLauDtoFromStringEncoded(swfParamsCODIGOLAU.getParValor());
		GenLauDto genLauDtoCurrent = HandlerGeneratorLauSrv.getGeneratorLAU().getGenLauDto();

		validaDatosLau(genLauDtoCurrent, genLauDtoNew);

		registrarLauAnterior(genLauDtoCurrent);
		
		HandlerGeneratorLauSrv.getGeneratorLAU().updateCodeLau(genLauDtoNew.getLauKeyFirstPart(), genLauDtoNew.getLauKeySecondPart(), genLauDtoNew.getDiasVigencia(), new Date(),
				"", coduser, estacion, false);

		//HandlerGeneratorLauSrv.getCurrentInstanceHGen().actualizarClientesID();
		log.info("Codigo LAU activado [{}] por {} - {}", swfParamsCODIGOLAU.toString(), coduser, estacion);
	}

	private void registrarLauAnterior(GenLauDto genLauDtoNew){
		log.info("Registrando lau anterior: {} - {}", genLauDtoNew.getLauKeyFirstPart(), genLauDtoNew.getLauKeySecondPart());		
		if (genLauDtoNew == null || StringUtils.isBlank(genLauDtoNew.getLauKeyFirstPart()) || StringUtils.isBlank(genLauDtoNew.getLauKeySecondPart()) 
				|| genLauDtoNew.getDiasVigencia() == null || genLauDtoNew.getFechaCreacion() == null) {
			// los datos son invalidos
			log.info("lau con datos invalidos {} - {}", genLauDtoNew.getDiasVigencia(), genLauDtoNew.getLauEstado());
			return;
		}
		
		String parValor = "lfp=" + genLauDtoNew.getLauKeyFirstPart() + "&lsp=" + genLauDtoNew.getLauKeySecondPart() + "&ldv=" + genLauDtoNew.getDiasVigencia() + "&lfc="
				+ UtilsDate.stringFromDate(genLauDtoNew.getFechaCreacion(), GeneratorLAU.FECHA_FORMAT_LAU_PROP) + "&lst=" + genLauDtoNew.getLauEstado();

		String parValorEnc = Base64.encodeBase64String(UtilsSec.easeyEncrypt(parValor).getBytes());
		SwfParams swfParamsCODIGOLAU = new SwfParams();
		swfParamsCODIGOLAU.setParDescrip("DATOS CODIGO LAU ANTERIOR");
		swfParamsCODIGOLAU.setParCodpar(Constants.PARAM_CODIGOLAUOLD);
		swfParamsCODIGOLAU.setParValor(parValorEnc);
		log.info("lau anterior registrado {}", parValorEnc);
		swfParamsDao.saveOrUpdate(swfParamsCODIGOLAU);
	}
	
	public void startScheduling(String horajob, String idsched, String cronExpr) {
		log.info("Ejecutando configuration scheduler " + horajob);
		schedulerService.startScheduling(horajob, idsched, cronExpr);
	}

	private String[] inicializaCorreos(String codApp) {
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CORREOSPORAPP + "-" + codApp);
		String correos = swfParams.getParValor();
		log.debug("Preparando mails de mensaje observado " + correos);
		final String[] tokens = StringUtils.split(correos, ",;");
		final ArrayList<String> result = new ArrayList<String>();

		for (int i = 0; i < tokens.length; i++) {
			if (StringUtils.isNotBlank(tokens[i]))
				result.add(tokens[i]);
		}
		return result.toArray(new String[result.size()]);
	}

	private void validaDatosLau(GenLauDto genLauDtoCurrent, GenLauDto genLauDtoNew) {

		if (StringUtils.isBlank(genLauDtoNew.getLauKeyFirstPart()) || StringUtils.isBlank(genLauDtoNew.getLauKeySecondPart())) {
			throw new RuntimeException("Código LAU (primera parte y segunda parte) deben tener un valor.");
		}
		genLauDtoNew.setLauKeyFirstPart(genLauDtoNew.getLauKeyFirstPart().trim());
		genLauDtoNew.setLauKeySecondPart(genLauDtoNew.getLauKeySecondPart().trim());

		if (genLauDtoNew.getLauKeyFirstPart().trim().length() != 16 || genLauDtoNew.getLauKeyFirstPart().trim().length() != 16) {
			log.error("Código Key LAU (FirstPart o SecondPart) debe tener 16 caracteres");
			throw new RuntimeException("Código LAU (primera parte y segunda parte) deben tener 16 caracteres cada uno.");
		}

		if (genLauDtoNew.getDiasVigencia() == null || genLauDtoNew.getDiasVigencia().compareTo(0) < 0) {
			throw new RuntimeException("Días de vigencia inválido.");
		}

		if (genLauDtoNew.getDiasVigencia().compareTo(0) < 0 || genLauDtoNew.getDiasVigencia().compareTo(365) > 0) {
			throw new RuntimeException("Días de vigencia debe estar entre 0 y 365 días.");
		}

		if (isEqualsCodelau(genLauDtoCurrent, genLauDtoNew)) {
			throw new RuntimeException("Código LAU idéntico al actual, genere uno nuevo.");
		}

		GeneradorPassword generadorPassword = new GeneradorPassword(GeneratorLAU.LAU_KEY_LENGTH, true, true, false, true, GeneratorLAU.LAU_KEY_LENGTH_CHARS_REPEAT);
		if (!generadorPassword.validForzePassw(genLauDtoNew.getLauKeyFirstPart())) {
			throw new RuntimeException("Código LAU parte 1 no cumple con los requisitos mínimos.");
		}
		if (!generadorPassword.validForzePassw(genLauDtoNew.getLauKeySecondPart())) {
			throw new RuntimeException("Código LAU parte 2 no cumple con los requisitos mínimos.");
		}

		if (!genLauDtoNew.getLauEstado().equals("NUEVO")) {
			// throw new RuntimeException("Código LAU no generado.");
		}
	}

	public static boolean isEqualsCodelau(GenLauDto genLauDtoCurrent, GenLauDto genLauDtoNew) {
		return genLauDtoCurrent != null && genLauDtoNew != null && genLauDtoCurrent.getLauKeyFirstPart() != null && genLauDtoCurrent.getLauKeySecondPart() != null
				&& genLauDtoNew.getLauKeyFirstPart() != null && genLauDtoNew.getLauKeySecondPart() != null
				&& genLauDtoNew.getLauKeyFirstPart().equals(genLauDtoCurrent.getLauKeyFirstPart())
				&& genLauDtoNew.getLauKeySecondPart().equals(genLauDtoCurrent.getLauKeySecondPart());
	}

	public static boolean isParamEditable(String nameParam) {
		return !(nameParam.equals(Constants.PARAM_CODIGOLAU) || nameParam.equals(Constants.PARAM_PATHDIRSWIFT) || nameParam.equals(Constants.PARAM_PATHDIRSWIFTLAU));
	}
}