//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.05.17 a las 11:37:50 AM BOT 
//


package gob.bcb.lavado.ofac.ue.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the gob.bcb.lavado.ofac.ue.model package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PublicationUrl_QNAME = new QName("http://eu.europa.ec/fpi/fsd/export", "publicationUrl");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: gob.bcb.lavado.ofac.ue.model
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RegulationSummary }
     * 
     */
    public RegulationSummary createRegulationSummary() {
        return new RegulationSummary();
    }

    /**
     * Create an instance of {@link SubjectType }
     * 
     */
    public SubjectType createSubjectType() {
        return new SubjectType();
    }

    /**
     * Create an instance of {@link Regulation }
     * 
     */
    public Regulation createRegulation() {
        return new Regulation();
    }

    /**
     * Create an instance of {@link NameAlias }
     * 
     */
    public NameAlias createNameAlias() {
        return new NameAlias();
    }

    /**
     * Create an instance of {@link Citizenship }
     * 
     */
    public Citizenship createCitizenship() {
        return new Citizenship();
    }

    /**
     * Create an instance of {@link Birthdate }
     * 
     */
    public Birthdate createBirthdate() {
        return new Birthdate();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link SanctionEntity }
     * 
     */
    public SanctionEntity createSanctionEntity() {
        return new SanctionEntity();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://eu.europa.ec/fpi/fsd/export", name = "publicationUrl")
    public JAXBElement<String> createPublicationUrl(String value) {
        return new JAXBElement<String>(_PublicationUrl_QNAME, String.class, null, value);
    }

}
