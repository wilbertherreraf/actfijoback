package gob.bcb.lavado.repository;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.prowidesoftware.swift.model.BIC;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfBics;

//@Transactional
@Repository("swfBicsDao")
public class SwfBicsDaoImpl implements SwfBicsDao {
	private static final Logger log = LoggerFactory.getLogger(SwfBicsDaoImpl.class);

	private EntityManager entityManager;

	@Autowired
	@Qualifier("entityManagerFactory")
	private EntityManagerFactory entityManagerFactory;

	public SwfBics findByBicBranch(String bicCodbic, String bicCodbranch) {
		if (bicCodbranch != null && NumberUtils.isNumber(bicCodbranch.trim())) {
			bicCodbranch = String.format("%03d", Integer.valueOf(bicCodbranch.trim()));
		}
		return findByCodBicBranch(bicCodbic, bicCodbranch);
	}

	@Transactional(readOnly = true)
	public SwfBics findByCodBicBranch(String bicCodbic, String bicCodbranch) {
		String jpql = "SELECT t FROM SwfBics t WHERE t.id.bicCodbic = :bicCodbic ";
		jpql = jpql.concat("and t.id.bicCodbranch = :bicCodbranch ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("bicCodbic", bicCodbic);
		query.setParameter("bicCodbranch", bicCodbranch);
		List lista = query.getResultList();

		if (lista.size() > 0) {
			return (SwfBics) lista.get(0);
		}
		return null;
	}

	@Transactional(readOnly = true)
	public SwfBics findByBIC8(String bicCodbic) {
		if (StringUtils.isBlank(bicCodbic)) {
			return null;
		}
		BIC bic = new BIC(bicCodbic);

		String bicCod = null;
		String bicCodbranch = "XXX";
		if (bic.getBic8() != null)
			bicCod = bic.getBic8();
		if (bic.getBranch() != null)
			bicCodbranch = bic.getBranch();
		return findByBicBranch(bicCod, bicCodbranch);
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public SwfBics saveOrUpdate(SwfBics swfBics) {
		swfBics = entityManager.merge(swfBics);
		return swfBics;
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public SwfBics actualizar(SwfBics swfBics) {
		if (swfBics.getId() == null || StringUtils.isBlank(swfBics.getId().getBicCodbic()) || StringUtils.isBlank(swfBics.getId().getBicCodbranch())) {
			throw new SwiftAdminException("Valor codigo bic invalido");
		}
		swfBics.getId().setBicCodbranch(swfBics.getId().getBicCodbranch().trim());
		String bic = swfBics.getId().getBicCodbic();
		String branch = swfBics.getId().getBicCodbranch();
		String newbranch = swfBics.getId().getBicCodbranch();
		boolean actualizaBic = false;
		if (swfBics.getId().getBicCodbranch() != null && NumberUtils.isNumber(swfBics.getId().getBicCodbranch().trim())) {
			actualizaBic = swfBics.getId().getBicCodbranch().trim().length() != 3;
			newbranch = String.format("%03d", Integer.valueOf(swfBics.getId().getBicCodbranch().trim()));
		}

		if (newbranch.trim().length() != 3) {
			throw new SwiftAdminException("Longitud código Branch debe ser 3");
		}

		if (StringUtils.isBlank(swfBics.getBicDescrip())) {
			throw new SwiftAdminException("Descripción inválida");
		}

		SwfBics swfBicsOld = findByCodBicBranch(bic, newbranch);

		try {
			swfBics.setBicDescrip(UtilsGeneric.convertStringToEncode(swfBics.getBicDescrip(), Constants.ENCODING_ISO));
			swfBics.setBicDirecc1(UtilsGeneric.convertStringToEncode(swfBics.getBicDirecc1(), Constants.ENCODING_ISO));			
			swfBics.setBicDirecc2(UtilsGeneric.convertStringToEncode(swfBics.getBicDirecc2(), Constants.ENCODING_ISO));			
			swfBics.setBicPais(UtilsGeneric.convertStringToEncode(swfBics.getBicPais(), Constants.ENCODING_ISO));			
			swfBics.setBicCiudad(UtilsGeneric.convertStringToEncode(swfBics.getBicCiudad(), Constants.ENCODING_ISO));			
		} catch (UnsupportedEncodingException e) {
		}
		if (swfBicsOld == null) {
			swfBics.getId().setBicCodbranch(newbranch);
			entityManager.persist(swfBics);
			if (actualizaBic) {
				// se corrige el branch
				log.info("Actualizando BIC con branch no standard {} {} ", bic, branch);
				swfBicsOld = findByCodBicBranch(bic, branch);
				if (swfBicsOld != null) {
					eliminar(bic, branch);
				}
			}
			swfBics = findByCodBicBranch(bic, newbranch);
		} else {
			entityManager.merge(swfBics);
			swfBics = findByCodBicBranch(bic, newbranch);
		}

		log.info("Bics actualizado " + swfBics.getId().getBicCodbic() + swfBics.getId().getBicCodbranch() + " " + swfBics.getBicDescrip());
		return swfBics;
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void eliminar(String bicCodbic, String bicCodbranch) {
		SwfBics swfBicsOld = findByCodBicBranch(bicCodbic, bicCodbranch);
		if (swfBicsOld != null) {
			log.info("Eliminado BIC " + swfBicsOld.getId().getBicCodbic() + swfBicsOld.getId().getBicCodbranch());
			entityManager.remove(swfBicsOld);
			return;
		}
		throw new RuntimeException("Banco inexistente " + bicCodbic + " - " + bicCodbranch);
	}

	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
}
