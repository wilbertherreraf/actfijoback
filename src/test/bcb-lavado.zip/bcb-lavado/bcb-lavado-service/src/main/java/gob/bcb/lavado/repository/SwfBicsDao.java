package gob.bcb.lavado.repository;

import java.util.List;

import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfParams;

public interface SwfBicsDao {

	SwfBics findByBicBranch(String bicCodbic, String bicCodbranch);

	SwfBics findByBIC8(String bicCodbic);

	SwfBics actualizar(SwfBics swfBics);

	void eliminar(String bicCodbic, String bicCodbranch);

	SwfBics findByCodBicBranch(String bicCodbic, String bicCodbranch);
}
