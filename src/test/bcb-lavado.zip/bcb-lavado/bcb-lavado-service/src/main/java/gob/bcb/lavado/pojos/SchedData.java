package gob.bcb.lavado.pojos;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchedData{
	private final Logger log = LoggerFactory.getLogger(SchedData.class);
	private String idScheduler;	
	private String hora;
	private String minuto;
	private String segundo;
	private String cronExp;
	public SchedData() {

	}
	public SchedData(String hora, String minuto) {
		this.hora = hora;
		this.minuto = minuto;
	}		
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}
	public String getMinuto() {
		return minuto;
	}
	public void setMinuto(String minuto) {
		this.minuto = minuto;
	}
	public String cronExpresion(){
		hora = StringUtils.trimToEmpty(hora);
		minuto = StringUtils.trimToEmpty(minuto);
		segundo = StringUtils.trimToEmpty(segundo);
		if (StringUtils.isBlank(segundo) || !isValidTime(segundo))
			segundo = "0";
		if (!isValidTime(hora) || !isValidTime(minuto))
			return "";
		
		//String cronExpr = "0 " + minuto + " " + hora + " ? * 2-6";
		String cronExpr = cronExp.replace("ss", segundo);
		cronExpr = cronExpr.replace("mm", minuto);
		cronExpr = cronExpr.replace("hh", hora);
		log.debug("Expresion [" +cronExp+ "] => " + cronExpr);
		return cronExpr;
	}
	public String getCronExp() {
		return cronExp;
	}
	public void setCronExp(String cronExp) {
		this.cronExp = cronExp;
	}
	public String getSegundo() {
		return segundo;
	}
	public void setSegundo(String segundo) {
		this.segundo = segundo;
	}
	private boolean isValidTime(String time){
		if (StringUtils.isEmpty(time) || !NumberUtils.isNumber(time))
			return false;
		return true;
	}
	public String getIdScheduler() {
		return idScheduler;
	}
	public void setIdScheduler(String idScheduler) {
		this.idScheduler = idScheduler;
	}
}
