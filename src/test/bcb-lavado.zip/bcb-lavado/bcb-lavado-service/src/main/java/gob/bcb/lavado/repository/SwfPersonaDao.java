package gob.bcb.lavado.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import gob.bcb.lavado.model.SwfPersona;

public interface SwfPersonaDao {

	SwfPersona findByCodigo(Integer perCodemp);

	SwfPersona saveorupdate(SwfPersona swfPersona);

	void remove(Integer perCodemp, String codUsuario, String estacion);
	List<SwfPersona> empleadosAsignados(Integer resCodemp, Integer estRevision, Integer menGestion);

	List<SwfPersona> getAll();

	List<SwfPersona> empleadosCreadosEnLvd();

	SwfPersona findOrCreateSwfPersonaFromRRHH(Integer codEmpleado, String email, String login, String estacion);


	Optional<SwfPersona> findByTokenVerifica(String perIdverifica);
	Optional<SwfPersona> findByTokenVerifica(Integer perCodemp, String perIdverifica);
	void closeSession(Integer nroCodemp);
	
	void cambiarEstado(Integer perCodemp, Integer statreg, String codUsuario, String estacion);

	Optional<SwfPersona> findByCodEmail(Integer perCodemp);
}
