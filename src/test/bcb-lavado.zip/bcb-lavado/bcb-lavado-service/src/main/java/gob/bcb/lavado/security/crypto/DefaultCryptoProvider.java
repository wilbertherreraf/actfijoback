package gob.bcb.lavado.security.crypto;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this class tries to load key-store file, and load the keys from it. if file
 * does not exist, it creates it, creates the keys and stores it. if file exists
 * but one or more keys are missing - it creates the keys and stores to the
 * file.
 * 
 * if this jar is deplyed on GAE, for example, where files cannot be stored - we
 * have a flag for these cases, so this class will not try to store the
 * key-store file, but will work in-mem.
 * 
 * @author OhadR
 *
 */
public class DefaultCryptoProvider implements CryptoProvider {
	private static final Logger log = LoggerFactory.getLogger(DefaultCryptoProvider.class);

	private static final String SYMMETRIC_ALGORITHM = "AES/ECB/PKCS5Padding";
	private static final int SYMMETRIC_KEY_LENGTH = 128; // 128 bit (16 bytes)

	public static final String KEYSTORE_TYPE = "JCEKS";
	private static final String Algorithm = "AES"; // AES DESede
	private final KeyStore keyStore;
	private final Map<KeyHive, Key> keys;

	public DefaultCryptoProvider(String keystoreFile, String keystorePassword, boolean createFileIfNotExist) {
		try {
			log.info("Using keystore " + keystoreFile + " createFileIfNotExist " + createFileIfNotExist);			
			keys = new HashMap<KeyHive, Key>();

			keyStore = KeyStore.getInstance(KEYSTORE_TYPE);
			loadMasterKeys(keystoreFile, keystorePassword, createFileIfNotExist);
		} catch (Exception e) {
			throw new CryptoException("Failed initializing keystore from file " + keystoreFile, e);
		}
	}

	/**
	 * loads the keys from file. if file does not exist, it creates it, creates
	 * the keys and stores it. if file exists but one or more keys are missing -
	 * it creates the keys and stores to the file.
	 * 
	 * @param fileName
	 * @param password
	 * @param createFileIfNotExist
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws CertificateException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void loadMasterKeys(String fileName, String password, boolean createFileIfNotExist)
			throws NoSuchAlgorithmException, KeyStoreException, CertificateException, FileNotFoundException, IOException {
		boolean keystoreModified = false;
		KeyGenerator keyGen = null;
		try {
			keyStore.load(new FileInputStream(fileName), password.toCharArray());
		} catch (FileNotFoundException e) {
			if (!createFileIfNotExist) {
				throw new CryptoException("Archivo keystore inexistente " + fileName, e);
			}
			log.warn("Keystore file does not exist; Will try to create a new one in: " + fileName);
			keyStore.load(null, null);
		}

		// Load Symmetric keys
		for (KeyHive hive : KeyHive.values()) {
			Key key = null;
			String keyAlias = "WatchDox_" + hive.toString();
			char[] keyPassword = (password + "__" + keyAlias).toCharArray();
			try {
				key = keyStore.getKey(keyAlias, keyPassword);
			} catch (UnrecoverableKeyException e) {
				// This key does not exist; Will be created by the next if
				// statement
				log.warn("key not exist, this be created...");
			}
			if (key == null) {
				if (keyGen == null) {
					keyGen = KeyGenerator.getInstance(Algorithm);
					keyGen.init(SYMMETRIC_KEY_LENGTH);
				}
				log.info("Creating NEW symmetric key: " + keyAlias);
				key = keyGen.generateKey();
				keyStore.setKeyEntry(keyAlias, key, keyPassword, null);
				keystoreModified = true;
			} else {
				log.debug("Loaded symmetric key: " + keyAlias);
			}
			keys.put(hive, key);
		}

		if (keystoreModified && createFileIfNotExist) {
			// We loaded some keys, we need to update the keystore
			keyStore.store(new FileOutputStream(fileName), password.toCharArray());
			log.info("file keyStore created: " + fileName);
		}

	}

	public Key getKey(ImmutablePair<KeyHive, String> keyParams) {
		Key masterKey = keys.get(keyParams.getLeft());

		return masterKey;
	}

	public Cipher getCipher(Key key, int cryptMode) throws InvalidKeyException {
		Cipher cipher = null;
		try {
			if (key.getEncoded().length > 16) {
				cipher = Cipher.getInstance(SYMMETRIC_ALGORITHM);
			} else {
				cipher = Cipher.getInstance(Algorithm);
			}
		} catch (GeneralSecurityException e) {
			throw new CryptoException("Cipher creation failed", e);
		}

		cipher.init(cryptMode, key);

		return cipher;
	}
}
