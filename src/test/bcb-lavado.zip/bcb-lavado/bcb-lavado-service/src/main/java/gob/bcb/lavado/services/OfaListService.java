package gob.bcb.lavado.services;

import java.util.List;

import org.apache.commons.lang3.tuple.ImmutablePair;

import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.ofac.dto.OfacListas;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry;

public interface OfaListService {

	void cargarListaOfac(String fileSdn, Integer nrolote);

	void truncateTablesOfac(String codUsuario, String estacion) throws Throwable;

	void loadListsFromDirectory(String codusuario, String estacion) throws Exception;

	void saveLista(List<ImmutablePair<OfaSdnentry, OfacListas>> ofaSdnentryList);

	List<ImmutablePair<Integer, List<OfaSdnentry>>> filterSdnEntryNoRegistrados(List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableList);

}