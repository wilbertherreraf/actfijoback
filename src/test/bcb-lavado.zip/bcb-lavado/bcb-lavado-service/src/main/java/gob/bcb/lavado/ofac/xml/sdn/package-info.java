@javax.xml.bind.annotation.XmlSchema(namespace = "http://tempuri.org/sdnList.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package gob.bcb.lavado.ofac.xml.sdn;
