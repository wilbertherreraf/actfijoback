package gob.bcb.lavado.pojos;
 
import java.io.Serializable;

public class Empleado implements Serializable{
	private Integer nroEmpleado;
	private String codUnidadOrg;
	private String codUnidadProg;
	private String DescUnidadOrg;
	private String nombre;
	private String email;
	private String prefunidadorgs;	
	private Integer nroEmpleadopadre;
	private Integer estadoRevision;
	private String estadoRevisionDesc;	
	
	public Empleado(){
		
	}
	public Integer getNroEmpleado() {
		return nroEmpleado;
	}
	public void setNroEmpleado(Integer nroEmpleado) {
		this.nroEmpleado = nroEmpleado;
	}
	public String getCodUnidadOrg() {
		return codUnidadOrg;
	}
	public void setCodUnidadOrg(String codUnidadOrg) {
		this.codUnidadOrg = codUnidadOrg;
	}
	public String getCodUnidadProg() {
		return codUnidadProg;
	}
	public void setCodUnidadProg(String codUnidadProg) {
		this.codUnidadProg = codUnidadProg;
	}
	public String getDescUnidadOrg() {
		return DescUnidadOrg;
	}
	public void setDescUnidadOrg(String descUnidadOrg) {
		DescUnidadOrg = descUnidadOrg;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPrefunidadorgs() {
		return prefunidadorgs;
	}
	public void setPrefunidadorgs(String prefunidadorgs) {
		this.prefunidadorgs = prefunidadorgs;
	}
	public Integer getNroEmpleadopadre() {
		return nroEmpleadopadre;
	}
	public void setNroEmpleadopadre(Integer nroEmpleadopadre) {
		this.nroEmpleadopadre = nroEmpleadopadre;
	}
	public Integer getEstadoRevision() {
		return estadoRevision;
	}
	public void setEstadoRevision(Integer estadoRevision) {
		this.estadoRevision = estadoRevision;
	}
	public String getEstadoRevisionDesc() {
		return estadoRevisionDesc;
	}
	public void setEstadoRevisionDesc(String estadoRevisionDesc) {
		this.estadoRevisionDesc = estadoRevisionDesc;
	}
}
