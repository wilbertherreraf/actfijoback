package gob.bcb.lavado.repository;

import java.util.List;

import gob.bcb.lavado.model.GenDesctabla;

public interface GenDesctablaDao {

	List<GenDesctabla> findByDesCodtab(Integer desCodtab);

	GenDesctabla findByDesCodtab(Integer desCodtab, Integer desCodigo);

}
