package gob.bcb.lavado.search.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.QueryMatch;

public class SearchResultOfac extends QueryMatch {
	private static final Logger log = LoggerFactory.getLogger(SearchResultOfac.class);
	private Object documentMatch;
	private OfacQuery ofacQuery;
	protected final Map<String, MatchHolder<OfacQuery>> matches = new HashMap<>();

	private static class MatchHolder<T> {
		Map<String, T> matches = new HashMap<>();
	}

	private Float score;

	public SearchResultOfac(String queryId, String docId) {
		super(queryId, docId);
		this.score = 0.0f;
	}

	public SearchResultOfac(String queryId, String docId, Float score) {
		super(queryId, docId);
		this.score = score;
	}

	public Float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public Object getDocumentMatch() {
		return documentMatch;
	}

	public void setDocumentMatch(Object documentMatch) {
		this.documentMatch = documentMatch;
	}

	public OfacQuery getOfacQuery() {
		return ofacQuery;
	}

	public void setOfacQuery(OfacQuery ofacQuery) {
		this.ofacQuery = ofacQuery;
	}

	public void addMatch(String queryId, String field, OfacQuery match) {
		MatchHolder<OfacQuery> docMatches = matches.get(field);

		if (docMatches == null) {
			docMatches = new MatchHolder<>();
			matches.put(field, docMatches);
		}

		if (docMatches.matches.containsKey(queryId)) {
			docMatches.matches.put(queryId, (match.getScore() < docMatches.matches.get(queryId).getScore() ? docMatches.matches.get(queryId) : match));
		} else {
			docMatches.matches.put(queryId, match);
		}
	}

	public Map<String, OfacQuery> matches(String field) {
		MatchHolder<OfacQuery> docMatches = matches.get(field);
		if (docMatches == null)
			return null;
		return docMatches.matches;
	}

	public List<OfacQuery> getMatches(String field) {
		MatchHolder<OfacQuery> docMatches = matches.get(field);
		if (docMatches == null)
			return null;
		List<OfacQuery> results = new ArrayList<>();
		docMatches.matches.values().forEach(o -> {
			results.add(o);
		});
		return results;
	}

	public OfacQuery matches(String field, String queryId) {
		MatchHolder<OfacQuery> docMatches = matches.get(field);
		if (docMatches == null)
			return null;
		return docMatches.matches.get(queryId);
	}

	public List<OfacQuery> getMatches() {
		List<OfacQuery> results = new ArrayList<>();
		for (MatchHolder<OfacQuery> searchResultOfac : matches.values()) {
			for (OfacQuery searchResult : searchResultOfac.matches.values()) {
				results.add(searchResult);
			}
		}
		return results;
	}

	public boolean isValidFields() {
		int actualFields = matches.size() - ofacQuery.getFieldQuery().getValidatorStrategy().getExpectedFields();
		return (matches.size() > 0 && actualFields >= 0);
	}

	public boolean isValidTerms() {
		boolean validTerms = true;
		for (String field : matches.keySet()) {
			Map<String, OfacQuery> matchesOfacQuery = matches(field);
			for (OfacQuery ofacQuery : matchesOfacQuery.values()) {
				validTerms = ofacQuery.isValidTerms(ofacQuery.getFieldQuery().getValidatorStrategy().getExpectedMatches());
				if (!validTerms){
					return false;
				}
			}
		}
		return validTerms;
	}
	
	public boolean isValid(){
		//return isValidFields() && isValidTerms();
		return isValidTerms();
	}
	
	
}
