package gob.bcb.lavado.search;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.queryparser.classic.QueryParser.Operator;
import org.apache.lucene.search.BooleanClause;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.strategy.ValidatorStrategy;

public class FieldQuery extends QueryMatch {
	public static final float BOOST_DEFAULT = 1.0f;
	public static final int DISTANCEUPTO_DEFAULT = 0;

	private String id;
	private String idStrategy;	
	private String field;
	private String queryTemplate;
	private String typeQ;	
	private float boost = BOOST_DEFAULT;
	private Operator operator = Operator.OR;
	private BooleanClause.Occur junction = BooleanClause.Occur.SHOULD; 
	/**
	 * distancia entre palabras que existen (cambios entre palabras) ej kitten
	 * and sitting = 3 1 kitten -> sitten (substitution of s for k) 2 sitten ->
	 * sittin (substitution of i for e) 3 sittin -> sitting (insert g at the
	 * end)
	 */
	private int distanceUpTo = DISTANCEUPTO_DEFAULT;
	/**
	 * cantidad de term que seran evaluadas
	 */
	private int prefixLength = 0;

	private int minShingleSize = 2;
	
	/**
	 * cantidad minima de letras permitas para considerarla en los tokens
	 */
	private int minWordLen = 2;
	/**
	 * maximo numero de shingles normalmente deberia de ser el mismo al
	 * maxShingleStop
	 */

	private int maxShingleSize = 8;
	private int maxShingleStop = 0;	
	private boolean exceptNumbers = false;
	private int slop = 0;
	private boolean inOrder = true;
	private Integer maxResults;
	private int minMatchesRequired = 0;

	private Class<?> clazz;
	private Analyzer analyzer;
	private ValidatorStrategy validatorStrategy;

//	protected FieldQuery() {
//	}
//
	protected FieldQuery(String id, String field, Class<?> clazz, Analyzer analyzer) {
		super(id,field);
		this.id = id;
		this.field = field;
		this.clazz = clazz;
		this.analyzer = analyzer;
		validatorStrategy = new ValidatorStrategy(1, true);
	}

	public String getId() {
		return id;
	}

	public String getField() {
		return field;
	}

	public String getQueryTemplate() {
		return queryTemplate;
	}

	public void setQueryTemplate(String queryTemplate) {
		this.queryTemplate = queryTemplate;
	}

	public int getMinShingleSize() {
		return minShingleSize;
	}

	public void setMinShingleSize(int minShingleSize) {
		this.minShingleSize = minShingleSize;
	}

	public int getMaxShingleSize() {
		return maxShingleSize;
	}

	public void setMaxShingleSize(int maxShingleSize) {
		this.maxShingleSize = maxShingleSize;
	}

	public boolean isExceptNumbers() {
		return exceptNumbers;
	}

	public void setExceptNumbers(boolean exceptNumbers) {
		this.exceptNumbers = exceptNumbers;
	}

	public int getSlop() {
		return slop;
	}

	public void setSlop(int slop) {
		this.slop = slop;
	}

	public boolean isInOrder() {
		return inOrder;
	}

	public void setInOrder(boolean inOrder) {
		this.inOrder = inOrder;
	}

	public int getDistanceUpTo() {
		return distanceUpTo;
	}

	public void setDistanceUpTo(int distanceUpTo) {
		this.distanceUpTo = distanceUpTo;
	}

	public int getPrefixLength() {
		return prefixLength;
	}

	public void setPrefixLength(int prefixLength) {
		this.prefixLength = prefixLength;
	}

	public float getBoost() {
		return boost;
	}

	public void setBoost(float boost) {
		this.boost = boost;
	}

	public int getMaxShingleStop() {
		return maxShingleStop;
	}

	public void setMaxShingleStop(int maxShingleStop) {
		this.maxShingleStop = maxShingleStop;
	}

	public Integer getMaxResults() {
		return maxResults;
	}

	public void setMaxResults(Integer maxResults) {
		this.maxResults = maxResults;
	}

	public int getMinMatchesRequired() {
		return minMatchesRequired;
	}

	public void setMinMatchesRequired(int minMatchesRequired) {
		this.minMatchesRequired = minMatchesRequired;
	}

	public static Builder builder(String id) {
		return new Builder(id);
	}

	public Class<?> getClazz() {
		return clazz;
	}

	public Analyzer getAnalyzer() {
		return analyzer;
	}

	private void setAnalyzer(Analyzer analyzer) {
		this.analyzer = analyzer;
	}

	public static class Builder {
		private final String id;
		private final FieldQuery fieldQuery;
		private final Map<String, FieldQuery> fieldsQuery = new HashMap<>();

		/**
		 * Create a new Builder for an InputDocument with the given id
		 * 
		 * @param id
		 *            the id of the InputDocument
		 */
		public Builder(String id) {
			fieldQuery = new FieldQuery(id, "", null, null);
			this.id = id;
		}

		public Builder addField(String field, Analyzer analyzer) {
			//checkFieldName(field);
			fieldQuery.field = field;
			fieldQuery.analyzer = analyzer;
			return this;
		}

		public Builder addQueryTemplate(String queryTemplate) {
			fieldQuery.queryTemplate = queryTemplate;
			return this;
		}

		public Builder addBoost(float boost) {
			fieldQuery.setBoost(boost);
			return this;
		}

		public Builder addOcurrencies(int minMatchesRequired) {
			fieldQuery.setMinMatchesRequired(minMatchesRequired);
			return this;
		}

		public Builder addFuzzy(int distanceUpTo, int prefixLength) {
			fieldQuery.setDistanceUpTo(distanceUpTo);
			fieldQuery.setPrefixLength(prefixLength);
			return this;
		}

		public Builder addPhrase(int minShingleSize, int maxShingleStop, int maxShingleSize, boolean exceptNumbers) {
			fieldQuery.setMinShingleSize(minShingleSize);
			fieldQuery.setMaxShingleStop(maxShingleStop);
			fieldQuery.setMaxShingleSize(maxShingleSize);
			fieldQuery.setExceptNumbers(exceptNumbers);
			return this;
		}

		public Builder addSpanPhrase(int slop, boolean inOrder) {
			fieldQuery.setSlop(slop);
			fieldQuery.setInOrder(inOrder);
			return this;
		}

		public Builder addClazz(Class<?> clazz) {
			fieldQuery.clazz = clazz;
			return this;
		}

		public FieldQuery build() {
			FieldQuery fieldQuery = new FieldQuery(id, this.fieldQuery.getField(), this.fieldQuery.getClazz(), this.fieldQuery.getAnalyzer());
			fieldQuery.setMinShingleSize(this.fieldQuery.getMinShingleSize());
			fieldQuery.setMaxShingleStop(this.fieldQuery.getMaxShingleStop());
			fieldQuery.setMaxShingleSize(this.fieldQuery.getMaxShingleSize());
			fieldQuery.setDistanceUpTo(this.fieldQuery.getDistanceUpTo());
			fieldQuery.setPrefixLength(this.fieldQuery.getPrefixLength());
			fieldQuery.setExceptNumbers(this.fieldQuery.isExceptNumbers());
			fieldQuery.setBoost(this.fieldQuery.getBoost());
			fieldQuery.setQueryTemplate(this.fieldQuery.getQueryTemplate());
			fieldQuery.setSlop(this.fieldQuery.getSlop());
			fieldQuery.setInOrder(this.fieldQuery.isInOrder());

			return fieldQuery;
		}
	}

	private static void checkFieldName0(String fieldName) {
		Optional<String> field = OfacIndexer.fieldsAllfields.stream().filter(s -> s.equals(fieldName)).findFirst();
		if (!field.isPresent())
			throw new IllegalArgumentException(fieldName + " no es un campo valido");
	}

	public ValidatorStrategy getValidatorStrategy() {
		return validatorStrategy;
	}

	public void setValidatorStrategy(ValidatorStrategy validatorStrategy) {
		this.validatorStrategy = validatorStrategy;
	}

	public Operator getOperator() {
		return operator;
	}

	public void setOperator(Operator operator) {
		this.operator = operator;
	}

	public BooleanClause.Occur getJunction() {
		return junction;
	}

	public void setJunction(BooleanClause.Occur junction) {
		this.junction = junction;
	}

	public String getIdStrategy() {
		return idStrategy;
	}

	public void setIdStrategy(String idStrategy) {
		this.idStrategy = idStrategy;
	}

	public int getMinWordLen() {
		return minWordLen;
	}

	public void setMinWordLen(int minWordLen) {
		this.minWordLen = minWordLen;
	}

	public String getTypeQ() {
		return typeQ;
	}

	public void setTypeQ(String typeQ) {
		this.typeQ = typeQ;
	}
	
}
