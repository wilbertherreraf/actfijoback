package gob.bcb.lavado.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;

import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.commons.ArchivoSinpleServiceImpl;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.model.OfaAddresslist;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaCitizenship;
import gob.bcb.lavado.model.OfaDateofbirth;
import gob.bcb.lavado.model.OfaIdlist;
import gob.bcb.lavado.model.OfaNationality;
import gob.bcb.lavado.model.OfaPlaceofbirth;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.ofac.OfacLoader;
import gob.bcb.lavado.ofac.dto.OfacListas;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry;
import gob.bcb.lavado.repository.OfaAddresslistRepository;
import gob.bcb.lavado.repository.OfaAkalistRepository;
import gob.bcb.lavado.repository.OfaCitizenshipRepository;
import gob.bcb.lavado.repository.OfaDateofbirthRepository;
import gob.bcb.lavado.repository.OfaIdlistRepository;
import gob.bcb.lavado.repository.OfaNationalityRepository;
import gob.bcb.lavado.repository.OfaPlaceofbirthRepository;
import gob.bcb.lavado.repository.OfaSdnentryRepository;
import gob.bcb.lavado.repository.OfaVesselinfoRepository;
import gob.bcb.lavado.repository.SwfLoteDao;
import gob.bcb.lavado.repository.SwfParamsDao;

@Service(value = "ofaListService")
// @Transactional
public class OfaListServiceImpl implements OfaListService {
	private static final Logger log = LoggerFactory.getLogger(OfaListServiceImpl.class);
	@Autowired
	private OfaAkalistRepository ofaAkalistRepository;

	@Autowired
	private OfaIdlistRepository ofaIdlistRepository;

	@Autowired
	private OfaNationalityRepository ofaNationalityRepository;

	@Autowired
	private OfaAddresslistRepository ofaAddresslistRepository;

	@Autowired
	private OfaCitizenshipRepository ofaCitizenshipRepository;

	@Autowired
	private OfaVesselinfoRepository ofaVesselinfoRepository;

	@Autowired
	private OfaDateofbirthRepository ofaDateofbirthRepository;

	@Autowired
	private OfaPlaceofbirthRepository ofaPlaceofbirthRepository;

	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private AppProperties appProperties;
	@Autowired
	private SwfLoteDao swfLoteDao;
	@Autowired
	@Qualifier("dataSourceSwift")
	protected DataSource dataSourceSwift;
	@Autowired
	private OfaSdnentryRepository ofaSdnentryRepository;

	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;

	@Autowired
	@Qualifier("entityManagerFactory")
	private EntityManagerFactory entityManagerFactory;

	@PostConstruct
	public void init() {
		log.info("PostConstruct........");
	}

	private SwfLote crearSwfLoteOfac(String pathFileSource, String codusuario, String estacion) {
		log.info("pathFileSource " + pathFileSource);

		String nameFileOriginal = ArchivoUtil.getOriginalFilename(pathFileSource);
		ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
		archivoSinpleService.fromPathfile(pathFileSource, nameFileOriginal);
		archivoSinpleService.getArchivoSinple().setDirectory(appProperties.getLavado().getAppdir() + "/" + Constants.DIR_OFAC_FILES_TMP);

		SwfLote swfLoteNew = swfLoteDao.guardarLoteOfac(codusuario, archivoSinpleService.getArchivoSinple(), false, estacion);
		return swfLoteNew;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void saveLista(List<ImmutablePair<OfaSdnentry, OfacListas>> ofaSdnentryList) {

		if (ofaSdnentryList == null || ofaSdnentryList.size() == 0) {
			return;
		}

		log.info("{} [{}] saveLista inicio...>>> con {} regs", ofaSdnentryList.get(0).right.getPosition() , Thread.currentThread().getName(), ofaSdnentryList.size());
		int nosaveds = 0;
		for (ImmutablePair<OfaSdnentry, OfacListas> ofaSdnentry : ofaSdnentryList) {
			OfacListas ofacListas = ofaSdnentry.right;
			boolean salvado = false;
			Integer sdnId = null;
			try {
				//ofaSdnentry.left.setSdnNrolote(ofacListas.getPosition());
				OfaSdnentry ofaSdnNew = ofaSdnentryRepository.saveAndFlush(ofaSdnentry.left);
				nosaveds++;
				sdnId = ofaSdnNew.getSdnId();
				salvado = true;				
			} catch (Exception e) {
				log.error(nosaveds + "==> Error al guardar (sleeping ...) " + ofaSdnentry.left.getSdnEntryuid() + " : " + e.getMessage());
				log.error(nosaveds + "==> Error {} {} {}", ofaSdnentry.right.getListaOfaAkalist().size(), ofaSdnentry.left.getSdnLastname(), ofaSdnentry.left.getSdnRemarks());
				try {
					Thread.sleep(500);
					OfaSdnentry ofaSdnNew = ofaSdnentryRepository.saveAndFlush(ofaSdnentry.left);
					sdnId = ofaSdnNew.getSdnId();
					salvado = true;
					nosaveds++;
				} catch (Exception e1) {
					// throw new RuntimeException(e);
					log.error(nosaveds + "==> Error al guardar (2do intento) idxml: " + ofaSdnentry.left.getSdnEntryuid() + " : " + e1.getMessage());
				}
			}

			if (!salvado) {
				continue;
			}

			if (ofacListas.getListaOfaDateofbirth() != null && ofacListas.getListaOfaDateofbirth().size() > 0) {
				for (OfaDateofbirth ofac : ofacListas.getListaOfaDateofbirth()) {
					ofac.setBirEntryuid(sdnId);
				}
//				ofaDateofbirthRepository.save(ofacListas.getListaOfaDateofbirth());
			}
			if (ofacListas.getListaOfaAddresslist() != null && ofacListas.getListaOfaAddresslist().size() > 0) {
				for (OfaAddresslist ofac : ofacListas.getListaOfaAddresslist()) {
					ofac.setAdrEntryuid(sdnId);
				}
//				ofaAddresslistRepository.save(ofacListas.getListaOfaAddresslist());
			}

			if (ofacListas.getListaOfaNationality() != null && ofacListas.getListaOfaNationality().size() > 0) {
				for (OfaNationality ofac : ofacListas.getListaOfaNationality()) {
					ofac.setNatEntryuid(sdnId);
				}
//				ofaNationalityRepository.save(ofacListas.getListaOfaNationality());
			}

			if (ofacListas.getListaOfaCitizenship() != null && ofacListas.getListaOfaCitizenship().size() > 0) {
				for (OfaCitizenship ofac : ofacListas.getListaOfaCitizenship()) {
					ofac.setCitEntryuid(sdnId);
				}
//				ofaCitizenshipRepository.save(ofacListas.getListaOfaCitizenship());
			}

			if (ofacListas.getListaOfaPlaceofbirth() != null && ofacListas.getListaOfaPlaceofbirth().size() > 0) {
				for (OfaPlaceofbirth ofac : ofacListas.getListaOfaPlaceofbirth()) {
					ofac.setPobEntryuid(sdnId);
				}
//				ofaPlaceofbirthRepository.save(ofacListas.getListaOfaPlaceofbirth());
			}

			if (ofacListas.getListaOfaIdlist() != null && ofacListas.getListaOfaIdlist().size() > 0) {
				for (OfaIdlist ofac : ofacListas.getListaOfaIdlist()) {
					ofac.setIdlEntryuid(sdnId);
				}
//				ofaIdlistRepository.save(ofacListas.getListaOfaIdlist());
			}

			if (ofacListas.getListaOfaAkalist() != null && ofacListas.getListaOfaAkalist().size() > 0) {
				for (OfaAkalist ofac : ofacListas.getListaOfaAkalist()) {
					ofac.setAkaEntryuid(sdnId);
				}
//				ofaAkalistRepository.save(ofacListas.getListaOfaAkalist());
			}

			salvarHijos(ofacListas);
			
//			if (ofacListas.getOfaVesselinfo() != null) {
//				ofacListas.getOfaVesselinfo().setVesEntryuid(sdnId);
//				ofaVesselinfoRepository.save(ofacListas.getOfaVesselinfo());
//			}
		}
		log.info("{} [{}] saveLista Fin...>>> con {}/{} regs", ofaSdnentryList.get(0).right.getPosition() , Thread.currentThread().getName(), nosaveds, ofaSdnentryList.size());
	}

	private void salvarHijos(OfacListas ofacListas) {
		if (ofacListas.getListaOfaDateofbirth() != null && ofacListas.getListaOfaDateofbirth().size() > 0) {
			ofaDateofbirthRepository.save(ofacListas.getListaOfaDateofbirth());
		}
		if (ofacListas.getListaOfaAddresslist() != null && ofacListas.getListaOfaAddresslist().size() > 0) {
			ofaAddresslistRepository.save(ofacListas.getListaOfaAddresslist());
		}

		if (ofacListas.getListaOfaNationality() != null && ofacListas.getListaOfaNationality().size() > 0) {
			ofaNationalityRepository.save(ofacListas.getListaOfaNationality());
		}

		if (ofacListas.getListaOfaCitizenship() != null && ofacListas.getListaOfaCitizenship().size() > 0) {
			ofaCitizenshipRepository.save(ofacListas.getListaOfaCitizenship());
		}

		if (ofacListas.getListaOfaPlaceofbirth() != null && ofacListas.getListaOfaPlaceofbirth().size() > 0) {
			ofaPlaceofbirthRepository.save(ofacListas.getListaOfaPlaceofbirth());
		}

		if (ofacListas.getListaOfaIdlist() != null && ofacListas.getListaOfaIdlist().size() > 0) {
			ofaIdlistRepository.save(ofacListas.getListaOfaIdlist());
		}

		if (ofacListas.getListaOfaAkalist() != null && ofacListas.getListaOfaAkalist().size() > 0) {
			ofaAkalistRepository.save(ofacListas.getListaOfaAkalist());
		}		
	}
	
	public void truncateTablesOfac(String codUsuario, String estacion) throws Throwable {
		log.info("truncateTablesOfac codUsuario {}, estacion {}", codUsuario, estacion);
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_TRUNCATEOFAC);
		boolean truncarTables = false;
		// verificamos que el parametro este habilitado para truncar
		if (swfParams != null) {
			String tipoProceso = swfParams.getParValor();
			truncarTables = (tipoProceso != null && tipoProceso.trim().toUpperCase().equals("S"));
		}
		if (!truncarTables) {
			throw new Exception("Proceso requiere que el parametro " + Constants.PARAM_TRUNCATEOFAC + " tenga valor 'S', cambie el valor para continuar");
		}
		log.info("##### Truncando tablas por codUsuario: " + codUsuario + " #####" + " " + estacion);
		truncateTablesOfac();
	}

	public List<ImmutablePair<Integer, List<OfaSdnentry>>> filterSdnEntryNoRegistrados(List<ImmutablePair<Integer, List<OfaSdnentry>>> immutableList) {
		List<ImmutablePair<Integer, List<OfaSdnentry>>> list = new ArrayList<>();

		for (ImmutablePair<Integer, List<OfaSdnentry>> inmu : immutableList) {
			ImmutablePair<Integer, List<OfaSdnentry>> itemlist = new ImmutablePair<Integer, List<OfaSdnentry>>(inmu.left, new ArrayList<>());

			List<OfaSdnentry> entryNotE = filterNotExists(inmu.right);
			itemlist.right.addAll(entryNotE);
			list.add(itemlist);
		}
		return list;
	}

	public Optional<OfaSdnentry> findOfaSdnentryIDLista(Integer entryUid, String idLista) {
		if (entryUid == null || idLista == null)
			return Optional.empty();

		List<OfaSdnentry> result = ofaSdnentryRepository.findBySdnEntryuidAndSdnIdlista(entryUid, idLista);
		return result.size() > 0 ? Optional.of(result.get(0)) : Optional.empty();
	}

	public List<OfaSdnentry> filterNotExists(List<OfaSdnentry> entryList) {
		List<OfaSdnentry> entryNotE = new ArrayList<>();

		for (OfaSdnentry ofaSdnentry : entryList) {
			Optional<OfaSdnentry> ofaSdnentryOpt = findOfaSdnentryIDLista(ofaSdnentry.getSdnEntryuid(), ofaSdnentry.getSdnIdlista());
			if (!ofaSdnentryOpt.isPresent()) {
				entryNotE.add(ofaSdnentry);
			}
		}
		return entryNotE;
	}

	/************************************************/
	
	public void loadListsFromDirectory(String codusuario, String estacion) throws Exception {
		String inputDirectory = appProperties.getLavado().getAppdir() + "/" + Constants.DIR_OFAC_FILES_DESCARGA;
		log.info("Inicio cargado de archivo desde " + inputDirectory);
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_TIPPROCOFAC);
		// determina si se guarda los registros si el archivo existe
		boolean continueIfExist = false;
		if (swfParams != null) {
			String tipoProceso = swfParams.getParValor();
			continueIfExist = (tipoProceso != null && tipoProceso.trim().toUpperCase().equals("S"));
		}

		loadListsFromDirectory(inputDirectory, continueIfExist, codusuario, estacion);
		log.info("Archivos guardados de directorio " + inputDirectory);

	}

	private int loadListsFromDirectory(String inputDirectory, boolean continueIfExist, String codusuario, String estacion) throws Exception {
		String dirFileDest = appProperties.getLavado().getAppdir() + "/" + Constants.DIR_OFAC_FILES;
		log.info("Cpy archivos de: {} a: {}", inputDirectory, dirFileDest);
		int count = 0;
		for (Path filePath : Files.newDirectoryStream(FileSystems.getDefault().getPath(inputDirectory))) {
			File f = filePath.toFile();
			if (f.isDirectory()) {
				continue;
			}
			String nameFile = f.getName();
			File fDest = new File(dirFileDest, nameFile);
			if (fDest.exists() && !fDest.isDirectory()) {
				if (!continueIfExist) {
					log.info("Archivo OFAC existente {}", nameFile);
					// continue;
				}
			}

			String pathFileSource = f.getAbsolutePath();
			String content;
			try (FileInputStream fis = new FileInputStream(f); InputStreamReader reader = new InputStreamReader(fis, Charsets.UTF_8)) {
				content = CharStreams.toString(reader);
				String contentFile = UtilsGeneric.getShortText(content, 188);
				if (contentFile.toLowerCase().contains("<sdnlist")) {
					log.info("CPY: Archivo SDN XML " + pathFileSource + " ==> " + contentFile);
					SwfLote swfLoteNew = crearSwfLoteOfac(pathFileSource, codusuario, estacion);
					cargarListaOfac(pathFileSource, swfLoteNew.getLotNrolote());
					count++;
				}
			}

			String p = UtilsFile.copiarArchivo(pathFileSource, fDest.getAbsolutePath(), false);
			log.info("Proceso TMP: Archivo ofac!!! en " + p);
		}
		if (count == 0) {
			throw new RuntimeException(
					"No se procesÃ³ ningÃºn archivo desde el directorio " + inputDirectory + " verifique la existencia de archivos con formato XML");
		}
		return count;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.lavado.services.OfaListService#cargarListaOfac(java.lang.
	 * String)
	 */
	@Transactional
	public void cargarListaOfac(String fileSdn, Integer nrolote) {
		log.info("Inicio carga lista OFAC desde " + fileSdn + " nrolote: " + nrolote);
		long startTime = System.currentTimeMillis();
		try {
			Integer regs = OfacLoader.readFileToOfaSdnentry(fileSdn, nrolote);
			log.info("Done[lote : " + nrolote + " ] cargarListaOfac[regs: " + regs + "] at (" + (System.currentTimeMillis() - startTime) + " ms.)");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (Throwable e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		log.info("committing...");
	}
	
	
	
	
	private void truncateTablesOfac() throws Throwable {

		try (final Connection connection = dataSourceSwift.getConnection(); final Statement statement = connection.createStatement();) {

			log.info("truncate tables ofacs Catalog: " + connection.getCatalog() + " isClosed: " + connection.isClosed());
			statement.executeUpdate("truncate ofa_addresslist;");
			statement.executeUpdate("truncate ofa_akalist;");
			statement.executeUpdate("truncate ofa_citizenship;");
			statement.executeUpdate("truncate ofa_dateofbirth;");
			statement.executeUpdate("truncate ofa_idlist;");
			statement.executeUpdate("truncate ofa_nationality;");
			statement.executeUpdate("truncate ofa_placeofbirth;");
			statement.executeUpdate("truncate ofa_publshinform;");
			statement.executeUpdate("truncate ofa_vesselinfo;");
			statement.executeUpdate("truncate ofa_sdnentry;");
			// connection.close();
		}
		log.info("Tablas ofacs TRUNCADAS!!!!!");
	}
	
}
