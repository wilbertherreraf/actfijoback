package gob.bcb.lavado.search.indexer;

import org.hibernate.CacheMode;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.jpa.FullTextEntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class MassIndexer {
	private static final Logger log = LoggerFactory.getLogger(MassIndexer.class);

	public void init(FullTextEntityManager fullTextEntityManager, List<Class> entidades) throws InterruptedException {
		long startTime = System.currentTimeMillis();
		
		for (Class entidade : entidades) {
			massiveIndexer(entidade, fullTextEntityManager);
			fullTextEntityManager.flush();
		}
		
		long endTime = System.currentTimeMillis();
		log.info("En indexOfaSdnentry...hecho. (" + (endTime - startTime) + " ms.)");		
	}

	private void massiveIndexer(Class clazz, FullTextEntityManager fullTextEntityManager) throws InterruptedException {
		log.info("indexing.class " + clazz.getSimpleName());

		org.hibernate.search.MassIndexer indexer = fullTextEntityManager.createIndexer(clazz).batchSizeToLoadObjects(25).cacheMode(CacheMode.NORMAL)
				.threadsToLoadObjects(5).idFetchSize(Integer.MIN_VALUE);
		try {
			indexer.startAndWait();
		} catch (InterruptedException e) {
			log.error(e.getMessage(), e);
			throw e;
		}
	}
}
