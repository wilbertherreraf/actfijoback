package gob.bcb.lavado.repository;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.QL.rrhh.PlafinQLBean;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.pojos.Empleado;

@Repository("swfPersonaDao")
@Transactional
public class SwfPersonaDaoImpl implements SwfPersonaDao {
	private static final Logger log = LoggerFactory.getLogger(SwfPersonaDaoImpl.class);
	public static final Integer MIN_COD_PERSONA = 50000;
	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;

	@Autowired
	private PlafinQLBean plafinQLBean;
	
	@Autowired
	@Qualifier("entityManagerFactory")	
	private EntityManagerFactory entityManagerFactory;

	public SwfPersona findByCodigo(Integer perCodemp) {
		if (perCodemp == null)
			return null;
		String jpql = "SELECT t FROM SwfPersona t WHERE t.perCodemp = :perCodemp ";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("perCodemp", perCodemp);
		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfPersona) lista.get(0);
		}
		return null;

	}
	
	public List<SwfPersona> getAll(){
		String jpql = "SELECT t FROM SwfPersona t ";
		Query query = entityManager.createQuery(jpql);

		List lista = query.getResultList();
		return lista;
	}
	public List<SwfPersona> empleadosAsignados(Integer resCodemp, Integer estRevision, Integer menGestion) {
		// areas con las que trabaja el empleado

		String jpql = "SELECT distinct p FROM SwfPersona p, SwfAsignamensaje t ";
		jpql = jpql.concat("where p.perCodemp = t.id.resCodemp ");
		jpql = jpql.concat("and t.id.resCodemp != t.resCodemppadre ");		
		jpql = jpql.concat("and t.resCodemppadre = :resCodemp ");
		
		if (estRevision != null) {
			jpql = jpql.concat("and t.resEstrevision = :estRevision ");
		}
		
		if (menGestion != null) {
			jpql = jpql.concat("and exists(select 1 ");
			jpql = jpql.concat("FROM SwfMensaje m ");
			jpql = jpql.concat("WHERE m.menCodmen = t.id.resCodmen ");		
			jpql = jpql.concat("and m.menGestion >= :menGestion) ");
		}
		
		Query query = entityManager.createQuery(jpql);

		if (estRevision != null) {
			query.setParameter("estRevision", estRevision);
		}
		query.setParameter("resCodemp", resCodemp);

		if (menGestion != null) {
			query.setParameter("menGestion", menGestion);
		}
		List lista = query.getResultList();
		return lista;
	}
	public List<SwfPersona> empleadosCreadosEnLvd() {
		// areas con las que trabaja el empleado

		String jpql = "SELECT p FROM SwfPersona p ";
		jpql = jpql.concat("where p.perCodemp > :perCodemp ");
		
		Query query = entityManager.createQuery(jpql);
		
		query.setParameter("perCodemp", MIN_COD_PERSONA);
		
		return query.getResultList();
	}
	
	public Optional<SwfPersona> findByCodEmail(Integer perCodemp) {
		if (perCodemp == null )
			return Optional.empty();
		
		
		String jpql = "SELECT t FROM SwfPersona t ";
		jpql = jpql.concat("WHERE t.perCodemp = :perCodemp ");
//		jpql = jpql.concat("and t.perEmail = :perEmail ");
		jpql = jpql.concat("and t.perStatreg = :perStatreg ");
		
		Query query = entityManager.createQuery(jpql);
		query.setParameter("perCodemp", perCodemp);
//		query.setParameter("perEmail", perEmail);
		query.setParameter("perStatreg", Constants.TAB_STATREG_VIG);
		
		List lista = query.getResultList();
		if (lista.size() > 0) {
			return Optional.of((SwfPersona) lista.get(0));
		}
		return Optional.empty();

	}	
	
	/**
	 * @param perIdverifica
	 * @return
	 */
	public Optional<SwfPersona> findByTokenVerifica(String perIdverifica) {
		if (StringUtils.isBlank(perIdverifica))
			return Optional.empty();

		String jpql = "SELECT t FROM SwfPersona t WHERE t.perIdverifica = :perIdverifica ";
		
		Query query = entityManager.createQuery(jpql);
		query.setParameter("perIdverifica", perIdverifica);
		
		List lista = query.getResultList();
		if (lista.size() == 1) {
			return Optional.of((SwfPersona) lista.get(0));
		}
		return Optional.empty();
	}

	public Optional<SwfPersona> findByTokenVerifica(Integer perCodemp, String perIdverifica) {
		if (StringUtils.isBlank(perIdverifica))
			return Optional.empty();

		String jpql = "SELECT t FROM SwfPersona t WHERE t.perIdverifica = :perIdverifica ";
		jpql = jpql.concat("and t.perCodemp = :perCodemp ");
		
		Query query = entityManager.createQuery(jpql);
		query.setParameter("perIdverifica", perIdverifica);
		query.setParameter("perCodemp", perCodemp);
		
		List lista = query.getResultList();
		if (lista.size() == 1) {
			return Optional.of((SwfPersona) lista.get(0));
		}
		return Optional.empty();
	}

	public SwfPersona saveorupdate(SwfPersona swfPersona){

		if (StringUtils.isBlank(swfPersona.getPerNombre()))
			throw new DataException("Nombre de persona inválido " + swfPersona.getPerCodemp());
//		if (StringUtils.isBlank(swfPersona.getPerEmail()))
//			throw new DataException("Correo de persona inválido");
		
		SwfPersona swfPersonaOld = findByCodigo(swfPersona.getPerCodemp());		
		if (swfPersonaOld == null){
			if (swfPersona.getPerCodemp() == null || swfPersona.getPerCodemp().compareTo(0)<=0){
				Integer codigo = newCodigo();
				swfPersona.setPerCodemp(codigo);				
			}
			swfPersona.setPerAuditfho(new Date());
			swfPersona.setPerTabstatreg(Constants.TAB_STATREG);
			swfPersona.setPerStatreg(Constants.TAB_STATREG_VIG);
			
			try {
				swfPersona.setPerNombre(UtilsGeneric.convertStringToEncode(swfPersona.getPerNombre(), Constants.ENCODING_ISO));
			} catch (UnsupportedEncodingException e) {
			}
			swfPersona.setPerEmail(!StringUtils.isBlank(swfPersona.getPerEmail()) ? swfPersona.getPerEmail().trim().toLowerCase() : null);
			
			entityManager.persist(swfPersona);
			log.info("Creando nueva persona " + swfPersona.toString());
			return findByCodigo(swfPersona.getPerCodemp());			
		} else {
			swfPersona.setPerEmail(!StringUtils.isBlank(swfPersona.getPerEmail()) ? swfPersona.getPerEmail().trim().toLowerCase() : null);
			entityManager.merge(swfPersona);
			log.info("Actualizando persona " + swfPersona.toString());
			return findByCodigo(swfPersona.getPerCodemp());			
		}
 
	}
	
	public void remove(Integer perCodemp, String codUsuario, String estacion){
		cambiarEstado(perCodemp, Constants.TAB_STATREG_SUSP, codUsuario, estacion);
	}

	public void cambiarEstado(Integer perCodemp, Integer statreg, String codUsuario, String estacion){
		SwfPersona swfPersonaOld = findByCodigo(perCodemp);
		if (swfPersonaOld != null){
			swfPersonaOld.setPerAuditusr(codUsuario);
			swfPersonaOld.setPerAuditwst(estacion);
			swfPersonaOld.setPerAuditfho(new Date());
			swfPersonaOld.setPerStatreg(statreg);
			entityManager.merge(swfPersonaOld);
			log.info("Persona cambia estado " + swfPersonaOld.toString());
			//entityManager.remove(swfPersonaOld);
		}
	}

	public SwfPersona findOrCreateSwfPersonaFromRRHH(Integer codEmpleado, String email, String login, String estacion){
		
		SwfPersona swfPersona = findByCodigo(codEmpleado);
		if (swfPersona == null){
			swfPersona = new SwfPersona();			
			Empleado empleado = plafinQLBean.findEmpleado(codEmpleado, true);
			if (empleado != null){
				swfPersona.setPerCodemp(empleado.getNroEmpleado());
				swfPersona.setPerNombre(empleado.getNombre());
				swfPersona.setPerArecod(empleado.getCodUnidadOrg());
				if (!StringUtils.isBlank(empleado.getEmail()) && empleado.getEmail().trim().toLowerCase().contains("bcb.gob.bo"))
					swfPersona.setPerEmail(empleado.getEmail());
			} else {
				swfPersona.setPerCodemp(codEmpleado);
				swfPersona.setPerNombre("NN: " + String.valueOf(codEmpleado));
			}
			swfPersona.setPerEmail(!StringUtils.isBlank(swfPersona.getPerEmail()) ? swfPersona.getPerEmail().trim().toLowerCase() : null);
			swfPersona.setPerTabstatreg(Constants.TAB_STATREG);
			swfPersona.setPerStatreg(Constants.TAB_STATREG_VIG);
			swfPersona.setPerAuditusr(login);
			swfPersona.setPerAuditwst(estacion);

			swfPersona = saveorupdate(swfPersona);			
			log.info("Registro de nueva persona en BD swift " + swfPersona.getPerCodemp());
		} else {
			if (StringUtils.isBlank(swfPersona.getPerArecod())) {
				Empleado empleado = plafinQLBean.findEmpleado(codEmpleado, true);
				if (empleado != null){
					swfPersona.setPerArecod(empleado.getCodUnidadOrg());
					swfPersona.setPerAuditusr(login);
					swfPersona.setPerAuditwst(estacion);
					
					swfPersona.setPerTabstatreg(Constants.TAB_STATREG);
					swfPersona.setPerStatreg(Constants.TAB_STATREG_VIG);
					
					if (StringUtils.isBlank(swfPersona.getPerEmail())){
						if (!StringUtils.isBlank(empleado.getEmail()) && empleado.getEmail().trim().toLowerCase().contains("bcb.gob.bo"))
							swfPersona.setPerEmail(empleado.getEmail());
					}
					swfPersona.setPerEmail(!StringUtils.isBlank(swfPersona.getPerEmail()) ? swfPersona.getPerEmail().trim().toLowerCase() : null);
					swfPersona = saveorupdate(swfPersona);					
				}
			}
		}
		
		return swfPersona;
	}
	
	public void closeSession(Integer perCodemp) {
		StringBuilder jpql = new StringBuilder("update SwfPersona t ");
		jpql.append("set t.perIdverifica = null ");
		jpql.append("WHERE t.perCodemp = :perCodemp ");

		Query query = entityManager.createQuery(jpql.toString());
		query.setParameter("perCodemp", perCodemp);
		
		Integer result = query.executeUpdate();
		log.info("Session invalidada {} regs: {} ", perCodemp, result);
	}
	
	private Integer newCodigo(){
		//crea un codigo para una persona nueva
		StringBuilder jsql = new StringBuilder();
		jsql.append("select max(l.perCodemp) ");
		jsql.append("from SwfPersona l ");
		jsql.append("where  l.perCodemp > :perCodemp ");
		
		Query query = entityManager.createQuery(jsql.toString());
		query.setParameter("perCodemp", MIN_COD_PERSONA);
		
		List result = query.getResultList();
		if (result.size() > 0) {
			Integer maximo = (Integer) result.get(0);
			return (maximo == null ? MIN_COD_PERSONA + 1 : ++maximo);
		}

		return MIN_COD_PERSONA + 1;		
	}
}
