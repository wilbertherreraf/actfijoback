package gob.bcb.lavado.repository;

import java.util.Date;
import java.util.List;

import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.pojos.Asignacion;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.MensajesDatos;

public interface SwfAsignamensajeDao {

	List<SwfAsignamensaje> byCodigoEmpleado(Integer resCodemp);

	SwfAsignamensaje byCodigo(Integer resCodmen, Integer resCodemp);

	SwfAsignamensaje saveOrUpdate(Integer codMensaje, Integer nroEmpleado, Integer resCodemppadre, SwfAsignamensaje swfAsignamensaje,
			Integer estRevision);

	SwfAsignamensaje crearAsignacion(SwfMensaje swfMensaje, Integer resCodemp, Integer resCodemppadre, String resArecod, Integer estRevision, String login, String estacion);

	List<String> areasPorEmpEstado(Integer resCodemp, Integer estRevision);

	SwfAsignamensaje updateReg(SwfAsignamensaje swfAsignamensaje);

	void eliminarAsignacion(Integer codmen, Integer codemp, Integer codemppadre);

	List<SwfAsignamensaje> findAsignacionesPorCodmen(Integer resCodmen);

	List<Asignacion> asignar(Integer menCodmen, Integer resCodemppadre, String codusuario, String estacion);

	void procesar(Integer codmen, Integer codemp, String codusuario, String estacion);

	SwfAsignamensaje rechazarAsignacion(Integer codmen, Integer codemp, String codusuario, String estacion);

	void habilitar(Integer codmen, Integer codemp, Integer newEstRevision, String codusuario, String estacion);

	List<MensajesDatos> buscarMensajesAsignados(Integer codmen, Integer resCodemp, Integer resCodempasig, Integer resCodempUsuario, Integer estRevision, Integer estMensaje,
			Date conFecinicio, Date conFecfin);

	void eliminarPersona(Integer codemp, String codUsuario, String estacion);

}
