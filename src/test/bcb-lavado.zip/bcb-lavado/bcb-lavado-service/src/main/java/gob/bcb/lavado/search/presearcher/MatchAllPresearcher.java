package gob.bcb.lavado.search.presearcher;

import static java.util.stream.Collectors.toList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.CandidateMatcher;
import gob.bcb.lavado.search.DocumentBatch;
import gob.bcb.lavado.search.DocumentMatches;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.MatchError;
import gob.bcb.lavado.search.MatcherFactory;
import gob.bcb.lavado.search.Matches;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.Presearcher;
import gob.bcb.lavado.search.QueryMatch;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.facet.FacetQueryOfac;
import gob.bcb.lavado.search.indexer.JPASearchFactoryController;

import org.apache.lucene.queryparser.classic.QueryParser.Operator;

public class MatchAllPresearcher {
	private static final Logger log = LoggerFactory.getLogger(MatchAllPresearcher.class);
	private static final int commitBatchSize = 5000;
	protected long slowLogLimit = 2000000;

	private final FacetQueryOfac facetQueryOfac;
	private final Presearcher presearcher;
	private final JPASearchFactoryController jPASearchFactoryController;
	private final FieldQuery fieldQueryDefault;
	private CandidateMatcher<?> actualMatcher;

	public MatchAllPresearcher(JPASearchFactoryController jPASearchFactoryController, Presearcher presearcher, FieldQuery fieldQueryDefault) {
		this.jPASearchFactoryController = jPASearchFactoryController;
		this.facetQueryOfac = new FacetQueryOfac(this.jPASearchFactoryController);
		this.presearcher = presearcher;
		this.fieldQueryDefault = fieldQueryDefault;
	}

	public void addFieldQuery(String query, List<FieldQuery> fieldQueryLista) {
		log.debug("addFieldQuery Query : " + query + " load queries List<FieldQuery>.size() " + fieldQueryLista.size());
		List<OfacQuery> updates = new LinkedList<>();

		for (FieldQuery fieldQuery : fieldQueryLista) {
			List<OfacQuery> ofacQueryLista = presearcher.buildQuery(query, fieldQuery);
			ofacQueryLista.forEach(ofacQuery -> updates.add(ofacQuery));

			if (updates.size() > commitBatchSize) {
				facetQueryOfac.commit(updates);
				updates.clear();
			}
		}
		facetQueryOfac.commit(updates);
	}

	public void addFieldQuery(String query, FieldQuery fieldQuery){
		addFieldQuery(query, Arrays.asList(fieldQuery));
	}

	public void addFieldQuery(String query){
		addFieldQuery(query, fieldQueryDefault);
	}

	public <T extends QueryMatch> DocumentBatch<T> match(String query, DocumentBatch<T> docs, MatcherFactory<T> factory) throws IOException {
		CandidateMatcher<T> matcher = factory.createMatcher(docs, facetQueryOfac);
		matcher.adjustComponent(null);
//		log.info("Match with class: " + matcher.getClass().getSimpleName());
		actualMatcher = matcher;
		long buildTime = System.nanoTime();		
		StandardQueryCollector<T> collector = new StandardQueryCollector<>(matcher);
		for (T doc : docs) {
			SearchResultOfac searchResultOfac = (SearchResultOfac) doc;
			collector.matchQuery(query, searchResultOfac, null);			
		}
		buildTime = System.nanoTime() - buildTime;		
		matcher.finish(buildTime, collector.queryCount);
		return collector.getMatchesR();
	}

	public <T extends QueryMatch> DocumentBatch<T> match(DocumentBatch<T> docs, MatcherFactory<T> factory) throws IOException {
		StandardQueryCollector<T> collector = (StandardQueryCollector<T>) matchCollector(docs, factory);
		return collector.getMatchesR();
	}

	private <T extends QueryMatch> FacetQueryOfac.QueryCollector matchCollector(DocumentBatch<T> docs, MatcherFactory<T> factory) throws IOException {
		CandidateMatcher<T> matcher = factory.createMatcher(docs, facetQueryOfac);
		matcher.adjustComponent(null);
		return match(matcher);
	}

	private <T extends QueryMatch> FacetQueryOfac.QueryCollector match(CandidateMatcher<T> matcher) throws IOException {
//		log.info("Match with class: " + matcher.getClass().getSimpleName());
		actualMatcher = matcher;
		StandardQueryCollector<T> collector = new StandardQueryCollector<>(matcher);
		long buildTime = facetQueryOfac.search(new PresearcherQueryBuilder("", presearcher, (CandidateMatcher<SearchResultOfac>) matcher), collector);
		matcher.finish(buildTime, collector.queryCount);
		return collector;
	}

	public <T extends QueryMatch> DocumentBatch<T> validate(DocumentBatch<T> documents) throws IOException {
		DocumentBatch<T> results = new DocumentBatch<>();
		if (documents == null) {
			return results;
		}

		for (T queryMatch : documents) {
			SearchResultOfac searchResultOfac = (SearchResultOfac) queryMatch;
			if (searchResultOfac.isValid()) {
				results.add((T) searchResultOfac);
			}
		}
		return results;
	}

	public <T extends QueryMatch> boolean continueSearch(DocumentBatch<T> matches, DocumentBatch<T> valids) throws IOException {
		if (matches == null || matches.getBatchSize() == 0) {
			return false;
		}
		int countMatches = matches.getBatchSize();
		int countValids = valids.getBatchSize();

		boolean found = (countMatches > 0) && (countValids > 0) && (countMatches >= countValids);
//		log.info("ContinueSearch? [" + presearcher.getClass().getSimpleName() + "] found: " + found + " countMatches: " + countMatches + " countValids: "
//				+ countValids + " {" + fieldQueryDefault.getOperator().toString() + "}");
		
		boolean continueSearch = true;		
		if (found){
			// verificamos si es OR o AND
			if (fieldQueryDefault.getOperator().compareTo(Operator.OR) == 0){
				continueSearch = true;
			} else {
				continueSearch = !found;
			}
		}else{
			continueSearch = !found;			
		}
		return continueSearch;
	}

	private class StandardQueryCollector<T extends QueryMatch> implements FacetQueryOfac.QueryCollector {

		final CandidateMatcher<T> matcher;
		int queryCount = 0;
		public final Map<String, StringBuilder> matchingTerms = new HashMap<>();

		private StandardQueryCollector(CandidateMatcher<T> matcher) {
			this.matcher = matcher;
		}

		public PresearcherMatches<T> getMatches() {
			return new PresearcherMatches<>(matchingTerms, matcher.getMatches());
		}

		public DocumentBatch<T> getMatchesR() {
			DocumentBatch<T> a = new DocumentBatch<>();
			for (DocumentMatches<T> docMatches : matcher.getMatchesUnique()) {
				for (T match : docMatches) {
					a.add(match);
				}
			}
			return a;
		}

		@Override
		public void matchQuery(String id, SearchResultOfac searchResultOfac, Map result) {
			if (!matchingTerms.containsKey(id))
				matchingTerms.put(id, new StringBuilder());
			
			if (searchResultOfac != null){
//				matchingTerms.get(id).append(" ").append(searchResultOfac.getOfacQuery().getField()).append(":")
//				.append(searchResultOfac.getOfacQuery().getQuery());
				queryCount++;				
			}
			
			try {
				matcher.matchQuery(id, (T) searchResultOfac, null);
			} catch (Exception e) {
				matcher.reportError(new MatchError(id, e));
			}
		}
		
		@Override
		public Matches<SearchResultOfac> matches() {
			return (Matches<SearchResultOfac>) matcher.getMatches();
		}

		@Override
		public void removeMatches() {
			matcher.clearMatches();
		}
	}

	private class PresearcherQueryBuilder implements FacetQueryOfac.QueryBuilder {
		final Presearcher presearcher;
		final String query;
		final CandidateMatcher<SearchResultOfac> matcher;

		private PresearcherQueryBuilder(String query, Presearcher presearcher, CandidateMatcher<SearchResultOfac> matcher) {
			this.presearcher = presearcher;
			this.query = query;
			this.matcher = matcher;

		}

		@Override
		public List<OfacQuery> buildQuery(FieldQuery fieldQuery) throws IOException {
			addFieldQuery("", fieldQuery);
			// matcher.adjustComponent(match);

			OfacQuery ofacQueryNew = new OfacQuery(fieldQuery.getId(), fieldQuery.getId(), "", null);
			ofacQueryNew.setFieldQuery(fieldQuery);
			SearchResultOfac searchResultOfac = new SearchResultOfac(ofacQueryNew.getQueryId(), "");
			searchResultOfac.setOfacQuery(ofacQueryNew);

			List<SearchResultOfac> searchResultOfacList = matcher.adjustComponent(searchResultOfac);

			if (searchResultOfacList != null) {
				List<OfacQuery> ofacQueryL = searchResultOfacList.stream().map(SearchResultOfac::getOfacQuery).collect(toList());
				return ofacQueryL;
			}
			return presearcher.buildQuery(query, fieldQuery);
		}

		@Override
		public List<OfacQuery> buildQuery(List<FieldQuery> fieldQuery) throws IOException {
			List<OfacQuery> ofacQueryL = new ArrayList<>();
			for (FieldQuery fieldQuery2 : fieldQuery) {
				ofacQueryL.addAll(buildQuery(fieldQuery2));
			}
			return ofacQueryL;
		}
	}

}
