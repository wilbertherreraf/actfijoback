package gob.bcb.lavado.rest;

import java.io.File;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.search.indexer.JPASearchFactoryControllerImpl;
import gob.bcb.lavado.search.indexer.JPASearchFactoryHolder;
import gob.bcb.lavado.services.ReporteSwiftService;
import gob.bcb.lavado.services.SwiftBcbSearcherService;
import gob.bcb.lavado.strategy.StrategyBase;
import gob.bcb.swift.pojos.SwiftDatos;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(Constants.PATH_RESOURCE_API_LVD)
//@Api(tags = { "SwiftMensajes" })
public class LvdSwiftsResource {
	private final Logger log = LoggerFactory.getLogger(LvdSwiftsResource.class);

	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;
	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private AppProperties appProperties;
	@Autowired
	private ReporteSwiftService reporteSwiftService;
	@Autowired
	private JPASearchFactoryHolder jPASearchFactoryHolder;
	private final MediaType pdfMediaType = MediaType.parseMediaType("application/pdf");

	/**
	 * SEARCH /_search/scan-field?query=:query&field=:field : search for swift
	 * in the text plain corresponding to the query.
	 * 
	 * @param query
	 *            texto a buscar
	 * @param fieldSwift
	 *            codigo de consulta
	 * @return
	 */
	@RequestMapping(value = "/search/swifts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, params = { "query", "inOut", "idquery",
			"estverif", "fromDate", "toDate" })
	//@ApiOperation(value = "Consulta de búsqueda de mensajes swift registrados segun los criterios")
	public ResponseEntity<List<SwfMensaje>> searchScanSwifts(@RequestParam(value = "query") String query, @RequestParam(value = "inOut") String inOut,
			@RequestParam(value = "idquery") String idquery, @RequestParam(value = "estverif") Integer estverif,
			@RequestParam(value = "fromDate") String fromDate, @RequestParam(value = "toDate") String toDate, Pageable pageable) {

		Date tDate = StringUtils.isBlank(toDate) ? new Date() : UtilsDate.dateFromString(toDate, "yyyy-MM-dd");
		Date fDate = StringUtils.isBlank(fromDate) ? UtilsDate.addTime(tDate, -1, 5) : UtilsDate.dateFromString(fromDate, "yyyy-MM-dd");
		
		List<SwfMensaje> result = searchSwfMensajes(query, inOut, idquery, estverif, fDate, tDate, pageable);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@RequestMapping(value = "/search/strategies", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Retorna los codigo de strategias disponibles para búsquedas")
	public ResponseEntity<List<String>> getStrategies() {
		log.info("REST request to list de strategies");
		List<String> result = getStrategiesLvd();
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@RequestMapping(value = "/fromplano", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, params = { "query" })
	//@ApiOperation(value = "Desparsea un mensaje swift en formato plano y retorna un objeto", response = SwfMensaje.class)
	public ResponseEntity<SwfMensaje> desparsearSwiftPlano(@RequestParam(value = "query") String query) {
		log.info("REST request to desparsearSwiftPlano");
		log.debug("searchScanSwifts query {} ", query);
		SwiftDatos swiftDatos;
		SwfMensaje swfMensaje = null;
		try {
			swiftDatos = swiftBcbSearcherService.mensajePlanoToSwfMensaje(query, true);
			swfMensaje = swiftDatos.getSwfMensaje();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return Optional.ofNullable(swfMensaje).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY));

	}

	@RequestMapping(value = "/report/swift-plano", method = RequestMethod.GET, params = { "swifttext" })
	//@ApiOperation(value = "Retorna el reporte en formato pdf de un mensaje swift plano", response = byte[].class)
	HttpEntity<byte[]> reportSwiftPlano(@RequestParam(value = "swifttext") String menPlano) {
		ArchivoSinple archivoSinplePDF = null;
		try {
			archivoSinplePDF = reporteSwiftService.generarReportePDFFromPlano(menPlano, "codUsuario", null);
			log.info("reportSwift reporte PDF generado " + archivoSinplePDF.getNameOriginal());
		} catch (Exception e) {
			log.error("Error al geernar reporte pdf: " + e.getMessage(), e);
		}

		return Optional.ofNullable(archivoSinplePDF).map(archivoSinple -> {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(this.pdfMediaType);
			return new ResponseEntity<>(archivoSinple.getData(), httpHeaders, HttpStatus.OK);
		}).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	public List<String> getStrategiesLvd() {
		File DIR_QUERIES_DIRECTORY = new File(appProperties.getLavado().getAppdir(), Constants.DIR_QUERIES);
		List<String> result = new ArrayList<>();
		try {
			StrategyBase strategyBase = StrategyBase.getInstance().initialize(DIR_QUERIES_DIRECTORY.getAbsolutePath());
			return strategyBase.getListStrategies();

		} catch (Exception e) {
			return result;
		}

	}

	public List<SwfMensaje> searchSwfMensajes(String query, String inOut, String idquery, Integer estverif, Date fDate, Date tDate, Pageable pageable) {
		if (idquery == null || idquery.trim().isEmpty()) {
			idquery = appProperties.getLavado().getSearch().getIdEstrategiaplano();
		}

		log.info("searchSwfMensajes query {} inOut {} field {} fromDate {} toDate {}", query, inOut, idquery, fDate, tDate);
		SwfMensaje swfMensaje = new SwfMensaje();
		swfMensaje.setMenInout(inOut);
		swfMensaje.setMenEstverifica(estverif);

		List<SwfMensaje> result = new ArrayList<>();

		List<SwfMensaje> swfMensajeLista = swfMensajeDao.buscarMensajesEntrantes(swfMensaje, null, null, null, fDate, tDate);
		if (swfMensajeLista.size() > 0){
			if (swfMensajeLista.size() > Constants.SEARCH_LIMIT_REGS){
				swfMensajeLista = swfMensajeLista.subList(0, Constants.SEARCH_LIMIT_REGS);
			}
		}
		if (query == null || query.trim().isEmpty()) {
			result = swfMensajeLista;
		} else {
			JPASearchFactoryControllerImpl jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());			
			for (SwfMensaje swfMensaje2 : swfMensajeLista) {
				try {
					String resp = swiftBcbSearcherService.searchForQueryInSwfMensaje(query, swfMensaje2, idquery, jPASearchFactoryController);
					if (resp != null) {
						result.add(swfMensaje2);
					}
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}
			}
			jPASearchFactoryController.close();
		}
		log.info("found: " + result.size() + " recs for searchScanSwifts query {} inOut{} field{} fromDate {} toDate {}", query, inOut, idquery, fDate,
				tDate);
		return result;
	}
}
