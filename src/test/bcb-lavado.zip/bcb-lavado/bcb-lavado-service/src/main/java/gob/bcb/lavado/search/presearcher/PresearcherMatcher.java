package gob.bcb.lavado.search.presearcher;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.search.CandidateMatcher;
import gob.bcb.lavado.search.DocumentBatch;
import gob.bcb.lavado.search.MatcherFactory;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.facet.FacetQueryOfac;

public class PresearcherMatcher extends CandidateMatcher<SearchResultOfac> {
	private final Logger log = LoggerFactory.getLogger(PresearcherMatcher.class);
	private final FacetQueryOfac facetQueryOfac;
	public final Map<String, StringBuilder> matchingTerms = new HashMap<>();

	public PresearcherMatcher(DocumentBatch<?> batch, FacetQueryOfac facetQueryOfac) {
		super(batch);
		this.facetQueryOfac = facetQueryOfac;
	}

	@Override
	protected void doMatchQuery(String queryId, SearchResultOfac matchQuery, Map<String, String> metadata) throws IOException {
		if (matchQuery == null)
			return;
		SearchResultOfac searchResultOfac = doMatch(matchQuery);
		this.addMatch(searchResultOfac);

	}

	@Override
	public SearchResultOfac resolve(SearchResultOfac match1, SearchResultOfac match2) {
		if (match1.getOfacQuery().getScore() < match2.getOfacQuery().getScore()) {
			return match2;
		} else {
			if (match1.getOfacQuery().getScore() == match2.getOfacQuery().getScore())
				if (match2.getOfacQuery().getType().equals(OfacQuery.Type.EXACT)) {
					return match2;
				}
			return match1;
		}
	}

	@Override
	protected SearchResultOfac doMatch(SearchResultOfac match) {
		match.addMatch(match.getOfacQuery().getQueryId(), match.getOfacQuery().getField(), match.getOfacQuery());
		return match;
	}

	@Override
	public void addMatch(SearchResultOfac match) {
		Map<String, SearchResultOfac> matches = this.matches(match.getDocId());
		if (matches != null) {
			for (SearchResultOfac searchResultOfac : matches.values()) {
				searchResultOfac.addMatch(match.getOfacQuery().getQueryId(), match.getOfacQuery().getField(), match.getOfacQuery());
				for (OfacQuery ofacQueryPrv : searchResultOfac.getMatches()) {
					match.addMatch(ofacQueryPrv.getQueryId(), ofacQueryPrv.getField(), ofacQueryPrv);
				}
			}
		}
		
		for (SearchResultOfac searchResultOfac : docs) {
			String id = searchResultOfac.getDocId();
			if (match.getDocId().equals(id)) {
				// existe en docs 
				for (OfacQuery ofacQueryPrv : searchResultOfac.getMatches()) {
					match.addMatch(ofacQueryPrv.getQueryId(), ofacQueryPrv.getField(), ofacQueryPrv);					
				}
			} 
		}
		match.setScore(0);
		// actualizamos el score
		for (OfacQuery ofacQueryPrv : match.getMatches()) {
			match.setScore(match.getScore() + ofacQueryPrv.getScore());					
		}		
		super.addMatch(match);
	}

	public static final MatcherFactory<SearchResultOfac> FACTORY = new MatcherFactory<SearchResultOfac>() {
		@Override
		public PresearcherMatcher createMatcher(DocumentBatch docs, FacetQueryOfac facetQueryOfac) {
			return new PresearcherMatcher(docs, facetQueryOfac);
		}
	};

	@Override
	public List<SearchResultOfac> adjustComponent(SearchResultOfac match) {
		return null;
	}

}
