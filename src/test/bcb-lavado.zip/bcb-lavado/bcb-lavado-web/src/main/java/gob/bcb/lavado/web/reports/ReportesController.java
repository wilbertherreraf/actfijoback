package gob.bcb.lavado.web.reports;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.commons.ArchivoSinpleServiceImpl;

@Component
public class ReportesController {
	private static final Logger log = LoggerFactory.getLogger(ReportesController.class);
	
	@Autowired
	private SimpleReportFiller simpleReportFiller;
	@Autowired
	private SimpleReportExporter simpleReportExporter;
	
	public ArchivoSinple generarReporte(Map<String, Object> parameters, String nameFile) {
		log.info("Parametros reporte " + parameters.toString());
        simpleReportFiller.setParameters(parameters);

        simpleReportFiller.fillReport(nameFile);

        simpleReportExporter.setJasperPrint(simpleReportFiller.getJasperPrint());
        String nFile = "Reporte_" + UtilsDate.stringFromDate(new Date(), "yyyyMMddHHmmss") + ".pdf";
        ArchivoSinpleServiceImpl archivoSinplePDF = simpleReportExporter.exportToPdf(nFile, "bcb");
        return archivoSinplePDF.getArchivoSinple();
	}
}
