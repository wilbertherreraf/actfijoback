package gob.bcb.lavado.web.converter;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.QL.rrhh.PlafinQLBean;
import gob.bcb.lavado.pojos.Empleado;



@FacesConverter("empleadoConverter")
public class EmpleadoConverter implements Converter {
	private static final Logger log = LoggerFactory.getLogger(EmpleadoConverter.class);	
	@Autowired
	private PlafinQLBean plafinQLBean;
	
    public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
        if(value != null && value.trim().length() > 0) {
            try {
            	log.info("XXX: plafinQLBean nulo? " + (plafinQLBean == null) + " value = " + value);
            	if (plafinQLBean != null){
                	Empleado empleado = plafinQLBean.findEmpleado(Integer.parseInt(value), false);
                    return empleado;            		
            	} else {
            		return null;
            	}
            } catch(NumberFormatException e) {
            	log.error(e.getMessage(), e);
                throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Conversion Error", "Not a valid empleado."),e);
            } catch(Exception e) {
            	log.error("Excepcion " + e.getMessage(), e);
                throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Conversion Error", "Not a valid empleado."),e);                
            }
        }
        else {
            return null;
        }
    }
 
    public String getAsString(FacesContext fc, UIComponent uic, Object object) {
        if(object != null) {
        	log.info("XXX: NroEmpleado" + ((Empleado) object).getNroEmpleado());
            return String.valueOf(((Empleado) object).getNroEmpleado());
        }
        else {
            return null;
        }
    }   
}     
