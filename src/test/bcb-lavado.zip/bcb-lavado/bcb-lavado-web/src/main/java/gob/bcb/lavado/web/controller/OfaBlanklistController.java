package gob.bcb.lavado.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.model.OfaBlanklist;
import gob.bcb.lavado.repository.OfaBlanklistRepository;
import gob.bcb.lavado.services.SwiftAdminDaoService;

@ManagedBean(name = "ofaBlanklistController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class OfaBlanklistController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(OfaBlanklistController.class);

	private List<OfaBlanklist> ofaBlanklistLista = new ArrayList<>();
	private OfaBlanklist ofaBlanklistSelected = new OfaBlanklist();
	
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
	@Autowired
	private OfaBlanklistRepository ofaBlanklistRepository;
	
	@PostConstruct 
	public void init() {
		try {
			inicializar();
			recuperardatos();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}
	
	private void recuperardatos() {
		ofaBlanklistLista = ofaBlanklistRepository.findAll();
	}

	public String guardar() {
		try {
			ofaBlanklistSelected.setBlcAuditusr(getVisitBean().getUsuario().getUsrLogin());
			ofaBlanklistSelected.setBlcAuditwst(getVisitBean().getUsuario().getUsrAuditwst());
			swiftAdminDaoService.actualizarOfaBlanklist(ofaBlanklistSelected);
			recuperardatos() ;
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");
			return null;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			return null;
		}
	}
	public void eliminar(OfaBlanklist ofaBlanklist) {
		try {
			ofaBlanklist.setBlcAuditwst(getVisitBean().getUsuario().getUsrAuditwst());			
			swiftAdminDaoService.eliminarOfaBlanklist(ofaBlanklist);
			recuperardatos() ;
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}
	
	public void autorizar(OfaBlanklist ofaBlanklist) {
		try {
			ofaBlanklist.setBlcAuditusr(getVisitBean().getUsuario().getUsrLogin());
			ofaBlanklist.setBlcAuditwst(getVisitBean().getUsuario().getUsrAuditwst());
			swiftAdminDaoService.autorizarOfaBlanklist(ofaBlanklist);
			recuperardatos() ;
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}	
	public void cambiarAPendiente(OfaBlanklist ofaBlanklist) {
		try {
			ofaBlanklist.setBlcAuditusr(getVisitBean().getUsuario().getUsrLogin());
			ofaBlanklist.setBlcAuditwst(getVisitBean().getUsuario().getUsrAuditwst());
			swiftAdminDaoService.cambiarAPendienteOfaBlanklist(ofaBlanklist);
			recuperardatos() ;
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}	
	public void nuevo() {
		ofaBlanklistSelected = new OfaBlanklist();
	}	
	public void selectItem(OfaBlanklist ofaBlanklistSelected) {
		this.ofaBlanklistSelected = ofaBlanklistSelected;
	}
	
	public List<OfaBlanklist> getOfaBlanklistLista() {
		return ofaBlanklistLista;
	}

	public void setOfaBlanklistLista(List<OfaBlanklist> ofaBlanklistLista) {
		this.ofaBlanklistLista = ofaBlanklistLista;
	}

	public OfaBlanklist getOfaBlanklistSelected() {
		return ofaBlanklistSelected;
	}

	public void setOfaBlanklistSelected(OfaBlanklist ofaBlanklistSelected) {
		this.ofaBlanklistSelected = ofaBlanklistSelected;
	}
}
