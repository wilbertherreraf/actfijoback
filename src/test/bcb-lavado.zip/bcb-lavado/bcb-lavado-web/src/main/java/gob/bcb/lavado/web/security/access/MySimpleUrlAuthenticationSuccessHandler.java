package gob.bcb.lavado.web.security.access;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import gob.bcb.axesso.services.LoginAttemptService;
import gob.bcb.lavado.commons.Constants;

@Component("mySimpleUrlAuthenticationSuccessHandler")
public class MySimpleUrlAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {
	protected final Logger log = LoggerFactory.getLogger(MySimpleUrlAuthenticationSuccessHandler.class);

	@Autowired
	private LoginAttemptService loginAttemptService;
//	@Autowired
//	private VisitBean visitBean;
	public MySimpleUrlAuthenticationSuccessHandler() {
		super();
	}

	// API

	@Override
	public void onAuthenticationSuccess(final HttpServletRequest request, final HttpServletResponse response, final Authentication authentication) throws ServletException, IOException{
		String username = authentication.getName();
		log.info("onAuthenticationSuccess for user: " + username);

		boolean passChangeRequired = loginAttemptService.loginSucceeded(username);
		if (passChangeRequired) {
			// start "change password" flow:
			log.info("password expired for user " + username + " redirect to " +request.getContextPath() + "/view/cambioPassword.xhtml");
//			// redirect to a set new password page:
			request.getSession().setAttribute(Constants.SES_REQUIRE_CHGPASSWORD, username);
			response.sendRedirect(request.getContextPath() + "/view/cambioPassword.xhtml");
			return;
		}
		super.onAuthenticationSuccess(request, response, authentication);
	}
}
