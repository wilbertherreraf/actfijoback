package gob.bcb.lavado.web.controller;

import java.util.ArrayList;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.jee.axesso.remoto.UsuarioEjbRemoto;
import gob.bcb.jee.axesso.util.UtilRemoto;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfBicsPK;
import gob.bcb.lavado.repository.SwfBicsDao;
import gob.bcb.lavado.services.SwiftBcbSearcherService;

@ManagedBean(name = "swfBicsController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class SwfBicsController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(SwfBicsController.class);

	private List<SwfBics> swfBicsLista = new ArrayList<>();
	private SwfBics swfBicsSelected = new SwfBics();
	private SwfBics swfBicsSearch = new SwfBics();
	private boolean nuevo= false;
	@Autowired
	private SwfBicsDao swfBicsDao;
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;

	@PostConstruct
	public void init() {
		try {
			inicializar();
			swfBicsSelected.setId(new SwfBicsPK());
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public String guardar() {
		log.info("guardar " + (swfBicsSelected.getId() == null) + " " + swfBicsSelected.getBicDescrip());
		try {
			if (StringUtils.isBlank(swfBicsSelected.getId().getBicCodbic()) ||  StringUtils.isBlank(swfBicsSelected.getId().getBicCodbranch())){
				showMessageError("Codigo BIC o branch invalido", "Codigo BIC o branch invalido");
				return null;
			}
			
			if (nuevo){
				// control de la existencia en base
				SwfBics swfBics = swfBicsDao.findByBicBranch(swfBicsSelected.getId().getBicCodbic(), swfBicsSelected.getId().getBicCodbranch());
				if (swfBics != null){
					throw new RuntimeException("BIC " + swfBicsSelected.getId().getBicCodbic() + " - "+ swfBicsSelected.getId().getBicCodbranch()  + ", ya fue registrado");					
				}
			}
			
			SwfBics swfBicsNew = swfBicsDao.actualizar(swfBicsSelected);
			swfBicsLista = new ArrayList<>();
			swfBicsLista.add(swfBicsNew);
			nuevo = false;
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");
			return null;
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			return null;			
		}
	
	}
	public void eliminar(SwfBics swfBics) {
		try {
			swfBicsDao.eliminar(swfBics.getId().getBicCodbic(), swfBics.getId().getBicCodbranch());
			swfBicsLista = new ArrayList<>();
			addMessageInfo("La operación fue realizada exitósamente.", "La operación fue realizada exitósamente.");			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}	
	public void nuevo() {
		swfBicsSelected = new SwfBics();
		swfBicsSelected.setId(new SwfBicsPK());
		nuevo = true;
	}
	public void buscar() {
		swfBicsLista = new ArrayList<>();		
		try {
			if (StringUtils.isBlank(swfBicsSearch.getBicDescrip()))
				throw new RuntimeException("Ingrese texto a buscar");
			swfBicsLista = (List<SwfBics>) swiftBcbSearcherService.searchForQueryInSwfBics(swfBicsSearch.getBicDescrip(), Constants.BICS_CODESTRATEGIA_DEFAULT);
			addMessageInfo("Búsqueda finalizada con " + swfBicsLista.size() + " registros encontrados", "Búsqueda finalizada con " + swfBicsLista.size() + " registros encontrados");			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}	
	public void selectItem(SwfBics swfBics) {
		try {
			nuevo = false;
			swfBicsSelected = swfBicsDao.findByCodBicBranch(swfBics.getId().getBicCodbic(), swfBics.getId().getBicCodbranch());
			if (swfBicsSelected == null)
				throw new RuntimeException("Banco inexistente " + swfBics.getId().getBicCodbic() + "-"+ swfBics.getId().getBicCodbranch());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}		
	}
	public List<SwfBics> getSwfBicsLista() {
		return swfBicsLista;
	}
	public void setSwfBicsLista(List<SwfBics> swfBicsLista) {
		this.swfBicsLista = swfBicsLista;
	}
	public SwfBics getSwfBicsSelected() {
		return swfBicsSelected;
	}
	public void setSwfBicsSelected(SwfBics swfBicsSelected) {
		this.swfBicsSelected = swfBicsSelected;
	}

	public SwfBics getSwfBicsSearch() {
		return swfBicsSearch;
	}

	public void setSwfBicsSearch(SwfBics swfBicsSearch) {
		this.swfBicsSearch = swfBicsSearch;
	}

	public boolean isRegistroNuevo(){
		return (nuevo);
	}
}
