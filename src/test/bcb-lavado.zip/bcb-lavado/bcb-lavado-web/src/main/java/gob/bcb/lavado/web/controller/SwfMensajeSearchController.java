package gob.bcb.lavado.web.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.services.SwiftAdminDaoService;

@ManagedBean(name = "swfMensajeSearchController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class SwfMensajeSearchController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(SwfMensajeSearchController.class);
	private SwfMensaje swfMensajeSelected = new SwfMensaje();
	private List<SwfMensaje> mensajesDatosSelectedLista;
	private List<SwfMensaje> mensajesDatosProcesadosLista;
	private List<SwfMensaje> mensajesDatosObservadosLista;
	@Autowired
	private SwfMensajeDao swfMensajeDao;

	@PostConstruct
	public void init() {
		try {
			inicializar();
			inicializaAlAbrir();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	private void inicializaAlAbrir() {
		inicializaObjetos();
		Calendar c = GregorianCalendar.getInstance();

		Date primerDia = UtilsDate.dateFromString("01/01/" + c.get(Calendar.YEAR), "dd/MM/yyyy");
		Date ultDia = new Date();

		Integer codempleado = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());
		swfMensajeSelected.setMenInout(Constants.TIPO_MENSAJE_IN);
		mensajesDatosSelectedLista = swfMensajeDao.buscarMensajesEntrantes(swfMensajeSelected, null, codempleado, Constants.TAB_ESTREVISION_PEND, primerDia, ultDia);
		mensajesDatosProcesadosLista = swfMensajeDao.buscarMensajesEntrantes(swfMensajeSelected, null, codempleado, Constants.TAB_ESTREVISION_PROCESADO, primerDia,
				ultDia);
		mensajesDatosObservadosLista = swfMensajeDao.findObservados(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ);
	}

	private void inicializaObjetos() {
		swfMensajeSelected = new SwfMensaje();
	}

	public void irAPendientes() {
		redirect("/view/procesos/lote_view?faces-redirect=true", "VIEW_ASIGNA");
	}

	public void irABuscar(String tipoBusq) {
		if (!isAuthorized("BUSCARSWF")) {
			showMessageError("Error : no tiene permisos [BUSCARSWF]", "no tiene permisos");
			return;
		}
		getVisitBean().setParametro("VIEW_TIPOBUSQ", tipoBusq);
		redirect("/view/procesos/mensajes_search?faces-redirect=true", "VIEW_SEARCHRESULT");
	}

	public void irABuscarObservados() {
		redirect("/view/ofac/lvd_observado_list?faces-redirect=true", "VIEW_OBSERVADOS");
	}

	public Integer getMensajesPend() {
		Integer pend = 0;
		if (mensajesDatosSelectedLista != null) {
			pend = mensajesDatosSelectedLista.size();
		}
		return pend;
	}

	public Integer getMensajesProcesados() {
		Integer pend = 0;
		if (mensajesDatosProcesadosLista != null) {
			pend = mensajesDatosProcesadosLista.size();
		}
		return pend;
	}

	public Integer getMensajesObservados() {
		Integer pend = 0;
		if (mensajesDatosObservadosLista != null) {
			pend = mensajesDatosObservadosLista.size();
		}
		return pend;
	}

}
