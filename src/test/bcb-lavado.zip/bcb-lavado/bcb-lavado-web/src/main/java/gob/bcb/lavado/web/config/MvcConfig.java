/*
 * Copyright 2016 Vincenzo De Notaris
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 */

package gob.bcb.lavado.web.config;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.resource.PathResourceResolver;

import gob.bcb.lavado.web.security.core.CurrentUserHandlerMethodArgumentResolver;

@Configuration
@EnableWebMvc

// @ComponentScan(basePackageClasses = { AdminController.class,
// MainController.class, CoinQLBean.class, PlafinQLBean.class,
// SwfBicsDaoService.class,
// StrategyBase.class, SwiftMessageResource.class,OfacLoader.class,
// OfacIndexer.class})
// @EnableConfigurationProperties({ AppProperties.class, LavadoProperties.class
// })
// @Import({ DomainAndPersistenceConfig.class, DomainAndPersistenceCoin.class,
// DomainAndPersistenceSap.class, DomainAndPersistenceSearchConfig.class })
public class MvcConfig extends WebMvcConfigurerAdapter {

	private static final Logger log = LoggerFactory.getLogger(MvcConfig.class);
	@Autowired
	CurrentUserHandlerMethodArgumentResolver currentUserHandlerMethodArgumentResolver;

	public MvcConfig() {
		log.info("en MvcConfig construct");
	}

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		log.info("en addViewControllers:_::");
		// registry.addRedirectViewController("/", "/index.xhtml");
		registry.addViewController("/").setViewName("redirect:/index.xhtml");
		// registry.addViewController("/").setViewName("index");
		registry.addViewController("/error").setViewName("error");
	}

	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
		log.info("en addArgumentResolvers :_::");
		argumentResolvers.add(currentUserHandlerMethodArgumentResolver);
	}

	// @Override
	// public void
	// configureHandlerExceptionResolvers(List<HandlerExceptionResolver>
	// exceptionResolvers) {
	// log.info("en configureHandlerExceptionResolvers :_::");
	// exceptionResolvers.add(handlerExceptionResolver());
	// }

	// @Bean
	// public SimpleMappingExceptionResolver simpleMappingExceptionResolver() {
	// log.info("en simpleMappingExceptionResolver :_::");
	// SimpleMappingExceptionResolver b = new SimpleMappingExceptionResolver();
	//
	// Properties mappings = new Properties();
	// mappings.put("javax.el.ELException", "error");
	// b.setExceptionMappings(mappings);
	// return b;
	// }

	// @Bean
	// public HandlerExceptionResolver handlerExceptionResolver() {
	// log.info("en handlerExceptionResolver :_::");
	// Properties exceptionMapping = new Properties();
	// exceptionMapping.setProperty(javax.el.ELException.class.getName(),
	// "error");
	// exceptionMapping.setProperty(org.springframework.security.access.AccessDeniedException.class.getName(),
	// "error");
	//
	// SimpleMappingExceptionResolver exceptionResolver = new
	// SimpleMappingExceptionResolver();
	// exceptionResolver.setExceptionMappings(exceptionMapping);
	// exceptionResolver.setDefaultErrorView("error");
	// return exceptionResolver;
	// }

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		log.info("en addResourceHandlers :_::");
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");

		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");

		registry.addResourceHandler("/resources/**")
				.addResourceLocations("/resources/‌​", "/resources/css/bootstrap/‌​", "/resources/css/bootstrap/‌​font/", "/resources/css/bootstrap/fontawesome/",
						"/resources/css/bootstrap/plugins/", "/resources/css/bootstrap/plugins/jquery-ui/", "/resources/css/templates/tema1/", "/resources/js/bootstrap/",
						"/resources/js/bootstrap/plugins/slimscroll/", "/resources/js/bootstrap/libs/", "/resources/img/", "/resources/main/images/", "/resources/bootstrap/js/",
						"/resources/bootstrap/fonts/", "/resources/bootstrap/css/", "/resources/vendors/datatables/js/", "/resources/vendors/datatables/css/",
						"/resources/vendors/datatables/images/", "/resources/vendors/datatables/js/")
				.setCachePeriod(3600).resourceChain(true).addResolver(new PathResourceResolver());
		// registry.addResourceHandler("/resources/**").addResourceLocations("/resources/‌​").setCachePeriod(3600).resourceChain(true).addResolver(new
		// PathResourceResolver());
	}
}