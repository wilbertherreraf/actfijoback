package gob.bcb.lavado.web.security.access;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import gob.bcb.axesso.services.LoginAttemptService;

@Component("authenticationFailureHandler")
public class CustomAuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler {
	private static final Logger log = LoggerFactory.getLogger(CustomAuthenticationFailureHandler.class);

	public static final String SPRING_SECURITY_FORM_USERNAME_KEY = "j_username";
	// @Autowired
	// private MessageSource messages;
	//
	// @Autowired
	// private LocaleResolver localeResolver;

	@Autowired
	private LoginAttemptService loginAttemptService;

	@Override
	public void onAuthenticationFailure(final HttpServletRequest request, final HttpServletResponse response, final AuthenticationException exception)
			throws IOException, ServletException {
		String errorMessage = exception.getMessage();		
		log.info("Error en logueo: " + errorMessage + " Exception: " + exception.getClass().getSimpleName());
		setDefaultFailureUrl("/auth/error");

		for (Throwable cause = exception; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
			if (cause instanceof LockedException) {
				super.onAuthenticationFailure(request, response, exception);
				return;
			}
		}
		
		String username = obtainUsername(request);
		loginAttemptService.loginFailed(username);
		if(exception instanceof UsernameNotFoundException || exception instanceof BadCredentialsException ){
			errorMessage = "Usuario o contraseña incorrecta";
		}
		if (loginAttemptService.isBlocked(username)) {
			log.info("Account has been locked out for user: " + username + " due to exceeding number of attempts to login.");
			//getRedirectStrategy().sendRedirect(request, response, "error/error.xhtml");
			errorMessage = "Cuenta de usuario : " + username + " bloqueada";
		} 
		super.onAuthenticationFailure(request, response, exception);

		log.info("{} -> errorMessage {}", exception.getClass().getSimpleName(), errorMessage);
		
		request.getSession().setAttribute(WebAttributes.AUTHENTICATION_EXCEPTION, errorMessage);
	}

	protected String obtainUsername(HttpServletRequest request) {
		return request.getParameter(SPRING_SECURITY_FORM_USERNAME_KEY);
	}
}