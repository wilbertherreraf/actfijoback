package gob.bcb.lavado.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.model.OfaAddresslist;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaIdlist;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.repository.OfaAddresslistRepository;
import gob.bcb.lavado.repository.OfaAkalistRepository;
import gob.bcb.lavado.repository.OfaIdlistRepository;
import gob.bcb.lavado.repository.OfaSdnentryRepository;

@ManagedBean(name = "ofaSdnentryController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class OfaSdnentryController extends BaseBean {
	private final Logger log = LoggerFactory.getLogger(OfaSdnentryController.class);
	private OfaSdnentry ofaSdnentrySelected;
	private List<OfaIdlist> ofaIdlistList = new ArrayList<>();
	private List<OfaAkalist> ofaAkalistList = new ArrayList<>();
	private List<OfaAddresslist> ofaAddresslistList = new ArrayList<>();

	@Autowired
	private OfaSdnentryRepository ofaSdnentryRepository;
	@Autowired
	private OfaIdlistRepository ofaIdlistRepository;
	@Autowired
	private OfaAkalistRepository ofaAkalistRepository;
	@Autowired
	private OfaAddresslistRepository ofaAddresslistRepository;
	
	@PostConstruct
	public void init() {
		try {
			inicializar();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	private void recuperarDatos() {
		String viewAction = (String) getVisitBean().getParametro("VIEW_ACTION");
		if (!StringUtils.isBlank(viewAction)) {
			if (viewAction.equals("VIEW_SDN")) {
				// ofaSdnentrySelected = new OfaSdnentry();
				ofaIdlistList = new ArrayList<>();
				ofaAkalistList = new ArrayList<>();
				ofaAddresslistList = new ArrayList<>();
				ofaSdnentrySelected = null;
				getVisitBean().removeParametro("VIEW_ACTION");
			}
		}
	}

	private void loadSdnentry() throws Exception {
		ofaSdnentrySelected = new OfaSdnentry();
		String idReg = (String) getVisitBean().getParametro("PAR_IDSDN");
		if (!StringUtils.isBlank(idReg)) {
			log.info("idReg " + idReg);
			ofaSdnentrySelected = ofaSdnentryRepository.findOne(Integer.valueOf(idReg));
			if (ofaSdnentrySelected == null) {
				getVisitBean().removeParametro("PAR_IDSDN");
				ofaSdnentrySelected = new OfaSdnentry();
			}
		}
	}

	public void loadIdlist() {
		try {
			if (ofaSdnentrySelected != null)
			ofaIdlistList = ofaIdlistRepository.findByIdlEntryuid(ofaSdnentrySelected.getSdnId());
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void loadAkalist() {
		try {
			if (ofaSdnentrySelected != null)
			ofaAkalistList = ofaAkalistRepository.findByAkaEntryuid(ofaSdnentrySelected.getSdnId());
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void loadAddrlist() {
		try {
			if (ofaSdnentrySelected != null)
			ofaAddresslistList = ofaAddresslistRepository.findByAdrEntryuid(ofaSdnentrySelected.getSdnId());
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public List<OfaIdlist> getOfaIdlistList() {
		return ofaIdlistList;
	}

	public void setOfaIdlistList(List<OfaIdlist> ofaIdlistList) {
		this.ofaIdlistList = ofaIdlistList;
	}

	public OfaSdnentry getOfaSdnentrySelected() {
		recuperarDatos();
		if (ofaSdnentrySelected == null) {
			try {
				loadSdnentry();
				loadAkalist();
				loadAddrlist();
				loadIdlist();
			} catch (Exception e) {
				log.error("error al iniciar " + e.getMessage(), e);
				showMessageError(e.getMessage(), e.getMessage());
			}
		}
		return ofaSdnentrySelected;
	}

	public void setOfaSdnentrySelected(OfaSdnentry ofaSdnentrySelected) {
		this.ofaSdnentrySelected = ofaSdnentrySelected;
	}

	public List<OfaAkalist> getOfaAkalistList() {
		return ofaAkalistList;
	}

	public void setOfaAkalistList(List<OfaAkalist> ofaAkalistList) {
		this.ofaAkalistList = ofaAkalistList;
	}

	public List<OfaAddresslist> getOfaAddresslistList() {
		return ofaAddresslistList;
	}

	public void setOfaAddresslistList(List<OfaAddresslist> ofaAddresslistList) {
		this.ofaAddresslistList = ofaAddresslistList;
	}
}
