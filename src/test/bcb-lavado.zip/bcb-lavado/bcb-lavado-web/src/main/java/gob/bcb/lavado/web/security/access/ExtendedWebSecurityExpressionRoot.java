package gob.bcb.lavado.web.security.access;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.expression.WebSecurityExpressionRoot;

/**
 * Created by marten on 13-06-14.
 */
public class ExtendedWebSecurityExpressionRoot extends WebSecurityExpressionRoot {
	private static final Logger log = LoggerFactory.getLogger(ExtendedWebSecurityExpressionRoot.class);
	
    public ExtendedWebSecurityExpressionRoot(Authentication a, FilterInvocation fi) {
        super(a, fi);
    }

    public boolean localAccess() {
        return hasIpAddress("127.0.0.1") || hasIpAddress("0:0:0:0:0:0:0:1");

    }
}
