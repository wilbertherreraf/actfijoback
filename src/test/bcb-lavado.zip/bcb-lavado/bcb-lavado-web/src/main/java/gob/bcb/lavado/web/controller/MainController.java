package gob.bcb.lavado.web.controller;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import gob.bcb.core.utils.UtilsDate;

@ManagedBean(name = "mainController")
@SessionScoped
@Component
@Scope("session")
public class MainController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(MainController.class);

	@PostConstruct
	public void init() {
		log.info("Creando MainController .....");
	}

	public void irARecursoDesdeMenu(String codRecurso, String urlProceso, String viewActionOrigen, String urlDestino, String viewActionDestino) {
		if (getVisitBean() != null) {
			log.info("==))) EN irARecursoDesdeMenu de urlProceso= " + urlProceso + " con viewActionOrigen " + viewActionOrigen + " A urlDestino " + urlDestino
					+ " hacer viewActionDestino " + viewActionDestino + " codRecurso " + codRecurso);

			getVisitBean().setParametro("VIEW_ACTION", viewActionDestino);
			getVisitBean().setParametro("SIN-IDRECURSO", codRecurso);

			HttpSession sesiones = (HttpSession) getFacesContext().getExternalContext().getSession(false);
 
			for (String element : StringUtils.toStringArray(sesiones.getAttributeNames())) {
				String key = element;
				log.debug("key " + key);				
				if (key.endsWith("Controller") && !key.contains("mainController") ){ // && key.contains(".DESTRUCTION_CALLBACK.")
					log.debug("Session removida " + key);
					sesiones.removeAttribute(key);					
				}
			}
			redirect(urlDestino, viewActionDestino);
		}
	}
	public String getFechaLiteral() {
		return UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy");
	}
	
	public void idleListener() {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		HttpSession  httpSession = request.getSession(false);
		int inactivesec = 0;				
		if (httpSession != null)
			inactivesec = httpSession.getMaxInactiveInterval();
		else {
			httpSession = request.getSession();					
		}
		if (inactivesec == 0){
			log.info("timeout!!!");
			addMessageInfo("Your session is closed", "Your session is closed");
			redirect("/index?faces-redirect=true", "");			
		}
		
	}
	
    public void activeListener() {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
										"Aviso", "Su sesión ha caducado!"));
	}	
}
