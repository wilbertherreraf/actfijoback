package gob.bcb.lavado.web.controller; 

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.model.GenDesctabla;
import gob.bcb.lavado.repository.GenDesctablaDao;

@ManagedBean(name = "descTablasController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public class DescTablasController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(DescTablasController.class);
	private List<GenDesctabla> genDesctablaList = new ArrayList<GenDesctabla>();
	@Autowired
	private GenDesctablaDao genDesctablaDao;
	@PostConstruct
	public void init() {
		inicializar();
		
		Integer descodigo = (Integer) getVisitBean().getParametro("PAR_DESCODTAB");
		if (descodigo != null){
			log.info("PAR_DESCODTAB= " + descodigo);			
			genDesctablaList = genDesctablaDao.findByDesCodtab(descodigo);
		}
	}
	public void selectCarFromDialog(GenDesctabla genDesctabla) {
        RequestContext.getCurrentInstance().closeDialog(genDesctabla);
    }
	
	public List<GenDesctabla> getGenDesctablaList() {
		return genDesctablaList;
	}
	public void setGenDesctablaList(List<GenDesctabla> genDesctablaList) {
		this.genDesctablaList = genDesctablaList;
	}

}
