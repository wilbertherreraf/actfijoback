package gob.bcb.lavado.web.security.core;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import gob.bcb.axesso.services.AxessoDaoService;
import gob.bcb.axesso.services.LoginAttemptService;
import gob.bcb.core.utils.WebUtils;
import gob.bcb.jee.axesso.entidades.Password;
import gob.bcb.jee.axesso.excepciones.OperationException;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.pojos.GenUsuario;
import gob.bcb.lavado.web.security.Salt;
import gob.bcb.lavado.web.security.SecurityUser;
import gob.bcb.lavado.web.security.SecurityUtils;

@Service("userDetailsServiceImpl")
public class UserDetailsServiceImpl implements UserDetailsService {
	private static final Logger log = LoggerFactory.getLogger(UserDetailsServiceImpl.class);

	@Autowired
	private AxessoDaoService axessoDaoService;
	@Autowired
	private LoginAttemptService loginAttemptService;

	public UserDetailsServiceImpl() {
		log.info("creando UserDetailsServiceImpl...");
	}
	
	@Override
	public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
		String usrLogin = StringUtils.trimToEmpty(login);
		log.info("ooo000OOO Inicio autenticacion [{}, ip {}] OOO000ooo", usrLogin, WebUtils.getIpAdress(WebUtils.geHttpServletRequest()));
		HttpServletRequest request = WebUtils.geHttpServletRequest();
		String password=request.getParameter("j_password");

		if (loginAttemptService.isBlocked(usrLogin))
			throw new LockedException("Cuenta de usuario bloqueado");
		return getUserDetails(usrLogin, password);
	}

	public UserDetails changePassword(String password, String passwordNew, HttpServletResponse response, HttpServletRequest request)
			throws UsernameNotFoundException {

		String usrLogin = SecurityUtils.getCurrentUserLogin();
		log.info("En changePassword " + usrLogin);
		SecurityUser userDetailsOld = getUserDetails(usrLogin, password);
		
		Password passwordEjb = axessoDaoService.changePassword(usrLogin, password, passwordNew, response, request);
		SecurityContext securityContext = SecurityContextHolder.getContext();
		request.getSession().removeAttribute(Constants.SES_REQUIRE_CHGPASSWORD);
		request.getSession().invalidate();
		request.getSession(true);

		UserDetails userDetails = new SecurityUser(userDetailsOld.getId(), usrLogin, passwordEjb.getPassword().trim().toLowerCase(), true, true, true, true,
				userDetailsOld.getAuthorities(), generateSalt().toString(), userDetailsOld.getGenUsuario());

		final Authentication newAuthentication = new UsernamePasswordAuthenticationToken(userDetails, passwordEjb.getPassword().trim().toLowerCase(),
				userDetailsOld.getAuthorities());
		securityContext.setAuthentication(newAuthentication);

		return userDetails;
	}

	private SecurityUser getUserDetails(String login, String password) throws UsernameNotFoundException {
		String usrLogin = StringUtils.trimToEmpty(login);
		log.info("Inicio autenticacion " + usrLogin);
		GenUsuario genUsuario = axessoDaoService.getGenUsuarioFromLogin(usrLogin);

		Optional<GenUsuario> usuarioEjb = Optional.of(genUsuario);
		if (!usuarioEjb.isPresent()) {
			log.warn("Password invalido " + usrLogin);
			throw new UsernameNotFoundException("Usuario inexistente " + usrLogin);
		}

		return usuarioEjb.map(usrejb -> {
			
			Password axsPasswordslcl;
			try {
				axsPasswordslcl = axessoDaoService.findPasswordByLogin(usrLogin, password);
			} catch (OperationException e) {
				throw new UsernameNotFoundException("Password no encontrado " + usrLogin);				
			}
			if (axsPasswordslcl == null){
				throw new UsernameNotFoundException("Credenciales inválidas para " + usrLogin);
			}
			
			List<GrantedAuthority> grantedAuthorities = usuarioEjb.get().getRecursos().stream().map(authority -> new SimpleGrantedAuthority(authority))
					.collect(Collectors.toList());
			if (grantedAuthorities.size() <= 0){
				log.error("Usuario sin roles asignados " + usrLogin);
				throw new InsufficientAuthenticationException("Usuario con permisos insuficientes " + usrLogin);				
			}
			genUsuario.setUsrAuditwst(WebUtils.getIpAdress(WebUtils.geHttpServletRequest()));
			SecurityUser userDetails = new SecurityUser(genUsuario.getUsrCoduser().toString(), usrLogin,
					axsPasswordslcl.getPassword().trim().toLowerCase(), true, true, true, true, grantedAuthorities, generateSalt().toString(),
					genUsuario);

			log.info("==>Credenciales creada usuario " + genUsuario.getUsrLogin() + "[" + genUsuario.getUsrNombres() + "] recursos "
					+ ArrayUtils.toString(genUsuario.getRecursos()) + " UsrCodemp " + genUsuario.getUsrCodemp() + " IP " + genUsuario.getUsrAuditwst());

			return userDetails;
		}).orElseGet(() -> {
			List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
			String lowercaseLogin = "ANONYMOUS"; // StringUtils.trimToEmpty(usrLogin).toLowerCase(Locale.ENGLISH)
													// + " " + usrEmail;
			log.error("User " + lowercaseLogin + " was not found in the database AXESSO created user ANONYMOUS");
			GenUsuario genUsuarioan = new GenUsuario();
			genUsuarioan.setUsrLogin(lowercaseLogin.toString());
			genUsuario.setUsrAuditwst(WebUtils.getIpAdress(WebUtils.geHttpServletRequest()));			
			SecurityUser userDetails = new SecurityUser(lowercaseLogin.toString(), lowercaseLogin, "", true, true, false, true, grantedAuthorities,
					generateSalt().toString(), genUsuarioan);
			return userDetails;
		});
	}

	private Salt generateSalt() {
		return new Salt().generate();
	}
}
