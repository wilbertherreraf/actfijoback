package gob.bcb.lavado.web.config;

public abstract class ConstantsSec {
	public static String SAML_FILE_KEYSTORE="security";
    public static final String ANONYMOUS = "ROLE_ANONYMOUS";	
}
