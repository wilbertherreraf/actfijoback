package gob.bcb.lavado.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.lavado.services.SwiftAdminDaoService;
import gob.bcb.lavado.services.SwiftAdminDaoServiceImpl;

@ManagedBean(name = "swfParamsController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class SwfParamsController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(SwfParamsController.class);
	private SwfParams swfParamsSelected = new SwfParams();
	private List<SwfParams> swfParamsLista = new ArrayList<SwfParams>();
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;

	@PostConstruct
	public void init() {
		try {
			log.info("enn SwfParamsController");
			inicializar();
			recuperardatos();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	private void recuperardatos() {
		try {
			swfParamsLista = swfParamsDao.getAll();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public String guardar() {
		log.info("guardar swfParams {} ", swfParamsSelected.toString());
		try {
			swiftAdminDaoService.actualizarSwfParams(swfParamsSelected, getVisitBean().getCurrentUserLogin(),
					getVisitBean().getUsuario().getUsrAuditwst());
			recuperardatos();
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");
			return null;
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			return null;
		}

	}

	public void selectItem(SwfParams swfParamsSelected) {
		this.swfParamsSelected = swfParamsDao.findByCod(swfParamsSelected.getParCodpar());
	}

	public SwfParams getSwfParamsSelected() {
		return swfParamsSelected;
	}

	public void setSwfParamsSelected(SwfParams swfParamsSelected) {
		this.swfParamsSelected = swfParamsSelected;
	}

	public List<SwfParams> getSwfParamsLista() {
		return this.swfParamsLista;
	}

	public void setSwfParamsLista(List<SwfParams> swfParamsLista) {
		this.swfParamsLista = swfParamsLista;
	}

}
