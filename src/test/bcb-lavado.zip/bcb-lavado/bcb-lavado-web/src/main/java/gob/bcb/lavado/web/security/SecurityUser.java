package gob.bcb.lavado.web.security;

import gob.bcb.lavado.pojos.GenUsuario;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;

public class SecurityUser extends User {

	private String id;
	private String salt;
	private GenUsuario genUsuario;
	
	public SecurityUser(final String id, final String username, final String password, final boolean enabled, final boolean accountNonExpired,
			 final boolean credentialsNonExpired, final boolean accountNonLocked,final Collection<? extends GrantedAuthority> authorities, final String salt,
			final GenUsuario genUsuario) {
		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
		this.id = id;
		this.setSalt(salt);
		this.genUsuario = genUsuario;
	}

	public String getId() {
		return id;
	}

	//@JsonIgnore
	public String getSalt() {
		return salt;
	}

	public void setSalt(final String salt) {
		this.salt = salt;
	}

	public GenUsuario getGenUsuario() {
		return genUsuario;
	}
}
