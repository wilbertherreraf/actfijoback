package gob.bcb.lavado.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;
import org.primefaces.event.SelectEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.GenDesctabla;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.rest.LvdSwiftsResource;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.client.pojos.SearchResponse.ItemsInfo;
import gob.bcb.lavado.services.SwiftBcbSearcherService;

@ManagedBean(name = "ofacSearchController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class OfacSearchController extends BaseBean {
	private final Logger log = LoggerFactory.getLogger(OfacSearchController.class);
	private SwfMensaje paramsSearch = new SwfMensaje();
	private List<ItemsInfo> itemsInfoLista = new ArrayList<>();
	private List<String> strategiesLista;
	private boolean viewSearch = false;
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;
	
	@Autowired
	private LvdSwiftsResource lvdSwiftsResource;
	@PostConstruct
	public void init() {
		try {
			inicializar();
			String viewAction = (String) getVisitBean().getParametro("VIEW_ACTION");
			if (!StringUtils.isBlank(viewAction)) {
				viewSearch = viewAction.equals("VIEW_SEARCH");
			}
			// recuperarDatos();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	private void recuperarDatos() {
		String viewAction = (String) getVisitBean().getParametro("VIEW_ACTION");
		if (!StringUtils.isBlank(viewAction)) {
			
			if (viewAction.equals("VIEW_SCANRESPONSE")) {
				String menPlano = (String) getVisitBean().getParametro("PAR_MENPLANO");
				if (!StringUtils.isBlank(menPlano)) {
					SearchResponse searchResponse = scanPlano(menPlano);
					paramsSearch.setMenPlano(searchResponse.getQry());
				}
				getVisitBean().removeParametro("PAR_MENPLANO");
			}
			getVisitBean().removeParametro("VIEW_ACTION");
		}
	}

	public void buscar() {
		try {
			itemsInfoLista = new ArrayList<>();
			if (StringUtils.isBlank(paramsSearch.getMenEmisor())){
				throw new RuntimeException("Ingrese el texto a buscar");
			}
			
			if (StringUtils.isBlank(paramsSearch.getMenCodmt())){
				throw new RuntimeException("Seleccione una estrategia de la lista");
			}
			
			SearchResponse searchResponse = swiftBcbSearcherService.verificarMensaje(paramsSearch.getMenEmisor(), paramsSearch.getMenCodmt());
			if (searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO) || searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_01)){
				if (searchResponse.getItemsInfo() != null) {
					for (ItemsInfo itemsInfo : searchResponse.getItemsInfo()) {
						itemsInfoLista.add(itemsInfo);
					}
				}				
				
				addMessageInfo("Operacion realizada exitósamente con " + searchResponse.getItemsInfo().length + " registros encontrados", "No existe ningun registro encontrado");
			}else {
				showMessageError(searchResponse.getCodResp() + " " + searchResponse.getDescripResp(), searchResponse.getDescripResp());				
			}			
			
		} catch (Exception e) {
			log.error("error al buscar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void scanPlano() {
		scanPlano(paramsSearch.getMenPlano());
	}

	private SearchResponse scanPlano(String menPlano) {
		SearchResponse searchResponse = null;
		itemsInfoLista = new ArrayList<>();
		try {
			if (StringUtils.isBlank(menPlano)){
				throw new RuntimeException("Ingrese el texto en formato RJE");
			}
			
			searchResponse = swiftBcbSearcherService.searchScanSingle(menPlano, false);
			if (searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO) || searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_01)){
				if (searchResponse.getItemsInfo() != null) {
					for (ItemsInfo itemsInfo : searchResponse.getItemsInfo()) {
						itemsInfoLista.add(itemsInfo);
					}
				}				
				
				addMessageInfo("Operacion realizada exitósamente con " + searchResponse.getItemsInfo().length + " registros encontrados", "No existe ningun registro encontrado");
			}else {
				showMessageError(searchResponse.getDescripResp(), searchResponse.getDescripResp());				
			}
		} catch (Exception e) {
			log.error("error al buscar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}

		return searchResponse;
	}

	public void inicializaObjetos() {
		paramsSearch = new SwfMensaje();
		itemsInfoLista = new ArrayList<>();
	}

	public void onDescTablaChosen(SelectEvent event) {
		setGenDesctablaSelected((GenDesctabla) event.getObject());
		if (getGenDesctablaSelected().getId().getDesCodtab().compareTo(Constants.TAB_ESTVERIFICA) == 0) {
			paramsSearch.setGenDesctablaEstmensaje(getGenDesctablaSelected());
		}
	}

	public void verItemInfo(ItemsInfo itemsInfo) {
		log.info("itemsInfo.getIdDoc() " + itemsInfo.getClazz() + ":" + itemsInfo.getIdDoc());
		if (itemsInfo.getClazz().equalsIgnoreCase("ofasdnentry")) {
			getVisitBean().setParametro("PAR_IDSDN", itemsInfo.getIdDoc());
			redirect("/view/ofac/ofasdnentry_show?faces-redirect=true", "VIEW_SDN");
		} else if (itemsInfo.getClazz().equalsIgnoreCase("ofaakalist")) {
			getVisitBean().setParametro("PAR_IDSDN", itemsInfo.getIdDoc());
			redirect("/view/ofac/ofasdnentry_show?faces-redirect=true", "VIEW_SDN");
		}
	}

	public List<ItemsInfo> getItemsInfoLista() {
		// recuperarDatos();
		return itemsInfoLista;
	}

	public SwfMensaje getParamsSearch() {
		recuperarDatos();
		return paramsSearch;
	}

	public List<String> getStrategiesLista() {
		if (strategiesLista == null) {
			strategiesLista = lvdSwiftsResource.getStrategiesLvd();
		}

		return strategiesLista;
	}

	public boolean isViewSearch() {
		return viewSearch;
	}
}
