package gob.bcb.lavado.web.controller;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.WebUtils;
import gob.bcb.lavado.model.SwfNumeraswf;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.repository.SwfPersonaDao;
import gob.bcb.lavado.services.NumeracionSwiftService;

@ManagedBean(name = "swfNumeraSwfController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public class SwfNumeraSwfController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(SwfNumeraSwfController.class);

	private SwfPersona swfPersonaSelected = new SwfPersona();
	private SwfNumeraswf swfNumeraswfSelected = new SwfNumeraswf();
	@Autowired
	private NumeracionSwiftService numeracionSwiftService;

	@PostConstruct
	public void init() {
		try {
			log.info("==> inicializar Ingresando a " + this.getClass().getName() );
			recuperarParametros();
			initVars();

		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
		} finally {
			//getVisitBean().removeParametro("idver");
		}
	}

	private void initVars() {
		swfPersonaSelected = new SwfPersona();
		swfNumeraswfSelected = new SwfNumeraswf();
	}

	public void solicitarNro() {
		try {
			log.info("En nueva solicitud de numero {}", swfPersonaSelected.getPerCodemp());
			// validacion de valores de formulario.
			validateForm();

			HttpServletRequest request = (HttpServletRequest) getFacesContext().getExternalContext().getRequest();

			String baseUrl = getUrl(request);

			numeracionSwiftService.solicitudManual(swfPersonaSelected.getPerCodemp(), null,
					WebUtils.getIpAdress(request), baseUrl);

			addMessageInfo("Una solicitud de correlativo Swift fue creada y enviada a su correo, revise el mismo y acceda al link enviado.", "");
			initVars();
			FacesContext facesContext = FacesContext.getCurrentInstance();
			Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
			sesiones.remove("swfNumeraSwfController");

			redirect("/public/nroswift/?faces-redirect=true", "");

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			initVars();
		}
	}

	public void btnLimpiar() {
		initVars();
//		FacesContext facesContext = FacesContext.getCurrentInstance();
//		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
//		sesiones.remove("swfNumeraSwfController");

		redirect("/public/nroswift/?faces-redirect=true", "");
	}

	private boolean validateForm() throws Exception {
		log.info("Iniciando validacion de formulario");
		// validacion de existencia de campos
		if (swfPersonaSelected.getPerCodemp() == null) {
			throw new Exception("Codigo de usuario invalido");
		}

		return true;
	}

	public SwfPersona getSwfPersonaSelected() {
		return swfPersonaSelected;
	}

	public static String getUrl(HttpServletRequest request) {
		String scheme = request.getScheme();
		String serverName = request.getServerName();
		int serverPort = request.getServerPort();
		String contextPath = request.getContextPath(); // includes leading forward slash

		String resultPath = scheme + "://" + serverName + ":" + serverPort + contextPath;
		return resultPath;
	}

	public SwfNumeraswf getSwfNumeraswfSelected() {
		return swfNumeraswfSelected;
	}

}
