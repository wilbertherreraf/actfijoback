package gob.bcb.lavado.web.controller;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.jee.axesso.entidades.Password;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.web.security.core.UserDetailsServiceImpl;

@ManagedBean(name = "cambiarPasswordController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class CambiarPasswordController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(CambiarPasswordController.class);

	// almacena la contraseña anterior
	private String passwordBef;
	// almacena la contraseña nueva
	private String passwordNew;
	// almacena la repeticion de la contraseña nueva
	private String passwordRep;
	// switch de control si la operacion ha sido exitosa
	@Autowired(required = true)
	@Qualifier("userDetailsServiceImpl")
	private UserDetailsServiceImpl userDetailsServiceImpl;

	@PostConstruct
	public void init() {
		try {
			log.info("enn CambiarPasswordController");
			inicializar();
			if (isGoLogout())
				addMessageInfo("Su contraseña ha caducado", "Su contraseña ha caducado");
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}	
	public String verificarPassword() {
		try {
			log.info("En cambiar password");
			// validacion de valores de formulario.
			validateForm();
			// Realiza el proceso de actualizacion de contraseña
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
			// ingresa la nueva contraseña para el usuario
			userDetailsServiceImpl.changePassword(passwordBef, passwordNew, response, request);
			addMessageInfo("Contraseña modificada exitosamente, para continuar debe autenticarse nuevamente",
					"Contraseña modificada exitosamente, para continuar debe autenticarse nuevamente");
			redirect("/index", "");
			return "/index?faces-redirect=true";			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			return "";
		}
	}
	public void cancelar() {
		redirect("/index?faces-redirect=true", "");
	}
		
	/**
	 * Metodo que realiza la validacion del formulario de cambio de contraseña
	 *
	 * @return
	 * @throws Exception
	 */
	private boolean validateForm() throws Exception {
		log.info("Iniciando validacion de formulario");
		// validacion de existencia de campos
		if (StringUtils.isBlank(this.passwordBef)) {
			throw new Exception("La CONTRASEÑA ACTUAL es vacia");
		}
		if (StringUtils.isBlank(passwordNew)) {
			throw new Exception("La CONTRASEÑA NUEVA es vacia");
		} else {
			// validacion del numero de caracteres de la nueva contraseña
			if (this.passwordNew.length() < 8) {
				throw new Exception("La CONTRASEÑA NUEVA debe tener minimo ocho caracteres");
			}
		}
		if (StringUtils.isBlank(passwordRep)) {
			throw new Exception("La REPETICION de la contraseña es vacia");
		}
		// validacion si la contraseña nueva y su repeticion coinciden
		if (!this.passwordNew.equals(this.passwordRep)) {
			throw new Exception("La REPETICION de la contraseña y la CONTRASEÑA no tienen el mismo valor");
		}
		return true;
	}

	public String getPasswordBef() {
		return passwordBef;
	}

	public void setPasswordBef(String passwordBef) {
		this.passwordBef = passwordBef;
	}

	public String getPasswordNew() {
		return passwordNew;
	}

	public void setPasswordNew(String passwordNew) {
		this.passwordNew = passwordNew;
	}

	public String getPasswordRep() {
		return passwordRep;
	}

	public void setPasswordRep(String passwordRep) {
		this.passwordRep = passwordRep;
	}
	
	public boolean isGoLogout(){
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String ses = (String) request.getSession().getAttribute(Constants.SES_REQUIRE_CHGPASSWORD);
		return ses != null;
	}
}
