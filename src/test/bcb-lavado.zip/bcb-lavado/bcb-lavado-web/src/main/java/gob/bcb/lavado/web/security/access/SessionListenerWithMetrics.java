package gob.bcb.lavado.web.security.access;

import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.codahale.metrics.Counter;

import gob.bcb.lavado.web.security.monitoring.MetricRegistrySingleton;

public class SessionListenerWithMetrics implements HttpSessionListener {
	private static final Logger log = LoggerFactory.getLogger(SessionListenerWithMetrics.class);
    private final AtomicInteger activeSessions;

    private final Counter counterOfActiveSessions;

    public SessionListenerWithMetrics() {
        super();
        log.info("Creando SessionListenerWithMetrics");
        activeSessions = new AtomicInteger();
        counterOfActiveSessions = MetricRegistrySingleton.metrics.counter("web.sessions.active.count");
    }

    // API

    public final int getTotalActiveSession() {
        return activeSessions.get();
    }

    @Override
    public final void sessionCreated(final HttpSessionEvent event) {
    	log.info("En sessionCreated " + event.getSession().getId());
        activeSessions.incrementAndGet();
        counterOfActiveSessions.inc();
    }

    @Override
    public final void sessionDestroyed(final HttpSessionEvent event) {
    	log.info("En sessionDestroyed " + event.getSession().getId());
        activeSessions.decrementAndGet();
        counterOfActiveSessions.dec();
    }

}