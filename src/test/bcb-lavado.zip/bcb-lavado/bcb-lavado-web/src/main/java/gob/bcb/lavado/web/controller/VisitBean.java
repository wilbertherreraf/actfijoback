package gob.bcb.lavado.web.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.pojos.GenUsuario;
import gob.bcb.lavado.web.security.SecurityUser;
import gob.bcb.lavado.web.security.SecurityUtils;
import gob.bcb.lavado.web.security.core.UserDetailsServiceImpl;

@Component("visitBean")
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class VisitBean {
	private static final Logger log = LoggerFactory.getLogger(VisitBean.class);
	private Map<String, Object> parametro = new HashMap<String, Object>();

//	@Autowired
//	public VisitBean(UserDetailsServiceImpl userDetailsServiceImpl) {
//		if (userDetailsServiceImpl == null) {
//			throw new IllegalArgumentException("samlUserDetailsService cannot be null");
//		}
//	}
//	
//	public void init() {
//		loadDetailsUsuario(SecurityUtils.getCurrentUserLogin());
//	}

	private void loadDetailsUsuario(String login) {
		log.info("Load Details Usuario for Init Visit....." + login);		
	}
	
	public void setParametro(String key, Object valor) {
		if (this.parametro == null) {
			parametro = new HashMap<String, Object>();
		}
		if (valor == null) {
			if (parametro.containsKey(key))
				parametro.remove(key);
		} else {
			if (key != null) {
				parametro.put(key, valor);
			}
		}
	}

	public Object getParametro(String key) {
		return parametro.get(key);
	}

	public void removeParametro(String key) {
		try {
			parametro.remove(key);
		} catch (Exception e) {
		}
	}

	public void limpiarParametros() {
		parametro.clear();
	}

	public void setParametro(Map<String, Object> parametro) {
		this.parametro = parametro;
	}

	public Map<String, Object> getParametro() {
		return parametro;
	}
	
	public String getCurrentUserLogin() {
		return SecurityUtils.getCurrentUserLogin();
	}
	
	public boolean isAuthenticated(){
		return SecurityUtils.isAuthenticated();
	}
	
	public List<String> getRoles() {
		return SecurityUtils.getRolesIfSignedIn();
	}

	public List<String> getRecursos() {
		return SecurityUtils.getRolesIfSignedIn();
	}

	public boolean isInRole(String rol) {
		return SecurityUtils.isCurrentUserInRole(rol);
	}

	public boolean isAutorized(String recurso) {
		return SecurityUtils.isCurrentUserInRole(recurso);
	}

	public GenUsuario getUsuario() {
		SecurityUser  securityUser  = SecurityUtils.getAuthenticatedUser();
		return securityUser.getGenUsuario();
	}

}
