package gob.bcb.lavado.web.security.access;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.expression.SecurityExpressionOperations;
import org.springframework.security.access.expression.SecurityExpressionRoot;
import org.springframework.security.authentication.AuthenticationTrustResolver;
import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.expression.DefaultWebSecurityExpressionHandler;

public class ExtendedWebSecurityExpressionHandler extends DefaultWebSecurityExpressionHandler {
	private static final Logger log = LoggerFactory.getLogger(ExtendedWebSecurityExpressionHandler.class);
	private AuthenticationTrustResolver trustResolver = new AuthenticationTrustResolverImpl();

	@Override
	protected SecurityExpressionRoot createSecurityExpressionRoot(Authentication authentication, FilterInvocation fi) {
		log.debug(fi.getHttpRequest().getSession().getId() + " Authentication " + authentication.getName() + "; ServletPath: "
				+ fi.getHttpRequest().getServletPath() + " " + fi.getHttpRequest().getParameter("error"));
		ExtendedWebSecurityExpressionRoot root = new ExtendedWebSecurityExpressionRoot(authentication, fi);
		root.setPermissionEvaluator(getPermissionEvaluator());
		root.setTrustResolver(trustResolver);
		root.setRoleHierarchy(getRoleHierarchy());
		root.setDefaultRolePrefix("");
		return root;
	}

	@Override
	public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
		this.trustResolver = trustResolver;
		super.setTrustResolver(trustResolver);
	}
}
