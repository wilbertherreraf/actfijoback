package gob.bcb.lavado.web.reports;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.web.controller.BaseBean;

@ManagedBean(name = "printViewController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public class PrintViewController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(PrintViewController.class);
	private List<MensajesDatos> mensajesDatosLista = new ArrayList<MensajesDatos>();

	@PostConstruct
	public void init() {

		//if (!StringUtils.isBlank(viewAction)) {
		mensajesDatosLista =  (List<MensajesDatos>) getVisitBean().getParametro("PAR_REPMENRESU");		
			if (mensajesDatosLista != null) {
				log.info("En reporte recuperados " + mensajesDatosLista.size() + " registros");
			} else {
				log.info("En reporte recuperados NULOOOOOOOOOOOOO");
				mensajesDatosLista = new ArrayList<MensajesDatos>();
			}
		//}
		removeParmsRequest();
		getVisitBean().removeParametro("VIEW_ACTION");
		getVisitBean().removeParametro("PAR_REPMENRESU");

		if (!FacesContext.getCurrentInstance().isPostback()) {
			RequestContext.getCurrentInstance().execute("window.print();");
		}
	}

	public String getFechaHora(){
		return UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy H:mm:ss");
	}

	public List<MensajesDatos> getMensajesDatosLista() {
		return mensajesDatosLista;
	}

	public void setMensajesDatosLista(List<MensajesDatos> mensajesDatosLista) {
		this.mensajesDatosLista = mensajesDatosLista;
	}
}
