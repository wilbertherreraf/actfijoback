package gob.bcb.lavado.web.controller;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.sql.DataSource;

import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.GenDesctabla;
import gob.bcb.lavado.model.SwfNumeraswf;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.repository.GenDesctablaDao;
import gob.bcb.lavado.repository.SwfNumeraswfDaoImpl;
import gob.bcb.lavado.repository.SwfPersonaDao;
import gob.bcb.lavado.services.NumeracionSwiftService;
import gob.bcb.lavado.web.reports.ReportesController;

@ManagedBean(name = "swifNumeraAdminController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)

public class SwifNumeraAdminController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(SwifNumeraAdminController.class);

	private List<SwfNumeraswf> swfNumeraswfLista = new ArrayList<SwfNumeraswf>();
	private SwfNumeraswf swfNumeraswfSelected = new SwfNumeraswf();
	private SwfNumeraswf swfNumeraswfSearch = new SwfNumeraswf();
	private List<GenDesctabla> genDesctablaTipnroList = new ArrayList<GenDesctabla>();
	private List<GenDesctabla> genDesctablaEstnroList = new ArrayList<GenDesctabla>();
	@Autowired
	private GenDesctablaDao genDesctablaDao;
	@Autowired
	private NumeracionSwiftService numeracionSwiftService;
	@Autowired
	private SwfNumeraswfDaoImpl swfNumeraswfDao;
	@Autowired
	private SwfPersonaDao swfPersonaDao;
	@Autowired
	private ReportesController reportesController;

	@Autowired
	@Qualifier("dataSourceSwift")
	private DataSource dataSourceSwift;
	
	private Date fecInicio;
	private Date fecFin;
	private StreamedContent fileDownF;
	@PostConstruct
	public void init() {
		try {
			inicializar();
			inicializaObjetos();
			String viewAction = (String) getVisitBean().getParametro("VIEW_ACTION");
			getVisitBean().removeParametro("VIEW_ACTION");
		} catch (NullPointerException e) {
			showMessageError("Ocurrió un error inesperado", e.getMessage());
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void inicializaObjetos() {
		swfNumeraswfLista = new ArrayList<SwfNumeraswf>();
		swfNumeraswfSearch = new SwfNumeraswf();
		fecInicio = new Date(); // UtilsDate.addTime(new Date(), -8, 5);
		fecFin = new Date();
		genDesctablaEstnroList = genDesctablaDao.findByDesCodtab(Constants.TAB_ESTNRO);
		genDesctablaTipnroList = genDesctablaDao.findByDesCodtab(Constants.TAB_TIPONRO);
	}

	public void search() {
		swfNumeraswfLista = new ArrayList<SwfNumeraswf>();
		try {
			log.info("en boton search... ");

			swfNumeraswfLista = swfNumeraswfDao.searchAsignaciones(swfNumeraswfSearch, fecInicio, fecFin);
			log.info("en boton search... " + swfNumeraswfLista.size());
			for (SwfNumeraswf swfNumeraswf : swfNumeraswfLista) {
				GenDesctabla genDesctabla = genDesctablaDao.findByDesCodtab(swfNumeraswf.getNroTabestadonro(), swfNumeraswf.getNroEstadonro());
				swfNumeraswf.setGenDesctablaEstadonro(genDesctabla != null ? genDesctabla : new GenDesctabla());
				GenDesctabla genDesctablaTip = genDesctablaDao.findByDesCodtab(swfNumeraswf.getNroTabtipnroswf(), swfNumeraswf.getNroTipnroswf());
				swfNumeraswf.setGenDesctablaTiponroswf(genDesctablaTip != null ? genDesctablaTip : new GenDesctabla());
				SwfPersona swfPersona = swfPersonaDao.findByCodigo(swfNumeraswf.getNroCodemp());
				swfNumeraswf.setSwfPersona(swfPersona != null ? swfPersona : new SwfPersona());
			}

		} catch (Exception e) {
			log.error("error al buscar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void btnAbrirRechazarCorr(SwfNumeraswf swfNumeraswf) {
		swfNumeraswfSelected = swfNumeraswfDao.findByCodigo(swfNumeraswf.getNroCodnro());
	}

	public void guardarNumeraswfRechazo() {
		try {
			numeracionSwiftService.rechazarSolicitud(swfNumeraswfSelected);
		} catch (Exception e) {
			log.error("error al rechazar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void verReporteJasper() {
		try {
			log.info("verReporteJasper " );			

			Map<String, Object> parameters = new HashMap<>();
			
			fecInicio = fecInicio == null ? UtilsDate.dateFromString("01/01/1980", "dd/MM/yyyy") : fecInicio;
			fecFin = fecFin == null ? UtilsDate.dateFromString("01/01/3000", "dd/MM/yyyy") : fecFin;
			
			parameters.put("fechaini", fecInicio);
			parameters.put("fechafin", fecFin);
			
			if (swfNumeraswfSearch.getNroTipnroswf() != null && swfNumeraswfSearch.getNroTipnroswf().compareTo(0) > 0)
				parameters.put("tiponro", swfNumeraswfSearch.getNroTipnroswf());
			if (swfNumeraswfSearch.getNroEstadonro() != null && swfNumeraswfSearch.getNroEstadonro().compareTo(0) > 0)			
				parameters.put("estadonro", swfNumeraswfSearch.getNroEstadonro());
			
			ArchivoSinple archivoSinplePDF = reportesController.generarReporte(parameters, "asignaSwifts.jasper");
			
			log.info("reportSwift reporte PDF generado " + archivoSinplePDF.getNameOriginal());

			byte[] data = archivoSinplePDF.getData();
			InputStream inputStream = new ByteArrayInputStream(data);

			fileDownF = new DefaultStreamedContent(inputStream, "application/pdf", archivoSinplePDF.getNameOriginal());
			log.info("saliendo de verreporte " + archivoSinplePDF.getNameOriginal());

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public List<SwfNumeraswf> getSwfNumeraswfLista() {
		return swfNumeraswfLista;
	}

	public SwfNumeraswf getSwfNumeraswfSelected() {
		return swfNumeraswfSelected;
	}

	public SwfNumeraswf getSwfNumeraswfSearch() {
		return swfNumeraswfSearch;
	}

	public List<GenDesctabla> getGenDesctablaTipnroList() {
		return genDesctablaTipnroList;
	}

	public List<GenDesctabla> getGenDesctablaEstnroList() {
		return genDesctablaEstnroList;
	}

	public Date getFecInicio() {
		return fecInicio;
	}

	public void setFecInicio(Date fecInicio) {
		this.fecInicio = fecInicio;
	}

	public Date getFecFin() {
		return fecFin;
	}

	public void setFecFin(Date fecFin) {
		this.fecFin = fecFin;
	}

	public StreamedContent getFileDownF() {
		return fileDownF;
	}

}
