package gob.bcb.lavado.web;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

import gob.bcb.axesso.services.AxessoDaoServiceImpl;
import gob.bcb.lavado.ConfigApp;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.web.controller.SwfLoteFormController;
import gob.bcb.lavado.web.security.access.ExtendedWebSecurityExpressionHandler;

//@ComponentScan
//@EnableAutoConfiguration

@ComponentScan(basePackageClasses = { AxessoDaoServiceImpl.class, SwfLoteFormController.class, ExtendedWebSecurityExpressionHandler.class })
@EnableAutoConfiguration
@EnableConfigurationProperties({ AppProperties.class })
@PropertySource(value = "file:" + Constants.BASE_DIR_APP + Constants.FILE_APPLICATION_WEB)
public class ApplicationInitializer extends org.springframework.boot.web.support.SpringBootServletInitializer { //SpringBootServletInitializer {
	//private final static Logger log =  LoggerFactory.getLogger(this.getClass());

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder springApplicationBuilder) {
		//log =  LoggerFactory.getILoggerFactory()getLogger(ApplicationInitializer.class);
		//log.info("oooOOOOOO00000 INICIANDO APLICACION 00000OOOOOooo"); 
		return springApplicationBuilder.properties(getProperties()).sources(ApplicationInitializer.class,ConfigApp.class);
	}

	static Properties getProperties() { 
		//log.info("=> Setting enviroment web spring.config.location to : " + Constants.BASE_DIR_APP);		
		Properties props = new Properties();
		props.put("spring.config.location", Constants.BASE_DIR_APP);
		return props;
	}

}
