package gob.bcb.lavado.web.config;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.Map.Entry;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.www.BasicAuthenticationEntryPoint;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.filter.CharacterEncodingFilter;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.web.security.access.CsrfCookieGeneratorFilter;
import gob.bcb.lavado.web.security.access.CustomLogoutSuccessHandler;
import gob.bcb.lavado.web.security.access.ExtendedWebSecurityExpressionHandler;
import gob.bcb.lavado.web.security.access.MySimpleUrlAuthenticationSuccessHandler;
import gob.bcb.lavado.web.security.core.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true, prePostEnabled = true)
public class WebSecurityConfigEjb extends WebSecurityConfigurerAdapter {
	private static final Logger log = LoggerFactory.getLogger(WebSecurityConfigEjb.class); 

	@Autowired(required = true)
	@Qualifier("userDetailsServiceImpl")
	private UserDetailsServiceImpl userDetailsServiceImpl;

	@Autowired
	private AuthenticationFailureHandler authenticationFailureHandler;
	@Autowired
	private MySimpleUrlAuthenticationSuccessHandler mySimpleUrlAuthenticationSuccessHandler;
	@Autowired
	private CustomLogoutSuccessHandler customLogoutSuccessHandler;

	@Override
	public void configure(WebSecurity web) throws Exception {
		log.info("==>>configure(WebSecurity web) ignore");
		// web.ignoring().antMatchers(HttpMethod.OPTIONS, "/**")//
		web.ignoring()//
		.antMatchers("/public/**")//
		.antMatchers("/app/**/*.{js,html}")//
				.antMatchers(Constants.PATH_RESOURCE_API_SEARCH + "/**")//		
				.antMatchers(Constants.PATH_RESOURCE_API_V3_SEARCH + "/**")//
				.antMatchers("/javax.faces.resource/**")//
				.antMatchers("/javax.faces.resource/**/*.{js,html,css,map,png,jpeg,jpg}")//
				.antMatchers("/javax.faces.resource/**/*.*")//
				.antMatchers("/javax.faces.resource/**/*.*.*")//
				.antMatchers("/javax.faces.resource/**/**/*.*.*")//
				.antMatchers("/javax.faces.resource/img/*.*")//
				.antMatchers("/javax.faces.resource/bootstrap/css/bootstrap.css.map")//
				.antMatchers("/javax.faces.resource/vendors/datatables/images/**")//
				.antMatchers("/resources/**")//
				.antMatchers("/resources/**/*.*")//
				.antMatchers("/resources/**/**/*.*")//
				.antMatchers("/resources/**/**/**/*.*")//
				.antMatchers("/bower_components/**")//
				.antMatchers("/i18n/**")//
				.antMatchers("/content/**")//
				.antMatchers("/swagger-ui/index.html")//
				.antMatchers("/test/**")//
				.antMatchers("/h2-console/**");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		log.info("Configure HttpSecurity.....");

		CharacterEncodingFilter filter = new CharacterEncodingFilter() {
			@Override
			protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
				//log.debug("=>en CharacterEncodingFilter " + getEncoding() + " " + isForceRequestEncoding() + " " + isForceResponseEncoding() + " CharacterEncoding:: " + request.getCharacterEncoding());
		        
				String servletPath = request.getServletPath();				
				HttpSession  httpSession = request.getSession(false);
				int inactivesec = 0;				
				if (httpSession != null)
					inactivesec = httpSession.getMaxInactiveInterval();
				else {
					httpSession = request.getSession();					
				}

				//log.info("servletPath ==> " + servletPath);				
				if (inactivesec == 0 && !servletPath.contains("login") && !servletPath.contains("/api/")){
					log.info(httpSession.getId() + " -> " + inactivesec + " en filtro servletPath = " + servletPath);					
					response.sendRedirect(request.getContextPath() + "/login.xhtml");
					return;					
				}

				String ses = (String) httpSession.getAttribute(Constants.SES_REQUIRE_CHGPASSWORD);
				if (ses != null && !servletPath.contains("cambioPassword")){
					if (!servletPath.contains("logout")){
						log.info(httpSession.getId() + " -> en filtro a cambiar passw servletPath = " + servletPath);						
						response.sendRedirect(request.getContextPath() + "/view/cambioPassword.xhtml");
						return;
					}
				}
				log.info(httpSession.getId() + " -> " + inactivesec + " en filtro CharacterEncodingFilter servletPath = " + servletPath + " " + request.getRequestURI());					
				super.doFilterInternal(request, response, filterChain);
			}
			
			@Override
			protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
				// TODO Auto-generated method stub
//		        String path = request.getRequestURI();
//
//		        boolean nofilter = path.contains("/public/") || path.contains("/api/");
//		        log.info(nofilter + " no filter " + path);
//		        return nofilter;
				return super.shouldNotFilter(request);
			}
		};
		filter.setEncoding(Constants.ENCODING);
		filter.setForceEncoding(true);

		http.addFilterBefore(filter, CsrfFilter.class);
		http.addFilterAfter(new CsrfCookieGeneratorFilter(), CsrfFilter.class);

		http//
				.csrf()
				.disable()
				//;//
		//http
		.exceptionHandling()//
				// .authenticationEntryPoint(entryPoint())//
				.and()//
				.rememberMe().key("uniqueAndSecret").tokenValiditySeconds(86400)//
				.and()//
				.formLogin()//
				.loginPage("/login.xhtml") //
				.loginProcessingUrl("/login")//
				//.defaultSuccessUrl("/landing", false) //
				.successHandler(mySimpleUrlAuthenticationSuccessHandler)//
				.failureHandler(authenticationFailureHandler)//
				.usernameParameter("j_username")//
				.passwordParameter("j_password")//
				// .defaultSuccessUrl("/landing")//
				.permitAll()//
				.and()//
				.logout()//
				.deleteCookies("JSESSIONID", "CSRF-TOKEN")//
				.invalidateHttpSession(true)//
				.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))//
				// .logoutUrl("/logout").logoutSuccessUrl("/")//
				.logoutSuccessHandler(customLogoutSuccessHandler)
				// .permitAll()//
				.and()//
				.headers()//
				.frameOptions()//
				.sameOrigin()//
				.and()//
				.authorizeRequests()//
				.expressionHandler(extendedWebSecurityExpressionHandler())//
				// .antMatchers("/WEB-INF/**").permitAll()//
				.antMatchers("/javax.faces.resource/**/**/**.*").permitAll()//
				.antMatchers("/javax.faces.resource/bootstrap/css/bootstrap.css.map").permitAll()//
				.antMatchers("/javax.faces.resource/vendors/datatables/images/**").permitAll()//
				.antMatchers("/resources/**").permitAll()//
				.antMatchers("/resources/**/**").permitAll()//
				.antMatchers("/resources/**/**/**").permitAll()//
				.antMatchers("/resources/**/**/**/**").permitAll()//
				// .antMatchers("/resources/img/*.*").permitAll()//
				.antMatchers("/auth/error").permitAll()//
				.antMatchers(Constants.PATH_RESOURCE_API_SEARCH + "/**").permitAll()//
				.antMatchers(Constants.PATH_RESOURCE_API_V3_SEARCH + "/**").permitAll()//
				.antMatchers(Constants.PATH_RESOURCE_API_BIC + "/**", Constants.PATH_RESOURCE_API_LVD + "/**", Constants.PATH_RESOURCE_API_OFACLIST + "/**",
						Constants.PATH_RESOURCE_API_PARAM + "/**")
				.denyAll()//
				.antMatchers("/public/**/**").permitAll()//				
				.antMatchers("/login").permitAll()//
				.antMatchers("/login.xhtml").permitAll()//
				.antMatchers("/").permitAll() //
				// .antMatchers("/**").authenticated() //
				.antMatchers("/view/ofac/load_ofac.xhtml").access("hasAnyRole('CARGAROFAC')")//
				.antMatchers("/view/procesos/lote_edit.xhtml").access("hasAnyRole('CARGARLOTE')")//
				.antMatchers("/view/procesos/lote_view.xhtml").access("hasAnyRole('PROCESASWF')")//
				.antMatchers("/view/procesos/mensajes_search.xhtml").access("hasAnyRole('BUSCARSWF')")//
				.antMatchers("/view/procesos/mensajes_pend_list.xhtml").access("hasAnyRole('AUTOPEND')")//
				.antMatchers("/view/procesos/swasignacion_modal.xhtml").access("hasAnyRole('BUSCARSWF','PROCESASWF')")//				
				.antMatchers("/view/parametricas/persona_list.xhtml").access("hasAnyRole('PERSEDIT')")//
				.antMatchers("/view/parametricas/params_list.xhtml").access("hasAnyRole('PARAMADMIN')")//
				.antMatchers("/view/parametricas/blacklist_list.xhtml").access("hasAnyRole('ADMBLK')")//
				.antMatchers("/view/parametricas/swfbics_list.xhtml").access("hasAnyRole('PARAMADMIN')")//
				
				.antMatchers("/view/parametricas/generador_lau.xhtml").access("hasAnyRole('ADMLAU')")//
				
				.antMatchers("/view/ofac/load_ofac.xhtml").access("hasAnyRole('CARGAROFAC')")//
				.antMatchers("/view/ofac/lvd_observado_list.xhtml").access("hasAnyRole('LVDPROCOBS')")//
				.antMatchers("/view/ofac/ofac_search.xhtml").access("hasAnyRole('BUSCAROFC')")//
				.antMatchers("/view/ofac/ofasdnentry_show.xhtml").access("hasAnyRole('BUSCAROFC')")//
				.antMatchers("/view/ofac/search_form.xhtml").access("hasAnyRole('BUSCARSWFLVD')")//
				.anyRequest().authenticated()// ;
				.and()//
				.sessionManagement()//
				.sessionFixation().migrateSession()//
				.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)//
				.invalidSessionUrl("/login.xhtml")//
				.maximumSessions(2)//
				.expiredUrl("/login.xhtml");

	}

	@Autowired
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		log.info("=>configure AuthenticationManagerBuilder..... " + (userDetailsServiceImpl == null));
		auth.userDetailsService(userDetailsServiceImpl).passwordEncoder(passwordEncoder());
	}

	@Bean(name = "passwordEncoder")
	public PasswordEncoder passwordEncoder() {
		return new ShaPasswordEncoder();
	}

	@Bean
	public ExtendedWebSecurityExpressionHandler extendedWebSecurityExpressionHandler() {
		log.info("oooooo extendedWebSecurityExpressionHandler =oooooo ");
		return new ExtendedWebSecurityExpressionHandler();
	}

	@Bean
	public AuthenticationEntryPoint entryPoint() {
		log.info("En AuthenticationEntryPoint entryPoint........");
		BasicAuthenticationEntryPoint entryPoint = new BasicAuthenticationEntryPoint() {
			@Override
			public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
				log.info("En commence de entriy ponint........");
				for (Entry<String, String[]> par : request.getParameterMap().entrySet()) {
					log.info("Parameter: " + par.getKey() + " " + request.getParameter(par.getKey()));
				}
				log.info("================REQ HEADER======================");
				Enumeration<String> headerNames = request.getHeaderNames();
				while (headerNames.hasMoreElements()) {
					String headerName = headerNames.nextElement();
					String headerValue = request.getHeader(headerName);
					log.info("REQUEST HEAD[" + headerName + "]: " + headerValue);
				}

				for (String h : response.getHeaderNames()) {
					log.info("RESPONSE HEADER[" + h + "]: " + response.getHeader(h));
				}

				super.commence(request, response, authException);
			}
		};
		entryPoint.setRealmName("axessoRealm");

		return entryPoint;
	}

	@Bean
	public HttpSessionEventPublisher httpSessionEventPublisher() {
		return new HttpSessionEventPublisher();
	}

	public static void main(String[] args) {
		System.out.println("/public".equals("/public/a"));
	}
}
