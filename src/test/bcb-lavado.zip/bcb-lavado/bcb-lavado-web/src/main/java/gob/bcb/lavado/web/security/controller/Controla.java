package gob.bcb.lavado.web.security.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.web.controller.VisitBean;
import gob.bcb.lavado.web.security.SecurityUtils;

@Controller
@RequestMapping("/view")
public class Controla {
	private static final Logger log = LoggerFactory.getLogger(Controla.class);

//	@Autowired
//	private VisitBean visitBean;
	
	@RequestMapping(value = "/verifica", method = RequestMethod.GET)
	public String verifica(HttpServletRequest request, @RequestParam(value = "url") String url, @RequestParam(value = "idrec") String idrec,
			@RequestParam(value = "action") String action) {
		try {
			log.info(":::>Controller Controla url {}, idrec {}, action {} ", url, idrec, action);
			HttpSession sesiones = (HttpSession) request.getSession();
			request.setAttribute("action", action);
			for (String element : StringUtils.toStringArray(sesiones.getAttributeNames())) {
				String key = element;
				if (key.endsWith("Controller") && !key.contains("mainController")) {
					log.info("Session removida " + key);
					sesiones.removeAttribute(key);
				}
			}
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	
		try {
			String nurl = URLDecoder.decode(url, "UTF-8");
			if (SecurityUtils.isAuthenticated()) {
				String nurlredirect = nurl;
				if (!StringUtils.isEmpty(action)){
					request.setAttribute("action", action);
					nurlredirect = UtilsGeneric.encodeURL(nurl, "action", action);
				}
				//SecurityUtils.isCurrentUserInRole(idrec);
				return "redirect:" + nurlredirect;
			}
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
		} catch (UnsupportedEncodingException e) {
			log.error(e.getMessage(), e);
		}
		log.info("TO redirect:/index.xhtml");
		return "redirect:/index.xhtml";
	}
}
