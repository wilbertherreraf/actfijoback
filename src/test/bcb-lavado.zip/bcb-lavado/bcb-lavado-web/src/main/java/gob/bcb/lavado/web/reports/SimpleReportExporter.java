package gob.bcb.lavado.web.reports;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import gob.bcb.lavado.commons.ArchivoSinpleServiceImpl;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.HtmlExporter;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleHtmlExporterOutput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;
import net.sf.jasperreports.export.SimplePdfReportConfiguration;
import net.sf.jasperreports.export.SimpleWriterExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

@Component
public class SimpleReportExporter {
	private static final Logger log = LoggerFactory.getLogger(SimpleReportExporter.class);
	private static final int OUTPUT_BYTE_ARRAY_INITIAL_SIZE = 4096;
    private JasperPrint jasperPrint;

    public SimpleReportExporter() {
    }

    public SimpleReportExporter(JasperPrint jasperPrint) {
        this.jasperPrint = jasperPrint;
    }

    public JasperPrint getJasperPrint() {
        return jasperPrint;
    }

    public void setJasperPrint(JasperPrint jasperPrint) {
        this.jasperPrint = jasperPrint;
    }

    public ArchivoSinpleServiceImpl exportToPdf(String fileName, String author) {
    	ByteArrayOutputStream out = null;
    	out = new ByteArrayOutputStream(OUTPUT_BYTE_ARRAY_INITIAL_SIZE);
        // print report to file
        JRPdfExporter exporter = new JRPdfExporter();
        new SimpleOutputStreamExporterOutput(out);
        exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
        //exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(fileName));
        exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
        //exporter.setExporterOutput(out);
        
        SimplePdfReportConfiguration reportConfig = new SimplePdfReportConfiguration();
        reportConfig.setSizePageToContent(true);
        reportConfig.setForceLineBreakPolicy(false);

        SimplePdfExporterConfiguration exportConfig = new SimplePdfExporterConfiguration();
        exportConfig.setMetadataAuthor(author);
        exportConfig.setEncrypted(true);
        exportConfig.setAllowedPermissionsHint("PRINTING");

        exporter.setConfiguration(reportConfig);
        exporter.setConfiguration(exportConfig);
        try {
       	
            exporter.exportReport();
            log.info("rrrrrrrrrr 2222222222222222 " + out.size());
			ArchivoSinpleServiceImpl archivoSinpleServiceImpl = new ArchivoSinpleServiceImpl();
			archivoSinpleServiceImpl.newFromOutputStream(out, fileName);
			archivoSinpleServiceImpl.getArchivoSinple().setNameOriginal(fileName);
			
			out.close();
			
			return archivoSinpleServiceImpl;
        } catch (Exception e) {
            throw new RuntimeException("Error en reporte " + e.getMessage());
        }finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					log.error("Error al cerrar Documento " + e.getMessage(), e);
				}
			}
		}

    }

    public void exportToXlsx(String fileName, String sheetName) {
        JRXlsxExporter exporter = new JRXlsxExporter();

        exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
        exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(fileName));

        SimpleXlsxReportConfiguration reportConfig = new SimpleXlsxReportConfiguration();
        reportConfig.setSheetNames(new String[] { sheetName });

        exporter.setConfiguration(reportConfig);

        try {
            exporter.exportReport();
        } catch (JRException e) {
        	throw new RuntimeException("Error en reporte " + e.getMessage());
        }
    }

    public void exportToCsv(String fileName) {
        JRCsvExporter exporter = new JRCsvExporter();

        exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
        exporter.setExporterOutput(new SimpleWriterExporterOutput(fileName));

        try {
            exporter.exportReport();
        } catch (JRException e) {
        	throw new RuntimeException("Error en reporte " + e.getMessage());
        }
    }

    public void exportToHtml(String fileName) {
        HtmlExporter exporter = new HtmlExporter();

        exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
        exporter.setExporterOutput(new SimpleHtmlExporterOutput(fileName));

        try {
            exporter.exportReport();
        } catch (JRException e) {
        	throw new RuntimeException("Error en reporte " + e.getMessage());
        }
    }
}
