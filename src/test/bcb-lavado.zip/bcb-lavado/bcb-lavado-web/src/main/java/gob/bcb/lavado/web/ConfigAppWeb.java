package gob.bcb.lavado.web;

import java.util.Arrays;

import java.util.Collection;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import gob.bcb.axesso.services.AxessoDaoServiceImpl;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.web.controller.SwfLoteFormController;
import gob.bcb.lavado.web.security.access.ExtendedWebSecurityExpressionHandler;

@ComponentScan(basePackageClasses = { AxessoDaoServiceImpl.class, SwfLoteFormController.class, ExtendedWebSecurityExpressionHandler.class })
@EnableAutoConfiguration
@EnableConfigurationProperties({ AppProperties.class })
@PropertySource(value = "file:" + Constants.BASE_DIR_APP + Constants.FILE_APPLICATION_WEB)
public class ConfigAppWeb {
	private static final Logger log = LoggerFactory.getLogger(ConfigAppWeb.class);
	@Autowired
	private Environment env;

	public ConfigAppWeb() {
		log.info("Creando ConfigAppWeb...");
	
	}

	/**
	 * Initializes myapp.
	 * <p>
	 * Spring profiles can be configured with a program arguments
	 * --spring.profiles.active=your-active-profile
	 * <p>
	 * You can find more information on how profiles work with JHipster on
	 * <a href="http://jhipster.github.io/profiles/">http://jhipster.github.io/
	 * profiles/</a>.
	 */
	@PostConstruct
	public void initApplication() {
		log.info("------- Params Server WEB -------");
		log.info("server.port : " + env.getProperty("server.port"));
		log.info("server.address: " + env.getProperty("server.address"));
		log.info("server.contextPath: " + env.getProperty("server.contextPath"));
		log.info("spring.application.name: " + env.getProperty("spring.application.name"));
		log.info("Running with Spring profile(s) : {}", Arrays.toString(env.getActiveProfiles()));
		Collection<String> activeProfiles = Arrays.asList(env.getActiveProfiles());
		if (activeProfiles.contains(Constants.SPRING_PROFILE_DEVELOPMENT) && activeProfiles.contains(Constants.SPRING_PROFILE_PRODUCTION)) {
			log.error("You have misconfigured your application! It should not run " + "with both the 'dev' and 'prod' profiles at the same time.");
		}
	}

}
