package gob.bcb.lavado.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.stereotype.Component; 
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.model.OfaBlacklist;
import gob.bcb.lavado.repository.OfaBlacklistRepository;
import gob.bcb.lavado.services.SwiftAdminDaoService;

@ManagedBean(name = "ofaBlacklistController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class OfaBlacklistController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(OfaBlacklistController.class);

	private List<OfaBlacklist> ofaBlacklistLista = new ArrayList<>();
	private OfaBlacklist ofaBlacklistSelected = new OfaBlacklist();
	
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
	@Autowired
	private OfaBlacklistRepository ofaBlacklistRepository;
	
	@PostConstruct
	public void init() {
		try {
			inicializar();
			recuperardatos();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}
	
	private void recuperardatos() {
		ofaBlacklistLista = ofaBlacklistRepository.findAll();
	}

	public String guardar() {
		try {
			ofaBlacklistSelected.setBlkAuditusr(getVisitBean().getUsuario().getUsrLogin());
			ofaBlacklistSelected.setBlkAuditwst(getVisitBean().getUsuario().getUsrAuditwst());			
			swiftAdminDaoService.actualizarOfaBlacklist(ofaBlacklistSelected, getVisitBean().getUsuario().getUsrAuditwst());
			recuperardatos() ;
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");
			return null;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			return null;
		}
	}
	public void eliminar(OfaBlacklist ofaBlacklist) {
		try {
			ofaBlacklist.setBlkAuditwst(getVisitBean().getUsuario().getUsrAuditwst());			
			swiftAdminDaoService.eliminarOfaBlacklist(ofaBlacklist);
			recuperardatos() ;
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}	
	public void nuevo() {
		ofaBlacklistSelected = new OfaBlacklist();
	}	
	public void selectItem(OfaBlacklist ofaBlacklistSelected) {
		this.ofaBlacklistSelected = ofaBlacklistRepository.findOne(ofaBlacklistSelected.getBlkId());
	}
	
	public List<OfaBlacklist> getOfaBlacklistLista() {
		return ofaBlacklistLista;
	}

	public void setOfaBlacklistLista(List<OfaBlacklist> ofaBlacklistLista) {
		this.ofaBlacklistLista = ofaBlacklistLista;
	}

	public OfaBlacklist getOfaBlacklistSelected() {
		return ofaBlacklistSelected;
	}

	public void setOfaBlacklistSelected(OfaBlacklist ofaBlacklistSelected) {
		this.ofaBlacklistSelected = ofaBlacklistSelected;
	}
}
