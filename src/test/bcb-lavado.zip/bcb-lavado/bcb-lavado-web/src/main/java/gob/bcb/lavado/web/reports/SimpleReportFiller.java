package gob.bcb.lavado.web.reports;

import java.io.InputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRSaver;

@Component
public class SimpleReportFiller {
	private static final Logger log = LoggerFactory.getLogger(SimpleReportFiller.class);
    private String reportFileName;

    private JasperReport jasperReport;

    private JasperPrint jasperPrint;

	@Autowired
	@Qualifier("dataSourceSwift")
	private DataSource dataSourceSwift;

    private Map<String, Object> parameters;

    public SimpleReportFiller() {
        parameters = new HashMap<>();
    }

    public void prepareReport() {
        compileReport();
        fillReport();
    }

    public void compileReport() {
        try {
            InputStream reportStream = getClass().getResourceAsStream("/".concat(reportFileName));
            jasperReport = JasperCompileManager.compileReport(reportStream);
            JRSaver.saveObject(jasperReport, reportFileName.replace(".jrxml", ".jasper"));
        } catch (JRException e) {
        	log.error(e.getMessage(), e);
        }
    }

    public void fillReport() {
        try {
            jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSourceSwift.getConnection());
        } catch (JRException | SQLException e) {
        	log.error(e.getMessage(), e);
        }
    }

    public void fillReport(String reportFileName) {
        try {
        	InputStream reportStream = getClass().getResourceAsStream("/".concat(reportFileName));
            jasperPrint = JasperFillManager.fillReport(reportStream, parameters, dataSourceSwift.getConnection());
        } catch (JRException | SQLException e) {
        	throw new RuntimeException(e.getMessage());
        }			
    }
    public DataSource getDataSource() {
        return dataSourceSwift;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSourceSwift = dataSource;
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }

    public String getReportFileName() {
        return reportFileName;
    }

    public void setReportFileName(String reportFileName) {
        this.reportFileName = reportFileName;
    }

    public JasperPrint getJasperPrint() {
        return jasperPrint;
    }

}
