package gob.bcb.lavado.web.security.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.web.WebAttributes;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/auth")
public class AuthenticationController {
	private static final Logger log = LoggerFactory.getLogger(AuthenticationController.class);	
	@RequestMapping("/error")
	public String errorLogin(HttpServletRequest request) {
		String mens = ""; 
		try{
			if (request.getSession().getAttribute(WebAttributes.AUTHENTICATION_EXCEPTION) != null){
				if (request.getSession().getAttribute(WebAttributes.AUTHENTICATION_EXCEPTION) instanceof InternalAuthenticationServiceException){
					mens = "Error en credenciales, cuenta de usuario bloqueada o en permisos asignados";
				} else {
					mens = (String) request.getSession().getAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);					
				}
			} else {
				log.error("ERROR!!!! Atributo WebAttributes.AUTHENTICATION_EXCEPTION NULO");
				mens = "Ocurrio un error al ingresar sus credenciales, intente nuevamente";
			}

		
		}catch (Exception e) {
			log.error("Error en AUTH: " + e.getMessage(), e);
			mens = "Error al ingresar sus credenciales, intente nuevamente " + e.getMessage().substring(10);
		}
		//log.info("errorLogin " + mens);
		return "redirect:/login.xhtml?msg_error=" + mens;
	}
}
