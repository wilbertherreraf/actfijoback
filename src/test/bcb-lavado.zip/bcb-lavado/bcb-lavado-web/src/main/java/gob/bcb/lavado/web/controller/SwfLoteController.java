package gob.bcb.lavado.web.controller;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.commons.ArchivoSinpleServiceImpl;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.services.AdminInOutMsgService;
import gob.bcb.lavado.services.SwiftBcbSearcherService;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

@ManagedBean(name = "swfLoteController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class SwfLoteController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(SwfLoteController.class);
	private SwfMensaje swfMensajeSelected = new SwfMensaje();
	private SwfLote swfLoteSelected = new SwfLote();
	private List<Block4> block4List = new ArrayList<>();
	private ArchivoSinpleServiceImpl archivoSinpleService;
	private List<MensajesDatos> mensajesDatosLista;

	@Autowired
	private AdminInOutMsgService adminInOutMsgService;
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;
	@PostConstruct
	public void init() {
		try {
			inicializar();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void handleFileUpload(FileUploadEvent event) {
		log.info("En handleFileUpload " + event.getFile().getFileName());
		UploadedFile file = event.getFile();
		InputStream stream;
		mensajesDatosLista = new ArrayList<MensajesDatos>();
		try {
			stream = file.getInputstream();
			archivoSinpleService = new ArchivoSinpleServiceImpl();
			archivoSinpleService.fileUpload(stream, file.getFileName());

			swfLoteSelected = new SwfLote();
			swfLoteSelected.setLotNomorig(archivoSinpleService.getArchivoSinple().getNameOriginal());

			mensajesDatosLista = adminInOutMsgService.desparsearLoteFromArchivoSinple(archivoSinpleService.getArchivoSinple(),
					getVisitBean().getUsuario().getUsrLogin());
			log.info("Mensajes lote cargados " + mensajesDatosLista.size());
			addMessageInfo("Mensajes de lote cargados: " + mensajesDatosLista.size(), "Mensajes de lote cargados: " + mensajesDatosLista.size());			
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}

	}

	public void seleccionarDetalle(MensajesDatos mensajesDatos) {
		log.debug("en seleccionarDetalle " + mensajesDatos.getMenCodmen());
		swfMensajeSelected = mensajesDatos.getSwfMensaje();
		block4List = new ArrayList<>();
		try {
			SwiftDatos swiftDatos = swiftBcbSearcherService.mensajePlanoToSwfMensaje(mensajesDatos.getSwfMensaje().getMenPlano(),true);
			SwfMensaje swfMensaje = swiftDatos.getSwfMensaje(); 
			block4List = swfMensaje.getBlock4List();			
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public String guardarLoteMensajes() {
		try {
			if (mensajesDatosLista == null || mensajesDatosLista.size() <= 0) {
				showMessageError("No existe mensajes cargados", "No existe mensajes cargados");
				return null;
			}
			log.info("Inicio guardar lote ... " + mensajesDatosLista.size() + " [registros]");
			Integer codEmp = Integer.valueOf(getVisitBean().getUsuario().getUsrCodemp());
			swfLoteSelected.setLotAuditusr(getVisitBean().getCurrentUserLogin());
			swfLoteSelected.setLotAuditwst(getVisitBean().getUsuario().getUsrAuditwst());
			swfLoteSelected = adminInOutMsgService.guardarLote(codEmp, swfLoteSelected, archivoSinpleService.getArchivoSinple(), mensajesDatosLista);

			log.info("lote [" + swfLoteSelected.getLotNrolote() + "] SALVADO!!! " + mensajesDatosLista.size() + " [registros] EN "
					+ swfLoteSelected.getLotPathfile() + " HASH " + swfLoteSelected.getLotHash() + " POR " + getVisitBean().getUsuario().getUsrCodemp());
			addMessageInfo("La operación se realizó exitósamente", "La operación se realizó exitósamente");
			redirect("/view/procesos/lote_view", "VIEW_ASIGNA");
			return "/view/procesos/lote_view?faces-redirect=true";
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			return null;
		}
	}

	public SwfLote getSwfLoteSelected() {
		return swfLoteSelected;
	}

	public void setSwfLoteSelected(SwfLote swfLoteSelected) {
		this.swfLoteSelected = swfLoteSelected;
	}

	public SwfMensaje getSwfMensajeSelected() {
		return swfMensajeSelected;
	}

	public void setSwfMensajeSelected(SwfMensaje swfMensajeSelected) {
		this.swfMensajeSelected = swfMensajeSelected;
	}

	public List<MensajesDatos> getMensajesDatosLista() {
		if(mensajesDatosLista == null)
			return new ArrayList<MensajesDatos>();
		return mensajesDatosLista;
	}

	public List<Block4> getBlock4List() {
		return block4List;
	}

	public void setBlock4List(List<Block4> block4List) {
		this.block4List = block4List;
	}
}
