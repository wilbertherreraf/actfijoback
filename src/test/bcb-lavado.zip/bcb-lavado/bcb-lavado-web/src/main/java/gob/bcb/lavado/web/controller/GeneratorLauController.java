package gob.bcb.lavado.web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.client.HandlerGeneratorLauSrv;
import gob.bcb.lavado.client.lau.GeneratorLAU;
import gob.bcb.lavado.client.pojos.GenLauDto;
import gob.bcb.lavado.client.utils.GeneradorPassword;
import gob.bcb.lavado.client.utils.UtilsGeneric;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.lavado.services.SwiftAdminDaoService;
import gob.bcb.lavado.services.SwiftAdminDaoServiceImpl;

@ManagedBean(name = "generatorLauController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class GeneratorLauController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(GeneratorLauController.class);

	private GenLauDto genLauDtoCurrent = new GenLauDto();
	private GenLauDto genLauDtoNew = new GenLauDto();
	private GenLauDto genLauDtoNewInDDB = new GenLauDto();
	private SwfParams swfParamsCODIGOLAU = new SwfParams();
	private SwfParams swfParamsCORREOSCODLAU = new SwfParams();
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;

	@PostConstruct
	public void init() {
		try {
			inicializar();
			recuperardatos();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	private void recuperardatos() throws Exception {
		genLauDtoCurrent = HandlerGeneratorLauSrv.getGeneratorLAU().getGenLauDto();
		swfParamsCODIGOLAU = swfParamsDao.findByCod(Constants.PARAM_CODIGOLAU);
		if (swfParamsCODIGOLAU == null) {
			// log.info("Creando parámetro correo lau por defecto");
			swfParamsCODIGOLAU = new SwfParams();
			swfParamsCODIGOLAU.setParCodpar(Constants.PARAM_CODIGOLAU);
			swfParamsCODIGOLAU.setParDescrip("DATOS CODIGO LAU NUEVO");
		}

		genLauDtoNew = GeneratorLAU.getGenLauDtoFromStringEncoded(swfParamsCODIGOLAU.getParValor());
		genLauDtoNewInDDB = GeneratorLAU.getGenLauDtoFromStringEncoded(swfParamsCODIGOLAU.getParValor());
//		if (SwiftAdminDaoServiceImpl.isEqualsCodelau(genLauDtoCurrent, genLauDtoNew)) {
			// el actual es identico al nuevo
			genLauDtoNew.setLauKeyFirstPart("");
			genLauDtoNew.setLauKeySecondPart("");
			genLauDtoNew.setFechaCreacion(new Date());
			genLauDtoNew.setDiasVigencia(GeneratorLAU.LAU_KEY_DIASVIGENCIA_DEFAULT);
			genLauDtoNew.setLauEstado("");
//		}

		swfParamsCORREOSCODLAU = swfParamsDao.findByCod(Constants.PARAM_CORREOSCODLAU);
		if (swfParamsCORREOSCODLAU == null) {
			// log.info("Creando parámetro correo lau por defecto");
			swfParamsCORREOSCODLAU = new SwfParams();
			swfParamsCORREOSCODLAU.setParCodpar(Constants.PARAM_CORREOSCODLAU);
			swfParamsCORREOSCODLAU.setParDescrip("CORREO DESTINARIO DE ADMINISTRADOR SIST. ALLIANCE SWIFT(separado por comas)");
		}
	}

	public void botonGenerarNuevo() {
		try {
			GeneradorPassword generadorPassword = new GeneradorPassword(GeneratorLAU.LAU_KEY_LENGTH, true, true, false, true, GeneratorLAU.LAU_KEY_LENGTH_CHARS_REPEAT);

			genLauDtoNew.setFechaCreacion(new Date());

			generadorPassword.generatePasswordUntilValid();
			genLauDtoNew.setLauKeyFirstPart(generadorPassword.getPassword());
			generadorPassword.generatePasswordUntilValid();
			genLauDtoNew.setLauKeySecondPart(generadorPassword.getPassword());
			genLauDtoNew.setLauEstado("NUEVO");

		} catch (Exception e) {
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void botonGuardarYEnviarNotificacionAAdmSwift() {
		try {
			swiftAdminDaoService.guardarNuevoLauYNotificarAdmSwift(swfParamsCODIGOLAU, swfParamsCORREOSCODLAU, genLauDtoCurrent, genLauDtoNew,
					getVisitBean().getCurrentUserLogin(), getVisitBean().getUsuario().getUsrAuditwst());
			recuperardatos();
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");
		} catch (Exception e) {
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void botonActivarNuevo() {
		try {
			swiftAdminDaoService.activarCodigoLauNuevo(getVisitBean().getCurrentUserLogin(), getVisitBean().getUsuario().getUsrAuditwst());
			recuperardatos();
			addMessageInfo("Operación exitosa", "La operación fue realizada exitósamente.");
		} catch (Exception e) {
			log.error("error al actualizar lau " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public GenLauDto getGenLauDtoCurrent() {
		return genLauDtoCurrent;
	}

	public GenLauDto getGenLauDtoNew() {
		return genLauDtoNew;
	}

	public SwfParams getSwfParamsCORREOSCODLAU() {
		return swfParamsCORREOSCODLAU;
	}

	public boolean isExistsNewCode() {
		return (genLauDtoNew != null) && (genLauDtoNew.getLauEstado() != null && genLauDtoNew.getLauEstado().equals("NUEVO"));
	}

	public boolean isCanActivate() {
		try{
		if ((swfParamsCODIGOLAU == null) || (swfParamsCODIGOLAU.getParValor() == null)) {
			return false;
		}
		return !SwiftAdminDaoServiceImpl.isEqualsCodelau(genLauDtoCurrent, genLauDtoNewInDDB) && (swfParamsCODIGOLAU != null)
				&& (swfParamsCODIGOLAU.getParValor() != null);
		}catch (Exception e) {
			log.error("eeeeerrr " + e.getMessage(),e);
			return false;
		}
	}

	public GenLauDto getGenLauDtoNewInDDB() {
		return genLauDtoNewInDDB;
	}
}
