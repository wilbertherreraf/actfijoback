package gob.bcb.lavado.web.controller;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.model.SwfNumeraswf;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.services.NumeracionSwiftService;

@ManagedBean(name = "swfNumeraConfController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST)

public class SwfNumeraConfController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(SwfNumeraConfController.class);

	private SwfPersona swfPersonaSelected = new SwfPersona();
	private SwfNumeraswf swfNumeraswfSelected = new SwfNumeraswf();
	@Autowired
	private NumeracionSwiftService numeracionSwiftService;

	@PostConstruct
	public void init() {
		try {
			log.info("==> inicializar Ingresando a " + this.getClass().getName() );
			recuperarParametros();
			String parIdver = (String) getVisitBean().getParametro("idver");
			String parCodempStr = (String) getVisitBean().getParametro("codper");
			
			Integer parCodemp = parCodempStr != null && NumberUtils.isNumber(parCodempStr) ? Integer.valueOf(parCodempStr) : null;			
			log.info("enn confirmacion {} parIdver: {}", parCodempStr, parIdver);
			
			if (parCodemp != null && parIdver != null && !parIdver.isEmpty()) {
				initConfirmacion(parCodemp, parIdver);
			} 
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		} finally {
			//getVisitBean().removeParametro("idver");
		}
	}

	private void initVars() {
		swfPersonaSelected = new SwfPersona();
		swfNumeraswfSelected = new SwfNumeraswf();
	}

	private void initConfirmacion(Integer codEmp, String idver) {
		try {
			if (StringUtils.isBlank(idver)) {
				return;
			}
			swfNumeraswfSelected = numeracionSwiftService.obtenerSolicitudVig(codEmp,idver);
		} catch (Exception e) {
			log.error("error init confirmacion " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			swfNumeraswfSelected.setNroNroswift(null);
		}
	}

	public void confirmarNro() {
		try {
			log.info("En aceptacion {} de nro session {} ", swfNumeraswfSelected.getNroNroswift(), swfNumeraswfSelected.getNroIdverifica());

			numeracionSwiftService.confirmacionSolicitud(swfNumeraswfSelected.getNroCodnro(), swfNumeraswfSelected.getNroIdverifica(), swfNumeraswfSelected.getNroNroswift());

			addMessageInfo("Número swift asignado correctamente.", "");
			log.info("Numero swift asignado {} a {} ", swfNumeraswfSelected.getNroIdverifica(), swfNumeraswfSelected.getNroCodemp());
			// redirect("/index", "");
			//initVars();
			getVisitBean().removeParametro("idver");
			//redirect("/public/nroswift/?faces-redirect=true", "");
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			initVars();
			showMessageError(e.getMessage(), e.getMessage());
		}

	}

	public void btnIrASolicitud() {
		log.info("Ir a nueva solicitud");
		redirect("/public/nroswift/?faces-redirect=true", "");
	}

	public SwfNumeraswf getSwfNumeraswfSelected() {
		return swfNumeraswfSelected;
	}

	public SwfPersona getSwfPersonaSelected() {
		return swfPersonaSelected;
	}

}
