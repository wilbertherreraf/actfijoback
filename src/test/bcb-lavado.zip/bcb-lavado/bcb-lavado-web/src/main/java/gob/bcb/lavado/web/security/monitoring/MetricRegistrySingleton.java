package gob.bcb.lavado.web.security.monitoring;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Slf4jReporter;

import gob.bcb.lavado.commons.Constants;

public final class MetricRegistrySingleton {
	private static final Logger log = LoggerFactory.getLogger(MetricRegistrySingleton.class);
    public static final MetricRegistry metrics = new MetricRegistry();

    static {
    	final int v = (97 + (int) (Math.random() * 26)); 
        Logger logger = LoggerFactory.getLogger("lavado" + v);
        final Slf4jReporter reporter = Slf4jReporter.forRegistry(metrics).outputTo(logger).convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS).build();
        reporter.start(Constants.METRIC_TIME_REPORTER, TimeUnit.MINUTES);
        log.info("inicializado MetricRegistry " + v);
    }

    private MetricRegistrySingleton() {
        throw new AssertionError();
    }

}
