package gob.bcb.lavado.web.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.HiddenHttpMethodFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import javax.servlet.Filter;

//public class WebInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {
	public class WebInitializer{ 	
	private static final Logger log = LoggerFactory.getLogger(WebInitializer.class);

	//@Override
	protected Class<?>[] getRootConfigClasses() {
		log.info("WebInitializer RootConfigClasses");
		//return new Class<?>[] { MvcConfig.class };
		return null;
	}

	//@Override
	protected Class<?>[] getServletConfigClasses() {
		log.info("WebInitializer ServletConfigClasses");		
		//return new Class<?>[] { MvcConfig.class };
		return null;
	}

	//@Override
	protected String[] getServletMappings() {
		log.info("WebInitializer ServletMappings");		
		//return new String[] { "/" };
		return null;		
	}

	//@Override
	protected Filter[] getServletFilters() {
		log.info("WebInitializer ServletFilters");		
		CharacterEncodingFilter cef = new CharacterEncodingFilter();
		cef.setEncoding("UTF-8");
		cef.setForceEncoding(true);
		return new Filter[] { new HiddenHttpMethodFilter(), cef };
	}

}