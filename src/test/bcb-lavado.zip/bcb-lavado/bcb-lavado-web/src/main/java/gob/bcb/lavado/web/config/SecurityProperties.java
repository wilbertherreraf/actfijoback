package gob.bcb.lavado.web.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "security", ignoreUnknownFields = false)
public class SecurityProperties {
	private static final Logger log = LoggerFactory.getLogger(SecurityProperties.class);	
	private String filekeystore;

	public SecurityProperties() {
		log.info("creando SecurityProperties ........");
	}
	public String getFilekeystore() {
		return filekeystore;
	}

	public void setFilekeystore(String fileKeystore) {
		log.info("setFileKeystore: " + fileKeystore);		
		this.filekeystore = fileKeystore;
	}
}
