package gob.bcb.lavado.web.security;

import java.util.ArrayList;

import java.util.Collection;
import java.util.List;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.Assert;

import gob.bcb.lavado.web.config.ConstantsSec;

/**
 * Utility class for Spring Security.
 */
public final class SecurityUtils {

	private SecurityUtils() {
	}

	/**
	 * Get the login of the current user.
	 *
	 * @return the login of the current user
	 */
	public static String getCurrentUserLogin() {
		SecurityContext securityContext = SecurityContextHolder.getContext();
		if (securityContext == null)
			return null;

		Authentication authentication = securityContext.getAuthentication();
		String userName = null;
		if (authentication != null) {
			if (authentication.getPrincipal() instanceof UserDetails) {
				UserDetails springSecurityUser = (UserDetails) authentication.getPrincipal();
				userName = springSecurityUser.getUsername();
			} else if (authentication.getPrincipal() instanceof String) {
				userName = (String) authentication.getPrincipal();
			}
		}
		return userName;
	}

	/**
	 * Check if a user is authenticated.
	 *
	 * @return true if the user is authenticated, false otherwise
	 */
	public static boolean isAuthenticated() {
		SecurityContext securityContext = SecurityContextHolder.getContext();
		if (securityContext == null || securityContext.getAuthentication() == null)
			return false;
		if (securityContext.getAuthentication() instanceof AnonymousAuthenticationToken) {
			return false;
		}
		Collection<? extends GrantedAuthority> authorities = securityContext.getAuthentication().getAuthorities();
		if (authorities != null) {
			for (GrantedAuthority authority : authorities) {
				if (authority.getAuthority().equals(ConstantsSec.ANONYMOUS)) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * If the current user has a specific authority (security role).
	 *
	 * <p>
	 * The name of this method comes from the isUserInRole() method in the
	 * Servlet API
	 * </p>
	 *
	 * @param authority
	 *            the authorithy to check
	 * @return true if the current user has the authority, false otherwise
	 */
	public static boolean isCurrentUserInRole(String authority) {
		SecurityContext securityContext = SecurityContextHolder.getContext();
		if (securityContext == null)
			return false;
		Authentication authentication = securityContext.getAuthentication();
		if (authentication != null) {
			if (authentication.getPrincipal() instanceof UserDetails) {
				UserDetails springSecurityUser = (UserDetails) authentication.getPrincipal();
				return springSecurityUser.getAuthorities().contains(new SimpleGrantedAuthority(authority));
			}
		}
		return false;
	}

	public static List getRolesIfSignedIn() {
		List roles = new ArrayList();
		if (isAuthenticated()) {
			SecurityContext securityContext = SecurityContextHolder.getContext();
			if (securityContext == null)
				return roles;
			Authentication authentication = securityContext.getAuthentication();
			if (authentication != null)
				for (GrantedAuthority authority : authentication.getAuthorities()) {
					roles.add(authority.getAuthority());
				}
		}
		return roles;
	}

	public static SecurityUser getAuthenticatedUser() {
		final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Assert.notNull(authentication, "Lack of logged user in security context !");
		Assert.isTrue(!(authentication instanceof AnonymousAuthenticationToken));
		Assert.isTrue(authentication.isAuthenticated());

		return (SecurityUser) authentication.getPrincipal();
	}

	public static boolean isUserAnonymous() {
		return !isAuthenticated() || (SecurityContextHolder.getContext().getAuthentication() instanceof AnonymousAuthenticationToken);
	}
	
	public static void clearContext(){
		SecurityContextHolder.clearContext();
	}
	
    public static void clearSecurityContext(){
        SecurityContextHolder.getContext().setAuthentication(null);
    }
	
}
