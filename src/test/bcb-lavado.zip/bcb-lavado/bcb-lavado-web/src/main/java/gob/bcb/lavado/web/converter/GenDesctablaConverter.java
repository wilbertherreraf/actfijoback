package gob.bcb.lavado.web.converter;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.model.GenDesctabla;
import gob.bcb.lavado.repository.GenDesctablaDao;
import gob.bcb.lavado.web.controller.BaseBean;

@FacesConverter("genDesctablaConverter")
public class GenDesctablaConverter extends BaseBean implements Converter  {
	private static final Logger log = LoggerFactory.getLogger(GenDesctablaConverter.class);
	@Autowired
	private GenDesctablaDao genDesctablaDao; 
	@Override
	public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
		log.info("ccc " + value);
        if(value != null && value.trim().length() > 0) {
            try {
            	GenDesctabla g = genDesctablaDao.findByDesCodtab(2, Integer.parseInt(value));
                return g;
            } catch(NumberFormatException e) {
                throw new ConverterException(new FacesMessage(FacesMessage.SEVERITY_ERROR, "Conversion Error", "Not a valid theme."));
            }
        }
        else {
            return null;
        }
//		log.info("ccc " + value);
//		return null;
    }

	@Override
	public String getAsString(FacesContext fc, UIComponent uic, Object object) {

        if(object != null) {
    		log.info("cccaaaaa " + (((GenDesctabla) object).getId().getDesCodigo()));        	
            return String.valueOf(((GenDesctabla) object).getId().getDesCodigo());
        }
        else {
            return null;
        }
//		GenDesctabla g = (GenDesctabla) object;
		//log.info("cccaaaaa " + g.getDesDescrip());		
		//return null;
    }   

}
