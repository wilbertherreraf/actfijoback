package gob.bcb.lavado.web.controller;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.commons.ArchivoSinpleServiceImpl;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.repository.SwfLoteDao;
import gob.bcb.lavado.services.SwiftAdminDaoService;

@ManagedBean(name = "loadListOfacController")
@ViewScoped
@Component
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class LoadListOfacController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(LoadListOfacController.class);

	private SwfLote swfLoteSelected = new SwfLote();
	private ArchivoSinpleServiceImpl archivoSinpleService;
	private List<SwfLote> swfLoteLista = new ArrayList<SwfLote>();

	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
	@Autowired
	private SwfLoteDao swfLoteDao;

	@PostConstruct
	public void init() {
		try {
			inicializar();
			getLoteLista();
		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	private void getLoteLista() {
		swfLoteLista = swfLoteDao.findByTipolote(Constants.TIPO_LOTE_OFAC);
	}

	public void handleFileUpload(FileUploadEvent event) {
		log.info("En handleFileUpload " + event.getFile().getFileName());
		UploadedFile file = event.getFile();
		InputStream stream;
		try {
			stream = file.getInputstream();

			archivoSinpleService = new ArchivoSinpleServiceImpl();
			archivoSinpleService.fileUpload(stream, file.getFileName());

			swfLoteSelected = new SwfLote();
			swfLoteSelected.setLotNomorig(file.getFileName());
			log.info("Dir temporal: " + archivoSinpleService.getArchivoSinple().getPathFile());

		} catch (Exception e) {
			log.error("error al iniciar " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void guardarLoteMensajes() {
		try {
			log.info("En guardarLoteMensajes ");
			if (swfLoteSelected.getLotNrolote() != null) {
				throw new RuntimeException("Existe un proceso anterior, cargue nuevamente el archivo");
			}
			if (archivoSinpleService == null)
				throw new RuntimeException("Parametro archivo xml nulo, cargue el archivo correspondiente.");
			swfLoteSelected = swiftAdminDaoService.guardarLoteOfac(getVisitBean().getCurrentUserLogin(), archivoSinpleService.getArchivoSinple(), getVisitBean().getUsuario().getUsrAuditwst());

			getLoteLista();

			log.info("lote [" + swfLoteSelected.getLotNrolote() + "] SALVADO!!! EN " + swfLoteSelected.getLotPathfile() + " HASH "
					+ swfLoteSelected.getLotHash() + " POR " + getVisitBean().getCurrentUserLogin());
			addMessageInfo("El proceso concluyo exitósamente", "El proceso concluyo exitósamente");

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void guardarLoteMensajesSec() {
		try {
			log.info("En guardarLoteMensajesSec {}", getVisitBean().getCurrentUserLogin());
			if (swfLoteSelected.getLotNrolote() != null) {
				throw new RuntimeException("Existe un proceso anterior, cargue nuevamente el archivo");
			}
			if (archivoSinpleService == null)
				throw new RuntimeException("Parametro archivo xml nulo, cargue el archivo correspondiente.");
			swfLoteSelected = swiftAdminDaoService.guardarLoteOfacSec(getVisitBean().getCurrentUserLogin(), archivoSinpleService.getArchivoSinple(), getVisitBean().getUsuario().getUsrAuditwst());

			getLoteLista();

			log.info("lote [" + swfLoteSelected.getLotNrolote() + "] SALVADO!!! EN " + swfLoteSelected.getLotPathfile() + " HASH "
					+ swfLoteSelected.getLotHash() + " POR " + getVisitBean().getCurrentUserLogin());
			addMessageInfo("El proceso concluyo exitósamente", "El proceso concluyo exitósamente");

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}
	
	public void indexListaOfac() {
		log.info("ofacIndexer ");
		try {
			swiftAdminDaoService.indexOfaSdnentry();
			addMessageInfo("El proceso concluyo exitósamente", "El proceso concluyo exitósamente");
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}
	public void indexListaLvd() {
		log.info("indexListaLvd ");
		try {
			swiftAdminDaoService.indexLvdEntities();
			addMessageInfo("El proceso concluyo exitósamente", "El proceso concluyo exitósamente");
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}	

	public void truncarListaOfac() {
		log.info("truncarListaOfac ");
		try {
			swiftAdminDaoService.truncarListaOfac(getVisitBean().getUsuario().getUsrLogin(),getVisitBean().getUsuario().getUsrAuditwst());
			getLoteLista();
			addMessageInfo("El proceso concluyo exitósamente", "El proceso concluyo exitósamente");
		} catch (Throwable e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public void loadListsFromDirectory() {
		log.info("loadListsFromDirectory ");
		try {
			swiftAdminDaoService.loadListsFromDirectory(getVisitBean().getUsuario().getUsrLogin(),getVisitBean().getUsuario().getUsrAuditwst());
			getLoteLista();
			addMessageInfo("El proceso concluyo exitósamente", "El proceso concluyo exitósamente");
		} catch (Throwable e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}

	public SwfLote getSwfLoteSelected() {
		return swfLoteSelected;
	}

	public void setSwfLoteSelected(SwfLote swfLoteSelected) {
		this.swfLoteSelected = swfLoteSelected;
	}

	public List<SwfLote> getSwfLoteLista() {
		return swfLoteLista;
	}

	public void setSwfLoteLista(List<SwfLote> swfLoteLista) {
		this.swfLoteLista = swfLoteLista;
	}

}
