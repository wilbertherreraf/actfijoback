package gob.bcb.lavado.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import gob.bcb.lavado.QL.rrhh.PlafinQLBean;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.GenDesctabla;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.UnidadOrgCoin;
import gob.bcb.lavado.repository.GenDesctablaDao;
import gob.bcb.lavado.repository.SwfAsignamensajeDao;
import gob.bcb.lavado.repository.SwfPersonaDao;

@ManagedBean(name = "swfPersonaController")
@ViewScoped
@Component
//@Scope("prototype")
@Scope(value = WebApplicationContext.SCOPE_SESSION)
public class SwfPersonaController extends BaseBean {
	private static final Logger log = LoggerFactory.getLogger(SwfPersonaController.class);
	private List<SwfPersona> swfPersonaLista = new ArrayList<SwfPersona>();
	private SwfPersona swfPersonaSelected = new SwfPersona();
	private List<UnidadOrgCoin> unidadOrgCoinLista = new ArrayList<UnidadOrgCoin>();
	private Map<Integer, Empleado> empleadoMap = new HashMap<Integer, Empleado>();

	@Autowired
	private GenDesctablaDao genDesctablaDao;
	@Autowired
	private SwfPersonaDao swfPersonaDao;
	@Autowired
	private PlafinQLBean plafinQLBean;
	@Autowired
	private SwfAsignamensajeDao swfAsignamensajeDao0;
	private List<GenDesctabla> genDesctablaStatregList = new ArrayList<GenDesctabla>();
	
	@PostConstruct
	public void init() {
		inicializar();
		
		unidadOrgCoinLista = plafinQLBean.unidadesOrg();
		recuperardatos();
	}

	private void recuperardatos() {
		empleadoMap = new HashMap<Integer, Empleado>();
		swfPersonaLista = swfPersonaDao.getAll();
		genDesctablaStatregList = genDesctablaDao.findByDesCodtab(Constants.TAB_STATREG);
		
		for (SwfPersona swfPersona : swfPersonaLista) {
			Empleado empleado = plafinQLBean.findEmpleado(swfPersona.getPerCodemp(), true);

			if (empleado != null) {
			} else {
				empleado = new Empleado();
			}

			UnidadOrgCoin unidadOrgCoin = null;

			String areCod = swfPersona.getPerArecod();

			if (!StringUtils.isBlank(areCod) && NumberUtils.isNumber(areCod)) {
				unidadOrgCoin = plafinQLBean.unidadOrgByCodigo(Integer.valueOf(areCod));
			}
			
			if (unidadOrgCoin!= null)
				empleado.setDescUnidadOrg(unidadOrgCoin.getDescUnidadOrg());
			
			empleadoMap.put(swfPersona.getPerCodemp(), empleado);
			
			GenDesctabla genDesctablaTip = genDesctablaDao.findByDesCodtab(swfPersona.getPerTabstatreg(), swfPersona.getPerStatreg());
			swfPersona.setGenDesctablaStatreg(genDesctablaTip != null ? genDesctablaTip : new GenDesctabla());
		}
	}

	public String guardarPersona() {
		try {
			swfPersonaSelected.setPerAuditusr(getVisitBean().getCurrentUserLogin());
			swfPersonaSelected.setPerAuditwst(getVisitBean().getUsuario().getUsrAuditwst());
			if (StringUtils.isBlank(swfPersonaSelected.getPerEmail())){
				throw new RuntimeException("Valor de Correo inválido");				
			}
			SwfPersona swfPersona = swfPersonaDao.saveorupdate(swfPersonaSelected);
			recuperardatos() ;
			addMessageInfo("El registro se actualizó con código: " + swfPersona.getPerCodemp(), "La operación fue realizada exitósamente.");
			return null;
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
			return null;
		}
	}
	
	public void eliminarPersona(SwfPersona swfPersonaSelect) {
		try {
			swfPersonaDao.cambiarEstado(swfPersonaSelect.getPerCodemp(), Constants.TAB_STATREG_SUSP, getVisitBean().getCurrentUserLogin(), getVisitBean().getUsuario().getUsrAuditwst());
			recuperardatos() ;
			addMessageInfo("El registro se fue eliminado exitósamente", "La operación fue realizada exitósamente.");
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}
	public void activarPersona(SwfPersona swfPersonaSelect) {
		try {
			swfPersonaDao.cambiarEstado(swfPersonaSelect.getPerCodemp(), Constants.TAB_STATREG_VIG, getVisitBean().getCurrentUserLogin(), getVisitBean().getUsuario().getUsrAuditwst());
			recuperardatos() ;
			addMessageInfo("El registro se fue eliminado exitósamente", "La operación fue realizada exitósamente.");
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			showMessageError(e.getMessage(), e.getMessage());
		}
	}	
	public void nuevo() {
		swfPersonaSelected = new SwfPersona();
	}
	public void selectItem(SwfPersona swfPersonaSelect) {
		this.swfPersonaSelected = swfPersonaDao.findByCodigo(swfPersonaSelect.getPerCodemp());
	}

	public List<SwfPersona> getSwfPersonaLista() {
		return swfPersonaLista;
	}

	public void setSwfPersonaLista(List<SwfPersona> swfPersonaLista) {
		this.swfPersonaLista = swfPersonaLista;
	}

	public SwfPersona getSwfPersonaSelected() {
		return swfPersonaSelected;
	}

	public void setSwfPersonaSelected(SwfPersona swfPersonaSelected) {
		this.swfPersonaSelected = swfPersonaSelected;
	}

	public List<UnidadOrgCoin> getUnidadOrgCoinLista() {
		return unidadOrgCoinLista;
	}

	public void setUnidadOrgCoinLista(List<UnidadOrgCoin> unidadOrgCoinLista) {
		this.unidadOrgCoinLista = unidadOrgCoinLista;
	}
	
	public Empleado getEmpleado(Integer codEmp){
		return (Empleado) empleadoMap.get(codEmp);
	}
	
	public boolean isNuevo(){
		return (swfPersonaSelected.getPerCodemp() == null);
	}

	public List<GenDesctabla> getGenDesctablaStatregList() {
		return genDesctablaStatregList;
	}

}
