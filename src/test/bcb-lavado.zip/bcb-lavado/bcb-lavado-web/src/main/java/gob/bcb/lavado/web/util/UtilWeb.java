/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-jee-web
 * gob.bcb.jee.admdjd.util.UtilWeb
 * 12/03/2016 - 18:34:00
 * Creado por ysalinas
 */
package gob.bcb.lavado.web.util;

import org.primefaces.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Clase encargada de proveer funciones generales para la aplicacion
 * 
 * @author ysalinas
 */
public class UtilWeb {
	private static final Logger log = LoggerFactory.getLogger(UtilWeb.class);

	/**
	 * Redirecciona a una pagina determinada.
	 * 
	 * @param <code>String</code>
	 *            url
	 */
	public static void redireccionarURL(String url) {
		log.trace("Redireccionando a: " + url);
		log.info("REDIRECCIONANDO A " + url);

		try {
			FacesContext fc = FacesContext.getCurrentInstance();
			ExternalContext ec = fc.getExternalContext();

			ec.redirect(url);

			log.trace("Redireccionamiento satisfactorio.");
			log.info("Redireccionamiento satisfactorio.");
		} catch (IOException e) {
			log.error("Error en la redireccion a url: " + url + ". " + e.getMessage().toString());
		}
	}

	/**
	 * Metodo que carga la lista de propiedades de un archivo .properties
	 * 
	 * @param nombrePropiedades
	 * @return
	 */
	public Properties cargarPropiedades(String nombrePropiedades) {
		InputStream inputStream = null;
		Properties properties = new Properties();
		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
			// inputStream = new
			// FileInputStream(classLoader.getResource(nombrePropiedades).getFile());
			inputStream = classLoader.getResourceAsStream("/" + nombrePropiedades);
			Reader reader = new InputStreamReader(inputStream, "ISO-8859-1");
			properties.load(reader);
		} catch (Exception e) {
			log.error("Error al cargar propiedades", e);
		} finally {
			if (inputStream != null)
				try {
					inputStream.close();
				} catch (IOException e) {
					log.error("Error al cerrar el archivo de propiedades", e);
				}
		}
		return properties;
	}

	/**
	 * Metodo que realiza la generacion de un hash a partir de un String
	 * 
	 * 
	 * @param msg
	 * @return
	 */
	public static String getHash(String msg) {
		String res = "";
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			byte[] buffer = msg.getBytes();
			messageDigest.reset();
			messageDigest.update(buffer);
			byte[] resumen = messageDigest.digest();

			res = "";
			for (int i = 0; i < resumen.length; i++) {
				res += Integer.toHexString((resumen[i] >> 4) & 0xf);
				res += Integer.toHexString(resumen[i] & 0xf);
			}
		} catch (java.security.NoSuchAlgorithmException e) {
			log.error("Error al generar HASH para:" + msg, e);
		}
		return res;
	}

	/**
	 * Obtiene el IP del cliente que se conecta a la aplicacion.
	 * 
	 * @return
	 */
	public static String getIPRemoto() {
		try {
			HttpServletRequest httpServletRequest = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			String ip = httpServletRequest.getRemoteAddr();
			log.info("IP conectado: " + ip);
			return ip;
		} catch (Exception e) {
			log.error("Error al obtener el IP remoto", e);
			return null;
		}
	}

	/**
	 * Metodo para ejecutar un javascript
	 * 
	 * 
	 * @param script
	 */
	public static void executeScript(String script) {
		RequestContext requestContext = RequestContext.getCurrentInstance();
		requestContext.execute(script);
	}

	/**
	 * Metodo que cuenta el numero de coincidencias de una cadena en otra
	 * 
	 * 
	 * @param cadena
	 * @param buscar
	 * @return
	 */
	public static Integer countString(String cadena, String buscar) {
		int count = 0;
		int idx = 0;

		while ((idx = cadena.indexOf(buscar, idx)) != -1) {
			idx++;
			count++;
		}
		return count;
	}

	private static final BigDecimal MAX_BIG_DECIMAL = new BigDecimal("9999999999999.15");

	public static BigDecimal getMaxBigDecimal() {
		return MAX_BIG_DECIMAL;
	}

	/**
	 * Obtiene el primer dia del mes actual
	 * 
	 * 
	 * @return
	 */
	public static Date getFirstDateOfCurrentMonth() {
		Calendar aCalendar = Calendar.getInstance();

		aCalendar.set(Calendar.DATE, 1);
		aCalendar.set(Calendar.HOUR_OF_DAY, 0);
		aCalendar.set(Calendar.MINUTE, 0);
		aCalendar.set(Calendar.SECOND, 0);
		return aCalendar.getTime();
	}

	public static Date getLastHourFromNow() {
		Calendar aCalendar = Calendar.getInstance();
		aCalendar.set(Calendar.HOUR_OF_DAY, aCalendar.get(Calendar.HOUR_OF_DAY) - 1);
		return aCalendar.getTime();
	}

	/**
	 * Obtiene el utlimo dia del mes actual
	 * 
	 * 
	 * @return
	 */
	public static Date getLastDateOfCurrentMonth() {
		Calendar aCalendar = Calendar.getInstance();

		aCalendar.set(Calendar.DATE, aCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		aCalendar.set(Calendar.HOUR_OF_DAY, 23);
		aCalendar.set(Calendar.MINUTE, 59);
		aCalendar.set(Calendar.SECOND, 59);
		return aCalendar.getTime();
	}

	/**
	 * Obtiene la Hora inicial del Dia
	 * 
	 * 
	 * @return
	 */
	public static Date getFirstDayHour() {
		Calendar calendar = Calendar.getInstance();

		calendar.set(Calendar.DATE, Calendar.getInstance().get(Calendar.DATE));
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return calendar.getTime();
	}

	/**
	 * Obtiene la ultima hora del dia
	 * 
	 * 
	 * @return
	 */
	public static Date getLastDayHour() {
		Calendar calendar = Calendar.getInstance();

		calendar.set(Calendar.DATE, Calendar.getInstance().get(Calendar.DATE));
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		return calendar.getTime();
	}

	/**
	 * Validador de formatos de emails
	 */
	public static boolean emailValidator(String email) {
		try {
			Pattern patron = Pattern.compile("^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,3})$");
			Matcher matcher = patron.matcher(email);
			return matcher.matches();
		} catch (NullPointerException e) {
			return false;
		}
	}
}
