package gob.bcb.lavado.client;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.codec.binary.Base64;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.client.crypto.CryptoProviderImpl;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.client.utils.UtilsGeneric;
import gob.bcb.lavado.client.utils.UtilsSec;

public class HandlerGeneratorLauCliTest {
	private static final Logger log = LoggerFactory.getLogger(HandlerGeneratorLauCliTest.class);
	
	//@Test
	public void generateToken() throws Exception{
		log.info("============generateToken=============");
		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", "codapp");
		params.put("coduser", "coduser");
		String idCliente = "test01";
		HandlerGeneratorLauCli.initCurrentInstance("/opt/aplicaciones/lavado", idCliente);
		String codectrl = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);
		
		log.info("codectrl {}", codectrl);		
		for (Entry<String, String> element : params.entrySet()) {
			log.info("key {} : {}", element.getKey(), element.getValue());
		}
		
		String decode = new String (Base64.decodeBase64(params.get("ctrldata")));
		String ctrlcode = params.get("ctrlcode");
		log.info("ctrldata => {}", decode);
		//String valuDig = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateKey(params);
		log.info("ctrlcode => {} ", ctrlcode);
		
		HandlerGeneratorLauCli.getGeneratorLAU().validateKeyDigest(decode, ctrlcode);
		
		Map<String, String> map = UtilsGeneric.paramsLista(decode);
		
		for (Entry<String, String> element : map.entrySet()) {
			log.info("value dec=> {} : {}", element.getKey(), element.getValue());
		}
		
		String secretDec = UtilsSec.easeyDecrypt( map.get("pc"));
		log.info("secret => {}", secretDec);
		
				
		String phraseSecretInServ = idCliente + "__LAVADO";
		
		HandlerGeneratorLauCli.getGeneratorLAU().validateKeyDigest(decode, ctrlcode);
		log.info("secret valid => {}", phraseSecretInServ.equals(secretDec));			
	}
	
	// @Test
	public void generateTokenwithlau() throws Exception{
		log.info("============generateTokenwithlau=============");
		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", "codapp");
		params.put("coduser", "coduser");
		
		String codeKeyFP2 = "Abcd1234abcd1235";
		String codeKeySP2 = "Abcd1234abcd1235";
		
		HandlerGeneratorLauCli.initCurrentInstance("/opt/aplicaciones/lavado", "test02");
		HandlerGeneratorLauCli.getGeneratorLAU().updateCodeLau(codeKeyFP2 , codeKeySP2, 90, new Date(),"SIOC, AICOS", "codUsuario", "estacion", false);
		
		String codectrl = HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);
		log.info("codectrl {}", codectrl);		
		for (Entry<String, String> element : params.entrySet()) {
			log.info("key {} : {}", element.getKey(), element.getValue());
		}
		
		String decode = new String (Base64.decodeBase64(params.get("ctrldata")));
		String ctrlcode = params.get("ctrlcode");
		log.info("ctrldata => {}", decode);
		log.info("ctrlcode => {}", params.get("ctrlcode"));
		Map<String, String> map = UtilsGeneric.paramsLista(decode);
		
		for (Entry<String, String> element : map.entrySet()) {
			log.info("value dec=> {} : {}", element.getKey(), element.getValue());
		}
		String lau = HandlerGeneratorLauCli.getGeneratorLAU().signLau(decode);
		log.info("lau => {} DATA:: {}", lau , decode);
		HandlerGeneratorLauCli.getGeneratorLAU().signLauValidate(decode, ctrlcode);
		log.info("============FIN generateTokenwithlau=============");
	}
	
	//@Test
	public void transferClienteSinLauYServSinLau() throws Exception{
		log.info("============transferClienteSinLauYServSinLau=============");
		String idcliente = "testcli01";
		String idserver = "testserv01";		
		HandlerGeneratorLauCli.initCurrentInstance("/opt/aplicaciones/lavado", idcliente);		
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().reinitGeneratorLAU();
		
		// prepara mensaje  
		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", "codapp");
		params.put("coduser", "coduser");
		
		// se envia al serv
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);

		// en el serv se procesa data y code
		String ctrldata = params.get(HandlerGeneratorLauCli.PARAM_CODE_DATA);
		String ctrlcode = params.get(HandlerGeneratorLauCli.PARAM_CODE_CTRL);
		String typeenc = params.get(HandlerGeneratorLauCli.PARAM_TYPE_ENC);
		log.info("ctrldata: {}", ctrldata );
		log.info("ctrlcode: {}", ctrlcode );		
		log.info("typeenc: {}", typeenc);

		log.info("============en server=============");		
		HandlerGeneratorLauSrv.initCurrentInstance("/opt/aplicaciones/lavado", idserver);		
		HandlerGeneratorLauSrv.getCurrentInstanceHGen().reinitGeneratorLAU();
		
		SearchResponse searchResponse = HandlerGeneratorLauSrv.getCurrentInstanceHGen().validateAndReponse(idcliente, ctrldata, ctrlcode, typeenc);
		log.info("idresponse: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(),searchResponse.getCodResplau(), searchResponse.getDescripResp());
		
		log.info("============FIN transferClienteSinLauYServSinLau=============");		
	}
	
	@Test
	public void transferClienteSinLauYServConLau() throws Exception{
		log.info("============transferClienteSinLauYServConLau=============");
		String idcliente = "SIOC";
		String idserver = "LAVADO";		
		HandlerGeneratorLauCli.initCurrentInstance("/opt/aplicaciones/lavado", idcliente);
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().reinitGeneratorLAU();
		
		// prepara mensaje  
		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", "codapp");
		params.put("coduser", "coduser");

		// se envia al serv
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);
		// en el serv se procesa data y code
		String ctrldata = params.get(HandlerGeneratorLauCli.PARAM_CODE_DATA);
		String ctrlcode = params.get(HandlerGeneratorLauCli.PARAM_CODE_CTRL);
		String typeenc = params.get(HandlerGeneratorLauCli.PARAM_TYPE_ENC);
		log.info("ctrldata: {}", ctrldata );
		log.info("ctrlcode: {}", ctrlcode );		
		log.info("typeenc: {}", typeenc);
		
		log.info("============en server=============");		
		HandlerGeneratorLauSrv.initCurrentInstance("/opt/aplicaciones/lavado", idserver);
		HandlerGeneratorLauSrv.getCurrentInstanceHGen().reinitGeneratorLAU();
		
		String codeKeyFP2 = "Abcd1234abcd1235";
		String codeKeySP2 = "Abcd1234abcd1235";		
		HandlerGeneratorLauSrv.getGeneratorLAU().updateCodeLau(codeKeyFP2 , codeKeySP2, 90, new Date(),"SIOC, AICOS", "codUsuario", "estacion", false);
	
		SearchResponse searchResponse = HandlerGeneratorLauSrv.getCurrentInstanceHGen().validateAndReponse(idcliente, ctrldata, ctrlcode, typeenc);
		log.info("idresponse: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(),searchResponse.getCodResplau(), searchResponse.getDescripResp());		
		log.info("============en cliente=============");		
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().processResponse(searchResponse);		
		
		log.info("============FIN transferClienteSinLauYServConLau=============");		
	}	
	
	//@Test
	public void transferClienteConLauYServSinLau() throws Exception{
		log.info("============transferClienteConLauYServSinLau=============");
		String idcliente = "testcli02";
		String idserver = "testserv02";
		HandlerGeneratorLauCli.initCurrentInstance("/opt/aplicaciones/lavado", idcliente);
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().reinitGeneratorLAU();

		String codeKeyFP2 = "Abcd1234abcd1235";
		String codeKeySP2 = "Abcd1234abcd1235";		
		HandlerGeneratorLauCli.getGeneratorLAU().updateCodeLau(codeKeyFP2 , codeKeySP2, 90, new Date(),"SIOC, AICOS", "codUsuario", "estacion", false);
		
		// prepara mensaje  
		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", "codapp");
		params.put("coduser", "coduser");

		// se envia al serv
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);
		// en el serv se procesa data y code
		String ctrldata = params.get(HandlerGeneratorLauCli.PARAM_CODE_DATA);
		String ctrlcode = params.get(HandlerGeneratorLauCli.PARAM_CODE_CTRL);
		String typeenc = params.get(HandlerGeneratorLauCli.PARAM_TYPE_ENC);
		log.info("ctrldata: {}", ctrldata );
		log.info("ctrlcode: {}", ctrlcode );		
		log.info("typeenc: {}", typeenc);
		
		log.info("============en server=============");		
		HandlerGeneratorLauSrv.initCurrentInstance("/opt/aplicaciones/lavado", idserver);
		HandlerGeneratorLauSrv.getCurrentInstanceHGen().reinitGeneratorLAU();
		
		SearchResponse searchResponse = HandlerGeneratorLauSrv.getCurrentInstanceHGen().validateAndReponse(idcliente, ctrldata, ctrlcode, typeenc);
		log.info("idresponse: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(),searchResponse.getCodResplau(), searchResponse.getDescripResp());		
		log.info("============en cliente=============");		
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().processResponse(searchResponse);
		
		log.info("============FIN transferClienteConLauYServSinLau=============");		
	}	
	//@Test
	public void transferClienteConLauYServConLauCodeLauInvalido() throws Exception{
		log.info("============transferClienteConLauYServConLauCodeLauInvalido=============");
		String idcliente = "testcli02";
		String idserver = "testserv02";
		HandlerGeneratorLauCli.initCurrentInstance("/opt/aplicaciones/lavado", idcliente);
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().reinitGeneratorLAU();

		String codeKeyFP2 = "Abcd1234abcd1235";
		String codeKeySP2 = "Abcd1234abcd1235";		
		HandlerGeneratorLauCli.getGeneratorLAU().updateCodeLau(codeKeyFP2 , codeKeySP2, 90, new Date(),"SIOC, AICOS", "codUsuario", "estacion", false);
		
		// prepara mensaje  
		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", "codapp");
		params.put("coduser", "coduser");

		// se envia al serv
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);
		// en el serv se procesa data y code
		String ctrldata = params.get(HandlerGeneratorLauCli.PARAM_CODE_DATA);
		String ctrlcode = params.get(HandlerGeneratorLauCli.PARAM_CODE_CTRL);
		String typeenc = params.get(HandlerGeneratorLauCli.PARAM_TYPE_ENC);
		log.info("ctrldata: {}", ctrldata );
		log.info("ctrlcode: {}", ctrlcode );		
		log.info("typeenc: {}", typeenc);
		
		log.info("============en server=============");		
		HandlerGeneratorLauSrv.initCurrentInstance("/opt/aplicaciones/lavado", idserver);
		HandlerGeneratorLauSrv.getCurrentInstanceHGen().reinitGeneratorLAU();

		codeKeyFP2 = "Abcd1235abcd1235";
		codeKeySP2 = "Abcd1235abcd1235";		
		HandlerGeneratorLauSrv.getGeneratorLAU().updateCodeLau(codeKeyFP2 , codeKeySP2, 90, new Date(),"SIOC, AICOS", "codUsuario", "estacion", false);
		
		SearchResponse searchResponse = HandlerGeneratorLauSrv.getCurrentInstanceHGen().validateAndReponse(idcliente, ctrldata, ctrlcode, typeenc);
		log.info("idresponse: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(),searchResponse.getCodResplau(), searchResponse.getDescripResp());		
		log.info("============en cliente=============");		
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().processResponse(searchResponse);
		
		log.info("============FIN transferClienteConLauYServConLauCodeLauInvalido=============");		
	}
	
	//@Test
	public void transferClienteConLauYServConLauCodeLauValido() throws Exception{
		log.info("============transferClienteConLauYServConLauCodeLauValido=============");
		String idcliente = "SIOC";
		String idserver = "LAVADO";
		HandlerGeneratorLauCli.initCurrentInstance("/opt/aplicaciones/lavado", idcliente);
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().reinitGeneratorLAU();

		String codeKeyFP2 = "Abcd1234abcd1235";
		String codeKeySP2 = "Abcd1234abcd1235";		
		HandlerGeneratorLauCli.getGeneratorLAU().updateCodeLau(codeKeyFP2 , codeKeySP2, 90, new Date(),"SIOC, AICOS", "codUsuario", "estacion", false);
		
		// prepara mensaje  
		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", "codapp");
		params.put("coduser", "coduser");

		// se envia al serv
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().generateToken(params);
		// en el serv se procesa data y code
		String ctrldata = params.get(HandlerGeneratorLauCli.PARAM_CODE_DATA);
		String ctrlcode = params.get(HandlerGeneratorLauCli.PARAM_CODE_CTRL);
		String typeenc = params.get(HandlerGeneratorLauCli.PARAM_TYPE_ENC);
		log.info("ctrldata: {}", ctrldata );
		log.info("ctrlcode: {}", ctrlcode );		
		log.info("typeenc: {}", typeenc);
		
		log.info("============en server=============");		
		HandlerGeneratorLauSrv.initCurrentInstance("/opt/aplicaciones/lavado", idserver);
		HandlerGeneratorLauSrv.getCurrentInstanceHGen().reinitGeneratorLAU();

		HandlerGeneratorLauSrv.getGeneratorLAU().updateCodeLau(codeKeyFP2 , codeKeySP2, 90, new Date(),"SIOC, AICOS", "codUsuario", "estacion", false);
		
		SearchResponse searchResponse = HandlerGeneratorLauSrv.getCurrentInstanceHGen().validateAndReponse(idcliente, ctrldata, ctrlcode, typeenc);
		log.info("idresponse: {} {} {} {}", searchResponse.getCodResp(), searchResponse.getDescripResp(),searchResponse.getCodResplau(), searchResponse.getDescripResp());

		log.info("============en cliente=============");		
		HandlerGeneratorLauCli.getCurrentInstanceHGenCli().processResponse(searchResponse);
		log.info("============FIN transferClienteConLauYServConLauCodeLauValido=============");		
	}	
}
