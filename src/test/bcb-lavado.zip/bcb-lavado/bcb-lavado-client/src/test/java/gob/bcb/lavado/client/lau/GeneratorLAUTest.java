package gob.bcb.lavado.client.lau;

import java.io.File;
import java.util.Date;
import java.util.UUID;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.client.crypto.CryptoProviderImpl;

public class GeneratorLAUTest {
	private static final Logger log = LoggerFactory.getLogger(GeneratorLAUTest.class);

	//@Test
	public void initGenerator() throws Exception{
		log.info("============initGenerator=============");
		
		GeneratorLAU generatorLAU = new GeneratorLAU("/opt/aplicaciones/lavado", "test");
		generatorLAU.loadGeneratorLau(false);
		new File("/opt/aplicaciones/lavado", "test").delete();
	}
	
	
	@Test
	public void intercambioKeys() throws Exception{
		log.info("============intercambioKeys=============");
		String phraseCommons= "phrase secreta!";
		String codeKeyFP = "Abcd1234abcd1234";
		String codeKeySP = "Abcd1234abcd1234";
		
		GeneratorLAU generatorLAU = new GeneratorLAU("/opt/aplicaciones/lavado", "testcli");
		generatorLAU.loadGeneratorLau(true);
		
		generatorLAU.updateCodeLau(codeKeyFP , codeKeySP, 90, new Date(), "","codUsuario", "estacion", false);
		
		String phraseCommonslau = generatorLAU.signLau(phraseCommons);
		log.info("datolau cli: [" + phraseCommonslau + "] ");
		
		String ksstrcli = generatorLAU.exportKeyToStr(CryptoProviderImpl.KEY_ALIAS_MACLAU, "testcli02", "testcli02__LAVADO");
		
		String codeKeyFP2 = "Abcd1234abcd1235";
		String codeKeySP2 = "Abcd1234abcd1235";		
		log.info("============generatorLAU2=============");
		GeneratorLAU generatorLAU2 = new GeneratorLAU("/opt/aplicaciones/lavado", "testserv");
		generatorLAU2.loadGeneratorLau(true);
		
		//generatorLAU2.updateCodeLau(codeKeyFP2 , codeKeySP2, 90, new Date(),"SIOC, AICOS", "codUsuario", "estacion", false);
		generatorLAU2.importKeyFromString(ksstrcli, "", "testcli02", CryptoProviderImpl.KEY_ALIAS_MACLAU, "testcli02__LAVADO");
		
		String phraseCommonslauServ = generatorLAU2.signLau(CryptoProviderImpl.KEY_ALIAS_MACLAU, phraseCommons);
		log.info("phraseCommons cli: [" + phraseCommonslau + "] " + phraseCommonslauServ);
		
		generatorLAU2.loadGeneratorLau(false);
		phraseCommonslauServ = generatorLAU2.signLau(CryptoProviderImpl.KEY_ALIAS_MACLAU, phraseCommons);
		log.info("phraseCommonsAAAAAA cli: [" + phraseCommonslau + "] " + phraseCommonslauServ);
		//String ksstrserv = generatorLAU2.exportKeyToStr(CryptoProviderImpl.KEY_ALIAS_MACLAU,"IDMACLAU", "password para cliente");
		
		
		
	}
	
	//@Test
	public void generatorKeyLauSystem() throws Exception{
		log.info("============generatorKeyLauSystem=============");
		String phraseCommons= "phrase secreta!aaaaaaaaaaaaaa";
		
		GeneratorLAU generatorLAU = new GeneratorLAU("/opt/aplicaciones/lavado", "testcli");
		generatorLAU.loadGeneratorLau(true);
		String idSession = UUID.randomUUID().toString().replace("-", "");		
		log.info("mac cli: [" + generatorLAU.signLauSystem(idSession) + "] ");
		log.info("Sha1-: [" + generatorLAU.generateKeyDigest(idSession) + "] ");
	}	
	
	//@Test
	public void intercambioKeys2() throws Exception{
		log.info("============intercambioKeys=============");
		String phraseCommons= "phrase secreta!";
		String codeKeyFP = "Abcd1234abcd1234";
		String codeKeySP = "Abcd1234abcd1234";
		
		
	}	
}
