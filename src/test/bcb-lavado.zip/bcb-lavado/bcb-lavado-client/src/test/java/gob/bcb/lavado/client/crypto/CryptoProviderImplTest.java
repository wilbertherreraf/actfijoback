package gob.bcb.lavado.client.crypto;

import java.security.Key;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CryptoProviderImplTest {
	private static final Logger log = LoggerFactory.getLogger(CryptoProviderImplTest.class);

	// @Test
	public void createFileStore() throws Exception {
		log.info("============createFileStore=============");
		String archLaunew = "e:/opt/aplicaciones/lavado/fstestcli.fs";
		CryptoProviderImpl cryptoProvider = new CryptoProviderImpl(archLaunew, "password", null, true, false);
		cryptoProvider.addKeySymetric("SIOC", "siocPhasePassw");
		Key key = cryptoProvider.getKey("SIOC");
		log.info("key " + key.getAlgorithm());
		cryptoProvider.addKeyMac("LVDLAU", "siocPhasePassw");
		key = cryptoProvider.getKey("LVDLAU");
		log.info("key " + key.getAlgorithm());
		// cryptoProvider.getKey(keyParams);
	}

	// @Test
	public void createFileStoreFromAlias() throws Exception {
		log.info("============createFileStoreFromAlias=============");
		String archLaunew = "e:/opt/aplicaciones/lavado/fstestcli.fs";
		String archLaunew2 = "e:/opt/aplicaciones/lavado/fstestcli2.fs";

		CryptoProviderImpl cryptoProvider = new CryptoProviderImpl(archLaunew, "password", null, true, false);
		CryptoProviderImpl cryptoProvider2 = new CryptoProviderImpl(archLaunew2, "password2", null, true, false);

		cryptoProvider.addKeySymetric("SIOC", "phrase password en servidor");
		Key key = cryptoProvider.getKey("SIOC");
		log.info("key " + key.getAlgorithm());

		String ksstr = cryptoProvider.exportKeyToStr("SIOC", "SIOCIMPORT", "phrase password de cliente sioc");
		log.info("key ksstr " + ksstr);
		// cryptoProvider.getKey(keyParams);

		cryptoProvider2.importKeyFromString(ksstr, "", "SIOC", "SIOCIMPORT", "phrase password de cliente sioc");
		Key key2 = cryptoProvider2.getKey("SIOCIMPORT");
		log.info("key " + key2.getAlgorithm());

	}

	@Test
	public void procesoIntercambioLAU() throws Exception {
		log.info("============procesoIntercambioLAU=============");
		String archLaunew = "e:/opt/aplicaciones/lavado/fsserv.fs";
		String archLaunew2 = "e:/opt/aplicaciones/lavado/fsclient.fs";
		// se crean en el serv y cliente un fs
		CryptoUtilImpl cryptoUtilImplServ = new CryptoUtilImpl();
		cryptoUtilImplServ.initialize(archLaunew, "passord fs serv", null, true, false);

		String passforclient = cryptoUtilImplServ.encryptAndBase64("pharse passw para sioc".getBytes(), cryptoUtilImplServ.getActiveProvider().getKeySystem());
		String passforclientdec = cryptoUtilImplServ.decryptBase64ToString(passforclient, cryptoUtilImplServ.getActiveProvider().getKeySystem());

		log.info("passforclient: [" + passforclient + "] dec= " + passforclientdec);
		
		CryptoUtilImpl cryptoUtilImplClient = new CryptoUtilImpl();
		cryptoUtilImplClient.initialize(archLaunew2, "passord fs client", null, true, false);

		String passforserv = cryptoUtilImplClient.encryptAndBase64("pharse passw para serv".getBytes(), cryptoUtilImplClient.getActiveProvider().getKeySystem());
		String passforservdec = cryptoUtilImplClient.decryptBase64ToString(passforserv, cryptoUtilImplClient.getActiveProvider().getKeySystem());

		log.info("passforSERV: [" + passforserv + "] dec= " + passforservdec);

		cryptoUtilImplServ.getActiveProvider().addKeySymetric("SIOC", passforclientdec);
		
		Key key = cryptoUtilImplServ.getActiveProvider().getKey("SIOC");		

		String codeKeyFP = "Abcd1234abcd1234";
		String codeKeySP = "Abcd1234abcd1234";
		cryptoUtilImplServ.getActiveProvider().addKeyMac("MACLAU", codeKeyFP + codeKeySP);

		String datoenc = cryptoUtilImplServ.encryptAndBase64("dato a encriptar".getBytes(), key);
		String datodec = cryptoUtilImplServ.decryptBase64ToString(datoenc, key);

		log.info("datoenc serv: [" + datoenc + "] datodec= " + datodec);

		log.info("===========LAU==============");
		Key keymlau = cryptoUtilImplServ.getActiveProvider().getKey("MACLAU");
		datoenc = cryptoUtilImplServ.getMacHash("dato a encriptar", keymlau);
		log.info("datoenc serv LAU: [" + datoenc + "]");

		String ksstr = cryptoUtilImplServ.getActiveProvider().exportKeyToStr("SIOC", "SIOCIMPORT", passforserv);

		log.info("=========================");
		
		cryptoUtilImplClient.getActiveProvider().importKeyFromString(ksstr, "", "SIOC", "SIOCIMPORT", passforserv);

		Key key0 = cryptoUtilImplClient.getActiveProvider().getKey("SIOCIMPORT");

		datoenc = cryptoUtilImplClient.encryptAndBase64("dato a encriptar".getBytes(), key0);
		datodec = cryptoUtilImplClient.decryptBase64ToString(datoenc, key0);

		log.info("datoenc: [" + datoenc + "] datodec= " + datodec);

		log.info("===========LAU==============");
		Key keymlau0 = cryptoUtilImplClient.getActiveProvider().getKey("MACLAU");
		datoenc = cryptoUtilImplClient.getMacHash("dato a encriptar", keymlau0);
		log.info("datoenc LAU: [" + datoenc + "]");
	}
}
