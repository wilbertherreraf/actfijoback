package gob.bcb.lavado.client.sign;

public class SignPru {

}
