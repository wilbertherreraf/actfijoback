package gob.bcb.lavado.client;

import java.util.Date;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.client.crypto.CryptoProviderImpl;
import gob.bcb.lavado.client.lau.GeneratorLAU;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.client.utils.UtilsGeneric;
import gob.bcb.lavado.client.utils.UtilsSec;

public class HandlerGeneratorLauCli {
	private static final Logger log = LoggerFactory.getLogger(HandlerGeneratorLauCli.class);
	public static final String PARAM_CODE_DATA = "ctrldata";
	public static final String PARAM_CODE_CTRL = "ctrlcode";
	public static final String PARAM_TYPE_ENC = "tenc";
	public static final String PARAM_TYPE_ENC_LAU = "l";
	public static final String PARAM_TYPE_ENC_NOTLAU = "n";
	public static final String PARAM_SECRETID = "pc";
	public static final String PARAM_RESPONSE_KEYSTORESTR = "kl";	
	public static final String PARAM_RESPONSE_IDHASHLAU = "hl";	
	private static GeneratorLAU generatorLAU;
	private static HandlerGeneratorLauCli currInstance;
	private String secret;
	private String idGenerator;
	private String pathBase;

	private HandlerGeneratorLauCli() {
	}

	public static HandlerGeneratorLauCli getCurrentInstanceHGenCli() {
		if (currInstance == null) {
			throw new RuntimeException("Instancia no inicializada");
		}
		return currInstance;
	}

	public static GeneratorLAU getGeneratorLAU() throws Exception {
		getCurrentInstanceHGenCli();
		if (generatorLAU == null) {
			generatorLAU = new GeneratorLAU(currInstance.pathBase, currInstance.idGenerator);
			generatorLAU.loadGeneratorLau(false);
			
			log.info("Fin inicializa contenedor LAU config..." + currInstance.existsLau());
		}
		return generatorLAU;
	}

	public static GeneratorLAU initCurrentInstance(String pathBase, String idGenerator) throws Exception {
		if (currInstance == null) {
			log.info("=====> Iniciando instancia Server LAU <===== [{}] {}", idGenerator, pathBase);
			currInstance = new HandlerGeneratorLauCli();
			currInstance.generateSecret(idGenerator);
			currInstance.idGenerator = idGenerator;
			currInstance.pathBase = pathBase;
		
		}
		GeneratorLAU  gl = getGeneratorLAU();
		return gl;
	}

	/**
	 * genera el token para envio al servidor, agrega el campo codectrl al mapa
	 * de parametros
	 * 
	 * @param parameters
	 * @return
	 */
	public String generateToken(Map<String, String> parameters) {
		log.info("Generando token : {}", parameters.toString());
		String encoded;
		// tipo de encriptacion
		String codectrl = "";
		int secondsToExpire = 5;
		try {
			parameters.put("expires", String.valueOf(new Date().getTime() / 1000 + secondsToExpire));
			encoded = UtilsGeneric.encodeQueryParams(parameters);

			if (!existsLau()) {
				// sino tiene lau se encripta y el codigo de control sera el
				// token
				encoded += "&" + PARAM_SECRETID + "=" + secret;
				codectrl = generatorLAU.generateKeyDigest(encoded);
				// codectrl = Base64.encodeBase64String(raw);
				parameters.put(PARAM_TYPE_ENC, PARAM_TYPE_ENC_NOTLAU);
				parameters.put(PARAM_CODE_DATA, Base64.encodeBase64String(encoded.getBytes()));
				parameters.put(PARAM_CODE_CTRL, codectrl);
				log.info("Enviando token sin lau " + codectrl);
			} else {
				encoded += "&" + PARAM_SECRETID + "=" + generatorLAU.getLauIdProp();
				codectrl = generatorLAU.signLau(encoded);
				log.info("LAU a enviar: {} data: {}", codectrl, encoded );
				parameters.put(PARAM_TYPE_ENC, PARAM_TYPE_ENC_LAU);
				parameters.put(PARAM_CODE_DATA, Base64.encodeBase64String(encoded.getBytes()));
				parameters.put(PARAM_CODE_CTRL, codectrl);
			}

			return codectrl;
		} catch (Exception e) {
			log.error("Error al generar token " + e.getMessage(), e);
			throw new RuntimeException("Error al generar token " + e.getMessage(), e);
		}
	}
	
	public static String generateTokenForMsg(final String menPlano) {
		//log.info("Generando token : {}", menPlano);
		// tipo de encriptacion
		try {
			if (!existsLau()) {
				return "";
			} else {
				final String codectrl = generatorLAU.signLau(menPlano);
				log.info("LAU a enviar: {}", codectrl);
				return codectrl;
			}

		} catch (Exception e) {
			log.error("Error al generar token " + e.getMessage(), e);
			throw new RuntimeException("Error al generar token " + e.getMessage(), e);
		}
	}	
	public boolean processResponse(SearchResponse searchResponse) throws Exception {
		boolean requireSend = false;
		log.info("procesando respuesta LVD: " + searchResponse.getCodResp());
		if (searchResponse.getCodResp().equals(Constants.COD_RESP_ERR_03)){
			// solo se procesa si es error para lau
			if (searchResponse.getCodResplau().equals(Constants.COD_RESP_ERR_LAU_L01)){
				// se actualiza lau
				updateKeyLAUFromString(searchResponse.getDescripResplau());
				requireSend = true;
			} else if (searchResponse.getCodResplau().equals(Constants.COD_RESP_ERR_LAU_L02)){
				// se elimina el keystore
				deleteKeyLAUOnKeyStore();
				requireSend = true;
			}
		}
		return requireSend;
	}
	
	public void updateKeyLAUFromString(String idresplau) throws Exception {
		log.info("Accion: actualizar LAU en cliente");
		String idresponse = new String(Base64.decodeBase64(idresplau));
		Map<String, String> map = UtilsGeneric.paramsLista(idresponse);
		String klToImport = map.get(PARAM_RESPONSE_KEYSTORESTR);
		String idclToImport = map.get(PARAM_RESPONSE_IDHASHLAU);
		
		if (StringUtils.isBlank(idclToImport)){
			log.error("Codigo hash lau nulo de response {}",idresponse);
		}
		String passksToImport = UtilsSec.easeyDecrypt(secret);

		log.info("Actualizando LAU, importando idlau: {} key from server {}", idclToImport, idresponse);
		log.info("----> passksToImport {} ----- {}", passksToImport, currInstance.idGenerator);
		generatorLAU.importKeyFromString(klToImport, "", currInstance.idGenerator, CryptoProviderImpl.KEY_ALIAS_MACLAU, passksToImport);

		generatorLAU.updateLauPropertiesOnClient(idclToImport, currInstance.idGenerator, "SYSTEMCLI");
		// cargamos todo nuevamente
		generatorLAU.loadGeneratorLau(false);
		// verficamos que exista la llave importada
		if (!generatorLAU.existKey(CryptoProviderImpl.KEY_ALIAS_MACLAU)) {
			log.error("Error!!!! al generar cargar llave importada datos: " + map.toString());
			throw new RuntimeException("Error al importar codigo de verificación LAU");
		}
		log.info("Importado key Alias Lau {}", CryptoProviderImpl.KEY_ALIAS_MACLAU);
	}

	public void deleteKeyLAUOnKeyStore() throws Exception {
		log.info("Accion: eliminar LAU en cliente");
		reinitGeneratorLAU();
	}

	public void reinitGeneratorLAU() throws Exception {
		log.info("Reiniciando instancia GeneratorLAU");
		generatorLAU.deleteFilesLau();
		generatorLAU = null;
		getGeneratorLAU();
	}

	public static boolean existsLau() {
		return generatorLAU.isRegisterCodeLau();
	}

	private void generateSecret(String idGenerator) {
		secret = UtilsSec.easeyEncrypt(idGenerator + "__LAVADO");
	}

}
