package gob.bcb.lavado.client.crypto;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.client.utils.UtilsFile;

/**
 * this class tries to load key-store file, and load the keys from it. if file
 * does not exist, it creates it, creates the keys and stores it. if file exists
 * but one or more keys are missing - it creates the keys and stores to the
 * file.
 * 
 * if this jar is deplyed on GAE, for example, where files cannot be stored - we
 * have a flag for these cases, so this class will not try to store the
 * key-store file, but will work in-mem.
 * 
 *
 */
public class CryptoProviderImpl implements CryptoProvider {
	private static final Logger log = LoggerFactory.getLogger(CryptoProviderImpl.class);

	private final static String CRYPTO_ALGO = "HmacSHA256";
	private static final String SYMMETRIC_ALGORITHM = "AES/ECB/PKCS5Padding";
	private static final int SYMMETRIC_KEY_LENGTH = 128; // 128 bit (16 bytes)

	public static final String KEYSTORE_TYPE = "JCEKS";
	private static final String Algorithm = "AES"; // AES DESede
	private final static String CRYPTO_ALGO_HMAC = "HmacSHA256";
	private File fileStore;
	private final KeyStore keyStore;
	private final Map<String, Key> keys;
	private KeyGenerator keyGenerator;
	private Mac hasher;
	private final String keystoreFile;
	private final String keystorePassword;
	public static final String KEY_ALIAS_SYSTEM = "lvd_system";
	public static final String KEY_ALIAS_MACLAU = "lvd_maclau";
	private static final String ASYMMETRIC_KEY_NAME = "WatchDox_DSA";
	private PrivateKey privateKey;
	private Certificate certificate;

	public CryptoProviderImpl(String keystoreFile, String keystorePassword, String passwordLau, boolean createFileIfNotExist, boolean createdKeyLauIfNotExists) {
		try {
			this.keystoreFile = keystoreFile;
			this.keystorePassword = keystorePassword;

			keys = new HashMap<String, Key>();
			keyStore = KeyStore.getInstance(KEYSTORE_TYPE);
			loadKeyStore(createFileIfNotExist, passwordLau, createdKeyLauIfNotExists);
		} catch (Exception e) {
			throw new CryptoExceptionLau("Fallo al inicializar archivo keystore para " + keystoreFile, e);
		}
	}

	private void loadKeyStore(boolean createFileIfNotExist, String passwordLau, boolean createdKeyLauIfNotExists) throws Exception {
		try {
			keyStore.load(new FileInputStream(keystoreFile), keystorePassword.toCharArray());
			log.info("initialize File store " + keystoreFile);
		} catch (FileNotFoundException e) {
			log.warn("Keystore file does not exist; Will try to create a new one in: " + keystoreFile);
			keyStore.load(null, null);
		}

		Enumeration<String> aliases = keyStore.aliases();
		while (aliases.hasMoreElements()) {
			String alias = (String) aliases.nextElement();
			log.info("alias to loaded {}", alias);

			final String keyPassword = keystorePassword + "__" + alias;
			Key key = null;

			try {
				key = keyStore.getKey(alias, keyPassword.toCharArray());
				keys.put(alias, key);
			} catch (UnrecoverableKeyException e) {
				log.warn("WARN!!: key not exist {} with: {}", alias, keyPassword);
			}
		}

		Key key = keys.get(KEY_ALIAS_SYSTEM);

		if (key == null && createFileIfNotExist) {
			log.warn("key {} not exist, this be created.", KEY_ALIAS_SYSTEM);
			if (createdKeyLauIfNotExists){
				addKeyMac(KEY_ALIAS_SYSTEM, passwordLau);
			} else {
				addKeySymetric(KEY_ALIAS_SYSTEM, "");				
			}
		}
		log.info("::::> Keys charged in keys {} in keystore {}", keys.size(), keyStore.size());
	}

	private void updateFileKeyStore() throws KeyStoreException, NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException {
		keyStore.store(new FileOutputStream(keystoreFile), keystorePassword.toCharArray());
		log.info("file keyStore created: " + keystoreFile);
	}

	public Key getKey(String keyAlias) {
		Key masterKey = keys.get(keyAlias.toLowerCase());
		return masterKey;
	}

	public Cipher getCipher(Key key, int cryptMode) throws InvalidKeyException {
		Cipher cipher = null;
		try {
			if (key == null){
				throw new RuntimeException("Llave a cifrar nulo");				
			}
			if (key.getEncoded().length > 16) {
				cipher = Cipher.getInstance(SYMMETRIC_ALGORITHM);
			} else {
				cipher = Cipher.getInstance(Algorithm);
			}
		} catch (GeneralSecurityException e) {
			throw new CryptoExceptionLau("Cipher creation failed", e);
		}

		cipher.init(cryptMode, key);

		return cipher;
	}

	public Mac initCipherMac(Key key) throws InvalidKeyException {
		try {
			Mac hasher = Mac.getInstance(CRYPTO_ALGO);
			hasher.init(key);
			return hasher;
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("Error al iniciar Hasher " + e.getMessage(), e);
		}
	}

	public void addKey(String fileName, String password, Key key, String nameKey, String keyAlias, String keyPassword) throws Exception {
		nameKey = nameKey.toLowerCase();
		Key keyA = null;
		try {
			keyA = keyStore.getKey(keyAlias, keyPassword.toCharArray());
		} catch (UnrecoverableKeyException e) {
			log.info(":::key not exist, this be created...");
		}
		if (keyA != null) {
			log.info(":::key exist, keyA != null..." + nameKey);
			keyStore.deleteEntry(keyAlias);
		} else {
			log.info(":::key exist, keyA ======== null..." + nameKey);
		}

		keyStore.setKeyEntry(keyAlias, key, keyPassword.toCharArray(), null);
		keys.put(nameKey, key);

		keyStore.store(new FileOutputStream(fileName), password.toCharArray());
	}

	public void addKeySymetric(String keyAlias, String keyPassword) throws Exception {
		keyAlias = keyAlias.toLowerCase();
		String pkey = keystorePassword + "__" + keyAlias;
		Key key = createSymetric(keyAlias, pkey);
		updateFileKeyStore();
		keys.put(keyAlias, key);
	}

	public void addKeyMac(String keyAlias, String keyPassword) throws Exception {
		keyAlias = keyAlias.toLowerCase();
		final String pkey = keystorePassword + "__" + keyAlias;
		Key key = createKeyMac(keyAlias, keyPassword, pkey);
		updateFileKeyStore();
		keys.put(keyAlias, key);
	}

	public Key createSymetric(String keyAlias, String keyPassword) throws NoSuchAlgorithmException, KeyStoreException, CertificateException, FileNotFoundException, IOException {
		keyAlias = keyAlias.toLowerCase();
		if (keyGenerator == null) {
			keyGenerator = KeyGenerator.getInstance(Algorithm);
			keyGenerator.init(SYMMETRIC_KEY_LENGTH);
		}
		keyStore.deleteEntry(keyAlias);
		Key key = keyGenerator.generateKey();

		log.info("Creating NEW symmetric key: " + keyAlias);

		keyStore.setKeyEntry(keyAlias, key, keyPassword.toCharArray(), null);

		return key;
	}

	public Key createKeyMac(String keyAlias, String keyMac, String keyPassword) throws Exception {
		if (hasher == null) {
			hasher = Mac.getInstance(CRYPTO_ALGO_HMAC);
		}
		keyStore.deleteEntry(keyAlias);

		Key key = new SecretKeySpec(keyMac.getBytes(), CRYPTO_ALGO_HMAC);
		hasher.init(key);
		log.info("Creating NEW Mac key: " + keyAlias);
		keyStore.setKeyEntry(keyAlias, key, keyPassword.toCharArray(), null);

		return key;
	}

	public File getFileStore() {
		File keystore = new File(keystoreFile);
		return keystore;
	}

	public String getFileStoreEncode() {
		String menPlano = UtilsFile.readFileAsString2(keystoreFile);
		return DatatypeConverter.printHexBinary(menPlano.getBytes());
	}

	public String exportKeyToStr(String keyAlias, String keyAliasExport, String keyPassword) throws Exception {
		log.info("Exportando key alias {}", keyAlias);		
		keyAlias = keyAlias.toLowerCase();
		keyAliasExport = keyAliasExport.toLowerCase();
		Key key = keys.get(keyAlias);
		if (key == null)
			throw new CryptoExceptionLau("Llave a exportar inexistente " + keyAlias);		

		KeyStore keyStore = KeyStore.getInstance(KEYSTORE_TYPE);
		keyStore.load(null, null);
		keyStore.setKeyEntry(keyAliasExport, key, keyPassword.toCharArray(), null);
		
		ByteArrayOutputStream out = new ByteArrayOutputStream(4096);
		
		keyStore.store(out, "".toCharArray());
		
		byte[] data = out.toByteArray();
		log.info("data. size " + data.length);
		out.close();
		return DatatypeConverter.printHexBinary(data);
	}
	
	public void importKeyFromString(String fsEncode, String passFs, String keyAlias, String keyAliasNew, String keyPassword) throws Exception {
		keyAlias = keyAlias.toLowerCase();
		keyAliasNew = keyAliasNew.toLowerCase();
		
		log.info("import key alias {} -> {}", keyAlias, keyAliasNew);
		
		KeyStore keyStoreVar = KeyStore.getInstance(KEYSTORE_TYPE);

		if (StringUtils.isBlank(fsEncode))
			throw new CryptoExceptionLau("Cadena Key a importar nula");
		
		byte[] data = DatatypeConverter.parseHexBinary(fsEncode);
		log.info("data size " + data.length);

		ByteArrayInputStream bais = new ByteArrayInputStream(data);
		keyStoreVar.load(bais, passFs.toCharArray());

		Key key = keyStoreVar.getKey(keyAlias, keyPassword.toCharArray());

		if (key == null)
			throw new CryptoExceptionLau("Llave importada nula");

		final String keyPasswordServ = keystorePassword + "__" + keyAliasNew;
		
		keyStore.setKeyEntry(keyAliasNew, key, keyPasswordServ.toCharArray(), null);
		
		updateFileKeyStore();
		
		bais.close();
		
		keys.put(keyAliasNew, key);
		Key masterKey = keys.get(keyAliasNew);
		
		if (masterKey == null)
			throw new CryptoExceptionLau("Llave importada inexistente en lista llaves " + keyAliasNew);
		
		log.info("import new key alias: {} ", keyAliasNew);		
		Key keyVerif = keyStore.getKey(keyAliasNew, keyPasswordServ.toCharArray());
		if (keyVerif == null)
			throw new CryptoExceptionLau("Llave importada inexistente en keystore " + keyAliasNew);
		
	}

	public Key getKeySystem() {
		return keys.get(KEY_ALIAS_SYSTEM);
	}


}
