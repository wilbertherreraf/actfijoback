package gob.bcb.lavado.client.crypto;


public class CryptoExceptionLau extends RuntimeException
{
	private static final long serialVersionUID = 1L;

	public CryptoExceptionLau()
	{
		super();
	}

	public CryptoExceptionLau(String message, Throwable cause)
	{
		super(message, cause);
	}

	public CryptoExceptionLau(String message)
	{
		super(message);
	}

	public CryptoExceptionLau(Throwable cause)
	{
		super(cause);
	}

}
