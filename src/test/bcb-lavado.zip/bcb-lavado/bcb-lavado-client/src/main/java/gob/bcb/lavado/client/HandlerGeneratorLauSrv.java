package gob.bcb.lavado.client;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.client.crypto.CryptoProviderImpl;
import gob.bcb.lavado.client.lau.GeneratorLAU;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.client.utils.UtilsGeneric;
import gob.bcb.lavado.client.utils.UtilsProperties;

public class HandlerGeneratorLauSrv {
	private static final Logger log = LoggerFactory.getLogger(HandlerGeneratorLauSrv.class);
	private static GeneratorLAU generatorLAU;
	private static HandlerGeneratorLauSrv currInstance;
	public static final String TIPOCLI_SINLAU = "csl";
	public static final String TIPOCLI_CONLAU = "ccl";	
	private String idGenerator;
	private String pathBase;
	private HandlerGeneratorLauSrv() {
	} 

	public static HandlerGeneratorLauSrv getCurrentInstanceHGen() {
		if (currInstance == null) {
			throw new RuntimeException("Instancia no inicializada");
		}
		return currInstance;
	}

	public static GeneratorLAU getGeneratorLAU() throws Exception {
		getCurrentInstanceHGen();
		if (generatorLAU == null) {
			generatorLAU = new GeneratorLAU(currInstance.pathBase, currInstance.idGenerator);
			generatorLAU.loadGeneratorLau(true);
		}
		return generatorLAU;
	}

	public static GeneratorLAU initCurrentInstance(String pathBase, String idGenerator) throws Exception {
		if (currInstance == null) {
			log.info("=====> Iniciando instancia Server LAU <===== [{}] {}", idGenerator, pathBase);
			currInstance = new HandlerGeneratorLauSrv();
			currInstance.idGenerator = idGenerator;
			currInstance.pathBase = pathBase;
		}

		return getGeneratorLAU();
	}

	/**
	 * Proceso para recepcion de inicio de session en lavado, valida el mensaje
	 * 
	 * @param idCliente
	 * @param ctrldata
	 * @param ctrlcode
	 * @param typeEnc
	 * @return
	 * @throws Exception
	 */
	public SearchResponse validateAndReponse(String idCliente, String ctrldata, String ctrlcode, String typeEnc) throws Exception {
		
		SearchResponse searchResponse = new SearchResponse();
		searchResponse.setCountRegs(0);
		searchResponse.setItemsInfo(new SearchResponse.ItemsInfo[0]);
		
		String idSession = UUID.randomUUID().toString().replace("-", "");

		log.info("Validando y repondiendo idCliente {}, typeEnc {}", idCliente, typeEnc);
		if (typeEnc == null && ctrldata == null && ctrlcode == null){
			log.warn("ATENCION!!!: Llamada servicio sin implementacion en cliente LAU!!! {}", idCliente);
 
			idSession = idSession + TIPOCLI_SINLAU;
			searchResponse.setCodoperacion(idSession);
			searchResponse.setCodResp(Constants.COD_RESP_EXITO);
			searchResponse.setDescripResp("Operacion realizada exitosamente idsession: " + searchResponse.getCodoperacion());
			
			return searchResponse;
		}
		log.info("ctrldata {}", ctrldata);
		log.info("ctrlcode {}", ctrlcode);
		log.info("Proceso lau cliente tiene lau? {}, servicio tiene lau? {}", typeEnc.equals(HandlerGeneratorLauCli.PARAM_TYPE_ENC_LAU), existsLau());

		String idResponse = "";
		final String passwKLauEnc = idCliente + "__LAVADO";
		
		if (typeEnc.equals(HandlerGeneratorLauCli.PARAM_TYPE_ENC_NOTLAU)) {
			validateDataAndCode(ctrldata, ctrlcode, typeEnc);
			if (!existsLau()) {
				// happy day!!!
				// tr ok = 000
				idSession = idSession + TIPOCLI_SINLAU;
				searchResponse.setCodResp(Constants.COD_RESP_EXITO);
				searchResponse.setCodoperacion(idSession);
				searchResponse.setDescripResp("Operacion realizada exitosamente idsession: " + searchResponse.getCodoperacion());
			} else {
				String ksLauExport = generatorLAU.exportKeyToStr(CryptoProviderImpl.KEY_ALIAS_MACLAU, idCliente, passwKLauEnc);
				idResponse = HandlerGeneratorLauCli.PARAM_RESPONSE_KEYSTORESTR + "=" + ksLauExport + "&" + HandlerGeneratorLauCli.PARAM_RESPONSE_IDHASHLAU + "="
						+ generatorLAU.getLauIdProp();
				idResponse = Base64.encodeBase64String(idResponse.getBytes());
				
				String idInProp = getClienteId(idCliente);
				if (StringUtils.isBlank(idInProp)){
					registrarClienteProp(idCliente, idResponse);
				} else {
					idResponse = idInProp; 
					validateDataAndCode(ctrldata, ctrlcode, HandlerGeneratorLauCli.PARAM_TYPE_ENC_LAU);
				}
				
				searchResponse.setCodResp(Constants.COD_RESP_ERR_03);
				searchResponse.setDescripResp("Código Lau requerido, actualizar en cliente");
				searchResponse.setCodResplau(Constants.COD_RESP_ERR_LAU_L01);
				searchResponse.setDescripResplau(idResponse);
			}
		} else if (typeEnc.equals(HandlerGeneratorLauCli.PARAM_TYPE_ENC_LAU)) {
			if (!existsLau()) {
				searchResponse.setCodResp(Constants.COD_RESP_ERR_03);
				searchResponse.setDescripResp("Código Lau NO requerido para proceso, eliminar en cliente");
				searchResponse.setCodResplau(Constants.COD_RESP_ERR_LAU_L02);
			} else {
				String ctrldt = new String(Base64.decodeBase64(ctrldata));
				Map<String, String> map = UtilsGeneric.paramsLista(ctrldt);
				String secretid = map.get(HandlerGeneratorLauCli.PARAM_SECRETID);

				if (StringUtils.isBlank(secretid)) {
					log.error("Parámetro " + HandlerGeneratorLauCli.PARAM_SECRETID + " con valor nulo");
					throw new RuntimeException("Parámetro " + HandlerGeneratorLauCli.PARAM_SECRETID + " con valor nulo, solicite asistencia técnica");
				} else {
					String idInProp = getClienteId(idCliente);
					if (!generatorLAU.getLauIdProp().equals(secretid)) {
						log.warn("Codigos lau diferentes!!! serv - cli: {} <-> {}", generatorLAU.getLauIdProp(), secretid);
						String ksLauExport = generatorLAU.exportKeyToStr(CryptoProviderImpl.KEY_ALIAS_MACLAU, idCliente, passwKLauEnc);
						idResponse = HandlerGeneratorLauCli.PARAM_RESPONSE_KEYSTORESTR + "=" + ksLauExport + "&" + HandlerGeneratorLauCli.PARAM_RESPONSE_IDHASHLAU + "="
								+ generatorLAU.getLauIdProp();
						idResponse = Base64.encodeBase64String(idResponse.getBytes());
						
						if (StringUtils.isBlank(idInProp)){
							registrarClienteProp(idCliente, idResponse);
							
							searchResponse.setCodResp(Constants.COD_RESP_ERR_03);
							searchResponse.setDescripResp("Código Lau requerido, actualizar en cliente");
							searchResponse.setCodResplau(Constants.COD_RESP_ERR_LAU_L01);
							searchResponse.setDescripResplau(idResponse);
							
						} else {
							String idresponse = new String(Base64.decodeBase64(idInProp));
							Map<String, String> mapcliente = UtilsGeneric.paramsLista(idresponse);
							String idclToImport = mapcliente.get(HandlerGeneratorLauCli.PARAM_RESPONSE_IDHASHLAU);
							
							if (idclToImport.equals(secretid)) {
								registrarClienteProp(idCliente, idResponse);
								
								searchResponse.setCodResp(Constants.COD_RESP_ERR_03);
								searchResponse.setDescripResp("Código Lau requerido, actualizar en cliente");
								searchResponse.setCodResplau(Constants.COD_RESP_ERR_LAU_L01);
								searchResponse.setDescripResplau(idResponse);								
							} else {
								validateDataAndCode(ctrldt, ctrlcode, HandlerGeneratorLauCli.PARAM_TYPE_ENC_LAU);
								idResponse = idInProp; 
								
								searchResponse.setCodResp(Constants.COD_RESP_ERR_03);
								searchResponse.setDescripResp("Código Lau requerido, actualizar en cliente");
								searchResponse.setCodResplau(Constants.COD_RESP_ERR_LAU_L01);
								searchResponse.setDescripResplau(idResponse);								
							}
						
						}
						
					} else {
						// happy day!!!
						// tr ok = 000
						validateDataAndCode(ctrldt, ctrlcode, typeEnc);

						searchResponse.setCodResp(Constants.COD_RESP_EXITO);
						idSession = idSession + TIPOCLI_CONLAU;
						searchResponse.setCodoperacion(idSession);
						searchResponse.setDescripResp("Operacion realizada exitosamente idsession: " + searchResponse.getCodoperacion());						
					}
				}
			}
		} else {
			throw new RuntimeException("Parámetro " + HandlerGeneratorLauCli.PARAM_TYPE_ENC + " con valor no soportado " + typeEnc);
		}

		return searchResponse;

	}

	public void validateCodeLauForMsg(String ctrlDat, String ctrlcode) throws Exception {
		log.info("Validando code LAU para mensaje {} exists lau?: {}", ctrlcode , existsLau());
		if (!existsLau()) {
			return;
		}
		generatorLAU.signLauValidate(ctrlDat, ctrlcode);
	}
	
	public void validateDataAndCode(String ctrldata, String ctrlcode, String typeEnc) throws Exception {
		if (typeEnc.equals(HandlerGeneratorLauCli.PARAM_TYPE_ENC_NOTLAU)) {
			validateTokenDigest(ctrldata, ctrlcode);
		} else if (typeEnc.equals(HandlerGeneratorLauCli.PARAM_TYPE_ENC_LAU)) {
			validateTokenLau(ctrldata, ctrlcode);
		} else {
			throw new RuntimeException("Parámetro " + HandlerGeneratorLauCli.PARAM_TYPE_ENC + " con valor no soportado " + typeEnc);
		}
	}

	public void updateCodeLau(String lauKeyFP, String lauKeySP, Integer diasVigencia, Date validoDesde, String clientes, String codUsuario, String estacion) throws Exception {
		getCurrentInstanceHGen();
		generatorLAU.updateCodeLau(lauKeyFP, lauKeySP, diasVigencia, validoDesde, null, codUsuario, estacion, false);
	}

	public void validateTokenDigest(String ctrlDat, String ctrlcode) throws Exception {
		log.info("Validando token Digest {}", ctrlcode);
		String ctrlDataDecode = new String(Base64.decodeBase64(ctrlDat));
		generatorLAU.validateKeyDigest(ctrlDataDecode, ctrlcode);
	}

	public void validateTokenLau(String ctrlDat, String ctrlcode) throws Exception {
		log.info("Validando token LAU {}", ctrlcode);
		if (!existsLau()) {
			log.error("Variable " + CryptoProviderImpl.KEY_ALIAS_MACLAU + " inexistente en keys");
			throw new Exception("Código LAU no inicializado, tipo de validación por LAU");
		}
		generatorLAU.signLauValidate(ctrlDat, ctrlcode);
	}
	
	public void reinitGeneratorLAU() throws Exception {
		log.info("Reiniciando instancia GeneratorLAU");
		generatorLAU.deleteFilesLau();
		generatorLAU = null;
		getGeneratorLAU();
	}

	public boolean existsLau() {
		return generatorLAU.isRegisterCodeLau();
	}
	
	private void registrarClienteProp(String idCliente, String idResponse) throws IOException{
		String pathFileClientProp = new File(pathBase, "lauClients").getAbsolutePath();
		File f = new File(pathFileClientProp);
		Properties properties; 
		if (f.exists() && f.isFile()) {
			properties = UtilsProperties.loadFileMsgProperties(pathFileClientProp);
			log.info("Propiedades Clientes LAU cargado {}", pathFileClientProp);
		} else {
			Properties propertiesNew = new Properties();
			properties = UtilsProperties.store(pathFileClientProp, propertiesNew, "Archivo LAU no inicializado");
			log.info("Propiedades LAU creado {}", pathFileClientProp);
		}
		
		properties.setProperty(idCliente, idResponse);
		UtilsProperties.store(pathFileClientProp, properties, "Archivo LAU clientes ");
	}
	
	public void actualizarClientesID() throws Exception{
		String pathFileClientProp = new File(pathBase, "lauClients").getAbsolutePath();
		log.info("Actualizando IDs {}", pathFileClientProp);		
		File f = new File(pathFileClientProp);
		Properties properties; 
		if (f.exists() && f.isFile()) {
			properties = UtilsProperties.loadFileMsgProperties(pathFileClientProp);
			for (Entry<Object, Object> key : properties.entrySet()){
				String idCliente = (String) key.getKey();				
				String passwKLauEnc = idCliente + "__LAVADO";
				log.info("key {} {}", key.getKey(),key.getValue());
				String ksLauExport = generatorLAU.exportKeyToStr(CryptoProviderImpl.KEY_ALIAS_MACLAU, idCliente, passwKLauEnc);
				String idResponse = HandlerGeneratorLauCli.PARAM_RESPONSE_KEYSTORESTR + "=" + ksLauExport + "&" + HandlerGeneratorLauCli.PARAM_RESPONSE_IDHASHLAU + "="
						+ generatorLAU.getLauIdProp();
				// registro de cliente
				idResponse = Base64.encodeBase64String(idResponse.getBytes());
				properties.setProperty(idCliente, idResponse);				
			}
			UtilsProperties.store(pathFileClientProp, properties, "Archivo LAU clientes ");			
		} 
	}
	
	private String getClienteId(String idCliente) throws IOException{
		String pathFileClientProp = new File(pathBase, "lauClients").getAbsolutePath();
		File f = new File(pathFileClientProp);
		Properties properties; 
		if (f.exists() && f.isFile()) {
			properties = UtilsProperties.loadFileMsgProperties(pathFileClientProp);
			log.info("Propiedades Clientes LAU inicializado {}", pathFileClientProp);
			String key = properties.getProperty(idCliente);
			return key;
		} 
		return null;
	}	
}
