package gob.bcb.lavado.client;

import java.io.Serializable;

public abstract class Constants implements Serializable {
	
	/******** resources ******/
	public static final String PATH_RESOURCE_API_SEARCH = "/api/V3/_search";
	public static final String PATH_RESOURCE_API_BIC = "/api/bic";	
	public static final String PATH_RESOURCE_API_PARAM = "/api/param";	
	public static final String PATH_RESOURCE_API_OFACLIST = "/api/ofaclist";	
	public static final String PATH_RESOURCE_API_LVD = "/api/swift";
	
	public static final String COD_RESP_EXITO = "000";
	public static final String COD_RESP_ERR_01 = "E01";
	public static final String COD_RESP_ERR_02 = "E02";	
	/**
	 * Error al procesar lau
	 */
	public static final String COD_RESP_ERR_03 = "E03";	
	public static final String COD_RESP_ERR_LAU_L00 = "L00";	
	public static final String COD_RESP_ERR_LAU_L01 = "L01";	
	public static final String COD_RESP_ERR_LAU_L02 = "L02";	
	public static final String COD_RESP_ERR_LAU_L03 = "L03";	
	
}
