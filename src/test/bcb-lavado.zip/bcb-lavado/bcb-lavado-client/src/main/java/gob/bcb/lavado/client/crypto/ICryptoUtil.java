package gob.bcb.lavado.client.crypto;

import java.security.Key;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

public interface ICryptoUtil {
	public String encryptAndBase64(byte[] data, Key key);

	public byte[] decryptBase64(String base64andEncrypted, Key key) throws IllegalBlockSizeException, BadPaddingException;

	void initialize(String fileKeystore, String password, String passwordLau, boolean createKeystoreFileIfNotExist, boolean errorIfNotExist) throws Exception;

	void addCryptoKeyToKeyStore(String fileKeystore, String password, Key key, String nameKey, String keyAlias, String keyPassword) throws Exception;

	CryptoProvider getActiveProvider();

	String decryptBase64ToString(String base64andEncrypted, Key key) throws Exception;

	String getMacHash(String data, Key key) throws Exception;

}
