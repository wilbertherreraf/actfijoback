package gob.bcb.lavado.client.lau;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.client.crypto.CryptoExceptionLau;
import gob.bcb.lavado.client.crypto.CryptoProviderImpl;
import gob.bcb.lavado.client.crypto.CryptoUtilImpl;
import gob.bcb.lavado.client.crypto.ICryptoUtil;
import gob.bcb.lavado.client.pojos.GenLauDto;
import gob.bcb.lavado.client.utils.GeneradorPassword;
import gob.bcb.lavado.client.utils.UtilsDate;
import gob.bcb.lavado.client.utils.UtilsFile;
import gob.bcb.lavado.client.utils.UtilsGeneric;
import gob.bcb.lavado.client.utils.UtilsProperties;
import gob.bcb.lavado.client.utils.UtilsSec;

public class GeneratorLAU {
	private static final Logger log = LoggerFactory.getLogger(GeneratorLAU.class);

	private final static String LAU_FILESTORE_DIRBACKUP = "/fslaubackup";
	private final static String ALGORITHM_256 = "SHA-1";
	private String LAU_FILESTORE_NAMEFILE = "lau.fs";
	private String LAU_PROP_NAMEFILE = "lau.properties";

	private final static String PROP_LAU_KEY_FIRST = "lau.key.first";
	private final static String PROP_LAU_KEY_SECOND = "lau.key.second";
	private final static String PROP_LAU_FECHA = "lau.fecha";
	private final static String PROP_LAU_CODUSUARIO = "lau.codusuario";
	private final static String PROP_LAU_ESTACION = "lau.estacion";
	private final static String PROP_LAU_SECRET = "lau.secret";
	private final static String PROP_LAU_DIASVIGENCIA = "lau.diasvigencia";
	private final static String PROP_LAU_CODE_SYSTEM = "lau.keysystem";
	private final static String PROP_LAU_ID = "lau.id";

	public final static String FECHA_FORMAT_LAU_PROP = "dd-MM-yyyy";
	public final static int LAU_KEY_LENGTH = 16;
	public final static int LAU_KEY_LENGTH_CHARS_REPEAT = 3;
	public final static int LAU_KEY_DIASVIGENCIA_DEFAULT = 30;

	private String pathFileKeystore;
	private String pathFileProperties;
	private String LAU_FILESTORE_PATHDIRBACKUP;

	private int diasVigencia = LAU_KEY_DIASVIGENCIA_DEFAULT;
	private Date fechaCreacion;
	private Date fechaCaducidad;
	private String lauKeyFirstPartProp;
	private String lauKeySecondPartProp;
	private String secretStoreProp;
	private String lauIdProp;
	private String keyLauSystemProp;
	private Properties properties;
	private ICryptoUtil cryptoUtil;
	private Key keySystem;
	private Key keyMac;
	private boolean canExecuteSign = false;

	public GeneratorLAU(String pathBase, String idGenerator) {
		log.info("Configurando Generador LAU en {} con id {}", pathBase, idGenerator);
		if (StringUtils.isBlank(pathBase)) {
			log.error("Directorio base para proceso LAU nulo");
			throw new RuntimeException("Directorio base para proceso LAU nulo");
		}

		LAU_FILESTORE_NAMEFILE = idGenerator + LAU_FILESTORE_NAMEFILE;
		LAU_PROP_NAMEFILE = idGenerator + LAU_PROP_NAMEFILE;
		LAU_FILESTORE_PATHDIRBACKUP = pathBase + LAU_FILESTORE_DIRBACKUP;

		pathFileKeystore = new File(pathBase, LAU_FILESTORE_NAMEFILE).getAbsolutePath();
		pathFileProperties = new File(pathBase, LAU_PROP_NAMEFILE).getAbsolutePath();

		try {
			new File(pathBase).mkdirs();
			new File(LAU_FILESTORE_PATHDIRBACKUP).mkdirs();

		} catch (Exception e) {
			throw new RuntimeException("error al inicializar Generator lau: " + e.getMessage(), e);
		}
	}

	public void loadGeneratorLau(boolean createdKeyLauSystemIfNotExists) throws Exception {
		log.info("=====In loads keys =======");

		initializeProperties();

		// secretStoreProp = properties.getProperty(PROP_LAU_SECRET);
		if (StringUtils.isBlank(secretStoreProp)) {
			// en prop no existe un password vigente se crea uno aleatorio para
			// el sistema
			GeneradorPassword generadorPassword = new GeneradorPassword(8, false, true, false, true, 0);
			generadorPassword.generatePassword();
			lauKeyFirstPartProp = "";
			lauKeySecondPartProp = "";
			lauIdProp = "";
			secretStoreProp = generadorPassword.getPassword();
			keyLauSystemProp = "";
			final String secretenc = UtilsSec.easeyEncrypt(secretStoreProp);
			if (createdKeyLauSystemIfNotExists) {
				generadorPassword = new GeneradorPassword(LAU_KEY_LENGTH, false, true, false, true, 3);
				generadorPassword.generatePassword();
				keyLauSystemProp = generadorPassword.getPassword();
			}

			Properties propnew = createProperties(secretenc, lauKeyFirstPartProp, lauKeySecondPartProp, lauIdProp, diasVigencia, new Date(), "", keyLauSystemProp, "INIT SYSTEM",
					"INIT SYSTEM");
			UtilsProperties.store(pathFileProperties, propnew, "Properties creado por inicialización");
			log.info("Password fs creado por defecto en " + pathFileProperties + " " + secretStoreProp);

			initializeProperties();
		}

		initializeCryptoProvider(UtilsSec.easeyDecrypt(secretStoreProp), keyLauSystemProp, createdKeyLauSystemIfNotExists);
	}

	public void updateCodeLau(String lauKeyFP, String lauKeySP, Integer diasVigencia, Date validoDesde, String clientes, String codUsuario, String estacion,
			boolean overrideIfExists) throws Exception {
		log.info("Inicio proceso de actualizar code LAU ...");
		validCodeLauRules(lauKeyFP, lauKeySP);
		cryptoUtil.getActiveProvider().addKeyMac(CryptoProviderImpl.KEY_ALIAS_MACLAU, lauKeyFP + lauKeySP);
		updateLauProperties(lauKeyFP, lauKeySP, diasVigencia, validoDesde, clientes, keyLauSystemProp, codUsuario, estacion);
		initializeProperties();
		initializeCryptoProvider(UtilsSec.easeyDecrypt(secretStoreProp), keyLauSystemProp, false);
	}

	private void initializeCryptoProvider(String secretStore, String passwordLauSystem, boolean createdKeyLauSystemIfNotExists) throws Exception {
		cryptoUtil = getEncriptor(pathFileKeystore, secretStore, passwordLauSystem, true, createdKeyLauSystemIfNotExists);
		keySystem = cryptoUtil.getActiveProvider().getKey(CryptoProviderImpl.KEY_ALIAS_SYSTEM);
		keyMac = cryptoUtil.getActiveProvider().getKey(CryptoProviderImpl.KEY_ALIAS_MACLAU);
		log.info("keys registers? keyMac: " + (keyMac != null) + " keySystem: " + (keySystem != null));
	}

	public void updateLauPropertiesOnClient(String lauIdProp, String codUsuario, String estacion) throws Exception {
		String lauKeyFP = "IMPORTADO DEL SRV";
		String lauKeySP = "IMPORTADO DEL SRV";
		Integer diasVigencia = 0; // DEFINIDO EN EL SERVIDOR DE LAVADO
		Date validoDesde = new Date();
		String clientes = ""; // no usado
		Properties properties = createProperties(secretStoreProp, lauKeyFP, lauKeySP, lauIdProp, diasVigencia, validoDesde, clientes, keyLauSystemProp, codUsuario, estacion);
		doBackupFile(pathFileProperties, LAU_FILESTORE_PATHDIRBACKUP);
		UtilsProperties.store(pathFileProperties, properties, "LAU importado en proceso por " + codUsuario + " estacion: " + estacion);
	}

	private void updateLauProperties(String lauKeyFP, String lauKeySP, Integer diasVigencia, Date validoDesde, String clientes, String keyLauSystem, String codUsuario,
			String estacion) throws Exception {
		validCodeLauRules(lauKeyFP, lauKeySP);
		String lauKeyFPEncryptedContent = UtilsSec.easeyEncrypt(lauKeyFP);
		String lauKeySPEncryptedContent = UtilsSec.easeyEncrypt(lauKeySP);
		String lauIdProp = generateKeyDigest(lauKeyFP + lauKeySP);

		Properties properties = createProperties(secretStoreProp, lauKeyFPEncryptedContent, lauKeySPEncryptedContent, lauIdProp, diasVigencia, validoDesde, clientes,
				keyLauSystem, codUsuario, estacion);

		doBackupFile(pathFileProperties, LAU_FILESTORE_PATHDIRBACKUP);

		UtilsProperties.store(pathFileProperties, properties, "Archivo LAU creado por " + codUsuario + " estacion: " + estacion);
	}

	private void initializeProperties() throws Exception {
		File f = new File(pathFileProperties);

		if (f.exists() && f.isFile()) {
			properties = UtilsProperties.loadFileMsgProperties(pathFileProperties);
			log.info("Propiedades LAU inicializado {}", pathFileProperties);
		} else {
			Properties propertiesNew = new Properties();
			properties = UtilsProperties.store(pathFileProperties, propertiesNew, "Archivo LAU no inicializado");
			log.info("Propiedades LAU creado {}", pathFileProperties);
		}

		if (properties == null) {
			throw new Exception("No se pudo crear archivo propiedades LAU");
		}

		secretStoreProp = properties.getProperty(PROP_LAU_SECRET);
		log.info("secretStoreProp {}", secretStoreProp);
		lauKeyFirstPartProp = properties.getProperty(PROP_LAU_KEY_FIRST);
		lauKeySecondPartProp = properties.getProperty(PROP_LAU_KEY_SECOND);
		lauIdProp = properties.getProperty(PROP_LAU_ID);
		keyLauSystemProp = properties.getProperty(PROP_LAU_CODE_SYSTEM);
		diasVigencia = getPropDiasVigenciaLau();
		fechaCreacion = getPropFechaLau();
		canExecuteSign = !StringUtils.isBlank(secretStoreProp) && !StringUtils.isBlank(lauKeyFirstPartProp) && !StringUtils.isBlank(lauKeySecondPartProp);

		if (canExecuteSign) {
			fechaCaducidad = calularFechaCaducidad(fechaCreacion, diasVigencia);
		}
		log.info("KS lauIdProp: " + lauIdProp + " diasVigencia: " + diasVigencia + " fechaCreacion: " + fechaCreacion + " canExecuteSign: " + canExecuteSign + " fechaCaducidad: "+ fechaCaducidad);
	}

	private Properties createProperties(String pswFileStore, String lauKeyFP, String lauKeySP, String lauIdProp, Integer diasVigencia, Date validoDesde, String clientes,
			String keyLauSystem, String codUsuario, String estacion) {
		if (StringUtils.isBlank(pswFileStore)) {
			log.error("Código Key LAU (FirstPart o SecondPart) nulo");
			// throw new RuntimeException("Código Key LAU (FirstPart o
			// SecondPart) nulo");
		}

		Properties properties = new Properties();
		properties.setProperty(PROP_LAU_FECHA, UtilsDate.stringFromDate(validoDesde, FECHA_FORMAT_LAU_PROP));
		properties.setProperty(PROP_LAU_CODUSUARIO, codUsuario);
		properties.setProperty(PROP_LAU_ESTACION, estacion);

		properties.setProperty(PROP_LAU_SECRET, pswFileStore);

		if (diasVigencia != null)
			properties.setProperty(PROP_LAU_DIASVIGENCIA, String.valueOf(diasVigencia));
		else
			properties.setProperty(PROP_LAU_DIASVIGENCIA, String.valueOf(LAU_KEY_DIASVIGENCIA_DEFAULT));

		properties.setProperty(PROP_LAU_KEY_FIRST, lauKeyFP);
		properties.setProperty(PROP_LAU_KEY_SECOND, lauKeySP);
		properties.setProperty(PROP_LAU_ID, lauIdProp);
		properties.setProperty(PROP_LAU_CODE_SYSTEM, keyLauSystem);
		return properties;
	}

	private ICryptoUtil getEncriptor(String pathFileKeystore, String password, String passwordLau, boolean createKeystoreFileIfNotExist, boolean createdKeyLauIfNotExists) {
		ICryptoUtil cryptoUtil = new CryptoUtilImpl();
		try {
			cryptoUtil.initialize(pathFileKeystore, password, passwordLau, createKeystoreFileIfNotExist, createdKeyLauIfNotExists);
		} catch (Exception e) {
			log.error("Error al generar cryptoutil " + e.getMessage(), e);
			throw new CryptoExceptionLau(e);
		}
		return cryptoUtil;
	}

	public static Date calularFechaCaducidad(Date fechaCreacion, int diasVigencia) {
		final int unidTiempoDias = 5;

		if (fechaCreacion == null)
			throw new RuntimeException("Fecha de creación de lau inválido");

		if (diasVigencia == 0) {
			// no tiene caducidad ampliamos a 8 años
			return UtilsDate.addTime(fechaCreacion, 365 * 8, unidTiempoDias);
		}

		return UtilsDate.addTime(fechaCreacion, diasVigencia, unidTiempoDias);
	}

	/* getters and setters for properties */
	private Integer getPropDiasVigenciaLau() {
		String lauDias = properties.getProperty(PROP_LAU_DIASVIGENCIA);
		Integer dias = null;
		if (!StringUtils.isBlank(lauDias) && NumberUtils.isNumber(lauDias))
			dias = Integer.valueOf(lauDias);
		else
			dias = LAU_KEY_DIASVIGENCIA_DEFAULT;
		return dias;
	}

	public String getLauIdProp() {
		return lauIdProp;
	}

	/**
	 * Obtiene la fecha de registro del codigo lau, sino existe retorna nulo
	 * 
	 * @return fecha
	 */
	private Date getPropFechaLau() {
		String lauFecha = properties.getProperty(PROP_LAU_FECHA);
		Date fecha = null;
		if (!StringUtils.isBlank(lauFecha))
			fecha = UtilsDate.dateFromString(lauFecha, FECHA_FORMAT_LAU_PROP);

		return fecha;
	}

	public void deleteFilesLau() {
		log.info("On delete files {}, {}", pathFileKeystore, pathFileProperties);
		doBackupFile(pathFileKeystore, LAU_FILESTORE_PATHDIRBACKUP);
		doBackupFile(pathFileProperties, LAU_FILESTORE_PATHDIRBACKUP);
	}

	private void doBackupFile(String pathFileToBackup, String pathDirBackup) {
		File f = new File(pathFileToBackup);

		if (f.exists() && f.isFile()) {
			try {
				UtilsFile.copy(pathFileToBackup, pathDirBackup + "/" + lauIdProp + "." + UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd"));
			} catch (IOException e) {
			}
			new File(pathFileToBackup).delete();
			log.info("Backup de {} -> {}", pathFileToBackup, pathDirBackup + "/" + lauIdProp + "." + UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd"));
		}
	}

	private void validCodeLauRules(String lauKeyFP, String lauKeySP) {
		if (StringUtils.isBlank(lauKeyFP) || StringUtils.isBlank(lauKeySP)) {
			log.error("Código Key LAU (FirstPart o SecondPart) nulo");
			throw new RuntimeException("Código Key LAU (FirstPart o SecondPart) nulo");
		}

		if (lauKeyFP.trim().length() != 16 || lauKeySP.trim().length() != 16) {
			log.error("Código Key LAU (FirstPart o SecondPart) debe tener 16 caracteres");
			throw new RuntimeException("Código Key LAU (FirstPart o SecondPart) debe tener 16 caracteres");
		}

	}

	public boolean isRegisterCodeLau() {
		return (cryptoUtil.getActiveProvider().getKey(CryptoProviderImpl.KEY_ALIAS_MACLAU) != null);
	}

	public boolean isRegisterCodeLauSystem() {
		return (cryptoUtil.getActiveProvider().getKey(CryptoProviderImpl.KEY_ALIAS_SYSTEM) != null && keySystem != null && StringUtils.isBlank(keyLauSystemProp));
	}

	/* encriptaciones */

	// public String encrypt(String strPlain) {
	// return cryptoUtil.encryptAndBase64(strPlain.getBytes(), keySystem);
	// }
	//
	// public String decrypt(String strPlain) throws Exception {
	// return cryptoUtil.decryptBase64ToString(strPlain, keySystem);
	// }

	public String signLau(final String strPlain) throws Exception {
		Key keyMac = cryptoUtil.getActiveProvider().getKey(CryptoProviderImpl.KEY_ALIAS_MACLAU);
		if (keyMac == null) {
			throw new RuntimeException("Código Key LAU no inicializado");
		}
		if (StringUtils.isBlank(strPlain)) {
			throw new RuntimeException("Proceso Lau mensaje a firmar nulo.");
		}
		return cryptoUtil.getMacHash(strPlain, keyMac);
	}

	public String signLauSystem(String strPlain) throws Exception {

		return signLau(CryptoProviderImpl.KEY_ALIAS_SYSTEM, strPlain);
	}

	public String signLau(String keyAlias, String strPlain) throws Exception {
		Key key = cryptoUtil.getActiveProvider().getKey(keyAlias);

		if (key == null) {
			throw new RuntimeException("Código Key LAU no inicializado " + keyAlias);
		}
		return cryptoUtil.getMacHash(strPlain, key);
	}

	public boolean existKey(String keyAlias) {
		return cryptoUtil.getActiveProvider().getKey(keyAlias) != null;
	}

	public void signLauSystemValidate(String content, String codeLauGive) throws Exception {
		String codeLauExpected = "";
		if (StringUtils.isBlank(content))
			throw new Exception("Valor a verificar lau nulo");

		if (StringUtils.isBlank(codeLauGive))
			throw new Exception("Código Lau a comparar nulo");

		try {
			codeLauExpected = signLauSystem(content);
		} catch (Exception e) {
			log.error("Error al validar lau " + e.getMessage(), e);
			throw new Exception(e);
		}

		if (codeLauExpected != null && !codeLauExpected.equals(codeLauGive)) {
			log.error("Código lau inválido {} Esperado:{} [{}]", codeLauGive, codeLauExpected, content);
			throw new Exception("Código lau inválido");
		}
	}

	public void signLauValidate(String content, String codeLauGive) throws Exception {
		String codeLauExpected = "";
		if (StringUtils.isBlank(content))
			throw new Exception("Valor a verificar lau nulo");

		if (StringUtils.isBlank(codeLauGive))
			throw new Exception("Código Lau a comparar nulo");

		try {
			codeLauExpected = signLau(content);
		} catch (Exception e) {
			log.error("Error al validar lau " + e.getMessage(), e);
			throw new Exception(e);
		}

		if (codeLauExpected != null && !codeLauExpected.equals(codeLauGive)) {
			log.error("Código lau inválido {} Esperado:{} [{}]", codeLauGive, codeLauExpected, content);
			throw new Exception("Código lau inválido");
		}
	}

	public String exportKeyToStr(String keyAlias, String keyAliasExport, String keyPassword) throws Exception {
		return cryptoUtil.getActiveProvider().exportKeyToStr(keyAlias, keyAliasExport, keyPassword);
	}

	public void importKeyFromString(String fsEncode, String passFs, String keyAlias, String keyAliasNew, String keyPassword) throws Exception {
		cryptoUtil.getActiveProvider().importKeyFromString(fsEncode, passFs, keyAlias, keyAliasNew, keyPassword);
	}

	public String generateKeyDigest(String value) {
		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance(ALGORITHM_256);
			byte[] bytes = digest.digest(value.getBytes("UTF-8"));
			return String.format("%032x", new BigInteger(1, bytes));
		} catch (NoSuchAlgorithmException nsae) {
			throw new IllegalStateException("MD5 algorithm not available.  Fatal (should be in the JDK).", nsae);
		} catch (UnsupportedEncodingException uee) {
			throw new IllegalStateException("UTF-8 encoding not available.  Fatal (should be in the JDK).", uee);
		}
	}

	public void validateKeyDigest(String valueData, String codeGive) throws Exception {
		String codeExpected = generateKeyDigest(valueData);

		if (codeExpected != null && !codeExpected.equals(codeGive)) {
			log.error("Código de verificación inválido codeExpected: {} codeGive: {}", codeExpected, codeGive);
			throw new Exception("Código de verificación inválido ");
		}
	}

	public GenLauDto getGenLauDto() {
		GenLauDto genLauDto = new GenLauDto();
		if (isRegisterCodeLau()) {
			genLauDto.setLauKeyFirstPart(UtilsSec.easeyDecrypt(lauKeyFirstPartProp));
			genLauDto.setLauKeySecondPart(UtilsSec.easeyDecrypt(lauKeySecondPartProp));
			genLauDto.setDiasVigencia(diasVigencia);
			genLauDto.setFechaCreacion(fechaCreacion);
			genLauDto.setFechaCaducidad(fechaCaducidad);
		}
		return genLauDto;
	}

	public static GenLauDto getGenLauDtoFromStringEncoded(String datCodeLau) {
		GenLauDto genLauDtoNew = new GenLauDto();
		genLauDtoNew.setFechaCreacion(new Date());
		genLauDtoNew.setDiasVigencia(GeneratorLAU.LAU_KEY_DIASVIGENCIA_DEFAULT);
		genLauDtoNew.setLauEstado("");
		genLauDtoNew.setLauKeyFirstPart("");
		genLauDtoNew.setLauKeySecondPart("");

		if (!StringUtils.isBlank(datCodeLau)) {
			try {
				// decript valor cadena
				String ctrldt = UtilsSec.easeyDecrypt(new String(Base64.decodeBase64(datCodeLau)));
				Map<String, String> map = UtilsGeneric.paramsLista(ctrldt);

				String lauKeyFP = map.get("lfp");
				String lauKeySP = map.get("lsp");
				Date fechaC = new Date();
				if (map.containsKey("lfc"))
					fechaC = UtilsDate.dateFromString(map.get("lfc"), FECHA_FORMAT_LAU_PROP);
				Integer diasVig = 0;
				if (map.containsKey("ldv"))
					diasVig = Integer.valueOf(map.get("ldv"));
				String lauEstado = map.get("lst");

				genLauDtoNew.setLauKeyFirstPart(lauKeyFP);
				genLauDtoNew.setLauKeySecondPart(lauKeySP);
				genLauDtoNew.setFechaCreacion(fechaC);
				genLauDtoNew.setDiasVigencia(diasVig);
				genLauDtoNew.setLauEstado(lauEstado);
				
				if (fechaC != null){ 
					Date fechaCad = calularFechaCaducidad(fechaC, diasVig);
					genLauDtoNew.setFechaCaducidad(fechaCad);
				}
			} catch (Exception e) {
				log.error("error al decodificar " + datCodeLau);
			}
		}
		return genLauDtoNew;
	}

	public static void main(String[] args) {
		String parValor = "lfp=AkrRrTHTP0E78XOb&lsp=P8IFzTgV940GCa02&ldv=90&lfc=29-11-2017&lst=NUEVO";
		String parValorEnc = Base64.encodeBase64String(UtilsSec.easeyEncrypt(parValor).getBytes());
		System.out.println(parValorEnc);
		String datCodeLau = "QUF7WFtaWVpTNUhofnxxTjdJSFF9NFdRfDRXU300fl1xfHFOe29YVDZWS2ZxTUhRbFI0VntVWFNbaEtaOl5ZVzhFWlR7UkxmcU02WF1sflJKRkhZWWxJWn1OcGd2SllUe15LZg==";
		String ctrldt = UtilsSec.easeyDecrypt(new String(Base64.decodeBase64(datCodeLau)));
		System.out.println(ctrldt);
	}

	public Key getKeyMac() {
		return keyMac;
	}
}
