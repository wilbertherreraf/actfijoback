package gob.bcb.lavado.client.crypto;

import java.security.GeneralSecurityException;
import java.security.Key;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CryptoUtilImpl implements ICryptoUtil{	
	private static final Logger log = LoggerFactory.getLogger(CryptoUtilImpl.class);
	private CryptoProvider activeProvider;
	/**
	 * The size of a bare DSA signature (two 160-bit integers)
	 */
	static public final int BARE_DSA_SIGNATURE_SIZE = 40;

	public void initialize(String fileKeystore, String password, String passwordLau, boolean createKeystoreFileIfNotExist, boolean errorIfNotExist) throws Exception {
		//log.info("initialize CryptoUtil " + fileKeystore);
		activeProvider = new CryptoProviderImpl(fileKeystore, password, passwordLau, createKeystoreFileIfNotExist, errorIfNotExist);		
	}

	public void addCryptoKeyToKeyStore(String fileKeystore, String password, Key key, String nameKey, String keyAlias, String keyPassword) throws Exception {
		activeProvider.addKey(fileKeystore, password,key, nameKey, keyAlias, keyPassword);
	}
	
	private byte[] encryptBytes(byte[] data, Key key) {
		try {
			Cipher cipher = activeProvider.getCipher(key, Cipher.ENCRYPT_MODE);
			return cipher.doFinal(data);
		} catch (GeneralSecurityException e) {
			throw new CryptoExceptionLau("Crypto engine failed to encrypt", e);
		}
	}

	private byte[] decryptBytes(byte[] data, Key key) throws IllegalBlockSizeException, BadPaddingException {
		try {
			Cipher cipher = activeProvider.getCipher(key, Cipher.DECRYPT_MODE);
			return cipher.doFinal(data);
		} catch (Exception e) {
			throw new CryptoExceptionLau("Crypto engine failed to initialize decryption", e);
		}
	}

	// @Override
	public String encryptAndBase64(byte[] data, Key key) {
		return Base64.encodeBase64String(encryptBytes(data, key));
	}

	// @Override
	public byte[] decryptBase64(String base64andEncrypted, Key key) throws IllegalBlockSizeException, BadPaddingException {
		return decryptBytes(Base64.decodeBase64(base64andEncrypted), key);
	}

	public String decryptBase64ToString(String base64andEncrypted, Key key) throws Exception {
			//Key key = cryptoUtil.getCryptoKey("UrlContent");
		byte[] based64DecryptedContent = decryptBase64(base64andEncrypted.replaceAll("\\.", "+"), key);

		return new String(based64DecryptedContent);
	}

	public String getMacHash(final String data, Key key) throws Exception {
		try {
			Mac hasher = activeProvider.initCipherMac(key);
			byte[] hash = hasher.doFinal(data.getBytes());
			return DatatypeConverter.printHexBinary(hash);
		} catch (Exception e) {
			log.error("Error al generar codigo LAU " + e.getMessage(), e);
			throw new Exception("Codigo LAU " + e.getMessage(), e);
		}
	}	
	
	public CryptoProvider getActiveProvider() {
		return activeProvider;
	}
}
