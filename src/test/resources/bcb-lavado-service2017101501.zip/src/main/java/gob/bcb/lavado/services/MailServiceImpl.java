package gob.bcb.lavado.services;

import java.util.Locale;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.CharEncoding;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring4.SpringTemplateEngine;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfParamsDao;

@Service("mailService")
public class MailServiceImpl implements MailService {
	private static final Logger log = LoggerFactory.getLogger(MailServiceImpl.class);

	@Autowired
	private JavaMailSenderImpl javaMailSender;
	@Autowired
	private SpringTemplateEngine templateEngine;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private SwfParamsDao swfParamsDao;

	@Async
	public void sendEmail(String[] to, String subject, String content, boolean isMultipart, ArchivoSinple archivoSinple, boolean isHtml) {
		log.info("Send e-mail[multipart '{}' and html '{}'] to '{}' with subject '{}' and content={}", isMultipart, isHtml, to, subject, content);
		// Prepare message using a Spring helper
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		try {
			SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CORREOREMITENTE);
			String from = swfParams.getParValor();

			MimeMessageHelper message = new MimeMessageHelper(mimeMessage, isMultipart, CharEncoding.UTF_8);
			message.setTo(to);
			message.setFrom(from);
			message.setSubject(subject);
			message.setText(content, isHtml);

			if (archivoSinple != null) {
				Resource resource = new ByteArrayResource(archivoSinple.getData());
				message.addAttachment(archivoSinple.getNameOriginal(), resource);
			}

			javaMailSender.send(mimeMessage);
			log.info("==>Sent e-mail to User '{}'", ArrayUtils.toString(to));
		} catch (Exception e) {
			log.error("E-mail could not be sent to user '{}', exception is: {}", to, e.getMessage());
		}
	}

	@Async
	public void sendAlertSwiftForRevisionEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle, ArchivoSinple archivoSinple) {
		log.info("Sending sendAlertSwiftForRevisionEmail e-mail to '{}'", ArrayUtils.toString(emailDetalle.getTo()));
		Locale locale = Locale.getDefault();
		Context context = new Context(locale);
		context.setVariable("swfMensaje", mensajesDatos.getSwfMensaje());
		log.debug("Thymeleaf Initialized " + templateEngine.isInitialized());
		if (!templateEngine.isInitialized()) {
			templateEngine.initialize();
			log.info("Thymeleaf initialized!!! " + templateEngine.isInitialized());
		}

		String content = templateEngine.process("alertaVerificacionEmail", context);

		if (StringUtils.isBlank(emailDetalle.getSubject())){
			String subject = messageSource.getMessage("email.alertalavado.title", null, locale);			
			emailDetalle.setSubject(subject);
		}
		sendEmail(emailDetalle.getTo(), emailDetalle.getSubject(), content, false, null, true);
	}

	@Async
	public void sendAlertSwiftAutorizadoEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle, ArchivoSinple archivoSinple) {
		log.info("Sending sendAlertSwiftAutorizadoEmail e-mail to '{}'", ArrayUtils.toString(emailDetalle.getTo()));
		Locale locale = Locale.getDefault();
		Context context = new Context(locale);
		context.setVariable("swfMensaje", mensajesDatos.getSwfMensaje());
		log.debug("Thymeleaf Initialized " + templateEngine.isInitialized());
		if (!templateEngine.isInitialized()) {
			templateEngine.initialize();
			log.info("Thymeleaf initialized!!! " + templateEngine.isInitialized());
		}

		String content = templateEngine.process("alertaAutorizacionEmail", context);
		String subject = messageSource.getMessage("email.alertaautorizacion.title", null, locale);

		sendEmail(emailDetalle.getTo(), subject, content, false, null, true);
	}	
	@Async
	public void sendSwiftAsignForProcessWithAttachEmail(MensajesDatos mensajesDatos, EmailDetalle emailDetalle, ArchivoSinple archivoSinple) {
		log.info("Sending creation sendSwiftAsignForProcessWithAttachEmail e-mail to '{}'", ArrayUtils.toString(emailDetalle.getTo()));
		Locale locale = Locale.getDefault();
		Context context = new Context(locale);
		context.setVariable("swfMensaje", mensajesDatos.getSwfMensaje());
		log.debug("Thymeleaf Initialized " + templateEngine.isInitialized());
		if (!templateEngine.isInitialized()) {
			templateEngine.initialize();
			log.info("Thymeleaf initialized!!! " + templateEngine.isInitialized());
		}

		String content = templateEngine.process("envioConAdjunto", context);
		String subject = messageSource.getMessage("email.sendattach.title", null, locale);

		sendEmail(emailDetalle.getTo(), subject, content, true, archivoSinple, true);
	}
}
