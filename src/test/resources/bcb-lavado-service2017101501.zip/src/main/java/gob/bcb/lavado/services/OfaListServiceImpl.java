package gob.bcb.lavado.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.Statement;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;

import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.commons.ArchivoSinpleServiceImpl;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.config.LavadoProperties;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.ofac.OfacLoader;
import gob.bcb.lavado.repository.SwfLoteDao;
import gob.bcb.lavado.repository.SwfParamsDao;

@Service(value = "ofaListService")
@Transactional
public class OfaListServiceImpl implements OfaListService {
	private static final Logger log = LoggerFactory.getLogger(OfaListServiceImpl.class);
	@Autowired
	private OfacLoader ofacLoader;
	@Autowired
	private SwfParamsDao swfParamsDao;
//	@Autowired
//	private LavadoProperties lavadoProperties;
	@Autowired
	private AppProperties appProperties;	
	@Autowired
	private SwfLoteDao swfLoteDao;
	@Autowired
	@Qualifier("dataSourceSwift")
	protected DataSource dataSourceSwift;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.lavado.services.OfaListService#cargarListaOfac(java.lang.
	 * String)
	 */
	@Transactional
	public void cargarListaOfac(String fileSdn, Integer nrolote) {
		log.info("Inicio carga lista OFAC desde " + fileSdn + " nrolote: " + nrolote);
		long startTime = System.currentTimeMillis();
		try {
			Integer regs = ofacLoader.readFileToOfaSdnentry(fileSdn, nrolote);
			log.info("Done[lote : " + nrolote + " ] cargarListaOfac[regs: " + regs + "] at (" + (System.currentTimeMillis() - startTime) + " ms.)");
		} catch (UnexpectedInputException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (ParseException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (Throwable e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		log.info("committing...");
	}

	private int loadListsFromDirectory(String inputDirectory, boolean continueIfExist, String codusuario, String estacion) throws Exception {
		String dirFileDest = appProperties.getLavado().getAppdir() + "/" + Constants.DIR_OFAC_FILES;
		log.info("Cpy archivos de: {} a: {}", inputDirectory, dirFileDest);
		int count = 0;
		for (Path filePath : Files.newDirectoryStream(FileSystems.getDefault().getPath(inputDirectory))) {
			File f = filePath.toFile();
			if (f.isDirectory()) {
				continue;
			}
			String nameFile = f.getName();
			File fDest = new File(dirFileDest, nameFile);
			if (fDest.exists() && !fDest.isDirectory()) {
				if (!continueIfExist) {
					log.info("Archivo OFAC existente {}", nameFile);
					//continue;
				}
			}

			String pathFileSource = f.getAbsolutePath();
			String content;
			try (FileInputStream fis = new FileInputStream(f); InputStreamReader reader = new InputStreamReader(fis, Charsets.UTF_8)) {
				content = CharStreams.toString(reader);
				String contentFile = UtilsGeneric.getShortText(content, 188);
				if (contentFile.toLowerCase().contains("<sdnlist")) {
					log.info("CPY: Archivo SDN XML " + pathFileSource + " ==> " + contentFile);
					SwfLote swfLoteNew = crearSwfLoteOfac(pathFileSource, codusuario, estacion);
					cargarListaOfac(pathFileSource, swfLoteNew.getLotNrolote());
					count++;
				}
			}

			try {
				String p = UtilsFile.copiarArchivo(pathFileSource, fDest.getAbsolutePath(), false);
				log.info("Proceso TMP: Archivo ofac!!! en " + p);
			} catch (Exception e) {
				log.error("Error al guardar archivo " + pathFileSource + ": " + e.getMessage(), e);
				throw new RuntimeException(e);
			}
		}
		if (count == 0){
			throw new RuntimeException("No se procesó ningún archivo desde el directorio " + inputDirectory  + " verifique la existencia de archivos con formato XML" );
		}
		return count;
		
	}

	public void loadListsFromDirectory(String codusuario, String estacion) throws Exception {
		String inputDirectory = appProperties.getLavado().getAppdir() + "/" + Constants.DIR_OFAC_FILES_DESCARGA;
		log.info("Inicio cargado de archivo desde " + inputDirectory);
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_TIPPROCOFAC);
		// determina si se guarda los registros si el archivo existe
		boolean continueIfExist = false;
		if (swfParams != null) {
			String tipoProceso = swfParams.getParValor();
			continueIfExist = (tipoProceso != null && tipoProceso.trim().toUpperCase().equals("S"));
		}

		loadListsFromDirectory(inputDirectory, continueIfExist,codusuario, estacion);
		log.info("Archivos guardados de directorio " + inputDirectory);

	}

	private SwfLote crearSwfLoteOfac(String pathFileSource, String codusuario, String estacion) {
		log.info("pathFileSource " + pathFileSource);

		String nameFileOriginal = ArchivoUtil.getOriginalFilename(pathFileSource);
		ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
		archivoSinpleService.fromPathfile(pathFileSource, nameFileOriginal);
		archivoSinpleService.getArchivoSinple().setDirectory(appProperties.getLavado().getAppdir() + "/" + Constants.DIR_OFAC_FILES_TMP);

		SwfLote swfLoteNew = swfLoteDao.guardarLoteOfac(codusuario, archivoSinpleService.getArchivoSinple(), false, estacion);
		return swfLoteNew;
	}

	public void truncateTablesOfac(String codUsuario, String estacion) throws Throwable {
		log.info("truncateTablesOfac codUsuario {}, estacion {}", codUsuario, estacion);		
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_TRUNCATEOFAC);
		boolean truncarTables = false;
		// verificamos que el parametro este habilitado para truncar 
		if (swfParams != null) {
			String tipoProceso = swfParams.getParValor();
			truncarTables = (tipoProceso != null && tipoProceso.trim().toUpperCase().equals("S"));
		}
		if (!truncarTables) {
			throw new Exception(
					"Proceso requiere que el parametro " + Constants.PARAM_TRUNCATEOFAC + " tenga valor 'S', cambie el valor para continuar");
		}
		log.info("##### Truncando tablas por codUsuario: " + codUsuario + " #####" + " " + estacion);
		truncateTablesOfac();
	}

	private void truncateTablesOfac() throws Throwable {
		final Connection connection = dataSourceSwift.getConnection();
		final Statement statement = connection.createStatement();

		log.info("truncate tables ofacs Catalog: " + dataSourceSwift.getConnection().getCatalog() + " isClosed: " + dataSourceSwift.getConnection().isClosed());
		statement.executeUpdate("truncate ofa_addresslist;");
		statement.executeUpdate("truncate ofa_akalist;");
		statement.executeUpdate("truncate ofa_citizenship;");
		statement.executeUpdate("truncate ofa_dateofbirth;");
		statement.executeUpdate("truncate ofa_idlist;");
		statement.executeUpdate("truncate ofa_nationality;");
		statement.executeUpdate("truncate ofa_placeofbirth;");
		statement.executeUpdate("truncate ofa_publshinform;");
		statement.executeUpdate("truncate ofa_vesselinfo;");
		statement.executeUpdate("truncate ofa_sdnentry;");
		connection.close();
		log.info("Tablas ofacs TRUNCADAS!!!");
	}
}
