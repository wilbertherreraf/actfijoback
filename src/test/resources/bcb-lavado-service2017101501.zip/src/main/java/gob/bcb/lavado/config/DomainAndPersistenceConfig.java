package gob.bcb.lavado.config;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.repository.BancosRepository;
import gob.bcb.lavado.repository.SwfMensajeDaoImpl;
import gob.bcb.lavado.search.OfacIndexer;
import gob.bcb.lavado.security.database.DatabaseUpdate;

@Configuration
@ConfigurationProperties(prefix = Constants.PROP_PREFIX_LAVADO)
@EnableJpaRepositories(basePackageClasses = BancosRepository.class)
@EnableTransactionManagement
public class DomainAndPersistenceConfig extends HikariConfig {
	private static final Logger log = LoggerFactory.getLogger(DomainAndPersistenceConfig.class);

	@Autowired
	private AppProperties appProperties;

	public DomainAndPersistenceConfig() {
		log.info("creando DomainAndPersistenceConfig");
	}
	// @Bean(name = "dataSourceSwift", destroyMethod = "close")
	// @Primary
	// public DataSource dataSourceSwift() throws IllegalArgumentException,
	// NamingException {
	// log.info("dataSourceSwift " + appProperties.getLavado().getAppdir() + " "
	// + getDataSourceJNDI());
	// JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
	// bean.setJndiName(getDataSourceJNDI());
	// bean.setProxyInterface(DataSource.class);
	// bean.setLookupOnStartup(false);
	// bean.afterPropertiesSet();
	//
	// HikariDataSource ds = new HikariDataSource();
	// ds.setDataSource((DataSource) bean.getObject());
	// ds.addDataSourceProperty("cachePrepStmts", "true");
	// ds.addDataSourceProperty("useServerPrepStmts", "true");
	// ds.setConnectionTestQuery("select * from swf_params");
	// ds.setAutoCommit(false);
	// ds.setPoolName(Constants.PUNIT_LAVADO);
	//
	// return ds;
	// }

	@Bean(name = "dataSourceSwift")
	@Primary
	public DataSource dataSourceSwift() throws NamingException {
		log.info("dataSourceSwift========= ");
		JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
		bean.setJndiName(getDataSourceJNDI());
		bean.setProxyInterface(DataSource.class);
		bean.setLookupOnStartup(false);
		bean.afterPropertiesSet();
		return (DataSource) bean.getObject();
	}

	private JpaVendorAdapter jpaVendorAdapter() {
		HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
		hibernateJpaVendorAdapter.setShowSql(false);
		hibernateJpaVendorAdapter.setDatabase(Database.INFORMIX);
		hibernateJpaVendorAdapter.setDatabasePlatform("org.hibernate.dialect.InformixDialect");

		return hibernateJpaVendorAdapter;
	}

	@Bean(name = "entityManagerFactory")
	@Primary
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(@Qualifier("dataSourceSwift") DataSource dataSourceSwift) {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();

		em.setDataSource(dataSourceSwift);
		em.setPackagesToScan(SwfBics.class.getPackage().getName(), SwfMensajeDaoImpl.class.getPackage().getName());
		em.setJpaVendorAdapter(jpaVendorAdapter());
		em.setJpaPropertyMap(jpaProperties());
		em.setPersistenceUnitName(Constants.PUNIT_LAVADO);
		//em.afterPropertiesSet();
		log.info("config entityManagerFactory hecho... " + em.getPersistenceUnitName());
		return em;
	}

	@Bean(name = "transactionManager")
	@Primary
	public JpaTransactionManager transactionManager(@Qualifier("entityManagerFactory") LocalContainerEntityManagerFactoryBean entityManagerFactory) {
		log.info("%%%%%%%%%%% transactionManager %%%%%%%%%%%%");
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory.getObject());
		return transactionManager;
	}

	@Bean(name = "exceptionTranslation")
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}

	private Map<String, ?> jpaProperties() {
		Map<String, Object> jpaPropertiesMap = new HashMap<String, Object>();
		log.info("Setting hibernate.search.default.indexBase in: " + appProperties.getLavado().getSearch().getIndexdir());
		
//		jpaPropertiesMap.put("hibernate.hikari.leakDetectionThreshold", "3000");
//		jpaPropertiesMap.put("hibernate.hikari.registerMbeans", "true");
		
		jpaPropertiesMap.put("hibernate.search.default.directory_provider", "filesystem");
		jpaPropertiesMap.put("hibernate.search.default.indexBase", appProperties.getLavado().getSearch().getIndexdir());
		jpaPropertiesMap.put("hibernate.search.lucene_version", org.apache.lucene.util.Version.LATEST.toString());
		// refresh every half hour
		jpaPropertiesMap.put("hibernate.search.default.refresh", "1800");
		jpaPropertiesMap.put("hibernate.search.default.optimizer.operation_limit.max", "10");
		jpaPropertiesMap.put("hibernate.search.indexing_strategy", "event");

		jpaPropertiesMap.put("hibernate.search.model_mapping", OfacIndexer.buildProgrammaticSearchMapping());

		jpaPropertiesMap.put("hibernate.current_session_context_class", "jta");
		jpaPropertiesMap.put("hibernate.transaction.manager_lookup_class", "org.springframework.orm.hibernate4.HibernateTransactionManager");
		
		jpaPropertiesMap.put("hibernate.c3p0.min_size", String.valueOf(5));
		jpaPropertiesMap.put("hibernate.c3p0.max_size", String.valueOf(50));
		jpaPropertiesMap.put("hibernate.c3p0.timeout", String.valueOf(300));
		//jpaPropertiesMap.put("hibernate.c3p0.max_statements", String.valueOf(50));
		jpaPropertiesMap.put("hibernate.c3p0.idle_test_period", String.valueOf(3000));
		
		return jpaPropertiesMap;
	}

	@Bean(name = "textEncryptor")
	public TextEncryptor textEncryptor(@Qualifier("dataSourceSwift") DataSource dataSourceSwift) throws Exception {
		// InitialContext jndiEnc = new InitialContext();
		// DataSource ds = (DataSource) jndiEnc.lookup(Constants.JNDI_LAVADO);
		// log.info("::::::> Actualizando encryptor <:::::: " + (ds == null));
//		Connection connection = dataSourceSwift.getConnection();
//		log.info("dataSourceSwift connection.isClosed " + connection.isClosed());
		String pathFileConfig = appProperties.getSecurity().getEncryptor().getPathFileConfig();
		DatabaseUpdate databaseUpdate = new DatabaseUpdate(dataSourceSwift, pathFileConfig);
		// DatabaseUpdate databaseUpdate = new DatabaseUpdate(ds,
		// pathFileConfig);
		TextEncryptor textEncryptor = databaseUpdate.run();
		log.info("::::::> fin Actualizando encryptor <::::::");
		return textEncryptor;
	}

}
