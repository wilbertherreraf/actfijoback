package gob.bcb.lavado.services;

import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry;

public interface SdnListMapper {
	OfaSdnentry getOfaSdnentry(SdnEntry sdnEntry, Integer nrolote);
}