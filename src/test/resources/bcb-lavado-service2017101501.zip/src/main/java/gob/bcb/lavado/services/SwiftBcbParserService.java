package gob.bcb.lavado.services;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import gob.bcb.lavado.model.SwfDetmensaje;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.swift.SwiftMessageBcb;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

public interface SwiftBcbParserService {

	/**
	 * Genera una lista de objetos mensaje datos desde un archivo plano RJE
	 * @param planoLote
	 * @return
	 * @throws IOException
	 */
	List<MensajesDatos> swfMensajeFromLote(String planoLote);

	/**
	 * Desparsea un mensaje plano descomponiento {@link SwiftDatos} y en una lista {@link SwfDetmensaje}
	 * @param menPlano mensaje en formato plano
	 * @param codUsr usuario audit
	 * @return
	 */
	SwiftDatos swiftDatosFromString(String menPlano);

	List<Block4> block4FromString(String menPlano);

	SwiftDatos actualizarSwfMensajeFromPlano(SwfMensaje swfMensaje, String menplano);

	List<Block4> createListBlock4(SwiftMessageBcb swiftMessageBcb, boolean requireDescrip);

	String decryptPlano(String menPlano);
}
