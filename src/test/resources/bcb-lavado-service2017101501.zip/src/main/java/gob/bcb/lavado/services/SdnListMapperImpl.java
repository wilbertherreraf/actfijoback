package gob.bcb.lavado.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.lavado.model.OfaAddresslist;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaCitizenship;
import gob.bcb.lavado.model.OfaDateofbirth;
import gob.bcb.lavado.model.OfaIdlist;
import gob.bcb.lavado.model.OfaNationality;
import gob.bcb.lavado.model.OfaPlaceofbirth;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.model.OfaVesselinfo;
import gob.bcb.lavado.ofac.dto.SdnListDTO;
import gob.bcb.lavado.ofac.xml.sdn.SdnList;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry;
import gob.bcb.lavado.repository.OfaAddresslistRepository;
import gob.bcb.lavado.repository.OfaAkalistRepository;
import gob.bcb.lavado.repository.OfaCitizenshipRepository;
import gob.bcb.lavado.repository.OfaDateofbirthRepository;
import gob.bcb.lavado.repository.OfaIdlistRepository;
import gob.bcb.lavado.repository.OfaNationalityRepository;
import gob.bcb.lavado.repository.OfaPlaceofbirthRepository;
import gob.bcb.lavado.repository.OfaSdnentryRepository;
import gob.bcb.lavado.repository.OfaVesselinfoRepository;

@Service(value = "sdnListMapper")
@Transactional
public class SdnListMapperImpl implements SdnListMapper {
	private static final Logger log = LoggerFactory.getLogger(SdnListMapperImpl.class);
	@Autowired
	private OfaSdnentryRepository ofaSdnentryRepository;

	@Autowired
	private OfaAkalistRepository ofaAkalistRepository;

	@Autowired
	private OfaIdlistRepository ofaIdlistRepository;

	@Autowired
	private OfaNationalityRepository ofaNationalityRepository;

	@Autowired
	private OfaAddresslistRepository ofaAddresslistRepository;

	@Autowired
	private OfaCitizenshipRepository ofaCitizenshipRepository;

	@Autowired
	private OfaVesselinfoRepository ofaVesselinfoRepository;

	@Autowired
	private OfaDateofbirthRepository ofaDateofbirthRepository;

	@Autowired
	private OfaPlaceofbirthRepository ofaPlaceofbirthRepository;

	private Integer cont=0;
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.lavado.services.SdnListMapper#getOfaSdnentry(gob.bcb.
	 * swiftadmin.ofac.xml.sdn.SdnList.SdnEntry)
	 */
	@Override
	public OfaSdnentry getOfaSdnentry(SdnEntry sdnEntry, Integer nrolote) {
		SdnListDTO sdnListDTO = new SdnListDTO();

		OfaSdnentry ofaSdnentry = sdnListDTO.sdnEntryToOfaSdnentry(sdnEntry);
		ofaSdnentry.setSdnId(ofaSdnentry.getSdnEntryuid());
		ofaSdnentry.setSdnNrolote(nrolote);
		ofaSdnentryRepository.save(ofaSdnentry);

		Set<OfaDateofbirth> listaOfaDateofbirth = sdnListDTO.dateOfBirthListToOfaDateofbirth(sdnEntry);
		log.info("Salvando SdnEntryuid: " + ofaSdnentry.getSdnEntryuid() + " cont: " + ++cont);
		if (listaOfaDateofbirth != null)
			ofaDateofbirthRepository.save(listaOfaDateofbirth);
		ofaSdnentry.setOfaDateofbirth(listaOfaDateofbirth);
		
		Set<OfaAddresslist> listaOfaAddresslist = sdnListDTO.addressListToOfaAddresslist(sdnEntry);
		if (listaOfaAddresslist != null)
			ofaAddresslistRepository.save(listaOfaAddresslist);
		ofaSdnentry.setOfaAddresslist(listaOfaAddresslist);

		Set<OfaNationality> listaOfaNationality = sdnListDTO.nationalityListToOfaNationality(sdnEntry);
		if (listaOfaNationality != null)
			ofaNationalityRepository.save(listaOfaNationality);
		ofaSdnentry.setOfaNationality(listaOfaNationality);

		Set<OfaCitizenship> listaOfaCitizenship = sdnListDTO.citizenshipListToOfaCitizenship(sdnEntry);
		if (listaOfaCitizenship != null)
			ofaCitizenshipRepository.save(listaOfaCitizenship);
		ofaSdnentry.setOfaCitizenship(listaOfaCitizenship);

		Set<OfaPlaceofbirth> listaOfaPlaceofbirth = sdnListDTO.placeOfBirthListToOfaPlaceofbirth(sdnEntry);
		if (listaOfaPlaceofbirth != null)
			ofaPlaceofbirthRepository.save(listaOfaPlaceofbirth);
		ofaSdnentry.setOfaPlaceofbirth(listaOfaPlaceofbirth);

		Set<OfaIdlist> listaOfaIdlist = sdnListDTO.idListToOfaIdlist(sdnEntry);
		if (listaOfaIdlist != null)
			ofaIdlistRepository.save(listaOfaIdlist);
		ofaSdnentry.setOfaIdlist(listaOfaIdlist);

		Set<OfaAkalist> listaOfaAkalist = sdnListDTO.akaListToOfaAkalist(sdnEntry);
		if (listaOfaAkalist != null)
			ofaAkalistRepository.save(listaOfaAkalist);
		ofaSdnentry.setOfaAkalist(listaOfaAkalist);

		OfaVesselinfo ofaVesselinfo = sdnListDTO.vesselInfoToOfaVesselinfo(sdnEntry);
		if (ofaVesselinfo != null)
			ofaVesselinfoRepository.save(ofaVesselinfo);
		ofaSdnentry.setOfaVesselinfo(ofaVesselinfo);

		return ofaSdnentry;
	}
}
