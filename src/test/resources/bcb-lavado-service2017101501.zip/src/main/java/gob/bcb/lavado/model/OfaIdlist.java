package gob.bcb.lavado.model;

import java.io.Serializable;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Norms;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TermVector;


/**
 * The persistent class for the ofa_idlist database table.
 * 
 */
//@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY,isGetterVisibility = JsonAutoDetect.Visibility.ANY,getterVisibility = JsonAutoDetect.Visibility.ANY)
@Entity
@Table(name = "ofa_idlist")
@NamedQuery(name = "OfaIdlist.findAll", query = "SELECT o FROM OfaIdlist o")
public class OfaIdlist implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "idl_uid")
	private Integer idlUid;

	@Field(analyze = Analyze.NO, norms = Norms.NO)
	@Column(name = "idl_entryuid")
	private int idlEntryuid;

	@Field(analyze = Analyze.NO, norms = Norms.NO)
	@Column(name = "idl_expirationdate")
	private String idlExpirationdate;

	@Field(store = Store.YES, analyze = Analyze.NO, norms = Norms.NO)
	@Column(name = "idl_idcountry")
	private String idlIdcountry;

	@Field(store = Store.YES)
	@Column(name = "idl_idnumber")
	private String idlIdnumber;

	//@Field(store = Store.YES, analyze = Analyze.NO, norms = Norms.NO)
	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "idl_idtype")
	private String idlIdtype;

	@Field(analyze = Analyze.NO, norms = Norms.NO)
	@Column(name = "idl_issuedate")
	private String idlIssuedate;

	// @JsonIgnore
	@ContainedIn
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "idl_entryuid", nullable = false, insertable = false, updatable = false, referencedColumnName = "sdn_entryuid")
	private OfaSdnentry ofaSdnentry;

	public OfaIdlist() {
	}

	public Integer getIdlUid() {
		return this.idlUid;
	}

	public void setIdlUid(Integer idlUid) {
		this.idlUid = idlUid;
	}

	public int getIdlEntryuid() {
		return this.idlEntryuid;
	}

	public void setIdlEntryuid(int idlEntryuid) {
		this.idlEntryuid = idlEntryuid;
	}

	public String getIdlExpirationdate() {
		return this.idlExpirationdate;
	}

	public void setIdlExpirationdate(String idlExpirationdate) {
		this.idlExpirationdate = idlExpirationdate;
	}

	public String getIdlIdcountry() {
		return this.idlIdcountry;
	}

	public void setIdlIdcountry(String idlIdcountry) {
		this.idlIdcountry = idlIdcountry;
	}

	public String getIdlIdnumber() {
		return this.idlIdnumber;
	}

	public void setIdlIdnumber(String idlIdnumber) {
		this.idlIdnumber = idlIdnumber;
	}

	public String getIdlIdtype() {
		return this.idlIdtype;
	}

	public void setIdlIdtype(String idlIdtype) {
		this.idlIdtype = idlIdtype;
	}

	public String getIdlIssuedate() {
		return this.idlIssuedate;
	}

	public void setIdlIssuedate(String idlIssuedate) {
		this.idlIssuedate = idlIssuedate;
	}

	public OfaSdnentry getOfaSdnentry() {
		return ofaSdnentry;
	}

	public void setOfaSdnentry(OfaSdnentry ofaSdnentry) {
		this.ofaSdnentry = ofaSdnentry;
	}
}
