package gob.bcb.lavado.ofac;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.Source;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.oxm.Unmarshaller;
import org.springframework.oxm.XmlMappingException;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;

import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry;
import gob.bcb.lavado.services.SdnListMapper;
import gob.bcb.lavado.services.SdnListMapperImpl;

@Component
public class OfacLoader {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SdnListMapper sdnListMapper;

	private ItemReader<OfaSdnentry> createItemReaderXml(Resource inputSDNXML, Integer nrolote) {
		final Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setClassesToBeBound(SdnEntry.class);
		jaxb2Marshaller.setMappedClass(SdnEntry.class);

		StaxEventItemReader staxEventItemReader = new StaxEventItemReader();
		staxEventItemReader.setFragmentRootElementNames("publshInformation,sdnEntry".split(","));
		staxEventItemReader.setFragmentRootElementName("sdnEntry");
		staxEventItemReader.setResource(inputSDNXML);

		staxEventItemReader.setUnmarshaller(new Unmarshaller() {
			@Override
			public Object unmarshal(Source source) throws XmlMappingException, IOException {
				SdnEntry sdnEntry = (SdnEntry) jaxb2Marshaller.unmarshal(source);

				// guardando el registro parseado
				OfaSdnentry ofaSdnentry = sdnListMapper.getOfaSdnentry(sdnEntry, nrolote);
				return ofaSdnentry;
			}

			@Override
			public boolean supports(Class<?> clazz) {
				return true;
			}

		});

		return staxEventItemReader;
	}

	public Integer readFileToOfaSdnentry(String pathFile, Integer nrolote) throws UnexpectedInputException, ParseException, Exception {
		List<OfaSdnentry> ofaSdnentryList = readFileToOfaSdnentryToList(pathFile, nrolote);
		return ofaSdnentryList.size();
	}
	
	public List<OfaSdnentry> readFileToOfaSdnentryToList(String pathFile, Integer nrolote) throws UnexpectedInputException, ParseException, Exception {
		log.info("readFileToOfaSdnentry: Cargando LISTA OFAC[lote: " + nrolote + "]:  " + pathFile);
		long startTime = System.currentTimeMillis();
		FileInputStream fis = new FileInputStream(new File(pathFile));
		Resource inputSDNXML = new InputStreamResource(fis);

		StaxEventItemReader<OfaSdnentry> itemReaderxml = (StaxEventItemReader<OfaSdnentry>) createItemReaderXml(inputSDNXML, nrolote);
		log.info("Antes de ExecutionContext...");
		itemReaderxml.open(new ExecutionContext());
		List<OfaSdnentry> ofaSdnentryList = new ArrayList<OfaSdnentry>();
		OfaSdnentry ssxml0 = null;
		while ((ssxml0 = itemReaderxml.read()) != null) {
			ofaSdnentryList.add(ssxml0);
		}

		log.info("Done load List with [" + ofaSdnentryList.size() + "] regs. at (" + (System.currentTimeMillis() - startTime) + " ms.)");
		return ofaSdnentryList;
	}	
}
