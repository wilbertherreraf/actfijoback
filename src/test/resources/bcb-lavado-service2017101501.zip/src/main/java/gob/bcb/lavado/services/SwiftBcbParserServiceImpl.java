package gob.bcb.lavado.services;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;

import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfBicsDao;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.swift.ParserSwiftMessage;
import gob.bcb.swift.SwiftMessageBcb;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

/**
 * Componente de desparseo de mensajes swift
 * 
 * @author wherrera
 *
 */

@Component("swiftBcbParserService")
public class SwiftBcbParserServiceImpl implements SwiftBcbParserService {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	public static final List<String> fieldsWithBics = Stream.of("57", "52", "56").collect(Collectors.toList());// new
																												// ArrayList<>();
																												// //
																												// Stream.of("57",
																												// "52",
																												// "56").collect(toList());
	public static final String SWIFT_EOL = "\r\n";	
	public static final String[] exceptFields = {};
	@Autowired
	private SwfBicsDao swfBicsDao;
	@Autowired
	private CryptoSwiftService cryptoSwiftService;

	static final Locale locale = new Locale("es");

	public String decryptPlano(String menPlano) {
		menPlano = cryptoSwiftService.decryptPlain(menPlano);
		return ArchivoUtil.decodeFromUri(menPlano);
		
	}
	/**
	 * retorna el mensaje swift BCB desde un archivo en formato plano
	 * 
	 * @param menPlano
	 *            mensaje en formato plano
	 * @return {@link SwiftMessageBcb} estructura desparceada de swift
	 */
	private SwiftMessageBcb swiftMessageBcbFromString(String menPlano) {
		// if (menPlano.contains("#|"))
		// menPlano = menPlano.replace("#|", SWIFT_EOL);
		try {
			if (menPlano == null)
				throw new SwiftAdminException("Mensaje swift RJE nulo");
			menPlano = decryptPlano(menPlano);

			SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb(menPlano);
			swiftMessageBcb.fromString(menPlano);
			return swiftMessageBcb;			
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			throw new SwiftAdminException("Error al parsear mensaje swift NULO " + e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SwiftAdminException("Error al parsear mensaje swift " + e.getMessage(), e);
		}


	}

	public List<Block4> block4FromString(String menPlano) {
		try {
			SwiftMessageBcb swiftMessageBcb = swiftMessageBcbFromString(menPlano);
			return createListBlock4(swiftMessageBcb, true);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	public SwiftDatos swiftDatosFromString(String menPlano) {
		try {
			log.debug("Inicio conversion de plano a objeto SwiftDatos");

			if (log.isDebugEnabled())
				log.debug(menPlano);

			SwiftMessageBcb swiftMessageBcb = swiftMessageBcbFromString(menPlano);

			if (swiftMessageBcb.getSwiftMessage().getDirection() != null && swiftMessageBcb.getSwiftMessage().isOutgoing())
				if (!swiftMessageBcb.isValid()) {
					log.error("Mensaje PLANO invalido: " + UtilsGeneric.getShortText(swiftMessageBcb.getMenPlano(), 288));
					throw new SwiftAdminException("Mensaje Swift con formato invalido");
				}

			SwfMensaje swfMensaje = new SwfMensaje();
			swfMensaje = newSwfMensajeFrom(swiftMessageBcb, swfMensaje);

			SwiftDatos swiftDatos = new SwiftDatos();
			swiftDatos.setSwiftMessageBcb(swiftMessageBcb);
			swiftDatos.setSwfMensaje(swfMensaje);

			return swiftDatos;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.lavado.services.SwiftBcbParserService#swfMensajeFromLote(java
	 * .lang.String)
	 */
	public List<MensajesDatos> swfMensajeFromLote(String planoLote) {
		List<MensajesDatos> mensajesDatosLista = new ArrayList<>();
		if (!ParserSwiftMessage.isFormatSwift(planoLote)) {
			log.error("Formato de archivo invalido");
			throw new RuntimeException("Formato de archivo invalido");
		}

		String[] splitSwift = ParserSwiftMessage.splitSwift(planoLote);
		int conta = 1;
		for (String swiftPlano : splitSwift) {
			MensajesDatos mensajesDatos = new MensajesDatos();
			SwiftDatos swiftDatos = swiftDatosFromString(swiftPlano);
			swiftDatos.getSwfMensaje().setBlock4List(createListBlock4(swiftDatos.getSwiftMessageBcb(), true));

			if (swiftDatos.getSwiftMessageBcb().getBlock2() != null) {
				swiftDatos.getSwfMensaje().setMenCodmen(conta);

				mensajesDatos.setMenCodmen(conta);
				mensajesDatos.setSwfMensaje(swiftDatos.getSwfMensaje());
				mensajesDatos.setBlock4List(swiftDatos.getSwfMensaje().getBlock4List());
				mensajesDatosLista.add(mensajesDatos);
				conta++;
			}
		}
		log.info("Mensajes desparseados de lote " + mensajesDatosLista.size());
		return mensajesDatosLista;
	}

	private SwfMensaje newSwfMensajeFrom(SwiftMessageBcb swiftMessageBcb, SwfMensaje swfMensaje) {
		log.info("Creando SwfMensaje de SwiftMessageBcb");
		swfMensaje.setMenCodmt(swiftMessageBcb.getSwiftMessage().getType());
		swfMensaje.setMenPlano(swiftMessageBcb.getMenPlano());
		swfMensaje.setSwiftfPlano(swiftMessageBcb.getMenPlano());
		swfMensaje.setMenHash(swiftMessageBcb.checkSum());

		if (swiftMessageBcb.getSwiftMessage().isIncoming()) {
			swfMensaje.setMenCodapp((!StringUtils.isBlank(swfMensaje.getMenCodapp()) ? swfMensaje.getMenCodapp() : Constants.COD_APP_NEMO));
			swfMensaje.setMenRefer(!StringUtils.isBlank(swfMensaje.getMenRefer()) ? swfMensaje.getMenRefer() : swfMensaje.getMenHash());

			swfMensaje.setMenEmisor(swiftMessageBcb.getSwiftMessage().getSender());
			swfMensaje.setMenReceiver(swiftMessageBcb.getSwiftMessage().getReceiver());

			if (swiftMessageBcb.getBlock2() != null) {
				SwiftBlock2Output swiftBlock2Output = (SwiftBlock2Output) swiftMessageBcb.getBlock2();
				swfMensaje.setMenCodswift(swiftBlock2Output.getMIR());
				swfMensaje.setMenRefer(swiftBlock2Output.getMIR());
			}

			swfMensaje.setMenInout(Constants.TIPO_MENSAJE_IN);

			BIC bic = new BIC(swfMensaje.getMenEmisor());
			swfMensaje.setMenBic(bic.getBic8());
			swfMensaje.setMenBicbranch(bic.getBranch());
		} else if (swiftMessageBcb.getSwiftMessage().isOutgoing()) {
			swfMensaje.setMenReceiver(swiftMessageBcb.getSwiftMessage().getReceiver());
			swfMensaje.setMenEmisor(swiftMessageBcb.getSwiftMessage().getSender());

			Field20 f20 = (Field20) swiftMessageBcb.getField(Constants.CAMPO_SWIFT_20);
			if (f20 != null) {
				String[] cmp20 = f20.getValue().split("/");
				// swfMensaje.setMenNrocorr((cmp20.length == 3 &&
				// NumberUtils.isNumber(cmp20[0]) ? Integer.valueOf(cmp20[0]) :
				// swfMensaje.getMenNrocorr()));
				if (StringUtils.isBlank(swfMensaje.getMenCodusrswf()))
					swfMensaje.setMenCodusrswf((cmp20.length == 3 ? cmp20[2] : swfMensaje.getMenCodusrswf()));
				swfMensaje.setMenCodswift(f20.getValue());
			} else {
				log.warn("Mensaje swift sin campo 20 " + swfMensaje.getMenHash() + " sera el codigo de operaion");
				swfMensaje.setMenCodswift(swfMensaje.getMenRefer());
			}

			swfMensaje.setMenInout(Constants.TIPO_MENSAJE_OUT);

			BIC bic = new BIC(swfMensaje.getMenReceiver());
			swfMensaje.setMenBic(bic.getBic8());
			swfMensaje.setMenBicbranch(bic.getBranch());
		}

		return swfMensaje;
	}

	private Block4 getBlock4FromField(Field field, String mt, boolean requireDescrip) {

		if (field.isEmpty()) {
			return null;
		}
		Block4 block4 = new Block4();
		block4.setName(field.getName());
		String valorCampo = field.getValue();
		block4.setValue(valorCampo);

		if (!requireDescrip)
			return block4;

		String label = StringEscapeUtils.unescapeHtml(field.getLabel(field.getName(), mt, null, locale));
		log.debug(" => label " + field.getName() + "[" + mt + "] : " + label + " : " + field.getValue());
		List<String> result = new ArrayList<String>();

		StringBuilder valueDescrip = new StringBuilder();
		for (int i = 1; i <= field.componentsSize(); i++) {
			String labelComp = field.getComponentLabel(i);
			if (StringUtils.isBlank(labelComp)) {
				labelComp = field.getName(); 
			}
			String component = field.getComponent(i);
			String valueDisplay = field.getValueDisplay(i, locale);
			if (!StringUtils.isBlank(component)) {
				if (labelComp.equals("BIC")) {
					BIC bic = new BIC(component);
					String branch = bic.getBranch();
					if (StringUtils.isBlank(bic.getBranch())) {
						branch = "XXX";
					}
					//log.debug("BIC " + field.getComponent(i) + " valid? " + bic.isValid());
					if (bic.isValid()) {
						SwfBics swfBics = swfBicsDao.findByBicBranch(bic.getBic8(), branch);
						if (swfBics != null) {
							component = component + SWIFT_EOL + StringUtils.trimToEmpty(swfBics.getBicDescrip());
							component = component + SWIFT_EOL + StringUtils.trimToEmpty(swfBics.getBicPais()) + ", " + StringUtils.trimToEmpty(swfBics.getBicCiudad());
						}
						valueDisplay = component; 
					}
				}
				result.add(labelComp);
				
				valueDescrip.append(labelComp + " : " + valueDisplay);
				if (i < field.componentsSize() && !StringUtils.isBlank(field.getComponent(i + 1)))
					valueDescrip.append(SWIFT_EOL);
			}
		}

		block4.setReference(label);
		block4.setValueDescrip(valueDescrip.toString());
		return block4;
	}

	public List<Block4> createListBlock4(SwiftMessageBcb swiftMessageBcb, boolean requireDescrip) {
		List<Block4> block4Lista = new ArrayList<>();
		final SwiftBlock4 b4 = swiftMessageBcb.getSwiftMessage().getBlock4();

		if (b4 != null && !b4.isEmpty()) {
			for (Tag t : b4.getTags()) {
				final Field field = t.getField();
				Block4 block = getBlock4FromField(field, swiftMessageBcb.getSwiftMessage().getType(), requireDescrip);
				if (block == null)
					continue;
				block4Lista.add(block);
			}
		}
		return block4Lista;
	}

	public SwiftDatos actualizarSwfMensajeFromPlano(SwfMensaje swfMensaje, String menplano) {
		// el objeto es mantener el principio que el mensaje debe ser
		// actualizado a partir de las fuentes
		log.info("actualizar SwfMensaje FromPlano:: " + swfMensaje.getMenCodmen());

		try {
			SwiftMessageBcb swiftMessageBcb = swiftMessageBcbFromString(menplano);

			swfMensaje = newSwfMensajeFrom(swiftMessageBcb, swfMensaje);

			SwiftDatos swiftDatos = new SwiftDatos();
			swiftDatos.setSwiftMessageBcb(swiftMessageBcb);
			swiftDatos.setSwfMensaje(swfMensaje);

			return swiftDatos;
		} catch (Exception e) {
			log.error("Error al actualizar mensaje swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar mensaje swift " + e.getMessage(), e);
		}
	}

	public static String decodeMensaje(String menPlano) {
		boolean isEncoded = true;
		try {
			new URI(menPlano);
		} catch (URISyntaxException e) {
			isEncoded = false;
		}

		if (isEncoded) {
			try {
				menPlano = URLDecoder.decode(menPlano, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				throw new SwiftAdminException("Error en URLDecoder.decode " + e.getMessage(), e);
			}
		}
		return menPlano;
	}

	public static void main(String[] args) {
		String c20 = "1235/0101207/XYZAS";
		String[] s = c20.split("/");
		if (s.length == 3) {

		}
	}
}
