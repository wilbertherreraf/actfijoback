package gob.bcb.lavado.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfAsignamensajePK;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.model.SwfTipomensaje;
import gob.bcb.lavado.pojos.Asignacion;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.MensajesDatos;

@Repository("swfAsignamensajeDao")
@Transactional
public class SwfAsignamensajeDaoImpl implements SwfAsignamensajeDao {
	private static final Logger log = LoggerFactory.getLogger(SwfAsignamensajeDaoImpl.class);

	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private SwfPersonaDao swfPersonaDao;

	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;

	@Autowired
	@Qualifier("entityManagerFactory")
	private EntityManagerFactory entityManagerFactory;

	public List<SwfAsignamensaje> findAsignacionesPorCodmen(Integer resCodmen) {
		String jpql = "SELECT t FROM SwfAsignamensaje t ";
		jpql = jpql.concat("WHERE t.id.resCodmen = :resCodmen ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodmen", resCodmen);

		List lista = query.getResultList();
		return lista;
	}

	public List<String> areasPorEmpEstado(Integer resCodemp, Integer estRevision) {
		// areas con las que trabaja el empleado
		String jpql = "SELECT distinct t.resArecod ";
		jpql = jpql.concat("FROM SwfAsignamensaje t ");
		jpql = jpql.concat("WHERE t.id.resCodemp != t.resCodemppadre ");
		if (estRevision != null) {
			jpql = jpql.concat("and t.resEstrevision = :estRevision ");
		}
		jpql = jpql.concat("and t.resCodemppadre = :resCodemp ");

		Query query = entityManager.createQuery(jpql);

		if (estRevision != null) {
			query.setParameter("estRevision", estRevision);
		}
		query.setParameter("resCodemp", resCodemp);

		List lista = query.getResultList();
		return lista;
	}

	public List<SwfAsignamensaje> byCodigoEmpleado(Integer resCodemp) {
		String jpql = "SELECT t FROM SwfAsignamensaje t ";
		jpql = jpql.concat("WHERE t.id.resCodemp = :resCodemp ");
		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodemp", resCodemp);
		List lista = query.getResultList();
		return lista;
	}

	public SwfAsignamensaje byCodigo(Integer resCodmen, Integer resCodemp) {
		String jpql = "SELECT t FROM SwfAsignamensaje t ";
		jpql = jpql.concat("WHERE t.id.resCodmen = :resCodmen ");
		jpql = jpql.concat("and t.id.resCodemp = :resCodemp ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodmen", resCodmen);
		query.setParameter("resCodemp", resCodemp);
		List lista = query.getResultList();

		if (lista.size() > 0) {
			return (SwfAsignamensaje) lista.get(0);
		}
		return null;
	}
	
	public SwfAsignamensaje findPadre(Integer resCodmen) {
		String jpql = "SELECT t FROM SwfAsignamensaje t ";
		jpql = jpql.concat("WHERE t.id.resCodmen = :resCodmen ");
		jpql = jpql.concat("and t.id.resCodemp = t.resCodemppadre ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodmen", resCodmen);
		List lista = query.getResultList();

		if (lista.size() > 0) {
			return (SwfAsignamensaje) lista.get(0);
		}
		return null;
	}

	public List<SwfAsignamensaje> buscarAsignaciones(Integer codmen, Integer resCodemp, Integer resCodempasig, Integer estRevision, Date conFecinicio, Date conFecfin) {
		// areas con las que trabaja el empleado
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfAsignamensaje t ");

		if (estRevision == null) {
			jpql = jpql.concat("WHERE t.resEstrevision != 9 ");
		} else {
			jpql = jpql.concat("WHERE t.resEstrevision = :estRevision ");
		}

		if (codmen != null)
			jpql = jpql.concat("and t.id.resCodmen = :resCodmen ");

		if (resCodemp != null)
			jpql = jpql.concat("and t.id.resCodemp = :resCodemp ");

		if (conFecinicio != null && conFecfin != null) {
			jpql = jpql.concat("and date(t.resFechoraasigna) between :conFecinicio and :conFecfin ");
		}

		if (resCodempasig != null) {
			// filtrar por empleado asignado por
			jpql = jpql.concat("and exists (select 1 ");
			jpql = jpql.concat("from SwfAsignamensaje t1 ");
			jpql = jpql.concat("where t1.id.resCodmen = t.id.resCodmen ");
			jpql = jpql.concat("and t1.id.resCodemp = :resCodempasig) ");
		}

		Query query = entityManager.createQuery(jpql);

		if (estRevision != null) {
			query.setParameter("estRevision", estRevision);
		}

		if (codmen != null)
			query.setParameter("resCodmen", codmen);

		if (resCodemp != null)
			query.setParameter("resCodemp", resCodemp);

		if (conFecinicio != null && conFecfin != null) {
			query.setParameter("conFecinicio", conFecinicio, TemporalType.DATE);
			query.setParameter("conFecfin", conFecfin, TemporalType.DATE);
		}

		if (resCodempasig != null) {
			query.setParameter("resCodempasig", resCodempasig);
		}

		List lista = query.getResultList();
		return lista;
	}

	@Transactional(readOnly = true)
	public List<MensajesDatos> buscarMensajesAsignados(Integer codmen, Integer resCodemp, Integer resCodempasig, Integer resCodempUsuario, Integer estRevision, Integer estMensaje,
			Date conFecinicio, Date conFecfin) {
		List<MensajesDatos> mensajesDatosLista = new ArrayList<MensajesDatos>();
		Map<Integer, SwfMensaje> mapCtrlSwfMensaje = new HashMap<Integer, SwfMensaje>();
		List<SwfAsignamensaje> swfAsignamensajeLista = buscarAsignaciones(codmen, resCodemp, resCodempasig, estRevision, conFecinicio, conFecfin);

		int countRegs = 0;
		for (SwfAsignamensaje swfAsignamensaje : swfAsignamensajeLista) {
			MensajesDatos mensajesDatos = null;

			SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(swfAsignamensaje.getId().getResCodmen());
			if (!mapCtrlSwfMensaje.containsKey(swfMensaje.getMenCodmen())) {
				mapCtrlSwfMensaje.put(swfMensaje.getMenCodmen(), swfMensaje);
				mensajesDatos = swfMensajeDao.mensajeDatosFromSwfMensaje(swfMensaje, null, null, null, null, false);

				if (resCodemp != null) {
					Asignacion asignacion = recuperarAsignacion(swfAsignamensaje);
					mensajesDatos.setAsignacion(asignacion);

					List<Asignacion> asignacionLista = recuperarAsignacionesMensaje(swfAsignamensaje.getId().getResCodmen(), swfAsignamensaje.getId().getResCodemp(), null);
					mensajesDatos.setAsignacionLista(asignacionLista);

					List<SwfAsignamensaje> swfAsignamensajeDeATerceros = swfMensajeDao.asignacionesDeATerceros(swfAsignamensaje.getId().getResCodmen(),
							swfAsignamensaje.getId().getResCodemp(), null);
					mensajesDatos.setSwfAsignamensajeDeATerceros(swfAsignamensajeDeATerceros);
				} else {
					// la asignacion es del padre origen
					SwfAsignamensaje swfAsignamensajeOld = findPadre(swfAsignamensaje.getId().getResCodmen());
					if (swfAsignamensajeOld == null)
						swfAsignamensajeOld = swfAsignamensaje;

					Asignacion asignacion = recuperarAsignacion(swfAsignamensajeOld);
					mensajesDatos.setAsignacion(asignacion);

					List<Asignacion> asignacionLista = recuperarAsignacionesMensaje(swfAsignamensajeOld.getId().getResCodmen(), swfAsignamensajeOld.getId().getResCodemp(), null);
					mensajesDatos.setAsignacionLista(asignacionLista);
					
					// la asignacion es la seleccionada
					List<SwfAsignamensaje> swfAsignamensajeDeATerceros = swfMensajeDao.asignacionesDeATerceros(swfAsignamensajeOld.getId().getResCodmen(),
							swfAsignamensajeOld.getId().getResCodemp(), null);
					mensajesDatos.setSwfAsignamensajeDeATerceros(swfAsignamensajeDeATerceros);					
				}
				
				mensajesDatosLista.add(mensajesDatos);				
			} else {
				continue;
			}

			if (++countRegs >= Constants.SEARCH_LIMIT_REGS)
				break;
		}

		return mensajesDatosLista;
	}

	private List<Asignacion> recuperarAsignacionesMensaje(Integer menCodmen, Integer codempleado, Integer estRevision) {
		log.debug("obtener lista de Asignaciones recuperarAsignacionesMensaje menCodmen " + menCodmen + " estRevision: " + estRevision + " codempleado " + codempleado);

		List<Asignacion> asignacionLista = new ArrayList<Asignacion>();

		List<SwfAsignamensaje> swfAsignamensajeLista = swfMensajeDao.asignacionesByEmpMasHijos(menCodmen, codempleado, estRevision);

		for (SwfAsignamensaje swfAsignamensaje : swfAsignamensajeLista) {
			// solo se filtra las asignaciones diferentes al usaurio
			// actual
			Asignacion asignacion = recuperarAsignacion(swfAsignamensaje);
			asignacionLista.add(asignacion);
		}

		return asignacionLista;
	}

	private Asignacion recuperarAsignacion(SwfAsignamensaje swfAsignamensaje) {
		Asignacion asignacion = new Asignacion();
		asignacion.setSwfAsignamensaje(swfAsignamensaje);

		SwfPersona swfPersona = swfPersonaDao.findByCodigo(swfAsignamensaje.getId().getResCodemp());
		SwfPersona swfPersonaPadre = swfPersonaDao.findByCodigo(swfAsignamensaje.getResCodemppadre());

		asignacion.setSwfPersona(swfPersona);
		asignacion.setSwfPersonaPadre(swfPersonaPadre);
		return asignacion;
	}

	public SwfAsignamensaje saveOrUpdate(Integer codMensaje, Integer nroEmpleado, Integer resCodemppadre, SwfAsignamensaje swfAsignamensaje, Integer estRevision) {
		SwfAsignamensaje swfAsignamensajeOld = byCodigo(codMensaje, nroEmpleado);
		if (swfAsignamensajeOld == null) {
			// ESTADO PENDIENTE
			Integer perCodigo = getCodigo(codMensaje);
			SwfAsignamensajePK swfAsignamensajePK = new SwfAsignamensajePK();
			swfAsignamensajePK.setResCodmen(codMensaje);
			swfAsignamensajePK.setResCodemp(nroEmpleado);

			swfAsignamensaje.setId(swfAsignamensajePK);

			swfAsignamensaje.setResCorrasigna(perCodigo);
			swfAsignamensaje.setResFechoraasigna(new Date());
			swfAsignamensaje.setResCodemppadre(resCodemppadre);
			swfAsignamensaje.setResNotif("N");
			swfAsignamensaje.setResAuditfho(new Date());
			swfAsignamensaje.setResEstrevision(estRevision);
			swfAsignamensaje.setResTabestrevision(Constants.TAB_ESTREVISION);

			entityManager.persist(swfAsignamensaje);
			log.info("nueva asignacion " + swfAsignamensaje.getId().getResCodemp() + " " + swfAsignamensaje.getId().getResCodmen());
		} else {
			entityManager.merge(swfAsignamensaje);
		}
		swfAsignamensaje = byCodigo(codMensaje, nroEmpleado);
		return swfAsignamensaje;
	}

	public SwfAsignamensaje updateReg(SwfAsignamensaje swfAsignamensaje) {
		log.info("En  updateReg SwfAsignamensaje " + swfAsignamensaje.toString());

		SwfAsignamensaje swfAsignamensajeOld = byCodigo(swfAsignamensaje.getId().getResCodmen(), swfAsignamensaje.getId().getResCodemp());
		if (swfAsignamensajeOld == null) {
			throw new SwiftAdminException("Asignación " + swfAsignamensaje.getId().getResCodmen() + " emp: " + swfAsignamensaje.getId().getResCodemp() + " inexistente");
		} else {
			entityManager.merge(swfAsignamensaje);
		}
		swfAsignamensaje = byCodigo(swfAsignamensaje.getId().getResCodmen(), swfAsignamensaje.getId().getResCodemp());
		log.info("SwfAsignamensaje actualizado " + swfAsignamensaje.toString());
		return swfAsignamensaje;
	}

	public SwfAsignamensaje crearAsignacion(SwfMensaje swfMensaje, Integer resCodemp, Integer resCodemppadre, String resArecod, Integer estRevision, String login,
			String estacion) {
		SwfAsignamensaje swfAsignamensajeOld = byCodigo(swfMensaje.getMenCodmen(), resCodemp);
		if (swfAsignamensajeOld != null) {
			throw new SwiftAdminException("Asignacion existente para empleado: " + resCodemp + " seleccione otro");
		}

		log.info("En crearAsignacion " + swfMensaje.getMenCodmen() + " a=> " + resCodemp + " por: " + resCodemppadre);
		// NUEVA ASIGNACION
		// antes de grabar en asignacion se crea el empleado en persona
		// si no existe

		SwfPersona swfPersona = swfPersonaDao.findOrCreateSwfPersonaFromRRHH(resCodemp, null, login, estacion);

		SwfAsignamensaje swfAsignamensaje = new SwfAsignamensaje();
		swfAsignamensaje.setResArecod(swfPersona.getPerArecod());
		swfAsignamensaje.setResNotif("N");
		swfAsignamensaje.setResAuditusr(login);
		swfAsignamensaje.setResAuditwst(estacion);

		// registramos la asignación en estado de reasignacion
		swfAsignamensaje = saveOrUpdate(swfMensaje.getMenCodmen(), resCodemp, resCodemppadre, swfAsignamensaje, estRevision);
		return swfAsignamensaje;

	}

	/**
	 * cambia el estado de las asignaciones a ESTREVISION_PROCESADO realizadas
	 * por resCodemppadre en un mensaje
	 */
	public List<Asignacion> asignar(Integer menCodmen, Integer resCodemppadre, String codusuario, String estacion) {
		SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(menCodmen);

		if (swfMensaje == null) {
			throw new SwiftAdminException("Error mensaje inexistente: " + menCodmen);
		}
		log.info("Inicio Asignar entrante " + swfMensaje.getMenCodmen() + " por: " + resCodemppadre);

		List<Asignacion> asignacionLista = new ArrayList<Asignacion>();
		// seleccionamos las asignaciones en estado de reasignacion diferentes
		// al usuario que esta asignando
		// solo se cambia estados de los diferentes al usuario que esta
		// asignando
		List<SwfAsignamensaje> swfAsignamensajeLista = swfMensajeDao.asignacionesByCodEmpEstRev(swfMensaje.getMenCodmen(), resCodemppadre,
				Constants.TAB_ESTREVISION_ENPROC_ASIGNACION);
		if (swfAsignamensajeLista.size() == 0) {
			return asignacionLista;
		}

		for (SwfAsignamensaje swfAsignamensaje : swfAsignamensajeLista) {
			log.info("::Asignando:: " + swfMensaje.getMenCodmen() + " a=> " + swfAsignamensaje.getId().getResCodemp() + " por: " + resCodemppadre);
			SwfPersona swfPersona = swfPersonaDao.findByCodigo(swfAsignamensaje.getId().getResCodemp());

			if (!StringUtils.isBlank(swfPersona.getPerEmail())) {
				boolean validEmail = UtilsGeneric.validarEmail2(swfPersona.getPerEmail());
				if (!validEmail) {
					throw new SwiftAdminException("Correo registrado[" + swfPersona.getPerEmail() + "] Mensaje [" + swfAsignamensaje.getId().getResCodmen() + "] empleado ["
							+ swfPersona.getPerCodemp() + "] inválido!!!");
				}
			}
			SwfPersona swfPersonaPadre = swfPersonaDao.findByCodigo(resCodemppadre);
			// cambio a estado pendiente al destinatario
			swfAsignamensaje.setResAuditusr(codusuario);
			swfAsignamensaje.setResAuditwst(estacion);
			swfAsignamensaje.setResAuditfho(new Date());
			swfAsignamensaje.setResEstrevision(Constants.TAB_ESTREVISION_PEND);
			swfAsignamensaje.setResTabestrevision(Constants.TAB_ESTREVISION);
			swfAsignamensaje.setResFechoraasigna(new Date());

			swfAsignamensaje = entityManager.merge(swfAsignamensaje);

			log.info("Asignado " + swfMensaje.getMenCodmen() + " a=> " + swfAsignamensaje.getId().getResCodemp() + " por: " + resCodemppadre);

			Asignacion asignacion = new Asignacion();
			asignacion.setSwfAsignamensaje(swfAsignamensaje);
			asignacion.setSwfPersona(swfPersona);
			asignacion.setSwfPersonaPadre(swfPersonaPadre);

			asignacionLista.add(asignacion);
		}

		// al momento de la asignacion marcamos el mensje padre, es decir el
		// asignado por el padre, como
		// procesado
		// cambiamos el estado de la asigancion padre a procesado
		procesar(swfMensaje.getMenCodmen(), resCodemppadre, codusuario, estacion);
		return asignacionLista;
	}

	/**
	 * cambia el estado de la revision de la asignacion mensaje a procesado
	 */
	public void procesar(Integer codmen, Integer codemp, String codusuario, String estacion) {
		log.info("En  procesar SwfAsignamensaje id= " + codmen + " Codemp: " + codemp);

		SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(codmen);
		swfMensajeDao.verificaEstado(swfMensaje);

		SwfAsignamensaje swfAsignamensajeOld = byCodigo(codmen, codemp);
		if (swfAsignamensajeOld == null)
			throw new SwiftAdminException("Asignacion inexistente mensaje: " + codmen + " cod empleado: " + codemp);

		if (swfAsignamensajeOld.getResEstrevision().compareTo(Constants.TAB_ESTREVISION_PEND) == 0) {
			// solo se procesa si esta en esta reasignado(pendiente)
			if (swfAsignamensajeOld.getId().getResCodemp().compareTo(swfAsignamensajeOld.getResCodemppadre()) == 0) {
				// validacion para la generacion de correlativo
				// si el empleado es el mismo que el padre es la asignacion
				// padre : se cambia estado del mensaje
				swfMensajeDao.cambiarEstadoAsignacion(swfMensaje, Constants.TAB_ESTMENSAJE_ASIGNADO);
			}
			swfAsignamensajeOld.setResEstrevision(Constants.TAB_ESTREVISION_PROCESADO);
			swfAsignamensajeOld.setResTabestrevision(Constants.TAB_ESTREVISION);
			swfAsignamensajeOld.setResFechorarevisa(new Date());
			swfAsignamensajeOld.setResAuditusr(codusuario);
			swfAsignamensajeOld.setResAuditwst(estacion);
			swfAsignamensajeOld.setResAuditfho(new Date());

			swfAsignamensajeOld = entityManager.merge(swfAsignamensajeOld);

			cambiarAEstDeMensajeEntranteAProcesado(codmen, codemp);
		}
	}

	public SwfAsignamensaje rechazarAsignacion(Integer codmen, Integer codemp, String codusuario, String estacion) {
		log.info("En  rechazar codmen: " + codmen + " codemp: " + codemp);
		List<SwfAsignamensaje> swfAsignamensajeLista = swfMensajeDao.asignacionesDeATerceros(codmen, codemp, Constants.TAB_ESTREVISION_PEND);

		if (swfAsignamensajeLista.size() == 0)
			throw new SwiftAdminException("El Mensajes no fue asignado por un tercero, o no se encuentra pendiente de proceso");

		SwfAsignamensaje swfAsignamensajeOld = swfAsignamensajeLista.get(0);

		// solo se rechaza si esta en esta reasignado(pendiente)

		swfAsignamensajeOld.setResEstrevision(Constants.TAB_ESTREVISION_ENPROC_ASIGNACION);
		if (swfAsignamensajeOld.getResGlosa() == null) {
			swfAsignamensajeOld.setResGlosa("");
		}
		swfAsignamensajeOld.setResGlosa(swfAsignamensajeOld.getResGlosa() + "; RECHAZADO por " + codemp);
		swfAsignamensajeOld.setResFechorarevisa(new Date());
		swfAsignamensajeOld.setResAuditfho(new Date());
		swfAsignamensajeOld.setResAuditusr(codusuario);
		swfAsignamensajeOld.setResAuditwst(estacion);

		entityManager.merge(swfAsignamensajeOld);

		swfAsignamensajeOld = byCodigo(codmen, codemp);

		SwfAsignamensaje swfAsignamensajePadre = byCodigo(codmen, swfAsignamensajeOld.getResCodemppadre());

		if (swfAsignamensajePadre != null) {
			// cambiamos el estado de la asigancion padre a pendiente
			swfAsignamensajePadre.setResEstrevision(Constants.TAB_ESTREVISION_PEND);
			swfAsignamensajePadre.setResTabestrevision(Constants.TAB_ESTREVISION);
			swfAsignamensajePadre.setResAuditfho(new Date());
			swfAsignamensajePadre.setResAuditusr(codusuario);
			swfAsignamensajePadre.setResAuditwst(estacion);
			swfAsignamensajeOld = entityManager.merge(swfAsignamensajeOld);
		}

		return swfAsignamensajeOld;
	}

	/**
	 * recupera en mensaje asignado
	 */
	public void habilitar(Integer codmen, Integer codemp, Integer newEstRevision, String codusuario, String estacion) {
		log.info("En  habilitar codmen: " + codmen + " codemp: " + codemp + " nuevo estado newEstRevision: " + newEstRevision);

		SwfAsignamensaje swfAsignamensajeOld = null;

		List<SwfAsignamensaje> swfAsignamensajeLista = swfMensajeDao.asignacionesByEmpMasHijos(codmen, codemp, Constants.TAB_ESTREVISION_ENPROC_ASIGNACION);

		while (swfAsignamensajeLista.size() > 0) {
			swfAsignamensajeOld = byCodigo(codmen, swfAsignamensajeLista.get(0).getId().getResCodemp());
			if (swfAsignamensajeOld != null)
				entityManager.remove(swfAsignamensajeOld);
			swfAsignamensajeLista = swfMensajeDao.asignacionesByEmpMasHijos(codmen, codemp, Constants.TAB_ESTREVISION_ENPROC_ASIGNACION);
		}

		swfAsignamensajeLista = swfMensajeDao.asignacionesByEmpMasHijos(codmen, codemp, Constants.TAB_ESTREVISION_PEND);

		while (swfAsignamensajeLista.size() > 0) {
			swfAsignamensajeOld = byCodigo(codmen, swfAsignamensajeLista.get(0).getId().getResCodemp());
			if (swfAsignamensajeOld != null)
				entityManager.remove(swfAsignamensajeOld);
			swfAsignamensajeLista = swfMensajeDao.asignacionesByEmpMasHijos(codmen, codemp, Constants.TAB_ESTREVISION_PEND);
		}

		swfAsignamensajeOld = byCodigo(codmen, codemp);

		if (swfAsignamensajeOld != null) {
			// solo se habilita si esta en esta estado procesado
			log.info("Mensaje habilitado: " + codmen + " codemp: " + codemp);
			swfAsignamensajeOld.setResEstrevision(Constants.TAB_ESTREVISION_PEND);
			swfAsignamensajeOld.setResTabestrevision(Constants.TAB_ESTREVISION);
			swfAsignamensajeOld.setResFechorarevisa(new Date());
			swfAsignamensajeOld.setResAuditusr(codusuario);
			swfAsignamensajeOld.setResAuditwst(estacion);
			swfAsignamensajeOld.setResAuditfho(new Date());

			entityManager.merge(swfAsignamensajeOld);
		} else {
			throw new SwiftAdminException("Asignacion inexistente mensaje: " + codmen + " cod empleado: " + codemp);
		}
	}

	private void cambiarAEstDeMensajeEntranteAProcesado(Integer menCodmen, Integer codemp) {
		boolean conAsiganciones = true;
		SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(menCodmen);
		List<SwfAsignamensaje> swfAsignamensajeLista = findAsignacionesPorCodmen(menCodmen);
		for (SwfAsignamensaje swfAsignamensaje2 : swfAsignamensajeLista) {
			if (swfAsignamensaje2.getResEstrevision().compareTo(Constants.TAB_ESTREVISION_PROCESADO) != 0) {
				conAsiganciones = false;
				break;
			}
		}

		if (conAsiganciones && swfAsignamensajeLista.size() > 0) {
			log.info("PROCESO TOTAL del mensaje " + menCodmen);
			swfMensajeDao.cambiarEstadoAsignacion(swfMensaje, Constants.TAB_ESTMENSAJE_PROCESADO);
		}
	}

	/**
	 * Elimina una asignacion de codemp asignado por codemppadre
	 */
	public void eliminarAsignacion(Integer codmen, Integer codemp, Integer codemppadre) {
		log.info("En  remove SwfAsignamensaje " + codmen + " codemp: " + codemp + " por " + codemppadre);
		SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(codmen);
		swfMensajeDao.verificaEstado(swfMensaje);

		SwfAsignamensaje swfAsignamensajeOld = byCodigo(codmen, codemp);
		if (swfAsignamensajeOld != null) {
			// estado creado
			if (swfAsignamensajeOld.getResCodemppadre() == null || swfAsignamensajeOld.getResCodemppadre().compareTo(codemppadre) != 0) {
				log.error("Asignacion no le corresponde de empleado[" + codemp + "], no puede continuar");
				throw new SwiftAdminException("Asignacion de mensaje " + codmen + " no le corresponde de empleado[" + codemp + "], no puede continuar");
			}

			if (swfAsignamensajeOld.getResEstrevision().compareTo(Constants.TAB_ESTREVISION_PEND) == 0
					|| swfAsignamensajeOld.getResEstrevision().compareTo(Constants.TAB_ESTREVISION_ENPROC_ASIGNACION) == 0) {
				// solo se elimina si esta en esta reasignado(pendiente) o
				// asignado
				entityManager.remove(swfAsignamensajeOld);
			} else {
				throw new SwiftAdminException("Asignacion con estado diferente a pendiente o en proceso de asignacion no puede continuar");
			}
		} else {
			throw new SwiftAdminException("Asignacion inexistente mensaje: " + codmen + " cod empleado: " + codemp);
		}
	}

	private Integer getCodigo(Integer codMensaje) {
		Integer codigo = null;
		StringBuilder jSql = new StringBuilder();
		jSql.append("select max(m.resCorrasigna) from SwfAsignamensaje m ");
		jSql.append("where m.id.resCodmen = :codMensaje ");

		Query query = entityManager.createQuery(jSql.toString());
		query.setParameter("codMensaje", codMensaje);

		List result = query.getResultList();
		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.debug("Nuevo codigo : " + codigo);
		return codigo;

	}
}
