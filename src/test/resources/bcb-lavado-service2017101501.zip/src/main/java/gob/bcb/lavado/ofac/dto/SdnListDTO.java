package gob.bcb.lavado.ofac.dto;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.lavado.model.OfaAddresslist;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaCitizenship;
import gob.bcb.lavado.model.OfaDateofbirth;
import gob.bcb.lavado.model.OfaIdlist;
import gob.bcb.lavado.model.OfaNationality;
import gob.bcb.lavado.model.OfaPlaceofbirth;
import gob.bcb.lavado.model.OfaPublshinform;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.model.OfaVesselinfo;
import gob.bcb.lavado.ofac.xml.sdn.SdnList;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.PublshInformation;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry.VesselInfo;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry.AddressList.Address;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry.AkaList.Aka;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry.CitizenshipList.Citizenship;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry.DateOfBirthList.DateOfBirthItem;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry.IdList.Id;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry.NationalityList.Nationality;
import gob.bcb.lavado.ofac.xml.sdn.SdnList.SdnEntry.PlaceOfBirthList.PlaceOfBirthItem;

public class SdnListDTO {
	private final Logger log = LoggerFactory.getLogger(this.getClass());	
	public OfaSdnentry sdnEntryToOfaSdnentry(SdnEntry sdnEntry) {
		
		if (sdnEntry == null) {
			return null;
		}

		OfaSdnentry ofaSdnentry = new OfaSdnentry();
		ofaSdnentry.setSdnEntryuid(sdnEntry.getUid());
		ofaSdnentry.setSdnFirstname(sdnEntry.getFirstName());
		ofaSdnentry.setSdnLastname(sdnEntry.getLastName());
		ofaSdnentry.setSdnTitle(sdnEntry.getTitle());
		ofaSdnentry.setSdnSdntype(sdnEntry.getSdnType());
		ofaSdnentry.setSdnRemarks(sdnEntry.getRemarks());

		for (String sdnProgram : sdnEntry.getProgramList().getProgram()) {
			if (ofaSdnentry.getSdnProgramlist() == null)
				ofaSdnentry.setSdnProgramlist(sdnProgram);
			else
				ofaSdnentry.setSdnProgramlist(ofaSdnentry.getSdnProgramlist() + ";" + sdnProgram);
		}

		return ofaSdnentry;

	}

	public Set<OfaIdlist> idListToOfaIdlist(SdnEntry sdnEntry) {
		if (sdnEntry.getIdList() == null) {
			return null;
		}
		Set<OfaIdlist> ofaIdlists = new HashSet<>();

		for (Id id : sdnEntry.getIdList().getId()) {
			OfaIdlist ofaIdlist = new OfaIdlist();

			ofaIdlist.setIdlEntryuid(sdnEntry.getUid());
			ofaIdlist.setIdlUid(id.getUid());
			ofaIdlist.setIdlIdtype(id.getIdType());
			ofaIdlist.setIdlIdnumber(id.getIdNumber());
			ofaIdlist.setIdlIdcountry(id.getIdCountry());
			ofaIdlist.setIdlIssuedate(id.getIssueDate());
			ofaIdlist.setIdlExpirationdate(id.getExpirationDate());

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public Set<OfaAddresslist> addressListToOfaAddresslist(SdnEntry sdnEntry) {
		if (sdnEntry.getAddressList() == null) {
			return null;
		}
		Set<OfaAddresslist> ofaIdlists = new HashSet<>();

		for (Address id : sdnEntry.getAddressList().getAddress()) {
			OfaAddresslist ofaIdlist = new OfaAddresslist();

			ofaIdlist.setAdrEntryuid(sdnEntry.getUid());
			ofaIdlist.setAdrUid(id.getUid());
			ofaIdlist.setAdrAddress1(id.getAddress1());
			ofaIdlist.setAdrAddress2(id.getAddress2());
			ofaIdlist.setAdrAddress3(id.getAddress3());
			ofaIdlist.setAdrCity(id.getCity());
			ofaIdlist.setAdrStateorprovinc(id.getStateOrProvince());
			ofaIdlist.setAdrPostalcode(id.getPostalCode());
			ofaIdlist.setAdrCountry(id.getCountry());

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public Set<OfaNationality> nationalityListToOfaNationality(SdnEntry sdnEntry) {
		if (sdnEntry.getNationalityList() == null) {
			return null;
		}
		Set<OfaNationality> ofaIdlists = new HashSet<>();

		for (Nationality id : sdnEntry.getNationalityList().getNationality()) {
			OfaNationality ofaIdlist = new OfaNationality();

			ofaIdlist.setNatEntryuid(sdnEntry.getUid());
			ofaIdlist.setNatUid(id.getUid());
			ofaIdlist.setNatCountry(id.getCountry());
			ofaIdlist.setNatMainentry(Boolean.toString(id.isMainEntry()));

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public Set<OfaCitizenship> citizenshipListToOfaCitizenship(SdnEntry sdnEntry) {
		if (sdnEntry.getCitizenshipList() == null) {
			return null;
		}
		Set<OfaCitizenship> ofaIdlists = new HashSet<>();

		for (Citizenship id : sdnEntry.getCitizenshipList().getCitizenship()) {
			OfaCitizenship ofaIdlist = new OfaCitizenship();

			ofaIdlist.setCitEntryuid(sdnEntry.getUid());
			ofaIdlist.setCitUid(id.getUid());
			ofaIdlist.setCitCountry(id.getCountry());
			ofaIdlist.setCitMainentry(Boolean.toString(id.isMainEntry()));

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public Set<OfaDateofbirth> dateOfBirthListToOfaDateofbirth(SdnEntry sdnEntry) {
		if (sdnEntry.getDateOfBirthList() == null) {
			return null;
		}
		Set<OfaDateofbirth> ofaIdlists = new HashSet<>();

		for (DateOfBirthItem id : sdnEntry.getDateOfBirthList().getDateOfBirthItem()) {
			OfaDateofbirth ofaIdlist = new OfaDateofbirth();

			ofaIdlist.setBirEntryuid(sdnEntry.getUid());
			ofaIdlist.setBirUid(id.getUid());
			ofaIdlist.setBirDateofbirth(id.getDateOfBirth());
			ofaIdlist.setBirMainentry(Boolean.toString(id.isMainEntry()));

			//log.info("dateeee  " + sdnEntry.getUid() + " - "+id.getUid() + " "  + Boolean.toString(id.isMainEntry()));			
			ofaIdlists.add(ofaIdlist);
		}

		return ofaIdlists;
	}

	public Set<OfaPlaceofbirth> placeOfBirthListToOfaPlaceofbirth(SdnEntry sdnEntry) {
		if (sdnEntry.getPlaceOfBirthList() == null) {
			return null;
		}
		Set<OfaPlaceofbirth> ofaIdlists = new HashSet<>();

		for (PlaceOfBirthItem id : sdnEntry.getPlaceOfBirthList().getPlaceOfBirthItem()) {
			OfaPlaceofbirth ofaIdlist = new OfaPlaceofbirth();

			ofaIdlist.setPobEntryuid(sdnEntry.getUid());
			ofaIdlist.setPobUid(id.getUid());
			ofaIdlist.setPobPlaceofbirth(id.getPlaceOfBirth());
			ofaIdlist.setPobMainentry(Boolean.toString(id.isMainEntry()));

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public Set<OfaAkalist> akaListToOfaAkalist(SdnEntry sdnEntry) {
		if (sdnEntry.getAkaList() == null) {
			return null;
		}
		Set<OfaAkalist> ofaIdlists = new HashSet<>();

		for (Aka id : sdnEntry.getAkaList().getAka()) {
			OfaAkalist ofaIdlist = new OfaAkalist();

			ofaIdlist.setAkaEntryuid(sdnEntry.getUid());
			ofaIdlist.setAkaUid(id.getUid());
			ofaIdlist.setAkaFirstname(id.getFirstName());
			ofaIdlist.setAkaLastname(id.getLastName());
			ofaIdlist.setAkaCategory(id.getCategory());
			ofaIdlist.setAkaType(id.getType());

			ofaIdlists.add(ofaIdlist);
		}
		return ofaIdlists;
	}

	public OfaVesselinfo vesselInfoToOfaVesselinfo(SdnEntry sdnEntry) {
		if (sdnEntry.getVesselInfo() == null) {
			return null;
		}
		VesselInfo id = sdnEntry.getVesselInfo();
		OfaVesselinfo ofaIdlist = new OfaVesselinfo();

		ofaIdlist.setVesEntryuid(sdnEntry.getUid());
		ofaIdlist.setVesCallsign(id.getCallSign());
		ofaIdlist.setVesVesseltype(id.getVesselType());
		ofaIdlist.setVesVesselflag(id.getVesselFlag());
		ofaIdlist.setVesVesselowner(id.getVesselOwner());
		if (id.getTonnage() != null)
			ofaIdlist.setVesTonnage(String.valueOf(id.getTonnage()));
		if (id.getGrossRegisteredTonnage() != null)
			ofaIdlist.setVesGrossregistere(String.valueOf(id.getGrossRegisteredTonnage()));

		return ofaIdlist;
	}
	
	public OfaPublshinform publshInformationToOfaVesselinfo(SdnList sdnEntry) {
		if (sdnEntry.getPublshInformation() == null) {
			return null;
		}
		PublshInformation id = sdnEntry.getPublshInformation();
		OfaPublshinform ofaIdlist = new OfaPublshinform();

		ofaIdlist.setPinPublishdate(id.getPublishDate());
		ofaIdlist.setPinRecordcount(id.getRecordCount());

		return ofaIdlist;
	}	
}
