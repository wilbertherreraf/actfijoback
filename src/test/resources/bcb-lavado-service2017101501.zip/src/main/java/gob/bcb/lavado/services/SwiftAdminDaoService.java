package gob.bcb.lavado.services;

import java.util.List;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.lavado.model.OfaBlacklist;
import gob.bcb.lavado.model.OfaBlanklist;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.pojos.GenUsuario;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.pojos.Participante;

public interface SwiftAdminDaoService {

	OfaBlacklist actualizarOfaBlacklist(OfaBlacklist ofaBlacklist, String estacion);

	void eliminarOfaBlacklist(OfaBlacklist ofaBlacklist);

	SwfBics actualizarSwfBics(SwfBics swfBics);

	SwfLote guardarLoteOfac(String codEmpleado, ArchivoSinple archivoSinple, String estacion);

	void indexOfaSdnentry() throws Exception;

	List<MensajesDatos> findObservados(Integer estVerifica);

	void indexLvdEntities() throws Exception;

	OfaBlanklist actualizarOfaBlanklist(OfaBlanklist ofaBlanklist);

	void eliminarOfaBlanklist(OfaBlanklist ofaBlanklist);

	OfaBlanklist autorizarOfaBlanklist(OfaBlanklist ofaBlanklist);

	OfaBlanklist cambiarAPendienteOfaBlanklist(OfaBlanklist ofaBlanklist);

	SwfParams actualizarSwfParams(SwfParams swfParams);

	SwfMensaje habilitarMensaje(Integer codMen, String codUsuario, String estacion);

	SwfMensaje bloquearMensaje(Integer codMen, String codUsuario, String estacion);

	SwfMensaje solicitarCorrelativo(String codapp, String codoperacion, String coduser, String estacion, String idsession);

	void grabarEnDirectorioSwift(List<SwfMensaje> swfMensajeLista, String codUser, String estacion);

	void grabarEnDirectorioSwift(String codUser, String estacion);

	SwfMensaje rechazarMensaje(Integer codMen, String codUsuario, String estacion);

	void startScheduling(String horajob, String idsched, String cronExpr);

	void truncarListaOfac(String codEmpleado, String estacion) throws Throwable;

	void loadListsFromDirectory(String codEmpleado, String estacion) throws Throwable;


}