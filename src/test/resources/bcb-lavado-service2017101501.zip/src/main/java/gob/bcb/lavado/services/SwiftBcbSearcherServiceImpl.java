package gob.bcb.lavado.services;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.OfaAkalist;
import gob.bcb.lavado.model.OfaSdnentry;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.lavado.rest.dto.SearchResponse;
import gob.bcb.lavado.rest.dto.SearchResponse.ItemsInfo;
import gob.bcb.lavado.search.DocumentBatch;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.search.OfacQuery;
import gob.bcb.lavado.search.dto.SearchResultOfac;
import gob.bcb.lavado.search.indexer.JPASearchFactoryControllerImpl;
import gob.bcb.lavado.search.indexer.JPASearchFactoryHolder;
import gob.bcb.lavado.search.queryparsers.QueryParsersBuilder;
import gob.bcb.lavado.strategy.StrategyBase;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

@Service(value = "swiftBcbSearcherService")
public class SwiftBcbSearcherServiceImpl<T> implements SwiftBcbSearcherService {
	private static final Logger log = LoggerFactory.getLogger(SwiftBcbSearcherServiceImpl.class);
	public static final int MAX_CHARS_LOG = 88;
	@Autowired
	private SwiftBcbParserService swiftBcbParserService;
	@Autowired
	private JPASearchFactoryHolder jPASearchFactoryHolder;	
	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private SwfParamsDao swfParamsDao;
	// @Autowired
	// private LavadoProperties lavadoProperties;
	@Autowired
	private AppProperties appProperties;
	@Autowired
	private MailService mailService;
	@Autowired
	private SessionsSearcherService sessionsSearcherService;
	//@Autowired
	//private OfacScanServiceImpl ofacScanServiceImpl;
	private String pathDirectoryQueries;
	private StrategyBase strategyBase;
	private EmailDetalle emailDetalle = new EmailDetalle();
	private String accionScan = Constants.PARAM_ACCIONSCAN_BLQ;
	private final static long LIMITDELAY = 50;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.lavado.services.SwiftBcbSearcherService#verificarMensajePlano
	 * (java.lang.String)
	 */
	@PostConstruct
	public void init() {
		pathDirectoryQueries = new File(appProperties.getLavado().getAppdir(), Constants.DIR_QUERIES).getAbsolutePath();
		log.info("PostConstruct " + this.getClass().getSimpleName() + " DIR_QUERIES_DIRECTORY " + pathDirectoryQueries);
	}

	public SearchResponse beginSession(String codapp, String coduser, String estacion) {
		SearchResponse searchResponse = new SearchResponse();
		try {
			searchResponse.setCodResp(Constants.COD_RESP_EXITO);
			searchResponse.setCountRegs(0);
			searchResponse.setItemsInfo(new SearchResponse.ItemsInfo[0]);
			searchResponse.setCodoperacion(UUID.randomUUID().toString());
			searchResponse.setDescripResp("Operacion realizada exitosamente idsession: " + searchResponse.getCodoperacion());
			
			sessionsSearcherService.createSession(searchResponse.getCodoperacion(), codapp);
			
			log.info("INICIO SESSION codapp {} coduser {} estacion {} session {}", codapp, coduser, estacion,searchResponse.getCodoperacion());
			log.info("Respuesta: " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());			
			return searchResponse;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		}
	}

	public SearchResponse solicitarCorrelativo(String codapp, String codoperacion, String coduser, String idsession, String estacion) {
		log.info("Solicitar correlativo codapp {} codoperacion {} user {} idsession {}", codapp, codoperacion, coduser, idsession);
		SearchResponse searchResponse = new SearchResponse();
		try {
			sessionsSearcherService.validateSession(idsession, codapp);	
			
			SwfMensaje swfMensaje = swfMensajeDao.solicitarCorrelativo(codapp, coduser, codoperacion, estacion, idsession);

			searchResponse.setCodResp(Constants.COD_RESP_EXITO);
			searchResponse.setCountRegs(0);
			searchResponse.setItemsInfo(new SearchResponse.ItemsInfo[0]);
			searchResponse.setCodoperacion(String.valueOf(swfMensaje.getMenCodmen()));
			searchResponse.setNrocorr(swfMensaje.getMenNrocorr());
			searchResponse.setDescripResp("Operacion realizada exitosamente idMensaje: {" + searchResponse.getCodoperacion() + "} correlativo generado {"
					+ swfMensaje.getMenNrocorr() + "}");
			sessionsSearcherService.revalidateSession(idsession, codapp);
			
			log.info("Respuesta: " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());			
			return searchResponse;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		}
	}

	public SearchResponse scanMensajePlanoConCorrSolicitado(String menPlano, String codapp, Integer menCodmen, Integer nroCorrelativo, String codoperacion,
			String coduser, String estacion, String idsession) {
		log.info("scanMensajePlanoConCorrSolicitado codapp {}, menCodmen {}, nroCorrelativo {}, codoperacion {}, coduser {}, estacion {}, idsession {}", codapp, menCodmen, nroCorrelativo, codoperacion,
				coduser, estacion, idsession);
		JPASearchFactoryControllerImpl jPASearchFactoryController = null;		
		try {
			sessionsSearcherService.validateSession(idsession, codapp);			
			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
			jPASearchFactoryController.init();
			OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);
			SwfMensaje swfMensaje = swfMensajeDao.actualizarConPlano(menPlano, codapp, menCodmen, nroCorrelativo, codoperacion, coduser, estacion, idsession);
			SearchResponse searchResponse = verificarSalienteAndSendMail(swfMensaje, ofacScanServiceImpl);
			
			sessionsSearcherService.revalidateSession(idsession, codapp);
			
			log.info("Respuesta: " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());			
			return searchResponse;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error("Error: "+ e.getMessage(), e);
			return getSearchResultFromException(e);
		} finally {
			if (jPASearchFactoryController != null)
				jPASearchFactoryController.close();
		}
	}

	public SearchResponse preAutorizaSwift(Integer codlvd, String codapp, String coduser, String codoperacion, String idSession, String menPlano,
			String estacion) {
		log.info("=======preAutorizaSwift==========");
		SearchResponse searchResponse = new SearchResponse();
		try {
			sessionsSearcherService.validateSession(idSession, codapp);
			
			SwfMensaje swfMensaje = swfMensajeDao.preAutorizaSwift(codlvd, codapp, coduser, codoperacion, idSession, menPlano, estacion);

			searchResponse.setCodResp(Constants.COD_RESP_EXITO);
			searchResponse.setCodoperacion(String.valueOf(swfMensaje.getMenCodmen()));
			searchResponse.setIdresponse(swfMensaje.getMenHash());
			searchResponse.setNrocorr(swfMensaje.getMenNrocorr());
			searchResponse.setCountRegs(0);
			List<SearchResponse.ItemsInfo> itemsInfoList = new LinkedList<>();
			searchResponse.setItemsInfo(itemsInfoList.toArray(new SearchResponse.ItemsInfo[0]));
			searchResponse.setDescripResp("Operacion realizada exitosamente " + swfMensaje.getMenCodmen());
			
			sessionsSearcherService.revalidateSession(idSession, codapp);
			
			log.info("Respuesta: " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());			
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		}
		return searchResponse;
	}

	public SearchResponse endSession(String codapp, String idsession, String coduser, String estacion) {
		log.info("FIN SESSION codapp {} idsession {} coduser {} estacion {}", codapp, idsession, coduser, estacion);
		SearchResponse searchResponse = new SearchResponse();
		try {
			sessionsSearcherService.validateSession(idsession, codapp);
			sessionsSearcherService.closeSession(idsession);
			
			Integer nroRecs = swfMensajeDao.cerrarTransaccion(idsession);
			searchResponse.setCodResp(Constants.COD_RESP_EXITO);
			searchResponse.setCountRegs(nroRecs);
			searchResponse.setItemsInfo(new SearchResponse.ItemsInfo[0]);
			searchResponse.setCodoperacion(idsession);
			searchResponse.setDescripResp("Operacion realizada exitosamente con registros actualizados: " + nroRecs);
			
			log.info("Respuesta: " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());			
			return searchResponse;
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			return getSearchResultFromException(e);
		}
	}
	
	private SearchResponse verificarSalienteAndSendMail(SwfMensaje swfMensaje, OfacScanServiceImpl ofacScanServiceImpl) {
		inicializaValoresScan();
		SearchResponse searchResponse = new SearchResponse();
		try {
			// verificamos si el mensaje esta en verificacion (pendiente) o fue
			// marcado como positivo(bloqueado)
			if ((swfMensaje.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0)) {
				// se scanea
				DocumentBatch<SearchResultOfac> documentBatchResult = searchForSwfMensaje(swfMensaje.getBlock4List(),ofacScanServiceImpl);
				searchResponse = fromSearchResultOfacDTO(documentBatchResult, false, ofacScanServiceImpl);
			} else if ((swfMensaje.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0)
					|| (swfMensaje.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO) == 0)) {
				// no se hace nada
				log.info("Mensaje REGISTRADO ANTERIORMENTE " + swfMensaje.toString());
				searchResponse.setCountRegs(0);
			} else {
				// el mensaje tiene un esta
				log.info("Mensaje " + swfMensaje.getMenCodmen() + " REGISTRADO ANTERIORMENTE con estado " + swfMensaje.getMenEstverifica());
				searchResponse.setCountRegs(1);
			}
			cambiarEstadoPostScan(swfMensaje, searchResponse);
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			searchResponse = getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			searchResponse = getSearchResultFromException(e);
		} 
		log.info("~~~~~~~~~~~~~~End verified Message plain ~~~~~~~~~~~~~~[" + searchResponse.getCountRegs() + "]");
		return searchResponse;
	}

	private void verificarEntranteAndSendMail(SwfMensaje swfMensaje, OfacScanServiceImpl ofacScanServiceImpl) {
		log.info("=======verificarEntranteAndSendMail========== " + swfMensaje.getMenCodmen());
		SearchResponse searchResponse = new SearchResponse();
		try {
			SwiftDatos swiftDatos = mensajePlanoToSwfMensaje(swfMensaje.getMenPlano(), false);
			DocumentBatch<SearchResultOfac> documentBatchResult = searchForSwfMensaje(swiftDatos.getSwfMensaje().getBlock4List(), ofacScanServiceImpl);
			searchResponse = fromSearchResultOfacDTO(documentBatchResult, false, ofacScanServiceImpl);

			cambiarEstadoPostScan(swfMensaje, searchResponse);
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
		}

		log.info("~~~~~~~~~~~~~~Fin verificar Mensaje entrante swift ~~~~~~~~~~~~~~[" + searchResponse.getCountRegs() + "]");
	}

	@Async
	public void scanLoteAsync(Integer menNrolote) {
		log.info("@@@@@@@@@@@@@@ Inicio scan async[lote: " + menNrolote + "]... @@@@@@@@@@@@@@@@");
		inicializaValoresScan();
		JPASearchFactoryControllerImpl jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);		
		List<SwfMensaje> mensajesDatosLista = swfMensajeDao.findByNroLote(menNrolote);
		for (SwfMensaje swfMensaje : mensajesDatosLista) {
			log.info("scan async... " + swfMensaje.getMenCodmen());
			if (swfMensaje.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) != 0)
				continue;

			/* #### SCANEO #### */
			verificarEntranteAndSendMail(swfMensaje, ofacScanServiceImpl);
		}
		
		jPASearchFactoryController.close();		
		log.info("Scan async lote {} con regs {} ... hecho ", menNrolote, mensajesDatosLista.size());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.lavado.services.SwiftBcbSearcherService#searchScanSingle
	 * (java.lang.String)
	 */
	public SearchResponse searchScanSingle(String menPlano) {
		log.info("=======searchScanSingle==========");

		SearchResponse searchResponse = null;
		JPASearchFactoryControllerImpl jPASearchFactoryController = null;		
		try{
			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
			jPASearchFactoryController.init();
			OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);			
			
			SwiftDatos swiftDatos = mensajePlanoToSwfMensaje(menPlano, false);
			DocumentBatch<SearchResultOfac> documentBatchResult = searchForSwfMensaje(swiftDatos.getSwfMensaje().getBlock4List(),ofacScanServiceImpl);
			searchResponse = fromSearchResultOfacDTO(documentBatchResult, true, ofacScanServiceImpl);
			searchResponse.setQry(swiftDatos.getSwiftMessageBcb().getMenPlano());
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			searchResponse = getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			searchResponse = getSearchResultFromException(e);
		} finally {
			jPASearchFactoryController.close();			
		}

		log.info("~~~~~~~~~~~~~~End verified Message plain ~~~~~~~~~~~~~~[" + searchResponse.getCountRegs() + "]");
		return searchResponse;
	}

	public SwiftDatos mensajePlanoToSwfMensaje(String menPlano, boolean requireDescrip) {
		log.debug("inicio Desparseo Mensaje Plano");
		SwiftDatos swiftDatos = swiftBcbParserService.swiftDatosFromString(menPlano);
		swiftDatos.getSwfMensaje().setBlock4List(swiftBcbParserService.createListBlock4(swiftDatos.getSwiftMessageBcb(), requireDescrip));
		return swiftDatos;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.lavado.services.SwiftBcbSearcherService#verificarMensaje(java
	 * .lang.String, java.lang.String)
	 */
	public SearchResponse verificarMensaje(String query, String idEstrategia) {
		log.info("==>> verificarMensaje: " + idEstrategia + " : " + query);
		if (idEstrategia == null || idEstrategia.trim().length() == 0) {
			SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CODESTRADEFAULT);
			idEstrategia = swfParams.getParValor().trim().toUpperCase();
		}

		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();
		SearchResponse searchResponse = null;
		JPASearchFactoryControllerImpl jPASearchFactoryController = null;		
		try{
			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
			jPASearchFactoryController.init();
			OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);			
			documentBatchResult = searchForIdEstrategia(query, idEstrategia, ofacScanServiceImpl);
			searchResponse = fromSearchResultOfacDTO(documentBatchResult, true, ofacScanServiceImpl);
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			searchResponse = getSearchResultFromException(e);
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			searchResponse = getSearchResultFromException(e);
		} finally {
			jPASearchFactoryController.close();			
		}
		log.info("==>> Fin scan field: " + idEstrategia + ":" + query + " regs[" + searchResponse.getCountRegs() + "]");
		return searchResponse;
	}

	/**
	 * Proceso de scaneo de items en lista, el proceso es asyncronico
	 * 
	 * @param block4List
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @throws TimeoutException
	 */
	private DocumentBatch<SearchResultOfac> searchForSwfMensaje(List<Block4> block4List, OfacScanServiceImpl ofacScanServiceImpl)
			throws Exception {
		strategyBase = StrategyBase.getInstance(pathDirectoryQueries);
		
		long buildTime = System.currentTimeMillis();
		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();
		if (block4List.size() == 0) {
			log.error("ATENCION: Mensaje sin elementos");
			throw new SwiftAdminException("Mensaje sin elementos para evaluar");
		}
		for (Block4 block4 : block4List) {
			DocumentBatch<SearchResultOfac> documentBatchResultR = ofacScanServiceImpl.searchForFieldSwift(block4.getValue(), block4.getName(), strategyBase);
			if (documentBatchResultR.getBatchSize() > 0)
				for (SearchResultOfac searchResultOfac : documentBatchResultR)
					documentBatchResult.add(searchResultOfac);
			log.info("Resp provisional ==> " + documentBatchResult.getBatchSize());
		}

		log.info("Fin mensaje plano " + (System.currentTimeMillis() - buildTime) + " ms @ " + documentBatchResult.getBatchSize() + " @");
		return documentBatchResult;
	}

	private DocumentBatch<SearchResultOfac> searchForIdEstrategia(String query, String idEstrategia, OfacScanServiceImpl ofacScanServiceImpl)
			throws Exception {
		StrategyBase strategyBase = StrategyBase.getInstance(pathDirectoryQueries);

		Map<String, List<FieldQuery>> fieldQueryMap = strategyBase.matchesForIdEstrategia(idEstrategia);

		if (fieldQueryMap.size() == 0) {
			log.info("==>> field: " + idEstrategia + " Sin estrategias!!! " + pathDirectoryQueries);
			return new DocumentBatch<SearchResultOfac>();
		}
		log.info("===oooO0[Inicio scan Estrategia swift[" + idEstrategia + "] query:\n" + UtilsGeneric.getShortText(query, MAX_CHARS_LOG) + "\n]0Oooo==="
				+ UtilsDate.stringFromDate(new Date(), "ddMMyyyy HH:mm:SS"));

		long buildTime = System.currentTimeMillis();

		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();

		/* ####### process search ###### */
		DocumentBatch<SearchResultOfac> documentBatchResultR = ofacScanServiceImpl.search(query, fieldQueryMap);
		for (SearchResultOfac searchResultOfacR : documentBatchResultR)
			documentBatchResult.add(searchResultOfacR);

		log.info("==>> field: " + idEstrategia + ":" + query + " Con registros!!!" + documentBatchResult.getBatchSize() + "["
				+ (System.currentTimeMillis() - buildTime) + " ms.]");
		return documentBatchResult;
	}

	public String searchForQueryInSwfMensaje(String query, SwfMensaje swfMensaje, String idEstrategia, JPASearchFactoryControllerImpl jPASearchFactoryController)
			throws Exception {
		log.info("searchForQueryInSwfMensaje");
		if (jPASearchFactoryController == null)
			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
		
		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(jPASearchFactoryController, SwfMensaje.class);

		StrategyBase strategyBase = StrategyBase.getInstance(pathDirectoryQueries);

		Map<String, List<FieldQuery>> fieldQueryMap = strategyBase.matchesForIdEstrategia(idEstrategia);
		if (fieldQueryMap == null || fieldQueryMap.size() == 0) {
			log.info("==>> idEstrategia: " + idEstrategia + " Sin estrategias!!!");
			return null;
		}

		for (List<FieldQuery> fieldQueryEntry : fieldQueryMap.values()) {
			for (FieldQuery fieldQuery : fieldQueryEntry) {
				try {
					String hiqh = queryParsersBuilder.highlightFieldSpanNearFuzzy(fieldQuery.getField(), query, swiftBcbParserService.decryptPlano(swfMensaje.getMenPlano()),
							fieldQuery.getDistanceUpTo(), fieldQuery.getPrefixLength(), fieldQuery.getBoost(), fieldQuery.getSlop(), fieldQuery.isInOrder(),
							fieldQuery.getMinWordLen(), fieldQuery.isExceptNumbers(), fieldQuery.getAnalyzer());
					if (hiqh != null) {
						return hiqh;
					}
				} catch (IOException | InvalidTokenOffsetsException e) {
					log.error(e.getMessage(), e);
				}
			}
		}
		return null;
	}

	public List<?> searchForQueryInSwfBics(String query, String idEstrategia) {
		log.info("searchForQueryInSwfBics query {} idEstrategia {}", query, idEstrategia);
		DocumentBatch<SearchResultOfac> documentBatchResult = new DocumentBatch<SearchResultOfac>();
		List<?> searchResponse = new ArrayList<>();
		JPASearchFactoryControllerImpl jPASearchFactoryController = null;		
		try{
			jPASearchFactoryController = new JPASearchFactoryControllerImpl(jPASearchFactoryHolder.getEntityManagerFactory());
			jPASearchFactoryController.init();
			OfacScanServiceImpl ofacScanServiceImpl = new OfacScanServiceImpl(jPASearchFactoryController);			
			documentBatchResult = searchForIdEstrategia(query, idEstrategia , ofacScanServiceImpl);
			searchResponse = documentMatchFromSearchResult(documentBatchResult);
		} catch (NullPointerException e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException("Valor nulo al buscar bics");
		} catch (Throwable e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e.getMessage(),e);			
		} finally {
			jPASearchFactoryController.close();
		}
		return searchResponse;
	}

	/**
	 * Convierte los resultados a {@link SearchResponse} con el numero de items
	 * encontrados
	 * 
	 * @param document
	 * @param requireResp
	 *            true si en la respuesta se devuelve los terminos encontrados
	 *            marcados
	 * @return
	 */
	private SearchResponse fromSearchResultOfacDTO(DocumentBatch<SearchResultOfac> document, boolean requireResp, OfacScanServiceImpl ofacScanServiceImpl) {
		SearchResponse searchResponse = new SearchResponse();

		Map<String, SearchResponse.ItemsInfo> itemsInfoMap = new LinkedHashMap<>();
		log.info("Convert DocumentBatch to SearchResponse " + document.getBatchSize() + " [regs]" + " "
				+ (ofacScanServiceImpl.getjPASearchFactoryController() == null));
		QueryParsersBuilder queryParsersBuilder = new QueryParsersBuilder(ofacScanServiceImpl.getjPASearchFactoryController(), OfaSdnentry.class);

		for (SearchResultOfac searchResultOfac : document) {
			for (OfacQuery ofacQuery : searchResultOfac.getMatches()) {
				log.debug("searchResultOfac " + searchResultOfac.getDocId() + " " + ofacQuery.getQuery());
				ItemsInfo itemsInfo = new ItemsInfo();

				itemsInfo.setScore(ofacQuery.getScore());
				itemsInfo.setIdDoc(searchResultOfac.getDocId());
				if (searchResultOfac.getDocumentMatch() instanceof OfaAkalist) {
					OfaAkalist ofaAkalist = (gob.bcb.lavado.model.OfaAkalist) searchResultOfac.getDocumentMatch();
					itemsInfo.setIdDoc(String.valueOf(ofaAkalist.getAkaEntryuid()));
				}

				itemsInfo.setClazz(ofacQuery.getFieldQuery().getClazz().getSimpleName());
				itemsInfo.setField(ofacQuery.getFieldQuery().getField());

				String idInfo = String.valueOf(Objects.hash(itemsInfo.getClazz(), itemsInfo.getIdDoc()));
				itemsInfo.setId(idInfo);
				String hiqh = "";
				if (requireResp) {
					try {
						if (StringUtils.isBlank(ofacQuery.getTermHigh())) {
							hiqh = queryParsersBuilder.highlightFieldSpanOrQueryFuzzy(itemsInfo.getField(), ofacQuery.getQuery(), ofacQuery.getTerm(),
									ofacQuery.getFieldQuery().getDistanceUpTo(), ofacQuery.getFieldQuery().getPrefixLength(),
									ofacQuery.getFieldQuery().getBoost(), ofacQuery.getFieldQuery().getSlop(), ofacQuery.getFieldQuery().isInOrder(),
									ofacQuery.getFieldQuery().getMinWordLen(), ofacQuery.getFieldQuery().isExceptNumbers(),
									ofacQuery.getFieldQuery().getAnalyzer());
						} else {
							hiqh = ofacQuery.getTermHigh();
						}

						if (hiqh == null) {
							hiqh = ofacQuery.getTerm();
						}
					} catch (IOException | InvalidTokenOffsetsException e) {
						log.error(e.getMessage(), e);
						hiqh = "";
					}
				}
				if (!itemsInfoMap.containsKey(idInfo)) {
					itemsInfo.setContentHighlight(ofacQuery.getFieldQuery().getField() + ": " + hiqh);
					itemsInfoMap.put(idInfo, itemsInfo);
				} else {
					itemsInfoMap.get(idInfo).setContentHighlight(
							itemsInfoMap.get(idInfo).getContentHighlight() + "<br/>" + ofacQuery.getFieldQuery().getField() + ": " + hiqh);
					itemsInfoMap.get(idInfo).setScore(itemsInfoMap.get(idInfo).getScore() + itemsInfo.getScore());
				}
			}
		}

		List<ItemsInfo> itemsInfoList = itemsInfoMap.values().stream().collect(Collectors.toList());
		searchResponse.setCountRegs(itemsInfoList.size());
		itemsInfoList.sort((u1, u2) -> u1.getScore().compareTo(u2.getScore()));
		Collections.reverse(itemsInfoList);

		searchResponse.setItemsInfo(itemsInfoList.toArray(new SearchResponse.ItemsInfo[0]));
		searchResponse.setDescripResp("Operacion de scaneo realizada exitosamente sin observados");
		searchResponse.setCodResp(Constants.COD_RESP_EXITO);
		if (searchResponse.getCountRegs() > 0){
			searchResponse.setCodResp(Constants.COD_RESP_ERR_01);			
			searchResponse.setDescripResp("Operacion de Scaneo con registros observados " + searchResponse.getCountRegs());			
		}
		log.info("Registros encontrados ==> [" + searchResponse.getCountRegs() + "] regs.");
		return searchResponse;
	}

	private List<?> documentMatchFromSearchResult(DocumentBatch<SearchResultOfac> document) {
		Map<String, Object> itemsInfoMap = new LinkedHashMap<>();
		log.info("Convert DocumentBatch to List " + document.getBatchSize() + " [regs]");
		for (SearchResultOfac searchResultOfac : document) {
			for (OfacQuery ofacQuery : searchResultOfac.getMatches()) {
				log.debug("searchResultOfac " + searchResultOfac.getDocId() + " " + ofacQuery.getQuery());
				String idInfo = String.valueOf(Objects.hash(ofacQuery.getFieldQuery().getClazz().getSimpleName(), searchResultOfac.getDocId()));
				if (!itemsInfoMap.containsKey(idInfo)) {
					itemsInfoMap.put(idInfo, searchResultOfac.getDocumentMatch());
				}
				if (itemsInfoMap.size() > Constants.SEARCH_LIMIT_REGS){
					break;
				}
			}
			if (itemsInfoMap.size() > Constants.SEARCH_LIMIT_REGS){
				break;
			}
		}

		List<Object> itemsInfoList = itemsInfoMap.values().stream().collect(Collectors.toList());
		return itemsInfoList;
	}

	/**
	 * retorna el objeto detallando la excepcion
	 * 
	 * @param e
	 * @return
	 */
	private SearchResponse getSearchResultFromException(Throwable e) {
		log.info("Generando objeto respuesta por exception " + e.getMessage());
		StringBuilder sb = new StringBuilder();
		int count = 0;
		for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
			if (cause instanceof SQLException) {
				count++;
				sb.append(cause.getMessage());
				sb.append(" , ");
			}
		}
		String consent = (count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", ""));
		
		SearchResponse searchResponse = new SearchResponse();
		List<SearchResponse.ItemsInfo> itemsInfoList = new LinkedList<>();
		searchResponse.setCodResp(Constants.COD_RESP_ERR_02);
		searchResponse.setCountRegs(1);
		searchResponse.setItemsInfo(itemsInfoList.toArray(new SearchResponse.ItemsInfo[0]));
		searchResponse.setDescripResp(consent);
		
		log.info("Respuesta con Error " + searchResponse.getCodResp() + ": " + searchResponse.getDescripResp());
		return searchResponse;
	}

	/**
	 * Cambia el estado segun el parametro ACCIONSCAN de la tabla parametros
	 * 
	 * @param swfMensaje
	 *            Objeto {@link SwfMensaje} de base de datos
	 * @param searchResponse
	 *            objeto {@link SearchResponse} de respuesta del scaneo
	 * @return Nuevo objeto {@link SwfMensaje}
	 */
	private SwfMensaje cambiarEstadoPostScan(SwfMensaje swfMensaje, SearchResponse searchResponse) {
		SwfMensaje swfMensajeNew = swfMensajeDao.cambiarEstadoPostScan(swfMensaje.getMenCodmen(), searchResponse.getCountRegs(), accionScan);
		searchResponse.setCodoperacion(String.valueOf(swfMensajeNew.getMenCodmen()));
		searchResponse.setIdresponse(swfMensajeNew.getMenHash());
		searchResponse.setNrocorr(swfMensajeNew.getMenNrocorr());

		if (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0
				|| swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0) {
			sendMailForVerify(swfMensajeNew,Constants.COD_APP_NEMO+": Alerta de mensaje swift observado " + swfMensajeNew.getMenCodmen());
		}
		if (swfMensajeNew.getMenInout().equals(Constants.TIPO_MENSAJE_IN) && searchResponse.getCountRegs().compareTo(0) > 0 ){
			if (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO) == 0)
				sendMailForVerify(swfMensajeNew,Constants.COD_APP_NEMO+": Alerta de mensaje Entrante observado " + swfMensajeNew.getMenCodmen());
		}
		accionPostScan(swfMensajeNew, searchResponse);
		return swfMensajeNew;
	}

	private void accionPostScan(SwfMensaje swfMensajeNew, SearchResponse searchResponse) {
		// acciones de respuesta si es observado
		if (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0
				|| swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0) {
			// mensaje escaneado y bloqueado
			searchResponse.setCodResp(Constants.COD_RESP_ERR_01);
			searchResponse.setDescripResp("Mensaje " + swfMensajeNew.getMenCodmen() + "[" + swfMensajeNew.getMenCodswift()
					+ "] se encuentra bloqueado, comuniquese con el adm de LAVADO");
			log.info("Mensaje bloqueado [" + swfMensajeNew.getMenCodmen() + "] scaneado con estado " + swfMensajeNew.getMenEstverifica());
		} else {
			// mensaje observado pero no se bloquea
			searchResponse.setCountRegs(0);
			searchResponse.setCodResp(Constants.COD_RESP_EXITO);
			searchResponse.setItemsInfo(new SearchResponse.ItemsInfo[0]);
			searchResponse.setDescripResp("Operacion de control de lavado: mensaje swift sin observados.");

			log.info("Mensaje observado sin bloqueo [" + swfMensajeNew.getMenCodmen() + "] scaneado con estado " + swfMensajeNew.getMenEstverifica());
		}
	}

	private void inicializaValoresScan() {
		inicializaCorreos();
		inicializaTipoBloqueo();
	}

	private void inicializaCorreos() {
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CORRALERTAVERIF);
		String correos = swfParams.getParValor();
		log.debug("Preparando mails de mensaje observado " + correos);
		final String[] tokens = StringUtils.split(correos, ",;");
		final ArrayList<String> result = new ArrayList<String>();

		for (int i = 0; i < tokens.length; i++) {
			if (StringUtils.isNotBlank(tokens[i]))
				result.add(tokens[i]);
		}
		emailDetalle.setTo(result.toArray(new String[result.size()]));
	}

	private void inicializaTipoBloqueo() {
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_ACCIONSCAN);
		accionScan = swfParams.getParValor();
		log.info("Mensaje con observaciones accion a tomar " + accionScan);
	}

	private void sendMailForVerify(SwfMensaje swfMensaje, String subject) {
		// correos para alerta
		MensajesDatos mensajesDatos = new MensajesDatos();
		mensajesDatos.setSwfMensaje(swfMensaje);
		
		emailDetalle.setSubject(subject);
		
		mailService.sendAlertSwiftForRevisionEmail(mensajesDatos, emailDetalle, null);
		log.info("Envio de correo de ALERTA hecho... " + swfMensaje.getMenCodmen());
	}
}
