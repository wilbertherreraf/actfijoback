package gob.bcb.lavado.services;

import java.util.List;

import gob.bcb.lavado.model.OfaSdnentry;

public interface OfaListService {

	void cargarListaOfac(String fileSdn, Integer nrolote);

	void truncateTablesOfac(String codUsuario, String estacion) throws Throwable;

	//int loadListsFromDirectory(String inputDirectory, boolean continueIfExist, String codusuario, String estacion) throws Exception;

	void loadListsFromDirectory(String codusuario, String estacion) throws Exception;

}