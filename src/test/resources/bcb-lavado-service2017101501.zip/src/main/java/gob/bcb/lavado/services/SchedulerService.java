package gob.bcb.lavado.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;
import java.util.concurrent.ScheduledFuture;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.scheduling.support.SimpleTriggerContext;
import org.springframework.stereotype.Service;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.lavado.QL.contbcb.CoinQLBean;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.pojos.SchedData;

@Service(value = "schedulerService")
public class SchedulerService {
	private final Logger log = LoggerFactory.getLogger(SchedulerService.class);

	private static Map<String, ScheduledFuture> scheduledFutures = new HashMap<String, ScheduledFuture>();
	@Autowired
	private TaskScheduler taskScheduler;

	@Autowired
	private CoinQLBean coinQLBean;

	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;

	public SchedulerService() {
		log.info("created SchedulerService");
	}

	private List<SchedData> cronConfig(String idscheduler, String horas, String cronExpr) {
		log.info("cronConfig  idscheduler {}, horas {}, cronExpr {}", idscheduler, horas, cronExpr);
		List<SchedData> schedDataList = new ArrayList<>();
		if (StringUtils.isBlank(horas)) {
			return schedDataList;
		}
		// String cronExpr = "ss mm hh ? * 2-6"; // "0 0/1 * 1/1 * ? *"
		for (String keyValue : horas.split(" *, *")) {
			String[] pairs = keyValue.split(" *: *", 3);
			if (pairs.length < 2)
				throw new RuntimeException("Formato de hora requiere minimo hora y minuto Value:" + keyValue);
			SchedData schedData = new SchedData(pairs[0], pairs[1]);
			schedData.setCronExp(cronExpr);

			if (pairs.length == 3)
				schedData.setSegundo(pairs[2]);
			schedData.setIdScheduler(idscheduler + schedData.getHora() + schedData.getMinuto() + StringUtils.trimToEmpty(schedData.getSegundo()));
			schedDataList.add(schedData);
		}

		return schedDataList;
	}

	public String startScheduling(String horas, String idsched, String cronExpr) {
		log.info("Start Scheduler horas {}, idsched {}, cronExpr {} ", horas, idsched, cronExpr);
		cancelById(idsched);
		scheduleAdd(horas, idsched, cronExpr);
		log.info("Scheduling of jobs has been started.");
		return "OK";
	}

	private void scheduleAdd(String horas, String idsched, String cronExpr) {
		log.info("Scheduling all applications to run.");

		// eventually go through the database and load all jobs to be scheduled
		// here.
		List<SchedData> schedDataList = cronConfig(idsched, horas, cronExpr);
		for (SchedData schedData : schedDataList) {
			if (idsched.equals(Constants.PARAM_HORARIOSIMPORT)) {
				if (!StringUtils.isBlank(schedData.cronExpresion())){
					ScheduledFuture<?> future = schedule(schedData, grabarEnDirectorioJob(schedData.cronExpresion()));
					if (future != null)
						scheduledFutures.put(schedData.getIdScheduler(), future);
				}
			} else if (idsched.equals(Constants.PARAM_HORARIOSINDEXAR)) {
				if (!StringUtils.isBlank(schedData.cronExpresion())){				
					ScheduledFuture<?> future = schedule(schedData, indexar(schedData.cronExpresion()));
					if (future != null)					
						scheduledFutures.put(schedData.getIdScheduler(), future);
				}
			}
		}
	}

	private void cancelById(String idscheduler) {
		log.info("Cancelando por id {} ", idscheduler);
		for (Entry<String, ScheduledFuture> entry : scheduledFutures.entrySet()) {
			ScheduledFuture scheduledFuture = entry.getValue();
			if (scheduledFuture == null)
				continue;
			String idsch = entry.getKey();
			if (idsch.startsWith(idscheduler)) {
				log.info("Cancelando scheduledFuture " + idsch + " " + (scheduledFuture == null)) ;				
				if (!scheduledFuture.isCancelled())
					scheduledFuture.cancel(true);
			}
		}
		
		Iterator it = scheduledFutures.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			String idsch = (String) pair.getKey();
			if (idsch.startsWith(idscheduler)) {
				log.info("Borrando de scheduledFuture " + idsch);
				it.remove(); // avoids a ConcurrentModificationException
			}
		}
		
		for (Entry<String, ScheduledFuture> entry : scheduledFutures.entrySet()) {
			log.info("Schedules disponibles: " + entry.getKey());			
		}
	}

	/**
	 * Schedule the scheduled report with the given cron schedule information
	 */
	private ScheduledFuture<?> schedule(SchedData schedData, Runnable runnable) {
		TimeZone tz = TimeZone.getDefault();
		log.info("Setting cron expression {} to execute at time {}.", schedData.cronExpresion(), tz.getDisplayName());
		if (StringUtils.isEmpty(schedData.cronExpresion())) {
			log.error("Expresion cron invalida");
			return null;
		}
		TriggerContext EMPTY_TRIGGER_CONTEXT = new SimpleTriggerContext();
		String cronExprPendientes = schedData.cronExpresion();
		Trigger cronTrigger = new CronTrigger(cronExprPendientes);

		if (taskScheduler == null) {
			log.error("Unable to schedule job as scheduler was not found");
			return null;
		}

		log.info("schedule job as scheduler was found [" + UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy HH:mm:ss") + "] with next execution "
				+ UtilsDate.stringFromDate(cronTrigger.nextExecutionTime(EMPTY_TRIGGER_CONTEXT), "dd/MM/yyyy HH:mm:ss"));

		ScheduledFuture<?> future = taskScheduler.schedule(runnable, cronTrigger);

		return future;
	}

	private Runnable grabarEnDirectorioJob(String cronExpr) {
		return () -> {
			Date fecha = new Date();
			boolean isHabil = coinQLBean.isHabil(fecha);
			TriggerContext EMPTY_TRIGGER_CONTEXT = new SimpleTriggerContext();
			Trigger cronTrigger = new CronTrigger(cronExpr);
			log.info("Ejecutando [" + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy HH:mm:ss") + "] en Dia Habil? " + isHabil);
			log.info("schedule job next execution " + UtilsDate.stringFromDate(cronTrigger.nextExecutionTime(EMPTY_TRIGGER_CONTEXT), "dd/MM/yyyy HH:mm:ss"));
			if (isHabil)
				swiftAdminDaoService.grabarEnDirectorioSwift("userjoblavado", Constants.COD_APP_NEMO);
		};
	}

	private Runnable indexar(String cronExpr) {
		return () -> {
			Date fecha = new Date();
			TriggerContext EMPTY_TRIGGER_CONTEXT = new SimpleTriggerContext();
			Trigger cronTrigger = new CronTrigger(cronExpr);
			log.info("schedule [" + UtilsDate.stringFromDate(fecha, "dd/MM/yyyy HH:mm:ss") + "] job next execution "
					+ UtilsDate.stringFromDate(cronTrigger.nextExecutionTime(EMPTY_TRIGGER_CONTEXT), "dd/MM/yyyy HH:mm:ss"));
			try {
				swiftAdminDaoService.indexLvdEntities();
				swiftAdminDaoService.indexOfaSdnentry();
			} catch (Exception e) {
				log.error("Error al indexar " + e.getMessage());
			}
		};
	}

	public static Map<String, String> paramsLista(String text) {
		Map<String, String> map = new LinkedHashMap<String, String>();
		if (text == null || text.trim().length() == 0) {
			return map;
		}
		String params = new String(text);

		for (String keyValue : params.split(" *, *")) {
			String[] pairs = keyValue.split(" *: *", 2);
			map.put(pairs[0], pairs.length == 1 ? "" : pairs[1]);
		}
		return map;
	}

	public static boolean isRunningScheduler() {
		return scheduledFutures.size() > 0;
	}
}
