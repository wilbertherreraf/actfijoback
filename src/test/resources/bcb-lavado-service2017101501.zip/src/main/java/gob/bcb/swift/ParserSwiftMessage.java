package gob.bcb.swift;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParserSwiftMessage {
	private static final Logger log = LoggerFactory.getLogger(ParserSwiftMessage.class);
	
	public static String[] splitSwift(String str) {
		ArrayList<Object> splitLista = new ArrayList<>();
		if (StringUtils.isBlank(str)) {
			log.error("Error al dividir lote de mensajes swift Parametro nulo");
			throw new RuntimeException("Error al dividir lote de mensajes swift Parametro nulo");
		}

		str = str.concat("{1:}");
		str = str.replace("\r\n", "#|");

		String strIni = "\\{1:";
		String strFin = "\\{1:";

		Pattern pattern = Pattern.compile("" + strIni + "(.*?)(?=" + strFin + ")");
		Matcher matcher = pattern.matcher(str);

		while (matcher.find()) {
			String swiftPlano = matcher.group();
			swiftPlano = swiftPlano.replace("#|", "\r\n");
			splitLista.add(swiftPlano);
		}
		log.info("SplitSwift Mensajes " + splitLista.size());

		String[] res = new String[splitLista.size()];
		return splitLista.toArray(res);		
	}

	public static boolean isFormatSwift(String plano){
		if (StringUtils.isBlank(plano)) {
			return false;
		}
		//plano = plano.concat("{1:}");
		String strIni = "\\{1:";
		String strFin = "\\}\\{1:";
		strFin = "\\}";
		Pattern pattern = Pattern.compile("" + strIni + "(.*?)(?=" + strFin + ")");
		Matcher matcher = pattern.matcher(plano);
		return  matcher.find();
	}
}
