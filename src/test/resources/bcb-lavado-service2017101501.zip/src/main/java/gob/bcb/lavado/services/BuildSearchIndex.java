package gob.bcb.lavado.services;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.repository.SwfParamsDao;

@Component
public class BuildSearchIndex {
	private static final Logger log = LoggerFactory.getLogger(BuildSearchIndex.class);

	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private SchedulerService schedulerService;
	
//	@Autowired
//	private AppProperties appProperties;
//	
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
    @EventListener
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
    	log.info("oooooOOOOOO00000 en onApplicationEvent 00000OOOOOooooo");
    	SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_HORARIOSIMPORT);
    	log.info("schedulerService con: " + swfParams.getParValor());    	

    	//schedulerService.startScheduling(swfParams.getParValor(), Constants.PARAM_HORARIOSIMPORT, Constants.SCHEDULER_CRON_EXPRESION);
    	swfParams = swfParamsDao.findByCod(Constants.PARAM_HORARIOSINDEXAR);
    	schedulerService.startScheduling(swfParams.getParValor(), Constants.PARAM_HORARIOSINDEXAR, Constants.SCHEDULER_CRON_EXPRESION);    	
       
    	try {
			swiftAdminDaoService.indexOfaSdnentry();
//			log.info("Indexando entidades lvd");
//			swiftAdminDaoService.indexLvdEntities();
		} catch (Exception e) {
			throw new RuntimeException("Error al iniciar indices OFAC");
		}
    	log.info("oooooOOOOOO LAVADO IINCIALIZADO A LA ESPERA DE MENSAJES OOOOOooooo");    	
    }

}
