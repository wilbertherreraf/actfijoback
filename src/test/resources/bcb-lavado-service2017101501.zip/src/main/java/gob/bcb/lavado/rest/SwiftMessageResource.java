package gob.bcb.lavado.rest;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.rest.dto.SearchResponse;
import gob.bcb.lavado.services.SwiftAdminDaoService;
import gob.bcb.lavado.services.SwiftBcbSearcherService;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(Constants.PATH_RESOURCE_API_SEARCH)
//@Api(tags = { "Scans" })
public class SwiftMessageResource {
	private final Logger log = LoggerFactory.getLogger(SwiftMessageResource.class);
	// public final static String PATH_RESOURCE_API_SEARCH =
	// Constants.PATH_RESOURCE_API_SEARCH;
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;

	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private SwiftAdminDaoService swiftAdminDaoService;
	
	@RequestMapping(value = "/lvd-inicia", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Solicita session", response = SearchResponse.class)
	public ResponseEntity<SearchResponse> getSessionLavado(@RequestParam(value = "codapp") String codapp, @RequestParam(value = "coduser") String coduser, HttpServletRequest request) {
		log.info("REST request lvd-ini:=> para solicitar SESSION codapp {} coduser {}", codapp, coduser);
		SearchResponse searchResponse = swiftBcbSearcherService.beginSession(codapp, coduser, request.getRemoteAddr());

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	@RequestMapping(value = "/scan-correlativo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Solicita un numero de correlativo swift y registra el mensaje", response = SearchResponse.class)
	public ResponseEntity<SearchResponse> solicitarCorrelativo(@RequestParam(value = "codapp") String codapp,
			@RequestParam(value = "idop") String codoperacion, @RequestParam(value = "coduser") String coduser,
			@RequestParam(value = "idsession") String idsession, HttpServletRequest request) {
		log.info("REST request:=> para solicitar correlativo codapp {} codoperacion {} user {} idsession {}", codapp, codoperacion, coduser, idsession);
		SearchResponse searchResponse = swiftBcbSearcherService.solicitarCorrelativo(codapp, codoperacion, coduser, idsession, request.getRemoteAddr());

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	@RequestMapping(value = "/scan-registro", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Escanea un mensaje swift en formato plano, requiere codigo de aplicación y codigo de usuario", response = SearchResponse.class)
	public ResponseEntity<SearchResponse> scanSwift(@RequestParam(value = "codapp") String codapp, @RequestParam(value = "coduser") String coduser,
			@RequestParam(value = "codlvd") Integer codlvd, @RequestParam(value = "nroswf") Integer nroCorrelativo,
			@RequestParam(value = "idop") String codoperacion, @RequestParam(value = "idsession") String idSession,
			@RequestParam(value = "swfp") String menPlano, HttpServletRequest request) {

		log.info("REST request scan-registro:=> scan mensaje swift REGISTRO app {} usr {} codlvd {} idoperacion {} session {}", codapp, coduser, codlvd,
				codoperacion, idSession);

		SearchResponse searchResponse = swiftBcbSearcherService.scanMensajePlanoConCorrSolicitado(menPlano, codapp, codlvd, nroCorrelativo, codoperacion,
				coduser, request.getRemoteAddr(), idSession);

		log.info("### ANTES DE RETORNO scan-registro [" + searchResponse.getCountRegs() + "]###");

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	@RequestMapping(value = "/scan-preaut", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Preautoriza un mensaje swift registrado y scaneado, requiere codigo de aplicación y codigo de usuario", response = SearchResponse.class)
	public ResponseEntity<SearchResponse> preautorizarSwift(@RequestParam(value = "codapp") String codapp, @RequestParam(value = "coduser") String coduser,
			@RequestParam(value = "codlvd") Integer codlvd, @RequestParam(value = "nroswf") Integer nroCorrelativo,
			@RequestParam(value = "idop") String codoperacion, @RequestParam(value = "idsession") String idSession,
			@RequestParam(value = "swfp") String menPlano, HttpServletRequest request) {

		log.info("REST request preautoriza:=> pre autorizar swift scaneado app {} usr {} codlvd {} idoperacion {} session {}", codapp, coduser, codlvd,
				codoperacion, idSession);

		SearchResponse searchResponse = swiftBcbSearcherService.preAutorizaSwift(codlvd, codapp, coduser, codoperacion, idSession, menPlano, request.getRemoteAddr());

		log.info("### ANTES DE RETORNO preautoriza [" + searchResponse.getCountRegs() + "]###");
		if (searchResponse.getCodResp().equals(Constants.COD_RESP_EXITO)){
			guardarEnImportados(codlvd, coduser, request.getRemoteAddr());
		}
		
		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	@RequestMapping(value = "/lvd-fin", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	//@ApiOperation(value = "Finaliza una session de lavado", response = SearchResponse.class)
	public ResponseEntity<SearchResponse> endSession(@RequestParam(value = "codapp") String codapp,
			@RequestParam(value = "coduser") String coduser, @RequestParam(value = "idsession") String idSession, HttpServletRequest request) {

		log.info("REST request lvd-fin:=> fin session app {} usr {} session {}", codapp, coduser, idSession);

		SearchResponse searchResponse = swiftBcbSearcherService.endSession(codapp, idSession, coduser, request.getRemoteAddr());

		log.info("### ANTES DE RETORNO lvd-fin [" + searchResponse.getCountRegs() + "]###");

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	/**
	 * SEARCH /_search/scan-single?query=:query : search for swift in the text
	 * plain corresponding to the query. Not send mail and not save in DB
	 *
	 * @param query
	 *            text swift
	 * @return the result of the search
	 */
	@RequestMapping(value = "/scan-single", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, params = { "query" })
	//@ApiOperation(value = "Escanea un mensaje swift en formato plano, no realiza ningún registro en base de datos", response = SearchResponse.class)
	public ResponseEntity<SearchResponse> searchScanSingle(@RequestParam(value = "query") String menPlano, HttpServletRequest request) {
		log.info("REST request:=> to search searchScanSingle for query " + request.getRemoteAddr());
		log.info(menPlano);
		SearchResponse searchResponse = swiftBcbSearcherService.searchScanSingle(menPlano);

		log.info("### ### ### ANTES DE RETORNO [" + searchResponse.getCountRegs() + "]### ### ###");

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	/**
	 * SEARCH /_search/scan-field?query=:query&field=:field : search for swift
	 * in the text plain corresponding to the query.
	 * 
	 * @param query
	 *            texto a buscar
	 * @param fieldSwift
	 *            codigo de consulta
	 * @return
	 */
	@RequestMapping(value = "/scan-field", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE, params = { "query", "field" })
	//@ApiOperation(value = "Escanea un mensaje una cadena según el codigo de estrategia en field", response = SearchResponse.class)
	public ResponseEntity<SearchResponse> searchScanField(@RequestParam(value = "query") String query, @RequestParam(value = "field") String fieldSwift, HttpServletRequest request) {
		log.info("REST request:=> to search for searchScanField query {} field{}", query, fieldSwift);

		SearchResponse searchResponse = swiftBcbSearcherService.verificarMensaje(query, fieldSwift);

		return Optional.ofNullable(searchResponse).map(result -> new ResponseEntity<>(result, HttpStatus.OK))
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}
	
	private void guardarEnImportados(Integer menCodmen, String coduser, String estacion){
		SwfMensaje swfMensaje = swfMensajeDao.findByCodigo(menCodmen);
		if (swfMensaje != null){
			List<SwfMensaje> swfMensajeLista = new ArrayList<>();
			swfMensajeLista.add(swfMensaje);
			swiftAdminDaoService.grabarEnDirectorioSwift(swfMensajeLista, coduser, estacion);
		}
	}
}
