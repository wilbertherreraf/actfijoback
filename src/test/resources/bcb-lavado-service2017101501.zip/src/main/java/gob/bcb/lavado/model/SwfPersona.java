package gob.bcb.lavado.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;


/**
 * The persistent class for the swf_persona database table.
 * 
 */
@Entity
@Table(name="swf_persona")
public class SwfPersona implements Serializable, gob.bcb.lavado.model.DomainObject {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="per_codemp")
	private Integer perCodemp;

	@Column(name="per_nombre")
	private String perNombre;
	
	@Column(name="per_email")
	private String perEmail;

	@Column(name="per_prefunidadorgs")
	private String perPrefunidadorgs;
	
	@Column(name="per_arecod")
	private String perArecod;	

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "per_auditfho")
	private Date perAuditfho;

	@Column(name = "per_auditusr")
	private String perAuditusr;

	@Column(name = "per_auditwst")
	private String perAuditwst;
	
	public SwfPersona() {
	}

	public Integer getPerCodemp() {
		return this.perCodemp;
	}

	public void setPerCodemp(Integer perCodemp) {
		this.perCodemp = perCodemp;
	}

	public String getPerEmail() {
		return this.perEmail;
	}

	public void setPerEmail(String perEmail) {
		this.perEmail = perEmail;
	}

	public String getPerPrefunidadorgs() {
		return perPrefunidadorgs;
	}

	public void setPerPrefunidadorgs(String perPrefunidadorgs) {
		this.perPrefunidadorgs = perPrefunidadorgs;
	}

	public Date getPerAuditfho() {
		return perAuditfho;
	}

	public void setPerAuditfho(Date perAuditfho) {
		this.perAuditfho = perAuditfho;
	}

	public String getPerAuditusr() {
		return perAuditusr;
	}

	public void setPerAuditusr(String perAuditusr) {
		this.perAuditusr = perAuditusr;
	}

	public String getPerAuditwst() {
		return perAuditwst;
	}

	public void setPerAuditwst(String perAuditwst) {
		this.perAuditwst = perAuditwst;
	}

	public String getPerNombre() {
		return perNombre;
	}

	public void setPerNombre(String perNombre) {
		this.perNombre = perNombre;
	}

	public String getPerArecod() {
		return perArecod;
	}

	public void setPerArecod(String perArecod) {
		this.perArecod = perArecod;
	}

	@Override
	public String toString() {
		return "SwfPersona [perCodemp=" + perCodemp + ", perNombre=" + perNombre + ", perEmail=" + perEmail + ", perPrefunidadorgs=" + perPrefunidadorgs + ", perArecod="
				+ perArecod + ", perAuditfho=" + perAuditfho + ", perAuditusr=" + perAuditusr + ", perAuditwst=" + perAuditwst + "]";
	}

	
}