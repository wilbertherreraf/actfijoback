package gob.bcb.lavado.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TermVector;

/**
 * The persistent class for the ofa_sdnentry database table.
 * 
 */
@Entity
@Table(name = "ofa_sdnentry")
public class OfaSdnentry implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "sdn_id")
	@DocumentId
	private Integer sdnId;

	@Field(analyze = Analyze.NO)
	@Column(name = "sdn_entryuid")
	private Integer sdnEntryuid;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "sdn_firstname")
	private String sdnFirstname;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "sdn_lastname")
	private String sdnLastname;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "sdn_programlist")
	private String sdnProgramlist;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "sdn_remarks")
	private String sdnRemarks;

	//@Field(analyze = Analyze.NO, norms = Norms.NO)
	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "sdn_sdntype")
	private String sdnSdntype;

	@Field(store = Store.YES, termVector = TermVector.WITH_POSITION_OFFSETS)
	@Column(name = "sdn_title")
	private String sdnTitle;

	@Column(name = "sdn_nrolote")
	private Integer sdnNrolote;
	
	//@IndexedEmbedded()
	@OneToMany(mappedBy = "ofaSdnentry", fetch = FetchType.LAZY)
	//@JsonIgnore
	private Set<OfaAddresslist> ofaAddresslist;

	//@IndexedEmbedded(includeEmbeddedObjectId = true)
	@ContainedIn
	@OneToMany(mappedBy = "ofaSdnentry", fetch = FetchType.LAZY)
	//@JsonIgnore	
	private Set<OfaAkalist> ofaAkalist = new HashSet<>();

	//@IndexedEmbedded()
	@OneToMany(mappedBy = "ofaSdnentry", fetch = FetchType.LAZY)
	//@JsonIgnore	
	private Set<OfaCitizenship> ofaCitizenship = new HashSet<>();

	//@IndexedEmbedded()
	@OneToMany(mappedBy = "ofaSdnentry", fetch = FetchType.LAZY)
	//@JsonIgnore	
	private Set<OfaDateofbirth> ofaDateofbirth = new HashSet<>();

	//@IndexedEmbedded()
	@OneToMany(mappedBy = "ofaSdnentry", fetch = FetchType.LAZY)
	//@JsonIgnore	
	private Set<OfaIdlist> ofaIdlist = new HashSet<>();

	//@IndexedEmbedded()
	@OneToMany(mappedBy = "ofaSdnentry", fetch = FetchType.LAZY)
	//@JsonIgnore	
	private Set<OfaNationality> ofaNationality = new HashSet<>();

	//@IndexedEmbedded()
	@OneToMany(mappedBy = "ofaSdnentry", fetch = FetchType.LAZY)
	//@JsonIgnore	
	private Set<OfaPlaceofbirth> ofaPlaceofbirth = new HashSet<>();

	//@IndexedEmbedded()
	@OneToOne(mappedBy = "ofaSdnentry", fetch = FetchType.LAZY)
	//@JsonIgnore	
	private OfaVesselinfo ofaVesselinfo;

	public OfaSdnentry() {
	}

	public Integer getSdnId() {
		return this.sdnId;
	}

	public void setSdnId(Integer sdnId) {
		this.sdnId = sdnId;
	}

	public Integer getSdnEntryuid() {
		return this.sdnEntryuid;
	}

	public void setSdnEntryuid(Integer sdnEntryuid) {
		this.sdnEntryuid = sdnEntryuid;
	}

	public String getSdnFirstname() {
		return this.sdnFirstname;
	}

	public void setSdnFirstname(String sdnFirstname) {
		this.sdnFirstname = sdnFirstname;
	}

	public String getSdnLastname() {
		return this.sdnLastname;
	}

	public void setSdnLastname(String sdnLastname) {
		this.sdnLastname = sdnLastname;
	}

	public String getSdnProgramlist() {
		return this.sdnProgramlist;
	}

	public void setSdnProgramlist(String sdnProgramlist) {
		this.sdnProgramlist = sdnProgramlist;
	}

	public String getSdnRemarks() {
		return this.sdnRemarks;
	}

	public void setSdnRemarks(String sdnRemarks) {
		this.sdnRemarks = sdnRemarks;
	}

	public String getSdnSdntype() {
		return this.sdnSdntype;
	}

	public void setSdnSdntype(String sdnSdntype) {
		this.sdnSdntype = sdnSdntype;
	}

	public String getSdnTitle() {
		return this.sdnTitle;
	}

	public void setSdnTitle(String sdnTitle) {
		this.sdnTitle = sdnTitle;
	}

	public Set<OfaAddresslist> getOfaAddresslist() {
		return ofaAddresslist;
	}

	public void setOfaAddresslist(Set<OfaAddresslist> ofaAddresslist) {
		this.ofaAddresslist = ofaAddresslist;
	}

	public Set<OfaAkalist> getOfaAkalist() {
		return ofaAkalist;
	}

	public void setOfaAkalist(Set<OfaAkalist> ofaAkalist) {
		this.ofaAkalist = ofaAkalist;
	}

	public Set<OfaCitizenship> getOfaCitizenship() {
		return ofaCitizenship;
	}

	public void setOfaCitizenship(Set<OfaCitizenship> ofaCitizenship) {
		this.ofaCitizenship = ofaCitizenship;
	}

	public Set<OfaDateofbirth> getOfaDateofbirth() {
		return ofaDateofbirth;
	}

	public void setOfaDateofbirth(Set<OfaDateofbirth> ofaDateofbirth) {
		this.ofaDateofbirth = ofaDateofbirth;
	}

	public Set<OfaIdlist> getOfaIdlist() {
		return ofaIdlist;
	}

	public void setOfaIdlist(Set<OfaIdlist> ofaIdlist) {
		this.ofaIdlist = ofaIdlist;
	}

	public Set<OfaNationality> getOfaNationality() {
		return ofaNationality;
	}

	public void setOfaNationality(Set<OfaNationality> ofaNationality) {
		this.ofaNationality = ofaNationality;
	}

	public Set<OfaPlaceofbirth> getOfaPlaceofbirth() {
		return ofaPlaceofbirth;
	}

	public void setOfaPlaceofbirth(Set<OfaPlaceofbirth> ofaPlaceofbirth) {
		this.ofaPlaceofbirth = ofaPlaceofbirth;
	}

	public OfaVesselinfo getOfaVesselinfo() {
		return ofaVesselinfo;
	}

	public void setOfaVesselinfo(OfaVesselinfo ofaVesselinfo) {
		this.ofaVesselinfo = ofaVesselinfo;
	}

	@Override
	public String toString() {
		return "OfaSdnentry [sdnId=" + sdnId + ", sdnEntryuid=" + sdnEntryuid + ", sdnFirstname=" + sdnFirstname + ", sdnLastname=" + sdnLastname
				+ ", sdnProgramlist=" + sdnProgramlist + ", sdnRemarks=" + sdnRemarks + ", sdnSdntype=" + sdnSdntype + ", sdnTitle=" + sdnTitle + "]";
	}

	public Integer getSdnNrolote() {
		return sdnNrolote;
	}

	public void setSdnNrolote(Integer sdnNrolote) {
		this.sdnNrolote = sdnNrolote;
	}
	
}
