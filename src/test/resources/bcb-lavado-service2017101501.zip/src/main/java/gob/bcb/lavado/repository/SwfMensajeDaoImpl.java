package gob.bcb.lavado.repository;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.QL.portiaswift.LoaderQLBeanLocal;
import gob.bcb.lavado.QL.portiaswift.entities.Loader;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.exception.SwiftAdminException;
import gob.bcb.lavado.model.SwfAsignamensaje;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfBicsPK;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.model.SwfTipomensaje;
import gob.bcb.lavado.pojos.Asignacion;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.services.CryptoSwiftService;
import gob.bcb.lavado.services.MailService;
import gob.bcb.lavado.services.SwiftBcbParserService;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

@Repository("swfMensajeDao")
@Transactional
public class SwfMensajeDaoImpl implements SwfMensajeDao {
	private static final Logger log = LoggerFactory.getLogger(SwfMensajeDaoImpl.class);

	@Autowired
	private SwfTipomensajeDao swfTipomensajeDao;
	@Autowired
	private SwfBicsDao swfBicsDao;
	@Autowired
	private SwfPersonaDao swfPersonaDao;
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private SwiftBcbParserService swiftBcbParserService;
	@Autowired
	private CryptoSwiftService cryptoSwiftService;

	@Autowired
	private LoaderQLBeanLocal loaderQLBeanLocal;

	@PersistenceContext(unitName = Constants.PUNIT_LAVADO)
	private EntityManager entityManager;

	@Autowired
	@Qualifier("entityManagerFactory")
	private EntityManagerFactory entityManagerFactory;

	@Transactional(readOnly = true)
	public SwfMensaje findByCodigo(Integer menCodmen) {
		String jpql = "SELECT t FROM SwfMensaje t ";
		jpql = jpql.concat("WHERE t.menCodmen = :menCodmen ");
		Query query = entityManager.createQuery(jpql);
		query.setParameter("menCodmen", menCodmen);

		List lista = query.getResultList();
		if (lista.size() > 0) {
			return (SwfMensaje) lista.get(0);
		}
		return null;
	}

	@Transactional(readOnly = true)
	public SwfMensaje findByHash(String menHash, String menInout) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menHash = :menHash ");
		jpql = jpql.concat("and t.menInout = :menInout ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("menHash", menHash);
		query.setParameter("menInout", menInout);

		List lista = query.getResultList();

		if (lista.size() > 0) {
			return (SwfMensaje) lista.get(0);
		}
		return null;
	}

	@Transactional(readOnly = true)
	public List<SwfMensaje> findByCodOperacion(String menRefer, String menCodapp) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menRefer = :menRefer ");
		jpql = jpql.concat("and t.menCodapp = :menCodapp ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("menRefer", menRefer);
		query.setParameter("menCodapp", menCodapp);

		List<SwfMensaje> lista = query.getResultList();

		return lista;
	}

	@Transactional(readOnly = true)
	public List<SwfMensaje> findObservados(Integer menEstverifica) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menNrolote is null ");
		jpql = jpql.concat("and t.menEstverifica = :menEstverifica ");
		// jpql = jpql.concat("and m.menInout = 'O' ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("menEstverifica", menEstverifica);

		List<SwfMensaje> lista = query.getResultList();

		return lista;
	}

	@Transactional(readOnly = true)
	public List<SwfMensaje> findByEstautoriza(Integer menEstautoriza, Integer menEstmensaje) {
		// registros para autorizar al servidor swift
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menEstautoriza = :menEstautoriza ");
		jpql = jpql.concat("and t.menInout = :menInout ");
		jpql = jpql.concat("and t.menEstmensaje = :menEstmensaje ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("menEstautoriza", menEstautoriza);
		query.setParameter("menInout", Constants.TIPO_MENSAJE_OUT);
		query.setParameter("menEstmensaje", menEstmensaje);

		List<SwfMensaje> lista = query.getResultList();
		log.info("[{} regs.] de Consulta mens. por autorizar est: {}, query: {} ", lista.size(), menEstautoriza, jpql);

		return lista;
	}

	@Transactional(readOnly = true)
	public List<SwfMensaje> findByNroLote(Integer menNrolote) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfMensaje t ");
		jpql = jpql.concat("WHERE t.menNrolote = :menNrolote ");
		jpql = jpql.concat("and t.menInout = :menInout ");
		
		Query query = entityManager.createQuery(jpql);
		query.setParameter("menNrolote", menNrolote);
		query.setParameter("menInout", Constants.TIPO_MENSAJE_IN);
		List lista = query.getResultList();

		return lista;
	}

	@Transactional(readOnly = true)
	public List<MensajesDatos> buscarMensajesEntrantes(SwfMensaje swfMensaje, Integer resCodempasig, Integer resCodemp, Integer resEstrevision, Date conFecinicio,
			Date conFecfin, Integer codEmpleadoFiltro) {
		List<MensajesDatos> mensajesDatosLista = new ArrayList<MensajesDatos>();
		List<SwfMensaje> swfMensajeLista = buscarMensajesEntrantes(swfMensaje, resCodempasig, codEmpleadoFiltro, resEstrevision, conFecinicio, conFecfin);
		Map<String, SwfBics> mapCtrlSwfBics = new HashMap<String, SwfBics>();
		Map<String, SwfTipomensaje> mapCtrlSwfTipomensaje = new HashMap<String, SwfTipomensaje>();

		int countRegs = 0;
		for (SwfMensaje swfMensajeRet : swfMensajeLista) {
			String menBicBranch = swfMensajeRet.getMenBic() + swfMensajeRet.getMenBicbranch();
			// solo para performance buscamos en el mapa
			SwfBics swfBics = mapCtrlSwfBics.get(menBicBranch);
			SwfTipomensaje swfTipomensaje = mapCtrlSwfTipomensaje.get(swfMensajeRet.getMenCodmt());

			MensajesDatos mensajesDatos = mensajeDatosFromSwfMensaje(swfMensajeRet, swfBics, swfTipomensaje, resCodemp, null, true);
			if (!mapCtrlSwfBics.containsKey(menBicBranch)) {
				// si no esta en el mapa lo insertamos
				mapCtrlSwfBics.put(menBicBranch, mensajesDatos.getSwfBics());
			}

			if (swfTipomensaje != null && !mapCtrlSwfTipomensaje.containsKey(swfMensajeRet.getMenCodmt())) {
				// si no esta en el mapa lo insertamos
				mapCtrlSwfTipomensaje.put(swfMensajeRet.getMenCodmt(), swfTipomensaje);
			}
			mensajesDatosLista.add(mensajesDatos);
			if (++countRegs >= Constants.SEARCH_LIMIT_REGS)
				break;
		}
		return mensajesDatosLista;
	}
	@Transactional(readOnly = true)
	public List<SwfMensaje> buscarMensajesEntrantes(SwfMensaje swfMensaje, Integer resCodempasig, Integer resCodemp, Integer resEstrevision, Date conFecinicio,
			Date conFecfin) {

		String jpql = "SELECT m ";
		jpql = jpql.concat("FROM SwfMensaje m ");
		jpql = jpql.concat("WHERE m.menEstmensaje != 9 ");

		if (swfMensaje != null) {
			if (swfMensaje.getMenCodmen() != null && swfMensaje.getMenCodmen().compareTo(0) > 0)
				jpql = jpql.concat("and m.resCodmen = :resCodmen ");

			if (swfMensaje.getMenEstverifica() != null && swfMensaje.getMenEstverifica().compareTo(0) > 0)
				jpql = jpql.concat("and m.menEstverifica = :menEstverifica ");

			if (!StringUtils.isBlank(swfMensaje.getMenEmisor()))
				jpql = jpql.concat("and upper(m.menBic || m.menBicbranch) like :menEmisor ");

			if (!StringUtils.isBlank(swfMensaje.getMenInout()))
				jpql = jpql.concat("and m.menInout = :menInout ");

			if (swfMensaje.getMenEstmensaje() != null)
				jpql = jpql.concat("and m.menEstmensaje = :menEstmensaje ");

		}

		if (conFecinicio != null && conFecfin != null) {
			jpql = jpql.concat("and date(m.menFecreg) between :conFecinicio and :conFecfin ");
		}

		log.info("Consulta de busqueda: resCodemp " + resCodemp + " resEstrevision:" + resEstrevision + " conFecinicio:" + conFecinicio + " conFecfin:"
				+ conFecfin);
		log.info("=>" + jpql);
		Query query = entityManager.createQuery(jpql);

		if (swfMensaje != null) {
			if (swfMensaje.getMenCodmen() != null && swfMensaje.getMenCodmen().compareTo(0) > 0)
				query.setParameter("resCodmen", swfMensaje.getMenCodmen());

			if (swfMensaje.getMenEstverifica() != null && swfMensaje.getMenEstverifica().compareTo(0) > 0)
				query.setParameter("menEstverifica", swfMensaje.getMenEstverifica());

			if (!StringUtils.isBlank(swfMensaje.getMenEmisor()))
				query.setParameter("menEmisor", swfMensaje.getMenEmisor().toUpperCase() + "%");

			if (!StringUtils.isBlank(swfMensaje.getMenInout()))
				query.setParameter("menInout", swfMensaje.getMenInout());

			if (swfMensaje.getMenEstmensaje() != null)
				query.setParameter("menEstmensaje", swfMensaje.getMenEstmensaje());

		}
		if (conFecinicio != null && conFecfin != null) {
			query.setParameter("conFecinicio", conFecinicio, TemporalType.DATE);
			query.setParameter("conFecfin", conFecfin, TemporalType.DATE);
		}

		List<SwfMensaje> swfMensajeLista = query.getResultList();

		log.info("Encontrados " + swfMensajeLista.size() + " regs.");
		return swfMensajeLista;
	}

	@Transactional(readOnly = true)
	public MensajesDatos mensajeDatosFromSwfMensaje(SwfMensaje swfMensaje, SwfBics swfBics, SwfTipomensaje swfTipomensaje, Integer codempleado,
			Integer estRevision, boolean recuperaAsignacion) {
		MensajesDatos mensajesDatos = new MensajesDatos();

		mensajesDatos.setSeleccionado(false);
		mensajesDatos.setSecuencia(0);
		mensajesDatos.setMenCodmen(swfMensaje.getMenCodmen());
		mensajesDatos.setMenCodmt(swfMensaje.getMenCodmt());
		mensajesDatos.setMenEmisor(swfMensaje.getMenEmisor());
		mensajesDatos.setSwfMensaje(swfMensaje);

		if (swfBics == null) {
			swfBics = swfBicsDao.findByBicBranch(swfMensaje.getMenBic(), swfMensaje.getMenBicbranch());
		}

		if (swfBics == null) {
			SwfBicsPK swfBicsPK = new SwfBicsPK();
			swfBicsPK.setBicCodbic(swfMensaje.getMenBic());
			swfBicsPK.setBicCodbranch(swfMensaje.getMenBicbranch());

			swfBics = new SwfBics();
			swfBics.setId(swfBicsPK);
			swfBics.setBicDescrip("NO REGISTRADO: " + swfMensaje.getMenBic() + "" + swfMensaje.getMenBicbranch());
			swfBics.setBicCiudad("");
			swfBics.setBicDirecc1("");
			swfBics.setBicPais("");
			log.debug("ATENCION! BIC SIN REGISTRO en tabla swfBics  " + swfMensaje.getMenEmisor());
		}

		mensajesDatos.setSwfBics(swfBics);

		if (swfTipomensaje == null) {
			swfTipomensaje = swfTipomensajeDao.getByCodigo(swfMensaje.getMenCodmt());
		}

		if (swfTipomensaje != null) {
			mensajesDatos.setMenCodmtdescrip(swfTipomensaje.getTimDescrip());
		} else {
			log.debug("ATENCION! TIPO " + swfMensaje.getMenCodmt() + " NO PARAMETRIZADO");
			mensajesDatos.setMenCodmtdescrip("ATENCION! TIPO " + swfMensaje.getMenCodmt() + " NO PARAMETRIZADO");
		}

		return mensajesDatos;
	}

	private List<Asignacion> recuperarAsignacionesMensaje(MensajesDatos mensajesDatos, Integer menCodmen, Integer codempleado, Integer estRevision) {
		log.debug("obtener lista de Asignaciones recuperarAsignacionesMensaje menCodmen " + menCodmen + " estRevision: " + estRevision
				+ " codempleado " + codempleado);

		List<Asignacion> asignacionLista = new ArrayList<Asignacion>();
		List<SwfAsignamensaje> swfAsignamensajeLista = asignacionesByEmpMasHijos(menCodmen, codempleado, estRevision);

		for (SwfAsignamensaje swfAsignamensaje : swfAsignamensajeLista) {
			// solo se filtra las asignaciones diferentes al usaurio
			// actual
			Asignacion asignacion = recuperarAsignacion(swfAsignamensaje);
			asignacionLista.add(asignacion);
		}
		
		mensajesDatos.setAsignacionLista(asignacionLista);
		
		List<SwfAsignamensaje> swfAsignamensajeDeATerceros = asignacionesDeATerceros(menCodmen, codempleado, estRevision);
		mensajesDatos.setSwfAsignamensajeDeATerceros(swfAsignamensajeDeATerceros);
		
		return asignacionLista;
	}

	private Asignacion recuperarAsignacion(SwfAsignamensaje swfAsignamensaje) {
		Asignacion asignacion = new Asignacion();
		asignacion.setSwfAsignamensaje(swfAsignamensaje);

		SwfPersona swfPersona = swfPersonaDao.findByCodigo(swfAsignamensaje.getId().getResCodemp());
		SwfPersona swfPersonaPadre = swfPersonaDao.findByCodigo(swfAsignamensaje.getResCodemppadre());

		asignacion.setSwfPersona(swfPersona);
		asignacion.setSwfPersonaPadre(swfPersonaPadre);
		return asignacion;
	}

	/**
	 * Asignaciones realizadas por un empleado de un mensaje  
	 */
	public List<SwfAsignamensaje> asignacionesByCodEmpEstRev(Integer resCodmen, Integer resCodemp, Integer estRevision) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfAsignamensaje t ");
		jpql = jpql.concat("WHERE t.id.resCodmen = :resCodmen ");
		jpql = jpql.concat("and t.id.resCodemp != t.resCodemppadre ");

		if (estRevision != null) {
			jpql = jpql.concat("and t.resEstrevision = :estRevision ");
		}
		if (resCodemp != null) {
			jpql = jpql.concat("and t.resCodemppadre = :resCodemp ");
		}

		jpql = jpql.concat("order by t.resCorrasigna ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodmen", resCodmen);

		if (estRevision != null) {
			query.setParameter("estRevision", estRevision);
		}

		if (resCodemp != null) {
			query.setParameter("resCodemp", resCodemp);
		}
		List lista = query.getResultList();
		return lista;
	}

	/**
	 * determina si el mensaje es una asignacion de un tercero
	 */
	public List<SwfAsignamensaje> asignacionesDeATerceros(Integer resCodmen, Integer resCodemp, Integer estRevision) {
		String jpql = "SELECT t ";
		jpql = jpql.concat("FROM SwfAsignamensaje t ");
		jpql = jpql.concat("WHERE t.id.resCodmen = :resCodmen ");
		jpql = jpql.concat("and t.id.resCodemp != t.resCodemppadre ");

		if (estRevision != null) {
			jpql = jpql.concat("and t.resEstrevision = :estRevision ");
		}

		jpql = jpql.concat("and t.id.resCodemp = :resCodemp ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodmen", resCodmen);
		query.setParameter("resCodemp", resCodemp);
		if (estRevision != null) {
			query.setParameter("estRevision", estRevision);
		}

		List lista = query.getResultList();
		return lista;
	}
	
	public List<SwfAsignamensaje> asignacionesByEmpMasHijos(Integer resCodmen, Integer resCodemp, Integer estRevision) {
		log.debug("en asignacionesByEmpMasHijos resCodmen " + resCodmen + " resCodemp: " + resCodemp);
		List<SwfAsignamensaje> swfAsignamensajeListResp = new ArrayList<SwfAsignamensaje>();
		List<SwfAsignamensaje> swfAsignamensajeList = asignacionesByCodEmpEstRev(resCodmen, resCodemp, estRevision);

		if (swfAsignamensajeList.size() > 0) {
			swfAsignamensajeListResp.addAll(swfAsignamensajeList);
		} else {
			return swfAsignamensajeListResp;
		}

		for (SwfAsignamensaje swfAsignamensaje : swfAsignamensajeList) {
			// recursivamente llamamos
			List<SwfAsignamensaje> swfAsignamensajeListHijo = asignacionesByEmpMasHijos(resCodmen, swfAsignamensaje.getId().getResCodemp(), estRevision);
			if (swfAsignamensajeListHijo.size() > 0) {
				swfAsignamensajeListResp.addAll(swfAsignamensajeListHijo);
			}
		}
		return swfAsignamensajeListResp;
	}

	public SwfAsignamensaje swfAsignamensajeCodigo(Integer resCodmen, Integer resCodemp) {
		String jpql = "SELECT t FROM SwfAsignamensaje t ";
		jpql = jpql.concat("WHERE t.id.resCodmen = :resCodmen ");
		jpql = jpql.concat("and t.id.resCodemp = :resCodemp ");

		Query query = entityManager.createQuery(jpql);
		query.setParameter("resCodmen", resCodmen);
		query.setParameter("resCodemp", resCodemp);
		List lista = query.getResultList();

		if (lista.size() > 0) {
			return (SwfAsignamensaje) lista.get(0);
		}
		return null;
	}

	// @Transactional()
	public SwfMensaje registrarNuevo(SwfMensaje swfMensaje) {
		log.debug("Nuevo registro SwfMensaje " + swfMensaje.getMenHash());

		if (swfMensaje.getMenPlano() == null || StringUtils.isEmpty(swfMensaje.getMenPlano()))
			throw new SwiftAdminException("Mensaje " + swfMensaje.getMenHash() + " con parametro swfMensaje.MenPlano invalido");

		String decPlano = cryptoSwiftService.encryptPlain(swfMensaje.getMenPlano());
		if (decPlano == null) {
			log.error("Error en proceso de encriptacion " + swfMensaje.getMenHash() + " con mensaje \n" + swfMensaje.getMenPlano());
			throw new SwiftAdminException(
					"Error en proceso de encriptacion " + swfMensaje.getMenHash() + " en mensaje " + UtilsGeneric.getShortText(swfMensaje.getMenPlano(), 88));
		}

		swfMensaje.setMenPlano(decPlano);

		Integer perCodigo = getCodigo();

		swfMensaje.setMenTabestmensaje(Constants.TAB_ESTMENSAJE);
		swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_REGISTRADO);
		swfMensaje.setMenTabestverifica(Constants.TAB_ESTVERIFICA);
		swfMensaje.setMenEstverifica(Constants.TAB_ESTVERIFICA_REGISTRADO);
		swfMensaje.setMenTabestautoriza(Constants.TAB_ESTAUTORIZA);
		swfMensaje.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_PENDIENTEAUTORIZA);
		swfMensaje.setMenCodmen(perCodigo);
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenGestion(GregorianCalendar.getInstance().get(Calendar.YEAR));
		swfMensaje.setMenAuditfho(new Date());

		List<Block4> block4List = swfMensaje.getBlock4List();
		entityManager.persist(swfMensaje);
		log.info("Creado mensaje swift " + swfMensaje.toString());

		swfMensaje = findByCodigo(swfMensaje.getMenCodmen());
		swfMensaje.setBlock4List(block4List);
		return swfMensaje;
	}

	private SwfMensaje updateReg(SwfMensaje swfMensaje) {
		log.info("Actualizando " + swfMensaje.getMenCodmen());
		String encryptPlano = cryptoSwiftService.encryptPlain(swfMensaje.getMenPlano());
		if (encryptPlano == null) {
			log.error("UPD SWF: Error en proceso de encriptacion " + swfMensaje.getMenHash() + " con mensaje \n" + swfMensaje.getMenPlano());
			throw new SwiftAdminException("UPD SWF: Error en proceso de encriptacion " + swfMensaje.getMenHash() + " en mensaje "
					+ UtilsGeneric.getShortText(swfMensaje.getMenPlano(), 88));
		}
		swfMensaje.setMenPlano(encryptPlano);
		swfMensaje.setMenAuditfho(new Date());
		List<Block4> block4List = swfMensaje.getBlock4List();

		SwfMensaje swfMensajeNew = entityManager.merge(swfMensaje);
		swfMensajeNew.setBlock4List(block4List);
		log.info("Mensaje actualizado " + swfMensajeNew.toString());

		return swfMensajeNew;
	}

	private SwfMensaje updateRegSinEnc(SwfMensaje swfMensaje) {
		log.info("Actualizando updateRegSinEnc " + swfMensaje.getMenCodmen());
		swfMensaje.setMenAuditfho(new Date());
		List<Block4> block4List = swfMensaje.getBlock4List();

		SwfMensaje swfMensajeNew = entityManager.merge(swfMensaje);
		swfMensajeNew.setBlock4List(block4List);
		log.info("Mensaje actualizado " + swfMensajeNew.toString());

		return swfMensajeNew;
	}

	/**
	 * Verifica si el mensaje fue escaneado, registra si el mismo no se
	 * encuentra en base de datos
	 * 
	 * @param swfMensaje
	 * @return retorna {@link SwfMensaje} objeto en base de datos
	 */
	private SwfMensaje verificarEstadoScan(SwfMensaje swfMensajeOld, String menPlano) {

		if (!swfMensajeOld.getMenInout().equals(Constants.TIPO_MENSAJE_OUT)) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con tipo de mensaje " + swfMensajeOld.getMenInout() + " invalido");
		}

		if ((swfMensajeOld.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con estado incorrecto de autorizacion "
					+ swfMensajeOld.getMenEstautoriza() + " no puede continuar");
		}

		if ((swfMensajeOld.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR) == 0)) {
			if ((swfMensajeOld.getMenNrocorr() == null) || swfMensajeOld.getMenNrocorr().compareTo(0) == 0) {
				throw new SwiftAdminException("INCONSISTENCIA: Mensaje " + swfMensajeOld.getMenCodmen() + ", con estado pre autorizado "
						+ swfMensajeOld.getMenEstautoriza() + " y correlativo invalido[correlativo: " + swfMensajeOld.getMenNrocorr()
						+ "] no puede continuar, comunique al administrador");
			}
		}

		if (swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0) {
			// el mensaje fue modificado y continua en estado pasible a
			// escaneo
			// puede ser que las condiciones de busqueda hayan cambiado por
			// lo tanto se escanea nuevamente
			log.info("Mensaje anteriormente registrado " + swfMensajeOld.getMenCodmen() + " se cambia de estado a " + Constants.TAB_ESTVERIFICA_REGISTRADO
					+ " para scaneo");

			return swfMensajeOld;
		} else if (swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_VERIFICADO) == 0) {
			if (swfMensajeOld.getMenHash() != null
					&& swfMensajeOld.getMenHash().equalsIgnoreCase(ArchivoUtil.hashString(ArchivoUtil.decodeFromUri(menPlano)))) {
				return swfMensajeOld;
			}
			log.info("Mensaje scaneado registrado " + swfMensajeOld.getMenCodmen() + " con estado " + swfMensajeOld.getMenEstverifica()
					+ " con diferentes hash " + swfMensajeOld.getMenHash());

			swfMensajeOld.setMenEstverifica(Constants.TAB_ESTVERIFICA_REGISTRADO);
			return swfMensajeOld;
		} else if ((swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0)) {
			// mnesaje registrado anteiormente el operador debe esperar
			// accion del administrador
			log.info("Mensaje registrado anteriormente se debe esperar accion del administrador " + swfMensajeOld.getMenCodmen());
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con estado bloqueado " + swfMensajeOld.getMenEstverifica()
					+ " se espera accion del administrador del sistema. " + swfMensajeOld.getMenRefer());
		} else if ((swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO) == 0)) {
			// el mensaje fue verificado y habilitado
			if (swfMensajeOld.getMenHash() != null
					&& swfMensajeOld.getMenHash().equalsIgnoreCase(ArchivoUtil.hashString(ArchivoUtil.decodeFromUri(menPlano)))) {
				// mensaje reenviado es el mismo al original no se escanea
				log.info("Mensaje registrado [" + swfMensajeOld.getMenCodmen() + "] anteriormente fue verificado y habilitado por administrador "
						+ swfMensajeOld.getMenUsrlvdverifica());

				return swfMensajeOld;
			} else {
				// mensaje reenviado difiere del original se escanea
				log.warn("Atencion!!: Mensaje registrado [" + swfMensajeOld.getMenCodmen() + ", hash: " + swfMensajeOld.getMenHash()
						+ "] anteriormente fue verificado y habilitado por administrador " + swfMensajeOld.getMenUsrlvdverifica()
						+ " pero difiere del original hash nuevo: " + swfMensajeOld.getMenHash());

				swfMensajeOld.setMenEstverifica(Constants.TAB_ESTVERIFICA_REGISTRADO);

				return swfMensajeOld;
			}
		} else if ((swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0)) {
			// mensaje reenviado el mismo fue revisado por el autorizador no
			// debe ser pasible a autorizacion
			log.info("Mensaje Bloqueado " + swfMensajeOld.getMenCodmen() + " por el  administrador [" + swfMensajeOld.getMenUsrlvdverifica()
					+ "] del sistema.");
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con estado bloqueado " + swfMensajeOld.getMenEstverifica()
					+ " consulte con el administrador[" + swfMensajeOld.getMenUsrlvdverifica() + "] del sistema.");
		}

		return swfMensajeOld;
	}

	public SwfMensaje actualizarConPlano(String menPlano, String codapp, Integer menCodmen, Integer nroCorrelativo, String codoperacion, String coduser,
			String estacion, String idsession) {
		log.info("actualizarConPlano codapp {}, menCodmen {}, nroCorrelativo {}, codoperacion {}, coduser {}, estacion {} idsession {}", codapp, menCodmen,
				nroCorrelativo, codoperacion, coduser, estacion, idsession);

		SwfMensaje swfMensajeOld = findByCodigo(menCodmen);
		if (swfMensajeOld == null) {
			log.error("Mensaje inexistente " + menCodmen);
			throw new SwiftAdminException("Mensaje inexistente " + menCodmen);
		}

		if (!swfMensajeOld.getMenCodapp().equalsIgnoreCase(codapp)) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con codigo de aplicacion [" + swfMensajeOld.getMenCodapp()
					+ "] swift diferente al enviado [" + codapp + "] ");
		}

		if ((swfMensajeOld.getMenNrocorr() != null) && nroCorrelativo != null && swfMensajeOld.getMenNrocorr().compareTo(nroCorrelativo) != 0) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con correlativo [" + swfMensajeOld.getMenNrocorr()
					+ "] swift diferente al enviado [" + nroCorrelativo + "] ");
		}

		log.info("Act Con PLANO: Mensaje con estado de correlativo solicitado  " + menCodmen);
		if ((swfMensajeOld.getMenNrocorr() == null) || swfMensajeOld.getMenNrocorr().compareTo(0) == 0) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", sin correlativo");
		}
		if (swfMensajeOld.getMenNrocorr().compareTo(nroCorrelativo) != 0) {
			throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con correlativo [" + swfMensajeOld.getMenNrocorr()
					+ "] swift diferente al enviado [" + nroCorrelativo + "] ");
		}
		if (menPlano != null){
			log.info("===== RJE =====");			
			log.info(ArchivoUtil.decodeFromUri(menPlano));
			log.info("===== === =====");			
		}
		verificarEstadoScan(swfMensajeOld, menPlano);
		SwiftDatos swiftDatos = swiftBcbParserService.actualizarSwfMensajeFromPlano(swfMensajeOld, menPlano);

		swfMensajeOld.setMenRefer(codoperacion);
		swfMensajeOld.setMenAuditusr(coduser);
		swfMensajeOld.setMenAuditwst(estacion);
		swfMensajeOld.setMenFirmaorigen(idsession);

		swfMensajeOld.setMenEstmensaje(Constants.TAB_ESTMENSAJE_REGISTRADO);
		if (!StringUtils.isBlank(swfMensajeOld.getMenFirmaorigen())) {
			// si existe session se marca con estado en proceso
			swfMensajeOld.setMenEstmensaje(Constants.TAB_ESTMENSAJE_EN_PROCESO);
		}		
		swiftDatos.getSwfMensaje().setBlock4List(swiftBcbParserService.createListBlock4(swiftDatos.getSwiftMessageBcb(), false));

		return updateReg(swfMensajeOld);
	}

	synchronized private Integer getCodigo() {
		log.info("solicitando codigo...");
		Integer codigo = null;
		StringBuilder query = new StringBuilder();
		query.append("select max(m.menCodmen) from SwfMensaje m ");

		List result = entityManager.createQuery(query.toString()).getResultList();
		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.debug("Nuevo codigo : " + codigo);
		return codigo;

	}

	public void verificaEstado(SwfMensaje swfMensaje) {
		log.info("verificando estado mensaje " + swfMensaje.getMenCodmen());
		if (swfMensaje.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_ELIMINADO) == 0) {
			throw new SwiftAdminException("Mensaje con estado " + swfMensaje.getMenEstmensaje() + ", no puede continuar.");
		}

		if (swfMensaje.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_PROCESADO) == 0) {
			throw new SwiftAdminException("Mensaje con estado " + swfMensaje.getMenEstmensaje() + ", no puede continuar.");
		}
	}

	public SwfMensaje cambiarEstadoAsignacion(SwfMensaje swfMensaje, Integer nuevoEstado) {
		SwfMensaje swfMensajeOld = findByCodigo(swfMensaje.getMenCodmen());
		if (swfMensajeOld == null) {
			throw new SwiftAdminException("Mensaje " + swfMensaje.getMenCodmen() + ", inexistente. ");
		}

		Integer estadoMenasignacionOld = swfMensajeOld.getMenEstmensaje();

		log.info("MENSAJE: cambio de estado " + swfMensajeOld.getMenCodmen() + " de:" + estadoMenasignacionOld + " => " + nuevoEstado);
		if (estadoMenasignacionOld.compareTo(Constants.TAB_ESTMENSAJE_ELIMINADO) == 0) {
			throw new SwiftAdminException("Mensaje con estado " + swfMensajeOld.getMenEstmensaje() + ", no puede continuar.");
		}

		if (estadoMenasignacionOld.compareTo(Constants.TAB_ESTMENSAJE_REGISTRADO) == 0 && nuevoEstado.compareTo(Constants.TAB_ESTMENSAJE_ASIGNADO) == 0) {
			// si el estado es de 1 a tres se genera un correlativo
			if (swfMensajeOld.getMenNrocorr() == null) {
				Integer corr = getCorrelativoAsignacion(swfMensajeOld.getMenGestion(), null, Constants.TIPO_MENSAJE_IN);
				swfMensajeOld.setMenNrocorr(corr);
			}
		}
		swfMensajeOld.setMenEstmensaje(nuevoEstado);
		swfMensajeOld.setMenAuditusr(swfMensaje.getMenAuditusr());
		swfMensajeOld.setMenAuditwst(swfMensaje.getMenAuditwst());

		return updateRegSinEnc(swfMensajeOld);
	}

	/**
	 * Proceso para cambiar el estado de la verificacion de un mensaje por parte del administrador de lavado 
	 */
	public SwfMensaje cambiarEstadoVerificacion(Integer codMen, String codUsuario, Integer newEstado, String estacion) {
		log.info("cambiarEstadoVerificacion codMen {},  codUsuario {}, newEstado {}, estacion {}", codMen, codUsuario, newEstado, estacion);
		SwfMensaje swfMensaje = findByCodigo(codMen);
		if (swfMensaje == null) {
			throw new SwiftAdminException("Mensaje " + codMen + ", inexistente. ");
		}

		// control de estados no permitidos de estado de autorizacion
		if ((swfMensaje.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)) {
			throw new SwiftAdminException(
					"Mensaje " + swfMensaje.getMenCodmen() + ", con estado incorrecto de autorizacion " + swfMensaje.getMenEstautoriza());
		}
		
		Integer menEstverificaOld = swfMensaje.getMenEstverifica();
		swfMensaje.setMenEstverifica(newEstado);
		swfMensaje.setMenUsrlvdverifica(codUsuario);
		swfMensaje.setMenAuditusr(codUsuario);
		swfMensaje.setMenAuditwst(estacion);

		log.info("MENSAJE: cambio de estado verificacion " + swfMensaje.getMenCodmen() + " de " + menEstverificaOld + "   => " + newEstado);
		return updateRegSinEnc(swfMensaje);
	}

	public SwfMensaje cambiarEstadoPostScan(Integer codMen, Integer countRegs, String accionScan) {
		log.info("inicio cambiarEstadoPostScan cod:{} regs:{} accion: {}", codMen, countRegs, accionScan);
		SwfMensaje swfMensajeNew = findByCodigo(codMen);
		if (swfMensajeNew == null) {
			throw new SwiftAdminException("Post scan: Mensaje " + codMen + ", inexistente. ");
		}

		if ((swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)
				|| (swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_RECHAZADOPORADMINSWFT) == 0)) {
			throw new SwiftAdminException("PostScan: Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de autorizacion "
					+ swfMensajeNew.getMenEstautoriza() + " no puede continuar");
		}

		if ((swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0)
				|| (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0)) {
			throw new SwiftAdminException("PostScan: Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de scaneo "
					+ swfMensajeNew.getMenEstverifica() + " no puede continuar");
		}

		// cambiamos el estado segun el resultado del scan
		if (countRegs.compareTo(0) == 0) {
			// el mensaje no tiene observaciones
			if (swfMensajeNew.getMenInout().equals(Constants.TIPO_MENSAJE_OUT)
					&& (swfMensajeNew.getMenNrocorr() == null || swfMensajeNew.getMenNrocorr().compareTo(0) == 0)) {
				// en mensajes de salida se genera el correlativo
				// Integer corr = getCorrelativo(swfMensajeNew.getMenGestion(),
				// null, swfMensajeNew.getMenInout());
				Integer corr = getCorrelativoPortia(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditwst(), swfMensajeNew.getMenAuditusr());
				log.info("Nuevo correlativo[" + swfMensajeNew.getMenCodmen() + " - " + swfMensajeNew.getMenHash() + "] : " + corr);

				swfMensajeNew.setMenNrocorr(corr);
			}
			swfMensajeNew.setMenEstverifica(Constants.TAB_ESTVERIFICA_VERIFICADO);
			swfMensajeNew = updateRegSinEnc(swfMensajeNew);
			log.info("PostScan: Mensaje verificado sin observacion [" + swfMensajeNew.getMenCodmen() + "] con estado " + swfMensajeNew.getMenEstverifica()
					+ " Nrocorr:" + swfMensajeNew.getMenNrocorr());
		} else {
			if (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0) {
				if (accionScan == null) {
					SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_ACCIONSCAN);
					accionScan = swfParams.getParValor();
				}
				if (accionScan.trim().equalsIgnoreCase(Constants.PARAM_ACCIONSCAN_BLQ) && swfMensajeNew.getMenInout().equals(Constants.TIPO_MENSAJE_OUT)) {
					// solo los mensajes de salida se bloquean
					swfMensajeNew.setMenEstverifica(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ);
					log.info("PostScan: Mensaje bloqueado [" + swfMensajeNew.getMenCodmen() + "] scaneado con estado " + swfMensajeNew.getMenEstverifica());
				} else {
					// no se bloquea el mensaje y el estado se cambia a falso
					// positivo
					if (swfMensajeNew.getMenInout().equals(Constants.TIPO_MENSAJE_OUT)
							&& (swfMensajeNew.getMenNrocorr() == null || swfMensajeNew.getMenNrocorr().compareTo(0) == 0)) {
						// en mensajes de salida se genera el correlativo
						// Integer corr =
						// getCorrelativo(swfMensajeNew.getMenGestion(), null,
						// swfMensajeNew.getMenInout());
						Integer corr = getCorrelativoPortia(swfMensajeNew.getMenCodapp(), swfMensajeNew.getMenAuditwst(), swfMensajeNew.getMenAuditusr());
						log.info("Nuevo correlativo[" + swfMensajeNew.getMenCodmen() + " - " + swfMensajeNew.getMenHash() + "] : " + corr);

						swfMensajeNew.setMenNrocorr(corr);
					}
					log.warn("AVISO!!! Mensaje [" + swfMensajeNew.getMenCodmen() + "] marcado como falso positivo por el sistema " + Constants.TAB_ESTVERIFICA_FALSO_POSITIVO );
					swfMensajeNew.setMenEstverifica(Constants.TAB_ESTVERIFICA_FALSO_POSITIVO);
				}
				swfMensajeNew = updateRegSinEnc(swfMensajeNew);
			}
		}

		log.info("PostScan: MENSAJE cambio de estado SCAN " + swfMensajeNew.getMenCodmen() + " nuevo estado=> " + swfMensajeNew.getMenEstverifica());
		return swfMensajeNew;
	}

	public SwfMensaje cambiarEstadoAutorizacion(Integer codMen, String codUsuario, Integer newEstado, String estacion) {
		log.info("cambiarEstadoAutorizacion codMen {},  codUsuario {}, newEstado {}, estacion {}", codMen, codUsuario, newEstado, estacion);
		SwfMensaje swfMensaje = findByCodigo(codMen);
		if (swfMensaje == null) {
			throw new SwiftAdminException("Mensaje " + codMen + ", inexistente. ");
		}

		// control de estados no permitidos de estado de autorizacion
		if ((swfMensaje.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)) {
			throw new SwiftAdminException(
					"Mensaje " + swfMensaje.getMenCodmen() + ", con estado incorrecto de autorizacion " + swfMensaje.getMenEstautoriza());
		}
		
		Integer menEstverificaOld = swfMensaje.getMenEstverifica();
		swfMensaje.setMenEstautoriza(newEstado);
		swfMensaje.setMenAuditusr(codUsuario);
		swfMensaje.setMenAuditwst(estacion);

		log.info("MENSAJE: cambio de estado autorizacion " + swfMensaje.getMenCodmen() + " de " + menEstverificaOld + "   => " + newEstado);
		return updateReg(swfMensaje);
	}	
	@Transactional()
	public SwfMensaje guardarEnImportados(Integer codMen, String codUsuario, String pathDirSwift, String estacion) {
		log.info("Inicio Salvado en IMPORTADOS " + codMen + " por: " + codUsuario);
		SwfMensaje swfMensajeNew = findByCodigo(codMen);
		if (swfMensajeNew == null) {
			throw new SwiftAdminException("guardarEnImportados: Mensaje " + codMen + ", inexistente. ");
		}

		if ((swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR) != 0)) {
			throw new SwiftAdminException("Mensaje " + codMen + ", con estado incorrecto de estado de pre autorizacion " + swfMensajeNew.getMenEstautoriza()
					+ " el mismo debe ser " + Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR + " para continuar");
		}

		swfMensajeNew.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT);
		//swfMensajeNew.setMenUsrlvdverifica(codUsuario);
		swfMensajeNew.setMenAuditusr(codUsuario);
		swfMensajeNew.setMenAuditwst(estacion);

		SwfMensaje swfMensaje = updateRegSinEnc(swfMensajeNew);

		String planoDecrypt = cryptoSwiftService.decryptPlain(swfMensaje.getMenPlano());
		String pathDirSwiftDec = pathDirSwift + "/" + nombreArchivo(swfMensaje);
		String pathDirSwiftEnc = pathDirSwift + "_Back/" + nombreArchivo(swfMensaje);		
		// guardamos fisicamente en el directorio swift

		String p = UtilsFile.grabaEnArchivo(planoDecrypt, pathDirSwiftDec);
		log.info("Mensaje salvado en IMPORTADOS " + codMen + " por: " + codUsuario + " en: " + p);
		String p_back = UtilsFile.grabaEnArchivo(swfMensaje.getMenPlano(), pathDirSwiftEnc);
		log.info("Mensaje BACKUP salvado en " + codMen + " por: " + codUsuario + " en: " + p_back);
		return swfMensaje;
	}

	private String nombreArchivo(SwfMensaje swfMensaje) {
		String nameFile = StringUtils.trim(swfMensaje.getMenCodapp() + swfMensaje.getMenGestion()) + "_" + swfMensaje.getMenCodmen() + "_"
				+ StringUtils.trim(swfMensaje.getMenRefer()) + "_" + String.format("%06d", swfMensaje.getMenNrocorr()) + swfMensaje.getMenCodusrswf()
				+ ".dos";
		return nameFile;
	}

	public SwfMensaje preAutorizaSwift(Integer menCodmen, String codapp, String coduser, String codoperacion, String idsession, String menPlano,
			String estacion) {
		log.info("Pre autorizacion menCodmen: {}, codapp: {}, coduser: {}, codoperacion: {}, idsession: {}, menPlano: {}, estacion: {}", menCodmen, codapp,
				coduser, codoperacion, idsession, menPlano, estacion);
		
		SwfMensaje swfMensajeNew = findByCodigo(menCodmen);
		if (swfMensajeNew == null){
			throw new SwiftAdminException("Mensaje " + menCodmen + " inexistente");			
		}
		if (StringUtils.isBlank(swfMensajeNew.getMenCodapp()) || !swfMensajeNew.getMenCodapp().equals(codapp) || StringUtils.isBlank(swfMensajeNew.getMenRefer()) || !swfMensajeNew.getMenRefer().equals(codoperacion)){
			throw new SwiftAdminException("La información no corresponde al registrado para Mensaje: " + menCodmen);			
		}
		
		// control de estados no permitidos de estado de autorizacion
		if ((swfMensajeNew.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0)) {
			log.error("Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de estado de autorizacion " + swfMensajeNew.getMenEstautoriza());
			throw new SwiftAdminException(
					"Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de estado de autorizacion " + swfMensajeNew.getMenEstautoriza());
		}

		if (swfMensajeNew.getMenNrocorr() == null || swfMensajeNew.getMenNrocorr().compareTo(0) == 0) {
			log.error("Error al aprobar mensaje " + swfMensajeNew.getMenCodmen() + " sin nro correlativo");
			throw new SwiftAdminException("Error al aprobar mensaje " + swfMensajeNew.getMenCodmen() + " sin nro correlativo");
		}

		if ((swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_EN_VERIFICACION_BLQ) == 0)
				|| (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0)
				|| (swfMensajeNew.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_REGISTRADO) == 0)) {
			throw new SwiftAdminException("Autorizacion: Mensaje " + swfMensajeNew.getMenCodmen() + ", con estado incorrecto de scaneo "
					+ swfMensajeNew.getMenEstverifica() + " no puede continuar");
		}

		swfMensajeNew.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR);
		swfMensajeNew.setMenAuditusr(coduser);
		swfMensajeNew.setMenAuditwst(estacion);
		swfMensajeNew.setMenFirmaorigen(idsession);
		swfMensajeNew.setMenEstmensaje(Constants.TAB_ESTMENSAJE_PROCESADO);
		if (!StringUtils.isBlank(swfMensajeNew.getMenFirmaorigen())) {
			// si existe session se marca con estado en proceso
			swfMensajeNew.setMenEstmensaje(Constants.TAB_ESTMENSAJE_EN_PROCESO);
		}		

		SwfMensaje swfMensajeupd = updateRegSinEnc(swfMensajeNew);
		log.info("SWIFT PRE autorizado... " + swfMensajeupd.getMenCodmen() + " hash:" + swfMensajeupd.getMenHash());
		return swfMensajeupd;
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public Integer cerrarTransaccion(String idsession) {
		log.info("=== CERRANDO SESSION ===== " + idsession);
		if (StringUtils.isBlank(idsession)) {
			return 0;
		}
		String jpqlQL = "update SwfMensaje t ";
		jpqlQL = jpqlQL.concat("set t.menEstmensaje = :menEstmensajeupd, ");
		jpqlQL = jpqlQL.concat("t.menFirmaorigen = :menFirmaorigenupd ");
		jpqlQL = jpqlQL.concat("WHERE t.menFirmaorigen = :menFirmaorigen ");
		jpqlQL = jpqlQL.concat("and t.menInout = :menInout ");
		//jpqlQL = jpqlQL.concat("and t.menEstmensaje = :menEstmensaje ");

		Query query = entityManager.createQuery(jpqlQL);
		query.setParameter("menFirmaorigenupd", idsession + "+");
		query.setParameter("menEstmensajeupd", Constants.TAB_ESTMENSAJE_PROCESADO);

		query.setParameter("menFirmaorigen", idsession);
		query.setParameter("menInout", Constants.TIPO_MENSAJE_OUT);
		//query.setParameter("menEstmensaje", Constants.TAB_ESTMENSAJE_EN_PROCESO);

		Integer result = query.executeUpdate();
		log.info("cerrarTransaccion idsession {} regs: {} ", idsession, result);
		return result;
	}

	/**
	 * Genera el correlativo del mensaje
	 * 
	 * @param menGestion
	 * @param estMensaje
	 * @param menInout
	 * @return
	 */
	private Integer getCorrelativoAsignacion(Integer menGestion, Integer estMensaje, String menInout) {
		Integer codigo = null;
		StringBuilder jpql = new StringBuilder();
		jpql.append("select max(m.menNrocorr) ");
		jpql.append("from SwfMensaje m ");
		jpql.append("where m.menGestion = :menGestion ");
		jpql.append("and m.menInout = :menInout ");

		Query query = entityManager.createQuery(jpql.toString());

		query.setParameter("menGestion", menGestion);
		query.setParameter("menInout", menInout);

		List result = query.getResultList();
		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.info("Nuevo correlativo[" + menInout + "] : " + codigo);
		return codigo;
	}

	synchronized private Integer getCorrelativoPortia(String idSistema, String auditWst, String auditUsr) {
		Loader loader = loaderQLBeanLocal.nuevoCodSwift(idSistema, auditWst, auditUsr);
		return loader.getNumeroSwift();
	}

	synchronized public SwfMensaje solicitarCorrelativo(String codapp, String codUsuario, String codoperacion, String estacion, String idSession) {
		log.info("Inicio solicitar correlativo codapp {}, codUsuario {}, codoperacion {}, estacion {}, idSession {}", codapp, codUsuario, codoperacion,
				estacion, idSession);

		if (StringUtils.isBlank(codapp)) {
			log.error("Valor codigo de aplicacion invalido ");
			throw new SwiftAdminException("Valor codigo de aplicacion invalido ");
		}
		SwfMensaje swfMensaje = null;
		if (!StringUtils.isBlank(codoperacion)) {
			List<SwfMensaje> swfMensajeLista = findByCodOperacion(codoperacion, codapp);

			for (SwfMensaje swfMensajeOld : swfMensajeLista) {
				// si ya fue registrado se verifica si sus estados
				if (swfMensajeOld.getMenEstautoriza().compareTo(Constants.TAB_ESTAUTORIZA_AUTORIZPORADMINSWFT) == 0) {
					log.error("Mensaje " + swfMensajeOld.getMenCodmen() + ", con codigo operacion [" + codoperacion + "] autorizado "
							+ swfMensajeOld.getMenEstautoriza() + " correlativo " + swfMensajeOld.getMenNrocorr());
					throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + ", con codigo operacion [" + codoperacion + "] autorizado "
							+ swfMensajeOld.getMenEstautoriza() + " correlativo " + swfMensajeOld.getMenNrocorr());
				}

				if ((swfMensajeOld.getMenEstverifica().compareTo(Constants.TAB_ESTVERIFICA_POSITIVO_BLQ) == 0)) {
					// bloqueado por administrador lavado
					log.info("Mensaje " + swfMensajeOld.getMenCodmen() + " con codigo operacion [" + codoperacion + "] bloqueado "
							+ swfMensajeOld.getMenEstverifica() + " consulte con el administrador [" + swfMensajeOld.getMenUsrlvdverifica()
							+ "] del sistema.");
					throw new SwiftAdminException("Mensaje " + swfMensajeOld.getMenCodmen() + " con codigo operacion [" + codoperacion + "] bloqueado consulte con el administrador[usuario: " + swfMensajeOld.getMenUsrlvdverifica()
							+ "] del sistema.");
				}

				if (swfMensajeOld.getMenNrocorr() != null && swfMensajeOld.getMenNrocorr().compareTo(0) >= 0)
					if ((swfMensajeOld.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_REGISTRADO) == 0)
							|| (swfMensajeOld.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_EN_PROCESO) == 0)
							|| (swfMensajeOld.getMenEstmensaje().compareTo(Constants.TAB_ESTMENSAJE_PROCESADO) == 0)) {
						log.info("CORRELATIVO: Mensaje registrado " + swfMensajeOld.toString());
						swfMensaje = swfMensajeOld;
					}
			}
		}
		if (swfMensaje == null) {
			swfMensaje = new SwfMensaje();
			log.info("CORRELATIVO: registrar: mensaje inexistente Codapp: " + codapp + " codoperacion: " + codoperacion);
			Integer perCodigo = getCodigo();
			swfMensaje.setMenCodmen(perCodigo);
			// obtener el correlativo portia
			Integer corrNroswift = getCorrelativoPortia(codapp, estacion, codUsuario);

			swfMensaje.setMenNrocorr(corrNroswift);
			swfMensaje.setMenCodapp(codapp);
			swfMensaje.setMenRefer(codoperacion);
			swfMensaje.setMenCodusrswf(codUsuario);
			swfMensaje.setMenFirmaorigen(idSession);
			swfMensaje.setMenInout(Constants.TIPO_MENSAJE_OUT);
			swfMensaje.setMenGestion(GregorianCalendar.getInstance().get(Calendar.YEAR));
			swfMensaje.setMenTabestmensaje(Constants.TAB_ESTMENSAJE);
			swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_REGISTRADO);
			if (!StringUtils.isBlank(swfMensaje.getMenFirmaorigen())) {
				// si existe session se marca con estado en proceso
				swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_EN_PROCESO);
			}			
			swfMensaje.setMenTabestverifica(Constants.TAB_ESTVERIFICA);
			swfMensaje.setMenEstverifica(Constants.TAB_ESTVERIFICA_REGISTRADO);
			swfMensaje.setMenTabestautoriza(Constants.TAB_ESTAUTORIZA);
			swfMensaje.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR);
			swfMensaje.setMenAuditusr(codUsuario);
			swfMensaje.setMenAuditfho(new Date());
			swfMensaje.setMenAuditwst(estacion);
			swfMensaje.setMenFecreg(new Date());
			entityManager.persist(swfMensaje);
		} else {
			log.info("CORRELATIVO: actualizar: mensaje existente Codapp: " + codapp + " codoperacion: " + codoperacion);
			swfMensaje.setMenCodusrswf(codUsuario);
			swfMensaje.setMenFirmaorigen(idSession);
			swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_REGISTRADO);
			if (!StringUtils.isBlank(swfMensaje.getMenFirmaorigen())) {
				// si existe session se marca con estado en proceso
				swfMensaje.setMenEstmensaje(Constants.TAB_ESTMENSAJE_EN_PROCESO);
			}
			swfMensaje.setMenEstautoriza(Constants.TAB_ESTAUTORIZA_PROVISIONALCONNROCORR);

			swfMensaje.setMenAuditusr(codUsuario);
			swfMensaje.setMenAuditfho(new Date());
			swfMensaje.setMenAuditwst(estacion);
			entityManager.merge(swfMensaje);
		}

		log.info("CORRELATIVO: Creado mensaje swift registrado:{} ", swfMensaje.toString());
		swfMensaje = findByCodigo(swfMensaje.getMenCodmen());
		return swfMensaje;
	}

}
