package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Norms;


/**
 * The persistent class for the ofa_vesselinfo database table.
 * 
 */
@Entity
//@Indexed
@Table(name="ofa_vesselinfo")
@NamedQuery(name="OfaVesselinfo.findAll", query="SELECT o FROM OfaVesselinfo o")
public class OfaVesselinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ves_entryuid")
	private Integer vesEntryuid;

	@Field
	@Column(name="ves_callsign")
	private String vesCallsign;

	@Field(analyze = Analyze.NO, norms = Norms.NO, index=Index.NO)
	@Column(name="ves_grossregistere")
	private String vesGrossregistere;

	@Field(analyze = Analyze.NO, norms = Norms.NO, index=Index.NO)
	@Column(name="ves_tonnage")
	private String vesTonnage;

	@Field
	@Column(name="ves_vesselflag")
	private String vesVesselflag;

	@Field
	@Column(name="ves_vesselowner")
	private String vesVesselowner;

	@Field
	@Column(name="ves_vesseltype")
	private String vesVesseltype;

	@ContainedIn
	////@IndexedEmbedded
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ves_entryuid", nullable = false, insertable = false, updatable = false, referencedColumnName = "sdn_entryuid")
	private OfaSdnentry ofaSdnentry;
	
	public OfaVesselinfo() {
	}

	public Integer getVesEntryuid() {
		return this.vesEntryuid;
	}

	public void setVesEntryuid(Integer vesEntryuid) {
		this.vesEntryuid = vesEntryuid;
	}

	public String getVesCallsign() {
		return this.vesCallsign;
	}

	public void setVesCallsign(String vesCallsign) {
		this.vesCallsign = vesCallsign;
	}

	public String getVesGrossregistere() {
		return this.vesGrossregistere;
	}

	public void setVesGrossregistere(String vesGrossregistere) {
		this.vesGrossregistere = vesGrossregistere;
	}

	public String getVesTonnage() {
		return this.vesTonnage;
	}

	public void setVesTonnage(String vesTonnage) {
		this.vesTonnage = vesTonnage;
	}

	public String getVesVesselflag() {
		return this.vesVesselflag;
	}

	public void setVesVesselflag(String vesVesselflag) {
		this.vesVesselflag = vesVesselflag;
	}

	public String getVesVesselowner() {
		return this.vesVesselowner;
	}

	public void setVesVesselowner(String vesVesselowner) {
		this.vesVesselowner = vesVesselowner;
	}

	public String getVesVesseltype() {
		return this.vesVesseltype;
	}

	public void setVesVesseltype(String vesVesseltype) {
		this.vesVesseltype = vesVesseltype;
	}

	public OfaSdnentry getOfaSdnentry() {
		return ofaSdnentry;
	}

	public void setOfaSdnentry(OfaSdnentry ofaSdnentry) {
		this.ofaSdnentry = ofaSdnentry;
	}

}
