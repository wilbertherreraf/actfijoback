package gob.bcb.lavado.services;

import java.util.List;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.rest.dto.SearchResponse;
import gob.bcb.lavado.search.indexer.JPASearchFactoryControllerImpl;
import gob.bcb.swift.pojos.SwiftDatos;

public interface SwiftBcbSearcherService {

	/**
	 * Scanea un mensaje plano no registra en base de datos 
	 * @param menPlano texto plano en formato swift
	 * @return {@link SearchResponse} 
	 */
	SearchResponse searchScanSingle(String menPlano);

	/**
	 * Busca una consulta segun una estrategia 
	 * @param query consulta 
	 * @param field codigo de estrategia si es nulo sera el por defecto
	 * @return {@link SearchResponse}
	 */
	SearchResponse verificarMensaje(String query, String field);

	/**
	 * Scanea un lote de mensajes entrantes, registra en la base de datos si el scan es positivo envia un correo, no realiza bloqueo
	 * @param menNrolote
	 */
	void scanLoteAsync(Integer menNrolote);

	List<?> searchForQueryInSwfBics(String query, String idEstrategia);

	SwiftDatos mensajePlanoToSwfMensaje(String menPlano, boolean requireDescrip);

	SearchResponse scanMensajePlanoConCorrSolicitado(String menPlano, String codapp, Integer menCodmen, Integer nroCorrelativo, String codoperacion,
			String coduser, String estacion, String idsession);

	SearchResponse preAutorizaSwift(Integer codlvd, String codapp, String coduser, String codoperacion, String idSession, String menPlano, String estacion);

	SearchResponse beginSession(String codapp, String coduser, String estacion);

	SearchResponse solicitarCorrelativo(String codapp, String codoperacion, String coduser, String idsession, String estacion);

	SearchResponse endSession(String codapp, String idsession, String coduser, String estacion);

	String searchForQueryInSwfMensaje(String query, SwfMensaje swfMensaje, String idEstrategia, JPASearchFactoryControllerImpl jPASearchFactoryController)
			throws Exception;

}