package gob.bcb.lavado.services;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import gob.bcb.lavado.commons.Constants;

@Service
public class SessionsSearcherService {
	private static final Logger log = LoggerFactory.getLogger(SessionsSearcherService.class);
	private LoadingCache<String, String> sessionsCache;	
	
	@PostConstruct
	public void init() {
		initCache(Constants.SEC_TIME_LIFE_FOR_SESSIONS_REST,TimeUnit.MINUTES);
	}
	
	public void initCache(Integer timeSessionLive, TimeUnit timeUnit) {
		if (sessionsCache != null){
			sessionsCache.invalidateAll();
		}
		
		sessionsCache = CacheBuilder.newBuilder().maximumSize(350).expireAfterWrite(timeSessionLive, timeUnit).build(new CacheLoader<String, String>() {
			@Override
			public String load(final String key) {
				return "";
			}
		});

		log.info("Session cache creado con {} segs de vida", timeSessionLive);
	}
	
	public void createSession(String idsession, String valorCache){
		sessionsCache.put(idsession, valorCache);
		log.info("Session creada {} con valor {} size {}", idsession, valorCache,sessionsCache.size());
	}
	public void closeSession(String idsession){
		sessionsCache.invalidate(idsession);
		log.info("Session cerrada {} size {}", idsession,sessionsCache.size());
	}
	public void revalidateSession(String idsession, String valorSession){
		String valorSessionOld = null;
		try {
			valorSessionOld = sessionsCache.get(idsession);
		} catch (final ExecutionException e) {
			valorSessionOld = null;
		}
		sessionsCache.put(idsession, valorSession);
		log.info("Session revalidada {} para {},  size {}", idsession, valorSession,sessionsCache.size());
	}	
	public void validateSession(String idsession, String valorCache){
		log.info("validateSession {} para valorCache {} " , idsession, valorCache);		
		if (StringUtils.isBlank(idsession)){
			throw new RuntimeException("Codigo de sesión nulo");
		}
		String valorSession = null;
		try {
			valorSession = sessionsCache.get(idsession);
		} catch (final ExecutionException e) {
			valorSession = null;
		}
		if (StringUtils.isBlank(valorSession)){
			sessionsCache.invalidate(idsession);
			throw new RuntimeException("Codigo de sesión " + idsession + " inválido o no fue registrado anteriormente");
		}
		if (!valorSession.equals(valorCache)){
			throw new RuntimeException("Codigo de sesión " +valorSession+" no corresponde a la aplicación " + valorCache);
		}	
	}
}
