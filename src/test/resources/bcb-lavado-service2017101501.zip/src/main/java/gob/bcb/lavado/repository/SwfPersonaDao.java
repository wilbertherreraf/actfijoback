package gob.bcb.lavado.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import gob.bcb.lavado.model.SwfPersona;

public interface SwfPersonaDao {

	SwfPersona findByCodigo(Integer perCodemp);

	SwfPersona saveorupdate(SwfPersona swfPersona);

	void remove(SwfPersona swfPersona);

	List<SwfPersona> empleadosAsignados(Integer resCodemp, Integer estRevision, Integer menGestion);

	List<SwfPersona> getAll();

	List<SwfPersona> empleadosCreadosEnLvd();

	SwfPersona findOrCreateSwfPersonaFromRRHH(Integer codEmpleado, String email, String login, String estacion);

}
