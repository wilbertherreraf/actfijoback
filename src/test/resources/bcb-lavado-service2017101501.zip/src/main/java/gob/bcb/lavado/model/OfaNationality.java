package gob.bcb.lavado.model;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;


/**
 * The persistent class for the ofa_nationality database table.
 * 
 */
@Entity
//@Indexed
@Table(name="ofa_nationality")
@NamedQuery(name="OfaNationality.findAll", query="SELECT o FROM OfaNationality o")
public class OfaNationality implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="nat_uid")
	private Integer natUid;

	@Field
	@Column(name="nat_country")
	private String natCountry;

	@Field
	@Column(name="nat_entryuid")
	private Integer natEntryuid;

	@Field
	@Column(name="nat_mainentry")
	private String natMainentry;

	@ContainedIn
	////@IndexedEmbedded
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "nat_entryuid", nullable = false, insertable = false, updatable = false, referencedColumnName = "sdn_entryuid")
	private OfaSdnentry ofaSdnentry;
	
	public OfaNationality() {
	}

	public Integer getNatUid() {
		return this.natUid;
	}

	public void setNatUid(Integer natUid) {
		this.natUid = natUid;
	}

	public String getNatCountry() {
		return this.natCountry;
	}

	public void setNatCountry(String natCountry) {
		this.natCountry = natCountry;
	}

	public Integer getNatEntryuid() {
		return this.natEntryuid;
	}

	public void setNatEntryuid(Integer natEntryuid) {
		this.natEntryuid = natEntryuid;
	}

	public String getNatMainentry() {
		return this.natMainentry;
	}

	public void setNatMainentry(String natMainentry) {
		this.natMainentry = natMainentry;
	}

	public OfaSdnentry getOfaSdnentry() {
		return ofaSdnentry;
	}

	public void setOfaSdnentry(OfaSdnentry ofaSdnentry) {
		this.ofaSdnentry = ofaSdnentry;
	}

}
