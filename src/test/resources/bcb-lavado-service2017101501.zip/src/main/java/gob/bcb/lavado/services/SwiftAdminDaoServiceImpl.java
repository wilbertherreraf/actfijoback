package gob.bcb.lavado.services;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.lavado.QL.rrhh.PlafinQLBean;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.config.LavadoProperties;
import gob.bcb.lavado.exception.DataException;
import gob.bcb.lavado.model.OfaBlacklist;
import gob.bcb.lavado.model.OfaBlanklist;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfLote;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.model.SwfParams;
import gob.bcb.lavado.model.SwfPersona;
import gob.bcb.lavado.pojos.Empleado;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.pojos.SchedData;
import gob.bcb.lavado.repository.OfaBlacklistRepository;
import gob.bcb.lavado.repository.OfaBlanklistRepository;
import gob.bcb.lavado.repository.SwfBicsDao;
import gob.bcb.lavado.repository.SwfLoteDao;
import gob.bcb.lavado.repository.SwfMensajeDao;
import gob.bcb.lavado.repository.SwfParamsDao;
import gob.bcb.lavado.repository.SwfPersonaDao;
import gob.bcb.lavado.search.OfacIndexer;

@Service("swiftAdminDaoService")
public class SwiftAdminDaoServiceImpl implements SwiftAdminDaoService {
	private static final Logger log = LoggerFactory.getLogger(SwiftAdminDaoServiceImpl.class);

	@Autowired
	private SwfMensajeDao swfMensajeDao;
	@Autowired
	private OfaBlacklistRepository ofaBlacklistRepository;
	@Autowired
	private OfaBlanklistRepository ofaBlanklistRepository;
	@Autowired
	private OfacIndexer ofacIndexer;
	@Autowired
	private SwfBicsDao swfBicsDao;
	@Autowired
	private SwfLoteDao swfLoteDao;
	@Autowired
	private OfaListService ofaListService;
	// @Autowired
	// private LavadoProperties lavadoProperties;
	@Autowired
	private AppProperties appProperties;
	@Autowired
	private SwfParamsDao swfParamsDao;
	@Autowired
	private SchedulerService schedulerService;

	@Autowired
	private MailService mailService;

	public List<MensajesDatos> findObservados(Integer estVerifica) {
		List<MensajesDatos> mensajesDatosLista = new ArrayList<MensajesDatos>();

		swfMensajeDao.findObservados(estVerifica).forEach(swfMensaje -> {
			MensajesDatos mensajesDatos = swfMensajeDao.mensajeDatosFromSwfMensaje(swfMensaje, null, null, null, 0, false);
			mensajesDatosLista.add(mensajesDatos);
		});
		log.info("Nro Observados " + mensajesDatosLista.size());
		return mensajesDatosLista;
	}

	public SwfMensaje bloquearMensaje(Integer codMen, String codUsuario, String estacion) {
		log.info("bloquearMensaje " + codMen + " por " + codUsuario);
		return swfMensajeDao.cambiarEstadoVerificacion(codMen, codUsuario, Constants.TAB_ESTVERIFICA_POSITIVO_BLQ, estacion);
	}

	public SwfMensaje habilitarMensaje(Integer codMen, String codUsuario, String estacion) {
		log.info("habilitarMensaje " + codMen + " por " + codUsuario);
		return swfMensajeDao.cambiarEstadoVerificacion(codMen, codUsuario, Constants.TAB_ESTVERIFICA_FALSO_POSITIVO, estacion);
	}

	public SwfMensaje rechazarMensaje(Integer codMen, String codUsuario, String estacion) {
		log.info("eliminarMensaje " + codMen + " por " + codUsuario);
		return swfMensajeDao.cambiarEstadoAutorizacion(codMen, codUsuario, Constants.TAB_ESTAUTORIZA_RECHAZADOPORADMINSWFT, estacion);
	}

	public OfaBlacklist actualizarOfaBlacklist(OfaBlacklist ofaBlacklist, String estacion) {
		if (StringUtils.isBlank(ofaBlacklist.getBlkContent()))
			throw new DataException("Valor ingresado para lista negra inválida");			
		if (StringUtils.isBlank(ofaBlacklist.getBlkType()))
			throw new DataException("Valor ingresado para tipo de lista negra inválida");
		
		if (ofaBlacklist.getBlkId() == null) {
			Optional<OfaBlacklist> ofaBlacklistMax = ofaBlacklistRepository.findOneMaximo();
			if (ofaBlacklistMax.isPresent()) {
				ofaBlacklist.setBlkId(ofaBlacklistMax.get().getBlkId() + 1);
			} else {
				ofaBlacklist.setBlkId(1);
			}
		}

		ofaBlacklist.setBlkAuditfho(new Date());
		ofaBlacklist.setBlkAuditwst(estacion);
		
		try {
			ofaBlacklist.setBlkContent(UtilsGeneric.convertStringToEncode(ofaBlacklist.getBlkContent(), Constants.ENCODING_ISO));
			ofaBlacklist.setBlkType(UtilsGeneric.convertStringToEncode(ofaBlacklist.getBlkType(), Constants.ENCODING_ISO));			
		} catch (UnsupportedEncodingException e1) {
			log.error("eror " + e1.getMessage(), e1);
		}
		
		ofaBlacklistRepository.saveAndFlush(ofaBlacklist);
		log.info("actualizarOfaBlacklist " + ofaBlacklist.getBlkId());
		try {
			ofacIndexer.indexerClassSync(OfaBlacklist.class);
		} catch (Exception e) {
			log.error("Error al indexar " + e.getMessage(), e);
		}
		return ofaBlacklistRepository.findOne(ofaBlacklist.getBlkId());
	}

	public void eliminarOfaBlacklist(OfaBlacklist ofaBlacklist) {
		Integer id = ofaBlacklist.getBlkId();
		ofaBlacklistRepository.delete(ofaBlacklist);
		log.info("eliminado OfaBlacklist " + id);
		try {
			ofacIndexer.indexerClassSync(OfaBlacklist.class);
		} catch (Exception e) {
			log.error("Error al indexar " + e.getMessage(), e);
		}
	}

	public OfaBlanklist actualizarOfaBlanklist(OfaBlanklist ofaBlanklist) {

		if (ofaBlanklist.getBlcId() == null) {
			Optional<OfaBlanklist> ofaBlanklistMax = ofaBlanklistRepository.findOneMaximo();
			if (ofaBlanklistMax.isPresent()) {
				ofaBlanklist.setBlcId(ofaBlanklistMax.get().getBlcId() + 1);
			} else {
				ofaBlanklist.setBlcId(1);
			}
		} else {
			OfaBlanklist ofaBlanklistOld = ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
			if (ofaBlanklistOld != null) {
				if (ofaBlanklistOld.getBlcStatusauto() != null && ofaBlanklistOld.getBlcStatusauto().compareTo(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE) != 0) {
					throw new DataException("No puede modificar el registro, el estado debe ser pendiente");
				}
			}
		}
		if (StringUtils.isBlank(ofaBlanklist.getBlcContent())){
			throw new DataException("Valor ingresado para lista blanca inválida");
		}
		if (StringUtils.isBlank(ofaBlanklist.getBlcType())){
			throw new DataException("Valor ingresado para tipo de lista blanca inválida");
		}		
		
		ofaBlanklist.setBlcTabstatusauto(Constants.TAB_STATUSAUTOLBLANCA);
		ofaBlanklist.setBlcStatusauto(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE);
		ofaBlanklist.setBlcEstadoauto(null);
		ofaBlanklist.setBlcAuditfho(new Date());
		
		try {
			ofaBlanklist.setBlcContent(UtilsGeneric.convertStringToEncode(ofaBlanklist.getBlcContent(), Constants.ENCODING_ISO));
			ofaBlanklist.setBlcType(UtilsGeneric.convertStringToEncode(ofaBlanklist.getBlcType(), Constants.ENCODING_ISO));			
		} catch (UnsupportedEncodingException e1) {
			log.error("eror " + e1.getMessage(), e1);
		}
		
		ofaBlanklistRepository.saveAndFlush(ofaBlanklist);
		log.info("actualizarfaBlanklist " + ofaBlanklist.getBlcId());
		try {
			ofacIndexer.indexerClassSync(OfaBlanklist.class);
		} catch (Exception e) {
			log.error("Error al indexar " + e.getMessage(), e);
			// throw new DataException("Codigo de empleado nulo no puede
			// registrar: " + swfPersona.getPerNombre());
		}
		return ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
	}

	public void eliminarOfaBlanklist(OfaBlanklist ofaBlanklist) {
		log.info("eliminado OfaBlacklist " + ofaBlanklist.toString());

		OfaBlanklist ofaBlanklistOld = ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
		if (ofaBlanklistOld != null) {
			if (ofaBlanklistOld.getBlcStatusauto() != null && ofaBlanklistOld.getBlcStatusauto().compareTo(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE) != 0) {
				throw new DataException("No puede eliminar el registro, el estado debe ser pendiente");
			}
		}
		ofaBlanklistRepository.delete(ofaBlanklist);
		try {
			ofacIndexer.indexerClassSync(OfaBlanklist.class);
		} catch (Exception e) {
			log.error("Error al indexar " + e.getMessage(), e);
		}
	}

	public OfaBlanklist autorizarOfaBlanklist(OfaBlanklist ofaBlanklist) {
		Integer id = ofaBlanklist.getBlcId();
		log.info("autorizando OfaBlanklist " + id);
		try {
			OfaBlanklist ofaBlanklistOld = ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
			if (ofaBlanklistOld == null){
				throw new RuntimeException("Registro inexistente"); 
			}
			
			if (ofaBlanklistOld.getBlcStatusauto().equals(Constants.TAB_STATUSAUTOLBLANCA_AUTORIZADO)){
				throw new RuntimeException("El registro autorizado, elija uno con estado no autorizado");
			}
			
			if (StringUtils.isBlank(ofaBlanklistOld.getBlcContent())){
				throw new DataException("Valor de contenido de lista inválido");
			}
			if (StringUtils.isBlank(ofaBlanklistOld.getBlcType())){
				throw new DataException("Valor de tipo contenido de lista inválido");
			}		
			
			ofaBlanklistOld.setBlcAuditfho(new Date());
			ofaBlanklistOld.setBlcTabstatusauto(Constants.TAB_STATUSAUTOLBLANCA);
			ofaBlanklistOld.setBlcStatusauto(Constants.TAB_STATUSAUTOLBLANCA_AUTORIZADO);
			ofaBlanklistOld.setBlcEstadoauto(Constants.TAB_STATUSAUTOLBLANCA_AUTORIZADOSTR);
			
			ofaBlanklistRepository.saveAndFlush(ofaBlanklistOld);

			ofacIndexer.indexerClassSync(OfaBlanklist.class);
			return ofaBlanklistRepository.findOne(ofaBlanklistOld.getBlcId());
		} catch (Exception e) {
			log.error("Error al autorizar registro " + e.getMessage(), e);
			throw new DataException("Error al autorizar registro: " + e.getMessage());
		}
	}

	public OfaBlanklist cambiarAPendienteOfaBlanklist(OfaBlanklist ofaBlanklist) {
		Integer id = ofaBlanklist.getBlcId();
		OfaBlanklist ofaBlanklistOld = ofaBlanklistRepository.findOne(ofaBlanklist.getBlcId());
		if (ofaBlanklistOld == null){
			throw new RuntimeException("Registro inexistente"); 
		}
		
		if (ofaBlanklistOld.getBlcStatusauto().equals(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE)){
			throw new RuntimeException("El registro en estado pendiente, elija uno con estado diferente");
		}
		
		log.info("cambiarAPendiente OfaBlacklist " + id);
		ofaBlanklist.setBlcAuditfho(new Date());
		ofaBlanklist.setBlcTabstatusauto(Constants.TAB_STATUSAUTOLBLANCA);
		ofaBlanklist.setBlcStatusauto(Constants.TAB_STATUSAUTOLBLANCA_PENDIENTE);
		ofaBlanklist.setBlcEstadoauto(null);
		ofaBlanklistRepository.saveAndFlush(ofaBlanklist);

		try {
			ofacIndexer.indexerClassSync(OfaBlanklist.class);
			return ofaBlanklist;
		} catch (Exception e) {
			log.error("Error al autorizar registro " + e.getMessage(), e);
			throw new DataException("Error al autorizar registro: " + ofaBlanklist.getBlcId());
		}
	}

	public SwfBics actualizarSwfBics(SwfBics swfBics) {
		SwfBics swfBicsNew = swfBicsDao.actualizar(swfBics);
		return swfBicsNew;
	}

	/**
	 * Salva un archivo con lista de obsrevados OFAC de formato XML
	 */
	public SwfLote guardarLoteOfac(String codEmpleado, ArchivoSinple archivoSinple, String estacion) {
		log.info("guardarLoteOfac " + codEmpleado);
		archivoSinple.setDirectory(appProperties.getLavado().getAppdir() + "/" + Constants.DIR_OFAC_FILES_TMP);
		SwfLote swfLoteNew = swfLoteDao.guardarLoteOfac(codEmpleado, archivoSinple, true, estacion);

		ofaListService.cargarListaOfac(swfLoteNew.getLotPathfile(), swfLoteNew.getLotNrolote());
		return swfLoteNew;
	}

	public void loadListsFromDirectory(String codEmpleado, String estacion) throws Throwable {
		log.info("loadListsFromDirectory " + codEmpleado);
		ofaListService.loadListsFromDirectory(codEmpleado, estacion);
	}

	public void truncarListaOfac(String codEmpleado, String estacion) throws Throwable {
		ofaListService.truncateTablesOfac(codEmpleado, estacion);
		indexOfaSdnentry();
	}

	public void indexOfaSdnentry() throws Exception {
		ofacIndexer.indexOfaSdnentry();
	}

	public void indexLvdEntities() throws Exception {
		ofacIndexer.indexLvdEntities();
	}

	/**
	 * Graba en el direcotrio swift (importados) los mensajes pendientes
	 */
	public void grabarEnDirectorioSwift(List<SwfMensaje> swfMensajeLista, String codUser, String estacion) {
		log.info("Inicio salvado en carpeta swift... " + codUser + " items: " + swfMensajeLista.size());
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_PATHDIRSWIFT);
		if (swfParams == null) {
			throw new DataException("Parametro '" + Constants.PARAM_PATHDIRSWIFT + "' no definido en tabla Swfparams");
		}
		String dirSwift = swfParams.getParValor();
		String pathDirSwift = new File(appProperties.getLavado().getAppdir(), dirSwift).getAbsolutePath();
		log.info("Directorio swift " + pathDirSwift);
		File f = new File(pathDirSwift);
		if (!f.exists() || !f.isDirectory()) {
			throw new DataException("Directorio swift inexistente " + pathDirSwift);
		}
		List<SwfMensaje> swfMensajeListaAutos = new ArrayList<>();
		// seleccionamos todos los mensajes pendientes
		for (SwfMensaje swfMensaje : swfMensajeLista) {
			// cambiamos el estado del registro
			log.info("Ante de proceso de salvado mensaje " + swfMensaje.getMenCodmen());
			SwfMensaje swfMensajeAuto = swfMensajeDao.guardarEnImportados(swfMensaje.getMenCodmen(), codUser, pathDirSwift, estacion);
			swfMensajeListaAutos.add(swfMensajeAuto);
		}

		EmailDetalle emailDetalle = new EmailDetalle();
		emailDetalle.setTo(inicializaCorreos());

		for (SwfMensaje swfMensaje : swfMensajeListaAutos) {
			// cambiamos el estado del registro
			log.info("mensaje autorizado para alerta Autorizacion " + swfMensaje.getMenCodmen());
			MensajesDatos mensajesDatos = new MensajesDatos();
			mensajesDatos.setSwfMensaje(swfMensaje);
			mailService.sendAlertSwiftAutorizadoEmail(mensajesDatos, emailDetalle, null);
		}
	}

	public void grabarEnDirectorioSwift(String codUser, String estacion) {
		log.info("Inicio salvado CRON SALVADO... " + codUser);

		List<SwfMensaje> swfMensajeLista = swfMensajeDao.findByEstautoriza(Constants.TAB_ESTAUTORIZA_PREAUTORIZADOCONNROCORR, Constants.TAB_ESTMENSAJE_PROCESADO);
		grabarEnDirectorioSwift(swfMensajeLista, codUser, estacion);
	}

	public SwfMensaje solicitarCorrelativo(String codapp, String codoperacion, String coduser, String estacion, String idsession) {
		return swfMensajeDao.solicitarCorrelativo(codapp, coduser, codoperacion, estacion, idsession);
	}

	public SwfParams actualizarSwfParams(SwfParams swfParams) {
		SwfParams swfParamsNew = swfParamsDao.saveOrUpdate(swfParams);
		
		if (swfParamsNew.getParCodpar().equals(Constants.PARAM_HORARIOSIMPORT)) {
			log.info("Actualizacion de " + Constants.PARAM_HORARIOSIMPORT + " seejecuta start scheduler " + swfParamsNew.getParValor());
			startScheduling(swfParamsNew.getParValor(), Constants.PARAM_HORARIOSIMPORT, Constants.SCHEDULER_CRON_EXPRESION);
		} else if (swfParamsNew.getParCodpar().equals(Constants.PARAM_HORARIOSINDEXAR)) {
			log.info("Actualizacion de " + Constants.PARAM_HORARIOSINDEXAR + " seejecuta start scheduler " + swfParamsNew.getParValor());
			startScheduling(swfParamsNew.getParValor(), Constants.PARAM_HORARIOSINDEXAR, Constants.SCHEDULER_CRON_EXPRESION);
		}
		return swfParamsNew;
	}

	public void startScheduling(String horajob, String idsched, String cronExpr) {
		log.info("Ejecutando configuration scheduler " + horajob);
		schedulerService.startScheduling(horajob, idsched, cronExpr);
	}

	private String[] inicializaCorreos() {
		SwfParams swfParams = swfParamsDao.findByCod(Constants.PARAM_CORRALERTAVERIF);
		String correos = swfParams.getParValor();
		log.debug("Preparando mails de mensaje observado " + correos);
		final String[] tokens = StringUtils.split(correos, ",;");
		final ArrayList<String> result = new ArrayList<String>();

		for (int i = 0; i < tokens.length; i++) {
			if (StringUtils.isNotBlank(tokens[i]))
				result.add(tokens[i]);
		}
		return result.toArray(new String[result.size()]);
	}

}
