package gob.bcb.swift;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.io.parser.SwiftParser;
import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.SwiftBlock1;
import com.prowidesoftware.swift.model.SwiftBlock2;
import com.prowidesoftware.swift.model.SwiftBlock2Input;
import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.SwiftBlock3;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftBlock5;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field21;
import com.prowidesoftware.swift.model.field.Field23B;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field33B;
import com.prowidesoftware.swift.model.field.Field50A;
import com.prowidesoftware.swift.model.field.Field50K;
import com.prowidesoftware.swift.model.field.Field52A;
import com.prowidesoftware.swift.model.field.Field52D;
import com.prowidesoftware.swift.model.field.Field53A;
import com.prowidesoftware.swift.model.field.Field53B;
import com.prowidesoftware.swift.model.field.Field53D;
import com.prowidesoftware.swift.model.field.Field54A;
import com.prowidesoftware.swift.model.field.Field54B;
import com.prowidesoftware.swift.model.field.Field54D;
import com.prowidesoftware.swift.model.field.Field56A;
import com.prowidesoftware.swift.model.field.Field56D;
import com.prowidesoftware.swift.model.field.Field57A;
import com.prowidesoftware.swift.model.field.Field57B;
import com.prowidesoftware.swift.model.field.Field57D;
import com.prowidesoftware.swift.model.field.Field58A;
import com.prowidesoftware.swift.model.field.Field58D;
import com.prowidesoftware.swift.model.field.Field59;
import com.prowidesoftware.swift.model.field.Field70;
import com.prowidesoftware.swift.model.field.Field71A;
import com.prowidesoftware.swift.model.field.Field71F;
import com.prowidesoftware.swift.model.field.Field72;
import com.prowidesoftware.swift.model.field.SwiftParseUtils;

import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.swift.commons.MensSwiftUtiles;

/**
 * Mantiene los datos de un mensaje swift desparseado
 * 
 * @author wherrera
 *
 */
public class SwiftMessageBcb {
	private static final Logger log = LoggerFactory.getLogger(SwiftMessageBcb.class);
	private String menPlano;
	private String hash;	
	private SwiftMessage swiftMessage;
	/**
	 * Block 1
	 */
	private SwiftBlock1 block1;

	/**
	 * Block 2
	 */
	private SwiftBlock2 block2;
	private SwiftBlock2Input swiftBlock2Input;
	private SwiftBlock2Output swiftBlock2Output;
	/**
	 * Block 3
	 */
	private SwiftBlock3 block3;

	/**
	 * Block 4
	 */
	private SwiftBlock4 block4;

	/**
	 * Block 5
	 */
	private SwiftBlock5 block5;

	public SwiftMessageBcb() {
		inicializar();
		menPlano = "";
	}

	public SwiftMessageBcb(String menPlano) {
		inicializar();
		this.menPlano = menPlano;
	}

	private void inicializar() {
		// crea los bloques estaticos 1, 2, 3
		block1 = new SwiftBlock1();
		// block2 = new SwiftBlock2Input();
		swiftBlock2Input = new SwiftBlock2Input();
		swiftBlock2Output = new SwiftBlock2Output();
		block3 = new SwiftBlock3();
		block4 = new SwiftBlock4();
		block5 = new SwiftBlock5();

		swiftMessage = new SwiftMessage();
		swiftMessage.setBlock1(block1);
		// swiftMessage.setBlock2(swiftBlock2Input);
		swiftMessage.setBlock3(block3);
		swiftMessage.setBlock4(block4);
		swiftMessage.setBlock5(block5);

	}

	public void createBlock1(String applicationId, String serviceId, String logicalTerminal, String sessionNumber, String sequenceNumber) {
		block1.setApplicationId(applicationId);
		block1.setServiceId(serviceId);
		block1.setLogicalTerminal(logicalTerminal);
		block1.setSessionNumber(sessionNumber);
		block1.setSequenceNumber(sequenceNumber);
	}

	public void createBlock2(String messageType, String bicReceiver, String messagePriority, String deliveryMonitoring, String obsolescencePeriod) {
		SwiftBlock2Input swiftBlock2Input = new SwiftBlock2Input();
		swiftBlock2Input.setMessageType(messageType);

		BIC bicswf = new BIC(bicReceiver);

		swiftBlock2Input.setReceiver(bicswf);
		swiftBlock2Input.setMessagePriority(messagePriority);
		block2 = swiftBlock2Input;
		swiftMessage.setBlock2(block2);

	}

	public void createBlock3(String tagname, String value) {
		value = value.trim();
		tagname = tagname.trim();
		Tag tag = new Tag(tagname, value);

		if (block3 == null) {
			List<Tag> tagsBlock3 = new ArrayList<Tag>();
			block3 = new SwiftBlock3();
			block3.setTags(tagsBlock3);
		}
		int v = block3.removeAll(tagname);

		log.debug("removido tag block 3 " + tagname + " value " + v + " value: [" + value + "]");
		block3.getTags().add(tag);
	}

	public Field getField(String fieldName) {
		Field field = block4.getFieldByName(fieldName);
		return field;
	}

	public Field modifyFieldComponent(String fieldName, Integer numberComponent, String value) {

		Field field = getField(fieldName);

		if (field == null) {
			Tag tag = new Tag(fieldName, value);
			field = tag.getField();

			List<String> components = new ArrayList<String>(numberComponent);
			field.setComponents(components);
		}
		field.setComponent(numberComponent, value);

		block4.removeAll(fieldName);

		block4.append(field);
		return getField(fieldName);
	}

	public Field addField(Field field, boolean replace) {
		if (replace) {
			Field fld = getField(field.getName());
			int count = block4.countByName(field.getName());
			int index = block4.indexOfFirst(field.getName());

			if (count == 1 && index > -1) {
				log.info("reemplazando index " + field.getName() + " index " + index + " " + fld.getValue());
				Tag tag = block4.getTags().set(index, field.asTag());

				log.info("reemplazando index " + field.getName() + " index " + index + " " + field.getValue() + " " + tag.getValue());
			} else {
				int c = block4.countAll();
				int v = block4.removeAll(field.getName());
				int c1 = block4.countAll();
				log.info("removido field " + field.getName() + " ant " + c + " count: " + v + " c1 " + c1);

				block4.append(field);
			}

		} else {
			block4.append(field);
		}

		Field f = getField(field.getName());
		return f;
	}

	public Field addField(Field field) {
		return addField(field, true);
	}

	public String FIN() {
		return swiftMessage.toMT().message();
	}

	public Field setField20(Integer nroCorr, Date fechaValor, String userIniciales) {
		userIniciales = StringUtils.trim(userIniciales);

		Field20 f = new Field20();

		String corr = String.format("%04d", (nroCorr == null ? 0 : nroCorr));
		String fecStr = UtilsDate.stringFromDate(fechaValor, "ddMMyy");

		String valor = corr + "/" + fecStr + "/" + userIniciales;

		f.setReference(valor);

		return f; // return addField(f);
	}

	public Field setField21(String valor) {
		valor = StringUtils.trim(valor);

		Field21 f = new Field21();
		f.setReference(valor);
		return f; // return addField(f);
	}

	public Field setField23B(String valor) {
		valor = StringUtils.trim(valor);

		Field23B f = new Field23B(valor);
		return f;
	}

	public Field setField32A(Date fecha, String codMoneda, BigDecimal monto) {
		Field32A f = new Field32A();

		Calendar c = GregorianCalendar.getInstance();
		c.setTime(fecha);
		Currency currency = Currency.getInstance(codMoneda);

		f.setDate(c);
		f.setCurrency(currency);
		f.setAmount(monto);

		return f; // return addField(f);
	}

	public Field setField33B(String codMoneda, BigDecimal monto) {
		Field33B f = new Field33B();

		Currency currency = Currency.getInstance(codMoneda);

		f.setCurrency(currency.getCurrencyCode());
		f.setAmount(monto);

		return f;
	}

	public Field setField50A(String bic) {
		bic = StringUtils.trim(bic);

		Field50A f = new Field50A();
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f;
	}

	public Field setField50K(String ctaNro, String location) {
		ctaNro = StringUtils.trimToEmpty(ctaNro);
		location = StringUtils.trimToEmpty(location);

		Field50K f = new Field50K();
		f.setAccount(ctaNro);

		List<String> lines = MensSwiftUtiles.splitInLines(location, 4, " ", "", 0);
		System.out.println("location " + ArrayUtils.toString(lines));
		SwiftParseUtils.setComponentsFromLines(f, 2, 4, 0, lines);

		return f; // return addField(f);
	}

	public Field setField50K(String ctaNro, String name, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		name = StringUtils.trim(name);
		location = StringUtils.trim(location);

		Field50K f = new Field50K();
		f.setAccount(ctaNro);
		String nameandlocation = name + " " + location;
		f.setNameAndAddressLine1(nameandlocation);
		return f; // return addField(f);
	}

	public Field setField52A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field52A f = new Field52A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; // return addField(f);
	}

	public Field setField52D(String valor) {
		valor = StringUtils.trim(valor);

		Field52D f = new Field52D();
		return f; // return addField(f);
	}

	public Field setField53A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field53A f = new Field53A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);

		return f; // return addField(f);
	}

	public Field setField53B(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);

		Field53B f = new Field53B();
		f.setAccount(ctaNro);
		f.setLocation(location);

		SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 35, location);
		return f; // return addField(f);
	}

	public Field setField53D(String valor) {
		valor = StringUtils.trim(valor);

		Field53D f = new Field53D();
		return f; // return addField(f);
	}

	public Field setField54A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field54A f = new Field54A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; // return addField(f);
	}

	public Field setField54B(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);

		Field54B f = new Field54B();
		f.setAccount(ctaNro);
		f.setLocation(location);
		SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 35, location);
		return f; // return addField(f);
	}

	public Field setField54D(String valor) {
		valor = StringUtils.trim(valor);

		Field54D f = new Field54D();
		return f; // return addField(f);
	}

	public Field setField56A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field56A f = new Field56A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; // return addField(f);
	}

	public Field setField56D(String valor) {
		Field56D f = new Field56D();
		return f; // return addField(f);
	}

	public Field setField57A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field57A f = new Field57A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; // return addField(f);
	}

	public Field setField57B(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		location = StringUtils.trim(location);

		Field57B f = new Field57B();
		f.setAccount(ctaNro);
		f.setLocation(location);
		SwiftParseUtils.setComponentsFromTokens(f, 3, 3, 35, location);
		return f; // return addField(f);
	}

	public Field setField57D(String ctaNro, String location) {
		if (StringUtils.isBlank(ctaNro)) {
			log.error("Nro de cuenta nulo ");
			return null;
		}
		ctaNro = StringUtils.trim(ctaNro).toUpperCase();
		if (ctaNro.startsWith("FW")) {
			ctaNro = "/".concat(ctaNro);
		}

		Field57D f = new Field57D();
		f.setAccount(ctaNro);

		location = StringUtils.trimToEmpty(location);

		List<String> lines = MensSwiftUtiles.splitInLines(location, 4, " ", "", 0);
		// System.out.println("location " + ArrayUtils.toString(lines));
		SwiftParseUtils.setComponentsFromLines(f, 3, 4, 0, lines);

		return f; // return addField(f);
	}

	public Field setField58A(String ctaNro, String bic) {
		ctaNro = StringUtils.trim(ctaNro);
		bic = StringUtils.trim(bic);

		Field58A f = new Field58A();
		f.setAccount(ctaNro);
		BIC bicswf = new BIC(bic);
		f.setBIC(bicswf);
		return f; // return addField(f);
	}

	public Field setField58D(String ctaNro, String location) {
		ctaNro = StringUtils.trim(ctaNro).toUpperCase();
		location = StringUtils.trim(location).toUpperCase();

		if (ctaNro.startsWith("FW")) {
			ctaNro = "/".concat(ctaNro);
		}

		Field58D f = new Field58D();
		f.setAccount(ctaNro);
		SwiftParseUtils.setComponentsFromTokens(f, 3, 5, 35, location);
		return f; // return addField(f);
	}

	public Field setField58D(String ctaNro, String name, String location) {
		ctaNro = StringUtils.trim(ctaNro);
		name = StringUtils.trim(name);
		location = StringUtils.trim(location);

		Field58D f = new Field58D();
		f.setAccount(ctaNro);
		String nameandlocation = name + " " + location;
		f.setNameAndAddressLine1(nameandlocation);
		return f; // return addField(f);
	}

	public Field setField59(String ctaNro, String name, String location) {
		if (StringUtils.isBlank(ctaNro)) {
			log.error("Nro de cuenta nulo ");
			return null;
		}

		ctaNro = StringUtils.trim(ctaNro);
		name = StringUtils.trimToEmpty(name);
		location = StringUtils.trimToEmpty(location);

		// location = name + "\n\r" + location;
		Field59 f = new Field59();
		f.setAccount(ctaNro);

		List<String> lines0 = MensSwiftUtiles.splitInLines(name, 4, " ", "", 0);
		List<String> lines1 = MensSwiftUtiles.splitInLines(location, 4, " ", "", 0);

		List<String> lines = new ArrayList<String>();
		lines.addAll(lines0);
		lines.addAll(lines1);
		SwiftParseUtils.setComponentsFromLines(f, 2, 4, 0, lines);

		return f; // return addField(f);
	}

	public Field setField70(String valor) {
		Field70 f = new Field70();
		if (StringUtils.isBlank(valor)) {
			return f;
		}
		valor = StringUtils.trimToEmpty(valor);

		List<String> lines = MensSwiftUtiles.splitInLines(valor, f.componentsPattern().length(), "", null, 0);
		SwiftParseUtils.setComponentsFromLines(f, 1, f.componentsPattern().length(), 0, lines);
		return f; // return addField(f);
	}

	public Field setField71A(String valor) {
		if (StringUtils.isBlank(valor)) {
			return null;
		}
		valor = StringUtils.trimToEmpty(valor);
		Field71A f = new Field71A(valor);

		return f; // return addField(f);
	}

	public Field setField71F(String codMoneda, BigDecimal monto) {
		Field71F f = new Field71F();

		Currency currency = Currency.getInstance(codMoneda);

		f.setCurrency(currency);
		f.setAmount(monto);

		return f;
	}

	public Field setField72(String valor) {
		valor = StringUtils.trimToEmpty(valor);
		Field72 f = new Field72();
		if (StringUtils.isBlank(valor)) {
			return f;
		}

		valor = StringUtils.replaceChars(valor, "\r\n", "  ");
		valor = StringUtils.replace(valor, "//", " ");

		List<String> lines = MensSwiftUtiles.splitInLines(valor, f.componentsPattern().length(), "", "//", 1);
		SwiftParseUtils.setComponentsFromLines(f, 1, f.componentsPattern().length(), 0, lines);
		return f; // return addField(f);
	}

	public void fromString(String swiftPlano) throws IOException {
		if (StringUtils.isBlank(swiftPlano)) {
			throw new RuntimeException("Parametro swift Plano (RJE) nulo");
		}

		log.debug("fromString " + swiftPlano);

		SwiftParser swiftParser = new SwiftParser(swiftPlano);
		// swiftParser.setConfiguration(configuration);
		swiftMessage = swiftParser.message();

		block1 = swiftMessage.getBlock1();
		if (block1 == null){
			throw new RuntimeException("Error al parsear swiftPlano bloque 1 invalido");
		}
		block2 = swiftMessage.getBlock2();

		// mensajes salientes desde el bcb
		if (block2 != null)
			if (block2 instanceof SwiftBlock2Input)
				swiftBlock2Input = (SwiftBlock2Input) block2;
			// mensajes entrantes desde el bcb
			else if (block2 instanceof SwiftBlock2Output)
				swiftBlock2Output = (SwiftBlock2Output) block2;
		block3 = swiftMessage.getBlock3();
		block4 = swiftMessage.getBlock4();
		block5 = swiftMessage.getBlock5();
	}

	public void verificarPlano(String swiftPlano) {
		if (StringUtils.isBlank(swiftPlano)) {
			throw new RuntimeException("Error al verificar mensaje parametro swiftPlano nulo");
		}

		try {
			log.debug("Verificando::\n" + swiftPlano);
			fromString(swiftPlano);

			// SwiftMessage swiftMessage = mtSwiftMessage.getModelMessage();
			if (swiftMessage.getBlockCount() <= 3) {
				throw new RuntimeException("numero de bloques invalido: " + swiftMessage.getBlockCount());
			}

			if (swiftMessage.getType() == null) {
				throw new RuntimeException("tipo de mensaje nulo");
			}

			if (swiftMessage.getSender() == null) {
				throw new RuntimeException("campo sender nulo");
			}

			if (swiftMessage.getReceiver() == null) {
				throw new RuntimeException("campo receiver nulo");
			}

			if (block4 == null || block4.isEmpty() || block4.getTags().size() <= 1) {
				throw new RuntimeException("bloque 4 con campos insuficientes");
			}

		} catch (Exception e) {
			log.error("Error al verificar mensaje plano:" + e.getMessage(), e);
			throw new RuntimeException("Error al verificar swift " + e.getMessage(), e);
		}
	}

	public boolean isValid() {
		return !((menPlano == null || menPlano.trim().length() == 0) || (swiftMessage.getBlockCount() <= 3) || (swiftMessage.getType() == null)
				|| (swiftMessage.getSender() == null) || (swiftMessage.getReceiver() == null)
				|| (block4 == null || block4.isEmpty() || block4.getTags().size() <= 1));
	}

	public Map<String, String> getTagMap(int index) {
		Map<String, String> tagMap = new HashMap<String, String>();

		switch (index) {
		case 1:
			tagMap.put(block1.getName(), block1.getValue());
			break;
		case 2:
			tagMap.put(block2.getName(), block2.getValue());
			break;
		case 3:
			tagMap = block3.getTagMap();
			break;
		case 4:
			tagMap = block4.getTagMap();
			break;
		case 5:
			tagMap = block5.getTagMap();
			break;
		}
		return tagMap;
	}

	public SwiftBlock1 getBlock1() {
		return block1;
	}

	public void setBlock1(SwiftBlock1 block1) {
		this.block1 = block1;
	}

	public SwiftBlock2 getBlock2() {
		return block2;
	}

	public void setBlock2(SwiftBlock2 block2) {
		this.block2 = block2;
	}

	public SwiftBlock3 getBlock3() {
		return block3;
	}

	public void setBlock3(SwiftBlock3 block3) {
		this.block3 = block3;
	}

	public SwiftBlock4 getBlock4() {
		return block4;
	}

	public void setBlock4(SwiftBlock4 block4) {
		this.block4 = block4;
	}

	public SwiftBlock5 getBlock5() {
		return block5;
	}

	public void setBlock5(SwiftBlock5 block5) {
		this.block5 = block5;
	}

	public SwiftMessage getSwiftMessage() {
		return swiftMessage;
	}

	public void setSwiftMessage(SwiftMessage swiftMessage) {
		this.swiftMessage = swiftMessage;
	}

	public SwiftBlock2Output getSwiftBlock2Output() {
		return swiftBlock2Output;
	}

	public void setSwiftBlock2Output(SwiftBlock2Output swiftBlock2Output) {
		this.swiftBlock2Output = swiftBlock2Output;
	}

	public String getMenPlano() {
		return menPlano;
	}

	public String checkSum(String... exceptFields) {
		if (menPlano == null || menPlano.trim().length() == 0) {
			hash = "";
			return hash;
		}
		hash = ArchivoUtil.hashString(menPlano);
		return hash;
		
//		List<String> linesPlano = new ArrayList<String>();
//		Set<String> fields = new HashSet<String>();
//		fields.addAll(Arrays.<String> asList(null == exceptFields ? new String[0] : exceptFields));
//		linesPlano.add(block1.getValue());
//		if (block2 != null)
//			if (swiftMessage.isIncoming()) {
//				SwiftBlock2Output swiftBlock2Output = (SwiftBlock2Output) block2;
//				linesPlano.add(swiftBlock2Output.getValue());
//			} else if (swiftMessage.isOutgoing()) {
//				SwiftBlock2Input swiftBlock2Input = (SwiftBlock2Input) block2;
//				linesPlano.add(swiftBlock2Input.getValue());
//			}
//
//		if (block3 != null)
//			for (Entry<String, String> tag : block3.getTagMap().entrySet()) {
//				linesPlano.add(tag.getKey() + ":" + tag.getValue());
//			}
//
//		if (block4 != null)
//			for (Tag tag : block4.getTags()) {
//				Optional<String> fieldBic = fields.stream().filter(f -> f.trim().toUpperCase().equals(tag.getName())).findFirst();
//				if (!fieldBic.isPresent())
//					linesPlano.add(tag.getName() + ":" + tag.getValue());
//			}
//
//		String[] arrValor = new String[linesPlano.size()];
//		linesPlano.toArray(arrValor);
//		String hashAct = "";
//		try {
//			hashAct = ArchivoUtil.checkSumString(arrValor);
//		} catch (Exception e) {
//			log.error("Error al extraer HASH: " + e.getMessage(), e);
//			hashAct = "";
//		}
//		hash = hashAct;
//		return hash;
	}

	public boolean isSimilar(Object obj, String... exceptFields) {
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SwiftMessageBcb other = (SwiftMessageBcb) obj;
		log.info(this.checkSum(exceptFields) + " <-> " + other.checkSum(exceptFields));
		return this.checkSum(exceptFields).equals(other.checkSum(exceptFields));
	}

	public String getHash() {
		if (hash == null)
			hash = checkSum();
		return hash;
	}
	
}
