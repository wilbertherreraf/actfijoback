package gob.bcb.lavado.security.database;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.crypto.encrypt.Encryptors;
import org.springframework.security.crypto.encrypt.TextEncryptor;

import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.security.crypto.CryptoException;
import gob.bcb.lavado.security.crypto.CryptoService;
import gob.bcb.lavado.security.crypto.CryptoUtilImpl;
import gob.bcb.lavado.security.crypto.ICryptoUtil;

public class DatabaseUpdate {
	private static final Logger log = LoggerFactory.getLogger(DatabaseUpdate.class);
	private static final String NAME_FILESTORE = "_filestore.fs";
	private final DatabaseUpgrader upgrader;
	private final DataSource dataSource;

	private TextEncryptor currentEncryptor;
	private final String dirFileStore;
	private final String encryptVersion;
	private final String passwCurr;

	public DatabaseUpdate(DataSource dataSource, String pathFileConfig) {
		Properties prop = UtilsProperties.loadFileMsgProperties(pathFileConfig);
		File f = new File(pathFileConfig);
		this.dirFileStore = f.getParent() + "/filestore/";
		new File(this.dirFileStore).mkdirs();		
		this.passwCurr = prop.getProperty("password"); 
		final String passwOld = prop.getProperty("passwordOld");		
		this.encryptVersion=prop.getProperty("version");
		this.dataSource = dataSource;
		log.info("pathFileConfig " + pathFileConfig + " dirFileStore: " + this.dirFileStore);
		
		this.upgrader = createUpgrader(dataSource, encryptVersion, passwCurr, passwOld);		
	}

	
	public DatabaseUpdate(DataSource dataSource, String dirFileStore,String encryptVersion, String passw, String passwOld) {
		this.dataSource = dataSource;
		this.dirFileStore = dirFileStore;
		this.encryptVersion=encryptVersion;
		this.passwCurr = passw;
		log.info("dirFileStore: " + this.dirFileStore);
		
		this.upgrader = createUpgrader(dataSource, encryptVersion, passw, passwOld);
	}

	// internal helpers
	private DatabaseUpgrader createUpgrader(DataSource dataSource,String encryptVersion, String passwCurr, String passwOld) {
		GenericDatabaseUpgrader upgrader = new GenericDatabaseUpgrader(dataSource);
		if (upgrader.getCurrentDatabaseVersion().equals(DatabaseVersion.zero())) {
			// addInstallChangeSet(upgrader);
			log.info("En createUpgrader.. VER CERO ");
			currentEncryptor = Encryptors.noOpText();
		} else {
			log.info("En createUpgrader.. OLD");
			// current filestore
			DatabaseVersion databaseVersionNew = DatabaseVersion.valueOf(encryptVersion);			
			if (upgrader.getCurrentDatabaseVersion().equals(databaseVersionNew) || StringUtils.isBlank(passwOld)) {
				currentEncryptor = getInstallEncryptor(upgrader.getCurrentDatabaseVersion(), passwCurr, false);				
			} else {
				currentEncryptor = getInstallEncryptor(upgrader.getCurrentDatabaseVersion(), passwOld, false);
			}
			// testeamos si el contenido esta encriptado y es valido
			// testEncrytMenPlano(dataSource);
		}
		return upgrader;
	}

	/**
	 * Ejecuta la operacion de actualizacion de encryptado
	 * 
	 * @return
	 */
	public TextEncryptor run() {
		// version actual o a la cual se actualizara
		DatabaseVersion databaseVersionNew = DatabaseVersion.valueOf(encryptVersion);
		log.info("Running upgrade version encrypt[current: " + upgrader.getCurrentDatabaseVersion() + "] version: " + databaseVersionNew);

		if (!upgrader.getCurrentDatabaseVersion().equals(databaseVersionNew)) {
			// si la version nueva es mayor a la actual o si la actual version
			// es mayor a cero y la nueva es cero (se anula la encryptacion)
			log.info("Upgrading Database of " + upgrader.getCurrentDatabaseVersion() + " to Version " + databaseVersionNew.toString());

			updateEncrytMenPlano(dataSource, databaseVersionNew, passwCurr);
			log.info("Database is at Version " + databaseVersionNew);
		}
		return currentEncryptor;
	}

	// Called for completely fresh DB only
	/**
	 * Instala un nuevo encryptor segun el parametro version
	 * {@link DatabaseVersion}, en caso que no exista lo crea
	 * 
	 * @param version
	 * @return
	 */
	private TextEncryptor getInstallEncryptor(DatabaseVersion version, String password, boolean createKeystoreFileIfNotExist) {
		String versionStr = String.format("%05d", (version == null ? 0 : Integer.valueOf(version.toString())));
		// versionStr = version.toString();
		String fileKeystore = dirFileStore + versionStr + NAME_FILESTORE;
		log.info("Instalando encryptor version: " + versionStr + " file store..." + fileKeystore);

		ICryptoUtil cryptoUtil = new CryptoUtilImpl();
		try {
			cryptoUtil.initialize(fileKeystore, password, createKeystoreFileIfNotExist);
			return new CryptoService(cryptoUtil, versionStr);
		} catch (Exception e) {
			log.error("Error al inicializar file store " + e.getMessage(), e);
			throw new CryptoException(e);
		}
	}

	private static final String SELECT_SWFMENSAJE_MENPLANO = "select men_codmen, men_plano from swf_mensaje where men_plano is not null";
	private static final String SELECT_TEST_SWFMENSAJE_MENPLANO = "select m1.men_plano from swf_mensaje m1 where m1.men_codmen = (select max(m0.men_codmen) from swf_mensaje m0 where men_plano is not null)";
	private static final String UPDATE_SWFMENSAJE_MENPLANO = "update swf_mensaje set men_plano = ? where men_codmen = ?";
	private static final String SWFMENSAJE_MENPLANO = "men_plano";
	private static final String UPDATE_SWFPARAMS_VERSIONENC = "update swf_params set par_valor = ? where par_codpar = 'VERSION_ENC'";
	private static final String SWFMENSAJE_CODMEN = "men_codmen";

	/**
	 * Actualiza la base con la nueva llave de cifrado
	 * 
	 * @param dataSource
	 * @param newVersion
	 *            Nueva version del cifrado
	 * @param passwNew
	 *            passw del almacen
	 */
	private void updateEncrytMenPlano(DataSource dataSource, DatabaseVersion newVersion, String passwNew) {
		log.info("ATENCION: operation DE ACTUALIZAR ENCRIPTADO INICIADO a version: " + newVersion);
		Connection connection = null;
		try {
			// actualizamos el crypto
			connection = getTransactionalConnection(dataSource);

			// // instalamos el nuevo encryptor
			TextEncryptor newEncryptor = null;
			if (newVersion.equals(DatabaseVersion.zero())) {
				// se reinicializa el encryptado y la base estara sin el mismo
				newEncryptor = Encryptors.noOpText();
			} else {
				newEncryptor = getInstallEncryptor(newVersion, passwNew, true);
			}

			// checks if the parameter exists
			Statement stmt = connection.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);

			PreparedStatement pstmt = null;
			pstmt = (PreparedStatement) connection.prepareStatement(UPDATE_SWFMENSAJE_MENPLANO);
			int result = -1;
			try {
				ResultSet queryResult = stmt.executeQuery(SELECT_SWFMENSAJE_MENPLANO);
				while (queryResult.next()) {
					String cad = newEncryptor.encrypt(currentEncryptor.decrypt((queryResult.getString(SWFMENSAJE_MENPLANO))));
					Long cod = queryResult.getLong(SWFMENSAJE_CODMEN);
					log.debug(cod + " => " + queryResult.getString(SWFMENSAJE_MENPLANO));
					pstmt.setString(1, cad);
					pstmt.setLong(2, cod);
					result = pstmt.executeUpdate();
					if (result <= 0) {
						log.error("!! Record NOT Created !!" + cod);
						throw new CryptoException("registro " + cod + " no fue acutalizado en base");
					}
				}

				updateDatabaseVersion(newVersion, connection);

				commitTransaction(connection);
				// actualizamos el encriptor
				createUpgrader(dataSource, newVersion.toString(), passwNew, passwNew);

				queryResult.close();
			} catch (Exception e) {
				log.error(e.getMessage());
				rollbackTransaction(connection);
				throw e;
			} finally {
				stmt.close();
				// statement.close();
			}
		} catch (SQLException e) {
			throw new RuntimeException("Error al actualizar encrypt " + e.getMessage(), e);
		} finally {
			if (connection != null) {
				closeConnection(connection);
			}
		}
	}

	private void testEncrytMenPlano(DataSource dataSource) {
		log.info("Inicio test verificacion de encriptado");
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			// checks if the parameter exists
			Statement stmt = connection.createStatement();
			try {
				ResultSet queryResult = stmt.executeQuery(SELECT_TEST_SWFMENSAJE_MENPLANO);
				while (queryResult.next()) {
					String menPlano = queryResult.getString(SWFMENSAJE_MENPLANO);
					// currentEncryptor.decrypt(menPlano);
					log.info("Testing Enc: " + menPlano + "\nDec: " + currentEncryptor.decrypt(menPlano));
				}

				queryResult.close();
				log.info("Test verificacion de encriptado valido!!!");
			} catch (Exception e) {
				log.error("Test verificacion de encriptado INVALIDO!!! " + e.getMessage());
				throw e;
			} finally {
				stmt.close();
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (connection != null) {
				closeConnection(connection);
			}
		}
	}

	private Connection getTransactionalConnection(DataSource dataSource) {
		try {
			Connection connection = dataSource.getConnection();
			beginTransaction(connection);
			return connection;
		} catch (SQLException e) {
			throw new RuntimeException("Could not get JDBC Connection", e);
		}
	}

	private void beginTransaction(Connection connection) {
		try {
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			throw new RuntimeException("Could not begin database transaction", e);
		}
	}

	private void updateDatabaseVersion(DatabaseVersion version, Connection connection) {
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(UPDATE_SWFPARAMS_VERSIONENC);
			statement.setString(1, version.toString());
			statement.execute();

		} catch (Exception e) {
			throw new RuntimeException("Failed to update encryptor version", e);
		} finally {
			if (statement != null)
				try {
					statement.close();
				} catch (SQLException e) {
				}
		}
	}

	private void commitTransaction(Connection connection) {
		try {
			log.warn("Committing...");
			connection.commit();
		} catch (SQLException e) {
			throw new RuntimeException("Could not commit", e);
		}
	}

	private void rollbackTransaction(Connection connection) {
		try {
			log.warn("Rollbaking...");
			connection.rollback();
		} catch (SQLException e) {
			throw new RuntimeException("Could not rollback", e);
		}
	}

	private void closeConnection(Connection connection) {
		try {
			connection.close();
		} catch (SQLException ex) {
			// nadini
		}
	}


	public String getEncryptVersion() {
		return encryptVersion;
	}

}
