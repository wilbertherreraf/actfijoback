package gob.bcb.lavado.services;

import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.stereotype.Component;

import gob.bcb.swift.ParserSwiftMessage;

@Component("cryptoSwiftService")
public class CryptoSwiftService {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private TextEncryptor textEncryptor;
	
	/**
	 * Decripta una cadena encriptada, solo en caso que la misma este encriptada y no tenga formato swift 
	 * @param valueEncrypt
	 * @return
	 */
	public String decryptPlain(String valueEncrypt){
		String decryptMensaje = valueEncrypt;
		if (valueEncrypt != null && !valueEncrypt.trim().isEmpty())
			if (!ParserSwiftMessage.isFormatSwift(valueEncrypt)) {
				String version = valueEncrypt.substring(0, 5);
				if (NumberUtils.isNumber(version)){
					decryptMensaje = textEncryptor.decrypt(valueEncrypt);					
				}
			}	
		return decryptMensaje; 
	}
	
	public String encryptPlain(String valueDecrypt){
		//String decryptMensaje = valueDecrypt;
		if (valueDecrypt != null && !valueDecrypt.trim().isEmpty())
			if (ParserSwiftMessage.isFormatSwift(valueDecrypt)) {
				return textEncryptor.encrypt(valueDecrypt);
				//log.info("Encrypt: valueDecrypt : " + valueDecrypt + " to => " + decryptMensaje);				
			} else {
				String version = valueDecrypt.substring(0, 5);
				if (NumberUtils.isNumber(version)){
					// cadena se encuentra encriptada
					return valueDecrypt;
				}				
			}
	
		return null; 
	}	
}
