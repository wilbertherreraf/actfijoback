package gob.bcb.lavado.services;


import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.search.OfacIndexer;
import gob.bcb.lavado.services.OfaListService;

public class OfaListServiceTest extends ConfigBaseTest {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OfaListService ofaListService;
	@Autowired
	private OfacIndexer ofacIndexer;

	@Test
	public void indexOfaSdnentryTest() throws Exception {
		log.info("%%%%%%%%%%%%%% indexOfaSdnentry %%%%%%%%%%%%%%");
		if (!listLoaded)
			ofacIndexer.indexOfaSdnentry();
	}

	public void indexLvdEntitiesTest() throws Exception {
		log.info("%%%%%%%%%%%%%% indexLvdEntities %%%%%%%%%%%%%%");
		ofacIndexer.indexLvdEntities();
	}

}
