package gob.bcb.lavado.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;

import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.lavadoclient.ClienteLvd;
import gob.bcb.lavado.model.SwfBics;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.rest.dto.SearchResponse;
import gob.bcb.lavado.rest.dto.SearchResponse.ItemsInfo;
import gob.bcb.lavado.services.CryptoSwiftService;
import gob.bcb.lavado.services.SwiftBcbSearcherService;
import gob.bcb.swift.pojos.Block4;
import gob.bcb.swift.pojos.SwiftDatos;

/**
 * Contiene test de las funciones basicas de busqueda: carga de listas ofac,
 * indexacion, busqueda
 * 
 * @author wherrera
 *
 */
public class SwiftBcbSearcherServiceImplTest extends ConfigBaseTest {
	protected final static Logger log = LoggerFactory.getLogger(SwiftBcbSearcherServiceImplTest.class);
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;
	@Autowired
	private CryptoSwiftService cryptoSwiftService;

	private String url;
	ClienteLvd scanSwiftMessage;	
	@Before
	@Override
	public void before() throws Throwable {
		super.before();
		//initDataInicialBaseSearch();
		url = base.toString();
		scanSwiftMessage = new ClienteLvd(url);		
	}	
	
	@Test
	public void verificarMensajePlanoSalienteTest() throws Throwable {
		final String archSwift = "src/test/resources/swifts/swf_4633_ent_alias.dos";
		searchAndVerifyResponse(archSwift, 1);
	}

	@Test
	public void verificarMensajePlanoEntranteTest() throws Throwable {
		final String archSwift = "src/test/resources/swifts/swf_4632_ent_in.dos";
		searchAndVerifyResponse(archSwift, 1);
	}

	@Test
	public void observadoEntidadTest() throws Throwable {
		final String archSwift = "src/test/resources/swifts/swf_4632_ent.dos";
		searchAndVerifyResponse(archSwift, 1);
	}

	@Test
	public void observadoEntidadPorAliasTest() throws Throwable {
		final String archSwift = "src/test/resources/swifts/swf_4633_ent_alias.dos";
		searchAndVerifyResponse(archSwift, 1);
	}

	@Test
	public void observadoIndividualTest() throws Throwable {
		final String archSwift = "src/test/resources/swifts/swf_9639_indiv.dos";
		searchAndVerifyResponse(archSwift, 1);
	}

	@Test
	public void observadoIndividualAliasTest() throws Throwable {
		final String archSwift = "src/test/resources/swifts/swf_9645_indiv_alias.dos";
		searchAndVerifyResponse(archSwift, 1);
	}

	@Test
	public void observadoSinObservacionTest() throws Throwable {
		final String archSwift = "src/test/resources/swifts/swf_sinobservacion.dos";
		searchAndVerifyResponse(archSwift, 0);
	}

	@Test
	public void searchQueryNameTest() {
		String query = "HASAN DUKHAN Abdul XXX";
		query = "venezuela ABU TAIR Mohammed Mahmud changos";
		String field = "IND_NOMBRE_ALIAS";
		SearchResponse searchResponse = swiftBcbSearcherService.verificarMensaje(query, field);
		Assert.assertNotNull("searchResponse nulo", searchResponse);
	}

	@Test
	public void searchSwfBicsTest() {
		log.info("====== searchSwfBicsTest ====== ");		
		String query = "AAALSARI HOLLANDI";
		//query = "LONDON";
		String field = "BICS";
		List<SwfBics> searchResponse = (List<SwfBics>) swiftBcbSearcherService.searchForQueryInSwfBics(query, field);
		Assert.assertNotNull("searchResponse nulo", searchResponse);
	}

	@Test
	public void resourceSearchScanSingleTest() throws Throwable {
		// test de todos los mensajes registrados en la carpeta swifts
		// initDataInicialBaseSearch("src/test/resources/ofac/ofac_small.xml");

		log.info("=== resourceSearchScanSingleTest Request URL " + url);
		long startTime = System.currentTimeMillis();
		String inputDirectory = "src/test/resources/swifts";
		int count = 0;
		for (Path filePath : Files.newDirectoryStream(FileSystems.getDefault().getPath(inputDirectory))) {
			log.info("------------------------------------------");
			File f = filePath.toFile();
			if (f.isDirectory()) {
				continue;
			}
			count++;
			String pathFileSource = f.getAbsolutePath();
			log.info("Archivo Test pathFileSource " + pathFileSource);
			String content;
			try (FileInputStream fis = new FileInputStream(f); InputStreamReader reader = new InputStreamReader(fis, Charsets.ISO_8859_1)) {
				content = CharStreams.toString(reader);
				SearchResponse searchResponse = scanSwiftMessage.scanMsgPlanoSingleFromString(content);
				Assert.assertNotNull("searchResponse nulo", searchResponse);
				Assert.assertNotNull("searchResponse.getItemsInfo() nulo", searchResponse.getItemsInfo());
				Assert.assertNotNull("searchResponse.getCodResp() nulo", searchResponse.getCodResp());
				log.info("Response[" + searchResponse.getCountRegs() + "] " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}
		}

		log.info("Test done [ " + count + " files] at (" + (System.currentTimeMillis() - startTime) + " ms.)");
	}

	@Test
	public void mensajePlanoToSwfMensajeTest() throws Exception{
		log.info("mensajePlanoToSwfMensajeTest ...");
		String archSwift = "src/test/resources/swifts/swf_4632_ent.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		String hashOrig = ArchivoUtil.hashString(menPlano);
		String encryptPlano = cryptoSwiftService.encryptPlain(menPlano);
		SwiftDatos swiftDatos = swiftBcbSearcherService.mensajePlanoToSwfMensaje(encryptPlano, true);
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();

		log.info(swfMensaje.getMenPlano());
		String hashPostProcess = ArchivoUtil.hashString(swfMensaje.getMenPlano());
		log.info("hashPostProcess " + hashPostProcess);
		Assert.assertTrue("Hash se esperaba " + hashOrig, hashOrig.equals(hashPostProcess));
		List<Block4> block4List = swfMensaje.getBlock4List();
		for (Block4 block4 : block4List) {
			log.info("block4 " + block4.getName() + " : " + block4.getValue() + " " + block4.getValueDescrip());
		}
		
	}
	
	private void searchAndVerifyResponse(String archSwift, Integer expectedregs) {
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		SearchResponse searchResponse = swiftBcbSearcherService.searchScanSingle(menPlano);
		verifyResponse(searchResponse, expectedregs);
	}

	private void verifyResponse(SearchResponse searchResponse, Integer expectedregs) {
		log.info("expectedregs " + expectedregs + " " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
		if (expectedregs.compareTo(0) > 0) {
			Assert.assertTrue("nro de registros invalido", searchResponse.getCountRegs().compareTo(expectedregs) >= 0);
		} else {
			Assert.assertTrue("nro de registros invalido", searchResponse.getCountRegs().compareTo(0) == 0);
		}
	}

	//@Test
	public void testMasivoTest() throws Throwable {
		// test de todos los mensajes registrados en la carpeta swifts
		// initDataInicialBaseSearch("src/test/resources/ofac/ofac_small.xml");

		log.info("=== testMasivoTest Request URL " + url);
		long startTime = System.currentTimeMillis();
		String inputDirectory = "src/test/resources/perf";
		int count = 0;
		
		SearchResponse searchResponse = scanSwiftMessage.getSessionLavado("TEST", "usertest");
		String idsession = searchResponse.getCodoperacion();
		log.info("SESSION LAVADO " + idsession);		
		
		for (Path filePath : Files.newDirectoryStream(FileSystems.getDefault().getPath(inputDirectory))) {
			log.info("------------------------------------------");
			File f = filePath.toFile();
			if (f.isDirectory()) {
				continue;
			}
			count++;
			String pathFileSource = f.getAbsolutePath();
			log.info("o=P Archivo Test pathFileSource " + pathFileSource);
			String content;
			try (FileInputStream fis = new FileInputStream(f); InputStreamReader reader = new InputStreamReader(fis, Charsets.ISO_8859_1)) {
				String codigo = String.valueOf(System.currentTimeMillis()).substring(5, 8);
				content = CharStreams.toString(reader);	
				
				searchResponse = scanSwiftMessage.solicitarCorrelativo("TEST", codigo, "usertest", idsession);
				searchResponse = scanSwiftMessage.scanSwiftRegistro("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()),
						searchResponse.getNrocorr(), codigo, idsession, content);
				//searchResponse = scanSwiftMessage.preautorizarSwift("TEST", "usertest", Integer.valueOf(searchResponse.getCodoperacion()), searchResponse.getNrocorr(), codigo, idsession, content);
				Assert.assertNotNull("searchResponse nulo", searchResponse);
				Assert.assertNotNull("searchResponse.getItemsInfo() nulo", searchResponse.getItemsInfo());
				Assert.assertNotNull("searchResponse.getCodResp() nulo", searchResponse.getCodResp());
				log.info("Response[" + searchResponse.getCountRegs() + "] " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp());
			}
		}
		scanSwiftMessage.postSessionLavado("TEST", "usertest", idsession);
		log.info("Test done [ " + count + " files] at (" + (System.currentTimeMillis() - startTime) + " ms.)");
	}
	
}
