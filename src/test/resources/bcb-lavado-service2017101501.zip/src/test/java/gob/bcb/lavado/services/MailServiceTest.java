package gob.bcb.lavado.services;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.CharEncoding;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.dumbster.smtp.SimpleSmtpServer;
import com.dumbster.smtp.SmtpMessage;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.commons.EmailDetalle;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.model.SwfMensaje;
import gob.bcb.lavado.pojos.MensajesDatos;
import gob.bcb.lavado.rest.dto.SearchResponse;
import gob.bcb.lavado.services.MailService;

public class MailServiceTest extends ConfigBaseTest {
	private static final Logger log = LoggerFactory.getLogger(MailServiceTest.class);
	@Autowired
	private MailService mailService;

	@Test
	public void sendAlertSwiftForRevisionEmailTest() {
		log.info("send Alert Swift For Revision Email dummy");
		MensajesDatos mensajesDatos = new MensajesDatos();
		SwfMensaje swfMensaje = new SwfMensaje();
		swfMensaje.setMenCodmen(0);
		swfMensaje.setMenCodmt("000");
		swfMensaje.setMenBic("XYZXXXXX");
		mensajesDatos.setSwfMensaje(swfMensaje);
		EmailDetalle emailDetalle = new EmailDetalle();
		emailDetalle.setFrom("asdf@localhost");
		emailDetalle.setTo(new String[] { "to@localhost" });
		emailDetalle.setContent("holaaaaa");
		emailDetalle.setSubject("asuntito");

		mailService.sendAlertSwiftForRevisionEmail(mensajesDatos, emailDetalle, null);
		mailService.sendAlertSwiftForRevisionEmail(mensajesDatos, emailDetalle, null);
		mailService.sendAlertSwiftForRevisionEmail(mensajesDatos, emailDetalle, null);
		log.info("sleeeeping ....");
		receiveMail(true);
	}

	@Test
	public void testSend() {
		log.info("en testSend");
		try {
			sendEmail("sender@here.com", "Test", "Test Body", false, true);
			sendEmail("sender2@here.com", "Test2", "Test Body2", false, true);
			receiveMail(true);
		} catch (Exception e) {
			log.error("message " + e.getMessage(), e);
		}
	}

	public Properties getMailProperties(int port) {
		Properties mailProps = new Properties();
		mailProps.setProperty("mail.smtp.host", TEST_SMTP_HOSTNAME);
		mailProps.setProperty("mail.smtp.port", "" + TEST_SMTP_PORT);
		mailProps.setProperty("mail.smtp.sendpartial", "true");
		return mailProps;
	}

	public void sendMessage(int port, String from, String subject, String body, String to) throws MessagingException {
		Properties mailProps = getMailProperties(port);
		Session session = Session.getInstance(mailProps, null);
		session.setDebug(true);

		MimeMessage msg = createMessage(session, from, to, subject, body);
		log.info("Send Email dummy to " + to);
		Transport.send(msg);
	}

	public void sendEmail(String to, String subject, String content, boolean isMultipart, boolean isHtml) {
		log.info("Send e-mail[multipart '{}' and html '{}'] to '{}' with subject '{}' and content={}", isMultipart, isHtml, to, subject, content);

		// Prepare message using a Spring helper
		MimeMessage mimeMessage = javaMailSenderImpl.createMimeMessage();
		try {
			MimeMessageHelper message = new MimeMessageHelper(mimeMessage, isMultipart, CharEncoding.UTF_8);
			message.setTo(to);
			message.setFrom("from@local.com");
			message.setSubject(subject);
			message.setText(content, isHtml);
			javaMailSenderImpl.send(mimeMessage);
			log.info("Sent e-mail to User '{}'", to);
		} catch (Exception e) {
			log.warn("E-mail could not be sent to user '{}', exception is: {}", to, e.getMessage());
		}
	}

	public MimeMessage createMessage(Session session, String from, String to, String subject, String body) throws MessagingException {
		MimeMessage msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress(from));
		msg.setSubject(subject);
		msg.setSentDate(new Date());
		msg.setText(body);
		msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
		return msg;
	}
}
