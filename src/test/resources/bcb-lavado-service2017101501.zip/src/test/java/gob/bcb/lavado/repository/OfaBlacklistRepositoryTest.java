package gob.bcb.lavado.repository;

import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.model.OfaBlacklist;
import gob.bcb.lavado.model.OfaBlanklist;
import gob.bcb.lavado.repository.OfaBlacklistRepository;
import gob.bcb.lavado.repository.OfaBlanklistRepository;
import gob.bcb.lavado.rest.dto.SearchResponse;
import gob.bcb.lavado.rest.dto.SearchResponse.ItemsInfo;
import gob.bcb.lavado.services.SwiftAdminDaoService;
import gob.bcb.lavado.services.SwiftBcbSearcherService;

public class OfaBlacklistRepositoryTest extends ConfigBaseTest {
	private static final Logger log = LoggerFactory.getLogger(OfaBlacklistRepositoryTest.class);

	@Autowired
	SwiftAdminDaoService swiftAdminDaoService;
	@Autowired
	OfaBlacklistRepository ofaBlacklistRepository;
	@Autowired
	OfaBlanklistRepository ofaBlanklistRepository;
	@Autowired
	private SwiftBcbSearcherService swiftBcbSearcherService;

	@Test
	public void actualizarOfaBlacklistTest() {
		log.info("========= actualizarOfaBlacklistTest =========");
		Optional<OfaBlacklist> ofaBlacklistMax = ofaBlacklistRepository.findOneMaximo();

		OfaBlacklist ofaBlacklist = new OfaBlacklist();
		ofaBlacklist.setBlkContent("textobloqueado" + (ofaBlacklistMax.isPresent() ? ofaBlacklistMax.get().getBlkId() + 1 : "1"));
		ofaBlacklist.setBlkType("tipobloqueado");
		ofaBlacklist.setBlkAuditusr("test");

		OfaBlacklist ofaBlacklistNew = swiftAdminDaoService.actualizarOfaBlacklist(ofaBlacklist,"estacion");
		Optional<OfaBlacklist> ofaBlacklistOld = ofaBlacklistRepository.findOneMaximo();

		Assert.assertTrue("ofaBlacklist no se creo", ofaBlacklistNew.getBlkId().compareTo(ofaBlacklistOld.get().getBlkId()) == 0);

		swiftAdminDaoService.eliminarOfaBlacklist(ofaBlacklistOld.get());
		log.info("eliminado " + ofaBlacklistNew.getBlkId());
		OfaBlacklist ofaBlacklistN = ofaBlacklistRepository.findOne(ofaBlacklistOld.get().getBlkId());
		log.info("(ofaBlacklistN == null) " + (ofaBlacklistN == null));
		Assert.assertNull("debe ser nulo", ofaBlacklistN);
	}

	@Test
	public void actualizarOfaBlanklistTest() {
		log.info("========= actualizarOfaBlanklistTest happy day!!!!!=========");
		OfaBlanklist ofaBlacklist = new OfaBlanklist();
		ofaBlacklist.setBlcContent("CONSULADO GENERAL DE BOLIVIA");
		ofaBlacklist.setBlcType("tipobloqueado");
		ofaBlacklist.setBlcStatusauto(1);
		ofaBlacklist.setBlcAuditusr("test");

		OfaBlanklist ofaBlacklistNew = swiftAdminDaoService.actualizarOfaBlanklist(ofaBlacklist);
		log.info("creado ofaBlacklistNew : " + ofaBlacklistNew.getBlcId());
		Optional<OfaBlanklist> ofaBlacklistOld = ofaBlanklistRepository.findOneMaximo();

		Assert.assertTrue("ofaBlanklist no se creo", ofaBlacklistNew.getBlcId().compareTo(ofaBlacklistOld.get().getBlcId()) == 0);

		// autorizamos el registro
		ofaBlacklistNew = swiftAdminDaoService.autorizarOfaBlanklist(ofaBlacklistNew);
		Assert.assertTrue("ofaBlanklist no se autorizo", ofaBlacklistNew.getBlcStatusauto().compareTo(Constants.TAB_STATUSAUTOLBLANCA_AUTORIZADO) == 0);

		final String archSwift = "src/test/resources/swifts/swf_lista_blanca.dos";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		SearchResponse searchResponse = swiftBcbSearcherService.searchScanSingle(menPlano);

		log.info("searchResponse : " + searchResponse.getCodResp() + " " + searchResponse.getDescripResp() + " " + searchResponse.getCountRegs());

		Assert.assertFalse("NO Se esperaba elementos en el scan", searchResponse.getCountRegs() > 0);
		log.info("=> [" + searchResponse.getCodResp() + "] " + searchResponse.getDescripResp() + " " + searchResponse.getCountRegs());

		for (ItemsInfo item : searchResponse.getItemsInfo()) {
			log.info("=> " + item.getIdDoc() + "[" + item.getScore() + "] " + item.getClazz() + "." + item.getField() + " : " + item.getContentHighlight());
		}

		swiftAdminDaoService.cambiarAPendienteOfaBlanklist(ofaBlacklistNew);

		swiftAdminDaoService.eliminarOfaBlanklist(ofaBlacklistOld.get());
		log.info("eliminado " + ofaBlacklistNew.getBlcId());
		OfaBlanklist ofaBlacklistN = ofaBlanklistRepository.findOne(ofaBlacklistOld.get().getBlcId());
		log.info("(ofaBlacklistN == null) " + (ofaBlacklistN == null));
		Assert.assertNull("debe ser nulo", ofaBlacklistN);
	}

}
