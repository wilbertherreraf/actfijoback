package gob.bcb.lavado.commons;

import java.nio.file.Paths;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.commons.ReporteSwift;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.services.ReporteSwiftService;

public class ReporteSwiftTest extends ConfigBaseTest {
	private static final Logger log = LoggerFactory.getLogger(ReporteSwiftTest.class);
	public static final String FILE_REPORT_SWIFT = "reposwift.docx";

	@Autowired
	private ReporteSwiftService reporteSwiftService;
	ReporteSwift reporteSwift = new ReporteSwift();
	
	@Before
	@Override
	public void before() throws Exception {
		log.info("=== Before setup ReporteSwift ==== ");		
		reporteSwift.initReporteSwift();
	}
	

	public void initReporteSwift() {
		String fullExecutablePath = this.getClass().getResource("").getPath();
		log.info("fullExecutablePath " + fullExecutablePath);
		String rootPath = Paths.get(".").toUri().normalize().getPath();
		log.info("rootPath " + rootPath);
		String extractedPath = fullExecutablePath.replace(rootPath, "");
		log.info(extractedPath);
	}
	
	@Test
	public void generarReportePDFFromPlanoTestOut() throws Exception{
		String archSwift = "src/test/resources/swifts/sioc2016000017.txt";
		log.info("====generarReportePDFFromPlanoTestOut===== ");
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		log.info(menPlano);		
		ArchivoSinple archivoSinplePDF = reporteSwiftService.generarReportePDFFromPlano(menPlano, "codUsuario", null);
		
		archivoSinplePDF.setDirectory("/tmp");
		archivoSinplePDF.setName(archivoSinplePDF.getHash() + "." + ArchivoUtil.obtenerExtension(archivoSinplePDF.getNameOriginal()));
		archivoSinplePDF.putPathFile();
		String p = UtilsFile.grabaEnArchivo(archivoSinplePDF.getStream(), archivoSinplePDF.getPathFile());
		
		log.info("archivo salvado " + p);
	}
	
	@Test
	public void generarReportePDFFromPlanoTestIn() throws Exception{
		log.info("====generarReportePDFFromPlanoTestIn===== ");		
		String archSwift = "src/test/resources/swifts/in_0001.txt";
		String menPlano = UtilsFile.readFileAsString2(archSwift);
		log.info(menPlano);		
		ArchivoSinple archivoSinplePDF = reporteSwiftService.generarReportePDFFromPlano(menPlano, "codUsuario", null);
		
		archivoSinplePDF.setDirectory("/tmp");
		archivoSinplePDF.setName(archivoSinplePDF.getHash() + "." + ArchivoUtil.obtenerExtension(archivoSinplePDF.getNameOriginal()));
		archivoSinplePDF.putPathFile();
		String p = UtilsFile.grabaEnArchivo(archivoSinplePDF.getStream(), archivoSinplePDF.getPathFile());
		
		log.info("archivo salvado " + p);
	}	
}
