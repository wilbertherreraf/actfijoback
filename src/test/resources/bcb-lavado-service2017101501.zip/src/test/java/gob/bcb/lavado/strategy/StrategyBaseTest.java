package gob.bcb.lavado.strategy;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import gob.bcb.lavado.commons.Constants;
import gob.bcb.lavado.config.AppProperties;
import gob.bcb.lavado.config.ConfigBaseTest;
import gob.bcb.lavado.rest.LvdSwiftsResource;
import gob.bcb.lavado.search.FieldQuery;
import gob.bcb.lavado.strategy.StrategyBase;

public class StrategyBaseTest extends ConfigBaseTest{
	private static final Logger log = LoggerFactory.getLogger(StrategyBaseTest.class);

	@Autowired 
	private AppProperties appProperties;
	@Autowired 
	private LvdSwiftsResource lvdSwiftsResource;
	@Test
	public void loadQueriesTest() throws Exception {
		String path = appProperties.getLavado().getAppdir() +  "/"+ Constants.DIR_QUERIES;
		StrategyBase strategyBase = StrategyBase.getInstance(path);
		String id = "59";
		log.info("Consultanto estrategia ..." + id);
		Map<String, Map<String, List<FieldQuery>>> docs = strategyBase.matchesForFieldswift(id);
		Assert.assertTrue("Numero de registros esperados menor campo swift " + id, docs.size() > 2);
	}

	@Test
	public void loadQueriesEstrategiaTest() throws Exception {
		final String path = appProperties.getLavado().getAppdir() +  "/"+ Constants.DIR_QUERIES;		
		List<String> result = lvdSwiftsResource.getStrategiesLvd();
		Assert.assertTrue("Numero de registros esperados invalido", result.size() > 0);
		StrategyBase strategyBase = StrategyBase.getInstance(path);		
		result.stream().forEach(s -> {
			log.info("Estrategia ..." + s);
			Map<String, List<FieldQuery>> fieldQueryMap = strategyBase.matchesForIdEstrategia(s);
			Assert.assertTrue("Numero Estrategias esperados invalido", fieldQueryMap.size() > 0);
			for (Entry<String, List<FieldQuery>> fieldQueryEntry : fieldQueryMap.entrySet()) {
				List<FieldQuery> fieldQueryLista = fieldQueryEntry.getValue();
				Assert.assertTrue("Numero fieldQueryLista esperados invalido", fieldQueryLista.size() > 0);
			}
		});
	}
}
