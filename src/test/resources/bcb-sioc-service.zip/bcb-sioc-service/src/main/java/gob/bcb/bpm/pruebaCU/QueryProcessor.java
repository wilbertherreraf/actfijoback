/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * 
 *  * 22/06/2011 - 16:52:20
 * 
 */
package gob.bcb.bpm.pruebaCU;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.activemq.command.ActiveMQDestination;
import org.apache.activemq.command.ActiveMQObjectMessage;
import org.apache.activemq.command.ActiveMQTopic;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.core.jms.BcbResponseImpl;
import gob.bcb.core.jms.ResponseContext;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.persist.EntityUserTransactionSioc;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.service.commons.EmailDetalle;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.qnatives.coin.CalendarioComun;
import gob.bcb.service.servicioBolsin.BolsinService;
import gob.bcb.service.servicioPortiaSwift.PortiaService;
import gob.bcb.service.servicioSioc.ClienteLvdSioc;
import gob.bcb.service.servicioSioc.MsgMailListener;
import gob.bcb.service.servicioSioc.ServicioSiocListener;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.ActualizarAFecha;
import gob.bcb.service.servicioSioc.logic.GenerarAutomatica;
import gob.bcb.service.servicioSioc.logic.GenerarComprobante;
import gob.bcb.service.servicioSioc.logic.GenerarFechaValor;
import gob.bcb.service.servicioSioc.logic.ProcesosSolicitud;
import gob.bcb.service.servicioSioc.logic.RegistrarSolicitud;
import gob.bcb.service.servicioSioc.logic.SwiftSiocService;
import gob.bcb.service.servicioSioc.mail.MsgLogic;
import gob.bcb.service.servicioSioc.pojos.CuentaS;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.swift.commons.ConstantsSwift;

/**
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 * 
 * 
 * @author eibanez
 * 
 */
public class QueryProcessor extends EntityUserTransactionSioc {
	private static final Log log = LogFactory.getLog(QueryProcessor.class);
	private static final char PENDIENTE = 'P';
	private static final char AUTORIZADO = 'A';
	private static final char RECHAZADO = 'Z';
	private static final String ERROR = "-1";
	private String ESTACION;
	private String USUARIO;
	private static final Integer MONUS = 34;
	private static final Integer MONUSV = 35;
	private static final Integer MONBS = 69;

	private BigDecimal tcUS = BigDecimal.valueOf(0);
	private BigDecimal tcUSV = BigDecimal.valueOf(0);
	private BigDecimal tcBS = BigDecimal.valueOf(1);
	private String usuario = "";
	private FactoryDao factoryDao;
	private ResponseContext responseContext;

	public QueryProcessor() {
		setNameSessionFactory(Constants.PROP_ALIAS_SIOC);
		log.info("nuevo QueryProcessor ha sido creado. " + getNameSessionFactory());

		factoryDao = new FactoryDao();
		Map<String, Object> mapa = new HashMap<String, Object>();
		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		mapa.put("socSolicitudesDao", socSolicitudesDao);
		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		mapa.put("socDetallessolDao", socDetallessolDao);
		SocBenefsDao socBenefsDao = new SocBenefsDao();
		mapa.put("socBenefsDao", socBenefsDao);
		SocComprobanteDao socComprobanteDao = new SocComprobanteDao();
		mapa.put("socComprobanteDao", socComprobanteDao);
		SocRengscompDao socRengscompDao = new SocRengscompDao();
		mapa.put("socRengscompDao", socRengscompDao);
		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		mapa.put("socCuentassolDao", socCuentassolDao);
		SocOperacionesDao socOperacionesDao = new SocOperacionesDao();
		mapa.put("socOperacionesDao", socOperacionesDao);
		SocDetallesopeDao socDetallesopeDao = new SocDetallesopeDao();
		mapa.put("socDetallesopeDao", socDetallesopeDao);
		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		mapa.put("socOpecomiDao", socOpecomiDao);
		SocInstrumentoDao socInstrumentoDao = new SocInstrumentoDao();
		mapa.put("socInstrumentoDao", socInstrumentoDao);
		SocMensajesDao socMensajesDao = new SocMensajesDao();
		mapa.put("socMensajesDao", socMensajesDao);
		SocDatosmenDao socDatosmenDao = new SocDatosmenDao();
		mapa.put("socDatosmenDao", socDatosmenDao);
		SocBenefslocalDao socBenefslocalDao = new SocBenefslocalDao();
		mapa.put("socBenefslocalDao", socBenefslocalDao);
		SocBolsinDao socBolsinDao = new SocBolsinDao();
		mapa.put("socBolsinDao", socBolsinDao);
		SocCambioDao socCambioDao = new SocCambioDao();
		mapa.put("socCambioDao", socCambioDao);
		SocParticipanteDao socParticipanteDao = new SocParticipanteDao();
		mapa.put("socParticipanteDao", socParticipanteDao);
		SocFacturasDao socFacturasDao = new SocFacturasDao();
		mapa.put("socFacturasDao", socFacturasDao);
		SocBenefsregDao socBenefsregDao = new SocBenefsregDao();
		mapa.put("socBenefsregDao", socBenefsregDao);
		SocOrdenesPagoDao socOrdenesPagoDao = new SocOrdenesPagoDao();
		mapa.put("socOrdenesPagoDao", socOrdenesPagoDao);
		SocEstadisticaDao socEstadisticaDao = new SocEstadisticaDao();
		mapa.put("socEstadisticaDao", socEstadisticaDao);

		for (Iterator<?> i = mapa.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			HibernateDaoSupport hibernateDaoSupport = (HibernateDaoSupport) mapa.get(key);
			hibernateDaoSupport.setSessionFactory(getSessionFactory());
			hibernateDaoSupport.getHibernateTemplate().setAllowCreate(false);
		}
		factoryDao.setDaos(mapa);
	}

	public QueryProcessor(ResponseContext responseContext) {
		this();
		this.responseContext = responseContext;
	}

	/**
	 * @param factoryDao
	 *            the factoryDao to set
	 */
	private static final Object monitor = new Object();

	public Map<String, Object> procesar(Map<String, Object> parametros) throws Exception {
		ESTACION = (String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION);
		USUARIO = (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID);
		String statusCode = Constants.OPERACION_RECEIVED;
		String consent = null;

		// String respuesta = null;
		String codigo = null;
		String solCodigo = null;
		begin();
		tcUS = getTipoCambio(MONUS, new Date());
		tcUSV = getTipoCambio(MONUSV, new Date());

		String opcion = (String) parametros.get("opcion");
		String codTipoOperacion = (String) parametros.get(Constants.AUDIT_COD_TIPO_OPERACION);

		String sIOCWEB_TIPOPERACION = "";
		if (parametros.containsKey("SIOCWEB_TIPOPERACION")) {
			sIOCWEB_TIPOPERACION = (String) parametros.get("SIOCWEB_TIPOPERACION");
			UserSessionHolder.set("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		}

		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
		log.info("===>[" + getNameSessionFactory() + "] llamando a la tarea " + opcion + "[codTipoOperacion:" + codTipoOperacion + "]["
				+ sIOCWEB_TIPOPERACION + "]");

		String sIOCServiceId = (String) parametros.get("SIOCServiceId");

		if (sIOCServiceId != null && sIOCServiceId.equals("sioc")) {
			SiocCoinService siocCoinService = new SiocCoinService();
			mapaRespuesta = siocCoinService.executeTask(parametros);
			log.info("Devolviendo mapa: " + mapaRespuesta);
			// return mapaRespuesta;
		}
		if (opcion.equals("obtenerTC")) {
			mapaRespuesta.put("tc", tcUSV);
		}

		// /////////////// control de horario //////////////

		SocHorarioDao socHorarioDao = new SocHorarioDao();
		socHorarioDao.setSessionFactory(getSessionFactory());
		Date horarecep = new Date();
		boolean enHorario = socHorarioDao.operacionEstaEnHorario(opcion, horarecep, (String) UserSessionHolder.get(Constants.COD_IFA_REQUEST));

		if (!enHorario) {
			log.error("Tipo de Operacion " + opcion + ", FUERA DE HORARIO, hora recepcion: "
					+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
			throw new RuntimeException("Tipo de Operacion " + opcion + " FUERA DE HORARIO, hora recepcion: "
					+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME) + " "
					+ (String) UserSessionHolder.get(Constants.COD_IFA_REQUEST));
		}

//		enHorario = socHorarioDao.operacionEstaEnHorario(codTipoOperacion, horarecep, (String) parametros.get(Constants.COD_IFA_REQUEST));
//
//		if (!enHorario) {
//			// temporal por ahora se verifica estos dos valores
//			log.error("Tipo de Operacion " + codTipoOperacion + ", FUERA DE HORARIO, hora recepcion: "
//					+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
//			throw new RuntimeException("Tipo de Operacion " + codTipoOperacion + " FUERA DE HORARIO, hora recepcion: "
//					+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
//		}
		// ////////////////////////

		// *************************************//
		// **********************************//
		ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
		procesosSolicitud.setSessionFactory(getSessionFactory());

		RegistrarSolicitud registrarSolicitud = new RegistrarSolicitud();
		registrarSolicitud.setSessionFactory(getSessionFactory());
		
		SwiftSiocService swiftSiocService = new SwiftSiocService();
		swiftSiocService.setSessionFactory(getSessionFactory());
		
		SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
		socUsuariosolDao.setSessionFactory(getSessionFactory());

		if (parametros.containsKey(Constants.OBJ_NAME_SOLICITUDTO)) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);

			solicitudTO.setCodEstacionAudit((String) parametros.get(Constants.AUDIT_USER_ESTACION));
			solicitudTO.setCodUsuarioAudit((String) parametros.get(Constants.AUDIT_USER_SESSION_ID));
			solicitudTO.setCodPersonaAudit((String) parametros.get(Constants.COD_IFA_REQUEST));
			solicitudTO.setCodUsuarioCont((String) parametros.get(Constants.AUDIT_USER_DATABASE_ID));
			solicitudTO.setCodTipoOperacion(codTipoOperacion);
		}

		if (opcion.equalsIgnoreCase("REG_SOLWS")) {
			Solicitud solicitudTO = new Solicitud();

			solicitudTO.setCodEstacionAudit((String) parametros.get(Constants.AUDIT_USER_ESTACION));
			solicitudTO.setCodUsuarioAudit((String) parametros.get(Constants.AUDIT_USER_SESSION_ID));
			solicitudTO.setCodPersonaAudit((String) parametros.get(Constants.COD_IFA_REQUEST));
			solicitudTO.setCodUsuarioCont((String) parametros.get(Constants.AUDIT_USER_DATABASE_ID));
			solicitudTO.setCodTipoOperacion(codTipoOperacion);

			mapaRespuesta = registrarSolicitud.procesarServicioSolicitudesWS(solicitudTO, parametros);

		} else if (opcion.equalsIgnoreCase("REG_SOLICITUD")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = registrarSolicitud.registrarSolicitud(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("REG_SOLICITUD_CC")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = registrarSolicitud.registrarSolicitudCarta(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);			

		} else if (opcion.equalsIgnoreCase("REG_CC_PAGOENMI")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = registrarSolicitud.registrarCartaPagoEnmienda(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("MOD_CARTACRED")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = registrarSolicitud.actualizarCartaSinEnmienda(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("ACT_A_FECHA")) {
			// modifica la solicitud si esta en estado P pendiente recrea el
			// detalle
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
			actualizarAFecha.setSessionFactory(getSessionFactory());			
			solicitudTO = actualizarAFecha.actualizarAFecha(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("ACT_A_FECHA_PRECON")) {
			// modifica la solicitud si esta en estado P pendiente recrea el
			// detalle
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
			actualizarAFecha.setSessionFactory(getSessionFactory());			
			solicitudTO = actualizarAFecha.actualizarAFechaPreContab(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("MOD_SOLICITUD")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.modificaSolicitud(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("ctrlcompros")) {
			// modifica la solicitud si esta en estado P pendiente recrea el
			// detalle
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.controlCompros(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("PREAUT")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.preAutorizar(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("ACT_FECHA_PREAUT")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.preAutorizarActFecha(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("PREAUTSOL")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.preAutorizarSolicitud(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("PREAUTOAUTO")) {
			// pre autoriza un proceso automatico
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.preAutorizarOperacionAutomatico(solicitudTO);
			mapaRespuesta.put("sgteoperacion", "NOTIFMEFP");			
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equals("PREAUTSWFT")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.preAutorizarSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equals("AUTSWFT")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.autorizarSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equals("AUTSOL")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.autorizar(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("APROSOL")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.autorizar(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("NOTIFMEFP")) {
			// autoriza la operacion y genera la operacion contable
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.notificarDebito(solicitudTO);

			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("RECHAZARSOL")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.rechazar(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("ANULARSOL")) {
			// crea una nueva solicitud
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.anular(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("REVOP")) {
			// crea una nueva solicitud
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			log.info("Inicio : revalidarOrdenDePago " + solicitudTO.getSolicitud().getSocCodigo());
			SocOrdenesPago socOrdenesPagoPar = solicitudTO.getSocOrdenesPagoLista().get(0);

			SocOrdenesPagoDao socOrdenesPagoDao = new SocOrdenesPagoDao();
			socOrdenesPagoDao.setSessionFactory(getSessionFactory());
			socOrdenesPagoDao.revalidarOP(socOrdenesPagoPar);
			
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("PREAUTSWFMEN")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.preAutorizarSwfMensaje(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("AUTSWIFT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.autorizarSwfMensaje(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("RECHSWIFT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.rechazarSwfMensaje(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("REG_BENEFEXT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			SocBenefsregDao socBenefsregDao = new SocBenefsregDao();
			socBenefsregDao.setSessionFactory(getSessionFactory());
			
			solicitudTO = socBenefsregDao.registrarBeneficiario(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("AUT_BENEFEXT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			SocBenefsregDao socBenefsregDao = new SocBenefsregDao();
			socBenefsregDao.setSessionFactory(getSessionFactory());
			
			solicitudTO = socBenefsregDao.autorizarBenef(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);			

		} else if (opcion.equalsIgnoreCase("RCH_BENEFEXT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			SocBenefsregDao socBenefsregDao = new SocBenefsregDao();
			socBenefsregDao.setSessionFactory(getSessionFactory());
			
			solicitudTO = socBenefsregDao.rechazarRegBenef(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);			

		} else if (opcion.equalsIgnoreCase("autorizarswift")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.autorizarSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("anularswift")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			// solicitudTO = procesosSolicitud.anularSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("autorizarswiftsinc")) {
			// actualiza la fecha de operacion
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.autorizarSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase(Constants.TIPO_OPERACION_RETIRO_AUTO)) {
			procesosSolicitud.procesarPendientesAuto(opcion);
		} else if (opcion.equalsIgnoreCase("reiniciarprocesos")) {
			ServicioSiocListener.stopScheduler();
			ServicioSiocListener.startScheduler();
			mapaRespuesta.put("respuesta", "ok");
		}

		/*********************************************************/
		/*********************************************************/
		/*********************************************************/
		/*********************************************************/

		if (opcion.equals("comisiones")) {
			// recupernado parametros enviadas por la capa web
			codigo = (String) parametros.get("codOperacion");

			List<SocOpecomi> lista = new ArrayList<SocOpecomi>();
			List<Opecomi> lista1 = new ArrayList<Opecomi>();

			// obteniendo dao de FactoryDao
			SocOpecomiDao socOpecomiDao = (SocOpecomiDao) factoryDao.getDao("socOpecomiDao");

			log.info("Solicitando lista de opeComi");
			lista = socOpecomiDao.getComis(codigo);

			BigDecimal total = BigDecimal.valueOf(0);
			BigDecimal totalU = BigDecimal.valueOf(0);
			BigDecimal montoU = BigDecimal.valueOf(0);
			for (SocOpecomi comi : lista) {
				total = total.add(comi.getOcoMonto());
				Opecomi opeComi = new Opecomi();
				OpecomiId id = new OpecomiId(Integer.valueOf(comi.getId().getClaComision()), comi.getId().getOpeCodigo(), comi.getId().getDetCodigo());
				opeComi.setId(id);
				opeComi.setOcoMonto(comi.getOcoMonto());
				montoU = comi.getOcoMonto().divide(tcUS, 2, RoundingMode.HALF_UP);
				totalU = totalU.add(montoU);
				opeComi.setOcoMontoU(montoU);
				String descripcion = "";
				switch (Integer.valueOf(comi.getId().getClaComision())) {
				case 1:
					descripcion = "TRANSFERENCIA AL EXTERIOR";
					break;
				case 2:
					descripcion = "GASTOS DE COMUNICACION";
					break;
				case 3:
					descripcion = "UTILES DE ESCRITORIO";
					break;
				case 4:
					descripcion = "VENTA DE DIVISAS";
					break;
				case 5:
					descripcion = "TRANSFERENCIA DEL EXTERIOR";
					break;
				case 6:
					descripcion = "EMISION DE CARTAS DE CREDITO";
					break;
				case 7:
					descripcion = "OTRAS COMISIONES";
					break;
				default:
					descripcion = "";
					break;
				}
				opeComi.setDescripcion(descripcion);
				opeComi.setEstilo("");
				lista1.add(opeComi);
			}
			mapaRespuesta.put("lista", lista1);
			mapaRespuesta.put("total", total);
			mapaRespuesta.put("totalU", totalU);
		}

		if (opcion.equals("nueva")) {
			log.info("ingreso de una nueva solicitud." + sIOCWEB_TIPOPERACION);
			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			SocDetallessol detalle = (SocDetallessol) parametros.get("detalle");

			SocSolicitudesDao solicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
			SocDetallessolDao detallesSolDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
			
			SocSolicitudes solicitudNew = solicitudesDao.generarSolicitud(solicitud);
			
			detallesSolDao.nuevo(solicitudNew, detalle, 1);
			mapaRespuesta.put("codSolicitud", solicitudNew.getSocCodigo());

			if (sIOCWEB_TIPOPERACION.equals("SOL_TRANS_EXT_SIST_FIN")) {
				// codigo 601 provisional para tipos de transf al exterior sist
				// financiero
				if (detalle.getDetCtabenef() == null || detalle.getDetCtabenef().compareTo(Integer.valueOf(0)) <= 0) {
					throw new RuntimeException("Cuenta del Beneficiario invalido");
				}
				
				if (StringUtils.isBlank(detalle.getDetConcepto())) {
					throw new RuntimeException("Concepto de la operación invalida");
				}				
				
				solicitud.setEsqCodigo(Constants.SOL_TRANS_EXT_SIST_FIN);
				solicitudesDao.saveOrUpdate(solicitud);
				enHorario = socHorarioDao.operacionEstaEnHorario(sIOCWEB_TIPOPERACION, horarecep,
						(String) UserSessionHolder.get(Constants.COD_IFA_REQUEST));

				if (!enHorario) {
					throw new RuntimeException("Tipo de Operacion " + sIOCWEB_TIPOPERACION + ", fuera de horario "
							+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
				}

				SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
				socSolicitanteDao.setSessionFactory(getSessionFactory());
				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudNew.getSolCodigo());

				String subject = "Registro de transferencia al exterior:" + solicitudNew.getSocCorrelativo();
				String content = MsgLogic.mensajeRegistroTransExtSistFin(solicitudNew, socSolicitante);

				socUsuariosolDao.formarMail("REGISTROTRANSEXTSISTFIN", subject, content, "'900'");

			} else if (sIOCWEB_TIPOPERACION.equals("SOL_TRANS_EXTERIOR")) {
				// OP_TRANS_EXT SOL_VDD_TRANS_EXT OP_VDD_TRANS_EXT
				// parche whf
				SocBenefsDao socBenefsDao = new SocBenefsDao();
				socBenefsDao.setSessionFactory(getSessionFactory());

				SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(detalle.getBenCodigo());
				if (socBenefs == null) {
					throw new RuntimeException("Beneficiaro inexistente " + detalle.getBenCodigo());
				}
				if (StringUtils.isBlank(socBenefs.getBenDireccion()) || StringUtils.isBlank(socBenefs.getBenPlaza())) {
					throw new RuntimeException("Beneficiaro sin datos de direccion o plaza, no puede continuar.");
				}
				
			} else if (sIOCWEB_TIPOPERACION.equals("SOL_AVISO_TRANS_DEL_EXT")) {
				
				SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
				socSolicitanteDao.setSessionFactory(getSessionFactory());
				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudNew.getSolCodigo());

				String subject = "Aviso de transferencia del exterior:" + solicitudNew.getSocCorrelativo();
				String content = MsgLogic.mensajeRegistroTransExtSistFin(solicitudNew, socSolicitante);

				socUsuariosolDao.formarMail("REGISTROTRANSEXTSISTFIN", subject, content, "'900'");
			}
		}

		if (opcion.equals("nuevaInt")) {
			// ingreso de una nueva solicitud
			log.info("ingreso de una nueva solicitud (usuario interno).");

			Map<String, Object> mapaOpe = new HashMap<String, Object>();
			Date hoy = new Date();
			solCodigo = Long.toString(hoy.getTime()); // Aqui se realiza el
														// insert
			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			SocDetallessol detalle = (SocDetallessol) parametros.get("detalle");
			Date fechaValor = (Date) parametros.get("fecha");
			usuario = USUARIO;
			solicitud.setSocCodigo(solCodigo);
			solicitud.setFecha(hoy);

			detalle.setId(new SocDetallessolId(solicitud.getSocCodigo(), 1));

			// registrando en la bbdd los datos capturados desde el formulario
			generarSolicitud(solicitud, detalle, "N");

			if (solicitud.getClaTipo().equals("TE") || solicitud.getClaTipo().equals("OB")) {
				mapaOpe = this.generarOperacion(solicitud, detalle, fechaValor, "I");

				String nroO = (String) mapaOpe.get("nroOperacion");
				String nroI = (String) mapaOpe.get("nroInst");
				mapaRespuesta.put("nroOperacion", nroO);
				mapaRespuesta.put("nroInst", nroI);
			} else {
//				String nroO = this.generarOperacionL(solicitud, detalle);
//				mapaRespuesta.put("nroOperacion", nroO);
				throw new RuntimeException("Error tipo de operacion transf local no implementado, avise a sistemas.");
			}

			if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_EXT")) {
				// SOL_VDD_TRANS_EXT OP_VDD_TRANS_EXT

				SocBenefsDao socBenefsDao = new SocBenefsDao();
				socBenefsDao.setSessionFactory(getSessionFactory());

				SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(detalle.getBenCodigo());
				if (socBenefs == null) {
					throw new RuntimeException("Beneficiaro inexistente " + detalle.getBenCodigo());
				}
				if (StringUtils.isBlank(socBenefs.getBenDireccion()) || StringUtils.isBlank(socBenefs.getBenPlaza())) {
					throw new RuntimeException("Beneficiaro sin datos de direccion o plaza, no puede continuar.");
				}
			}
		}

		if (opcion.equals("nuevaBolsin")) {
			// ingreso de una nueva solicitud
			log.info("ingreso de una nueva solicitud bolsin.");

			SocBolsin solicitudB = (SocBolsin) parametros.get("solicitud");

			// registrando en la bbdd los datos capturados desde el formulario
			SocBolsinDao bolsinDao = (SocBolsinDao) factoryDao.getDao("socBolsinDao");

			SocBolsin solicitudNew = bolsinDao.nuevoBolsin(solicitudB);

			log.info("Solicitud bolsin guardada: " + solicitudNew.getCorr() + " " + solicitudNew.getSocCodigo());

			mapaRespuesta.put("codSolicitud", solicitudNew.getSocCodigo());
		}

		if (opcion.equals("autBolsin")) {
			// ingreso de una nueva solicitud
			SocBolsin solicitudB0 = (SocBolsin) parametros.get("solicitud");
			log.info("Inicio proceso autBolsin " + opcion + " " + solicitudB0.getSocCodigo());
			// vd0

			SocBolsinDao bolsinDao = (SocBolsinDao) factoryDao.getDao("socBolsinDao");
			SocBolsin solicitudB = bolsinDao.getBySocCodigo(solicitudB0.getSocCodigo());

			if (!solicitudB.getClaEstado().equals('9') && !solicitudB.getClaEstado().equals('B')) {
				log.error("Solicitud en estado incorrecto posiblemente ya fue procesada");
				throw new RuntimeException("Solicitud en estado incorrecto posiblemente ya fue procesada");
			}

			if (solicitudB.getClaTipsolic().trim().equals("GD") || solicitudB.getClaTipsolic().trim().equals("ED")) {
				// actualizamos el monto adjudicado si es de venta directa
				solicitudB.setMontoAdj(solicitudB.getMontoSol());
			}

			solicitudB.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));
			solicitudB.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
			solicitudB.setFecha(new Date());
			log.info("XXX: solicitudB.getEstacion " + solicitudB.getEstacion());

			synchronized (monitor) {
				bolsinDao.saveOrUpdate(solicitudB);

				bolsinDao.validar(solicitudB);

				if (solicitudB.getClaTipsolic().trim().equals("G") || solicitudB.getClaTipsolic().trim().equals("E")) {
					enHorario = socHorarioDao.operacionEstaEnHorario(sIOCWEB_TIPOPERACION, horarecep,
							(String) UserSessionHolder.get(Constants.COD_IFA_REQUEST));

					if (!enHorario) {
						throw new RuntimeException("Tipo de Operacion " + sIOCWEB_TIPOPERACION + ", fuera de horario "
								+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
					}
				}

				Map<String, Object> mapaParametros = bolsinDao.provisionBolsin(factoryDao, solicitudB);

				flush();
				boolean continuar = mapaParametros.containsKey("comp");
				if (continuar) {
					// ########## proceso contable ##########
					SiocCoinService siocCoinService = new SiocCoinService();

					// agregamos el parametro para autorizacion de comprobante:
					// provision
					mapaParametros.put("consulta", "crear");

					Map<String, Object> mapaResultado = siocCoinService.executeTask(mapaParametros);
					SocComprobante comprobante0 = (SocComprobante) mapaParametros.get("comp");
					log.info("XXX: comprobante1comprobante0 " + comprobante0.getCpbNrocpbte());

					SocComprobante comprobante1 = (SocComprobante) mapaResultado.get("socComprobante");
					log.info("XXX: comprobante1comprobante1 " + comprobante1.getCpbNrocpbte());
					String nroComprob = (String) mapaResultado.get("comp");

					if (!nroComprob.equals("") && !nroComprob.equals("0000000")) {
						if (!nroComprob.equals("9999999")) {
							log.info("Comprobante coin creado: " + nroComprob);
						} else {
							log.info("Existe sobregiro en cuentas");
							throw new RuntimeException("Existe sobregiro en cuentas");
							// continuar = false;
						}
					} else {
						log.info("Error al crear comprobante coin");
						continuar = false;
					}

					if (continuar) {
						// cambiamos el estado a autorizado
						solicitudB.setClaEstado('0');
						// whf vd2
						solicitudB.setFechaHora(new Date());
						bolsinDao.saveOrUpdate(solicitudB);
						log.info("Solicitud bolsin guardada: " + solicitudB);
						mapaRespuesta.put("estado", "0");
					} else {
						mapaRespuesta.put("estado", ERROR);
					}
				}

				if (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("ED") || solicitudB.getClaTipsolic().trim().equalsIgnoreCase("GD")) {
					// si es una operacion de venta de divisas DIRECTA, se
					// procede a
					// autorizar directamente
					Map<String, Object> mapaResultado = bolsinDao.entregaBolsin(factoryDao, solicitudB, tcUS, tcUSV, tcUSV, 0);

					flush();
					log.info("commiteado sioc ");
					// agregamos el parametro para autorizacion de comprobante:
					// adjudicacion
					mapaResultado.put("consulta", "crear");

					log.info("Llamando al servicio de coin: crear comprobante");

					SiocCoinService siocCoinService = new SiocCoinService();
					Map<String, Object> mapaResultado2 = siocCoinService.executeTask(mapaResultado);

					String nroComprob = (String) mapaResultado2.get("comp");
					if (nroComprob != null && !nroComprob.equals("") && !nroComprob.equals("0000000")) {
						if (!nroComprob.equals("9999999")) {
							log.info("Comprobante coin creado: " + nroComprob);
							// cambiamos el estado a adjudicado
							solicitudB.setClaEstado('5');
							bolsinDao.saveOrUpdate(solicitudB);
							// devolvemos el estado 0 cmo exitoso
							mapaRespuesta.put("estado", "0");
						} else {
							log.info("Existe sobregiro en cuentas");
							mapaRespuesta.put("estado", ERROR);
						}
					} else {
						log.info("Error al crear Comprobante coin");
						mapaRespuesta.put("estado", ERROR);
					}
				}
				SiocCoinService.commit();
				commit();
				begin();
			}
			// begin();
			if (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("GD") || solicitudB.getClaTipsolic().trim().equalsIgnoreCase("ED")) {
				if (solicitudB.getClaEstado() != null && solicitudB.getClaEstado().equals('5')) {

					SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
					socSolicitanteDao.setSessionFactory(getSessionFactory());

					SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudB.getSolCodigo());
					SocSolicitante socSolicitanteBenef = null;

					if (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("GD")) {
						socSolicitanteBenef = socSolicitanteDao.solicitanteByCod(solicitudB.getBenef());
					} else {
						socSolicitanteBenef = socSolicitanteDao.solicitanteByCod(solicitudB.getSolCodigo());
					}

					String subject = "Operaciones Cambiarias: Autorizacion de Venta Directa de Divisas";
					String content = MsgLogic.mensajeSolicitudBolsin(solicitudB, socSolicitante, socSolicitanteBenef, subject);

					socUsuariosolDao.formarMail("SOLVENTADIRECTA", subject, content, "'900','" + solicitudB.getSolCodigo() + "'");

				}

			}
		}

		if (opcion.equals("anularBolsin")) {
			// Anular Solicitud
			log.info("Anular Solicitud Bolsin.");

			SocBolsin solicitudB0 = (SocBolsin) parametros.get("solicitud");

			// cambiando la solicitud en estado de anulado "A"
			SocBolsinDao bolsinDao = (SocBolsinDao) factoryDao.getDao("socBolsinDao");
			SocBolsin solicitudB = bolsinDao.getBySocCodigo(solicitudB0.getSocCodigo());

			if (!solicitudB.getClaEstado().equals('9') && !solicitudB.getClaEstado().equals('B')) {
				log.error("La Solicitud " + solicitudB.getCorr() + " se encuentra en estado procesado. No puede anular.");
				throw new RuntimeException("La Solicitud " + solicitudB.getCorr() + " se encuentra en estado procesado. No puede anular.");
			}

			solicitudB.setClaEstado('Z');
			bolsinDao.saveOrUpdate(solicitudB);

			mapaRespuesta.put("estado", "Z");
		}

		if (opcion.equals("nuevas")) {// ingreso de una nueva solicitud varios
			log.info("ingreso de una nueva solicitud varios.");

			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			List<SocDetallessol> listaDetalle = (List<SocDetallessol>) parametros.get("detalles");
			for (SocDetallessol socDetallessol : listaDetalle) {
				if (sIOCWEB_TIPOPERACION.equals("SOL_VDD_TRANS_EXT")) {
					// SOL_VDD_TRANS_EXT OP_VDD_TRANS_EXT

					SocBenefsDao socBenefsDao = new SocBenefsDao();
					socBenefsDao.setSessionFactory(getSessionFactory());

					SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(socDetallessol.getBenCodigo());
					if (socBenefs == null) {
						throw new RuntimeException("Beneficiaro inexistente " + socDetallessol.getBenCodigo());
					}
					if (StringUtils.isBlank(socBenefs.getBenDireccion()) || StringUtils.isBlank(socBenefs.getBenPlaza())) {
						throw new RuntimeException("Beneficiaro sin datos de direccion o plaza, no puede continuar.");
					}
				}
			}

			SocSolicitudesDao solicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
			solicitud = solicitudesDao.generarSolicitud(solicitud);

			SocDetallessolDao detallesSolDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
			detallesSolDao.nuevo(solicitud, listaDetalle);

			// registrando en la bbdd los datos capturados desde el formulario
			// generarSolicitud(solicitud, listaDetalle);

			mapaRespuesta.put("codSolicitud", solicitud.getSocCodigo());
		}

		if (opcion.equals("modificar")) {// modificar una solicitud
			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			SocDetallessol detalle = (SocDetallessol) parametros.get("detalle");

			// registrando en la bbdd los datos capturados desde el formulario
			generarSolicitud(solicitud, detalle, "M");
			mapaRespuesta.put("codSolicitud", solicitud.getSocCodigo());
		}

		if (opcion.equals("autSol")) {// Generar provisiÃ³n
			log.info("Autorizar solicitud.");

			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");

			// cambiando la solicitud en estado de verificado "V"
			SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
			solicitud.setClaEstado('V');
			socSolicitudesDao.saveOrUpdate(solicitud);
			log.info("Estado actualizado: V");

			mapaRespuesta.put("estado", "V");
		}

		if (opcion.equals("provision")) {
			// Generar provisiÃ³n
			log.info("Generar provisiÃ³n.");

			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
			socSolicitudesDao.setSessionFactory(getSessionFactory());
			solicitud = socSolicitudesDao.getSolicitud(solicitud.getSocCodigo());
			
			if (solicitud == null) {
				throw new RuntimeException("Solicitud inexistente");
			}
			
			log.info("XXX: solicitud " + solicitud.toString());
			
			if (solicitud.getClaEstado() == null) {
				throw new RuntimeException("Estado de la solicitud nulo, comunique a sistemas");
			}
			
			SocDetallessol detalle = (SocDetallessol) parametros.get("detalle");

			if (detalle.getDetCtabenef().compareTo(Integer.valueOf(-1)) == 0) {
				throw new RuntimeException("Cuenta del Beneficiario invalido");
			}

			String tipoEnt = Servicios.getTipoEnt(solicitud.getSolCodigo());

			if (!StringUtils.isBlank(tipoEnt)) {
				
				if (solicitud.getEsqCodigo() != null && solicitud.getEsqCodigo().equals(Constants.SOL_TRANS_EXT_SIST_FIN)) {
					if (solicitud.getClaEstado() != 'B') {
						throw new RuntimeException("Estado de la solicitud inválida " + solicitud.getClaEstado() + ", posiblemente ya fue procesada o eliminada.");
					}
				}
				
				Boolean continuar = true;

				// CCUH SIOC V.2
				// R-02 Suprimir provisiÃ³n para transferencia en otras monedas
				// Ya no se genera el comprobante
				// 03-07-2013
				if (solicitud.getClaTipo().equals("TC") || solicitud.getMonedaT().equals("USD")) {
					log.info("XXX: 333solicitud.getClaTipo() " + (solicitud.getClaTipo() == null) + " solicitud.getMonedaT() "
							+ (solicitud.getMonedaT() == null));
					continuar = GenerarComprobante.generarComprobante(factoryDao, solicitud, detalle, tipoEnt, tcUS, "PROVISION");
					log.info("XXX: 4444solicitud.getClaTipo() " + solicitud.getClaTipo() + " solicitud.getMonedaT() " + solicitud.getMonedaT());
					flush();
				}

				if (continuar) {
					// cambiando la solicitud en estado de recibido "R"

					solicitud.setClaEstado('R');
					socSolicitudesDao.saveOrUpdate(solicitud);
					log.info("Estado actualizado: R");

					if (solicitud.getClaTipo().equals("TC")) {
						GenerarAutomatica.generarAutomatica(factoryDao, solicitud, detalle, tcUS, usuario, ESTACION, "TC");
						solicitud.setClaEstado('O');
						socSolicitudesDao.saveOrUpdate(solicitud);
						log.info("Estado actualizado: O");
					}
					mapaRespuesta.put("estado", "R");
				} else {
					throw new RuntimeException("El tipo de solictud debe ser Transferencia a Cuenta o la moneda USD ");
				}
			} else
				throw new RuntimeException("error al buscar tipo de entidad " + solicitud.getSolCodigo());
		}

		// CCUH SIOC V.2
		// R-04 Incluir opciones separadas para IDH, RegalÃ­as
		// Se crearon opciones separadas para generar comprobantes
		// 01-07-2013
		if (opcion.equals("provisionReg")) // Generar provisiÃ³n pago de
											// regalÃ­as
		{
			log.info("Generar provisiÃ³n regalÃ­as.");

			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			SocDetallessol detalle = (SocDetallessol) parametros.get("detalle");

			String tipoEnt = Servicios.getTipoEnt(solicitud.getSolCodigo());

			if (!StringUtils.isBlank(tipoEnt)) {
				Boolean continuar = GenerarComprobante.generarComprobante(factoryDao, solicitud, detalle, tipoEnt, tcUS, "REG");
				if (continuar) {
					// cambiando la solicitud en estado de recibido "R"
					SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
					solicitud.setClaEstado('R');
					socSolicitudesDao.saveOrUpdate(solicitud);
					log.info("Estado actualizado: R");

					GenerarAutomatica.generarAutomatica(factoryDao, solicitud, detalle, tcUS, usuario, ESTACION, "REG");
					solicitud.setClaEstado('O');
					socSolicitudesDao.saveOrUpdate(solicitud);
					log.info("Estado actualizado: O");

					mapaRespuesta.put("estado", "R");
				} else {
					mapaRespuesta.put("estado", "-1");
				}
			} else {
				mapaRespuesta.put("estado", "-1");
			}
		}


		if (opcion.equals("provisionS")) {
			// Sï¿½lo se provisiona comisiones
			log.info("Provision SIGMA");

			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			String subtipo = (String) parametros.get("subtipo");

			SocDetallessolDao socDetallessolDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
			List<SocDetallessol> detalles = socDetallessolDao.getDetalles(solicitud.getSocCodigo());

			// CCUH SIOC V.2
			// R-03 Suprimir provisiÃ³n comisiones en Ventas a travÃ©s del SIGMA
			// Ya no se genera el comprobante
			// 03-07-2013
			// Boolean continuar = generarComprobante(solicitud, detalles,
			// subtipo);

			SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
			solicitud.setClaEstado('R');
			socSolicitudesDao.saveOrUpdate(solicitud);

			mapaRespuesta.put("estado", "R");
		}

		if (opcion.equals("provisionV")) // Generar provisiÃ³n cuenta fiscal
		{
			log.info("Generar provisiÃ³n cuenta fiscal.");

			Boolean continuar = true;

			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			String subtipo = (String) parametros.get("subtipo");

			SocDetallessolDao socDetallessolDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
			List<SocDetallessol> detalles = socDetallessolDao.getDetalles(solicitud.getSocCodigo());

			// CCUH SIOC V.2
			// R-03 Suprimir provisiÃ³n para ventas para transferencia en otras
			// monedas
			// Ya no se genera el comprobante
			// 03-07-2013
			// R-03 Suprimir provisiÃ³n comisiones en Ventas a travÃ©s de cuenta
			// fiscal
			// Se creÃ³ un nuevo esquema sin renglones de comisiones para VE
			// 03-07-2013
			if (solicitud.getMonedaT().equals("USD")) {
				continuar = GenerarComprobante.generarComprobante(factoryDao, solicitud, detalles, subtipo, tcUS);
			}

			if (continuar) {
				// cambiando la solicitud en estado de recibido "R"
				SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
				solicitud.setClaEstado('R');
				socSolicitudesDao.saveOrUpdate(solicitud);

				mapaRespuesta.put("estado", "R");
			} else {
				mapaRespuesta.put("estado", "-1");
			}
		}

		if (opcion.equals("anular")) {
			// Anular Solicitud
			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			log.info("Anular Solicitud: " + solicitud.toString());
			// cambiando la solicitud en estado de anulado "A"
			SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
			SocSolicitudes solicitud0 = socSolicitudesDao.getSolicitud(solicitud.getSocCodigo());
			solicitud0.setClaEstado('A');
			socSolicitudesDao.saveOrUpdate(solicitud0);

			mapaRespuesta.put("estado", "A");
		}

		if (opcion.equals("solBCB")) {
			// Registrar BCB
			log.info("Autorizar Solicitud BCB.");

			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");

			// cambiando la solicitud en estado de registro "R"
			SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
			solicitud.setClaEstado('R');
			socSolicitudesDao.saveOrUpdate(solicitud);

			mapaRespuesta.put("estado", "R");
		}

		if (opcion.equals("subasta")) {
			List<SocBolsin> listaBolsin = (List<SocBolsin>) parametros.get("solicitudes");
			BigDecimal base = (BigDecimal) parametros.get("base");

			if (base == null || base.compareTo(BigDecimal.ZERO) <= 0) {
				log.error("Tipo de cambio base incorrecto revise datos");
				throw new RuntimeException("Tipo de cambio base incorrecto revise datos");
			}
			listaBolsin = gob.bcb.bpm.pruebaCU.Servicios.getSocBolsinList("'0'", null, null, "'E','G'");
			if (listaBolsin == null || listaBolsin.size() == 0) {
				log.error("Subasta sin solicitudes posiblemente ya fueron procesadas o intente nuevamente");
				// throw new
				// RuntimeException("Subasta sin solicitudes posiblemente ya fueron procesadas o intente nuevamente");
			}
			char estado = procesarSubasta(base);
			flush();
			log.info("Estado actualizado: " + estado);
			if (estado == 'Z') {
				mapaRespuesta.put("estado", "-1");
			} else {
				mapaRespuesta.put("estado", "1");
			}
		}

		if (opcion.equals("sinSubasta")) {
			BigDecimal base = (BigDecimal) parametros.get("base");

			if (base == null || base.compareTo(BigDecimal.ZERO) <= 0) {
				log.error("Tipo de cambio base incorrecto revise datos");
				throw new RuntimeException("Tipo de cambio base incorrecto revise datos");
			}

			// char estado = sinSubasta(base);
			char estado = procesarSubasta(base);
			String respEstado = String.valueOf(estado);
			flush();
			log.info("Estado actualizado: " + respEstado);
			mapaRespuesta.put("estado", respEstado);
		}

		if (opcion.equals("publicar")) {
			Date fecha = (Date) parametros.get("fecha");

			SocCambioDao socCambioDao = new SocCambioDao();
			socCambioDao.setSessionFactory(getSessionFactory());

			SocCambio socCambio = socCambioDao.getCambio(fecha);
			if (socCambio == null) {
				throw new BusinessException("No existe registrado tipo de cambio, posiblemente no se efectuo la tarea de subasta "
						+ UtilsDate.stringFromDate(fecha, "dd/MM/yyyy"));
			}
			if (!socCambio.getClaEstado().equals("1")) {
				throw new BusinessException("Estado de subasta incorrecto, posiblemente ");
			}

			BolsinService bolsinService = new BolsinService();
			mapaRespuesta.put("estado", ERROR);
			bolsinService.doPublicar(fecha);
			flush();
			mapaRespuesta.put("estado", "P");
		}

		if (opcion.equals("revisaVDAuto")) {
			// Revision de solicituddes de Venta directa
			SocBolsinDao socBolsinDao = new SocBolsinDao();
			socBolsinDao.setSessionFactory(getSessionFactory());
			socBolsinDao.revisaPendientesVentadirecta();
		}

		if (opcion.equals("adjudicacion")) {
			// se verifica que la fecha actual es habil o no
			BolsinService bolsinService = new BolsinService();
			BolsinService.setSessionFactory(getSessionFactory());
			String tipoEjecucion = (String) parametros.get("tipoejecucion");
			// se verifica si la ejecucion es automativa o no
			boolean esAutomatica = (tipoEjecucion != null) && tipoEjecucion.contains(tipoEjecucion) && tipoEjecucion.equalsIgnoreCase("automatica");

			Map<String, String> msgRepuesta = bolsinService.adjudicar(factoryDao, esAutomatica);

			flush();
			// si es automatica se envia correo a los interesados
			if (esAutomatica) {
				String subject = "Adjudicacion automatica de fecha: " + UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy");
				String content = MsgLogic.mensajeAdjudicacionAuto(msgRepuesta);

				socUsuariosolDao.formarMail("ADJUDICACIONAUTO", subject, content, "'900'");
			}
			mapaRespuesta.put("resp_codmsg", "0");
			mapaRespuesta.put("resp_descripmsg", "Proceso de adjudicacion finalizada. " + ArrayUtils.toString(msgRepuesta));
		}

		if (opcion.equals("operacion")) {
			Map<String, Object> mapaOpe = new HashMap<String, Object>();
			SocSolicitudes solicitud = (SocSolicitudes) parametros.get("solicitud");
			SocDetallessol detalle = (SocDetallessol) parametros.get("detalle");
			Date fechaValor = (Date) parametros.get("fecha");
			usuario = USUARIO;
			log.info("XXX:###############################################################");
			log.info("Fecha de la operaciÃ³n: " + fechaValor);

			mapaOpe = this.generarOperacion(solicitud, detalle, fechaValor, "");

			String nroO = (String) mapaOpe.get("nroOperacion");
			String nroI = (String) mapaOpe.get("nroInst");
			flush();
			mapaRespuesta.put("nroOperacion", nroO);
			mapaRespuesta.put("nroInst", nroI);
		}

		if (opcion.equals("actualizar")) {
			log.info("XXX:20140707 actualizar........");
			SocOperaciones operacion = (SocOperaciones) parametros.get("operacion");
			BigDecimal tc = getTipoCambio(operacion.getMoneda(), new Date());

			GenerarFechaValor.generarTE(getSessionFactory(), factoryDao, operacion, tcUS, tc);
			mapaRespuesta.put("estado", "1");
		}

		if (opcion.equals("actualizarV")) {
			log.info("XXX:20140707 actualizarVV........");
			SocOperaciones operacion = (SocOperaciones) parametros.get("operacion");
			BigDecimal tc = (BigDecimal) parametros.get("tc");

			GenerarFechaValor.generarVE(getSessionFactory(), factoryDao, operacion, tcUS, tc, tcUSV);
			mapaRespuesta.put("estado", "1");
		}

		if (opcion.equals("verificar")) {
			// es ejecutado cuando se genera el mensaje swift solo
			// la fecha de operaciÃ³n es diferente
			log.info("Verificar mensaje.");

			// recupernado parametros enviadas por la capa web
			SocMensajes mens0 = (SocMensajes) parametros.get("mensaje");

			SocMensajesDao socMenDao = (SocMensajesDao) factoryDao.getDao("socMensajesDao");

			SocMensajes mens = (SocMensajes) socMenDao.getMensaje(mens0.getInsCodigo());

			if (mens != null && mens.getClaEstadomen().equals("E")) {

				SocParametrosDao socParametrosDao = new SocParametrosDao();
				socParametrosDao.setSessionFactory(getSessionFactory());

				SocParametros socParametros = socParametrosDao.getByCodigo(ConstantsSwift.PARAM_PATHSWIFT);

				String pathSwift = socParametros.getParValor();

				String mensajeSwift = Swift.crearSwiftTexto(mens.getInsCodigo());
				String nameFile = "sioc" + UtilsDate.stringFromDate(mens.getMenFechavalor(), "yyyy") + "_" + mens.getMenNroswift() + ".dos";
				// creamos el directorio si no existe

				String pathFileBck = pathSwift + "Backup/" + nameFile;
				String ptmp = UtilsFile.grabaEnArchivo(mensajeSwift, pathFileBck);

				String pathFileServSwift = pathSwift + "Autorizados/" + nameFile;
				String pathFile = pathSwift + "/" + nameFile;

				log.info("Swift en Backup [" + mens.getInsCodigo() + "] generado!!! en " + ptmp);

				try {
					File h = new File(pathFileServSwift);
					if (h.exists() && !h.isDirectory()) {
						log.info("=====%%% ATENCION!!! %%%=======");
						log.info("SWIFT [" + mens.getInsCodigo() + "] autorizado en archivo " + pathFileServSwift);
						log.info("SE RE - INTENTO AUTORIZAR EL MENSAJE, REVISAR MENSAJES ANTERIORES, POSIBLES ERROR EN AUTORIZACION ANTERIOR");
						log.info("=====%%% ATENCION!!! %%%=======");
					} else {
						// whf: se agrega proceso de pre autorizacion por lavado
						ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc(getSessionFactory());
						clienteLvdSioc.initClienteLvd();
						clienteLvdSioc.getSessionLavado(usuario);
						
						// en mens.getDetCodigo se almacena el nro lavado
						if (clienteLvdSioc.getClienteLvd() != null && (mens.getDetCodigo() != null && mens.getDetCodigo().compareTo(0) > 0)){
							clienteLvdSioc.preautorizarSwift(mens.getOpeCodigo(), usuario, mens.getDetCodigo(), mens.getMenNroswift(), mensajeSwift);
						} else{
							String p = UtilsFile.copiarArchivo(pathFileBck, pathFile, true);
							log.info("SWIFT AUTORIZADO!! [" + mens.getInsCodigo() + "] generado!!! en " + p);
						}
						
						clienteLvdSioc.cerrarSession(usuario);
						
						UtilsFile.copiarArchivo(pathFileBck, pathFileServSwift, false);
						log.info("Mensaje [" + mens.getInsCodigo() + "] de respaldo de autorizacion en " + pathFileServSwift);
					}
				} catch (Exception e) {
					log.error("Swift[" + mens.getInsCodigo() + "]: error al AUTORIZAR swift " + pathFile + ": " + e.getMessage(), e);
					throw new RuntimeException("Swift[" + mens.getInsCodigo() + "]: error al AUTORIZAR swift " + pathFile + ": " + e.getMessage(), e);
				}

				// guardamos el registro con el estado de que el
				// archivo fue guardado
				// PERO lo realizamos nativamente en otra
				// transacciÃ³n
				// el mensaje SWIFT debe ser guardado aun si la
				// transacciÃ³n tuvo errores
				socMenDao.grabaMensajeSwift(mens.getInsCodigo());
			}

			flush();
			log.info("Estado mensaje actualizado");
			mapaRespuesta.put("estado", "V");
		}
		if (opcion.equals("rechazarSwift")) {
			// es ejecutado cuando se genera el mensaje swift solo
			// la fecha de operaciÃ³n es diferente
			log.info("Rechazar mensaje.");

			// recupernado parametros enviadas por la capa web
			SocMensajes mens = (SocMensajes) parametros.get("mensaje");

			SocMensajesDao socMenDao = (SocMensajesDao) factoryDao.getDao("socMensajesDao");
			mens.setClaEstadomen("Z");
			socMenDao.saveOrUpdate(mens);

			flush();
			log.info("Estado mensaje rechazado");
			mapaRespuesta.put("estado", "Z");
		}

		if (opcion.equals("rechazar")) {
			log.info("Rechazar operaciÃ³n.");

			// recupernado parametros enviadas por la capa web
			codigo = (String) parametros.get("codOperacion");

			SocOperacionesDao socOperDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");
			SocOperaciones oper = socOperDao.getOperacionByCod(codigo);

			if (oper.getClaEstado() != null && !oper.getClaEstado().equals('P')) {
				log.error("La operacion se encuentra con estado incorrecto cod: " + oper.getOpeCodigo() + ", estado: " + oper.getClaEstado());
				throw new RuntimeException("La operacion se encuentra con estado incorrecto cod: " + oper.getOpeCodigo() + ", estado: "
						+ oper.getClaEstado());
			}

			oper.setClaEstado(RECHAZADO);
			socOperDao.saveOrUpdate(oper);

			flush();
			log.info("Estado actualizado");

			mapaRespuesta.put("estado", "Z");
		}

		if (opcion.equals("autorizar")) {
			// recuperando parametros enviadas por la capa web
			codigo = (String) parametros.get("codOperacion");
			String subTipoOperComp = (String) parametros.get("subtipo");
			if (subTipoOperComp == null) {
				subTipoOperComp = "";
			}
			log.info("Autorizar operaciÃ³n: " + codigo + " : " + subTipoOperComp);

			SocOperacionesDao socOperDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");
			SocOperaciones oper = socOperDao.getOperacionByCod(codigo);

			if (oper.getClaEstado() == null || !oper.getClaEstado().equals('P')) {
				log.error("La operacion cod: " + oper.getOpeCodigo() + ", se encuentra con estado incorrecto estado: " + oper.getClaEstado());
				throw new RuntimeException("La operacion cod: " + oper.getOpeCodigo() + ", se encuentra con estado incorrecto estado: "
						+ oper.getClaEstado());
			}

			SocDetallesopeDao socDetallesopeDao = (SocDetallesopeDao) factoryDao.getDao("socDetallesopeDao");
			List<SocDetallesope> dets = socDetallesopeDao.getDetalles(codigo);

			if (dets == null || dets.size() == 0) {
				log.error("No se encontraron detalles de operacion " + codigo);
				throw new RuntimeException("No se encontraron detalles de operacion " + codigo);
			}

			SocParametrosDao socParametrosDao = new SocParametrosDao();
			socParametrosDao.setSessionFactory(getSessionFactory());

			SocParametros socParametros = socParametrosDao.getByCodigo(ConstantsSwift.PARAM_PATHSWIFT);

			String pathSwift = socParametros.getParValor();

			for (SocDetallesope det : dets) {
				int tipo = Servicios.getTipoInst(det.getInsCodigo());
				if (tipo == 1) {

					SocMensajesDao socMenDao = (SocMensajesDao) factoryDao.getDao("socMensajesDao");
					SocMensajes mens = (SocMensajes) socMenDao.getMensaje(det.getInsCodigo());

					if (mens != null && mens.getClaEstadomen().equals("E")) {
						String mensajeSwift = Swift.crearSwiftTexto(mens.getInsCodigo());
						String nameFile = "sioc" + UtilsDate.stringFromDate(mens.getMenFechavalor(), "yyyy") + "_" + mens.getMenNroswift() + ".dos";
						// creamos el directorio si no existe

						String pathFileBck = pathSwift + "Backup/" + nameFile;
						String ptmp = UtilsFile.grabaEnArchivo(mensajeSwift, pathFileBck);

						String pathFileServSwift = pathSwift + "Autorizados/" + nameFile;
						String pathFile = pathSwift + "/" + nameFile;

						log.info("Swift en Backup [" + mens.getInsCodigo() + "] generado!!! en " + ptmp);
						try {
							File h = new File(pathFileServSwift);
							if (h.exists() && !h.isDirectory()) {
								log.info("=====%%% ATENCION!!! %%%=======");
								log.info("SWIFT [" + mens.getInsCodigo() + "] autorizado en archivo " + pathFileServSwift);
								log.info("SE RE - INTENTO AUTORIZAR EL MENSAJE, REVISAR MENSAJES ANTERIORES, POSIBLES ERROR EN AUTORIZACION ANTERIOR");
								log.info("=====%%% ATENCION!!! %%%=======");
							} else {
								ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc(getSessionFactory());
								clienteLvdSioc.initClienteLvd();
								clienteLvdSioc.getSessionLavado(usuario);
								
								// en mens.getDetCodigo se almacena el nro lavado
								if (clienteLvdSioc.getClienteLvd() != null && (mens.getDetCodigo() != null && mens.getDetCodigo().compareTo(0) > 0)){
									clienteLvdSioc.preautorizarSwift(mens.getOpeCodigo(), usuario, mens.getDetCodigo(), mens.getMenNroswift(), mensajeSwift);
								} else{
									String p = UtilsFile.copiarArchivo(pathFileBck, pathFile, true);
									log.info("SWIFT AUTORIZADO!! [" + mens.getInsCodigo() + "] generado!!! en " + p);
								}
								clienteLvdSioc.cerrarSession(usuario);
								
								UtilsFile.copiarArchivo(pathFileBck, pathFileServSwift, false);
								log.info("Mensaje [" + mens.getInsCodigo() + "] de respaldo de autorizacion en " + pathFileServSwift);
							}
						} catch (Exception e) {
							log.error("Swift[" + mens.getInsCodigo() + "]: error al AUTORIZAR swift " + pathFile + ": " + e.getMessage(), e);
							throw new RuntimeException("Swift[" + mens.getInsCodigo() + "]: error al AUTORIZAR swift " + pathFile + ": "
									+ e.getMessage(), e);
						}

						// guardamos el registro con el estado de que el
						// archivo fue guardado
						// PERO lo realizamos nativamente en otra
						// transacciÃ³n
						// el mensaje SWIFT debe ser guardado aun si la
						// transacciÃ³n tuvo errores
						socMenDao.grabaMensajeSwift(mens.getInsCodigo());
					}
				}
			}

			String nroComprobOper = "";

			SocComprobanteDao socCompDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
			List<SocComprobante> comps = socCompDao.comprobantesByOpeCodigo(codigo);

			if (comps != null && comps.size() > 0) {
				SocRengscompDao socRengscompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
				SocFacturasDao socFacturasDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
				SocOperacionesDao socOperacionesDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");

				// ciclo de aprobacion de comprobantes sin utiles
				for (SocComprobante comp : comps) {
					// //////////////////////////////////////
					// PARCHE 20140519 para TDs actualizamos los
					// comprobantes de
					// utiles la glosa
					if (comp.getEsqCodigo() != null && (comp.getEsqCodigo().compareTo(0) > 0)) {
						SocOperaciones operacion = socOperacionesDao.getOperacionByCod(codigo);
						if (operacion == null) {
							log.error("Error!! lo siento no se pudo encontrar la operacion : " + codigo + " comunique a sistemas");
							throw new RuntimeException("Error!! lo siento no se pudo encontrar la operacion : " + codigo + " comunique a sistemas");
						}

						if (operacion.getClaOperacion().equalsIgnoreCase("TD") && !StringUtils.isBlank(comp.getCveDettipocomp())
								&& comp.getCveDettipocomp().equals("U")) {
							// es un comprobante de una oepracion de TD
							// utiles no se procesa por ahora el mismo se
							// procesa en el siguiente ciclo
							continue;
						}
					}
					List<SocRengscomp> rengs = socRengscompDao.getRenglones(comp.getCpbCodigo());
					List<SocFacturas> facts = socFacturasDao.getFacturas(comp.getCpbCodigo());

					Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
					mapaParametros2.put("consulta", "crear");
					mapaParametros2.put("comp", comp);
					mapaParametros2.put("rengs", rengs);
					mapaParametros2.put("facts", facts);

					SiocCoinService siocCoinService = new SiocCoinService();
					Map<String, Object> mapaResultado2 = siocCoinService.executeTask(mapaParametros2);

					String nroCpbNrocpbteUtil = (String) mapaResultado2.get("comp");
					if (StringUtils.isBlank(nroCpbNrocpbteUtil)) {
						log.error("El servicio contable retorno nro comprobante invalido cod: " + nroCpbNrocpbteUtil);
						throw new RuntimeException("El servicio contable retorno nro comprobante invalido cod: " + nroCpbNrocpbteUtil);
					}
					comp.setCpbNrocpbte(nroCpbNrocpbteUtil);
					socCompDao.saveOrUpdate(comp);

					// codigo que se usa en las otras opciones de mas abajo,
					// aunque es cuestinable (si tiene la oper mas de uno no
					// funciona) ... revisar
					nroComprobOper = nroCpbNrocpbteUtil;
					flush();
					// ////////////////////////////////////
				}

				// segundo ciclo complemento de glosas utiles operaciones TD
				for (SocComprobante comp : comps) {
					if (comp.getEsqCodigo() != null && (comp.getEsqCodigo().compareTo(0) > 0)) {
						SocOperaciones operacion = socOperacionesDao.getOperacionByCod(codigo);
						if (operacion == null) {
							log.error("Error!! lo siento no se pudo encontrar la operacion : " + codigo + " comunique a sistemas");
							throw new RuntimeException("Error!! lo siento no pude encontrar la operacion : " + codigo + " comunique a sistemas");
						}

						if (operacion.getClaOperacion().equalsIgnoreCase("TD") && !StringUtils.isBlank(comp.getCveDettipocomp())
								&& comp.getCveDettipocomp().equals("U")) {

							log.info("Actualizando y aprobando comprobante de utiles de operaciones TD {CpbCodigo= " + comp.getCpbCodigo()
									+ ", opeCodigo=" + comp.getOpeCodigo() + "] ");
							if (StringUtils.isBlank(comp.getCpbCodigoref())) {
								log.error("comprobante de Transf. del Ext. : " + comp.getCpbCodigo()
										+ " de tipo Utiles sin codigo de comprobante referenciado. avise a sistemas");
								throw new RuntimeException("comprobante de Transf. del Ext. : " + comp.getCpbCodigo()
										+ " de tipo Utiles sin codigo de comprobante referenciado. avise a sistemas");
							}

							SocComprobante socComprobante = socCompDao.getComprobante(comp.getCpbCodigoref());
							if (socComprobante == null) {
								log.error("comprobante de Transf. del Ext. referenciado: " + comp.getCpbCodigoref()
										+ " de tipo Utiles inexistente. avise a sistemas");
								throw new RuntimeException("comprobante de Transf. del Ext. referenciado: " + comp.getCpbCodigoref()
										+ " de tipo Utiles inexistente. avise a sistemas");
							}
							// // // // // // // // //
							// actualizamos la glosa del comprobante de utiles
							comp.setCpbGlosa(comp.getCpbGlosa() + " EN COMPLEMENTO AL COMPROBANTE CONTABLE G-" + socComprobante.getCpbNrocpbte()
									+ " DE LA FECHA");
							// // // // // // // // //

							List<SocRengscomp> rengs = socRengscompDao.getRenglones(comp.getCpbCodigo());
							List<SocFacturas> facts = socFacturasDao.getFacturas(comp.getCpbCodigo());

							Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
							mapaParametros2.put("consulta", "crear");
							mapaParametros2.put("comp", comp);
							mapaParametros2.put("rengs", rengs);
							mapaParametros2.put("facts", facts);

							SiocCoinService siocCoinService = new SiocCoinService();
							Map<String, Object> mapaResultado2 = siocCoinService.executeTask(mapaParametros2);

							String nroCpbNrocpbteUtil = (String) mapaResultado2.get("comp");
							if (StringUtils.isBlank(nroCpbNrocpbteUtil)) {
								log.error("El servicio contable retorno nro comprobante invalido cod: " + nroCpbNrocpbteUtil);
								throw new RuntimeException("El servicio contable retorno nro comprobante invalido cod: " + nroCpbNrocpbteUtil);
							}
							comp.setCpbNrocpbte(nroCpbNrocpbteUtil);
							socCompDao.saveOrUpdate(comp);
						}
					}

					// ////////////////////////////////////
				}

				if (subTipoOperComp.equals("OP")) {
					String query = "select i.ins_codigo, i.ins_monto, i.moneda, i.ins_concepto, p.opa_reng, p.opa_imp, p.opa_benef "
							+ "from soc_instrumento i, soc_detallesope d, soc_operaciones o, soc_ordenespago p "
							+ "where i.ins_codigo = d.ins_codigo " + "and d.ope_codigo = o.ope_codigo " + "and i.ins_codigo = p.ins_codigo "
							+ "and d.ope_codigo = '" + codigo + "'";

					OrdenPago op = null;
					String codInst = "";
					List<OrdenPago> ops = new ArrayList<OrdenPago>();

					List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query,
							"ins_codigo, ins_monto, moneda, ins_concepto, opa_reng, opa_imp, opa_benef".split(","));
					if (resultado1.size() > 0) {
						for (Map<String, Object> res : resultado1) {
							log.info("resultado" + res.toString());
							op = new OrdenPago((String) res.get("ins_codigo"), (Integer) res.get("opa_reng"), (Integer) res.get("opa_imp"), 'I',
									(BigDecimal) res.get("ins_monto"), (Integer) res.get("moneda"), (String) res.get("opa_benef"),
									(String) res.get("ins_concepto"));
							ops.add(op);
						}
					}

					Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
					mapaParametros3.put("consulta", "ops");
					mapaParametros3.put("comp", nroComprobOper);
					mapaParametros3.put("ops", ops);

					log.info("Llamando al servicio de coin: crear OP");

					SiocCoinService siocCoinService = new SiocCoinService();
					siocCoinService.executeTask(mapaParametros3);

					SocOrdenesPagoDao socOPDao = (SocOrdenesPagoDao) factoryDao.getDao("socOrdenesPagoDao");

					for (OrdenPago op2 : ops) {
						codInst = op2.getNroComprob();
						SocOrdenesPago op1 = (SocOrdenesPago) socOPDao.getOrden(codInst);

						op1.setOpaNroordenpago(nroComprobOper);
						op1.setClaEstadoopa('C');
						socOPDao.saveOrUpdate(op1);
						log.info("OP actualizada");
					}

				} else if (subTipoOperComp.equals("RG")) {
					String ins = "";
					String query = "select p.ins_codigo, p.opa_nroordenpago, p.opa_reng, p.opa_imp "
							+ "from soc_detallesope d, soc_operaciones o, soc_ordenespago p " + "where d.ope_codigo = o.ope_codigo "
							+ "and d.ins_codigo = p.ins_codigo " + "and d.ope_codigo = '" + codigo + "' " + "and p.cla_estadoopa = 'P'";

					List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query,
							"ins_codigo, opa_nroordenpago, opa_reng, opa_imp".split(","));
					if (resultado1.size() == 1) {
						for (Map<String, Object> res : resultado1) {
							String nroComp = (String) res.get("opa_nroordenpago");
							int imp = (Integer) res.get("opa_imp");
							ins = (String) res.get("ins_codigo");

							Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
							mapaParametros3.put("consulta", "opaA");
							mapaParametros3.put("comp", nroComp);
							mapaParametros3.put("imp", imp);

							log.info("Llamando al servicio de coin: anular OP");
							SiocCoinService siocCoinService = new SiocCoinService();
							siocCoinService.executeTask(mapaParametros3);

							SocOrdenesPagoDao socOrdenDao = (SocOrdenesPagoDao) factoryDao.getDao("socOrdenesPagoDao");
							SocOrdenesPago opa = (SocOrdenesPago) socOrdenDao.getOrden(ins);
							opa.setClaEstadoopa('Y');
							socOrdenDao.saveOrUpdate(opa);
							log.info("Estado actualizado Ordenpago " + opa.getOpaNroordenpago());
						}
					}

				} else if (subTipoOperComp.equals("RGOP")) {
					String query = "select i.ins_codigo, i.ins_monto, i.moneda, i.ins_concepto, p.opa_reng, p.opa_imp, p.opa_benef "
							+ "from soc_instrumento i, soc_ordenespago p " + "where i.ins_codigo = p.ins_codigo " + "and i.ins_codigo = '" + codigo
							+ "'";

					OrdenPago op = null;
					String codInst = "";
					List<OrdenPago> ops = new ArrayList<OrdenPago>();

					List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query,
							"ins_codigo, ins_monto, moneda, ins_concepto, opa_reng, opa_imp, opa_benef".split(","));
					if (resultado1.size() > 0) {
						for (Map<String, Object> res : resultado1) {
							log.info("resultado" + res.toString());
							op = new OrdenPago((String) res.get("ins_codigo"), (Integer) res.get("opa_reng"), (Integer) res.get("opa_imp"), 'I',
									(BigDecimal) res.get("ins_monto"), (Integer) res.get("moneda"), (String) res.get("opa_benef"),
									(String) res.get("ins_concepto"));
							ops.add(op);
						}
					}

					Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
					mapaParametros3.put("consulta", "ops");
					mapaParametros3.put("comp", nroComprobOper);
					mapaParametros3.put("ops", ops);

					log.info("Llamando al servicio de coin: crear OP");

					SiocCoinService siocCoinService = new SiocCoinService();
					siocCoinService.executeTask(mapaParametros3);

					SocOrdenesPagoDao socOPDao = (SocOrdenesPagoDao) factoryDao.getDao("socOrdenesPagoDao");

					for (OrdenPago op2 : ops) {
						codInst = op2.getNroComprob();
						SocOrdenesPago op1 = (SocOrdenesPago) socOPDao.getOrden(codInst);

						op1.setOpaNroordenpago(nroComprobOper);
						op1.setClaEstadoopa('C');
						socOPDao.saveOrUpdate(op1);
						log.info("OP actualizada " + op1.getOpaNroordenpago());
					}

					String ins = "";
					query = "select p.ins_codigo, p.opa_nroordenpago, p.opa_reng, p.opa_imp "
							+ "from soc_detallesope d, soc_operaciones o, soc_ordenespago p " + "where d.ope_codigo = o.ope_codigo "
							+ "and d.ins_codigo = p.ins_codigo " + "and d.ope_codigo = '" + codigo + "' " + "and p.cla_estadoopa = 'P'";

					List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query,
							"ins_codigo, opa_nroordenpago, opa_reng, opa_imp".split(","));
					if (resultado2.size() == 1) {
						for (Map<String, Object> res : resultado2) {
							String nro = (String) res.get("opa_nroordenpago");
							int imp = (Integer) res.get("opa_imp");
							ins = (String) res.get("ins_codigo");

							Map<String, Object> mapaParametros4 = new HashMap<String, Object>();
							mapaParametros4.put("consulta", "opaA");
							mapaParametros4.put("comp", nro);
							mapaParametros4.put("imp", imp);

							log.info("Llamando al servicio de coin: anular OP");

							siocCoinService = new SiocCoinService();
							siocCoinService.executeTask(mapaParametros4);

							SocOrdenesPagoDao socOrdenDao = (SocOrdenesPagoDao) factoryDao.getDao("socOrdenesPagoDao");
							SocOrdenesPago opa = (SocOrdenesPago) socOrdenDao.getOrden(ins);
							opa.setClaEstadoopa('Y');
							socOrdenDao.saveOrUpdate(opa);
							log.info("Estado actualizado " + opa.getOpaNroordenpago());
						}
					}

				} else if (subTipoOperComp.equals("CC")) {
					int nro = 0;
					SocDetallesopeDao socDetOpeDao = (SocDetallesopeDao) factoryDao.getDao("socDetallesopeDao");
					SocDetallesope det = socDetOpeDao.getDetalle(codigo, 1);
					det.setInsCodigo(nroComprobOper);
					socDetOpeDao.saveOrUpdate(det);
					log.info("Detalle operacion actualizado nroComprob " + nroComprobOper);

					Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
					mapaParametros3.put("consulta", "concilia");
					mapaParametros3.put("comprob", nroComprobOper);

					log.info("Llamando al servicio de coin: get concilia");
					Map<String, Object> mapaResultado3;

					SiocCoinService siocCoinService = new SiocCoinService();
					mapaResultado3 = siocCoinService.executeTask(mapaParametros3);

					nro = (Integer) mapaResultado3.get("nro");

					socOperDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");
					oper = socOperDao.getOperacionByCod(codigo);
					String conc = String.format("%07d", nro);
					oper.setSocCorrelativo("(CC:H-" + conc + "-" + obtGestion() + ")");
					oper.setClaEstado(AUTORIZADO);
					socOperDao.saveOrUpdate(oper);
					log.info("Estado actualizado OpeCodigo " + oper.getOpeCodigo());
				}

				// autorizamos las operaciones
				if (!subTipoOperComp.equals("CC")) {
					socOperDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");
					oper = socOperDao.getOperacionByCod(codigo);
					if (oper.getSocCorrelativo() != null) {
						if (oper.getSocCorrelativo().indexOf("(CC:H-", 0) < 0) {
							oper.setClaEstado(AUTORIZADO);
						} else {
							oper.setClaEstado('C');
						}
					} else {
						oper.setClaEstado(AUTORIZADO);
					}
					socOperDao.saveOrUpdate(oper);
					log.info("Estado actualizado");
				}

				mapaRespuesta.put("estado", "A");

			} else {
				log.error("No se encontraron comprobantes para autorizar.");
				throw new RuntimeException("No se encontraron comprobantes para autorizar.");
			}

			flush();

		}
		
		PortiaService.flush();

		SiocCoinService.flush();
		flush();

		PortiaService.commit();
		log.info("=======ANTES DEL COMMIT(coin)=========");
		SiocCoinService.commit();
		log.info("=======DESPUES DEL COMMIT(coin)=========");

		log.info("=======ANTES DEL COMMIT(sioc)=========");
		commit();
		log.info("=======DESPUES DEL COMMIT(sioc)=========");
		List<EmailDetalle> emailDetalleList = (List<EmailDetalle>) UserSessionHolder.get("emailsaenviar");
		if (emailDetalleList != null) {
			log.info("Mails a enviar: " + emailDetalleList.size());			
			for (EmailDetalle emailDetalle : emailDetalleList) {
				log.info(emailDetalle.getSubject());
				MsgMailListener.enviar(emailDetalle);
			}
			// se setea a nulo para no enviar nuevamente 
			emailDetalleList.clear();
		}

		log.info("YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
		log.info("YYYYYYYYYY[" + opcion + "]YYYYYYYYYYYYYY");
		log.info("YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
		log.info("User:" + parametros.get(Constants.AUDIT_USER_SESSION_ID) + " Est: " + parametros.get(Constants.AUDIT_USER_ESTACION));
		
		if (!parametros.containsKey("sendtojms")) {
			statusCode = Constants.OPERACION_SUCCESS;
			consent = "Consulta u operación finalizada";
			// respuesta temporal hasta mejora de mensajes
			responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().setCodestadoresp(Constants.OPERACION_SUCCESS);
			responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().setDescripcion(consent);

			MessageObjectBean messageObjectBean1 = new MessageObjectBean();
			messageObjectBean1.setTransformedMessage(mapaRespuesta);

			BcbResponseImpl bcbResponseImpl = (BcbResponseImpl) responseContext.getBcbResponse();
			bcbResponseImpl.setBody(messageObjectBean1);

			try {
				//String logcitorep = (mapaRespuesta != null ? mapaRespuesta.toString() : "");
				log.info("===>[OPCION: " + opcion + "] culminada y respuesta enviada al origen::: ");
				bcbResponseImpl.sendResponseBcbMsg(statusCode, consent);

			} catch (Exception e) {
				log.error("Error al enviar respuesta: " + e.getMessage(), e);
				responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().setCodestadoresp(Constants.RUNTIME_EXCEPTION);
				throw new RuntimeException("ERROR_AL_ACTUALIZAR_RESPUESTA " + e.getMessage());
			}
		}
		if (opcion.equals("REG_SOLWS") || opcion.equals("PREAUTOAUTO")) {
			// si es de la Serv web
			// se hizo la provision de fondos
			if (mapaRespuesta.containsKey(Constants.OBJ_NAME_SOLICITUDTO) && mapaRespuesta.containsKey("sgteoperacion")) {
				log.info("YYYYYYYYYY[OPCION INTERM: " + opcion + "]YYYYYYYYYYYYYY");
				
				Solicitud solicitudTO = (Solicitud) mapaRespuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
				String tipooperacion = (String) mapaRespuesta.get("sgteoperacion");

				log.info(solicitudTO.getSolicitud().getSocCodigo() + " :::> sgteoperacion " + tipooperacion + " " + solicitudTO.getSolicitud().getClaEstado() + " "
						+ solicitudTO.getSolicitud().getFechaReg());

				parametros.put("opcion", tipooperacion);
				parametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
				parametros.put(Constants.AUDIT_COD_TIPO_OPERACION, tipooperacion);
				parametros.put(Constants.COD_IFA_REQUEST, Constants.COD_IFA_MEFP);
				parametros.put("sendtojms", "NO");
				procesar(parametros);
			}
		}

		return mapaRespuesta;
	}

	public static BigDecimal getTipoCambio(Integer mon, Date fecha) {
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("consulta", "tc");
		mapaParametros.put("fecha", fecha);
		mapaParametros.put("moneda", mon);

		BigDecimal tipo = BigDecimal.valueOf(0.00);

		// log.info("Llamando al servicio de coin: factor_conv_mn");
		Map<String, Object> mapaResultado;
		SiocCoinService siocCoinService = new SiocCoinService();
		mapaResultado = siocCoinService.executeTask(mapaParametros);
		tipo = (BigDecimal) mapaResultado.get("tc");
		
		return tipo;
	}

	public static BigDecimal getTipoCambio(String mon, Date fecha) {
		return getTipoCambio(Integer.valueOf(mon), fecha);
	}

	private void generarSolicitud(SocSolicitudes solicitud, SocDetallessol detalle, String tipo) {

		SocSolicitudesDao solicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");

		SocSolicitudes solicitudOld = solicitudesDao.getSolicitud(solicitud.getSocCodigo());
		if (solicitudOld == null && tipo.equalsIgnoreCase("M")) {
			// si la solicitud es para modificacion se verifica si ya existe
			log.error("Solicitud inexistente no se puede modificar " + solicitud.getSocCodigo());
			throw new RuntimeException("Solicitud inexistente no se puede modificar " + solicitud.getSocCodigo());
		}

		if (solicitudOld != null && solicitudOld.getEsqCodigo() != null
				&& solicitudOld.getEsqCodigo().compareTo(Constants.SOL_TRANS_EXT_SIST_FIN) == 0) {
			log.warn("Intento de modificacion de una transferencia al exterior " + solicitudOld.toString());
			throw new RuntimeException("Solicitud de transferencia al exterior no puede modificar");
		}

		solicitudesDao.saveOrUpdate(solicitud);
		log.info("Solicitud guardada: " + solicitud.toString());

		SocDetallessolDao detallesSolDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
		detallesSolDao.saveOrUpdate(detalle);
		log.info("Detalle guardado: " + detalle.toString());
	}

	private void generarComisiones(String codOperacion, SocSolicitudes solicitud, BigDecimal tc) {
		SocOpecomiId id1 = new SocOpecomiId("1", codOperacion, 1);
		BigDecimal monto = BigDecimal.valueOf(0.00);
		String tipoEnt = Servicios.getTipoEnt(solicitud.getSolCodigo());
		
		SocComitipoopeDao socComitipoopeDao = new SocComitipoopeDao();
		socComitipoopeDao.setSessionFactory(getSessionFactory());
		Integer codCargoCTRF = 4;
		
		if (tipoEnt.equals("SP")) {
//			monto = solicitud.getSocMontome()
//					.multiply(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRA"))).divide(BigDecimal.valueOf(100)))
//					.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			// no se deberia entrar aca esto es solo por control
			throw new RuntimeException("Solicitud de transferencia al exterior Sector financiero no implementado, avise a sistemas");
		} else {

			SocComitipoope socComitipoope = socComitipoopeDao.comisionByCodCargoTipoComis(codCargoCTRF, Constants.CLAVE_CARGOTIPOCOMIS_CTRF);
			monto = solicitud.getSocMontome()
					.multiply(socComitipoope.getValor().divide(BigDecimal.valueOf(100)))
					.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		}
		final BigDecimal montoComi1 = monto.multiply(tc);
		SocOpecomi opeComi1 = new SocOpecomi(id1, montoComi1);

		SocComitipoope socComitipoope = socComitipoopeDao.comisionByCodCargoTipoComis(codCargoCTRF, Constants.CLAVE_CARGOTIPOCOMIS_SWFT);
		
		SocOpecomiId id2 = new SocOpecomiId("2", codOperacion, 1);
		final BigDecimal montoComi2 = socComitipoope.getValor();
		SocOpecomi opeComi2 = new SocOpecomi(id2, montoComi2);

		socComitipoope = socComitipoopeDao.comisionByCodCargoTipoComis(codCargoCTRF, Constants.CLAVE_CARGOTIPOCOMIS_UTIL);
		SocOpecomiId id3 = new SocOpecomiId("3", codOperacion, 1);
		final BigDecimal montoComi3 = socComitipoope.getValor();
		SocOpecomi opeComi3 = new SocOpecomi(id3, montoComi3);

		SocOpecomiDao socOpecomiDao = (SocOpecomiDao) factoryDao.getDao("socOpecomiDao");
		socOpecomiDao.saveOrUpdate(opeComi1);
		socOpecomiDao.saveOrUpdate(opeComi2);
		socOpecomiDao.saveOrUpdate(opeComi3);
		log.info("Comisiones generadas: ");
	}

	private static Boolean generarSwift(FactoryDao factoryDao, String codInst, Date fechaValor, SocSolicitudes solicitud, SocDetallesope detalle) {
		log.info("Dentro de generar swift: " + codInst + "; fecha: " + fechaValor + " solicitud: " + solicitud.toString());
		flush();
		String esq = Servicios.getEsquema(detalle.getDetCtabenef());

		if (!StringUtils.isBlank(esq)) {

			Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
			mapaParametros2.put("consulta", "crear");
			log.info("Llamando al servicio de portiaswift: obtener numero swift");
			Map<String, Object> mapaResultado2;

			String usuario = (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID);
			
			ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc(getSessionFactory());
			clienteLvdSioc.initClienteLvd();
			clienteLvdSioc.getSessionLavado(usuario);		

			Integer nroSwift = null;
			Integer nroLavado = null;
			String codigoOperacion = solicitud.getSocCodigo() + "" +detalle.getId().getDetCodigo(); 

			if (clienteLvdSioc.getClienteLvd() == null){
				PortiaService portiaService = new PortiaService();
				mapaResultado2 = portiaService.executeTask(mapaParametros2);
	
				nroSwift = (Integer) mapaResultado2.get("swift");
			} else {
				SearchResponse searchResponse = clienteLvdSioc.solicitarCorrelativo(codigoOperacion, usuario);
				nroSwift = searchResponse.getNrocorr();
				nroLavado = Integer.valueOf(searchResponse.getCodoperacion());
			}
			
			if (nroSwift != null && nroSwift != 0) {
				SocMensajes swift = new SocMensajes(codInst, nroSwift, fechaValor, detalle.getDetMonto(), "E", usuario, esq);
				
				swift.setFechaHora(new Date());
				swift.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
				// whf 20170628: para lavado se reutiliza el campo det_codigo => nro lavado
				// y OpeCodigo para almacenar el codigo de la operacion 
				swift.setDetCodigo(nroLavado);
				swift.setOpeCodigo(codigoOperacion);
				
				SocMensajesDao socMensajesDao = (SocMensajesDao) factoryDao.getDao("socMensajesDao");
				socMensajesDao.saveOrUpdate(swift);
				log.info("Mensaje generado(New): "  + swift.toString());

				String[][] men = Swift.crearSwift(solicitud, detalle, swift);
				SocDatosmen dato = null;
				SocDatosmenDao socDatosmenDao = (SocDatosmenDao) factoryDao.getDao("socDatosmenDao");

				for (String[] dat : men) {
					if (dat[0] != null) {
						dato = new SocDatosmen(new SocDatosmenId(dat[0], codInst), dat[1]);
						socDatosmenDao.saveOrUpdate(dato);
					}
				}
				QueryProcessor.flush();
				String menPlano = Swift.crearSwiftTexto(codInst);
				clienteLvdSioc.scanMensaje(codigoOperacion, usuario, nroLavado, nroSwift, menPlano);
				clienteLvdSioc.cerrarSession(usuario);
				
				log.info("Mensaje Swift Campos generados nro sol: " + solicitud.getSocCodigo());
				return true;
			}
			log.info("Error al recuperar el numero de mensaje Swift, intentelo nuevamente");

			throw new RuntimeException("Error al recuperar el numero de mensaje Swift, intentelo nuevamente");
		} else {

			log.info("Cuenta de beneficiario " + detalle.getDetCtabenef() + " sin esquema");
			throw new RuntimeException("Cuenta de beneficiario " + detalle.getDetCtabenef() + " sin esquema");
		}
	}

	private Map<String, Object> generarOperacion(SocSolicitudes solicitud, SocDetallessol detalle, Date fechaValor, String uu) {
		log.info("Ingresando a Generar operaciÃ³n para " + solicitud.toString() + " fecha: " + fechaValor + " tipo: " + uu);
		Map<String, Object> mapOpe = new HashMap<String, Object>();
		int mon1 = 0;
		BigDecimal tc1 = BigDecimal.valueOf(0.00);
		BigDecimal montoT = BigDecimal.valueOf(0.00);

		// generando la operaciÃ³n
		SocOperaciones operacion = new SocOperaciones();
		operacion.setSolCodigo(solicitud.getSolCodigo());
		operacion.setClaOperacion(solicitud.getClaTipo());
		operacion.setOpeFecha(fechaValor);
		String moneda = solicitud.getMoneda();
		String monedaT = solicitud.getMonedaT();

		int mon = Servicios.getMoneda(moneda);
		operacion.setOpeCtaoperacion(solicitud.getSocCuentad());
		operacion.setOpeCtacomision(solicitud.getSocCuentac());
		operacion.setOpeNrocuentac(solicitud.getSocNrocuentac());
		operacion.setOpeNrocuentad(solicitud.getSocNrocuentad());
		operacion.setSocCorrelativo(solicitud.getSocCorrelativo());
		operacion.setSocCodigo(solicitud.getSocCodigo());
		operacion.setClaEstado(PENDIENTE);
		operacion.setUsrCodigo(USUARIO);

		Date hoy = new Date();

		operacion.setFechaHora(hoy);
		operacion.setEstacion(ESTACION);

		String codOperacion = Long.toString(hoy.getTime());
		operacion.setOpeCodigo(codOperacion);

		BigDecimal tipo = BigDecimal.valueOf(0.00);

		if (!moneda.equals(monedaT)) {
			tipo = getTipoCambio(mon, fechaValor);
			mon1 = Servicios.getMoneda(monedaT);
			tc1 = getTipoCambio(mon1, fechaValor);
			montoT = solicitud.getSocMontome().multiply(tipo).divide(tc1, 2, RoundingMode.HALF_UP);
			operacion.setOpeMontome(montoT);
		} else {
			mon1 = mon;
			tipo = getTipoCambio(mon, hoy);
			tc1 = tipo;
			operacion.setOpeMontome(solicitud.getSocMontome());
		}

		if (tipo == null || tipo.compareTo(BigDecimal.valueOf(0.00)) <= 0) {
			throw new RuntimeException("Error la recuperar tipo de cambio moneda " + mon);
		}

		final BigDecimal montoMN = operacion.getOpeMontome().multiply(tc1);
		operacion.setMoneda(mon1);
		operacion.setOpeMontomn(montoMN);

		SocOperacionesDao socOperacionesDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");
		socOperacionesDao.saveOrUpdate(operacion);
		log.info("OperaciÃ³n generada: ");

		SocDetallesope detOpe = new SocDetallesope();
		SocDetallesopeId id = new SocDetallesopeId(codOperacion, 1);
		detOpe.setId(id);
		detOpe.setBenCodigo(detalle.getBenCodigo());
		detOpe.setDetMonto(operacion.getOpeMontome());
		detOpe.setDetMontoOrd(detalle.getDetMontoord());

		detOpe.setMoneda(mon1);
		Integer cta = detalle.getDetCtabenef();
		detOpe.setDetCtabenef(Integer.toString(cta));
		detOpe.setDetConcepto(detalle.getDetConcepto());
		detOpe.setDetInfo(detalle.getDetInfo());
		detOpe.setDetFacturas(detalle.getDetFacturas());

		SocDetallesopeDao socDetallesopeDao = (SocDetallesopeDao) factoryDao.getDao("socDetallesopeDao");
		socDetallesopeDao.saveOrUpdate(detOpe);
		// whf ceci
		log.info("Detalle generado: ");
		mapOpe = generarOperacionAct(solicitud, detalle, operacion, detOpe, fechaValor, uu);

		return mapOpe;
	}

	private Map<String, Object> generarOperacionAct(SocSolicitudes solicitud, SocDetallessol detalle, SocOperaciones operacion,
			SocDetallesope detOpe, Date fechaValor, String uu) {
		log.info("Ingresando a generarOperacionAct: " + solicitud.toString() + " fechaValor: " + fechaValor + " tipo uu: " + uu);
		Map<String, Object> mapOpe = new HashMap<String, Object>();
		Boolean continuar = true;

		SocDetallesopeDao socDetallesopeDao = (SocDetallesopeDao) factoryDao.getDao("socDetallesopeDao");
		log.info("Generar operaciÃ³n.");

		String codOperacion = operacion.getOpeCodigo();
		int mon = Servicios.getMoneda(solicitud.getMoneda());

		Date hoy1 = new Date();
		String codInst = Long.toString(hoy1.getTime());
		SocInstrumento instrumento = new SocInstrumento(codInst, 1, operacion.getOpeMontome(), detOpe.getMoneda(), detalle.getDetConcepto());

		SocInstrumentoDao socInstrumentoDao = (SocInstrumentoDao) factoryDao.getDao("socInstrumentoDao");
		socInstrumentoDao.saveOrUpdate(instrumento);
		log.info("Instrumento generado: " + instrumento.getInsCodigo());

		QueryProcessor.generarSwift(factoryDao, codInst, fechaValor, solicitud, detOpe);

		String tipoOperacion = solicitud.getClaTipo();

		detOpe = socDetallesopeDao.getDetalle(codOperacion, 1);
		detOpe.setInsCodigo(codInst);
		socDetallesopeDao.saveOrUpdate(detOpe);
		log.info("Instrumento actualizado");

		DateTime hoyT = new DateTime(fechaValor);
		Date hoy2 = new Date();

		// CCUH SIOC V.2
		// Generar comprobante sÃ³lo si la fecha valor es igual a la fecha
		// de
		// registro
		// 26-07-2013
		String fecValor = UtilsDate.stringFromDate(fechaValor, "ddMMyyyy");
		String fecHoy = UtilsDate.stringFromDate(new Date(), "ddMMyyyy");

		// if (hoyT.getDayOfMonth() == hoy2.getDate()) {
		if (fecValor.equals(fecHoy)) {
			log.info("Operacion para ejecutarse en el dÃ­a " + solicitud.getSocCodigo());
			if (!tipoOperacion.equals("OB")) {
				BigDecimal tc = getTipoCambio(mon, fechaValor);
				this.generarComisiones(codOperacion, solicitud, tc);
			}

			String codComprobante = Long.toString(hoy2.getTime());
			SocComprobante comprobante = new SocComprobante(codComprobante, codOperacion, hoyT.getYear(), hoyT.getMonthOfYear(),
					hoyT.getDayOfMonth(), tcUS, Glosa.crearGlosa(getSessionFactory(), tipoOperacion, solicitud, detalle.getDetConcepto()));

			SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
			comprobanteDao.saveOrUpdate(comprobante);
			log.info("Comprobante guardado: " + codComprobante);

			String subTipo = "";
			// CCUH SIOC V.2
			// R-01 Suprimir provisiÃ³n comisiones para transferencias al
			// exterior
			// Se crearon nuevos esquemas para debitar las comisiones de la
			// cuenta del solicitante
			// 25-06-2013
			// R-02 Para transferencias en otras monedas no se realizÃ³
			// ninguna provisiÃ³n, debitar monto
			// de operaciÃ³n y comisiones de las cuentas del solicitante
			// como
			// una operaciÃ³n interna
			// 05-07-2013

			SocSolicitante socSolicitante = Servicios.getSocSolicitante(solicitud.getSolCodigo());
			if (socSolicitante == null) {
				throw new RuntimeException("Solicitante inexistente " + solicitud.getSolCodigo());
			}

			if (uu.equals("") && solicitud.getMonedaT().equals("USD")) {
				if (tipoOperacion.equals("TE") && solicitud.getSocCuentad().equals(solicitud.getSocCuentac())
						&& socSolicitante.getClaEntidad().equals("SF")) {
					// si es transferenci al exterior y las monedas son
					// iguales y si es del sistema financiero
					// esquema nro 18
					subTipo = "CC";
				} else {
					if (solicitud.getSocMontoord().compareTo(BigDecimal.ZERO) == 0) {
						if (solicitud.getSocCuentad().equals(solicitud.getSocCuentac())) {
							subTipo = "CCS";
						} else {
							subTipo = "OCS";
						}
					} else {
						subTipo = "CC";
					}
				}
			} else {
				// Se deben generar dÃ©bitos separados para monto de
				// operaciÃ³n y comisiones
				subTipo = "OC";
				if (!solicitud.getMonedaT().equals("USD")) {
					uu = "I";
				}
			}

			if (tipoOperacion.equals("VE"))
				subTipo = "TE";
			if (tipoOperacion.equals("OB"))
				subTipo = "TE";

			// //////////////////////////////
			// ya en serio!!! este es un parche para intentar soluc el
			// carnaval de
			// arriba
			String sIOCWEB_TIPOPERACION = (String) UserSessionHolder.get("SIOCWEB_TIPOPERACION");
			if (sIOCWEB_TIPOPERACION.equals("OP_GEN_OPERS") && solicitud.getClaTipo().equals("TE") && socSolicitante.getClaEntidad().equals("SF")
					&& solicitud.getSocCuentad().equals(solicitud.getSocCuentac())) {
				// autorizacion de una solicitud
				// cuenta 62
				tipoOperacion = "TRA_EXT_SF_TRANSFER";
				subTipo = "CTA_CTA";
				uu = "";
			}

			// /////////////////////////////////
			List<Map<String, Object>> resultado1 = Servicios.obtenerEsquema(tipoOperacion, subTipo + uu);
			List<SocDetallessol> detalles = new ArrayList<SocDetallessol>();
			detalles.add(detalle);

			SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
			List<SocRengscomp> renglones = rengsCompDao.CrearRenglones(codComprobante, resultado1, solicitud, detalles);
			flush();

			log.info("Renglones creados: ");

			String query = "select ren_codigo " + "from soc_rengscomp " + "where cpb_codigo = '" + codComprobante + "' "
					+ "and ren_afectable = '001564'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ren_codigo".split(","));
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					// log.info("resultado" + res.toString());
					Integer nro = (Integer) res.get("ren_codigo");
					SocFacturasDao facturasDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
					if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0)) > 0) {
						facturasDao.crearFactura(codComprobante, nro, detalle.getBenCodigo(), 'T');
					} else {
						facturasDao.crearFactura(codComprobante, nro, solicitud.getSolCodigo());
					}
				}
			}
			rengsCompDao.CrearRenglonesITF(codComprobante, codOperacion, new Date(), solicitud, detalle);
			flush();

		}
		if (continuar) {
			SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
			solicitud.setClaEstado('O');
			socSolicitudesDao.saveOrUpdate(solicitud);

			mapOpe.put("nroOperacion", codOperacion);
			mapOpe.put("nroInst", codInst);
		} else {
			mapOpe.put("nroOperacion", "0000");
			mapOpe.put("nroInst", "0000");
			log.info("no se pudo generar operaciÃ³n");
		}

		return mapOpe;
	}

	private char sinSubasta(BigDecimal tcBase) {
		char estado = '0';
		Date fecha = new Date();
		SocCambioDao socCambioDao = (SocCambioDao) factoryDao.getDao("socCambioDao");
		SocCambio socCambio = socCambioDao.getCambio(fecha);
		SocCambio cambio = new SocCambio();
		if (socCambio != null) {
			if (!StringUtils.isBlank(socCambio.getClaEstado()) && (socCambio.getClaEstado().equals("1") || socCambio.getClaEstado().equals("5"))) {
				throw new RuntimeException("Proceso de subasta con estado incorrecto posiblemente ya fue procesado");
			}
			cambio = socCambio;
		}

		Double diff_cv = Double.valueOf(Servicios.getParam("@diffcv"));
		Double cantidad_dis = Double.valueOf(Servicios.getParam("@disponible"));

		cambio.setFecha(fecha);
		cambio.setVenta(tcBase);
		cambio.setCompra(tcBase.subtract(BigDecimal.valueOf(diff_cv)));
		cambio.setBase(tcBase);
		cambio.setVend(BigDecimal.valueOf(0.00));
		cambio.setDisp(BigDecimal.valueOf(cantidad_dis));
		cambio.setPres(0);
		cambio.setAcep(0);
		cambio.setClaEstado("1");
		cambio.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));
		cambio.setFechaHora(fecha);
		cambio.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

		socCambioDao.saveOrUpdate(cambio);
		estado = '1';
		log.info("Subasta Procesada sin solicitudes ");

		return estado;
	}

	private char procesarSubasta(BigDecimal tcBase) {
		char estado = '0';
		// Date ldt_fech_hor;
		Date fecha = new Date();
		char lst_estado;
		String lst_cod_per, lst_fin;
		Integer llo_regacep = 0;
		// Boolean lbo_sn;
		BigDecimal lde_cantidads, lde_cantidadsi, lde_cantidad_dis, lde_cantidad_rech, lde_tipo, lde_cantidad_ven, lde_cantidad_tven = BigDecimal
				.valueOf(0), lde_saldo_cc = BigDecimal.valueOf(0), lde_montobs, lde_por, min_cambio, cotz_venta = BigDecimal.valueOf(0), cotz_compra;
		BigDecimal lde_cantidad_tip = BigDecimal.valueOf(0);

		SocParticipanteDao socPartDao = (SocParticipanteDao) factoryDao.getDao("socParticipanteDao");
		// vd0
		SocBolsinDao socBolsinDao = (SocBolsinDao) factoryDao.getDao("socBolsinDao");

		SocCambioDao socCambioDao = (SocCambioDao) factoryDao.getDao("socCambioDao");
		SocCambio socCambio = socCambioDao.getCambio(fecha);
		SocCambio cambio = new SocCambio();
		if (socCambio != null) {
			if (!StringUtils.isBlank(socCambio.getClaEstado()) && (socCambio.getClaEstado().equals("1") || socCambio.getClaEstado().equals("5"))) {
				throw new RuntimeException("Proceso de subasta con estado incorrecto posiblemente ya fue procesada");
			}
			cambio = socCambio;
		}
		List<SocBolsin> solics0 = socBolsinDao.getByEstadoFecha(fecha, "'1','2','3','5'", "'G','E'");
		if (solics0.size() > 0) {
			throw new RuntimeException("Inconsistencia!! ya existen solicitudes con estado procesado para la fecha, verifique los datos.");
		}
		// ojoooo se recupera solo registros de bolsin
		List<SocBolsin> solics = socBolsinDao.getByEstadoFecha(fecha, "'0'", "'G','E'");

		if (solics.size() == 0) {
			return sinSubasta(tcBase);
		}

		List<SocParticipante> parts = socPartDao.getParticipantes();
		for (SocParticipante part : parts) {
			part.setSaldo(BigDecimal.valueOf(1000000000));
			part.setSaldop(BigDecimal.valueOf(0));
			socPartDao.saveOrUpdate(part);
		}

		Double cantidad_dis = Double.valueOf(Servicios.getParam("@disponible"));
		lde_cantidad_dis = BigDecimal.valueOf(cantidad_dis);

		// seleccionamos las cotizaciones propuestaas para la compra y lo
		// ordenamos en mayor a menor
		String query = "select distinct cotiz ";
		query = query.concat("from soc_bolsin ");
		query = query.concat("where cla_estado = '0' ");
		query = query.concat("and sol_codigo <> '237' ");
		query = query.concat("and cla_tipsolic in ('G','E') ");
		query = query.concat("order by cotiz desc ");

		List<SocBolsin> socBolsinList0 = new ArrayList<SocBolsin>();

		List<Map<String, Object>> resultadoT = Servicios.ejecutarQuery(query, "cotiz".split(","));
		if (resultadoT.size() > 0) {
			for (Map<String, Object> res : resultadoT) {
				lde_tipo = (BigDecimal) res.get("cotiz");

				// sumamos los montos solicitados en USD de las solicitudes que
				// ingresaron el tipo de cambio
				query = "select sum(montosol) as monto ";
				query = query.concat("from soc_bolsin ");
				query = query.concat("where cla_estado = '0' ");
				query = query.concat("and sol_codigo <> '237' ");
				query = query.concat("and cla_tipsolic in ('G','E') ");
				query = query.concat("and cotiz = " + lde_tipo + " ");

				List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "monto".split(","));
				if (resultado.size() == 1) {
					for (Map<String, Object> res1 : resultado) {
						lde_cantidad_tip = (BigDecimal) res1.get("monto");
					}
				}

				lst_fin = "N";

				do {
					lde_cantidad_ven = BigDecimal.valueOf(0);
					lde_cantidad_rech = BigDecimal.valueOf(0);
					// /****************
					lde_saldo_cc = BigDecimal.valueOf(0);
					// ****************
					for (SocBolsin solic : solics) {
						lst_cod_per = solic.getSolCodigo();
						lde_cantidads = solic.getMontoSol();
						lde_cantidadsi = lde_cantidads;

						if (!lst_cod_per.equals("237") && lde_tipo.compareTo(solic.getCotiz()) == 0) {
							if (lde_tipo.compareTo(tcBase) >= 0) {
								SocParticipante part = (SocParticipante) socPartDao.getParticipante(lst_cod_per);

								lde_saldo_cc = BigDecimal.valueOf(1000000000);
								part.setSaldo(lde_saldo_cc);
								part.setClaEstado("2");
								socPartDao.saveOrUpdate(part);

								lde_saldo_cc = part.getSaldo().subtract(part.getSaldop());

								if (lde_cantidad_tip.compareTo(lde_cantidad_dis) >= 0) {
									lde_por = lde_cantidads.divide(lde_cantidad_tip, 30, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100));
									lde_cantidads = lde_cantidad_dis.multiply(lde_por).divide(BigDecimal.valueOf(100));
									lst_estado = '2';
								} else {
									lst_estado = '1';
								}

								lde_montobs = lde_cantidads.multiply(lde_tipo);

								if (lde_saldo_cc.compareTo(lde_montobs) >= 0) {
									lde_cantidad_ven = lde_cantidad_ven.add(lde_cantidads);

									solic.setClaEstado(lst_estado);
									solic.setMontoAdj(lde_cantidads);
									solic.setSeq(1);

									part.setSaldop(part.getSaldop().add(lde_montobs));
									socPartDao.saveOrUpdate(part);
								} else {
									lde_cantidad_rech = lde_cantidad_rech.add(lde_cantidadsi);
									solic.setClaEstado('4');
									solic.setMontoAdj(BigDecimal.valueOf(0));
								}
							} else {
								solic.setClaEstado('3');
								solic.setMontoAdj(BigDecimal.valueOf(0));
							}
						} else {
							if (lde_tipo.compareTo(solic.getCotiz()) == 0 && solic.getSolCodigo().equals("237")) {
								if (lde_tipo.compareTo(tcBase) >= 0) {
									lde_cantidads = solic.getMontoSol();
									solic.setClaEstado('1');
									solic.setMontoAdj(lde_cantidads);

									lde_cantidad_tven = lde_cantidad_tven.add(lde_cantidads);
								} else {
									solic.setClaEstado('3');
									solic.setMontoAdj(BigDecimal.valueOf(0));
								}
							}
						}

						socBolsinDao.saveOrUpdate(solic);
						socBolsinList0.add(solic);
					}

					if (lde_cantidad_rech.compareTo(BigDecimal.valueOf(0)) == 0) {
						lde_cantidad_dis = lde_cantidad_dis.subtract(lde_cantidad_ven);
						lde_cantidad_tven = lde_cantidad_tven.add(lde_cantidad_ven);
						lst_fin = "S";
					} else {
						for (SocParticipante part : parts) {
							part.setSaldo(BigDecimal.valueOf(0));
							part.setSaldop(BigDecimal.valueOf(0));
							socPartDao.saveOrUpdate(part);
						}
						lde_cantidad_tip = lde_cantidad_tip.subtract(lde_cantidad_rech);
					}

				} while (lst_fin.equals("N"));
			}
		}

		query = "select count(*) as acep ";
		query = query.concat("from soc_bolsin ");
		query = query.concat("where montoadj > 0 ");
		query = query.concat("and cla_estado in ('1', '2')  ");
		query = query.concat("and cla_tipsolic in ('G','E') ");

		List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query, "acep".split(","));
		if (resultado2.size() == 1) {
			for (Map<String, Object> res : resultado2) {
				BigDecimal aa = (BigDecimal) res.get("acep");
				String aas = aa.toString();
				llo_regacep = Integer.valueOf(aas);
			}
		}

		// 1. Verifica si la venta se llego a agotar
		min_cambio = BigDecimal.valueOf(0);
		if (lde_cantidad_tven.compareTo(BigDecimal.valueOf(cantidad_dis)) == 0) {
			query = "select min(cotiz) as min ";
			query = query.concat("from soc_bolsin ");
			query = query.concat("where montoadj > 0 ");
			query = query.concat("and cla_estado in ('1', '2')  ");
			query = query.concat("and cla_tipsolic in ('G','E') ");

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "min".split(","));
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					min_cambio = (BigDecimal) res.get("min");
				}
			}
		}
		cotz_compra = BigDecimal.valueOf(0);
		Double diff_cv = Double.valueOf(Servicios.getParam("@diffcv"));
		// 2. VErificar si la cotz_propuesta > de la venta
		if (min_cambio.compareTo(BigDecimal.valueOf(0)) > 0 && min_cambio.compareTo(cotz_venta) > 0) {
			cotz_compra = min_cambio.subtract(BigDecimal.valueOf(diff_cv));
		}
		// 3. Establecer como nueva cotizacion

		if (cotz_compra.compareTo(BigDecimal.valueOf(0)) > 0) {
			cambio.setFecha(fecha);
			cambio.setVenta(min_cambio);
			cambio.setCompra(cotz_compra);
			cambio.setBase(tcBase);
			cambio.setVend(lde_cantidad_tven);
			cambio.setDisp(BigDecimal.valueOf(cantidad_dis));
			cambio.setPres(solics.size());
			cambio.setAcep(llo_regacep);
			cambio.setClaEstado("1");
			cambio.setUsrCodigo(USUARIO);
			cambio.setFechaHora(new Date());
			cambio.setEstacion(ESTACION);
		} else {
			cambio.setFecha(fecha);
			cambio.setVenta(tcBase);
			cambio.setCompra(tcBase.subtract(BigDecimal.valueOf(diff_cv)));
			cambio.setBase(tcBase);
			cambio.setVend(lde_cantidad_tven);
			cambio.setDisp(BigDecimal.valueOf(cantidad_dis));
			cambio.setPres(solics.size());
			cambio.setAcep(llo_regacep);
			cambio.setClaEstado("1");
			cambio.setUsrCodigo(USUARIO);
			cambio.setFechaHora(new Date());
			cambio.setEstacion(ESTACION);
		}

		int ii = 0;
		BigDecimal total0 = BigDecimal.valueOf(0);
		for (SocBolsin solic : socBolsinList0) {
			ii++;
			String afecB = "";
			Boolean continuar = true;
			if (solic.getMontoSol().compareTo(solic.getMontoAdj()) > 0) {
				BigDecimal montoDev = solic.getMontoSol().subtract(solic.getMontoAdj()).multiply(solic.getCotiz());
				String codComprobante1 = null;
				DateTime hoy2 = new DateTime();
				Date hoy1 = new Date();
				String gg = "";
				if (solic.getMontoAdj().compareTo(BigDecimal.valueOf(0.00)) == 0)
					gg = "DEVOLUCION DE PROVISION DE FONDOS POR NO ADJUDICACION DE DIVISAS EN LA SESION DEL BOLSIN DE LA FECHA";
				else
					gg = "DEVOLUCION DE PROVISION DE FONDOS POR ADJUDICACION PARCIAL DE DIVISAS EN LA SESION DEL BOLSIN DE LA FECHA";
				codComprobante1 = Long.toString(hoy1.getTime());
				SocComprobante comprobante1 = new SocComprobante(codComprobante1, solic.getSocCodigo(), hoy2.getYear(), hoy2.getMonthOfYear(),
						hoy2.getDayOfMonth(), tcUS, gg);

				SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
				comprobanteDao.saveOrUpdate(comprobante1);
				log.info("Comprobante guardado: ");

				query = "SELECT cta_afectable " + "FROM soc_cuentassol WHERE cta_codigo = " + solic.getCuentaD();

				String afec = "";
				List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_afectable".split(","));
				if (resultado.size() == 1) {
					for (Map<String, Object> res : resultado) {
						afec = (String) res.get("cta_afectable");
					}
				}

				query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_b' " + "AND val_codigo = trim('"
						+ solic.getSolCodigo() + "')";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "val_nombre".split(","));
				if (resultado1.size() == 1) {
					for (Map<String, Object> res : resultado1) {
						afecB = (String) res.get("val_nombre");
					}
				}
				String mayorctaafect_b = "000108";
				SocRengscomp renglon1 = new SocRengscomp(new SocRengscompId(codComprobante1, 1), MONBS, 'D', tcBS, montoDev, montoDev,
						mayorctaafect_b, afecB);
				SocRengscomp renglon2 = new SocRengscomp(new SocRengscompId(codComprobante1, 2), MONBS, 'H', tcBS, montoDev, montoDev, "000110", afec);
				SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
				rengsCompDao.saveOrUpdate(renglon1);
				rengsCompDao.saveOrUpdate(renglon2);
				log.info("Renglones guardado: ");

				List<SocRengscomp> rengs = new ArrayList<SocRengscomp>();
				rengs.add(renglon1);
				rengs.add(renglon2);
				flush();
				Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
				mapaParametros2.put("consulta", "crear");
				mapaParametros2.put("comp", comprobante1);
				mapaParametros2.put("rengs", rengs);

				log.info("Llamando al servicio de coin: crear comprobante");
				Map<String, Object> mapaResultado2;

				SiocCoinService siocCoinService = new SiocCoinService();
				mapaResultado2 = siocCoinService.executeTask(mapaParametros2);

				String nroComprob = (String) mapaResultado2.get("comp");
				if (!nroComprob.equals("") && !nroComprob.equals("0000000")) {
					if (!nroComprob.equals("9999999")) {
						log.info("Comprobante coin creado: " + nroComprob);
					} else {
						log.info("Existe sobregiro en cuentas");
						continuar = false;
						estado = 'Z';
					}
				} else {
					log.info("Error al crear comprobante coin");
					continuar = false;
					estado = 'Z';
				}
			}
			if (continuar) {
				if (solic.getMontoAdj().compareTo(BigDecimal.valueOf(0)) > 0) {
					String codComprobante1 = null;
					DateTime hoy2 = new DateTime();
					Date hoy1 = new Date();
					// whf
					CalendarioComun calendarioComun = new CalendarioComun();
					calendarioComun.setSessionFactory(SiocCoinService.getSessionFactory());

					Date fechaHabil = calendarioComun.fecHabilAntesDespuesDe(hoy1, 1);
					DateTime fechaHabil1 = new DateTime(fechaHabil);

					codComprobante1 = Long.toString(hoy1.getTime());
					SocComprobante comprobante1 = new SocComprobante(codComprobante1, solic.getSocCodigo(), fechaHabil1.getYear(),
							fechaHabil1.getMonthOfYear(), fechaHabil1.getDayOfMonth(), cambio.getCompra(),
							"ENTREGA DE DIVISAS ADJUDICADAS EN SESION DEL BOLSIN DE FECHA " + hoy2.getDayOfMonth() + "/" + hoy2.getMonthOfYear()
									+ "/" + hoy2.getYear());

					SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
					comprobanteDao.saveOrUpdate(comprobante1);
					log.info("Comprobante guardado: ");

					SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
					socCuentassolDao.setSessionFactory(getSessionFactory());
					List<CuentaS> cuentas = socCuentassolDao.listaCuentasSolicitante(solic.getSolCodigo(), 34, null, null, null, null, null, true);

					if (cuentas == null || cuentas.size() != 1) {
						throw new RuntimeException("Cuenta inexistente entidad [" + solic.getSolCodigo() + "] moneda " + 34);
					}

					CuentaS cuentaS = cuentas.get(0);

					String afec = cuentaS.getCtaAfectable();

					query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_b' " + "AND val_codigo = trim('"
							+ solic.getSolCodigo() + "')";

					List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "val_nombre".split(","));
					if (resultado1.size() == 1) {
						for (Map<String, Object> res : resultado1) {
							afecB = (String) res.get("val_nombre");
						}
					} else {
						afecB = "";
					}

					String soli = Servicios.getSolicitante(solic.getSolCodigo());
					SocSolicitante socSolicitante = null;
					if (solic.getBenef() != null)
						socSolicitante = Servicios.getSocSolicitante(solic.getBenef());

					String conceptoCompro = "";
					if (solic.getClaTipsolic() == null || solic.getClaTipsolic().trim().equals("E")) {
						// si es entidad financiera el solicitante
						conceptoCompro = soli;
					} else {
						if ((socSolicitante != null) && (socSolicitante.getSolPersona() != null)
								&& (solic.getClaTipsolic() != null && solic.getClaTipsolic().trim().equals("G")))
							// si se encontrï¿½ el beneficiario y ademas el tipo
							// de solicitud es a publico en general
							if (solic.getBolCtamn() != null && solic.getBolCtame() != null)
								conceptoCompro = socSolicitante.getSolPersona() + " CTA. MN. " + solic.getBolCtamn() + " CTA. ME. "
										+ solic.getBolCtame();
							else
								conceptoCompro = socSolicitante.getSolPersona();
						else
							conceptoCompro = soli;
					}
					String mayorctaafect_b = "000108";
					SocRengscomp renglon1 = new SocRengscomp(new SocRengscompId(codComprobante1, 1), MONBS, 'D', tcBS, solic.getMontoAdj().multiply(
							solic.getCotiz()), solic.getMontoAdj().multiply(solic.getCotiz()), mayorctaafect_b, afecB);
					SocRengscomp renglon2 = new SocRengscomp(new SocRengscompId(codComprobante1, 2), MONUS, 'H', cambio.getCompra(),
							solic.getMontoAdj(), solic.getMontoAdj().multiply(cambio.getCompra()), "000110", afec, "SOL. NRO. " + ii + " POR USD. "
									+ formatearMonto(solic.getMontoAdj()) + " A BS. "
									+ formatearMonto(solic.getCotiz().divide(BigDecimal.ONE, 2, RoundingMode.HALF_UP)) + " BENEF. " + conceptoCompro);

					// para el monto excento
					BigDecimal comiV = solic.getMontoAdj().multiply(BigDecimal.valueOf(diff_cv));
					SocRengscomp renglon3 = new SocRengscomp(new SocRengscompId(codComprobante1, 3), MONBS, 'H', tcBS, comiV.multiply(BigDecimal
							.valueOf(1)), comiV.multiply(BigDecimal.valueOf(1)), Servicios.getParam("@mventaBolsin"),
							Servicios.getParam("@cventaBolsin"));

					SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
					rengsCompDao.saveOrUpdate(renglon1);
					rengsCompDao.saveOrUpdate(renglon2);
					rengsCompDao.saveOrUpdate(renglon3);
					BigDecimal diftc = solic.getCotiz().subtract(cambio.getVenta());
					if (diftc.compareTo(BigDecimal.valueOf(0.005)) > 0) {
						SocRengscomp renglon5 = new SocRengscomp(new SocRengscompId(codComprobante1, 4), MONBS, 'H', tcBS, solic.getMontoAdj()
								.multiply(diftc), solic.getMontoAdj().multiply(diftc), "000153", "004378");
						rengsCompDao.saveOrUpdate(renglon5);
					}
					log.info("Renglones guardados: ");
					// Codigo para la emision de factura sin credito
					// fiscal

					Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
					mapaParametros3.put("consulta", "nit");
					mapaParametros3.put("soli", solic.getSolCodigo().trim());
					String nit = "";
					char cveRuc = 'P';

					log.info("Llamando al servicio de coin: get nit");
					Map<String, Object> mapaResultado3;
					if (solic.getClaTipsolic() != null && solic.getClaTipsolic().equalsIgnoreCase("G")) {
						// si la venta es a publico en general
						nit = socSolicitante.getSolNit();
						soli = socSolicitante.getSolFactura();
					} else {
						SiocCoinService siocCoinService = new SiocCoinService();
						mapaResultado3 = siocCoinService.executeTask(mapaParametros3);

						nit = (String) mapaResultado3.get("nit");
					}

					SocFacturasId id = new SocFacturasId(codComprobante1, 3, 1);
					SocFacturas factura = new SocFacturas(id, nit, soli, solic.getMontoAdj().multiply(solic.getCotiz()), BigDecimal.valueOf(0), solic
							.getMontoAdj().multiply(solic.getCotiz()), tcBase, "VENTA DE DIVISAS", cveRuc);
					SocFacturasDao socFacturaDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
					socFacturaDao.saveOrUpdate(factura);
				}
			}
			total0 = total0.add(solic.getMontoAdj() != null ? solic.getMontoAdj() : BigDecimal.valueOf(0));
		}

		cambio.setVend(total0);

		socCambioDao.saveOrUpdate(cambio);
		log.info("Subasta Procesada, monto adjudicao " + total0 + " para fecha " + cambio.getFecha());

		return estado;
	}

	private String formatearMonto(BigDecimal monto) {
		int pos = 0;
		int ll = 0;
		int sep = 0;
		String valor = monto.toString();
		String montoT = "";

		valor = valor.replace('.', ',');
		pos = valor.indexOf(',');
		if (pos > -1) {
			if (valor.length() > 6) {
				valor = valor.substring(0, pos + 3);
				ll = pos - 1;
				sep = ll - 3;
				if (sep > -1) {
					montoT = valor.substring(0, sep + 1) + "." + valor.substring(sep + 1);
					valor = montoT;
					ll = sep;
					sep = ll - 3;
					if (sep > -1)
						montoT = valor.substring(0, sep + 1) + "." + valor.substring(sep + 1);
				}
			} else {
				montoT = valor;
			}
		}

		return montoT;
	}

	private String obtGestion() {
		String formato = "yyyy";
		SimpleDateFormat dateFormat = new SimpleDateFormat(formato);
		return dateFormat.format(new Date());
	}

	public void setResponseContext(ResponseContext responseContext) {
		this.responseContext = responseContext;
	}

	public ResponseContext getResponseContext() {
		return responseContext;
	}
}
