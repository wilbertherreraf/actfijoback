package gob.bcb.service;

import java.io.File;
import java.util.Properties;
import java.util.function.Function;

import org.apache.activemq.util.ServiceListener;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.util.StringUtils;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.lavado.client.HandlerGeneratorLauCli;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioPortiaSwift.PortiaService;
import gob.bcb.service.servicioSioc.MsgMailListener;
import gob.bcb.service.servicioSioc.ServicioSiocListener;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;


@SpringBootApplication(exclude = {HibernateJpaAutoConfiguration.class,JpaRepositoriesAutoConfiguration.class})
@ImportResource({"classpath:applicationcontextSioc.xml", "classpath:applicationcontextSiocCoin.xml","classpath:applicationcontextPortia.xml"})
public class SiocServer  extends SpringBootServletInitializer{
	private static final Log log = LogFactory.getLog(SiocServer.class);
	
	public static void main(String[] args) {
		initConfig();
		ApplicationContext applicationContext = SpringApplication.run(SiocServer.class, args);

		
		log.info("Iniciando servicio ...");
		//SeverMainSioc instance = new SeverMainSioc();
		
		//ApplicationContext applicationContext = null;
		//initConfig();

		String[] appContextList = { "classpath:applicationcontextSioc.xml", "classpath:applicationcontextSiocCoin.xml",
				"classpath:applicationcontextPortia.xml" };

		try {
			//applicationContext = instance.serverService.runServer(appContextList);
			//applicationContext = new ClassPathXmlApplicationContext(appContextList);
			((AbstractApplicationContext) applicationContext).registerShutdownHook();
//			
			for(String names : applicationContext.getBeanDefinitionNames()) {
				log.info(names);
			}
				
			String siocQUEUE = (String) applicationContext.getBean("siocQUEUE");
			log.info("Nombre de cola configurada : " + siocQUEUE);
			ConfigurationServ.setParamsSystem("siocQUEUE", siocQUEUE);
			//////////////////////////////////////////////////////////
			SessionFactory sessionFactorySioc = (SessionFactory) applicationContext.getBean("sessionFactoryBean");
			SessionFactory sessionFactoryBeanSiocCoin = (SessionFactory) applicationContext
					.getBean("sessionFactoryBeanSiocCoin");
			SessionFactory sessionFactoryBeanPortia = (SessionFactory) applicationContext
					.getBean("sessionFactoryBeanPortia");
			QueryProcessor.setSessionFactory(sessionFactorySioc);
			QueryProcessor.setNameSessionFactory(Constants.PROP_ALIAS_SIOC);
			SiocCoinService.setSessionFactory(sessionFactoryBeanSiocCoin);
			SiocCoinService.setNameSessionFactory(Constants.PROP_ALIAS_COIN);
			PortiaService.setSessionFactory(sessionFactoryBeanPortia);
			PortiaService.setNameSessionFactory(Constants.PROP_ALIAS_PORTIA);
			//////////////////////////////////////////////////////////
			log.info("antes de la inicializaci n de la colita 'ServiceListener' JMS");
//			ServicioSiocListener servicioSiocListener = (ServicioSiocListener) applicationContext
//					.getBean("ServiceListener");
			ServicioSiocListener servicioSiocListener = (ServicioSiocListener) applicationContext
			.getBean(ServicioSiocListener.class);
			servicioSiocListener.init(sessionFactorySioc);

//			MsgMailListener msgMailListener = (MsgMailListener) applicationContext.getBean("MailListener");
			MsgMailListener msgMailListener = (MsgMailListener) applicationContext.getBean(MsgMailListener.class);
			msgMailListener.init(sessionFactorySioc);
			log.info("===============oo000OOOOO000oo===============");
			log.info("~~~~Servicio iniciado a la espera de mensajes~~~~");
//			//instance.serverService.stop();
		} catch (Exception e) {
			log.error("ERROR al iniciar servicio " + e.getMessage(), e);
		} 
		
	}
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(SiocServer.class);
    }
	 public static void initConfig(){
	    	if (ConfigurationServ.isConfigured()){
	    		log.info("Iniciando configuracion ya fue configurada");
	    		return;
	    	}
	    	log.info("Iniciando seteo configuracion");
			Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
			String pathHome = properties.getProperty("path.home");
			ConfigurationServ.setServiceName(properties.getProperty("service.name"));
			if (pathHome == null) {
				throw new RuntimeException("Parametro [path.home] requerido no esta definido");
			}
			File f = new File(pathHome, ConfigurationServ.CONFIG_PROPERTIES);
			if (!f.exists()) {
				throw new RuntimeException(
						"Archivo " + ConfigurationServ.CONFIG_PROPERTIES + " inexistente " + f.getAbsolutePath());
			}
			
			pathHome = StringUtils.cleanPath(new File(f.getAbsolutePath()).getParent());
			log.info("pathHome: " + pathHome);

			ConfigurationServ.setHomeProperty(pathHome);
			ConfigurationServ.init(pathHome);

			log.info("Inicializando cliente LAU");
			try {
				HandlerGeneratorLauCli.initCurrentInstance(pathHome, Constants.CODAPP_SIOC);
			} catch (Exception e) {
				log.error("Error al inicializar cliente LAU " + e.getMessage(), e);
				throw new RuntimeException("Error al inicializar cliente LAU " + e.getMessage(), e);
			}
			String urlBroker = ConfigurationServ.getConfigProperty("jms.broker.url");

			if (urlBroker == null) {
				throw new RuntimeException("Par metro [jms.broker.url] requerido no est  definido");
			}
			gob.bcb.core.jms.Constants.setUrlBroker(urlBroker);
	    }
}
