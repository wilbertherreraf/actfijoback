package gob.bcb.service.servicioSioc.mail;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;

public class MsgLogic {
	public static final String ln = "" + '\r' + '\n';
	private static final Log log = LogFactory.getLog(MsgLogic.class);
	public static String IP_SMTP = null;
	public static int PORT_SMTP;

	public MsgLogic() {

	}

	public void addMsg() {

	}

	public static List<String> listaDeCorreos0(String tipo, String codInstitucion, String accion, boolean enviarAIFA) {
		// tipo: tipo del mensaje
		// se modifica el valor de enviarAIFA para asegurar que haya el valor
		// institucion
		// sera verdadero si se especifique que se envie y ademas exista una
		// institucion
		enviarAIFA = enviarAIFA && codInstitucion != null && !codInstitucion.trim().isEmpty();

		List<String> correos = new ArrayList<String>();
		Map<String, String> correosMap = new HashMap<String, String>();

		String query = "select u.sol_codigo, u.usr_email, u.usr_notifica " + "from soc_usuariosol u " + "where u.cla_vigente = 1 ";
		query = query + "and u.usr_email is not null ";
		if (enviarAIFA) {
			query += "and u.sol_codigo in ('" + codInstitucion + "','900') ";
		} else {
			query += "and u.sol_codigo = '900' ";
		}

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "sol_codigo, usr_email, usr_notifica".split(","));
		String usrEmail = "";
		String usrNotifica = "";
		String solCodigo = "";
		boolean notifica = false;
		for (Map<String, Object> res : resultado1) {
			usrEmail = (String) res.get("usr_email");

			if (StringUtils.isBlank(usrEmail)) {
				continue;
			}

			usrNotifica = (String) res.get("usr_notifica");
			solCodigo = (String) res.get("sol_codigo");
			notifica = false;
			if (!StringUtils.isBlank(usrNotifica)) {
				String[] tiposNotificaciones = usrNotifica.split(",");

				if (tiposNotificaciones != null && tiposNotificaciones.length > 0) {
					for (String tipoNot : tiposNotificaciones) {
						if (tipoNot.equalsIgnoreCase(tipo)) {
							notifica = true;
							break;
						}
					}
				}

			}

			if (!StringUtils.isBlank(accion) && accion.equals("ERROR")) {
				// es un correo de exception
				if (notifica) {
					// se verifica que tipos de exceptiones se notificara
					if (!correosMap.containsKey(usrEmail)) {
						correos.add(usrEmail);
						correosMap.put(usrEmail, usrEmail);
					}
				}
			} else {
				if (!solCodigo.equals("SOPORTE")) {
					// correos comunes y silvestres para el area y entidad
					if (!correosMap.containsKey(usrEmail)) {
						correos.add(usrEmail);
						correosMap.put(usrEmail, usrEmail);
					}
				}
			}

		}

		log.info("correos para " + tipo + " destinatarios registrados " + correos.toString());
		return correos;
	}

	public static String mensajeAdjudicacionAuto(Map<String, String> msgRepuesta) {
		StringBuffer sbf = new StringBuffer("Proceso de Adjudicacion Automotica ejecutado con el resultado:");
		sbf.append(ln);
		sbf.append(ln);
		sbf.append("-----------------------------------------------");
		sbf.append(ln);
		sbf.append(ln);
		for (Map.Entry<?, ?> entry : msgRepuesta.entrySet()) {
			String key = (String) entry.getKey();
			sbf.append(entry.getValue());
			sbf.append(ln);
		}

		sbf.append(ln);
		sbf.append("-----------------------------------------------");
		sbf.append(ln);
		sbf.append(ln + "Atte. " + ln + ln + "Departamento de Operaciones Cambiarias");

		return sbf.toString();
	}

	public static String mensajeSolicitudBolsin(SocBolsin solicitudB, SocSolicitante socSolicitante, SocSolicitante socSolicitanteBenef, String accion) {
		StringBuffer sbf = new StringBuffer("");
		sbf.append("Estimado(a) usuario(a),\n\n" + "Le comunicamos que en el sistema SIOC del Banco Central de Bolivia \nse registro una operacion\n"
				+ "\n---------------------------------------------------------\n");
		sbf.append("Entidad: " + socSolicitante.getSolPersona() + "\r\n");
		sbf.append("Actividad: " + accion + "\n");
		sbf.append("Cliente: " + socSolicitanteBenef.getSolPersona() + " \r");
		sbf.append("Origen de Recursos: " + solicitudB.getOrigenFondos() + "." + "\n\n");
		sbf.append("Destino de Recursos: " + solicitudB.getDestinoFondos() + "." + "\n\n");
		sbf.append("Motivo de la Transaccion: " + solicitudB.getMotivoFondos() + "." + "\n\n");
		if (!StringUtils.isBlank(solicitudB.getBolCtamn())) {
			sbf.append("Cuenta en Moneda Nacional(BS): " + solicitudB.getBolCtamn() + "." + "\n");
		}
		if (!StringUtils.isBlank(solicitudB.getBolCtame())) {
			sbf.append("Cuenta en Moneda Extranjera(SUS): " + solicitudB.getBolCtame() + " ." + "\n");			
		}
		sbf.append("Monto Solicitado(SUS):[ " + solicitudB.getMontoSol() + "]" + "\n ");
		sbf.append("Tipo de Cambio (BS):[ " + solicitudB.getCotiz() + "]" + "\n");
		sbf.append("Monto Solicitado(BS):[ " + solicitudB.getMontoMN() + "]");
		sbf.append("\n" + "---------------------------------------------------------" + ln);
//		sbf.append("Favor confirmar y reservar fondos respondiendo este mail a garispe@bcb.gob.bo y cvalencia@bcb.gob.bo " + ln + ln);
		sbf.append("Atte. \n\nDepartamento de Operaciones Cambiarias");

		return sbf.toString();
	}

	public static String mensajeRegistroTransExtSistFin(SocSolicitudes solicitudNew, SocSolicitante socSolicitante) {
		StringBuffer sbf = new StringBuffer("Se registro una operacion de Transferencia Sist. Financiero:");
		sbf.append(ln);
		sbf.append(ln + "-----------------------------------------------");
		sbf.append(ln);
		sbf.append(ln);
		sbf.append("Codigo solcitud: " + solicitudNew.getSocCodigo());
		sbf.append(ln);		
		sbf.append("Entidad:[" + socSolicitante.getSolCodigo() + "]" + socSolicitante.getSolPersona());
		sbf.append(ln);		
		sbf.append("Monto:" + solicitudNew.getSocMontome() + " " + solicitudNew.getMoneda());
		sbf.append(ln);		
		sbf.append("Correlativo:" + solicitudNew.getSocCorrelativo());

		sbf.append(ln);
		sbf.append("-----------------------------------------------");
		sbf.append(ln);
		sbf.append(ln + "Atte. " + ln + ln + "Departamento de Operaciones Cambiarias");

		return sbf.toString();
	}

	public static String textoSolicitud(Solicitud solicitud, Integer codDetalle, String tipo, Map<String, String> parametros) {

		StringBuilder msgRepuesta = new StringBuilder();

		if (solicitud.getSocEsquemas() != null) {
			msgRepuesta.append("Operación: [" + solicitud.getSocEsquemas().getEsqCodigo() + "] " + solicitud.getSocEsquemas().getEsqDescrip()
					+ ln);
		}

		msgRepuesta.append("Codigo BCB: " + solicitud.getSolicitud().getSocCodigo() + ln);
		msgRepuesta.append(ln + "Codigo MEFP: " + solicitud.getSolicitud().getCodSolicitudorig() + ln);
		msgRepuesta.append(ln + "Fecha Operacion: " + UtilsDate.stringFromDate(solicitud.getSolicitud().getFecha(), "dd/MM/yyyy") + ln);
		msgRepuesta.append(ln + "Fecha registro: " + UtilsDate.stringFromDate(solicitud.getSolicitud().getFechaReg(), "dd/MM/yyyy H:mm:ss") + ln);

		if (solicitud.getSocSolicitante() != null) {
			msgRepuesta.append(ln + "Entidad:[" + solicitud.getSocSolicitante().getSolCodigo() + "]" + solicitud.getSocSolicitante().getSolPersona());
		}
		msgRepuesta.append(ln + "Monto Solicitado: " + solicitud.getSolicitud().getSocMontome() + " [" + solicitud.getSolicitud().getCodMoneda()
				+ "]");
		SocOpecomi socOpecomiTOTDEBITO = solicitud.buscarClaComision("TOTALPROV", 0);
		if (socOpecomiTOTDEBITO != null)
			msgRepuesta.append(ln + "Monto Provisionado: " + socOpecomiTOTDEBITO.getMontoMo() + " [" + socOpecomiTOTDEBITO.getCodMoneda()
				+ "]");		
		if (solicitud.buscarClaComision("TOTDETMT", codDetalle) != null && solicitud.buscarClaComision("TOTDETMT", codDetalle).getMontoMo() != null
				&& solicitud.buscarClaComision("TOTDETMT", codDetalle).getMontoMo().compareTo(BigDecimal.ZERO) != 0) {
			msgRepuesta.append(ln + "Monto Transferencia:" + solicitud.buscarClaComision("TOTDETMT", codDetalle).getMontoMo() + " ["
					+ solicitud.buscarClaComision("TOTDETMT", codDetalle).getCodMoneda() + "]");
		}

		msgRepuesta.append(ln + "Estado: " + solicitud.getSolicitud().getClaEstado());

		if (parametros != null) {
			if (parametros.containsKey("observacion")) {
				msgRepuesta.append(ln + "OBSERVACION: " + parametros.get("observacion"));
			}
		}

		return msgRepuesta.toString();
	}

	public static String mailException(Throwable e, String accion) {

		StringBuffer sbf = new StringBuffer("Ocurrio un error: " + accion);
		sbf.append(ln);

		sbf.append(ln + e.getMessage());
		sbf.append(ln + e.getCause());
		sbf.append(ln);
		// StringWriter writer = new StringWriter();
		// e.printStackTrace(new PrintWriter(writer));
		// String stackTrace = writer.toString();
		//
		// sbf.append(stackTrace);
		sbf.append(ln + "-----------------------------------------------");
		sbf.append(ln);
		sbf.append(ln + "Atte. " + ln + ln + "Departamento de Operaciones Cambiarias");

		return sbf.toString();
	}

	public static void main(String[] args) {
	    // Double precision issue
        double d1 = 0.01;
        print("d1 = " + d1);

        double d2 = 33.33;
        print("d2 = " + d2);

        double d3 = d2 + d1;
        print("d3 = d2+d = " + d3);

        double d4 = 33.34;
        print("d4 = " + d4);

        // Let's work for BigDecimal
        BigDecimal bd1 = new BigDecimal(0.01);
        print("bd1 = " + bd1.doubleValue());

        BigDecimal bd2 = new BigDecimal(33.33);
        print("bd2 = " + bd2.doubleValue());

        BigDecimal bd3 = new BigDecimal(33.34);
        print("bd3 = " + bd3.doubleValue());

        BigDecimal bd4 = new BigDecimal(33.33 + 0.01);
        print("bd4 = " + bd4.doubleValue());

        // Provide values in String in BigDecimal for better precision
        // if you already have value in double like shown below
        double d11 = 0.1 + 0.1 + 0.1;
        print("d11 = " + d11);

        BigDecimal bd11 = new BigDecimal(String.valueOf(d11)); // You already lost the precision
        print("bd11 = " + bd11.doubleValue());

        /* Convert to string as per your needed precision like 2 for
           example when you might have lost the precision  */
        // Or make sure to do that before addition in double
        double d21 = 0.1;
        BigDecimal bd21 = new BigDecimal(String.valueOf(d21));
        BigDecimal bd22 = bd21.add(bd21).add(bd21);
        print("bd21 = " + bd21.doubleValue() + ", bd22 = " + bd22.doubleValue());

        DecimalFormat df = new DecimalFormat("###.###");
        System.out.println(df.format(bd4));
        System.out.println(NumberFormat.getNumberInstance().format(d11));        
    }

    public static void print(String s) {
        System.out.println(s);
    }

    public static void print(double d) {
        System.out.println(d);
    }

}
