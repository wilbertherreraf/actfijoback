/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.commons.Servicios
 * 26/07/2011 - 14:35:05
 * Creado por Gustavo Flores
 */
package gob.bcb.service.servicioTres.model;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.servicioBolsin.BolsinService;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Clase que contiene los metodos para comunicarse con la capa de bpm y
 * servicios.
 * 
 * @author Gustavo Flores
 * 
 */
public class ServiciosB {
	private static final Log log = LogFactory.getLog(Servicios.class);

	public static List<Map<String, Object>> ejecutarQuery0(String query, String[] namesColumns) {
		log.info("Consulta nativa : " + query);
		if (!BolsinService.isActive()){
			BolsinService.begin();
		}		
		Session session = SessionFactoryUtils.getSession(BolsinService.getSessionFactory(), false);
		List<Map<String, Object>> resultado = new ArrayList<Map<String, Object>>();
		SQLQuery sQLQuery = session.createSQLQuery(query);
		List result = sQLQuery.list();
		Iterator iter = result.iterator();
		if (!iter.hasNext()) {
			log.info("No objects to display.");
			return resultado;
		}

		while (iter.hasNext()) {
			Map<String, Object> fila = new LinkedHashMap<String, Object>();
			Object o = iter.next();
			Class clazz = o.getClass();

			if (clazz.isArray()) {
				// Object[] obj = (Object[]) iter.next();
				int length = Array.getLength(o);
				Object[] obj = (Object[]) o;
				for (int i = 0; i < length; i++) {
					fila.put((i > namesColumns.length ? String.valueOf(i) : namesColumns[i].trim()), obj[i]);
				}
				resultado.add(fila);
			} else {
				fila.put(namesColumns[0], o);
				resultado.add(fila);
			}

		}
		return resultado;
	}
}
