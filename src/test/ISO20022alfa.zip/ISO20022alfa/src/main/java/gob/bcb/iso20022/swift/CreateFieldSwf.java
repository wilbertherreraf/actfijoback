package gob.bcb.iso20022.swift;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.dao.SwfMencamposIsoDao;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.rules.Engine;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.translate.FormatEngine;
import gob.bcb.iso20022.utilsBank.Agreement;
import gob.bcb.iso20022.utilsBank.IsoCountry;
import gob.bcb.iso20022.utilsBank.IsoCurrency;

public abstract class CreateFieldSwf {
	protected static final Logger log = LoggerFactory.getLogger(CreateFieldSwf.class);
	FieldSwf fieldSwf;
	
	public CreateFieldSwf() {
	}
	public CreateFieldSwf(Instruccion instruccion, SwfMencamposIsoDao swfMencamposDaoIn) {
		createService(instruccion,swfMencamposDaoIn);
	}
	
	public void createService(Instruccion instruccion, SwfMencamposIsoDao swfMencamposDaoIn) {
		String formato = instruccion.getSwfMsgParam().getMenFormato();
		if (FileFormat.MX.toString().equals(formato) ) {
			fieldSwf = new FieldSwfMx() {};
		} else if (FileFormat.MT.toString().equals(formato) ) {
			fieldSwf = new FieldSwfMt() {};
		} else {
			throw new RuntimeException("Formato no reconocido " + formato);
		}
		fieldSwf.setSwfMencamposIsoDao(swfMencamposDaoIn);		
		fieldSwf.instruccion = instruccion;
	}
	
	public Instruccion initInstruccion() {
		fieldSwf.initInstruccion();
		return fieldSwf.instruccion;
	}
	
	public void recuperarSwfCampos(String typeMessage, String bloque) {
		fieldSwf.recuperarSwfCampos(typeMessage, bloque);
	}

	public void recuperarCampos( String bloque) {
		try {
			fieldSwf.recuperarSwfCampos(fieldSwf.instruccion.getSwfMsgParam().getMenIdTMessageTx(), bloque);
		} catch (Exception e) {
			throw new RuntimeException("Error al inicializar traductor(MT o MX) " + e.getMessage(), e);
		}		
	}
	
	public MappingTable getMappingTable() {
		return fieldSwf.instruccion.getMappingTable();
	}
	
	public void generaHeaderMsg() {
		fieldSwf.generaHeaderMsg();
	}
	
	public void initEngine(){
		try {
			fieldSwf.initEngine();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	public void registerFuncsDef() {
		fieldSwf.registerFactsDef();
	}
	
	public CreateFieldSwf addFact(String key, Object f) {
		MappingTable mappingTable = fieldSwf.instruccion.getMappingTable();
		mappingTable.putFact(key, f);
		return this;
	}
	
	public void addMethodCust(String nameMethod, Method method) {
		fieldSwf.formatEngine.getEngine().addMethod(nameMethod, method);
		
	}
	public void translate() {
		fieldSwf.translate();
		
	}
	public void translatePost() {
		fieldSwf.translatePost();
	}
	public String createMsgSwift() {
		return fieldSwf.generateMsg();
	}
	
	public Instruccion getInstruccion() {
		return fieldSwf.instruccion; 
	}
	
	public List<String> validateSyntax() {
		SwiftMessageAbstract sma = getInstruccion().getMessageHolder();
		if (sma == null)
			return new ArrayList<>();
		try {
			return sma.validateSyntax();
		} catch (Exception e) {
			log.error("Error al validar MX " + e.getMessage());
			return new ArrayList<>();
		}
	}
	
}
