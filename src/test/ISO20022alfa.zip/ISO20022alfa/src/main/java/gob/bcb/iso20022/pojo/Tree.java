package gob.bcb.iso20022.pojo;

import java.util.List;

public class Tree {
	Node root;

    public Tree() {
        root = new Node();
//        root.setNombre("Root");
    }

    public Tree(Node root) {
        this.root = root;
    }

    public Node getRoot() {
        return root;
    }

    public void setRoot(Node root) {
        this.root = root;
    }

    public static void addChild(Node parent, Node child) {
    	if (parent == null || child == null)
    		return;
    	
        parent.getChildArray().add(child);
        child.setParent(parent);

    }
}
