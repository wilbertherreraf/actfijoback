package gob.bcb.iso20022.swift;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.AbstractMessage;
import com.prowidesoftware.swift.model.mx.JaxbContextCacheImpl;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;

import gob.bcb.iso20022.dao.SwfMencamposIsoDao;
import gob.bcb.iso20022.exceptions.CompileException;
import gob.bcb.iso20022.exceptions.DataValidationSwitfException;
import gob.bcb.iso20022.exceptions.DuplicateNameException;
import gob.bcb.iso20022.exceptions.ParseException;
import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.CodNemoCompo;
import gob.bcb.iso20022.pojo.Node;
import gob.bcb.iso20022.translate.FormatEngine;
import gob.bcb.iso20022.utils.UtilsDate;

public abstract class FieldSwf {
	protected static final Logger log = LoggerFactory.getLogger(FieldSwf.class);
	public static final String FACT_SWFCMP = "swfcmp";
	protected Instruccion instruccion;
	private SwfMencamposIsoDao swfMencamposDao;
	protected FormatEngine formatEngine;
	Function<SwfMencampos, Boolean> evalFldCondicion = TemplateGenFSwf.evalFldCondicion(instruccion);
	Function<SwfMencampos, List<CampoForm>> evalFldExpresion = TemplateGenFSwf.evalFldExpresion(instruccion);
	Function<SwfMencampos, List<CampoForm>> evalFldReglasswf = TemplateGenFSwf.evalReglasswf(instruccion);

	public void initInstruccion() {
		if (instruccion.getMappingTable() == null) {
			log.info("Prams iniciales::> " + instruccion.getSwfMsgParam().toStringBas() + " " + instruccion.getSwfMsgParam().getMenIdoperacion());
			dataValidation();

			MappingTable mappingTable = new MappingTable(instruccion.getSwfMsgParam().getMenTypemessage(),
					FileFormat.valueOf(instruccion.getSwfMsgParam().getMenFormato()), FileFormat.valueOf(instruccion.getSwfMsgParam().getMenFormato()));

			instruccion.setMappingTable(mappingTable);
		}
	}

	public void initEngine() throws DuplicateNameException, CompileException, ParseException {
		String typeMessage = instruccion.getSwfMsgParam().getMenTypemessage();
		List<SwfMencampos> swfMencamposList = instruccion.swfMencamposList();
		formatEngine = FormatEngine.getInstance().readRulesExt(typeMessage, swfMencamposList, instruccion.getSwfMsgParam().getMenFormato());
		log.info("Engine inicializado {} con regs. {}", typeMessage, swfMencamposList.size());

		formatEngine.initEngineRules();
	}

	public void dataValidation() {
		SwfMsgParam swfMsgParam = instruccion.getSwfMsgParam();

		if (swfMsgParam == null)
			throw new DataValidationSwitfException("Datos de parametros (SwfMsgParam) requerido.");

		if (StringUtils.isBlank(swfMsgParam.getMenFormato()))
			throw new DataValidationSwitfException("Formato (Estandar) no especificado.");

		if (StringUtils.isBlank(swfMsgParam.getMenTypemessage()))
			throw new DataValidationSwitfException("Tipo de mensaje (typeMessage) no especificado.");

		if (StringUtils.isBlank(swfMsgParam.getMenIdTMessageTx()))
			throw new DataValidationSwitfException("Codigo de Tipo de mensaje (mensaje transaccional) no especificado.");

		if (StringUtils.isBlank(swfMsgParam.getMenEmisor()))
			throw new DataValidationSwitfException("Bic emisor debe tener valor.");

		if (StringUtils.isBlank(swfMsgParam.getMenReceiver()))
			throw new DataValidationSwitfException("Bic receiver debe tener valor.");
		
		if (swfMsgParam.getFileFormat() == FileFormat.MX && StringUtils.isBlank(swfMsgParam.getMenHdrversion()))
			throw new DataValidationSwitfException("Version de header MX requerido.");
	};

	public abstract String generateMsg();

	public abstract void settingHdr(AbstractMessage mt);

	public abstract void recuperarSwfCampos(String typeMessage, String bloque);

	public abstract void generaHeaderMsg();

	public abstract void registerFactsDef();

	public abstract void translate();

	public abstract void translatePost();

	public Function<SwfMencampos, List<CampoForm>> evalMenCampos() {
		return swfMencampos -> {
			List<CampoForm> campoFormList = new ArrayList<>();

			Boolean campoFormCond = evalFldCondicion.apply(swfMencampos);
			if (!campoFormCond) {
				return campoFormList;
			}

			List<CampoForm> cfDefaultList = TemplateGenFSwf.evalFldDefault(swfMencampos);
			cfDefaultList.forEach(cf -> {
				CampoFormUtils.addIfNotExistCF().accept(cf, campoFormList);
			});

			List<CampoForm> cfExprList = evalFldExpresion.apply(swfMencampos);
			cfExprList.forEach(cf -> {
				// se sobre escribe si existe uno anterior
				CampoFormUtils.mergeCampoForm().accept(cf, campoFormList);
			});

			List<CampoForm> cfReglaSwfList = evalFldReglasswf.apply(swfMencampos);
			cfReglaSwfList.forEach(cf -> {
				CampoFormUtils.addIfNotExistCF().accept(cf, campoFormList);
			});

			return campoFormList;
		};
	}

	public Function<SwfMencampos, List<SwfMencampos>> opcionCmpValida() {
		return swfMencamposIn -> {
			List<SwfMencampos> swfMencamposList = swfMencamposDao.opcionesDeCampo(swfMencamposIn.getMtfCodmt(), swfMencamposIn.getMtfNro(),
					swfMencamposIn.getMtfGrpopt(), swfMencamposIn.getMtfBloque());

			if (swfMencamposList.size() <= 1) {
				return swfMencamposList;
			}

			List<SwfMencampos> swfMencamposOptSelList = new ArrayList<>();

			for (SwfMencampos swfMencampos : swfMencamposList) {
				swfMencamposOptSelList.add(swfMencampos);
			}

			return swfMencamposOptSelList;
		};
	}

	public SwfMencamposIsoDao getSwfMencamposIsoDao() {
		return swfMencamposDao;
	}

	public void setSwfMencamposIsoDao(SwfMencamposIsoDao swfMencamposDao) {
		this.swfMencamposDao = swfMencamposDao;
	};

	public Predicate<SwfMencampos> registradoComoOptSelecc() {
		return swfMencampos -> {
			CodNemoCompo codNemoCompo = TemplateGenFSwf.builtFromNemoCodCmpF.apply(swfMencampos.getMtfNemo(), "OPTSEL");
			Optional<CampoForm> cmpFOpt = TemplateGenFSwf.findEntPropOperInstr(instruccion).apply(codNemoCompo.formatSGFn(), null);
			Optional<CampoForm> cmpFOptSelNemo = TemplateGenFSwf.findEntPropOperInstr(instruccion).apply(swfMencampos.getMtfNemo(), "OPTSEL");

			return (cmpFOpt.isPresent() && cmpFOpt.get().getValor().equalsIgnoreCase(codNemoCompo.getCodCampoLit()))
					|| (cmpFOptSelNemo.isPresent() && cmpFOptSelNemo.get().getValor().equalsIgnoreCase(codNemoCompo.getCodCampoLit()));
		};
	}

	public static Predicate<Node<SwfMencampos>> padreMandatory() {
		return nodeSwfCampo -> nodeSwfCampo.hasParent() ? TemplateGenFSwf.mandatorySwfCampos().test((SwfMencampos) nodeSwfCampo.getParent().getSwfMencampos())
				: false;
	}

	public static Predicate<Node<SwfMencampos>> mandatoryCampoYPadre() {
		return nodeSwfCampo -> {
			return TemplateGenFSwf.mandatorySwfCampos().test(nodeSwfCampo.getSwfMencampos()) && padreMandatory().test(nodeSwfCampo);
		};
	}

	public static String bizMsgIdr(SwfMsgParam swfMensaje) {
		return StringUtils.trim(swfMensaje.getMenCodapp() + "_" + swfMensaje.getMenGestion()) + "_" + swfMensaje.getMenCodmen() + "_"
				+ StringUtils.trim(swfMensaje.getMenIdoperacion());
	}

	public static void recTreeCampos(Node<SwfMencampos> node, LinkedHashMap<Integer, SwfMencampos> treeCampos) {
		SwfMencampos swfMencampos = node.getSwfMencampos();
		if (swfMencampos != null)
			treeCampos.put(swfMencampos.getMtfId(), swfMencampos);
		node.getChildArray().forEach(ch -> {
			recTreeCampos(ch, treeCampos);
		});
	}

	public static String msgID(Integer corrIn, String codUser) {
		String userIniciales = StringUtils.trim(codUser);

		String corr = String.format("%04d", (corrIn == null ? 0 : corrIn));
		String fecStr = UtilsDate.stringFromDate(new Date(), "ddMMyy");

		String valor = corr + "/" + fecStr + "/" + userIniciales;

		return valor;
	}
}
