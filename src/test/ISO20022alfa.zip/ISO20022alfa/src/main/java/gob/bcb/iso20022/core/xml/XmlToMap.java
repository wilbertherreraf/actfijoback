package gob.bcb.iso20022.core.xml;

import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.Node;
import org.dom4j.VisitorSupport;
import org.dom4j.XPath;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.dom4j.tree.DefaultElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.github.simy4.xpath.XmlBuilder;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;
import com.prowidesoftware.swift.model.MxNode;
import com.prowidesoftware.swift.model.mx.XMLGregorianCalendarAdapter;

import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.pojo.Tree;
import gob.bcb.iso20022.swift.CampoFormUtils;
import gob.bcb.iso20022.utils.UtilsDate;

public class XmlToMap<T> {
	public static final transient String PATH_SEPARATOR = "/";
	private static final Logger log = LoggerFactory.getLogger(XmlToMap.class);
	public static Type type = new TypeToken<Map<String, Object>>() {
	}.getType();
	public static Gson gson = new GsonBuilder().registerTypeAdapter(type, new MapDeserializer()).create();

	public static Map<String, String> jsonToMap(String json, String root, boolean excludeNumbers, int minlen) {
		LinkedTreeMap<String, String> outMap = new LinkedTreeMap<String, String>();

		Map<String, Object> outMapObj = jsonToMap(json, root);
		outMapObj.forEach((k, v) -> {
			if (excludeNumbers) {
				if (String.class.isAssignableFrom(v.getClass()) && !NumberUtils.isNumber(v.toString())) {
					if (v.toString().length() >= minlen) {
						outMap.put(k, v.toString());
					}
				}

			} else {
				outMap.put(k, v.toString());
			}
		});
		return outMap;
	}

	public static Map<String, Object> jsonToMap(String json, String root) {
		long ts = System.currentTimeMillis();
		Map<String, Object> blendedMap = gson.fromJson(json, type);
		LinkedTreeMap<String, Object> outMap = new LinkedTreeMap<String, Object>();

		mapTree(root, blendedMap, outMap);

		return outMap;
	}

	public static void mapTree(String root, Map<String, Object> map, Map<String, Object> outMap) {

		for (Map.Entry<String, Object> entry : map.entrySet()) {
			String ntree = root + MxNode.PATH_SEPARATOR + entry.getKey();

			if (entry.getValue() instanceof LinkedTreeMap) {
				Map<?, ?> mapa = (Map<?, ?>) entry.getValue();
				if (mapa.containsKey("year") && mapa.containsKey("month")) {
					String strdate = String.format("%02.0f-%02.0f-%04.0f", NumberUtils.toFloat(mapa.get("day").toString()),
							NumberUtils.toFloat(mapa.get("month").toString()), NumberUtils.toFloat(mapa.get("year").toString()));
					Date date = UtilsDate.dateFromString(strdate, "dd-MM-yyyy");
					outMap.put(ntree, date);
				} else {
					mapTree(ntree, (Map<String, Object>) entry.getValue(), outMap);
				}

			} else if (entry.getValue() instanceof ArrayList) {
				ArrayList<?> arr = (ArrayList<?>) entry.getValue();
				Integer cont = 0;
				if (arr.size() > 1) {
					cont = 1;
				}
				for (Object vv : arr) {
					boolean ip = CampoFormUtils.getTypeAsignable(vv.getClass()) != null;
					if (!ip) {
						mapTree(ntree, (Map<String, Object>) vv, outMap);
					} else {
						String arrStr = arr.size() > 1 ? "[" + cont + "]" : "";
						String name = ntree;
						if (entry.getKey().equals("value")) {
							name = root;
						}
						outMap.put(name + arrStr, vv);
						cont++;
					}
				}
				;
			} else if (entry.getValue() instanceof JsonObject) {
				String json = entry.getValue().toString();
				Map<String, Object> blendedMap = gson.fromJson(json, type);
				if (blendedMap.containsKey("year") && blendedMap.containsKey("month")) {
					String strdate = String.format("%02.0f-%02.0f-%04.0f", NumberUtils.toFloat(blendedMap.get("day").toString()),
							NumberUtils.toFloat(blendedMap.get("month").toString()), NumberUtils.toFloat(blendedMap.get("year").toString()));
					Date date = UtilsDate.dateFromString(strdate, "dd-MM-yyyy");
					outMap.put(ntree, date);
				} else {
					mapTree(ntree, blendedMap, outMap);
				}
			} else {
				String name = ntree;
				if (entry.getKey().equals("value")) {
					name = root;
				}
				outMap.put(name, entry.getValue());
			}
		}
	}

	public static <T> List<T> xmlToTreeMap(String xml, HashMap<Integer, T> mapCmp) {
		try {
			LinkedList<T> r = xmlToTreeList(xml, mapCmp);
			return r;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> LinkedList<T> xmlToTreeList(String xml, HashMap<Integer, T> mapCmp) {
		try {
			org.dom4j.Document doc = DocumentHelper.parseText(xml);
			Element e = doc.getRootElement();
			String exp = e.getPath();
			LinkedList<T> r = new LinkedList<T>();
			subNodesObj(doc, mapCmp, exp, r);
			return r;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> void subNodesObj(Document doc, HashMap<Integer, T> mapCmp, String exprin, LinkedList<T> r) {
		String expr = String.format(exprin + "/*");
		XPath xpath = DocumentHelper.createXPath(expr);

		List<Node> nodes = xpath.selectNodes(doc);
		for (int i = 0; i < nodes.size(); i++) {
			Element e = (Element) nodes.get(i);
			String cod = e.getText().trim();
			if (StringUtils.isBlank(cod)) {
				String exprn = e.getPath();
				subNodesObj(doc, mapCmp, exprn, r);
			} else {
				T pos = mapCmp.get(Integer.parseInt(cod));
				r.add(pos);
			}
		}
	}

	public static LinkedTreeMap<String, String> xmlToProps(final String xml) {
		LinkedTreeMap<String, String> outMap = new LinkedTreeMap<String, String>();
		if (StringUtils.isBlank(xml)) {
			return outMap;
		}
		try {
			org.dom4j.Document doc = DocumentHelper.parseText(xml);
			doc.accept(new NameSpaceCleaner());

			Element root = doc.getRootElement();
			String exp = root.getPath(); // "/" + root.getQualifiedName();

			subNodesObj(root.getDocument(), exp, outMap);

			return outMap;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static LinkedTreeMap<String, String> xmlToPropsNS(String xml) {
		LinkedTreeMap<String, String> outMap = new LinkedTreeMap<String, String>();
		if (StringUtils.isBlank(xml)) {
			return outMap;
		}
		try {
			org.dom4j.Document doc = DocumentHelper.parseText(xml);

			Element root = doc.getRootElement();
			String exp = root.getPath(); // "/" + root.getQualifiedName();

			subNodesObj(root.getDocument(), exp, outMap);

			return outMap;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}	
	public static void subNodesObj(Document doc, String exprin, LinkedTreeMap<String, String> propsXml) {
		String expr = String.format(exprin + "/*");
		XPath xpath = DocumentHelper.createXPath(expr);
		
		List<Node> nodes = xpath.selectNodes(doc);
		//log.info(" Expr " + expr + " [" + nodes.size()+ "]");
		for (int i = 0; i < nodes.size(); i++) {
			Node n = nodes.get(i);
			Element e = (Element) n;
			String value = e.getTextTrim();
			String path = e.getPath();
			
//			 log.info(" Expr " + e.getName() + " "+ e.elements().size() + " " +
//			 e.selectNodes(path).size() + " " + e.getUniquePath(e.getParent()) + " path: "
//			 + path + " uniq: " + e.getUniquePath() + " prefix " + e.getNamespacePrefix());
			if (e.elements().size() > 0) {
				subNodesObj(doc, path, propsXml);
			} else {
				String name = e.getUniquePath();
//				log.info(nodes.size() + "	" + expr + " ::: " + e.getPath() + " ATR: " + e.attributes());
				propsXml.put(name, value);
				e.attributes().forEach(a -> {
					propsXml.put(name + "/@" + a.getName(), a.getValue());
				});
			}
		}
	}

	public static Optional<Node> findFirst(Node node, String name) {
		try {
			if (node != null) {
				Element e = (Element) node;
				for (Element en : e.elements()) {
					Node n = en;
					if (n.getName().equalsIgnoreCase(name)) {
						return Optional.of(n);
					}
				}
			}
			return Optional.empty();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Optional<Node> findFirstByName(String xml, String name) {
		try {
			org.dom4j.Document doc = DocumentHelper.parseText(xml);
//			doc.accept(new NameSpaceCleaner());
			Optional<Node> n = findFirstByName(doc, name);
			return n;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Optional<Node> findFirstByName(final Document doc, String name) {
		try {
			final String[] segments = StringUtils.split(name, PATH_SEPARATOR);
			Element root = doc.getRootElement();
			Node nr = root.node(0);
			String exp = root.getPath() + "/*"; // "/" + root.getQualifiedName();
			// exp = name;
			// gob.bcb.iso20022.pojo.Node<Node> padre =
			// gob.bcb.iso20022.pojo.Node.createNodeDefault("typeMsgTx", "8");
			gob.bcb.iso20022.pojo.Node<Node> padre = new gob.bcb.iso20022.pojo.Node(nr);
			padre.setSwfMencamposCrr(nr);

			Node found = findNode(nr, exp, 0, segments, null, padre);
			print(padre, 0);
			return Optional.ofNullable(found);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static void print(gob.bcb.iso20022.pojo.Node<Node> node, Integer level) {
		String corr = String.format("%0" + (level + 1) + "d", 0);
		log.info(corr + " : "
				+ (node.hasCurrent() ? node.getSwfMencamposCrr().getName() + " => " + StringUtils.trimToEmpty(node.getSwfMencamposCrr().getText())
						: " NULO "));
		node.getChildArray().forEach(ch -> {
			print(ch, level + 3);
		});
	}

	public static Node findNode(final Node doc, String exprin, Integer index, String[] segments, gob.bcb.iso20022.pojo.Node<Node> padre,
			gob.bcb.iso20022.pojo.Node<Node> nodoCurrent) {
		HashMap<Integer, SwfMencampos> mapCmp;

		if (index >= segments.length) {
			return null;
		}
		if (padre != null)
			Tree.addChild(padre, nodoCurrent);

		String expr = String.format(exprin);
		XPath xpath = DocumentHelper.createXPath(expr);
		String localname = segments[index];
		int nextIndex = index + 1;
		List<Node> nodes = xpath.selectNodes(doc);

		if (!nodoCurrent.hasCurrent()) {
			nodoCurrent.setSwfMencamposCrr(doc);
		}

		for (int i = 0; i < nodes.size(); i++) {
			Node n = nodes.get(i);
			gob.bcb.iso20022.pojo.Node<Node> curr = new gob.bcb.iso20022.pojo.Node(n);
			curr.setSwfMencamposCrr(n);

			Element e = (Element) n;
			String path = e.getPath();
			// log.info(" " + index + " : [" + localname + "] name: " + n.getName() + "
			// path: " + path + " ezise: " + e.elements().size());
			if (localname.equals(".") || StringUtils.equalsIgnoreCase(n.getName(), localname)) {
				if (nextIndex == segments.length) {
					return n;
				} else {
					if (e.elements().size() > 0) {
						gob.bcb.iso20022.pojo.Node<Node> child = new gob.bcb.iso20022.pojo.Node(n);
						child.setSwfMencamposCrr(n);

						Node found = findNode(n, path + "/*", nextIndex, segments, nodoCurrent, child);
						if (found != null) {
							return found;
						}
					} else {
						gob.bcb.iso20022.pojo.Node<SwfMencampos> child = new gob.bcb.iso20022.pojo.Node(n);
						Tree.addChild(nodoCurrent, curr);
					}
				}
			} else {
				if (e.elements().size() > 0) {
					gob.bcb.iso20022.pojo.Node<Node> child = new gob.bcb.iso20022.pojo.Node(n);
					child.setSwfMencamposCrr(n);

					Node found = findNode(n, path + "/*", index, segments, nodoCurrent, child);
					if (found != null) {
						return found;
					}
				} else {
					gob.bcb.iso20022.pojo.Node<SwfMencampos> child = new gob.bcb.iso20022.pojo.Node(n);
					Tree.addChild(nodoCurrent, curr);
				}
			}
		}
		return null;
	}

	public static <T> gob.bcb.iso20022.pojo.Node<T> xmlToNodes(String xml, HashMap<Integer, T> mapCmp, gob.bcb.iso20022.pojo.Node<T> padre) {
		try {
			org.dom4j.Document doc = DocumentHelper.parseText(xml);

			Element root = doc.getRootElement();
			Node nr = root.node(0);
			String exp = root.getPath() + "/*"; // "/" + root.getQualifiedName();
			
			//gob.bcb.iso20022.pojo.Node<T> padre = new gob.bcb.iso20022.pojo.Node<T>();
			//padre.setSwfMencamposCrr(nr);

			buildNodes(nr, exp, 0, null, padre, mapCmp);
			// print(padre, 0);
			return padre;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> void buildNodes(final Node doc, String exprin, Integer index, gob.bcb.iso20022.pojo.Node<T> padre,
			gob.bcb.iso20022.pojo.Node<T> nodoCurrent, HashMap<Integer, T> mapCmp) {

		if (padre != null)
			Tree.addChild(padre, nodoCurrent);

		String expr = String.format(exprin);
		XPath xpath = DocumentHelper.createXPath(expr);
		List<Node> nodes = xpath.selectNodes(doc);

//		if (!nodoCurrent.hasCurrent()) {
//			nodoCurrent.setSwfMencamposCrr(doc);
//		}

		for (int i = 0; i < nodes.size(); i++) {
			Node n = nodes.get(i);
			Element e = (Element) n;
			String path = e.getPath();
			
			gob.bcb.iso20022.pojo.Node<T> curr = new gob.bcb.iso20022.pojo.Node<T>();			
			String cod = e.getText().trim();
			if (!StringUtils.isBlank(cod) ) {
				T t = mapCmp.get(Integer.parseInt(cod));
				curr.setSwfMencampos(t);
				curr.setSwfMencamposCrr(t);
			}
			
			if (e.elements().size() > 0) {
				buildNodes(n, path + "/*", index + 1, nodoCurrent, curr, mapCmp);
			} else {
				Tree.addChild(nodoCurrent, curr);
			}
		}
	}

	public static String xmlFromXPath4J(LinkedHashMap<String, Object> xmlProperties) {
		try {
			org.dom4j.Document document0 = new XmlBuilder().putAll(xmlProperties).build(DocumentHelper.createDocument());
			String cad = xmlToString(document0);
			return cad;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static String xmlSaaFromXPath(LinkedHashMap<String, Object> xmlProperties, String ns) {
		try {
			SaaNamespaceContext saa = new SaaNamespaceContext();
			org.dom4j.Document document0 = new XmlBuilder(saa).putAll(xmlProperties).build(DocumentHelper.createDocument());
			String cad = xmlToString(document0);
			return cad;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static String xmlToString(org.dom4j.Document xml) throws IOException {
		String lineSeparator = System.lineSeparator();
		OutputFormat format = OutputFormat.createCompactFormat();
		format.setIndentSize(4);
		format.setNewlines(true);
		format.setLineSeparator(lineSeparator);
		format.setSuppressDeclaration(true);
		StringWriter result = new StringWriter();
		XMLWriter writer = new XMLWriter(result, format);
		writer.write(xml);

		return result.toString().replaceFirst(lineSeparator, "");
	}

	public static String toJson(Object o) {
		final Gson gson = new GsonBuilder().registerTypeAdapter(XMLGregorianCalendar.class, new XMLGregorianCalendarAdapter()).setPrettyPrinting().create();
		return gson.toJson(o);
	}

	/************************************************/
	private static Optional<Node> findNode00(String path, final Document doc) {
		// ej. /Document/./PmtId/InstrId ./PmtId/InstrId
		// /Document/./GrpHdr/MsgId ./GrpHdr/MsgId
		// /AppHdr/./Fr/./FinInstnId/BICFI
		Element root = doc.getRootElement();
		String exp = root.getPath(); // "/" + root.getQualifiedName();
		Node found = findNode00(root.getDocument(), exp, "");
		return Optional.ofNullable(found);
	}

	private static Optional<Node> findFirstByName00(final Document doc, String name) {
		try {
			Element root = doc.getRootElement();
			String exp = root.getPath(); // "/" + root.getQualifiedName();
			exp = name;
			Node found = findNode00(root.getDocument(), exp, name);
			return Optional.ofNullable(found);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static Node findNode00(final Document doc, String exprin, String localname) {
		String expr = String.format(exprin);
		XPath xpath = DocumentHelper.createXPath(expr);

		List<Node> nodes = xpath.selectNodes(doc);
		// log.info(" Expr " + expr + " [" + nodes.size()+ "]");
		for (int i = 0; i < nodes.size(); i++) {
			Node n = nodes.get(i);
			Element e = (Element) n;
			String path = e.getPath();
			// log.info(" Expr " + e.getName() + " "+ e.getQualifiedName() + " " +
			// e.selectNodes(path).size() + " " + e.getUniquePath(e.getParent()) + " path: "
			// + path + " uniq: " + e.getUniquePath());
			if (StringUtils.equalsIgnoreCase(n.getName(), localname)) {
				return n;
			} else {
				// log.info(" Expr " + e.getName() + " "+ e.elements().size() + " " +
				// e.selectNodes(path).size() + " " + e.getUniquePath(e.getParent()) + " path: "
				// + path + " uniq: " + e.getUniquePath());
				if (e.elements().size() > 0) {
					Node found = findNode00(doc, path, localname);
					if (found != null) {
						return found;
					}
				}
			}
		}
		return null;
	}

	public static final class NameSpaceCleaner extends VisitorSupport {
		public void visit(Document document) {
			((DefaultElement) document.getRootElement()).setNamespace(Namespace.NO_NAMESPACE);
			document.getRootElement().additionalNamespaces().clear();
		}

		public void visit(Namespace namespace) {
			namespace.detach();
		}

		public void visit(Attribute node) {
			if (node.toString().contains("xmlns") || node.toString().contains("xsi:")) {
				node.detach();
			}
		}

		public void visit(Element node) {
			if (node instanceof DefaultElement) {
				((DefaultElement) node).setNamespace(Namespace.NO_NAMESPACE);
			}
		}
	}
}
