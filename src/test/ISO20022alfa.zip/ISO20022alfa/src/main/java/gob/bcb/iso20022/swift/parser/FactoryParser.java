package gob.bcb.iso20022.swift.parser;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;

import com.prowidesoftware.swift.model.AbstractMessage;
import com.prowidesoftware.swift.model.AbstractSwiftMessage;
import com.prowidesoftware.swift.model.MtSwiftMessage;
import com.prowidesoftware.swift.model.mt.AbstractMT;
import com.prowidesoftware.swift.model.mx.AbstractMX;

import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.utils.ParserSwiftMessage;

public class FactoryParser {

	public static SwiftMessageAbstract createParser(String swiftPlano) {
		if (StringUtils.isBlank(swiftPlano)) {
			throw new RuntimeException("Mensaje swift nulo");
		}
		boolean isMT = ParserSwiftMessage.isFormatSwift(swiftPlano);
		SwiftMessageAbstract sma = null;
		if (isMT) {
			sma = new SwiftMessageMT(swiftPlano);
		} else {
			sma = new SwiftMessageMX(swiftPlano);
		}
		return sma.createMsg();
	}

	public static SwiftMessageAbstract createParser(String typeMessage, String swiftPlano) {
		if (StringUtils.isBlank(swiftPlano)) {
			throw new RuntimeException("Mensaje swift nulo");
		}
		boolean isMT = ParserSwiftMessage.isFormatSwift(swiftPlano);
		SwiftMessageAbstract sma = null;
		if (isMT) {
			sma = new SwiftMessageMT(swiftPlano);
		} else {
			sma = new SwiftMessageMX(swiftPlano);
		}
		return sma.typeMessage(typeMessage).createMsg();
	}

//	public static SwiftMessageAbstract createParser(AbstractMessage absMsg, String typeMessage) {
//		if (absMsg.isMT()) {
//			AbstractMT mt = (AbstractMT) absMsg;
//			SwiftMessageMT sma = new SwiftMessageMT(typeMessage, FileFormat.MT);
//			sma.setAbsMsg(mt);
//			sma.createMsg();
//			return sma;
//		} else if (absMsg.isMX()) {
//			AbstractMX mx = (AbstractMX) absMsg;
//			SwiftMessageMX sma = new SwiftMessageMX(typeMessage, FileFormat.MX);
//			sma.setAbsMsg(mx);
//			sma.createMsg();
//			return sma;
//		}
//		return null;
//	}
}
