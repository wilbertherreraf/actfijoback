package gob.bcb.iso20022.swift;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.api.Fact;
import org.jeasy.rules.api.Facts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.field.Field;

import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.pojo.CampoFormTable;
import gob.bcb.iso20022.rules.IAction;
import gob.bcb.iso20022.rules.Rule;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.transforms.AmountCurrTransform;
import gob.bcb.iso20022.transforms.FactValTransform;
import gob.bcb.iso20022.transforms.FieldTransform;
import gob.bcb.iso20022.transforms.FuncDtTransform;
import gob.bcb.iso20022.transforms.GenListRulesTransform;
import gob.bcb.iso20022.transforms.TextSimpleTransform;
import gob.bcb.iso20022.utils.MxDataTypesConversor;

public class MappingTable {
	private final static Logger log = LoggerFactory.getLogger(MappingTable.class);
	private final List<MappingRule> mappingRuleList = new LinkedList<>();
	private FileFormat ffSource;
	private FileFormat ffDestine;
	private final Facts facts = new Facts();
	private String typeMessage;
	
	public MappingTable() {
		
	}
	
	public MappingTable(String typeMessage, FileFormat ffSource, FileFormat ffDestine) {
		this.typeMessage = typeMessage;
		this.ffDestine = ffDestine;
		this.ffSource = ffSource;
	}
	
	public MappingTable addRule(Rule r) {
		MappingRule mapRule = new MappingRule();
		mapRule.setRule(r);
		mapRule.putFacts(facts.asMap());
		
		Supplier<IAction> iaction = mapActions().get(r.getOutcome());
		if (iaction == null) {
			throw new RuntimeException("Transformador inexistente " + r.getOutcome());
		}

		mapRule.setActTransform(iaction.get());
		
		addMappingRule(mapRule);
		return this;
	}
	
	
	public FileFormat getFfSource() {
		return ffSource;
	}

	public FileFormat getFfDestine() {
		return ffDestine;
	}

	public List<MappingRule> getMappingRuleList() {
		return mappingRuleList;
	}
	
	public MappingTable addMappingRule(MappingRule mappingRule) {
		mappingRuleList.add(mappingRule);
		return this;
	}
	
	public Object fact(String key) {
		return facts.get(key);
	}

	public MappingTable putFact(String key, Object fact) {
		if (!StringUtils.isBlank(key) && fact != null ) {
			facts.put(key, fact);			
		}
		
		return this;
	}
	
	public MappingTable newFactAtribs(String nameObj, Map<String, Object> mapAtribs) {
		CampoFormTable cft = new CampoFormTable();
		cft.newEnt(nameObj, mapAtribs);

		putFact(nameObj, cft);			
		
		return this;
	}

	public MappingTable newFactCF(String nameObj, Map<String, CampoForm> mapAtribs) {
		boolean valid = mapAtribs.entrySet().stream().anyMatch(e -> {
			return e.getValue() != null && e.getValue().toString().length() > 0;
		});
		
		if (!valid || mapAtribs.size() == 0) {
			return this;
		}
		
		CampoFormTable cft = new CampoFormTable();
		cft.newEntCF(nameObj, mapAtribs);

		putFact(nameObj, cft);			
		
		return this;
	}
	
	public MappingTable rmFact(String key) {
		facts.remove(key);
		return this;
	}
	
	public MappingTable newFactAndAtribs(String nameObj, Object fact, String subEntity, Map<String, Object> mapAtribs, Boolean recProps) {
		if (fact == null) {
			return this;
		}
		
		CampoFormTable cft = new CampoFormTable(nameObj, fact);
		cft.newSEnt(subEntity, mapAtribs);
		
		if (recProps) {
			cft.recProps();
			putFact(nameObj, cft);
		} else {
			putFact(nameObj, cft);			
		}
		
		return this;
	}
	
	public MappingTable addSubFactToFact(String nameObj, String subEntity, Map<String, Object> mapAtribs) {
		Fact<?> fact = facts.getFact(nameObj);
		if (fact == null || fact.getValue() == null)
			return this;
		
		CampoFormTable cft = (CampoFormTable) fact.getValue();
		cft.newSEnt(subEntity, mapAtribs);
		
		putFact(nameObj, cft);			
		
		return this;
	}
	
	public MappingTable putFacts(Map<String, Object> fact) {
		fact.forEach((k,v) -> {
			putFact(k, v);
		});
		
		return this;
	}
	
	public Map<String, Object> getMapFacts() {
		return facts.asMap();
	}
	
	public LinkedHashMap<String, Object> xpathXmlValue() {
		LinkedHashMap<String, Object> xmlProperties = new LinkedHashMap<String, Object>();

		for (MappingRule mapRule : mappingRuleList) {
			mapRule.getCampos().forEach(cf -> {
				if (cf != null && !StringUtils.isBlank(cf.getCatalogo()) && !StringUtils.isBlank(cf.getValor()))
					xmlProperties.put(cf.getCatalogo(), cf.getValor());
			}); 
		}
		return xmlProperties;
	}

	public List<Rule> noExecs() {
		return mappingRuleList.stream().filter(m -> {
			return m.getCampos().size() == 0; 
		}).map(m -> m.getRule()).collect(Collectors.toList());
	}
	public Map<String, String> toProperties() {
		
		LinkedHashMap<String, Object> xmlPropsObj = xpathXmlValue();
		LinkedHashMap<String, String> xmlProperties = new LinkedHashMap<String, String>();
		xmlPropsObj.forEach((k, v) -> {
			xmlProperties.put(k, v.toString());
		});
		
		return xmlProperties;
	}
	
	public Facts getFacts() {
		return facts;
	}

	public String toXML() {
		String xml = XmlToMap.xmlSaaFromXPath(xpathXmlValue(), "");
		return xml ; //XmlToMap.xmlFromXPath4J(xpathXmlValue());
	}

	public static Map<String, Supplier<IAction>> mapActions() {
		Map<String, Supplier<IAction>> actionsMap = new HashMap<>();

		actionsMap.put(GenListRulesTransform.name, () -> new GenListRulesTransform().addMethod(MxDataTypesConversor.class));
		actionsMap.put(TextSimpleTransform.name, () -> new TextSimpleTransform().addMethod(MxDataTypesConversor.class));
		actionsMap.put(AmountCurrTransform.name, () -> new AmountCurrTransform().addMethod(MxDataTypesConversor.class));
		actionsMap.put(FuncDtTransform.name, () -> new FuncDtTransform().addMethod(MxDataTypesConversor.class));
		actionsMap.put(FactValTransform.name, () -> new FactValTransform().addMethod(MxDataTypesConversor.class));
		actionsMap.put(FieldTransform.name, () -> new FieldTransform().addMethod(MxDataTypesConversor.class));
		
		return actionsMap;
	}
	
	public String getTypeMessage() {
		return typeMessage;
	}

	public void setTypeMessage(String typeMessage) {
		this.typeMessage = typeMessage;
	}

}
