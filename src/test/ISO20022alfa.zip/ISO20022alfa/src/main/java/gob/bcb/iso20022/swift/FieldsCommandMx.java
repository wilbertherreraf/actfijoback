package gob.bcb.iso20022.swift;

import static org.mvel2.templates.TemplateCompiler.compileTemplate;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.mvel2.templates.CompiledTemplate;
import org.mvel2.templates.TemplateRuntime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.utils.MxDataTypesConversor;
import gob.bcb.iso20022.utils.UtilsDate;
import gob.bcb.iso20022.utils.ValidatorCodes;
import gob.bcb.iso20022.utilsBank.iban.Iban;

public class FieldsCommandMx {
	private static final Logger log = LoggerFactory.getLogger(FieldsCommandMx.class);

	final static String VALUE = "VALUE";

	public static Function<SwfMencampos, Optional<CampoForm>> empty() {
		return swf -> Optional.of(new CampoForm());
	}

	public static Function<SwfMencampos, Optional<CampoForm>> vlrCF(CampoForm cf) {
		return swf -> Optional.ofNullable(cf);
	}

	public static Function<SwfMencampos, Optional<CampoForm>> msgId(Date Fecha, Integer corrIn, String userIniciales) {
		return swf -> {
			if (StringUtils.isBlank(userIniciales)) {
				return Optional.empty();
			}
			String corr = String.format("%04d", (corrIn == null ? 0 : corrIn));
			String fecStr = UtilsDate.stringFromDate(Fecha, "ddMMyy");
			String valor = corr + "/" + fecStr + "/" + userIniciales;

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, valor);
			cf.setTipoValor("string");
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> fValTxt(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor))
				return Optional.empty();

			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, valor);
			cf.setTipoValor("string");
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> iban(String valor) {
		return swf -> {
			if (StringUtils.isBlank(valor))
				return Optional.empty();
			boolean val = Iban.isValid(valor);
			if (!val)
				return Optional.empty();
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, valor);
			cf.setTipoValor("string");
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> aba(String valor) {
		return swf -> {
			String vAba = ValidatorCodes.extractAba(valor);
			if (StringUtils.isBlank(vAba))
				return Optional.empty();
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, vAba);
			cf.setTipoValor("string");
			return Optional.of(cf);
		};
	}

	public static Function<SwfMencampos, Optional<CampoForm>> amtCurr(String currency, BigDecimal monto) {
		return swf -> {
			if (StringUtils.isBlank(currency))
				return Optional.empty();
			CampoForm cf = new CampoForm(swf.getMtfCodcampo(), VALUE, "");
			cf.setValDecimal(monto);
			cf.setValorAdic(currency);
			cf.setCatalogo(swf.getMtfXmltag());
			cf.setTipoValor("currency");
			return Optional.of(cf);
		};
	}

	public static CampoForm fGenx(SwfMencampos swfMencampos, String table, String idField, String cmp, String codeset,
			Function<SwfMencampos, Optional<CampoForm>> contentsF) {
//		log.info("Eval: {} {} {} {} nulo {}", table, idField, cmp, codeset, (contentsF == null));
		Optional<CampoForm> cfOpt = Optional.empty();
		if (contentsF != null) {
			cfOpt = contentsF.apply(swfMencampos);
		
			if (!cfOpt.isPresent()) {
				CampoForm cf = new CampoForm(swfMencampos.getMtfCodcampo(), "", "");
				cf.setTipoValor("string");
				return cf;
			}
		}
		cmp = StringUtils.trimToEmpty(cmp);
		codeset = StringUtils.trimToEmpty(codeset);
		CampoForm valorCf = cfOpt.orElse(new CampoForm());
		String valor = valorCf.getValor();
		if (cmp.equalsIgnoreCase("code")) {
			valor = codeset;
			valorCf.setValor(valor);
		}

		return valorCf;
	}

	public static CampoForm fCFNvl(Boolean cond, String valor, String valalter, String action, String tipovalor) {
		if (cond != null && cond == false) {
			if (action != null && action.equalsIgnoreCase("error")) {
				CampoForm cf = new CampoForm("table", "fld", valalter);
				cf.setTipoValor("error");
				cf.setAction("error");
				return cf;
			}
			
			CampoForm cf = new CampoForm("table", "fld", valalter);
			cf.setTipoValor(StringUtils.isBlank(tipovalor) ? "string" : tipovalor);
			cf.setAction(action);
			return cf;
		}
		
		CampoForm cf = new CampoForm("table", "fld", valor);
		cf.setTipoValor(StringUtils.isBlank(tipovalor) ? "string" : tipovalor);
		cf.setAction(action);
		return cf;
	}
	
	public static CampoForm fGenxCf(SwfMencampos swfMencampos, String table, String idField, String cmp, String codeset, CampoForm contents) {
		if (contents == null)
			return null;
		//log.info("ingresando {}:{} - {} - {} = {}", table, idField, cmp, codeset, contents);

		cmp = StringUtils.trimToEmpty(cmp);
		CampoForm valor = contents;

		if (cmp.equalsIgnoreCase("AMTCURR")) {
			valor.setValor(MxDataTypesConversor.isoAmt(contents.getValDecimal()));
			valor.setValorAdic(contents.getValorAdic());
		}
//		si es aba determinar el campo que se almacena en treglas
		return valor;
	}

	public static final Pattern pattern = Pattern.compile("(/[A-Z0-9]{1,8}\\/)");

	public static Map<String, String> mapNarrative(String narr, Map<String, Object> mapf) {
		Map<String, String> cdmp = new LinkedHashMap<String, String>();
		Matcher matcher = pattern.matcher(narr);
		StringBuffer sb = new StringBuffer();
		
		String cdLast = "";
		while (matcher.find()) {
			StringBuffer sb0 = new StringBuffer();
			String codeword = matcher.group(1);
			matcher.appendReplacement(sb0, "");
			if (!StringUtils.isBlank(cdLast)) {
				cdmp.put(cdLast, sb0.toString());
			}
			cdLast = codeword.replaceAll("/", "");
		}
		matcher.appendTail(sb);

		if (!StringUtils.isBlank(cdLast)) {
			cdmp.put(cdLast, sb.toString());
		} else {
			cdmp.put("", sb.toString());
		}

		Map<String, String> cdmpRes = new LinkedHashMap<String, String>();
		StringBuilder sbn = new StringBuilder();
		cdmp.forEach((k, v) -> {
			if (!StringUtils.isBlank(v)) {
				try {
					CompiledTemplate compiled = compileTemplate(v);
					Object o = TemplateRuntime.execute(compiled, mapf);
					String txt = o.toString();
					//String nrrtve = ntveUnStr(k, txt);
					cdmpRes.put(k, txt);
					sbn.append(txt);
				} catch (Exception e) {
					log.error("Error al evaluar expr narrative {}, error: {} ", e.getMessage(), v);
				}
			} else {
				cdmpRes.put(k, "");
			}
		});
		log.info("Narrative: {} -> {}", narr, sbn.toString());
		return cdmpRes;
	}
	
	public static Map<String, Object> mapFuncs() {
		Map<String, Object> vars = new HashMap<String, Object>();
		try {
			vars.put("fEmpty", FieldsCommandMx.class.getMethod("empty"));
			vars.put("fVlrCF", FieldsCommandMx.class.getMethod("vlrCF", CampoForm.class));
			vars.put("fMsgId", FieldsCommandMx.class.getMethod("msgId", Date.class, Integer.class, String.class));
			vars.put("fVlr", FieldsCommandMx.class.getMethod("fValTxt", String.class));
			vars.put("fIban", FieldsCommandMx.class.getMethod("iban", String.class));
			vars.put("fAba", FieldsCommandMx.class.getMethod("aba", String.class));
			vars.put("fAmtCurr", FieldsCommandMx.class.getMethod("amtCurr", String.class, BigDecimal.class));
			vars.put("fCFNvl", FieldsCommandMx.class.getMethod("fCFNvl", Boolean.class, String.class, String.class, String.class, String.class ));			
			vars.put("xGen",
					FieldsCommandMx.class.getMethod("fGenx", SwfMencampos.class, String.class, String.class, String.class, String.class, Function.class));

			return vars;
		} catch (Exception e) {
			log.error("error al registrar metodos " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}
}
