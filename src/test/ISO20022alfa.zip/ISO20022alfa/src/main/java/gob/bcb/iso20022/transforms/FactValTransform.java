package gob.bcb.iso20022.transforms;

import static org.mvel2.templates.TemplateCompiler.compileTemplate;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.mvel2.MVEL;
import org.mvel2.templates.CompiledTemplate;
import org.mvel2.templates.TemplateRuntime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.rules.AbstractAction;
import gob.bcb.iso20022.rules.CompiledRule;
import gob.bcb.iso20022.rules.Rule;
import gob.bcb.iso20022.swift.MappingRule;
import gob.bcb.iso20022.utils.UtilsGeneric;

public class FactValTransform extends AbstractAction<MappingRule, CampoForm> {
	private static final Logger log = LoggerFactory.getLogger(FactValTransform.class);	
	public final static String name = TransformEnum.FACTVAL.toString();

	public FactValTransform() {
		super(name);		
	}

	@Override
	protected CampoForm initializeOutputResult(CompiledRule rule, MappingRule input) {
		return new CampoForm();
	}

	@Override
	public CampoForm execute(CompiledRule rule, MappingRule input, Map<String, Object> facts) {
		input.getMapFacts().forEach((k, v) -> {
			if (!StringUtils.isBlank(k) && v != null)
				facts.putIfAbsent(k, v);
		});

		if (StringUtils.isBlank(input.getRule().getAction())) {
			String valDef = StringUtils.trimToEmpty(input.getSwfCampo().getMtfDefault());
			if (!valDef.isEmpty()) {
				CampoForm output = new CampoForm();
				output.setTabla(rule.getRule().getNamespace());
				output.setColumn(rule.getRule().getName());
				output.setCatalogo(rule.getRule().getPath());
				output.setValor(valDef);

				return output;
			}
		}
		return null;
	}
	@Override
	public void postExecuteAction(CompiledRule rule, MappingRule input, CampoForm output, Map<String, Object> facts) {
		SwfMencampos swfCampo = input.getSwfCampo();
		if (output != null && output.getValorObj() != null && (output.getValorObj() instanceof CampoForm)) {
			CampoForm cfOut = (CampoForm) output.getValorObj();
			cfOut.setCatalogo(rule.getRule().getPath());
			if (addOptional(swfCampo, cfOut)) {
				evalFormat(swfCampo, cfOut);
				log.info(rule.getRule().getPath() + " POR AQUI");
				input.addCampo(cfOut);				
			}
		} else {
			output.setTabla(rule.getRule().getNamespace());
			output.setColumn(rule.getRule().getName());
			output.setCatalogo(rule.getRule().getPath());
			if (addOptional(swfCampo, output)) {
				evalFormat(swfCampo, output);
				log.info(rule.getRule().getPath() + " POR AQUI(X)");
				input.updCFResult(output);				
			}
		}
	}
	
	@Override
	protected Object executeAction(CompiledRule rule, Map<String, Object> domainVars) {

		Rule r = rule.getRule();
		if (StringUtils.isBlank(r.getAction())) {
			return null;
		}
		CompiledTemplate compiled = null;
		try {
			compiled = compileTemplate(r.getAction());
		} catch (Exception e) {
			log.warn("No se puede parsear la expresion " + r.getAction() + " " + e.getMessage());
			return null;
		}
		if (compiled == null)
			return null;
		
		try {
			Object o = TemplateRuntime.execute(compiled, domainVars);
			if (o != null) {
				if (String.valueOf(o).equals("true")) {
					return null;
				} else {
					return o;
				}
			}
		} catch (Throwable e) {
			log.warn("No se puede parsear la expresion " + r.getAction() + " " + e.getMessage());
		}
		return null;		
	}
	

	private static void evalFormat(SwfMencampos sc, CampoForm cf) {
		if (sc == null)
			return;
		if (!StringUtils.isBlank(cf.getValor()) && !StringUtils.isBlank(sc.getMtfFormato())) {
			int ln = UtilsGeneric.extractNumber(sc.getMtfFormato(), "max", "text");
			if (ln > 0 && cf.getValor().length() > ln) {
				String nc = cf.getValor().substring(0, ln);
				cf.setValor(nc);
			}
		}
	}
	
	private static boolean addOptional(SwfMencampos sc, CampoForm cf) {
		if (sc == null)
			return true;
		if (StringUtils.isBlank(cf.getValor()) && !StringUtils.isBlank(sc.getMtfStatus())) {
			boolean isStr = !StringUtils.isBlank(cf.getTipoValor()) && cf.getTipoValor().equalsIgnoreCase("string"); 
			if (sc.getMtfStatus().trim().equalsIgnoreCase("o") && isStr) {
				return false;
			}
		}		
		return true;
	}	
}
