package gob.bcb.iso20022.swift.parser;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.prowidesoftware.swift.model.AbstractMessage;
import com.prowidesoftware.swift.model.MessageMetadataStrategy;
import com.prowidesoftware.swift.model.Money;
import com.prowidesoftware.swift.model.MxId;
import com.prowidesoftware.swift.model.MxSwiftMessage;
import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.prowidesoftware.swift.model.mx.AppHdr;
import com.prowidesoftware.swift.model.mx.MxParseUtils;

import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.exceptions.DataValidationSwitfException;
import gob.bcb.iso20022.lau.AuthParameters;
import gob.bcb.iso20022.lau.LAU;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.pojo.Block4;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.saa.DataPDUWriter;
import gob.bcb.iso20022.translate.ValidationEngine;
import gob.bcb.iso20022.utils.UtilsGeneric;

public class SwiftMessageMX extends SwiftMessageAbstract {
	private final static Logger log = LoggerFactory.getLogger(SwiftMessageMX.class);
	public static final transient String PATH_SEPARATOR = "/";
	public static final String IDTAG_LAU_MX = "./BizSvc";
	// public MxSwiftMessage swiftMessage;

	public SwiftMessageMX() {

	}

	public SwiftMessageMX(String swiftPlano) {
		super(swiftPlano);
	}

	public SwiftMessageAbstract createMsg() {
		final String mPlano = getMenPlanoOrig();
		if (StringUtils.isBlank(getMenPlanoOrig())) {
			throw new DataValidationSwitfException("Mensaje origen nulo, requerido para generar MX");
		}

		AbstractMX aMsg = null;
		Optional<MxId> idO = MxParseUtils.identifyMessage(mPlano);
		if (!idO.isPresent()) {
			if (!StringUtils.isBlank(getTypeMessage())) {
				MxId id = new MxId(getTypeMessage());
				aMsg = AbstractMX.parse(mPlano, id);
			} else {
				aMsg = AbstractMX.parse(mPlano);
			}
		} else {
			aMsg = AbstractMX.parse(mPlano);
		}

		if (aMsg == null) {
			throw new DataValidationSwitfException("No se pudo crear mensaje Swift MX, objeto MX nulo.");
		}

		if (StringUtils.isBlank(getTypeMessage())) {
			setTypeMessage(aMsg.getMxId().id());
		}

		setAbsMsg(aMsg);
		setPayLoad(aMsg.message());
		getSwfMsgParam().setMenFormato(FileFormat.MX.toString());

		DataPDUWriter w = new DataPDUWriter(aMsg).createDataPDUFromXml(mPlano).initBody();
		setdPDUWriter(w);
		String xml = w.xmlSaa();
		setMenPlano(xml);		
		getSwfMsgParam().setMenHash(w.getSignatureValue());
		log.info("Mensaje con LAU " + getSwfMsgParam().getMenHash());
		
		if (StringUtils.isBlank(getMenPlano())) {
			throw new DataValidationSwitfException("No se pudo crear mensaje Swift MX ");
		}
		return this;
	}

	public SwiftMessageAbstract createBlock4() {
		createBlock4Long(false);
		return this;
	}
	
	public final static int MAX_CHARS_RTE = 25;
	public final static int MIN_TAGS_VISIBLE = 3;
	
	public SwiftMessageAbstract createBlock4Long(boolean addAdics) {
		List<Block4> block4Lista = new ArrayList<>();
		AbstractMX mxOrig = (AbstractMX) getAbsMsg();
		if (mxOrig == null)
			return this;

		Map<String, String> outMap = XmlToMap.xmlToProps(getPayLoad());
//		outMap.forEach((k,v) -> {
//			log.info(k + " : " + v);
//		});
		outMap.forEach((k, v) -> {
			Block4 block = new Block4();
			block.setName(k);
			block.setNameShort(k);
			block.setValue(v);			

			if (addAdics) {
				String codMtTrx = !StringUtils.isBlank(getSwfMsgParam().getMenIdTMessageTx()) ? getSwfMsgParam().getMenIdTMessageTx() : mxOrig.getMxId().id();				
				String[] paths = StringUtils.split(k, PATH_SEPARATOR);
				List<String> texts = Arrays.asList(Arrays.copyOfRange(paths,0, paths.length -1));
				String path = render(texts, MAX_CHARS_RTE, MIN_TAGS_VISIBLE);
				block.setNameShort(path + "<" +paths[paths.length - 1] +">");

				if (paths.length - 1 >= 0) {
					block.setReference(paths[paths.length - 1]);
				}

				if (getSwfMencamposDao() != null) {
					List<SwfMencampos> scl = getSwfMencamposDao().findByMtCampo(codMtTrx, k);
					if (scl.size() > 0) {
						SwfMencampos sc = scl.get(0);
						if (!StringUtils.isBlank(sc.getMtfSinonimos()))
							block.setReference(sc.getMtfSinonimos());
						block.setValueDescrip(UtilsGeneric.truncateSuffix(sc.getMtfDescrip(), MAX_CHARS_RTE));
					}
//					log.info("dao MT: "+ scl.size()+ " "  + codMtTrx + " -> " + k + " : " + block.getReference());					
				} 
			}
			block4Lista.add(block);
		});

		getBlock4().clear();
		getBlock4().addAll(block4Lista);

		return this;
	}

	public SwiftMessageAbstract extractMetadataHdr() {
		AbstractMX mxOrig = (AbstractMX) getAbsMsg();

		MxSwiftMessage swiftMessage = new MxSwiftMessage(mxOrig);
		getSwfMsgParam().setMenEmisor(swiftMessage.getSender());
		getSwfMsgParam().setMenReceiver(swiftMessage.getReceiver());
		getSwfMsgParam().setMenTypemessage(swiftMessage.getMessageType());
		getSwfMsgParam().setMenIdTMessageTx(swiftMessage.getMessageType());
		getSwfMsgParam().setMenCodswift(swiftMessage.getReference());

		extractMetadataBody();

		return this;
	}

	public SwiftMessageAbstract extractMetadataBody() {
		Map<String, String> outMap = XmlToMap.xmlToProps(getPayLoad());
		outMap.forEach((k, v) -> {
			if (k.matches("(?s).*/IntrBkSttlmAmt.*/@Ccy")) {
				getSwfMsgParam().setMenCodmon(v);
				return;
			}
		});
		return this;
	}

	public SwiftMessageAbstract updMsgForSign() {
		if (StringUtils.isBlank(getMenPlanoOrig())) {
			throw new RuntimeException("Pre tarea de firma mensaje MX nulo");
		}

		AbstractMX mxOrig = (AbstractMX) getAbsMsg();
		setPayLoad(mxOrig.message());
		
		getdPDUWriter().createDataPDUFromXml(getMenPlanoOrig()).initBody().initLAU();
		String xmlSaa = getdPDUWriter().xmlSaa();
		setMenPlano(xmlSaa);
		
		return this;
	}

	public void addBlockLAU(AuthParameters authParameters) {
		String xmlToSign = getdPDUWriter().xmlSaa();
		LAU signer = new LAU();
		String xmlSigned = signer.signXmlV2(xmlToSign, authParameters);
		setMenPlano(xmlSigned);
		
		String sigValue =  DatatypeConverter.printBase64Binary(signer.sign(getPayLoad().getBytes()));
		getSwfMsgParam().setMenHash(sigValue);
		log.info("MX actualizado con firma ... hecho!! con mac: " + sigValue);
	}

	public String getTagCodeLau() {
		return null;
	}

	public String checkSum() {
		String hash = DigestUtils.md5Hex(getMenPlano());
		return hash;
	}

	public SwiftMessageAbstract updInstrId2(String key, String value) {
		throw new RuntimeException("no implementado");
	}

	public static final int MINIMAL_TAGS = 5;

	public boolean isValidMsg(boolean genError) {
		if (StringUtils.isBlank(getMenPlano())) {
			if (genError)
				throw new DataValidationSwitfException("Mensaje plano nulo");
			return false;
		}

		if (getAbsMsg() == null) {
			AbstractMX mxNew = AbstractMX.parse(getMenPlano());
			setAbsMsg(mxNew);
		}

		AbstractMX mxOrig = (AbstractMX) getAbsMsg();
		if (mxOrig == null) {
			if (genError)
				throw new DataValidationSwitfException("Objeto MX nulo, XML invalido.");
			return false;
		}

		Map<String, String> outMap = XmlToMap.xmlToProps(mxOrig.document());
		if (outMap.size() <= MINIMAL_TAGS) {
			if (genError)
				throw new DataValidationSwitfException("Numero de elementos BODY menor al permitido. " + MINIMAL_TAGS);
			return false;
		}

		AppHdr appHdr = mxOrig.getAppHdr();
		if (appHdr == null) {
			if (genError)
				throw new DataValidationSwitfException("HEADER del mensaje nulo");
			return false;
		}

		String xmlHdr = appHdr.xml();

		outMap = XmlToMap.xmlToProps(xmlHdr);

		if (outMap.size() < MINIMAL_TAGS) {
			if (genError)
				throw new DataValidationSwitfException("Numero de elementos HEADER menor al permitido. " + MINIMAL_TAGS);
			return false;
		}

		return true;
	}

	public List<String> validateSyntax() throws Exception {
		ValidationEngine engine = ValidationEngine.getInstance(); // .registerValidators();
		AbstractMX mx = (AbstractMX) getAbsMsg();
		if (mx == null) {
			return new ArrayList<>();
		}
		String msgXml = mx.document();
		if (StringUtils.isBlank(msgXml)) {
			return new ArrayList<>();
		}
		List<String> errors = engine.validateMsg(msgXml, getTypeMessage());
		return errors;
	}

	@Override
	public SwiftMessageAbstract createBlock4Long() {
		return createBlock4Long(true);
	}
	
    public static String render(List<String> texts, int max, int tagsVisible) {
        final List<String> joins = new ArrayList<>();
        final List<String> reversed = new ArrayList<>(texts);
        int replace = 0;
        int items = 0;
        Collections.reverse(reversed);
        int l = getVisibleLength(texts);
        if (l > max) {
            items = tagsVisible;
        }
        replace = max - l;
        for (final String t : reversed) {
            if (items > 0) {
                final String render = t;

                if (StringUtils.isNotEmpty(render)) {
                    joins.add(render);
                }
                items = items - 1; //t.trim().length();
            } else {
            	final String render = t.substring(0, (replace <= 0 ? 1 : t.length()));
                joins.add(render);
            }
            replace = max - getVisibleLength(joins);            
        }
        Collections.reverse(joins);
        return String.join(PATH_SEPARATOR, joins);
    }
    
    public static int getVisibleLength(List<String> texts) {
        return texts.stream().mapToInt(String::length).sum();
    }
    
	public static class MxMetadataCustStrategy implements MessageMetadataStrategy {
		@Override
		public Optional<String> reference(AbstractMessage message) {
			return Optional.of("REFERENCE");
		}

		@Override
		public Optional<Money> amount(AbstractMessage message) {
			return Optional.of(new Money("USD", new BigDecimal("1234.56")));
		}

		@Override
		public Optional<Calendar> valueDate(AbstractMessage message) {
			return Optional.empty();
		}

		@Override
		public Optional<Calendar> tradeDate(AbstractMessage message) {
			return Optional.empty();
		}
	}

    
}
