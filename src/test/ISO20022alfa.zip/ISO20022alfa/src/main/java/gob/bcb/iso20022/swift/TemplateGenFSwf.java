package gob.bcb.iso20022.swift;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.mvel2.ParserContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prowidesoftware.swift.model.BIC;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.mt.AbstractMT;

import gob.bcb.iso20022.commons.Constants;
import gob.bcb.iso20022.exceptions.CompileException;
import gob.bcb.iso20022.exceptions.DuplicateNameException;
import gob.bcb.iso20022.exceptions.ParseException;
import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.pojo.CodNemoCompo;
import gob.bcb.iso20022.rules.Engine;
import gob.bcb.iso20022.rules.IAction;
import gob.bcb.iso20022.rules.Rule;
import gob.bcb.iso20022.utils.MxDataTypesConversor;
import gob.bcb.iso20022.utils.ParserSwiftMessage;
import gob.bcb.iso20022.utils.UtilsGeneric;
import gob.bcb.iso20022.utils.ValidatorCodes;

/**
 * template con las funciones para generar un campo swft segun reglas
 * 
 * @author WHerrera
 *
 */
public class TemplateGenFSwf {
	private static final Logger log = LoggerFactory.getLogger(TemplateGenFSwf.class);
	public static final String SWF_BLOQUE_4 = "4";
	public static final String SWF_BLOQUE_3 = "3";
	public static final String SWF_STATUS_MANDATORY = "M";

	public static Map<String, String> patternsField = new HashMap<>();
	public static Map<String, String> patternsFieldCompo = new HashMap<>();
	// public static Map<String, String> patternsSeqBloqFld = new HashMap<>();
	public static Map<String, String> patternsSeqBloq = new HashMap<>();
	public static Map<String, Function<String, Optional<String>>> extractNemoCompoF = new LinkedHashMap<String, Function<String, Optional<String>>>();

	public static final String SWF_PATT_NEMO_SSF = "SSF";
	public static final String SWF_PATT_NEMO_SF = "SF";
	public static final String SWF_PATT_SEP = ".";
	public static final String SWF_PATT_SEPUNIQ = "[" + SWF_PATT_SEP + "]";
	public static final String SWF_PATT_SEQ = "S[A-Z]";
	public static final String SWF_PATT_SUBSEQ = SWF_PATT_SEQ + "[0-9]";
	public static final String SWF_PATT_GRUPOPT = SWF_PATT_SEPUNIQ + "[0-9]" + SWF_PATT_SEPUNIQ;
	public static final String SWF_PATT_FIELDONLY = "[1-9][0-9][A-Z]{0,1}";
	public static final String SWF_PATT_FIELDORDER = "(\\.[1-9]){0,1}";
	public static final String SWF_PATT_FIELD = SWF_PATT_FIELDONLY + SWF_PATT_FIELDORDER;
	public static final String SWF_PATT_NAMECOMPO = "[A-Za-z]{3,3}[A-Z0-9a-z]{0,}";

	static {
		patternsField.put("SSGF", SWF_PATT_SUBSEQ + SWF_PATT_GRUPOPT + SWF_PATT_FIELD);
		patternsField.put("SSF", SWF_PATT_SUBSEQ + SWF_PATT_SEPUNIQ + SWF_PATT_FIELD);
		patternsField.put("SGF", SWF_PATT_SEQ + SWF_PATT_GRUPOPT + SWF_PATT_FIELD);
		patternsField.put("SF", SWF_PATT_SEQ + SWF_PATT_SEPUNIQ + SWF_PATT_FIELD);
		patternsField.put("F", SWF_PATT_FIELD);

		patternsFieldCompo.put("SSGFC", SWF_PATT_SUBSEQ + SWF_PATT_GRUPOPT + SWF_PATT_FIELD + Constants.CAMPOFORM_TABLANAME_SEPARATOR + SWF_PATT_NAMECOMPO);
		patternsFieldCompo.put("SSFC", SWF_PATT_SUBSEQ + SWF_PATT_SEPUNIQ + SWF_PATT_FIELD + Constants.CAMPOFORM_TABLANAME_SEPARATOR + SWF_PATT_NAMECOMPO);
		patternsFieldCompo.put("SGFC", SWF_PATT_SEQ + SWF_PATT_GRUPOPT + SWF_PATT_FIELD + Constants.CAMPOFORM_TABLANAME_SEPARATOR + SWF_PATT_NAMECOMPO);
		patternsFieldCompo.put("SFC", SWF_PATT_SEQ + SWF_PATT_SEPUNIQ + SWF_PATT_FIELD + Constants.CAMPOFORM_TABLANAME_SEPARATOR + SWF_PATT_NAMECOMPO);
		patternsFieldCompo.put("FC", SWF_PATT_FIELD + Constants.CAMPOFORM_TABLANAME_SEPARATOR + SWF_PATT_NAMECOMPO);

		patternsSeqBloq.put("SSG", SWF_PATT_SUBSEQ + SWF_PATT_GRUPOPT);
		patternsSeqBloq.put("SS", SWF_PATT_SUBSEQ + SWF_PATT_SEPUNIQ);
		patternsSeqBloq.put("SG", SWF_PATT_SEQ + SWF_PATT_GRUPOPT);
		patternsSeqBloq.put("S", SWF_PATT_SEQ + SWF_PATT_SEPUNIQ);

		extractNemoCompoF.put("S1", UtilsGeneric.extractStrForPatt(SWF_PATT_SUBSEQ));
		extractNemoCompoF.put("S2", UtilsGeneric.extractStrForPatt(SWF_PATT_SEQ));
		extractNemoCompoF.put("F", UtilsGeneric.extractStrForPatt(SWF_PATT_FIELD));
		extractNemoCompoF.put("C", UtilsGeneric.extractStrForPatt(SWF_PATT_NAMECOMPO));
		extractNemoCompoF.put("G", UtilsGeneric.extractStrForPatt(SWF_PATT_GRUPOPT));

		// extractStrForPatt(String regex)
	}

	public static Function<String, Optional<String>> findPatternForValueF0 = UtilsGeneric.findPatternForValue(patternsFieldCompo);
	public static BiFunction<String, String, CodNemoCompo> builtFromNemoCodCmpF = builtFromNemoCodCmp(SWF_PATT_SEP, Constants.CAMPOFORM_TABLANAME_SEPARATOR);

	public static Function<String, AbstractMT> createMTFromFIN() {
		return msgFin -> {
			if (ValidatorCodes.isBlank.test(msgFin)) {
				throw new RuntimeException("Desparseo Swift: mensaje en formato RJE inválido.");
			}
			AbstractMT mt = null;
			try {
				mt = AbstractMT.parse(msgFin);
			} catch (IOException e) {
				throw new RuntimeException("Error en desparseo Swift: " + e.getMessage());
			}

			return mt;
		};
	}

	public static Function<SwfMencampos, Optional<Function<SwfMencampos, Optional<Field>>>> getFuncCreateField(
			final Map<String, Function<SwfMencampos, Optional<Field>>> mapFieldFunc) {
		return swfMencampos -> {
			CodNemoCompo codNemoCompo = builtFromNemoCodCmpF.apply(swfMencampos.getMtfCodcampo(), null);
			Function<SwfMencampos, Optional<Field>> funcField = mapFieldFunc.get(codNemoCompo.getCodCampoNL());

			if (funcField != null) {
				return Optional.ofNullable(funcField);
			}

			return Optional.ofNullable(mapFieldFunc.get(swfMencampos.getMtfCodcampo()));
		};

	}

	public static List<CampoForm> evalFldDefault(SwfMencampos swfMencampos) {
		// desparsea el campo default y almacena en una lista
		Map<String, String> mapaReglas = UtilsGeneric.paramsListaNoVal(swfMencampos.getMtfDefault());

		List<CampoForm> campoFormList = mapaReglas.entrySet().stream().map(entry -> {
			// por cada par creamos un registro
			String nameCompo = entry.getKey();
			String valCompo = entry.getValue();

			CampoForm campoForm = new CampoForm(swfMencampos.getMtfNemo(), nameCompo, valCompo);

			return campoForm;
		}).collect(Collectors.toList());

		return campoFormList;
	}

	public static Function<SwfMencampos, Boolean> evalFldCondicion(Instruccion instruccion) {
		return swfMencampos -> {

			Rule r = new Rule(swfMencampos.getMtfNemo(), swfMencampos.getMtfCodcampo(), swfMencampos.getMtfCondicion(), swfMencampos.getMtfReglavalid(), 1,
					swfMencampos.getMtfSecpadre(), swfMencampos.getMtfDescrip(), swfMencampos.getMtfExpresion(), swfMencampos.getMtfXmltag());

			MappingRule mapRule = new MappingRule();
			mapRule.setRule(r);
			mapRule.setSwfCampo(swfMencampos);

			Supplier<IAction> iaction = MappingTable.mapActions().get("MTTOMX");
			if (iaction == null) {
				throw new RuntimeException("Transformador inexistente " + r.getOutcome());
			}
			mapRule.setActTransform(iaction.get());

			try {
//				Engine engine = new Engine(Arrays.asList(r), true).addMethod(MxDataTypesConversor.class);
//				engine.addCompiledRuleToMap(true, r);
//				engine.executeAction(mapRule.getRule().getFullyQualifiedName(), mapRule, mapRule.getActTransform(), instruccion.getMapFacts());
				return true;
			} catch (Exception e) {
				log.error("Error en engine: " + e.getMessage());
				// throw new RuntimeException("Error en engine: " + e.getMessage());
				return false;
			}
			// return false;
		};
	}

	public static Function<SwfMencampos, List<CampoForm>> evalFldExpresion(Instruccion instruccion) {
		return swfMencampos -> {
			
			Rule r = new Rule(swfMencampos.getMtfNemo(), swfMencampos.getMtfCodcampo(), swfMencampos.getMtfCondicion(), swfMencampos.getMtfReglavalid(), 1,
					swfMencampos.getMtfSecpadre(), swfMencampos.getMtfDescrip(), swfMencampos.getMtfExpresion(), swfMencampos.getMtfXmltag());

			MappingRule mapRule = new MappingRule();
			mapRule.setRule(r);
			mapRule.setSwfCampo(swfMencampos);

			Supplier<IAction> iaction = MappingTable.mapActions().get("MTTOMX");
			if (iaction == null) {
				throw new RuntimeException("Transformador inexistente " + r.getOutcome());
			}
			mapRule.setActTransform(iaction.get());

			try {
//				Engine engine = new Engine(Arrays.asList(r), true).addMethod(MxDataTypesConversor.class);
//				engine.addCompiledRuleToMap(true, r);
//				engine.executeAction(mapRule.getRule().getFullyQualifiedName(), mapRule, mapRule.getActTransform(), instruccion.getMapFacts());
			} catch (Exception e) {
				log.error("Error en engine: " + e.getMessage());
				// throw new RuntimeException("Error en engine: " + e.getMessage());
			}			
			
			if (swfMencampos.getMtfExpresion() == null || swfMencampos.getMtfExpresion().trim().length() == 0) {
				return new ArrayList<>();
			}

			log.info("Eval expresion " + swfMencampos.toStringID() + " " + swfMencampos.getMtfExpresion() );

			return new ArrayList<>();
		};
	}

	public static Function<SwfMencampos, List<CampoForm>> evalReglasswf(Instruccion instruccion) {
		return swfMencampos -> {
			if (swfMencampos.getMtfReglaswf() == null || swfMencampos.getMtfReglaswf().trim().length() == 0) {
				return new ArrayList<>();
			}

			BiFunction<String, String, Optional<CampoForm>> findEntPropOperInstrF = findEntPropiedad(null);
			Map<String, String> mapaExp = UtilsGeneric.paramsListaNoVal(swfMencampos.getMtfReglaswf());

			List<CampoForm> cfList = mapaExp.entrySet().stream().map(entry -> {
				String codCampo = entry.getKey();
				String valorCampo = entry.getValue();
				Optional<CampoForm> cfOpt = runExpression(null, findEntPropOperInstrF).apply(valorCampo);

				if (cfOpt.isPresent()) {
					cfOpt.get().setColumn(codCampo);
					cfOpt.get().setTabla(swfMencampos.getMtfNemo());

				}
				return cfOpt;
			}).filter(cf -> cf.isPresent()).map(cf -> cf.get()).collect(Collectors.toList());
			return cfList;
		};
	}

	public static Predicate<SwfMencampos> mandatorySwfCampos() {
		return swfMencampos -> swfMencampos.getMtfStatus() != null && swfMencampos.getMtfStatus().trim().equalsIgnoreCase(SWF_STATUS_MANDATORY);
	}

	public static BiFunction<String, String, Optional<CampoForm>> findEntPropOperInstr(Instruccion instruccion) {
		return (entidad, propiedad) -> {
			return findEntPropiedad(null).apply(entidad, propiedad);
		};
	}

	public static Function<SwfMencampos, Function<String, Optional<CampoForm>>> evalAndFindVarForMenCampo(Instruccion instruccion,
			Function<SwfMencampos, List<CampoForm>> evalMenCampos) {
		// la funcion es exclusiva para busqueda de un campo swf por lo tanto la
		// variable a buscar debe ser un
		// compuesto de la tabla y el componenten(campo) del objeto Field

		BiFunction<String, String, Optional<CampoForm>> findEntPropiedadF = findEntPropiedad(null);

		return swfMencampos -> {
			List<CampoForm> campoFormList = evalMenCampos.apply(swfMencampos);

			campoFormList.stream().forEach(campoF -> {
				// uniformizamos el nomre de la tabla
				campoF.setTabla(swfMencampos.getMtfNemo());
			});

			return codVariableCompo -> {
				// primero buscamos en los registrados ya que por precedencia los valores de
				// instruccion van antes
				String tipoCF = "";
				Optional<CampoForm> cammpoFormFind = findEntPropiedadF.apply(swfMencampos.getMtfNemo(), codVariableCompo);
				if (!cammpoFormFind.isPresent()) {
					// si no se hallo se busca en solo en los calculados
					cammpoFormFind = findEntPropiedad(campoFormList).apply(swfMencampos.getMtfNemo(), codVariableCompo);
					if (!cammpoFormFind.isPresent()) {
						// por ultimo solo buscamos el valor ya que puede ser un campo compuesto
						// si se desea busvar en opercaionesval el campo debe ser ej: ISIN_VAOVALOR ,
						// MONTO_VAOVALORDECIMAL,
						// OPERACION_FECHAVALOR
						String[] tabColumna = codVariableCompo.split(Constants.CAMPOFORM_TABLANAME_SEPARATOR);
						if (tabColumna.length > 1) {
							cammpoFormFind = findEntPropiedadF.apply(null, codVariableCompo);
							tipoCF = cammpoFormFind.isPresent() ? "V" : "";
						}

					} else {
						tipoCF = "C";
					}

				} else {
					tipoCF = "I";
				}

				if (cammpoFormFind.isPresent()) {
					String valNew = UtilsGeneric.removeCharsInvalids(cammpoFormFind.get().getValor());

					cammpoFormFind.get().setValor(valNew == null ? valNew : valNew.toUpperCase());

				}
				Boolean validCF = cammpoFormFind.isPresent() && !CampoFormUtils.campoFormBlank.test(cammpoFormFind.get());

				return validCF ? cammpoFormFind : Optional.empty();
			};
		};

	}

	public static BiFunction<String, String, Optional<CampoForm>> findEntPropiedad(List<CampoForm> campoFormList) {
		return (entidad, propiedad) -> {
			// en instruccion.getPropsLista esta los valores de la BDD y los iniciales
			String codEnt = entidad == null ? "" : entidad.trim();
			String codProp = propiedad == null ? "" : propiedad.trim();

			String codVariable = codEnt + (!codEnt.isEmpty() && !codProp.isEmpty() ? Constants.CAMPOFORM_TABLANAME_SEPARATOR : "") + codProp;

			// primero buscamos si existe toda la variable en opersval
			// buscamos por el compuesto en la lista de variables registradas
			Optional<CampoForm> cmpFOpt = CampoFormUtils.findValorDeTabla(campoFormList).apply(codVariable);

			if (cmpFOpt.isPresent()) {
				return Optional.of(CampoFormUtils.cloneCampoForm().apply(cmpFOpt.get()));
			}
			return Optional.empty();
		};
	}

	public static Function<String, Optional<CampoForm>> runExpression(Map<String, Function<String, Supplier<Optional<CampoForm>>>> funciones,
			BiFunction<String, String, Optional<CampoForm>> findEntPropiedad) {
		return expresion -> {
			List<String> splitLista = UtilsGeneric.extractParams(expresion, "", "\\(");
			if (splitLista.size() > 0 && funciones != null) {
				String nomFunc = splitLista.get(0);
				Function<String, Supplier<Optional<CampoForm>>> func = funciones.get(nomFunc);
				if (func != null) {
					Optional<CampoForm> cfOpt = func.apply(expresion).get();
					if (cfOpt.isPresent()) {
						cfOpt.get().setTabla(nomFunc);
						log.info("Encontrado funcion[" + nomFunc + "] : " + cfOpt.get().getTabla() + " - " + cfOpt.get().getColumn() + " "
								+ cfOpt.get().getValor());
					}
					return cfOpt;
				} else {
					CampoForm cfo = null;
					return Optional.ofNullable(cfo);
				}
			} else {
				// no es una funcion es una asignacion de un campo
				// se busca el valor
				if (UtilsGeneric.entreComillas(expresion)) {
					String valorCampoN = expresion.trim().replace("'", "");
					CampoForm campoForm = new CampoForm("VALOREXPR", "VALOREXPR", valorCampoN);
					return Optional.of(campoForm);
				} else {
					return findEntPropiedad.apply(expresion, null);
				}
			}

		};
	}

	public static BiFunction<SwfMencampos, String, CodNemoCompo> builtTablaCompo() {
		return (swfMencampos, codComponente) -> {

			CodNemoCompo codNemoCompo = builtCodNemoCompo(SWF_PATT_SEP, Constants.CAMPOFORM_TABLANAME_SEPARATOR).apply(codComponente);
			// por defecto
			if (!codNemoCompo.getNemoIsField()) {
				// no cumple el patron para campo nemo
				// construimos el nuevo
				CodNemoCompo codNemoCompoN = builtCodNemoCompo(SWF_PATT_SEP, Constants.CAMPOFORM_TABLANAME_SEPARATOR).apply(swfMencampos.getMtfNemo());

				codNemoCompoN.setTabla(codNemoCompo.getTabla());
				codNemoCompoN.setComponente(codNemoCompo.getComponente());
				return codNemoCompoN;
			} else {

				return codNemoCompo;
			}

		};
	}

	public static BiFunction<String, String, CodNemoCompo> builtFromNemoCodCmp(String separatorField, String separatorTablaProp) {
		return (nemo, codComponente) -> {
			CodNemoCompo codNemoCompo = builtCodNemoCompo(separatorField, separatorTablaProp).apply(nemo);

			if (codComponente != null)
				extractNemoCompoF.get("C").apply(codComponente).ifPresent(valPat -> {
					codNemoCompo.setComponenteField(valPat);
				});

			return codNemoCompo;
		};
	}

	public static Function<String, CodNemoCompo> builtCodNemoCompo(String separatorField, String separatorTablaProp) {
		return codComponente -> {

			String[] tabColumna = codComponente.split(separatorTablaProp);
			String partField = tabColumna.length > 0 ? tabColumna[0] : codComponente;
			String partCompo = tabColumna.length > 1 ? tabColumna[1] : "";

			CodNemoCompo codNemoCompo = new CodNemoCompo(separatorField, separatorTablaProp);
			codNemoCompo.setValor(codComponente);

			if (tabColumna.length > 1) {
				codNemoCompo.setTabla(partField);
				codNemoCompo.setComponente(partCompo);
			} else {
				// sino existe el caracter de separacion tabla propiedad
				codNemoCompo.setComponente(codComponente);
			}

			Optional<String> patOpt = UtilsGeneric.findPatternForValue(patternsField).apply(partField);

			if (patOpt.isPresent()) {
				codNemoCompo.setNemoIsField(true);
				// si cumple el patron extraemos sus componentes
				extractNemoCompoF.get("S2").apply(partField).ifPresent(valPat -> {
					codNemoCompo.setSequence(valPat);
				});

				extractNemoCompoF.get("S1").apply(partField).ifPresent(valPat -> {
					codNemoCompo.setSequence(valPat);
				});

				extractNemoCompoF.get("F").apply(partField).ifPresent(valPat -> {
					codNemoCompo.setCodCampo(valPat);
				});

				extractNemoCompoF.get("G").apply(partField).ifPresent(valPat -> {
					codNemoCompo.setGrpOpt(valPat);
				});
			}

			extractNemoCompoF.get("C").apply(codComponente).ifPresent(valPat -> {
				codNemoCompo.setComponenteField(valPat);
				// se setea a nulo para tener un solo valor
				// codNemoCompo.setComponente("");
			});

			extractNemoCompoF.get("C").apply(partCompo).ifPresent(valPat -> {
				codNemoCompo.setComponente(valPat);
			});

			// extraemos la opcion si tiene
			String cmpNumLit = UtilsGeneric.extractStrForPatt(SWF_PATT_FIELDONLY).apply(codNemoCompo.getCodCampo()).orElse("");
			codNemoCompo.setCodCampoNL(cmpNumLit);

			String cmpNum = UtilsGeneric.extractStrForPatt("[1-9][0-9]").apply(codNemoCompo.getCodCampo()).orElse("");
			codNemoCompo.setCodCampoNum(cmpNum);

			String cmpOpt = UtilsGeneric.extractStrForPatt("[A-Z]").apply(codNemoCompo.getCodCampo()).orElse("");
			codNemoCompo.setCodCampoLit(cmpOpt);

			String cmpOrder = UtilsGeneric.extractStrForPatt("[" + separatorField + "][1-9]").apply(codNemoCompo.getCodCampo()).orElse("");
			codNemoCompo.setCodCampoOrder(cmpOrder);

			String seqLit = UtilsGeneric.extractStrForPatt(SWF_PATT_SEQ).apply(codNemoCompo.getSequence()).orElse("");
			codNemoCompo.setSequenceLit(seqLit);

			String seqNum = UtilsGeneric.extractStrForPatt("[0-9]").apply(codNemoCompo.getSequence()).orElse("");
			codNemoCompo.setSequenceNum(seqNum);
			return codNemoCompo;
		};
	}

	public static BiFunction<SwfMencampos, Field, List<CampoForm>> convertToCampoForm() {
		return (swfMencampos, field) -> {
			List<CampoForm> camposFormListG = CampoFormUtils
					.generateCampoFormList(ValidatorCodes.dateToStringDDMMYY, ValidatorCodes.bigDecimalToStringF(ValidatorCodes.PATTERN_DECIMAL))
					.apply(field);

			CodNemoCompo codNemoCompo = builtFromNemoCodCmp(SWF_PATT_SEP, Constants.CAMPOFORM_TABLANAME_SEPARATOR).apply(swfMencampos.getMtfNemo(), "VALUE");
			codNemoCompo.setCodCampoLit(field.letterOption() != null ? String.valueOf(field.letterOption()) : "");
			String nemoNew = codNemoCompo.format("SlSnGFnFlFo");
			camposFormListG.forEach(cf -> {
				// seteamos tabla y columna para busquedas

				cf.setTabla(swfMencampos.getMtfNemo().toUpperCase());
				if (codNemoCompo.getNemoIsField()) {
					cf.setTabla(nemoNew.toUpperCase());
				}
				cf.setColumn(cf.getColumn().toUpperCase());
				cf.setCampoKey(swfMencampos.toStringID().replace("[", "").replace("]", ""));
				cf.setTablaRel(swfMencampos.getMtfCodmt());
				cf.setCampoValue(field.getName());
				cf.setTipoCampo(swfMencampos.getMtfNro());
				if (cf.getColumn().equalsIgnoreCase("VALUE")) {
					// se opta por el ingles ya que prowide no tiene todas las referencias en
					// español
					cf.setDescripcion(nemoNew + swfMencampos.getMtfDescrip());
				}
			});

			return camposFormListG;
		};
	}

	public static Function<Field, List<CampoForm>> fieldToCampoForm() {
		return (field) -> {
			List<CampoForm> camposFormListG = CampoFormUtils
					.generateCampoFormList(ValidatorCodes.dateToStringDDMMYY, ValidatorCodes.bigDecimalToStringF(ValidatorCodes.PATTERN_DECIMAL))
					.apply(field);
			field.typesPattern();
			field.validatorPattern();

			CodNemoCompo codNemoCompo = builtFromNemoCodCmp(SWF_PATT_SEP, Constants.CAMPOFORM_TABLANAME_SEPARATOR).apply(field.getName(), "VALUE");
			codNemoCompo.setCodCampoLit(field.letterOption() != null ? String.valueOf(field.letterOption()) : "");
			String nemoNew = codNemoCompo.format("SlSnGFnFlFo");
			camposFormListG.forEach(cf -> {
				cf.setTabla(nemoNew.toUpperCase());
				cf.setColumn(cf.getColumn().toUpperCase());
				// cf.setCampoKey(swfMencampos.toStringID().replace("[", "").replace("]", ""));
				// cf.setTablaRel(swfMencampos.getMtfCodmt());
				cf.setCampoValue(field.getName());
				// cf.setTipoCampo(swfMencampos.getMtfNro());
				if (cf.getColumn().equalsIgnoreCase("VALUE")) {
					// se opta por el ingles ya que prowide no tiene todas las referencias en
					// español
					cf.setDescripcion(nemoNew + " - " + field.getLabel(field.getName(), null, null));
				}
			});

			return camposFormListG;
		};
	}

	public static Function<Field, List<CampoForm>> fieldToCampoFormMV() {
		return (field) -> {
			CampoForm cf = new CampoForm();

			Map<String, Class> inputs = new HashMap<String, Class>();
//			inputs.put("input", Instruccion.class);
			inputs.put("output", CampoForm.class);

			ParserContext ctx = new ParserContext();
			ctx.setStrongTyping(true);
			ctx.setInputs(inputs);
//			ctx.addImport(Instruccion.class);
			ctx.addImport(CampoForm.class);

			return null;
		};
	}

	public static Predicate<SwfMencampos> campoSequence() {
		return swfMencampos -> swfMencampos.getMtfCodcampo().trim().equals("16R") || swfMencampos.getMtfCodcampo().trim().startsWith("15");
	}

}
