package gob.bcb.iso20022.swift;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.api.Facts;

import gob.bcb.iso20022.exceptions.CompileException;
import gob.bcb.iso20022.exceptions.DuplicateNameException;
import gob.bcb.iso20022.exceptions.NoActionFoundException;
import gob.bcb.iso20022.exceptions.NoMatchingRuleFoundException;
import gob.bcb.iso20022.exceptions.ParseException;
import gob.bcb.iso20022.model.CampoForm;
import gob.bcb.iso20022.model.IOperacionDatos;
import gob.bcb.iso20022.model.SwfMencampos;
import gob.bcb.iso20022.rules.CompiledRule;
import gob.bcb.iso20022.rules.Engine;
import gob.bcb.iso20022.rules.IAction;
import gob.bcb.iso20022.rules.Rule;
import gob.bcb.iso20022.utils.ValidatorCodes;

public class MappingRule implements IOperacionDatos{
	private IAction actTransform;
	private Rule rule;
	private CompiledRule compiled;
	private SwfMencampos swfCampo;
	private CampoForm campoForm;
	private final List<CampoForm> campos = new ArrayList<>();
	private int expected = 1;
	
	private Facts facts = new Facts();
	
	public MappingRule() {
		
	}

	public MappingRule(Integer posicion, String codigo, String expression, IAction actTransform ) {
		rule = new Rule();
	}
	
	public MappingRule(Rule rule, IAction actTransform ) {
		this.rule = rule;
		this.actTransform = actTransform;
	}

	public SwfMencampos getSwfCampo() {
		return swfCampo;
	}

	public void setSwfCampo(SwfMencampos swfCampo) {
		this.swfCampo = swfCampo;
	}

	public Rule getRule() {
		return rule;
	}

	public void setRule(Rule rule) {
		this.rule = rule;
	}

	public IAction getActTransform() {
		return actTransform;
	}

	public void setActTransform(IAction actTransform) {
		this.actTransform = actTransform;
	}

	public CampoForm getCampoForm() {
		return campoForm;
	}

	public void setCampoForm(CampoForm campoForm) {
		this.campoForm = campoForm;
	}

	public CompiledRule getCompiled() {
		return compiled;
	}

	public void setCompiled(CompiledRule compiled) {
		this.compiled = compiled;
	}

	public Object fact(String key) {
		return facts.get(key);
	}

	public MappingRule putFact(String key, Object fact) {
		if (!StringUtils.isBlank(key) && fact != null ) {
			facts.put(key, fact);			
		}
		return this;
	}
	
	public MappingRule putFacts(Map<String, Object> fact) {
		fact.forEach((k,v) -> {
			putFact(k, v);
		});
		
		return this;
	}
	
	public Map<String, Object> getMapFacts() {
		return facts.asMap();
	}
	
	public void removeFact(String key) {
		facts.remove(key);
	}
	
	public void clearFacts() {
		facts.asMap().forEach((k, v) -> {
			facts.remove(k);			
		});
	}
	
	public boolean containsFact(String key) {
		return facts.get(key) != null;
	}
	
	public boolean containsFact(String[] keys) {
		for(String k : keys) {
			boolean e = containsFact(k);
			if (e) {
				return e;
			}
		}
		return false;
	}

	public List<CampoForm> getCampos() {
		return campos;
	}
	
	public void addCampo(CampoForm cf) {
		if (!valido(cf))
			return;		
		campos.add(cf);
	}

	public void updCFResult(CampoForm cf) {
		if (!valido(cf))
			return;
		if (campos.size() <= 0) {
			campos.add(cf);
		} else {
			campos.set(0, cf);	
		}
				
	}
	
	public int getExpected() {
		return expected;
	}
	
	public boolean valido(CampoForm cf) {
		return true;
	}
	
	public MappingRule addRule(String tabla, String column, String valor, String catalogo, IAction actTransform) {
		rule =  new Rule(tabla + "" + column, column, "true", actTransform.getName(), 1, tabla, "", valor, catalogo);
		this.actTransform = actTransform;
		return this;
	}

	public void factsSett(Facts facts) {
		this.facts = facts;
	}
	
}
