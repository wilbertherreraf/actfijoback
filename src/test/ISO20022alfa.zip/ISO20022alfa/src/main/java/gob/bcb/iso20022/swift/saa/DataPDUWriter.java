package gob.bcb.iso20022.swift.saa;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.LinkedHashMap;
import java.util.Objects;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlSchema;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.dom.DOMResult;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.prowidesoftware.swift.model.MxSwiftMessage;
import com.prowidesoftware.swift.model.mx.AbstractMX;
import com.prowidesoftware.swift.model.mx.AppHdr;
import com.prowidesoftware.swift.model.mx.DefaultEscapeHandler;
import com.prowidesoftware.swift.model.mx.EscapeHandler;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;
import com.prowidesoftware.swift.model.mx.MxWriteConfiguration;
import com.prowidesoftware.swift.model.mx.MxWriteImpl;
import com.prowidesoftware.swift.model.mx.MxWriteParams;
import com.prowidesoftware.swift.model.mx.adapters.TypeAdaptersConfiguration;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

import gob.bcb.iso20022.core.xml.JaxBConversionService;
import gob.bcb.iso20022.core.xml.XmlToMap;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.iso20022.swift.saa.model.AddressFullName;
import gob.bcb.iso20022.swift.saa.model.AddressInfo;
import gob.bcb.iso20022.swift.saa.model.DataPDU;
import gob.bcb.iso20022.swift.saa.model.Header;
import gob.bcb.iso20022.swift.saa.model.InterfaceInfo;
import gob.bcb.iso20022.swift.saa.model.Message;
import gob.bcb.iso20022.swift.saa.model.NetworkInfo;
import gob.bcb.iso20022.swift.saa.model.SubFormat;
import gob.bcb.iso20022.swift.saa.model.SwAny;
import gob.bcb.iso20022.utils.MxDataTypesConversor;
import gob.bcb.iso20022.utils.UtilsFile;

public class DataPDUWriter {
	private static final Logger log = LoggerFactory.getLogger(DataPDUWriter.class);
	public final static String DATAPDU_NAME = "DataPDU";
	private MxWriteParams params = new MxWriteParams();
	private AbstractMX mx;
	private DataPDU dataPDU;
	final static transient Class[] _classes = new Class[] { DataPDU.class };

	public DataPDUWriter() {
		params = new MxWriteParams();
		dataPDU = new DataPDU();
		createConfig("", false, new DefaultEscapeHandler(), new TypeAdaptersConfiguration(), null, null);
	}

	public DataPDUWriter(final AbstractMX mx) {
		this();
		this.mx = mx;
	}

	public DataPDUWriter initBody() {
		Objects.requireNonNull(dataPDU, "Objecto dataPDU no debe ser nulo");
		if (dataPDU.getBody() == null) {
			dataPDU.setBody(new SwAny());
		}

		dataPDU.getBody().getContent().clear();
		return this;
	}

	public DataPDUWriter initLAU() {
		Objects.requireNonNull(dataPDU, "Objecto dataPDU no debe ser nulo");
		if (dataPDU.getLAU() != null) {
			dataPDU.setBody(null);
		}
		return this;
	}
	
	private String document(AbstractMX mx, MxWriteParams params) {
		params.includeXMLDeclaration = false;
		String xml = MxWriteImpl.write(mx.getNamespace(), mx, mx.getClasses(), params);
		Document doc = JaxBConversionService.getDomFromString(xml);
		String xmlDoc = JaxBConversionService.getStringFromDom(doc, false);
		return xmlDoc;
	}

	public String embeddedSaa(String saaXml, String trxXml) {
		Objects.requireNonNull(dataPDU, "Objecto dataPDU no debe ser nulo");
		Validate.notBlank(saaXml, "XML DataPDU no debe ser blanco");
		Validate.notBlank(trxXml, "XML cuerpo de DataPDU no debe ser blanco");

		final String tagToReplace = "<Saa:Body/>";
		final String tagBody = "Saa:Body";
		StringBuilder xmlBody = new StringBuilder();

		xmlBody.append("<").append(tagBody).append(">");
		xmlBody.append(trxXml);
		xmlBody.append("</").append(tagBody).append(">");
		String saaXmlRet = saaXml.replace(tagToReplace, xmlBody.toString()).trim();
		return saaXmlRet;
	}

	public Document toDoc() {
		try {
			JAXBContext context = JaxbContextLoader.INSTANCE.get(DataPDU.class, _classes);
			Marshaller marshaller = context.createMarshaller();

			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true);
			DocumentBuilder docBuilder = domFactory.newDocumentBuilder();
			Document document = docBuilder.newDocument();
			DOMResult domResult = new DOMResult(document);

			XmlSchema xmlSchema = DataPDU.class.getPackage().getAnnotation(XmlSchema.class);
			marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapper() {
				@Override
				public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
					if (xmlSchema.namespace().equals(namespaceUri)) {
						return "Saa";
					}
					return suggestion;
				}
			});

			marshaller.marshal(dataPDU, domResult);
			return document;
		} catch (Exception e) {
			throw new RuntimeException("DataPDU desparceo: " + e.getMessage(), e);
		}
	}

	public DataPDUWriter xml(String xmlPDU) {
		createConfig("", false, new DefaultEscapeHandler(), new TypeAdaptersConfiguration(), null, null);
		this.mx = AbstractMX.parse(xmlPDU);
		return createDataPDUFromXml(xmlPDU).initBody();
	}

	public DataPDUWriter createDataPDUFromXml(String xml) {
		Validate.notBlank(xml, "XML DataPDU a parsear no debe ser blanco");
		try {
			int pos = xml.indexOf(DATAPDU_NAME);
			if (pos >= 0) {
				JAXBContext context = JaxbContextLoader.INSTANCE.get(DataPDU.class, _classes);

				Unmarshaller u = context.createUnmarshaller();
				dataPDU = (DataPDU) u.unmarshal(new StringReader(xml));
			} else {
				dataPDU = new DataPDU();
			}
			return this;
		} catch (Exception e) {
			throw new RuntimeException("DataPDU no pudo ser desparceado(vea errores anteriores): " + e.getMessage(), e);
		}
	}

	public String xmlSaa() {
		Document doc = toDoc();
		String saaXml = JaxBConversionService.getStringFromDom(doc);

		if (StringUtils.isBlank(saaXml)) {
			throw new RuntimeException("Cadena XML de DataPDU nulo");
		}
		String xmlBz = message();
		if (StringUtils.isBlank(xmlBz)) {
			return saaXml;
		}
		return embeddedSaa(saaXml, xmlBz);
	}

	private String message() {
		if (mx == null) {
			return null;
		}
		
		MxWriteConfiguration usableConf = new MxWriteConfiguration();
		usableConf.includeXMLDeclaration = false;

		StringBuilder xml = new StringBuilder();

		params.prefix = null;
		params.indent = "";
		
		final String header = header(mx.getAppHdr(), params);
		if (header != null) {
			xml.append(header);
		}
		xml.append(document(mx, params));

		return xml.toString();
	}

	private String header(AppHdr appHdr, MxWriteParams params) {
		if (appHdr == null) {
			return null;
		}

		params.includeXMLDeclaration = false;
		String xml = appHdr.xml(params);
		return xml;
	}
	
	public DataPDUWriter xmlPduFromFile(String nFile) {
		String xmlPDU = UtilsFile.readFileAsString2(nFile);
		xml(xmlPDU);
		return this;
	}

	public DataPDUWriter createConfig(String prefix, boolean includeXMLDeclaration, EscapeHandler escapeHandler, TypeAdaptersConfiguration adapters,
			JAXBContext context, String indent) {
		params.prefix = prefix;
		params.includeXMLDeclaration = includeXMLDeclaration;
		params.escapeHandler = escapeHandler;
		if (adapters != null)
			params.adapters = adapters;
		if (context != null)
			params.context = context;
		params.indent = indent;

		return this;
	}

	public DataPDU getDataPDU() {
		return dataPDU;
	}

	public void setDataPDU(DataPDU dataPDU) {
		this.dataPDU = dataPDU;
	}

	public String getSignatureValue() {
		if (dataPDU != null && dataPDU.getLAU() != null) {
			if (dataPDU.getLAU().getContent().size() > 0) {
				Node node = (org.w3c.dom.Element) dataPDU.getLAU().getContent().get(0);
				//String s = ToStringBuilder.reflectionToString(node, ToStringStyle.MULTI_LINE_STYLE);
				String sign = JaxBConversionService.valueOfTag(node,"SignatureValue");
				return sign;
			}
		}
		return null;
	}
	
	public String getDigestValue() {
		if (dataPDU != null && dataPDU.getLAU() != null) {
			if (dataPDU.getLAU().getContent().size() > 0) {
				Node node = (org.w3c.dom.Element) dataPDU.getLAU().getContent().get(0);
				String sign = JaxBConversionService.valueOfTag(node,"DigestValue");
				return sign;
			}
		}
		return null;		
	}
	
	public static void updateFromMxMessage0(DataPDU dataPDU, MxSwiftMessage mxSwftMsg) {
		Objects.requireNonNull(dataPDU, "Objecto dataPDU no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader(), "Objecto dataPDU.Header no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage(), "Objecto dataPDU.Header.Message no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getSender(), "Objecto Sender no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getReceiver(), "Objecto Receiver no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getInterfaceInfo(), "Objecto InterfaceInfo no debe ser nulo");
		Objects.requireNonNull(dataPDU.getHeader().getMessage().getNetworkInfo(), "Objecto NetworkInfo no debe ser nulo");
		// presumponremos que nunca habra msgs de outputs, q mal!!!
		String uumid = MxDataTypesConversor.genUUMID("I", mxSwftMsg.getSender(), mxSwftMsg.getMxId().id(), mxSwftMsg.getReference(), "");
		dataPDU.getHeader().getMessage().setSenderReference(uumid);
		dataPDU.getHeader().getMessage().setMessageIdentifier(mxSwftMsg.getIdentifier());
		dataPDU.getHeader().getMessage().setFormat(mxSwftMsg.isMX() ? "MX" : "MT");
		dataPDU.getHeader().getMessage().setSubFormat(SubFormat.INPUT);
		dataPDU.getHeader().getMessage().getSender().getFullName().setX1(mxSwftMsg.getSender());
		dataPDU.getHeader().getMessage().getReceiver().getFullName().setX1(mxSwftMsg.getReceiver());
		dataPDU.getHeader().getMessage().getInterfaceInfo().setUserReference(mxSwftMsg.getReference());
		dataPDU.getHeader().getMessage().getNetworkInfo().getSWIFTNetNetworkInfo().setRequestType(mxSwftMsg.getMessageType());
	}

	public static DataPDU newDataPDU() {
		DataPDU dataPDU = new DataPDU()//
				.setHeader((new Header())//
						.setMessage(new Message()//
								.setNetworkInfo(new NetworkInfo())//
								.setSender(new AddressInfo().setFullName(new AddressFullName()))//
								.setReceiver(new AddressInfo().setFullName(new AddressFullName()))//
								.setInterfaceInfo(new InterfaceInfo()))//
				);
		return dataPDU;
	}
}
