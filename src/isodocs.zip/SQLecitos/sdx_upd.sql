update banco
set bco_bic = "IADBUS3WXXX",
bco_plaza = "WASHINGTON, DC US"
where bco_codigo = '17';