alter table d_sigcoin.banco add(bco_dn varchar(70));
alter table d_sigcoin.banco add(bco_iddirecc varchar(20));

alter table d_sigcoin.cuenta_acreedor add(ben_iddirecc varchar(20) before cve_vigente);
alter table d_sigcoin.cuenta_acreedor add(ben_subregion varchar(70) before cve_vigente);
alter table d_sigcoin.cuenta_acreedor add(ben_nroedif varchar(20) before cve_vigente);
alter table d_sigcoin.cuenta_acreedor add(ben_dept varchar(70) before cve_vigente);
alter table d_sigcoin.cuenta_acreedor add(ben_codpostal varchar(70) before cve_vigente);

alter table d_sigcoin.mensaje modify(men_plano lvarchar(25000));
alter table d_sigcoin.mensaje add(men_codswift varchar(65) before liq_codigo);

--ALTER TABLE d_sigcoin.swf_mencampos ADD CONSTRAINT UNIQUE (mtf_codmt,mtf_codcampo,mtf_nro,mtf_grpopt) CONSTRAINT swfcmps_ix1;
alter table d_sigcoin.mensaje_esquema modify(mes_codigo varchar(20));
ALTER TABLE d_sigcoin.mensaje_esquema ADD CONSTRAINT PRIMARY KEY (mes_codigo);
    
alter table d_sigcoin.prestamo_esquema modify(mes_codigo varchar(20));

alter table d_sigcoin.cuenta add(cta_bic varchar(20));