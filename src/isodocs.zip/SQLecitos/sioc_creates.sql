alter table d_siocw.soc_bancos add(bco_dn varchar(70) before cla_vigente);

alter table d_siocw.soc_benefs add(ben_bic varchar(15) before ben_plaza);
alter table d_siocw.soc_benefs add(ben_iddirecc varchar(20) before ben_plaza);
alter table d_siocw.soc_benefs add(ben_pais varchar(50) before ben_plaza);
alter table d_siocw.soc_benefs add(ben_subregion varchar(70) before ben_plaza);
alter table d_siocw.soc_benefs add(ben_nroedif varchar(20) before ben_plaza);
alter table d_siocw.soc_benefs add(ben_dept varchar(70) before ben_plaza);
alter table d_siocw.soc_benefs add(ben_codpostal varchar(70) before ben_plaza);

alter table d_siocw.soc_solicitante add(sol_iddirecc varchar(20) before sol_bic);
alter table d_siocw.soc_solicitante add(sol_pais varchar(50) before sol_bic);

alter table d_siocw.soc_cuentas add(ben_codultben varchar(10) before cta_info);
alter table d_siocw.soc_benefsreg add(ben_codultben varchar(10) before info);

alter table d_siocw.swf_mensaje add(men_codswift varchar(65) before men_codmt);

--drop table d_siocw.swf_mencampos;
create table d_siocw.swf_mencampos(
mtf_id                      serial not null,
mtf_codcampo                varchar(50),
mtf_codmt                   varchar(50),
mtf_nro                     integer,
mtf_grpopt                  integer,
mtf_nemo                    varchar(150),
mtf_descrip                 lvarchar(500),
mtf_reglavalid              varchar(150),
mtf_status                  varchar(50),
mtf_tipocampo               varchar(150),
mtf_condicion               lvarchar(380),
mtf_expresion               lvarchar(380),
mtf_xmltag                  varchar(250),
mtf_secpadre                varchar(100),
mtf_bloque                  varchar(50),
mtf_formato                 varchar(100),
mtf_reglaswf                varchar(250),
mtf_datoadic                varchar(150),
mtf_default                 varchar(150),
mtf_estado                  varchar(10),
mtf_indexiso                varchar(150),
mtf_nivel                   integer,
mtf_cardinal	               varchar(150),
mtf_cambiavalor             varchar(150),
mtf_minimo                  varchar(50),
mtf_validacionerror         varchar(10),
mtf_cambiatipousr           varchar(10),
mtf_cardinalmult            varchar(10),
mtf_sinonimos               varchar(150),
mtf_convalornoreq           varchar(10),
mtf_esopcional              varchar(10),
mtf_esadicional             varchar(10),
mtf_subaction               varchar(250),
mtf_subaction2              varchar(250),
mtf_subaction3              varchar(250),
mtf_subaction4              varchar(250),
mtf_subaction5              varchar(250),
  MTF_AUDITUSR         VARCHAR(30),
  MTF_AUDITFHO         DATETIME YEAR TO FRACTION,
  MTF_AUDITWST         VARCHAR(30),
PRIMARY KEY (mtf_id) CONSTRAINT pk_id_swfcampos
);
ALTER TABLE d_siocw.swf_mencampos ADD CONSTRAINT UNIQUE (mtf_codmt,mtf_codcampo,mtf_nro,mtf_grpopt) CONSTRAINT swfcmps_ix1;

create index D_SIOCW.idx_grpcmp on d_siocw.swf_mencampos(mtf_codmt, mtf_nro, mtf_codcampo, mtf_grpopt ASC);
create index D_SIOCW.idx_nmo on d_siocw.swf_mencampos(mtf_nemo ASC);
create index D_SIOCW.idx_mtblk on D_SIOCW.swf_mencampos(mtf_codmt, mtf_bloque ASC);

alter table d_siocw.swf_mensaje modify(men_plano lvarchar(25000));
alter table d_siocw.swf_mensaje add(men_formato varchar(10) before men_auditusr);
alter table d_siocw.swf_mttransfer add(mtt_formato varchar(10));
alter table d_siocw.swf_mttransfer add(mtt_verheader varchar(20));

alter table d_siocw.soc_cuentas modify(cla_esquema varchar(20));
alter table d_siocw.swf_detmensaje modify(dem_codcampo varchar(250))