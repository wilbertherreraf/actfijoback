ALTER TABLE d_lavado.swf_mensaje DROP CONSTRAINT fk_ref_swf_tip2;

alter table d_lavado.swf_mensaje add(men_idtmessagetx varchar(20) before men_inout);
alter table d_lavado.swf_mensaje add(men_formato varchar(10) before men_inout);
alter table d_lavado.swf_mensaje add(men_monswift varchar(10) before men_codmon);
alter table d_lavado.swf_mensaje modify(men_nroswift varchar(80));
alter table d_lavado.swf_mensaje modify(men_firmaorigen varchar(100));
alter table d_lavado.swf_mensaje modify(men_plano lvarchar(25000));

alter table d_lavado.swf_mensaje_h add(men_idtmessagetx varchar(20) before men_inout);
alter table d_lavado.swf_mensaje_h add(men_formato varchar(10) before men_inout);
alter table d_lavado.swf_mensaje_h add(men_monswift varchar(10) before men_codmon);
alter table d_lavado.swf_mensaje_h modify(men_plano lvarchar(25000));

alter table d_lavado.swf_tipomensaje add(tim_codmtswf varchar(20));
alter table d_lavado.swf_tipomensaje add(tim_formato varchar(10));
alter table d_lavado.swf_tipomensaje add(tim_verheader varchar(20));


drop table d_lavado.swf_mencampos;
create table d_lavado.swf_mencampos(
mtf_id                      serial not null,
mtf_codcampo                varchar(50),
mtf_codmt                   varchar(50),
mtf_nro                     integer,
mtf_grpopt                  integer,
mtf_nemo                    varchar(150),
mtf_descrip                 lvarchar(500),
mtf_reglavalid              varchar(150),
mtf_status                  varchar(50),
mtf_tipocampo               varchar(150),
mtf_condicion               lvarchar(380),
mtf_expresion               lvarchar(380),
mtf_xmltag                  varchar(250),
mtf_secpadre                varchar(100),
mtf_bloque                  varchar(50),
mtf_formato                 varchar(100),
mtf_reglaswf                varchar(250),
mtf_datoadic                varchar(150),
mtf_default                 varchar(150),
mtf_estado                  varchar(10),
mtf_indexiso                varchar(150),
mtf_nivel                   integer,
mtf_cardinal	               varchar(150),
mtf_cambiavalor             varchar(150),
mtf_minimo                  varchar(50),
mtf_validacionerror         varchar(10),
mtf_cambiatipousr           varchar(10),
mtf_cardinalmult            varchar(10),
mtf_sinonimos               varchar(150),
mtf_convalornoreq           varchar(10),
mtf_esopcional              varchar(10),
mtf_esadicional             varchar(10),
mtf_subaction               varchar(250),
mtf_subaction2              varchar(250),
mtf_subaction3              varchar(250),
mtf_subaction4              varchar(250),
mtf_subaction5              varchar(250),
  MTF_AUDITUSR         VARCHAR(30),
  MTF_AUDITFHO         DATETIME YEAR TO FRACTION,
  MTF_AUDITWST         VARCHAR(30),
PRIMARY KEY (mtf_id) CONSTRAINT pk_id_swfcampos
);
ALTER TABLE d_lavado.swf_mencampos ADD CONSTRAINT UNIQUE (mtf_codmt,mtf_codcampo,mtf_nro,mtf_grpopt) CONSTRAINT swfcmps_ix1;
create index d_lavado.idx_grpcmp on d_lavado.swf_mencampos(mtf_codmt, mtf_nro, mtf_codcampo, mtf_grpopt ASC);
create index d_lavado.idx_nmo on d_lavado.swf_mencampos(mtf_nemo ASC);
create index d_lavado.idx_mtblk on d_lavado.swf_mencampos(mtf_codmt, mtf_bloque ASC);

