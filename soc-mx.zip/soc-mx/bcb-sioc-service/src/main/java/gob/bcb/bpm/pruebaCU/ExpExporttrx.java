package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "exp_exporttrx")
public class ExpExporttrx implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="ext_codexpo")
	private Integer extCodexpo;
	@Column(name ="ext_solcodigo")
	private String extSolcodigo;
	@Column(name ="ext_nrolote")
	private Integer extNrolote;
	@Column(name ="ext_soccodigo")
	private String extSoccodigo;
	@Column(name ="ext_montomo")
	private BigDecimal extMontomo;
	@Column(name ="ext_codmonmo")
	private String extCodmonmo;
	@Temporal(TemporalType.DATE)
	@Column(name ="ext_fecfactor")
	private Date extFecfactor;
	@Column(name ="ext_montopar")
	private BigDecimal extMontopar;	
	@Column(name ="ext_codmonpar")
	private String extCodmonpar;
	@Column(name ="ext_montomn")
	private BigDecimal extMontomn;
	@Column(name ="ext_diffcamb")
	private BigDecimal extDiffcamb;
	@Column(name ="ext_idoperorig")
	private String extIdoperorig;
	@Column(name ="ext_descrip")
	private String extDescrip;
	@Column(name ="ext_archivo")
	private String extArchivo;
	@Temporal(TemporalType.DATE)
	@Column(name ="ext_fecha")
	private Date extFecha;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name ="ext_fechorecep")
	private Date extFechorecep;
	@Temporal(TemporalType.DATE)
	@Column(name ="ext_fechovalid")
	private Date extFechovalid;
	@Temporal(TemporalType.DATE)
	@Column(name ="ext_fechoauto")
	private Date extFechoauto;
	@Column(name ="ext_bencodigo")
	private String extBencodigo;	
	@Column(name ="ext_estrecep")
	private String extEstrecep;
	@Column(name ="ext_estcont")
	private String extEstcont;
	@Column(name = "ext_esqcodigo")
	private Integer extEsqcodigo;
	@Column(name = "ext_auditusr")
	private String extAuditusr;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ext_auditfho")
	private Date extAuditfho;
	@Column(name = "ext_auditwst")
	private String extAuditwst;
	
	public ExpExporttrx() {
		// TODO Auto-generated constructor stub
	}
	public Integer getExtCodexpo() {
		return extCodexpo;
	}
	public void setExtCodexpo(Integer extCodexpo) {
		this.extCodexpo = extCodexpo;
	}
	public String getExtSolcodigo() {
		return extSolcodigo;
	}
	public void setExtSolcodigo(String extSolcodigo) {
		this.extSolcodigo = extSolcodigo;
	}
	public Integer getExtNrolote() {
		return extNrolote;
	}
	public void setExtNrolote(Integer extNrolote) {
		this.extNrolote = extNrolote;
	}
	public String getExtSoccodigo() {
		return extSoccodigo;
	}
	public void setExtSoccodigo(String extSoccodigo) {
		this.extSoccodigo = extSoccodigo;
	}
	public BigDecimal getExtMontomo() {
		return extMontomo;
	}
	public void setExtMontomo(BigDecimal extMontomo) {
		this.extMontomo = extMontomo;
	}
	public String getExtCodmonmo() {
		return extCodmonmo;
	}
	public void setExtCodmonmo(String extCodmonmo) {
		this.extCodmonmo = extCodmonmo;
	}
	public Date getExtFecfactor() {
		return extFecfactor;
	}
	public void setExtFecfactor(Date extFecfactor) {
		this.extFecfactor = extFecfactor;
	}
	public String getExtCodmonpar() {
		return extCodmonpar;
	}
	public void setExtCodmonpar(String extCodmonpar) {
		this.extCodmonpar = extCodmonpar;
	}
	public BigDecimal getExtMontomn() {
		return extMontomn;
	}
	public void setExtMontomn(BigDecimal extMontomn) {
		this.extMontomn = extMontomn;
	}
	public BigDecimal getExtDiffcamb() {
		return extDiffcamb;
	}
	public void setExtDiffcamb(BigDecimal extDiffcamb) {
		this.extDiffcamb = extDiffcamb;
	}
	public String getExtIdoperorig() {
		return extIdoperorig;
	}
	public void setExtIdoperorig(String extIdoperorig) {
		this.extIdoperorig = extIdoperorig;
	}
	public String getExtDescrip() {
		return extDescrip;
	}
	public void setExtDescrip(String extDescrip) {
		this.extDescrip = extDescrip;
	}
	public Date getExtFecha() {
		return extFecha;
	}
	public void setExtFecha(Date extFecha) {
		this.extFecha = extFecha;
	}
	public Date getExtFechorecep() {
		return extFechorecep;
	}
	public void setExtFechorecep(Date extFechorecep) {
		this.extFechorecep = extFechorecep;
	}
	public Date getExtFechovalid() {
		return extFechovalid;
	}
	public void setExtFechovalid(Date extFechovalid) {
		this.extFechovalid = extFechovalid;
	}
	public Date getExtFechoauto() {
		return extFechoauto;
	}
	public void setExtFechoauto(Date extFechoauto) {
		this.extFechoauto = extFechoauto;
	}
	public String getExtEstrecep() {
		return extEstrecep;
	}
	public void setExtEstrecep(String extEstrecep) {
		this.extEstrecep = extEstrecep;
	}
	public String getExtEstcont() {
		return extEstcont;
	}
	public void setExtEstcont(String extEstcont) {
		this.extEstcont = extEstcont;
	}
	public String getExtAuditusr() {
		return extAuditusr;
	}
	public void setExtAuditusr(String extAuditusr) {
		this.extAuditusr = extAuditusr;
	}
	public Date getExtAuditfho() {
		return extAuditfho;
	}
	public void setExtAuditfho(Date extAuditfho) {
		this.extAuditfho = extAuditfho;
	}
	public String getExtAuditwst() {
		return extAuditwst;
	}
	public void setExtAuditwst(String extAuditwst) {
		this.extAuditwst = extAuditwst;
	}
	public Integer getExtEsqcodigo() {
		return extEsqcodigo;
	}
	public void setExtEsqcodigo(Integer extEsqcodigo) {
		this.extEsqcodigo = extEsqcodigo;
	}
	public String getExtBencodigo() {
		return extBencodigo;
	}
	public void setExtBencodigo(String extBencodigo) {
		this.extBencodigo = extBencodigo;
	}
	public BigDecimal getExtMontopar() {
		return extMontopar;
	}
	public void setExtMontopar(BigDecimal extMontopar) {
		this.extMontopar = extMontopar;
	}
	public String getExtArchivo() {
		return extArchivo;
	}
	public void setExtArchivo(String extArchivo) {
		this.extArchivo = extArchivo;
	}
	
	
}
