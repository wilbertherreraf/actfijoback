package gob.bcb.swift.dao;

import gob.bcb.swift.model.SwfMttransfer;

import java.util.List;

import org.hibernate.SessionFactory;

public interface SwfMttransferLocal {
	SwfMttransfer findByCodigo(String mttCodttransfer);

	List<SwfMttransfer> getMTs();
	void setSessionFactory(SessionFactory sessionFactory);

}
