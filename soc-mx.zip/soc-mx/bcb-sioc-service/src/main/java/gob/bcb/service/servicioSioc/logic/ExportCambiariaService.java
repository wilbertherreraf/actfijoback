package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import gob.bcb.bpm.pruebaCU.ExpClasiffactor;
import gob.bcb.bpm.pruebaCU.ExpClasiffactorDao;
import gob.bcb.bpm.pruebaCU.ExpExporttrx;
import gob.bcb.bpm.pruebaCU.ExpExporttrxDao;
import gob.bcb.bpm.pruebaCU.ExpExporttrxdet;
import gob.bcb.bpm.pruebaCU.ExpExporttrxdetDao;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiId;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.bpm.pruebaCU.UtilsSioc;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioTres.model.FactorConvMnDao;
import gob.bcb.swift.service.ArchivoSinpleServiceImpl;

public class ExportCambiariaService {
	private final static Logger log = LoggerFactory.getLogger(ExportCambiariaService.class);
	private ExpClasiffactorDao expClasiffactorDao;
	private GenMonedaDao genMonedaDao;
	private ExpExporttrxDao expExporttrxDao;
	private ExpExporttrxdetDao expExporttrxdetDao;
	private SocEsquemasDao socEsquemasDao;
	private ProcesosSolicitud procesosSolicitud;
	private SocSolicitudctasDao socSolicitudctasDao;
	private SocOpecomiDao socOpecomiDao;
	private FactorConvMnDao factorConvMnDao;
	private final static String vCmp = "C";

	public void inicializa(SessionFactory sessionFactory, SessionFactory sessionFactoryCoin) {
		expClasiffactorDao = new ExpClasiffactorDao();
		expClasiffactorDao.setSessionFactory(sessionFactory);
		genMonedaDao = new GenMonedaDao();
		genMonedaDao.setSessionFactory(sessionFactory);
		expExporttrxDao = new ExpExporttrxDao();
		expExporttrxDao.setSessionFactory(sessionFactory);
		expExporttrxdetDao = new ExpExporttrxdetDao();
		expExporttrxdetDao.setSessionFactory(sessionFactory);
		socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(sessionFactory);
		procesosSolicitud = new ProcesosSolicitud();
		procesosSolicitud.setSessionFactory(sessionFactory);
		socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(sessionFactory);
		socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(sessionFactory);

		factorConvMnDao = new FactorConvMnDao();
		factorConvMnDao.setSessionFactory(sessionFactoryCoin);
		UtilsSioc utilsSioc = new UtilsSioc();
		utilsSioc.setFactorConvMnDao(factorConvMnDao);
	}

	public ExpExporttrx salvarLote(ExpExporttrx expExporttrx, List<ExpExporttrxdet> exps) {
		log.info("Salvando oper cambiaria Export " + expExporttrx.getExtAuditusr());

		verificaExp(expExporttrx);
		verificaExpDet(exps);

		expExporttrx.setExtAuditfho(new Date());
		ExpExporttrx newE = expExporttrxDao.saveOrUpdate(expExporttrx);

		exps.forEach(e -> {
			updDatAdic(newE, e);
		});

		exps.forEach(e -> {
			salvarExpDet(e);
		});

		verificaExport(newE);
		return newE;
	}

	public void salvarExpDet(ExpExporttrxdet expDet) {
		expExporttrxdetDao.saveOrUpdate(expDet);
	}

	public List<ExpExporttrxdet> loadAndUpdate(ExpExporttrx expExporttrx, ArchivoSinpleServiceImpl archivoSinpleService, String nameSheet, Integer firstRow) {
		log.info("Cargando " + archivoSinpleService.getArchivoSinple().getNameOriginal());
		List<ExpExporttrxdet> exps = ExportsUpload.loadFile(archivoSinpleService, nameSheet, firstRow).stream().map(e -> {
			updDatFactor(expExporttrx.getExtFecha(), e);
			return e;
		}).collect(Collectors.toList());

		expExporttrx.setExtArchivo(archivoSinpleService.getArchivoSinple().getNameOriginal());
		expExporttrx.setExtFechorecep(new Date());

		log.info("Cargado " + archivoSinpleService.getArchivoSinple().getNameOriginal() + " ... hecho " + exps.size());
		return exps;
	}

	public void updHdrLote(ExpExporttrx expExporttrx, List<ExpExporttrxdet> exps) {
		ExpExporttrxdet edtot = ExpExporttrxdetDao.retTotales(exps);
		expExporttrx.setExtMontomo(edtot.getDexMontousd());
		expExporttrx.setExtCodmonmo(Constants.COD_MONEDA_USD.toString());
		expExporttrx.setExtMontopar(edtot.getDexMontopar());
		expExporttrx.setExtCodmonpar(Constants.COD_MONEDA_BS.toString());

		Map<String, Object> montoConvertido = UtilsSioc.conversion(expExporttrx.getExtMontomo(), Integer.valueOf(expExporttrx.getExtCodmonmo()),
				Constants.COD_MONEDA_BS, expExporttrx.getExtFecha(), null, vCmp);

		BigDecimal montoBS = (BigDecimal) montoConvertido.get("montobs");
		BigDecimal montoMO = (BigDecimal) montoConvertido.get("montomo");
		BigDecimal tipocambiomo = (BigDecimal) montoConvertido.get("tipocambiomo");
		BigDecimal montoADebitarSUS = (BigDecimal) montoConvertido.get("montosus");

		expExporttrx.setExtMontomn(montoBS);
		expExporttrx.setExtDiffcamb(expExporttrx.getExtMontopar().subtract(expExporttrx.getExtMontomn()));
	}

	private void updDatAdic(ExpExporttrx expExporttrx, ExpExporttrxdet item) {
		item.getId().setDexCodexpo(expExporttrx.getExtCodexpo());
		item.setDexAuditfho(new Date());
		item.setDexAuditusr(expExporttrx.getExtAuditusr());
		item.setDexAuditwst(expExporttrx.getExtAuditwst());
	}

	public void updDatFactores(Date fecha, List<ExpExporttrxdet> items) {
		for (ExpExporttrxdet expDet : items) {
			updDatFactor(fecha, expDet);
		}
	}

	public void updDatFactor(Date fecha, ExpExporttrxdet expDet) {
		Optional<ExpClasiffactor> factor = expClasiffactorDao.findTramoVig(fecha, null, expDet.getDexMontousd());
		genMonedaDao.findBySigla(expDet.getDexCodmonmo()).ifPresent(m -> {
			expDet.setDexCodmonmo(m.getCodMoneda().toString());
		});

		expDet.setDexCodmonpar(null);
		expDet.setDexTramo(null);
		expDet.setDexTctramo(BigDecimal.ZERO);
		expDet.setDexCtatramo(null);
		expDet.setDexMontomn(BigDecimal.ZERO);
		expDet.setDexMontopar(BigDecimal.ZERO);

		if (factor.isPresent()) {
			ExpClasiffactor f = factor.get();
			expDet.setDexCodmonpar(f.getId().getFacCodmonpar());
			expDet.setDexTramo(f.getId().getFacTramo());
			expDet.setDexTctramo(f.getFacTctramo());
			expDet.setDexCtatramo(f.getFacCtatramo());
			expDet.setDexFechavig(f.getId().getFacFechavig());

			BigDecimal montoConvMonDestino = expDet.getDexMontousd().multiply(expDet.getDexTctramo()).setScale(2, BigDecimal.ROUND_HALF_UP);
			expDet.setDexMontopar(montoConvMonDestino);
			expDet.setDexCodmonpar(Constants.COD_MONEDA_BS.toString());

			Map<String, Object> montoConvertido = UtilsSioc.conversion(expDet.getDexMontousd(), Constants.COD_MONEDA_USD, Constants.COD_MONEDA_BS, fecha,
					null, vCmp);

			BigDecimal montoBS = (BigDecimal) montoConvertido.get("montobs");
			BigDecimal montoMO = (BigDecimal) montoConvertido.get("montomo");
			BigDecimal tipocambiomo = (BigDecimal) montoConvertido.get("tipocambiomo");
			BigDecimal montoADebitarSUS = (BigDecimal) montoConvertido.get("montosus");

			expDet.setDexMontomn(montoBS);
			expDet.setDexTccont(tipocambiomo);
		}
	}

	public void verificaExport(ExpExporttrx expDet) {
		List<ExpExporttrxdet> exps = expExporttrxdetDao.retLote(expDet.getExtCodexpo());
		ExpExporttrxdet edtot = ExpExporttrxdetDao.retTotales(exps);

		if (expDet.getExtMontomo().compareTo(edtot.getDexMontousd()) != 0) {
			throw new BusinessException(
					"Monto en USD del sumarizado(" + expDet.getExtMontomo() + ") difiere con el registrado en el detalle (" + edtot.getDexMontousd() + ")");
		}

		if (expDet.getExtMontopar().compareTo(edtot.getDexMontopar()) != 0) {
			throw new BusinessException(
					"Monto en USD del sumarizado(" + expDet.getExtMontopar() + ") difiere con el registrado en el detalle (" + edtot.getDexMontopar() + ")");
		}
	}

	public void verificaExp(ExpExporttrx expDet) {
		if (expDet.getExtMontomo() == null || expDet.getExtMontomo().compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException("Monto en USD debe ser mayor a cero");
		}
		if (expDet.getExtMontomn() == null || expDet.getExtMontomn().compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException("Monto en MN oficial debe ser mayor a cero");
		}
		if (expDet.getExtMontopar() == null || expDet.getExtMontopar().compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException("Monto en MN paralelo debe ser mayor a cero");
		}
		if (expDet.getExtFecha() == null) {
			throw new BusinessException("Fecha de operacion debe tener valor");
		}
	}

	public void verificaExpDet(List<ExpExporttrxdet> exps) {
		exps.forEach(e -> {
			verificaExpDet(e);
		});
	}

	public void verificaExpDet(ExpExporttrxdet expDet) {
		if (expDet.getDexMontousd() == null || expDet.getDexMontousd().compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException(
					"Item: " + expDet.getId().getDexNrodet() + " - Monto en USD debe ser mayor a cero, nro: " + expDet.getId().getDexNrodet());
		}
		if (expDet.getDexMontomn() == null || expDet.getDexMontomn().compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException(
					"Item: " + expDet.getId().getDexNrodet() + " - Monto MN Official debe ser mayor a cero, nro:  " + expDet.getId().getDexNrodet());
		}
		if (expDet.getDexMontopar() == null || expDet.getDexMontopar().compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException(
					"Item: " + expDet.getId().getDexNrodet() + " - Monto TC Paralelo debe ser mayor a cero, nro:  " + expDet.getId().getDexNrodet());
		}
		if (expDet.getDexTctramo() == null || expDet.getDexTctramo().compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException(
					"Item: " + expDet.getId().getDexNrodet() + " - TC Paralelo debe ser mayor a cero, nro:  " + expDet.getId().getDexNrodet());
		}

		if (expDet.getDexMontomo().compareTo(expDet.getDexMontopar()) != 0) {
			throw new BusinessException("Item: " + expDet.getId().getDexNrodet() + " - Monto origen en BS (" + expDet.getDexMontomo()
					+ ") difiere con el calculado (" + expDet.getDexMontopar() + ")");
		}

	}

	public Solicitud iniOActSolicitudExport(ExpExporttrx expExporttrx, List<ExpExporttrxdet> exps, Solicitud solicitudIn) {
		log.info("en iniOActSolicitudExport para export {}", expExporttrx.getExtCodexpo());

		Solicitud solicitud = recOCreaSolicitud(expExporttrx.getExtCodexpo());
		SocSolicitudes socSolicitudes = solicitud.getSolicitud();

		socSolicitudes.setSolCodigo(expExporttrx.getExtSolcodigo().trim());
		socSolicitudes.setEsqCodigo(expExporttrx.getExtEsqcodigo());

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(expExporttrx.getExtEsqcodigo());
		socSolicitudes.setClaTipo(socEsquemas.getCodTipooper());
		socSolicitudes.setCveSubtipooper(socEsquemas.getCveSubtipooper());

		socSolicitudes.setDetConcepto(expExporttrx.getExtDescrip());

		SocDetallessol socDetallessol = solicitudIn.getSocDetallessolLista().get(0);
		socDetallessol.setBenCodigo(expExporttrx.getExtBencodigo());

		socSolicitudes.setSocMontome(expExporttrx.getExtMontomo());
		// moneda de la carta
		socSolicitudes.setCodMoneda(Integer.valueOf(expExporttrx.getExtCodmonmo()));
		// sera la moneda seleccionada
		socSolicitudes.setCodMonedat(Integer.valueOf(expExporttrx.getExtCodmonmo()));

		// socDetallessol.setNroCuentabco(carCartascrdet.getCcdCodbcoreceptor());
		socDetallessol.setDetMonto(expExporttrx.getExtMontomn());
		socDetallessol.setCodMoneda(Constants.COD_MONEDA_BS);

		Assert.notNull(socDetallessol.getCodBanco(), "Entidad depositaria debe tener un valor");
		Assert.notNull(socDetallessol.getDetCodttransfer(), "Esquema swift debe tener un valor");
		Assert.isTrue(solicitudIn.getSocSolicitudctasLista() != null && solicitudIn.getSocSolicitudctasLista().size() > 0, "Lista de cuentas vacía");

		boolean existeCtaFV = false;
		// validar cuenta fondos vista
		for (SocSolicitudctas socSolicitudctas : solicitudIn.getSocSolicitudctasLista()) {
			if (socSolicitudctas.getId() != null) {
				if (!StringUtils.isBlank(socSolicitudctas.getId().getTipoCuenta())) {
					if (socSolicitudctas.getId().getTipoCuenta().equals(Constants.COD_CLAVE_BENEFMT)) {
						if (StringUtils.isBlank(socSolicitudctas.getCtaAfectable())) {
							throw new BusinessException("Cuenta Fondos Vista en socSolicitudctas debe tener valor.");
						}
						existeCtaFV = true;
						break;
					}
				}
			}
		}

		Assert.isTrue(existeCtaFV, "Cuenta Fondos Vista inválida");
		return solicitud;
	}

	public Solicitud recOCreaSolicitud(Integer expCod) {
		Solicitud solicitud = null;
		Optional<ExpExporttrx> expExportOpt = expExporttrxDao.findByCodexpo(expCod);
		if (!expExportOpt.isPresent()) {
			throw new RuntimeException("Opercion no registrada");
		}

		ExpExporttrx export = expExportOpt.get();
		List<ExpExporttrxdet> exps = expExporttrxdetDao.retLote(expCod);

		if (StringUtils.isBlank(export.getExtSoccodigo())) {
			solicitud = inicializaSolicitudParaExp(export, exps);
		} else {
			solicitud = procesosSolicitud.recuperarSolicitudSimple(export.getExtSoccodigo());
			List<SocSolicitudctas> socSolicitudctasListaOld = socSolicitudctasDao.getCuentas(export.getExtSoccodigo());
			solicitud.setSocSolicitudctasLista(socSolicitudctasListaOld);
			solicitud.setExporttrx(export);
			solicitud.setExporttrxLista(exps);
		}

		return solicitud;
	}

	public Solicitud inicializaSolicitudParaExp(ExpExporttrx expExporttrx, List<ExpExporttrxdet> exps) {
		log.info("en crearSolicitudParaExp para export {}", expExporttrx.getExtCodexpo());
		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(expExporttrx.getExtEsqcodigo());
		Solicitud solicitud = nuevaSolicitud(socEsquemas);

		SocSolicitudes socSolicitudes = solicitud.getSolicitud();
		socSolicitudes.setSolCodigo(expExporttrx.getExtSolcodigo().trim());
		socSolicitudes.setCodMoneda(Integer.valueOf(expExporttrx.getExtCodmonmo()));
		socSolicitudes.setCodMonedat(Integer.valueOf(expExporttrx.getExtCodmonmo()));

		solicitud.getSocDetallessolLista().get(0).setBenCodigo("");
		solicitud.getSocDetallessolLista().get(0).setCodMoneda(Constants.COD_MONEDA_USD);

		solicitud.setExporttrx(expExporttrx);
		solicitud.setExporttrxLista(exps);

		return solicitud;
	}

	public void actualizarDIFFCOMPRA(ExpExporttrx expExporttrx, Solicitud solicitudIn) {
		log.info("en DIFFCOMPRADIFFCOMPRADIFFCOMPRA " + expExporttrx.getExtMontopar() + " usd " + expExporttrx.getExtMontomo() + " MN "
				+ expExporttrx.getExtMontomn());
		SocOpecomi socOpecomi = newOpercomi(solicitudIn, Constants.COD_VAR_MONTODIFCAMBCOMDIV);
		socOpecomi.setMontoMo(expExporttrx.getExtDiffcamb());
		socOpecomi.setCodMoneda(Integer.valueOf(Constants.COD_MONEDA_BS));

		socOpecomiDao.getHibernateTemplate().merge(socOpecomi);
	}

	public void actualizarMONTOD(ExpExporttrx expExporttrx, Solicitud solicitudIn) {
		log.info("par " + expExporttrx.getExtMontopar() + " usd " + expExporttrx.getExtMontomo() + " MN " + expExporttrx.getExtMontomn());
		SocOpecomi socOpecomi = newOpercomi(solicitudIn, Constants.COD_VAR_MONTOD);
		socOpecomi.setMontoMo(expExporttrx.getExtMontopar());
		socOpecomi.setCodMoneda(Integer.valueOf(expExporttrx.getExtCodmonpar()));

		socOpecomiDao.getHibernateTemplate().merge(socOpecomi);
	}

	public SocOpecomi newOpercomi(Solicitud solicitudIn, String codVar) {

		SocOpecomi socOpecomiTOTTRANSMT = socOpecomiDao.getOpeComisByDetCodClaCom(solicitudIn.getSolicitud().getSocCodigo(), 0, codVar);

		if (socOpecomiTOTTRANSMT == null) {
			SocOpecomiId socOpecomiId = new SocOpecomiId();
			socOpecomiTOTTRANSMT = new SocOpecomi();
			socOpecomiTOTTRANSMT.setId(socOpecomiId);
			socOpecomiTOTTRANSMT.getId().setOpeCodigo(solicitudIn.getSolicitud().getSocCodigo());
			socOpecomiTOTTRANSMT.getId().setDetCodigo(0);
			socOpecomiTOTTRANSMT.getId().setClaComision(codVar);
		}

		socOpecomiTOTTRANSMT.setMontoMo(BigDecimal.ZERO);
		socOpecomiTOTTRANSMT.setCodMoneda(Integer.valueOf(Constants.COD_MONEDA_BS));
		socOpecomiTOTTRANSMT.setCveTipocomis("V");
		socOpecomiTOTTRANSMT.setClaEstadovar("C");
		socOpecomiTOTTRANSMT.setOcoMonto(BigDecimal.ZERO);
		socOpecomiTOTTRANSMT.setOcoMontoimpt(BigDecimal.ZERO);
		socOpecomiTOTTRANSMT.setTipoCambio(BigDecimal.ZERO);
		socOpecomiTOTTRANSMT.setFechaHora(new Date());
		socOpecomiTOTTRANSMT.setEstacion(solicitudIn.getCodEstacionAudit());
		socOpecomiTOTTRANSMT.setUsrCodigo(solicitudIn.getCodUsuarioAudit());

		return socOpecomiTOTTRANSMT;
	}

	public void calcComision(Date fecIni, Date fecFin) {
		Map<String, ExpExporttrxdet> mapLimits = new HashMap<>();
		List<ExpExporttrxdet> exps = expExporttrxdetDao.retEntreFechas(fecIni, fecFin);
		List<ExpExporttrxdet> expList = new ArrayList<>();

		List<ExpClasiffactor> fVigs = expClasiffactorDao.findVigentes(fecIni, null, null);
		if (fVigs.size() == 0) {
			throw new BusinessException("No existen rango vigentes anteriores a " + fecIni);
		}

		for (ExpClasiffactor f : fVigs) {
			ExpExporttrxdet ed = ExpExporttrxdetDao.newExportdet();
			ed.setDexMontopar(f.getFacLimiteinf());
			ed.setDexMontomo(f.getFacLimitesup());
			ed.setDexMontodiff(f.getFacPcomis());
			ed.setDexTramo(f.getId().getFacTramo());
			expList.add(ed);
			mapLimits.put(f.getId().getFacTramo(), ed);
		}

		BigDecimal sumUsd = BigDecimal.ZERO;
		Date fVigente = fVigs.get(0).getId().getFacFechavig();
		for (ExpExporttrxdet exp : exps) {
			BigDecimal sumPrv = sumUsd;
			BigDecimal amtLInf = BigDecimal.ZERO;
			BigDecimal amtresto = BigDecimal.ZERO;
			BigDecimal amtMM = BigDecimal.ZERO;
			BigDecimal amtrestoF = BigDecimal.ZERO;
			BigDecimal amtMMF = BigDecimal.ZERO;

			Optional<ExpClasiffactor> lPrvInf = expClasiffactorDao.limInf(fVigente, sumPrv, null, null);
			Optional<ExpClasiffactor> lPrvSup = expClasiffactorDao.limSup(fVigente, sumPrv, null, null);

			sumUsd = sumUsd.add(exp.getDexMontousd().setScale(0, RoundingMode.DOWN));
			Optional<ExpClasiffactor> lInf = expClasiffactorDao.limInf(fVigente, sumUsd, null, null);
			Optional<ExpClasiffactor> lSup = expClasiffactorDao.limSup(fVigente, sumUsd, null, null);
			Optional<ExpClasiffactor> lInfF = expClasiffactorDao.limInf(fVigente, lInf.get().getFacLimiteinf(), null, null);
			lInfF = !lInfF.isPresent() ? lInf : lInfF;
			if (!lInf.get().getId().getFacTramo().equals(lSup.get().getId().getFacTramo())) {
				lInf = lSup;
			}
			amtrestoF = lInf.get().getFacPcomis();

			if (sumUsd.compareTo(lPrvSup.get().getFacLimitesup()) > 0) {

				amtMM = lInf.get().getFacLimiteinf();
				amtMMF = lInf.get().getFacPcomis();
				amtresto = sumUsd.subtract(lInf.get().getFacLimitesup()).setScale(0, RoundingMode.DOWN);

			} else {
				amtMM = lPrvSup.get().getFacLimiteinf();
				amtMMF = lPrvSup.get().getFacPcomis();
				amtresto = sumUsd.subtract(lPrvSup.get().getFacLimiteinf()).setScale(0, RoundingMode.DOWN);
			}
			amtMM = lInf.get().getFacLimiteinf();
			amtresto = sumUsd.subtract(lInf.get().getFacLimiteinf()).setScale(0, RoundingMode.DOWN);

			BigDecimal amtInf = lInf.get().getFacLimiteinf().setScale(0, RoundingMode.DOWN);
			BigDecimal amtSup = sumUsd.subtract(lInf.get().getFacLimiteinf().setScale(0, RoundingMode.DOWN));

			ExpExporttrxdet ed = ExpExporttrxdetDao.newExportdet();
			ed.setDexMontousd(sumUsd);
			ed.setDexMontomo(exp.getDexMontousd().setScale(0, RoundingMode.DOWN));
			ed.setDexMontodiff(amtSup);

			ExpExporttrxdet edA = mapLimits.get(lInf.get().getId().getFacTramo());
			edA.setDexMontousd(edA.getDexMontousd().add(sumUsd));

			log.info(sumPrv + "  " + exp.getDexMontousd() + " = " + sumUsd + ":: "
					+ lInf.get().getFacLimiteinf() + " -> " + sumUsd + "(" + lInf.get().getFacPcomis() + ") " + lSup.get().getFacLimitesup() + "] " + amtMM
					+ "(" + lInfF.get().getFacPcomis() + ")" + " : " + amtresto + "(" + amtrestoF + ")");
		}
		mapLimits.entrySet().forEach(e -> {
			log.info("reg " + e.getKey() + " -> " + e.getValue().getDexMontousd());
		});
		expList.forEach(r -> {
			// log.info("reg " + r.getDexMontousd());
		});
	}

	public static Solicitud nuevaSolicitud(SocEsquemas socEsquemas) {
		Solicitud solicitud = new Solicitud();
		SocSolicitudes socSolicitudes = inicializarSocSolicitudes(socEsquemas);
		solicitud.setSolicitud(socSolicitudes);

		solicitud = nuevoSolicitudDetalle(solicitud);

		solicitud.setSocSolicitante(new SocSolicitante());
		return solicitud;
	}

	public static SocSolicitudes inicializarSocSolicitudes(SocEsquemas socEsquemas) {
		SocSolicitudes socSolicitudes = new SocSolicitudes();

		socSolicitudes.setClaEstadows(Constants.CLAVE_ESTWS_PROCESADO);
		socSolicitudes.setFecha(new Date());
		socSolicitudes.setFechaReg(new Date());
		// para enmiendas fecha sera el saldo
		socSolicitudes.setSocMontome(BigDecimal.ZERO);
		socSolicitudes.setCodMoneda(Constants.COD_MONEDA_USD);
		socSolicitudes.setSocMontoord(BigDecimal.ZERO);
		socSolicitudes.setSocMontomn(BigDecimal.ZERO);
		socSolicitudes.setCodMonedat(Constants.COD_MONEDA_USD);
		socSolicitudes.setSolEntsolic(Constants.COD_BCB);
		socSolicitudes.setTipoConcepto("O"); // ojoooo
		socSolicitudes.setCveTipctasolic(Constants.CLAVE_GENERADOPOR_SISTEMA);
		socSolicitudes.setSocTipnegociacion(Constants.CLAVE_TIPNEGOCIA_NORMAL);
		socSolicitudes.setClaTipo(Constants.CLAVE_SUBTIPOOPER_EXPO);
		socSolicitudes.setCveSubtipooper(Constants.CLAVE_SUBTIPOOPER_EXPO);
		socSolicitudes.setTipoRetencion(Constants.CLAVE_TIPORETENCION_SINDESC);

		socSolicitudes.setEsqCodigo(socEsquemas.getEsqCodigo());
		socSolicitudes.setClaTipo(socEsquemas.getCodTipooper());
		socSolicitudes.setCveSubtipooper(socEsquemas.getCveSubtipooper());

		return socSolicitudes;
	}

	private static Solicitud nuevoSolicitudDetalle(Solicitud solicitud) {
		SocDetallessol socDetallessol = inicializarSolicitudDetalle(solicitud.getSocDetallessolLista().size() + 1);
		solicitud.getSocDetallessolLista().add(socDetallessol);
		return solicitud;
	}

	public static SocDetallessol inicializarSolicitudDetalle(Integer detCodigo) {

		SocDetallessol socDetallessol = new SocDetallessol();
		SocDetallessolId socDetallessolId = new SocDetallessolId();
		socDetallessolId.setDetCodigo(detCodigo);
		socDetallessol.setId(socDetallessolId);
		socDetallessol.setBenCodigo(Constants.COD_BCB);
		socDetallessol.setDetMonto(BigDecimal.ZERO);
		socDetallessol.setDetMontoord(BigDecimal.ZERO);
		socDetallessol.setDetMontotrans(BigDecimal.ZERO);
		socDetallessol.setCodMoneda(Constants.COD_MONEDA_USD);
		socDetallessol.setCodMonedatdet(Constants.COD_MONEDA_USD);

		return socDetallessol;
	}

}
