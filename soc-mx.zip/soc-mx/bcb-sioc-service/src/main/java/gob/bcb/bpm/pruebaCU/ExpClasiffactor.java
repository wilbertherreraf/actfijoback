package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="exp_clasiffactor")
public class ExpClasiffactor implements Serializable{
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	private ExpClasiffactorPK id;
	
	@Column(name = "fac_tctramo")
	private BigDecimal facTctramo;
	@Column(name = "fac_limiteinf")
	private BigDecimal facLimiteinf;
	@Column(name = "fac_limitesup")
	private BigDecimal facLimitesup;
	@Column(name = "fac_docresol")
	private String facDocresol;
	@Column(name = "fac_codmon")
	private String facCodmon;
	@Column(name = "fac_ctatramo")
	private String facCtatramo;
	@Column(name = "fac_pcomis")
	private BigDecimal facPcomis;	
	@Column(name = "fac_estfactor")
	private String facEstfactor;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fac_auditfho")
	private Date facAuditfho;

	@Column(name = "fac_auditusr")
	private String facAuditusr;

	@Column(name = "fac_auditwst")
	private String facAuditwst;

	public ExpClasiffactor() {
	}
	public ExpClasiffactorPK getId() {
		return id;
	}

	public void setId(ExpClasiffactorPK id) {
		this.id = id;
	}

	public BigDecimal getFacTctramo() {
		return facTctramo;
	}

	public void setFacTctramo(BigDecimal facTctramo) {
		this.facTctramo = facTctramo;
	}

	public BigDecimal getFacLimiteinf() {
		return facLimiteinf;
	}

	public void setFacLimiteinf(BigDecimal facLimiteinf) {
		this.facLimiteinf = facLimiteinf;
	}

	public BigDecimal getFacLimitesup() {
		return facLimitesup;
	}

	public void setFacLimitesup(BigDecimal facLimitesup) {
		this.facLimitesup = facLimitesup;
	}

	public String getFacDocresol() {
		return facDocresol;
	}

	public void setFacDocresol(String facDocresol) {
		this.facDocresol = facDocresol;
	}

	public String getFacCodmon() {
		return facCodmon;
	}

	public void setFacCodmon(String facCodmon) {
		this.facCodmon = facCodmon;
	}

	public String getFacCtatramo() {
		return facCtatramo;
	}

	public void setFacCtatramo(String facCtatramo) {
		this.facCtatramo = facCtatramo;
	}

	public String getFacEstfactor() {
		return facEstfactor;
	}

	public void setFacEstfactor(String facEstfactor) {
		this.facEstfactor = facEstfactor;
	}

	public Date getFacAuditfho() {
		return facAuditfho;
	}

	public void setFacAuditfho(Date facAuditfho) {
		this.facAuditfho = facAuditfho;
	}

	public String getFacAuditusr() {
		return facAuditusr;
	}

	public void setFacAuditusr(String facAuditusr) {
		this.facAuditusr = facAuditusr;
	}

	public String getFacAuditwst() {
		return facAuditwst;
	}

	public void setFacAuditwst(String facAuditwst) {
		this.facAuditwst = facAuditwst;
	}
	public BigDecimal getFacPcomis() {
		return facPcomis;
	}
	public void setFacPcomis(BigDecimal facPcomis) {
		this.facPcomis = facPcomis;
	}
	
}
