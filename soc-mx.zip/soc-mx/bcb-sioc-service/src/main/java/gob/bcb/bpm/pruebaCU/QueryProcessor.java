/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * 
 *  * 22/06/2011 - 16:52:20
 * 
 */
package gob.bcb.bpm.pruebaCU;

import java.math.BigDecimal;
import java.io.File;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.core.jms.BcbResponseImpl;
import gob.bcb.core.jms.ResponseContext;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.persist.EntityUserTransactionSioc;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.commons.EmailDetalle;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.qnatives.coin.CalendarioComun;
import gob.bcb.service.servicioBolsin.BolsinService;
import gob.bcb.service.servicioSioc.MsgMailListener;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.job.SchedulerSioc;
import gob.bcb.service.servicioSioc.logic.ActualizarAFecha;
import gob.bcb.service.servicioSioc.logic.ProcesosSolicitud;
import gob.bcb.service.servicioSioc.logic.RegistrarSolicitud;
import gob.bcb.service.servicioSioc.logic.RevertirCompService;
import gob.bcb.service.servicioSioc.logic.SwiftSiocService;
import gob.bcb.service.servicioSioc.mail.MsgLogic;
import gob.bcb.service.servicioSioc.pojos.CuentaS;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

/**
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 * 
 * 
 * @author eibanez
 * 
 */
public class QueryProcessor extends EntityUserTransactionSioc {
	private static final Log log = LogFactory.getLog(QueryProcessor.class);
	private static final String ERROR = "-1";
	private String ESTACION;
	private String USUARIO;
	private static final Integer MONUS = 34;
	private static final Integer MONUSV = 35;
	private static final Integer MONBS = 69;

	private BigDecimal tcUS = BigDecimal.valueOf(0);
	private BigDecimal tcUSV = BigDecimal.valueOf(0);
	private BigDecimal tcBS = BigDecimal.valueOf(1);
	private FactoryDao factoryDao;
	private ResponseContext responseContext;

	public QueryProcessor() {
		setNameSessionFactory(Constants.PROP_ALIAS_SIOC);
		log.info("nuevo QueryProcessor ha sido creado. " + getNameSessionFactory());

		factoryDao = new FactoryDao();
		Map<String, Object> mapa = new HashMap<String, Object>();
		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		mapa.put("socSolicitudesDao", socSolicitudesDao);
		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		mapa.put("socDetallessolDao", socDetallessolDao);
		SocBenefsDao socBenefsDao = new SocBenefsDao();
		mapa.put("socBenefsDao", socBenefsDao);
		SocComprobanteDao socComprobanteDao = new SocComprobanteDao();
		mapa.put("socComprobanteDao", socComprobanteDao);
		SocRengscompDao socRengscompDao = new SocRengscompDao();
		mapa.put("socRengscompDao", socRengscompDao);
		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		mapa.put("socCuentassolDao", socCuentassolDao);
		SocOperacionesDao socOperacionesDao = new SocOperacionesDao();
		mapa.put("socOperacionesDao", socOperacionesDao);
		SocDetallesopeDao socDetallesopeDao = new SocDetallesopeDao();
		mapa.put("socDetallesopeDao", socDetallesopeDao);
		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		mapa.put("socOpecomiDao", socOpecomiDao);
		SocInstrumentoDao socInstrumentoDao = new SocInstrumentoDao();
		mapa.put("socInstrumentoDao", socInstrumentoDao);
		SocMensajesDao socMensajesDao = new SocMensajesDao();
		mapa.put("socMensajesDao", socMensajesDao);
		SocDatosmenDao socDatosmenDao = new SocDatosmenDao();
		mapa.put("socDatosmenDao", socDatosmenDao);
		SocBenefslocalDao socBenefslocalDao = new SocBenefslocalDao();
		mapa.put("socBenefslocalDao", socBenefslocalDao);
		SocBolsinDao socBolsinDao = new SocBolsinDao();
		mapa.put("socBolsinDao", socBolsinDao);
		SocCambioDao socCambioDao = new SocCambioDao();
		mapa.put("socCambioDao", socCambioDao);
		SocParticipanteDao socParticipanteDao = new SocParticipanteDao();
		mapa.put("socParticipanteDao", socParticipanteDao);
		SocFacturasDao socFacturasDao = new SocFacturasDao();
		mapa.put("socFacturasDao", socFacturasDao);
		SocBenefsregDao socBenefsregDao = new SocBenefsregDao();
		mapa.put("socBenefsregDao", socBenefsregDao);
		SocOrdenesPagoDao socOrdenesPagoDao = new SocOrdenesPagoDao();
		mapa.put("socOrdenesPagoDao", socOrdenesPagoDao);
		SocEstadisticaDao socEstadisticaDao = new SocEstadisticaDao();
		mapa.put("socEstadisticaDao", socEstadisticaDao);

		for (Iterator<?> i = mapa.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			HibernateDaoSupport hibernateDaoSupport = (HibernateDaoSupport) mapa.get(key);
			hibernateDaoSupport.setSessionFactory(getSessionFactory());
			hibernateDaoSupport.getHibernateTemplate().setAllowCreate(false);
		}
		factoryDao.setDaos(mapa);
	}

	public QueryProcessor(ResponseContext responseContext) {
		this();
		this.responseContext = responseContext;
	}

	/**
	 * @param factoryDao
	 *            the factoryDao to set
	 */
	private static final Object monitor = new Object();

	public Map<String, Object> procesar(Map<String, Object> parametros) throws Exception {
		ESTACION = (String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION);
		USUARIO = (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID);
		String statusCode = Constants.OPERACION_RECEIVED;
		String consent = null;

		// String respuesta = null;
		String codigo = null;
		String solCodigo = null;
		begin();
		tcUS = getTipoCambio(MONUS, new Date());
		tcUSV = getTipoCambio(MONUSV, new Date());

		String opcion = (String) parametros.get("opcion");
		String codTipoOperacion = (String) parametros.get(Constants.AUDIT_COD_TIPO_OPERACION);

		String sIOCWEB_TIPOPERACION = "";
		if (parametros.containsKey("SIOCWEB_TIPOPERACION")) {
			sIOCWEB_TIPOPERACION = (String) parametros.get("SIOCWEB_TIPOPERACION");
			UserSessionHolder.set("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		}

		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
		log.info("===>[" + getNameSessionFactory() + "] llamando a la tarea " + opcion + "[codTipoOperacion:" + codTipoOperacion + "]["
				+ sIOCWEB_TIPOPERACION + "]");

		String sIOCServiceId = (String) parametros.get("SIOCServiceId");

		if (sIOCServiceId != null && sIOCServiceId.equals("sioc")) {
			SiocCoinService siocCoinService = new SiocCoinService();
			mapaRespuesta = siocCoinService.executeTask(parametros);
			log.info("Devolviendo mapa: " + mapaRespuesta);
			// return mapaRespuesta;
		}
		if (opcion.equals("obtenerTC")) {
			mapaRespuesta.put("tc", tcUSV);
		}

		// /////////////// control de horario //////////////

		SocHorarioDao socHorarioDao = new SocHorarioDao();
		socHorarioDao.setSessionFactory(getSessionFactory());
		Date horarecep = new Date();
		boolean enHorario = socHorarioDao.operacionEstaEnHorario(opcion, horarecep, (String) UserSessionHolder.get(Constants.COD_IFA_REQUEST));

		if (!enHorario) {
			log.error("Tipo de Operacion " + opcion + ", FUERA DE HORARIO, hora recepcion: "
					+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
			throw new RuntimeException("Tipo de Operacion " + opcion + " FUERA DE HORARIO, hora recepcion: "
					+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME) + " "
					+ (String) UserSessionHolder.get(Constants.COD_IFA_REQUEST));
		}

		// **********************************//
		ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
		procesosSolicitud.setSessionFactory(getSessionFactory());

		RegistrarSolicitud registrarSolicitud = new RegistrarSolicitud();
		registrarSolicitud.setSessionFactory(getSessionFactory());
		
		RevertirCompService revertirCompService = new RevertirCompService();
		revertirCompService.setSessionFactory(getSessionFactory());
		
		SwiftSiocService swiftSiocService = new SwiftSiocService();
		swiftSiocService.setSessionFactory(getSessionFactory());
		
		SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
		socUsuariosolDao.setSessionFactory(getSessionFactory());

		SocBenefsregDao socBenefsregDao = new SocBenefsregDao();
		socBenefsregDao.setSessionFactory(getSessionFactory());
		
		if (parametros.containsKey(Constants.OBJ_NAME_SOLICITUDTO)) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);

			solicitudTO.setCodEstacionAudit((String) parametros.get(Constants.AUDIT_USER_ESTACION));
			solicitudTO.setCodUsuarioAudit((String) parametros.get(Constants.AUDIT_USER_SESSION_ID));
			solicitudTO.setCodPersonaAudit((String) parametros.get(Constants.COD_IFA_REQUEST));
			solicitudTO.setCodUsuarioCont((String) parametros.get(Constants.AUDIT_USER_DATABASE_ID));
			solicitudTO.setCodTipoOperacion(codTipoOperacion);
		}

		if (opcion.equalsIgnoreCase(Constants.MSG_PARAM_REG_SOLWS)) {
			Solicitud solicitudTO = new Solicitud();

			solicitudTO.setCodEstacionAudit((String) parametros.get(Constants.AUDIT_USER_ESTACION));
			solicitudTO.setCodUsuarioAudit((String) parametros.get(Constants.AUDIT_USER_SESSION_ID));
			solicitudTO.setCodPersonaAudit((String) parametros.get(Constants.COD_IFA_REQUEST));
			solicitudTO.setCodUsuarioCont((String) parametros.get(Constants.AUDIT_USER_DATABASE_ID));
			solicitudTO.setCodTipoOperacion(codTipoOperacion);

			mapaRespuesta = registrarSolicitud.procesarServicioSolicitudesWS(solicitudTO, parametros);

		} else if (opcion.equalsIgnoreCase("REG_SOLICITUD")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = registrarSolicitud.registrarSolicitud(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("REG_SOLICITUD_CC")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = registrarSolicitud.registrarSolicitudCarta(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);			

		} else if (opcion.equalsIgnoreCase("REG_CC_PAGOENMI")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = registrarSolicitud.registrarCartaPagoEnmienda(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("MOD_CARTACRED")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = registrarSolicitud.actualizarCartaSinEnmienda(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("ACT_A_FECHA")) {
			// modifica la solicitud si esta en estado P pendiente recrea el
			// detalle
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
			actualizarAFecha.setSessionFactory(getSessionFactory());			
			solicitudTO = actualizarAFecha.actualizarAFecha(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("ACT_A_FECHA_PRECON")) {
			// modifica la solicitud si esta en estado P pendiente recrea el
			// detalle
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
			actualizarAFecha.setSessionFactory(getSessionFactory());			
			solicitudTO = actualizarAFecha.actualizarAFechaPreContab(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("MOD_SOLICITUD")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.modificaSolicitud(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("ctrlcompros")) {
			// modifica la solicitud si esta en estado P pendiente recrea el
			// detalle
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.controlCompros(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("PREAUT")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.preAutorizar(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("ACT_FECHA_PREAUT")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.preAutorizarActFecha(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("PREAUTSOL")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.preAutorizarSolicitud(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("PREAUTOAUTO")) {
			// pre autoriza un proceso automatico
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.preAutorizarOperacionAutomatico(solicitudTO);
			mapaRespuesta.put("sgteoperacion", "NOTIFMEFP");			
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equals("PREAUTSWFT")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.preAutorizarSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equals("AUTSWFT")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.autorizarSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equals("AUTSOL")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.autorizar(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("APROSOL")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.autorizar(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("NOTIFMEFP")) {
			// autoriza la operacion y genera la operacion contable
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.notificarDebito(solicitudTO);

			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("RECHAZARSOL")) {
			// pre autoriza operaciones por el usuario
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.rechazar(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("ANULARSOL")) {
			// crea una nueva solicitud
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			procesosSolicitud.anular(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("REVOP")) {
			// crea una nueva solicitud
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			log.info("Inicio : revalidarOrdenDePago " + solicitudTO.getSolicitud().getSocCodigo());
			SocOrdenesPago socOrdenesPagoPar = solicitudTO.getSocOrdenesPagoLista().get(0);

			SocOrdenesPagoDao socOrdenesPagoDao = new SocOrdenesPagoDao();
			socOrdenesPagoDao.setSessionFactory(getSessionFactory());
			socOrdenesPagoDao.revalidarOP(socOrdenesPagoPar);
			
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("PREAUTSWFMEN")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.preAutorizarSwfMensaje(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("AUTSWIFT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.autorizarSwfMensaje(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("RECHSWIFT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.rechazarSwfMensaje(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("REG_BENEFEXT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
		
			solicitudTO = socBenefsregDao.registrarBeneficiario(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
			
		} else if (opcion.equalsIgnoreCase("AUT_BENEFEXT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			
			solicitudTO = socBenefsregDao.autorizarBenef(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);			

		} else if (opcion.equalsIgnoreCase("RCH_BENEFEXT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			
			solicitudTO = socBenefsregDao.rechazarRegBenef(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);			
		} else if (opcion.equalsIgnoreCase("UPD_CTABENEFEXT")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			
			solicitudTO = socBenefsregDao.actualizaCuentaBenef(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
		} else if (opcion.equalsIgnoreCase("autorizarswift")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.autorizarSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("anularswift")) {
			// graba el archivo generado
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			// solicitudTO = procesosSolicitud.anularSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase("autorizarswiftsinc")) {
			// actualiza la fecha de operacion
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = swiftSiocService.autorizarSwift(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

		} else if (opcion.equalsIgnoreCase(Constants.TIPO_OPERACION_RETIRO_AUTO)) {
			procesosSolicitud.procesarPendientesAuto(opcion);
		} else if (opcion.equalsIgnoreCase("reiniciarprocesos")) {
			SchedulerSioc.stopScheduler();
			SchedulerSioc.startScheduler();
			mapaRespuesta.put("respuesta", "ok");
			
		} else if (opcion.equals("SOL_AVISO_TRANS_DEL_EXT")) {
			
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = registrarSolicitud.registrarSolicitudAviso(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
		} else if (opcion.equals("REVERSA_CMPB_CREAR")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = revertirCompService.generaReversa(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
		} else if (opcion.equals("REVERSA_CMPB_AUTO")) {
			Solicitud solicitudTO = (Solicitud) parametros.get(Constants.OBJ_NAME_SOLICITUDTO);
			solicitudTO = procesosSolicitud.autorizarOperacionRvs(solicitudTO);
			mapaRespuesta.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);			
		}

		/*********************************************************/
		/*********************************************************/
		/*********************************************************/
		/*********************************************************/
		SocBolsinDao bolsinDao = new SocBolsinDao();
		bolsinDao.setSessionFactory(getSessionFactory());
		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(getSessionFactory());
		
		if (opcion.equals("comisiones")) {
			// recupernado parametros enviadas por la capa web
			codigo = (String) parametros.get("codOperacion");

			List<SocOpecomi> lista = new ArrayList<SocOpecomi>();
			List<Opecomi> lista1 = new ArrayList<Opecomi>();

			// obteniendo dao de FactoryDao
//			SocOpecomiDao socOpecomiDao = (SocOpecomiDao) factoryDao.getDao("socOpecomiDao");

			log.info("Solicitando lista de opeComi");
			lista = socOpecomiDao.getComis(codigo);

			BigDecimal total = BigDecimal.valueOf(0);
			BigDecimal totalU = BigDecimal.valueOf(0);
			BigDecimal montoU = BigDecimal.valueOf(0);
			for (SocOpecomi comi : lista) {
				total = total.add(comi.getOcoMonto());
				Opecomi opeComi = new Opecomi();
				OpecomiId id = new OpecomiId(Integer.valueOf(comi.getId().getClaComision()), comi.getId().getOpeCodigo(), comi.getId().getDetCodigo());
				opeComi.setId(id);
				opeComi.setOcoMonto(comi.getOcoMonto());
				montoU = comi.getOcoMonto().divide(tcUS, 2, RoundingMode.HALF_UP);
				totalU = totalU.add(montoU);
				opeComi.setOcoMontoU(montoU);
				String descripcion = "";
				switch (Integer.valueOf(comi.getId().getClaComision())) {
				case 1:
					descripcion = "TRANSFERENCIA AL EXTERIOR";
					break;
				case 2:
					descripcion = "GASTOS DE COMUNICACION";
					break;
				case 3:
					descripcion = "UTILES DE ESCRITORIO";
					break;
				case 4:
					descripcion = "VENTA DE DIVISAS";
					break;
				case 5:
					descripcion = "TRANSFERENCIA DEL EXTERIOR";
					break;
				case 6:
					descripcion = "EMISION DE CARTAS DE CREDITO";
					break;
				case 7:
					descripcion = "OTRAS COMISIONES";
					break;
				default:
					descripcion = "";
					break;
				}
				opeComi.setDescripcion(descripcion);
				opeComi.setEstilo("");
				lista1.add(opeComi);
			}
			mapaRespuesta.put("lista", lista1);
			mapaRespuesta.put("total", total);
			mapaRespuesta.put("totalU", totalU);
		}

		if (opcion.equals("nuevaBolsin")) {
			// ingreso de una nueva solicitud
			log.info("ingreso de una nueva solicitud bolsin.");

			SocBolsin solicitudB = (SocBolsin) parametros.get("solicitud");

			// registrando en la bbdd los datos capturados desde el formulario
//			SocBolsinDao bolsinDao = (SocBolsinDao) factoryDao.getDao("socBolsinDao");

			SocBolsin solicitudNew = bolsinDao.nuevoBolsin(solicitudB);

			log.info("Solicitud bolsin guardada: " + solicitudNew.getCorr() + " " + solicitudNew.getSocCodigo());

			mapaRespuesta.put("codSolicitud", solicitudNew.getSocCodigo());
		}

		if (opcion.equals("autBolsin")) {
			// ingreso de una nueva solicitud
			SocBolsin solicitudB0 = (SocBolsin) parametros.get("solicitud");
			log.info("Inicio proceso autBolsin " + opcion + " " + solicitudB0.getSocCodigo());
			// vd0

//			SocBolsinDao bolsinDao = (SocBolsinDao) factoryDao.getDao("socBolsinDao");
			SocBolsin solicitudB = bolsinDao.getBySocCodigo(solicitudB0.getSocCodigo());

			if (!solicitudB.getClaEstado().equals('9') && !solicitudB.getClaEstado().equals('B')) {
				log.error("Solicitud en estado incorrecto posiblemente ya fue procesada");
				throw new RuntimeException("Solicitud en estado incorrecto posiblemente ya fue procesada");
			}

			if (solicitudB.getClaTipsolic().trim().equals("GD") || solicitudB.getClaTipsolic().trim().equals("ED")) {
				// actualizamos el monto adjudicado si es de venta directa
				solicitudB.setMontoAdj(solicitudB.getMontoSol());
			}

			solicitudB.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));
			solicitudB.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
			solicitudB.setFecha(new Date());
			log.info("XXX: solicitudB.getEstacion " + solicitudB.getEstacion());

			synchronized (monitor) {
				bolsinDao.saveOrUpdate(solicitudB);

				bolsinDao.validar(solicitudB);

				if (solicitudB.getClaTipsolic().trim().equals("G") || solicitudB.getClaTipsolic().trim().equals("E")) {
					enHorario = socHorarioDao.operacionEstaEnHorario(sIOCWEB_TIPOPERACION, horarecep,
							(String) UserSessionHolder.get(Constants.COD_IFA_REQUEST));

					if (!enHorario) {
						throw new RuntimeException("Tipo de Operacion " + sIOCWEB_TIPOPERACION + ", fuera de horario "
								+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
					}
				}

				Map<String, Object> mapaParametros = bolsinDao.provisionBolsin(factoryDao, solicitudB);

				flush();
				boolean continuar = mapaParametros.containsKey("comp");
				if (continuar) {
					// ########## proceso contable ##########
					SiocCoinService siocCoinService = new SiocCoinService();

					// agregamos el parametro para autorizacion de comprobante:
					// provision
					mapaParametros.put("consulta", "crear");

					Map<String, Object> mapaResultado = siocCoinService.executeTask(mapaParametros);
					SocComprobante comprobante0 = (SocComprobante) mapaParametros.get("comp");
					log.info("XXX: comprobante1comprobante0 " + comprobante0.getCpbNrocpbte());

					SocComprobante comprobante1 = (SocComprobante) mapaResultado.get("socComprobante");
					log.info("XXX: comprobante1comprobante1 " + comprobante1.getCpbNrocpbte());
					String nroComprob = (String) mapaResultado.get("comp");

					if (!nroComprob.equals("") && !nroComprob.equals("0000000")) {
						if (!nroComprob.equals("9999999")) {
							log.info("Comprobante coin creado: " + nroComprob);
						} else {
							log.info("Existe sobregiro en cuentas");
							throw new RuntimeException("Existe sobregiro en cuentas");
							// continuar = false;
						}
					} else {
						log.info("Error al crear comprobante coin");
						continuar = false;
					}

					if (continuar) {
						// cambiamos el estado a autorizado
						solicitudB.setClaEstado('0');
						// whf vd2
						solicitudB.setFechaHora(new Date());
						bolsinDao.saveOrUpdate(solicitudB);
						log.info("Solicitud bolsin guardada: " + solicitudB);
						mapaRespuesta.put("estado", "0");
					} else {
						mapaRespuesta.put("estado", ERROR);
					}
				}

				if (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("ED") || solicitudB.getClaTipsolic().trim().equalsIgnoreCase("GD")) {
					// si es una operacion de venta de divisas DIRECTA, se
					// procede a
					// autorizar directamente
					Map<String, Object> mapaResultado = bolsinDao.entregaBolsin(factoryDao, solicitudB, tcUS, tcUSV, tcUSV, 0);

					flush();
					log.info("commiteado sioc ");
					// agregamos el parametro para autorizacion de comprobante:
					// adjudicacion
					mapaResultado.put("consulta", "crear");

					log.info("Llamando al servicio de coin: crear comprobante");

					SiocCoinService siocCoinService = new SiocCoinService();
					Map<String, Object> mapaResultado2 = siocCoinService.executeTask(mapaResultado);

					String nroComprob = (String) mapaResultado2.get("comp");
					if (nroComprob != null && !nroComprob.equals("") && !nroComprob.equals("0000000")) {
						if (!nroComprob.equals("9999999")) {
							log.info("Comprobante coin creado: " + nroComprob);
							// cambiamos el estado a adjudicado
							solicitudB.setClaEstado('5');
							bolsinDao.saveOrUpdate(solicitudB);
							// devolvemos el estado 0 cmo exitoso
							mapaRespuesta.put("estado", "0");
						} else {
							log.info("Existe sobregiro en cuentas");
							mapaRespuesta.put("estado", ERROR);
						}
					} else {
						log.info("Error al crear Comprobante coin");
						mapaRespuesta.put("estado", ERROR);
					}
				}
				SiocCoinService.commit();
				commit();
				begin();
			}
			// begin();
			if (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("GD") || solicitudB.getClaTipsolic().trim().equalsIgnoreCase("ED")) {
				if (solicitudB.getClaEstado() != null && solicitudB.getClaEstado().equals('5')) {

					SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
					socSolicitanteDao.setSessionFactory(getSessionFactory());

					SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitudB.getSolCodigo());
					SocSolicitante socSolicitanteBenef = null;

					if (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("GD")) {
						socSolicitanteBenef = socSolicitanteDao.solicitanteByCod(solicitudB.getBenef());
					} else {
						socSolicitanteBenef = socSolicitanteDao.solicitanteByCod(solicitudB.getSolCodigo());
					}

					String subject = "Operaciones Cambiarias: Autorizacion de Venta Directa de Divisas";
					String content = MsgLogic.mensajeSolicitudBolsin(solicitudB, socSolicitante, socSolicitanteBenef, subject);

					socUsuariosolDao.formarMail("SOLVENTADIRECTA", subject, content, "'900','" + solicitudB.getSolCodigo() + "'");

				}

			}
		}

		if (opcion.equals("anularBolsin")) {
			// Anular Solicitud
			log.info("Anular Solicitud Bolsin.");

			SocBolsin solicitudB0 = (SocBolsin) parametros.get("solicitud");

			// cambiando la solicitud en estado de anulado "A"
//			SocBolsinDao bolsinDao = (SocBolsinDao) factoryDao.getDao("socBolsinDao");
			SocBolsin solicitudB = bolsinDao.getBySocCodigo(solicitudB0.getSocCodigo());

			if (!solicitudB.getClaEstado().equals('9') && !solicitudB.getClaEstado().equals('B')) {
				log.error("La Solicitud " + solicitudB.getCorr() + " se encuentra en estado procesado. No puede anular.");
				throw new RuntimeException("La Solicitud " + solicitudB.getCorr() + " se encuentra en estado procesado. No puede anular.");
			}

			solicitudB.setClaEstado('Z');
			bolsinDao.saveOrUpdate(solicitudB);

			mapaRespuesta.put("estado", "Z");
		}

		if (opcion.equals("subasta")) {
			List<SocBolsin> listaBolsin = (List<SocBolsin>) parametros.get("solicitudes");
			BigDecimal base = (BigDecimal) parametros.get("base");

			if (base == null || base.compareTo(BigDecimal.ZERO) <= 0) {
				log.error("Tipo de cambio base incorrecto revise datos");
				throw new RuntimeException("Tipo de cambio base incorrecto revise datos");
			}
			listaBolsin = gob.bcb.bpm.pruebaCU.Servicios.getSocBolsinList("'0'", null, null, "'E','G'");
			if (listaBolsin == null || listaBolsin.size() == 0) {
				log.error("Subasta sin solicitudes posiblemente ya fueron procesadas o intente nuevamente");
				// throw new
				// RuntimeException("Subasta sin solicitudes posiblemente ya fueron procesadas o intente nuevamente");
			}
			char estado = procesarSubasta(base);
			flush();
			log.info("Estado actualizado: " + estado);
			if (estado == 'Z') {
				mapaRespuesta.put("estado", "-1");
			} else {
				mapaRespuesta.put("estado", "1");
			}
		}

		if (opcion.equals("sinSubasta")) {
			BigDecimal base = (BigDecimal) parametros.get("base");

			if (base == null || base.compareTo(BigDecimal.ZERO) <= 0) {
				log.error("Tipo de cambio base incorrecto revise datos");
				throw new RuntimeException("Tipo de cambio base incorrecto revise datos");
			}

			// char estado = sinSubasta(base);
			char estado = procesarSubasta(base);
			String respEstado = String.valueOf(estado);
			flush();
			log.info("Estado actualizado: " + respEstado);
			mapaRespuesta.put("estado", respEstado);
		}

		if (opcion.equals("publicar")) {
			Date fecha = (Date) parametros.get("fecha");

			SocCambioDao socCambioDao = new SocCambioDao();
			socCambioDao.setSessionFactory(getSessionFactory());

			SocCambio socCambio = socCambioDao.getCambio(fecha);
			if (socCambio == null) {
				throw new BusinessException("No existe registrado tipo de cambio, posiblemente no se efectuo la tarea de subasta "
						+ UtilsDate.stringFromDate(fecha, "dd/MM/yyyy"));
			}
			if (!socCambio.getClaEstado().equals("1")) {
				throw new BusinessException("Estado de subasta incorrecto, posiblemente ");
			}

			BolsinService bolsinService = new BolsinService();
			mapaRespuesta.put("estado", ERROR);
			bolsinService.doPublicar(fecha);
			flush();
			mapaRespuesta.put("estado", "P");
		}

		if (opcion.equals("revisaVDAuto")) {
			// Revision de solicituddes de Venta directa
			SocBolsinDao socBolsinDao = new SocBolsinDao();
			socBolsinDao.setSessionFactory(getSessionFactory());
			socBolsinDao.revisaPendientesVentadirecta();
		}

		if (opcion.equals("adjudicacion")) {
			// se verifica que la fecha actual es habil o no
			BolsinService bolsinService = new BolsinService();
			BolsinService.setSessionFactory(getSessionFactory());
			String tipoEjecucion = (String) parametros.get("tipoejecucion");
			// se verifica si la ejecucion es automativa o no
			boolean esAutomatica = (tipoEjecucion != null) && tipoEjecucion.contains(tipoEjecucion) && tipoEjecucion.equalsIgnoreCase("automatica");

			Map<String, String> msgRepuesta = bolsinService.adjudicar(factoryDao, esAutomatica);

			flush();
			// si es automatica se envia correo a los interesados
			if (esAutomatica) {
				String subject = "Adjudicacion automatica de fecha: " + UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy");
				String content = MsgLogic.mensajeAdjudicacionAuto(msgRepuesta);

				socUsuariosolDao.formarMail("ADJUDICACIONAUTO", subject, content, "'900'");
			}
			mapaRespuesta.put("resp_codmsg", "0");
			mapaRespuesta.put("resp_descripmsg", "Proceso de adjudicacion finalizada. " + ArrayUtils.toString(msgRepuesta));
		}

		SiocCoinService.flush();
		flush();

		log.info("=======ANTES DEL COMMIT(coin)=========");
		SiocCoinService.commit();
		log.info("=======DESPUES DEL COMMIT(coin)=========");

		log.info("=======ANTES DEL COMMIT(sioc)=========");
		commit();
		log.info("=======DESPUES DEL COMMIT(sioc)=========");
		List<EmailDetalle> emailDetalleList = (List<EmailDetalle>) UserSessionHolder.get("emailsaenviar");
		if (emailDetalleList != null) {
			log.info("Mails a enviar: " + emailDetalleList.size());			
			for (EmailDetalle emailDetalle : emailDetalleList) {
				log.info(emailDetalle.getSubject());
				MsgMailListener.enviar(emailDetalle);
			}
			// se setea a nulo para no enviar nuevamente 
			emailDetalleList.clear();
		}

		log.info("YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
		log.info("YYYYYYYYYY[" + opcion + "]YYYYYYYYYYYYYY");
		log.info("YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY");
		log.info("User:" + parametros.get(Constants.AUDIT_USER_SESSION_ID) + " Est: " + parametros.get(Constants.AUDIT_USER_ESTACION));
		
		if (!parametros.containsKey("sendtojms")) {
			statusCode = Constants.OPERACION_SUCCESS;
			consent = "Consulta u operación finalizada";
			// respuesta temporal hasta mejora de mensajes
			responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().setCodestadoresp(Constants.OPERACION_SUCCESS);
			responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().setDescripcion(consent);

			MessageObjectBean messageObjectBean1 = new MessageObjectBean();
			messageObjectBean1.setTransformedMessage(mapaRespuesta);

			BcbResponseImpl bcbResponseImpl = (BcbResponseImpl) responseContext.getBcbResponse();
			bcbResponseImpl.setBody(messageObjectBean1);

			try {
				//String logcitorep = (mapaRespuesta != null ? mapaRespuesta.toString() : "");
				log.info("===>[OPCION: " + opcion + "] culminada y respuesta enviada al origen::: ");
				bcbResponseImpl.sendResponseBcbMsg(statusCode, consent);

			} catch (Exception e) {
				log.error("Error al enviar respuesta: " + e.getMessage(), e);
				responseContext.getBcbResponse().getMsgBcbresp().getMsgsistemaresp().setCodestadoresp(Constants.RUNTIME_EXCEPTION);
				throw new RuntimeException("ERROR_AL_ACTUALIZAR_RESPUESTA " + e.getMessage());
			}
		}
		if (opcion.equals(Constants.MSG_PARAM_REG_SOLWS) || opcion.equals("PREAUTOAUTO")) {
			// si es de la Serv web
			// se hizo la provision de fondos
			if (mapaRespuesta.containsKey(Constants.OBJ_NAME_SOLICITUDTO) && mapaRespuesta.containsKey("sgteoperacion")) {
				log.info("YYYYYYYYYY[OPCION INTERM: " + opcion + "]YYYYYYYYYYYYYY");
				
				Solicitud solicitudTO = (Solicitud) mapaRespuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
				String tipooperacion = (String) mapaRespuesta.get("sgteoperacion");

				log.info(solicitudTO.getSolicitud().getSocCodigo() + " :::> sgteoperacion " + tipooperacion + " " + solicitudTO.getSolicitud().getClaEstado() + " "
						+ solicitudTO.getSolicitud().getFechaReg());

				parametros.put("opcion", tipooperacion);
				parametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
				parametros.put(Constants.AUDIT_COD_TIPO_OPERACION, tipooperacion);
				parametros.put(Constants.COD_IFA_REQUEST, Constants.COD_IFA_MEFP);
				parametros.put("sendtojms", "NO");
				procesar(parametros);
			}
		}

		return mapaRespuesta;
	}

	public static BigDecimal getTipoCambio(Integer mon, Date fecha) {
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("consulta", "tc");
		mapaParametros.put("fecha", fecha);
		mapaParametros.put("moneda", mon);

		BigDecimal tipo = BigDecimal.valueOf(0.00);

		// log.info("Llamando al servicio de coin: factor_conv_mn");
		Map<String, Object> mapaResultado;
		SiocCoinService siocCoinService = new SiocCoinService();
		mapaResultado = siocCoinService.executeTask(mapaParametros);
		tipo = (BigDecimal) mapaResultado.get("tc");
		
		return tipo;
	}

	public static BigDecimal getTipoCambio(String mon, Date fecha) {
		return getTipoCambio(Integer.valueOf(mon), fecha);
	}

	private char sinSubasta(BigDecimal tcBase) {
		char estado = '0';
		Date fecha = new Date();
		SocCambioDao socCambioDao = (SocCambioDao) factoryDao.getDao("socCambioDao");
		SocCambio socCambio = socCambioDao.getCambio(fecha);
		SocCambio cambio = new SocCambio();
		if (socCambio != null) {
			if (!StringUtils.isBlank(socCambio.getClaEstado()) && (socCambio.getClaEstado().equals("1") || socCambio.getClaEstado().equals("5"))) {
				throw new RuntimeException("Proceso de subasta con estado incorrecto posiblemente ya fue procesado");
			}
			cambio = socCambio;
		}

		Double diff_cv = Double.valueOf(Servicios.getParam("@diffcv"));
		Double cantidad_dis = Double.valueOf(Servicios.getParam("@disponible"));

		cambio.setFecha(fecha);
		cambio.setVenta(tcBase);
		cambio.setCompra(tcBase.subtract(BigDecimal.valueOf(diff_cv)));
		cambio.setBase(tcBase);
		cambio.setVend(BigDecimal.valueOf(0.00));
		cambio.setDisp(BigDecimal.valueOf(cantidad_dis));
		cambio.setPres(0);
		cambio.setAcep(0);
		cambio.setClaEstado("1");
		cambio.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));
		cambio.setFechaHora(fecha);
		cambio.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

		socCambioDao.saveOrUpdate(cambio);
		estado = '1';
		log.info("Subasta Procesada sin solicitudes ");

		return estado;
	}

	private char procesarSubasta(BigDecimal tcBase) {
		char estado = '0';
		// Date ldt_fech_hor;
		Date fecha = new Date();
		char lst_estado;
		String lst_cod_per, lst_fin;
		Integer llo_regacep = 0;
		// Boolean lbo_sn;
		BigDecimal lde_cantidads, lde_cantidadsi, lde_cantidad_dis, lde_cantidad_rech, lde_tipo, lde_cantidad_ven, lde_cantidad_tven = BigDecimal
				.valueOf(0), lde_saldo_cc = BigDecimal.valueOf(0), lde_montobs, lde_por, min_cambio, cotz_venta = BigDecimal.valueOf(0), cotz_compra;
		BigDecimal lde_cantidad_tip = BigDecimal.valueOf(0);

		SocParticipanteDao socPartDao = (SocParticipanteDao) factoryDao.getDao("socParticipanteDao");
		// vd0
		SocBolsinDao socBolsinDao = (SocBolsinDao) factoryDao.getDao("socBolsinDao");

		SocCambioDao socCambioDao = (SocCambioDao) factoryDao.getDao("socCambioDao");
		SocCambio socCambio = socCambioDao.getCambio(fecha);
		SocCambio cambio = new SocCambio();
		if (socCambio != null) {
			if (!StringUtils.isBlank(socCambio.getClaEstado()) && (socCambio.getClaEstado().equals("1") || socCambio.getClaEstado().equals("5"))) {
				throw new RuntimeException("Proceso de subasta con estado incorrecto posiblemente ya fue procesada");
			}
			cambio = socCambio;
		}
		List<SocBolsin> solics0 = socBolsinDao.getByEstadoFecha(fecha, "'1','2','3','5'", "'G','E'");
		if (solics0.size() > 0) {
			throw new RuntimeException("Inconsistencia!! ya existen solicitudes con estado procesado para la fecha, verifique los datos.");
		}
		// ojoooo se recupera solo registros de bolsin
		List<SocBolsin> solics = socBolsinDao.getByEstadoFecha(fecha, "'0'", "'G','E'");

		if (solics.size() == 0) {
			return sinSubasta(tcBase);
		}

		List<SocParticipante> parts = socPartDao.getParticipantes();
		for (SocParticipante part : parts) {
			part.setSaldo(BigDecimal.valueOf(1000000000));
			part.setSaldop(BigDecimal.valueOf(0));
			socPartDao.saveOrUpdate(part);
		}

		Double cantidad_dis = Double.valueOf(Servicios.getParam("@disponible"));
		lde_cantidad_dis = BigDecimal.valueOf(cantidad_dis);

		// seleccionamos las cotizaciones propuestaas para la compra y lo
		// ordenamos en mayor a menor
		String query = "select distinct cotiz ";
		query = query.concat("from soc_bolsin ");
		query = query.concat("where cla_estado = '0' ");
		query = query.concat("and sol_codigo <> '237' ");
		query = query.concat("and cla_tipsolic in ('G','E') ");
		query = query.concat("order by cotiz desc ");

		List<SocBolsin> socBolsinList0 = new ArrayList<SocBolsin>();

		List<Map<String, Object>> resultadoT = Servicios.ejecutarQuery(query, "cotiz".split(","));
		if (resultadoT.size() > 0) {
			for (Map<String, Object> res : resultadoT) {
				lde_tipo = (BigDecimal) res.get("cotiz");

				// sumamos los montos solicitados en USD de las solicitudes que
				// ingresaron el tipo de cambio
				query = "select sum(montosol) as monto ";
				query = query.concat("from soc_bolsin ");
				query = query.concat("where cla_estado = '0' ");
				query = query.concat("and sol_codigo <> '237' ");
				query = query.concat("and cla_tipsolic in ('G','E') ");
				query = query.concat("and cotiz = " + lde_tipo + " ");

				List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "monto".split(","));
				if (resultado.size() == 1) {
					for (Map<String, Object> res1 : resultado) {
						lde_cantidad_tip = (BigDecimal) res1.get("monto");
					}
				}

				lst_fin = "N";
// control para no ciclar infinito corregir el proceso (legado)
				int limiteCiclos = 100;
				int contCiclos = 0;
				do {
					lde_cantidad_ven = BigDecimal.valueOf(0);
					lde_cantidad_rech = BigDecimal.valueOf(0);
					// /****************
					lde_saldo_cc = BigDecimal.valueOf(0);
					// ****************
					for (SocBolsin solic : solics) {
						lst_cod_per = solic.getSolCodigo();
						lde_cantidads = solic.getMontoSol();
						lde_cantidadsi = lde_cantidads;

						if (!lst_cod_per.equals("237") && lde_tipo.compareTo(solic.getCotiz()) == 0) {
							if (lde_tipo.compareTo(tcBase) >= 0) {
								SocParticipante part = (SocParticipante) socPartDao.getParticipante(lst_cod_per);

								lde_saldo_cc = BigDecimal.valueOf(1000000000);
								part.setSaldo(lde_saldo_cc);
								part.setClaEstado("2");
								socPartDao.saveOrUpdate(part);

								lde_saldo_cc = part.getSaldo().subtract(part.getSaldop());

								if (lde_cantidad_tip.compareTo(lde_cantidad_dis) >= 0) {
									lde_por = lde_cantidads.divide(lde_cantidad_tip, 30, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100));
									lde_cantidads = lde_cantidad_dis.multiply(lde_por).divide(BigDecimal.valueOf(100));
									lst_estado = '2';
								} else {
									lst_estado = '1';
								}

								lde_montobs = lde_cantidads.multiply(lde_tipo);

								if (lde_saldo_cc.compareTo(lde_montobs) >= 0) {
									lde_cantidad_ven = lde_cantidad_ven.add(lde_cantidads);

									solic.setClaEstado(lst_estado);
									solic.setMontoAdj(lde_cantidads);
									solic.setSeq(1);

									part.setSaldop(part.getSaldop().add(lde_montobs));
									socPartDao.saveOrUpdate(part);
								} else {
									lde_cantidad_rech = lde_cantidad_rech.add(lde_cantidadsi);
									solic.setClaEstado('4');
									solic.setMontoAdj(BigDecimal.valueOf(0));
								}
							} else {
								solic.setClaEstado('3');
								solic.setMontoAdj(BigDecimal.valueOf(0));
							}
						} else {
							if (lde_tipo.compareTo(solic.getCotiz()) == 0 && solic.getSolCodigo().equals("237")) {
								if (lde_tipo.compareTo(tcBase) >= 0) {
									lde_cantidads = solic.getMontoSol();
									solic.setClaEstado('1');
									solic.setMontoAdj(lde_cantidads);

									lde_cantidad_tven = lde_cantidad_tven.add(lde_cantidads);
								} else {
									solic.setClaEstado('3');
									solic.setMontoAdj(BigDecimal.valueOf(0));
								}
							}
						}

						socBolsinDao.saveOrUpdate(solic);
						socBolsinList0.add(solic);
					}

					if (lde_cantidad_rech.compareTo(BigDecimal.valueOf(0)) == 0) {
						lde_cantidad_dis = lde_cantidad_dis.subtract(lde_cantidad_ven);
						lde_cantidad_tven = lde_cantidad_tven.add(lde_cantidad_ven);
						lst_fin = "S";
					} else {
						for (SocParticipante part : parts) {
							part.setSaldo(BigDecimal.valueOf(0));
							part.setSaldop(BigDecimal.valueOf(0));
							socPartDao.saveOrUpdate(part);
						}
						lde_cantidad_tip = lde_cantidad_tip.subtract(lde_cantidad_rech);
					}

					contCiclos++;
				} while (lst_fin.equals("N") && contCiclos <= limiteCiclos);
				if (contCiclos == limiteCiclos) {
					// whf 20220222 pensar en corregir si hubiera este error
					log.warn("ERROR IMPREVISTO!! Error en subasta, proceso ciclado, avise al administrador.");					
					//throw new RuntimeException("Error imprevisto!! Error en subasta, proceso ciclado, avise al administrador.");
				}
			}
		}

		query = "select count(*) as acep ";
		query = query.concat("from soc_bolsin ");
		query = query.concat("where montoadj > 0 ");
		query = query.concat("and cla_estado in ('1', '2')  ");
		query = query.concat("and cla_tipsolic in ('G','E') ");

		List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query, "acep".split(","));
		if (resultado2.size() == 1) {
			for (Map<String, Object> res : resultado2) {
				BigDecimal aa = (BigDecimal) res.get("acep");
				String aas = aa.toString();
				llo_regacep = Integer.valueOf(aas);
			}
		}

		// 1. Verifica si la venta se llego a agotar
		min_cambio = BigDecimal.valueOf(0);
		if (lde_cantidad_tven.compareTo(BigDecimal.valueOf(cantidad_dis)) == 0) {
			query = "select min(cotiz) as min ";
			query = query.concat("from soc_bolsin ");
			query = query.concat("where montoadj > 0 ");
			query = query.concat("and cla_estado in ('1', '2')  ");
			query = query.concat("and cla_tipsolic in ('G','E') ");

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "min".split(","));
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					min_cambio = (BigDecimal) res.get("min");
				}
			}
		}
		cotz_compra = BigDecimal.valueOf(0);
		Double diff_cv = Double.valueOf(Servicios.getParam("@diffcv"));
		// 2. VErificar si la cotz_propuesta > de la venta
		if (min_cambio.compareTo(BigDecimal.valueOf(0)) > 0 && min_cambio.compareTo(cotz_venta) > 0) {
			cotz_compra = min_cambio.subtract(BigDecimal.valueOf(diff_cv));
		}
		// 3. Establecer como nueva cotizacion

		cambio.setFecha(fecha);
		cambio.setVend(lde_cantidad_tven);
		cambio.setDisp(BigDecimal.valueOf(cantidad_dis));
		cambio.setPres(solics.size());
		cambio.setAcep(llo_regacep);
		cambio.setBase(tcBase);		
		cambio.setClaEstado("1");
		cambio.setUsrCodigo(USUARIO);
		cambio.setFechaHora(new Date());
		cambio.setEstacion(ESTACION);
		
		if (cotz_compra.compareTo(BigDecimal.valueOf(0)) > 0) {
			cambio.setVenta(min_cambio);
			cambio.setCompra(cotz_compra);
		} else {
			cambio.setVenta(tcBase);
			cambio.setCompra(tcBase.subtract(BigDecimal.valueOf(diff_cv)));
		}

		int ii = 0;
		BigDecimal total0 = BigDecimal.valueOf(0);
		for (SocBolsin solic : socBolsinList0) {
			ii++;
			String afecB = "";
			Boolean continuar = true;
			if (solic.getMontoSol().compareTo(solic.getMontoAdj()) > 0) {
				BigDecimal montoDev = solic.getMontoSol().subtract(solic.getMontoAdj()).multiply(solic.getCotiz());
				String codComprobante1 = null;
				DateTime hoy2 = new DateTime();
				Date hoy1 = new Date();
				String gg = "";
				if (solic.getMontoAdj().compareTo(BigDecimal.valueOf(0.00)) == 0)
					gg = "DEVOLUCION DE PROVISION DE FONDOS POR NO ADJUDICACION DE DIVISAS EN LA SESION DEL BOLSIN DE LA FECHA";
				else
					gg = "DEVOLUCION DE PROVISION DE FONDOS POR ADJUDICACION PARCIAL DE DIVISAS EN LA SESION DEL BOLSIN DE LA FECHA";
				codComprobante1 = Long.toString(hoy1.getTime());
				SocComprobante comprobante1 = new SocComprobante(codComprobante1, solic.getSocCodigo(), hoy2.getYear(), hoy2.getMonthOfYear(),
						hoy2.getDayOfMonth(), tcUS, gg);

				SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
				comprobanteDao.saveOrUpdate(comprobante1);
				log.info("Comprobante guardado: ");

				query = "SELECT cta_afectable " + "FROM soc_cuentassol WHERE cta_codigo = " + solic.getCuentaD();

				String afec = "";
				List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_afectable".split(","));
				if (resultado.size() == 1) {
					for (Map<String, Object> res : resultado) {
						afec = (String) res.get("cta_afectable");
					}
				}

				query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_b' " + "AND val_codigo = trim('"
						+ solic.getSolCodigo() + "')";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "val_nombre".split(","));
				if (resultado1.size() == 1) {
					for (Map<String, Object> res : resultado1) {
						afecB = (String) res.get("val_nombre");
					}
				}
				String mayorctaafect_b = "000108";
				SocRengscomp renglon1 = new SocRengscomp(new SocRengscompId(codComprobante1, 1), MONBS, 'D', tcBS, montoDev, montoDev,
						mayorctaafect_b, afecB);
				SocRengscomp renglon2 = new SocRengscomp(new SocRengscompId(codComprobante1, 2), MONBS, 'H', tcBS, montoDev, montoDev, "000110", afec);
				SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
				rengsCompDao.saveOrUpdate(renglon1);
				rengsCompDao.saveOrUpdate(renglon2);
				log.info("Renglones guardado: ");

				List<SocRengscomp> rengs = new ArrayList<SocRengscomp>();
				rengs.add(renglon1);
				rengs.add(renglon2);
				flush();
				Map<String, Object> mapaParametros2 = new HashMap<String, Object>();
				mapaParametros2.put("consulta", "crear");
				mapaParametros2.put("comp", comprobante1);
				mapaParametros2.put("rengs", rengs);

				log.info("Llamando al servicio de coin: crear comprobante");
				Map<String, Object> mapaResultado2;

				SiocCoinService siocCoinService = new SiocCoinService();
				mapaResultado2 = siocCoinService.executeTask(mapaParametros2);

				String nroComprob = (String) mapaResultado2.get("comp");
				if (!nroComprob.equals("") && !nroComprob.equals("0000000")) {
					if (!nroComprob.equals("9999999")) {
						log.info("Comprobante coin creado: " + nroComprob);
					} else {
						log.info("Existe sobregiro en cuentas");
						continuar = false;
						estado = 'Z';
					}
				} else {
					log.info("Error al crear comprobante coin");
					continuar = false;
					estado = 'Z';
				}
			}
			if (continuar) {
				if (solic.getMontoAdj().compareTo(BigDecimal.valueOf(0)) > 0) {
					String codComprobante1 = null;
					DateTime hoy2 = new DateTime();
					Date hoy1 = new Date();
					// whf
					CalendarioComun calendarioComun = new CalendarioComun();
					calendarioComun.setSessionFactory(SiocCoinService.getSessionFactory());

					Date fechaHabil = calendarioComun.fecHabilAntesDespuesDe(hoy1, 1);
					DateTime fechaHabil1 = new DateTime(fechaHabil);

					codComprobante1 = Long.toString(hoy1.getTime());
					SocComprobante comprobante1 = new SocComprobante(codComprobante1, solic.getSocCodigo(), fechaHabil1.getYear(),
							fechaHabil1.getMonthOfYear(), fechaHabil1.getDayOfMonth(), cambio.getCompra(),
							"ENTREGA DE DIVISAS ADJUDICADAS EN SESION DEL BOLSIN DE FECHA " + hoy2.getDayOfMonth() + "/" + hoy2.getMonthOfYear()
									+ "/" + hoy2.getYear());

					SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
					comprobanteDao.saveOrUpdate(comprobante1);
					log.info("Comprobante guardado: ");

					SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
					socCuentassolDao.setSessionFactory(getSessionFactory());
					List<CuentaS> cuentas = socCuentassolDao.listaCuentasSolicitante(solic.getSolCodigo(), 34, null, null, null, null, null, true);

					if (cuentas == null || cuentas.size() != 1) {
						throw new RuntimeException("Cuenta inexistente entidad [" + solic.getSolCodigo() + "] moneda " + 34);
					}

					CuentaS cuentaS = cuentas.get(0);

					String afec = cuentaS.getCtaAfectable();

					query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = 'cla_afec_b' " + "AND val_codigo = trim('"
							+ solic.getSolCodigo() + "')";

					List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query, "val_nombre".split(","));
					if (resultado1.size() == 1) {
						for (Map<String, Object> res : resultado1) {
							afecB = (String) res.get("val_nombre");
						}
					} else {
						afecB = "";
					}

					String soli = Servicios.getSolicitante(solic.getSolCodigo());
					SocSolicitante socSolicitante = null;
					if (solic.getBenef() != null)
						socSolicitante = Servicios.getSocSolicitante(solic.getBenef());

					String conceptoCompro = "";
					if (solic.getClaTipsolic() == null || solic.getClaTipsolic().trim().equals("E")) {
						// si es entidad financiera el solicitante
						conceptoCompro = soli;
					} else {
						if ((socSolicitante != null) && (socSolicitante.getSolPersona() != null)
								&& (solic.getClaTipsolic() != null && solic.getClaTipsolic().trim().equals("G")))
							// si se encontrï¿½ el beneficiario y ademas el tipo
							// de solicitud es a publico en general
							if (solic.getBolCtamn() != null && solic.getBolCtame() != null)
								conceptoCompro = socSolicitante.getSolPersona() + " CTA. MN. " + solic.getBolCtamn() + " CTA. ME. "
										+ solic.getBolCtame();
							else
								conceptoCompro = socSolicitante.getSolPersona();
						else
							conceptoCompro = soli;
					}
					String mayorctaafect_b = "000108";
					SocRengscomp renglon1 = new SocRengscomp(new SocRengscompId(codComprobante1, 1), MONBS, 'D', tcBS, solic.getMontoAdj().multiply(
							solic.getCotiz()), solic.getMontoAdj().multiply(solic.getCotiz()), mayorctaafect_b, afecB);
					SocRengscomp renglon2 = new SocRengscomp(new SocRengscompId(codComprobante1, 2), MONUS, 'H', cambio.getCompra(),
							solic.getMontoAdj(), solic.getMontoAdj().multiply(cambio.getCompra()), "000110", afec, "SOL. NRO. " + ii + " POR USD. "
									+ formatearMonto(solic.getMontoAdj()) + " A BS. "
									+ formatearMonto(solic.getCotiz().divide(BigDecimal.ONE, 2, RoundingMode.HALF_UP)) + " BENEF. " + conceptoCompro);

					// para el monto excento
					BigDecimal comiV = solic.getMontoAdj().multiply(BigDecimal.valueOf(diff_cv));
					SocRengscomp renglon3 = new SocRengscomp(new SocRengscompId(codComprobante1, 3), MONBS, 'H', tcBS, comiV.multiply(BigDecimal
							.valueOf(1)), comiV.multiply(BigDecimal.valueOf(1)), Servicios.getParam("@mventaBolsin"),
							Servicios.getParam("@cventaBolsin"));

					SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
					rengsCompDao.saveOrUpdate(renglon1);
					rengsCompDao.saveOrUpdate(renglon2);
					rengsCompDao.saveOrUpdate(renglon3);
					BigDecimal diftc = solic.getCotiz().subtract(cambio.getVenta());
					if (diftc.compareTo(BigDecimal.valueOf(0.005)) > 0) {
						SocRengscomp renglon5 = new SocRengscomp(new SocRengscompId(codComprobante1, 4), MONBS, 'H', tcBS, solic.getMontoAdj()
								.multiply(diftc), solic.getMontoAdj().multiply(diftc), "000153", "004378");
						rengsCompDao.saveOrUpdate(renglon5);
					}
					log.info("Renglones guardados: ");
					// Codigo para la emision de factura sin credito
					// fiscal

					Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
					mapaParametros3.put("consulta", "nit");
					mapaParametros3.put("soli", solic.getSolCodigo().trim());
					String nit = "";
					char cveRuc = 'P';

					log.info("Llamando al servicio de coin: get nit");
					Map<String, Object> mapaResultado3;
					if (solic.getClaTipsolic() != null && solic.getClaTipsolic().equalsIgnoreCase("G")) {
						// si la venta es a publico en general
						nit = socSolicitante.getSolNit();
						soli = socSolicitante.getSolFactura();
					} else {
						SiocCoinService siocCoinService = new SiocCoinService();
						mapaResultado3 = siocCoinService.executeTask(mapaParametros3);

						nit = (String) mapaResultado3.get("nit");
					}

					SocFacturasId id = new SocFacturasId(codComprobante1, 3, 1);
					SocFacturas factura = new SocFacturas(id, nit, soli, solic.getMontoAdj().multiply(solic.getCotiz()), BigDecimal.valueOf(0), solic
							.getMontoAdj().multiply(solic.getCotiz()), tcBase, "VENTA DE DIVISAS", cveRuc);
					SocFacturasDao socFacturaDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
					socFacturaDao.saveOrUpdate(factura);
				}
			}
			total0 = total0.add(solic.getMontoAdj() != null ? solic.getMontoAdj() : BigDecimal.valueOf(0));
		}

		cambio.setVend(total0);

		socCambioDao.saveOrUpdate(cambio);
		log.info("Subasta Procesada, monto adjudicao " + total0 + " para fecha " + cambio.getFecha());

		return estado;
	}

	private String formatearMonto(BigDecimal monto) {
		int pos = 0;
		int ll = 0;
		int sep = 0;
		String valor = monto.toString();
		String montoT = "";

		valor = valor.replace('.', ',');
		pos = valor.indexOf(',');
		if (pos > -1) {
			if (valor.length() > 6) {
				valor = valor.substring(0, pos + 3);
				ll = pos - 1;
				sep = ll - 3;
				if (sep > -1) {
					montoT = valor.substring(0, sep + 1) + "." + valor.substring(sep + 1);
					valor = montoT;
					ll = sep;
					sep = ll - 3;
					if (sep > -1)
						montoT = valor.substring(0, sep + 1) + "." + valor.substring(sep + 1);
				}
			} else {
				montoT = valor;
			}
		}

		return montoT;
	}

	public void setResponseContext(ResponseContext responseContext) {
		this.responseContext = responseContext;
	}

	public ResponseContext getResponseContext() {
		return responseContext;
	}
}
