package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Embeddable
public class ExpClasiffactorPK  implements Serializable{
	private static final long serialVersionUID = 1L;
	@Basic(optional = false)
	@Column(name = "fac_codmonpar")
	private String facCodmonpar;
	@Basic(optional = false)
	@Column(name = "fac_fechavig")
	@Temporal(TemporalType.DATE)
	private Date facFechavig;
	@Basic(optional = false)
	@Column(name = "fac_tramo")
	private String facTramo;
	
	public ExpClasiffactorPK() {
	}

	public String getFacCodmonpar() {
		return facCodmonpar;
	}

	public void setFacCodmonpar(String facCodmonpar) {
		this.facCodmonpar = facCodmonpar;
	}

	public Date getFacFechavig() {
		return facFechavig;
	}

	public void setFacFechavig(Date facFechavig) {
		this.facFechavig = facFechavig;
	}

	public String getFacTramo() {
		return facTramo;
	}

	public void setFacTramo(String facTramo) {
		this.facTramo = facTramo;
	}

	@Override
	public int hashCode() {
		return Objects.hash(facCodmonpar, facFechavig, facTramo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExpClasiffactorPK other = (ExpClasiffactorPK) obj;
		return Objects.equals(facCodmonpar, other.facCodmonpar) && Objects.equals(facFechavig, other.facFechavig) && Objects.equals(facTramo, other.facTramo);
	}

	
}
