package gob.bcb.swift.dao;

import gob.bcb.swift.model.SwfMttransferdet;

import gob.bcb.swift.model.SwfMttransferdetPK;

import java.util.List;

import org.hibernate.SessionFactory;

public interface SwfMttransferdetLocal {

	List<SwfMttransferdet> findByCodTTransfer0(String dttCodttransfer, Integer dttBloque);

	SwfMttransferdet findByCodigo0(String dttCodttransfer, String dttCodcampo, Integer dttBloque);
	void setSessionFactory(SessionFactory sessionFactory);
}
