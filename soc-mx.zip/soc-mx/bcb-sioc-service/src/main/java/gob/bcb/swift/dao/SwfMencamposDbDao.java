package gob.bcb.swift.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import gob.bcb.core.utils.UtilsQNatives;
import gob.bcb.iso20022.utils.ValidatorCodes;
import gob.bcb.swift.model.SwfMencamposDb;

@Repository("SwfMencamposDbDao")
public class SwfMencamposDbDao extends HibernateDaoSupport {
	private static final Logger log = Logger.getLogger(SwfMencamposDbDao.class);

	public Session getSessionHB() {
//		Session session=getHibernateTemplate().getSessionFactory().getCurrentSession();
//		if (session == null) {
//			session=getHibernateTemplate().getSessionFactory().openSession();
//			session.setFlushMode(FlushMode.MANUAL);
//		}
		Session session = SessionFactoryUtils.getSession(getSessionFactory(), true);
		return session;
	}

	public List<SwfMencamposDb> findByCodigoBlk(String mtfCodmt, String mtfCodcampo, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		if (mtfCodmt == null) {
			return new ArrayList<>();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt ");
		consulta.append("and t.mtfCodcampo = :mtfCodcampo ");
		if (mtfNro != null)
			consulta.append("and t.mtfNro = :mtfNro ");
		else
			consulta.append("and t.mtfNro >= 0 ");
		consulta.append("and t.mtfGrpopt = :mtfGrpopt ");
		consulta.append("and t.mtfBloque = :mtfBloque ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfCodcampo", mtfCodcampo);
		if (mtfNro != null)
			query.setParameter("mtfNro", mtfNro);
		query.setParameter("mtfGrpopt", mtfGrpopt);
		query.setParameter("mtfBloque", mtfBloque);

		List result = query.list();

		return result;
	}

	public List<SwfMencamposDb> findByCodigo(String mtfCodmt, String mtfCodcampo, Integer mtfNro, Integer mtfGrpopt) {
		if (mtfCodmt == null) {
			return new ArrayList<>();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt ");
		consulta.append("and t.mtfCodcampo = :mtfCodcampo ");
		consulta.append("and t.mtfNro = :mtfNro ");
		consulta.append("and t.mtfGrpopt = :mtfGrpopt ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfCodcampo", mtfCodcampo);
		query.setParameter("mtfNro", mtfNro);
		query.setParameter("mtfGrpopt", mtfGrpopt);

		List result = query.list();

		return result;
	}

	public Optional<SwfMencamposDb> findByNemo(String mtfCodmt, String mtfNemo) {
		if (mtfCodmt == null || mtfNemo == null) {
			return Optional.empty();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt ");
		consulta.append("and t.mtfNemo = :mtfNemo ");
		consulta.append("and t.mtfEstado = :mtfEstado ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfNemo", mtfNemo);
		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		List result = query.list();
		if (result.size() > 0) {
			return Optional.of((SwfMencamposDb) result.get(0));
		}

		return Optional.empty();
	}

	public List<SwfMencamposDb> findByMT(String mtfCodmt, String mtfBloque) {
		if (mtfCodmt == null) {
			return new ArrayList<>();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt  ");
		// solo los que no son grupo
		// whf parametrizar
		// consulta.append("and t.mtfStatus not like 'G%' ");
		if (!StringUtils.isBlank(mtfBloque))
			consulta.append("and t.mtfBloque = :mtfBloque ");
		// consulta.append("and t.mtfEstado = :mtfEstado ");
		consulta.append("order by t.mtfCodmt, t.mtfGrpopt, t.mtfNro, t.mtfCodcampo ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		if (!StringUtils.isBlank(mtfBloque))
			query.setParameter("mtfBloque", mtfBloque);
		String mtfEstado = "V";
		// query.setParameter("mtfEstado", mtfEstado);

		return query.list();
	}

	public List<SwfMencamposDb> findByMT(String mtfCodmt, Integer mtfGrpopt, String mtfBloque) {
		if (mtfCodmt == null) {
			return new ArrayList<>();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt  ");
		consulta.append("and t.mtfGrpopt = :mtfGrpopt ");
		// solo los que no son grupo
		// whf parametrizar
		consulta.append("and t.mtfStatus not like 'G%' ");
		consulta.append("and t.mtfBloque = :mtfBloque ");
		consulta.append("and t.mtfEstado = :mtfEstado ");
		consulta.append("order by t.mtfCodmt, t.mtfNro, t.mtfCodcampo ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfGrpopt", mtfGrpopt);
		query.setParameter("mtfBloque", mtfBloque);
		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		return query.list();
	}

	public List<SwfMencamposDb> subBloqueCampo(String mtfCodmt, Integer mtfGrpopt, String nemoSubloque) {
		if (mtfCodmt == null) {
			return new ArrayList<>();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt  ");
		consulta.append("and t.mtfGrpopt = :mtfGrpopt ");
		// solo los que no son grupo
		consulta.append("and t.mtfStatus not like 'G%' ");
		consulta.append("and t.mtfBloque = :mtfBloque ");
		consulta.append("and t.mtfNemo like :codSubbloque ");
		consulta.append("and t.mtfEstado = :mtfEstado ");
		consulta.append("order by t.mtfCodmt, t.mtfNro, t.mtfCodcampo ");

		Query query = getSessionHB().createQuery(consulta.toString());

		final String mtfBloque = "4";
		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfGrpopt", mtfGrpopt);
		query.setParameter("codSubbloque", nemoSubloque + "%");
		query.setParameter("mtfBloque", mtfBloque);
		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		return query.list();
	}

	public List<SwfMencamposDb> gruposOpcionesRepetitivos(String mtfCodmt, String mtfCodcampo, Integer mtfNro) {
		if (mtfCodmt == null) {
			return new ArrayList<>();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt ");
		consulta.append("and t.mtfCodcampo = :mtfCodcampo ");
		consulta.append("and t.mtfNro = :mtfNro ");
		consulta.append("and t.mtfBloque = :mtfBloque ");
		consulta.append("and t.mtfStatus not like 'G%' ");
		consulta.append("and t.mtfEstado = :mtfEstado ");
		consulta.append("order by t.mtfCodmt, t.mtfGrpopt, t.mtfCodcampo ");

		Query query = getSessionHB().createQuery(consulta.toString());

		final String mtfBloque = "4";
		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfCodcampo", mtfCodcampo);
		query.setParameter("mtfNro", mtfNro);
		query.setParameter("mtfBloque", mtfBloque);
		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		List result = query.list();

		return result;
	}

	public List<SwfMencamposDb> opcionesDeCampo(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		if (mtfCodmt == null) {
			return new ArrayList<>();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt ");
		consulta.append("and t.mtfGrpopt = :mtfGrpopt ");
		consulta.append("and t.mtfNro = :mtfNro ");
		consulta.append("and t.mtfBloque = :mtfBloque ");
		// consulta.append("and t.mtfStatus not like 'G%' ");
		consulta.append("and t.mtfEstado = :mtfEstado ");
		consulta.append("order by t.mtfCodmt, t.mtfNro, t.mtfCodcampo ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfGrpopt", mtfGrpopt);
		query.setParameter("mtfNro", mtfNro);
		query.setParameter("mtfBloque", mtfBloque);
		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		List result = query.list();

		return result;
	}

	public List<SwfMencamposDb> findByMtCampo(String mtfCodmt, String mtfCodcampo) {
		if (mtfCodmt == null || StringUtils.isBlank(mtfCodcampo)) {
			return new ArrayList<>();
		}
		String[] paths = StringUtils.split(mtfCodcampo, "/");
		int countNvl = paths.length - 1;
		String mtfCmp = paths.length > 1 ? paths[paths.length - 1] : mtfCodcampo;

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt ");
		consulta.append("and t.mtfCodcampo like :mtfCodcampo ");

//		if (countNvl >= 1)
//			consulta.append("and t.mtfNivel >= :mtfNivel ");
		consulta.append("order by t.mtfCodmt, t.mtfNro, t.mtfCodcampo ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		if (paths.length > 1)
			query.setParameter("mtfCodcampo", "%" + mtfCmp);
		else
			query.setParameter("mtfCodcampo", mtfCodcampo);

//		if (countNvl >= 1)
//			query.setParameter("mtfNivel", countNvl);

		List<SwfMencamposDb> result = query.list();

		if (paths.length == 1 || result.size() <= 1) {
			return result;
		}
		
		String[] reversed = Arrays.copyOfRange(paths, 0, paths.length - 1);
		ArrayUtils.reverse(reversed);
		
		List<SwfMencamposDb> resp = new ArrayList<>();		
		List<SwfMencamposDb> resXml = result.stream().filter(sc -> {
			String[] pathR = StringUtils.split(sc.getMtfXmltag(), "/");
			if (!StringUtils.isBlank(sc.getMtfXmltag()) && (sc.getMtfXmltag().equals(mtfCodcampo))) {
				resp.add(sc);
				return true;
			}
			return !StringUtils.isBlank(sc.getMtfXmltag()) && (pathR.length == paths.length);
		}).collect(Collectors.toList());
		
		if (resp.size() > 0) {
			return resp;
		}
		
		if (resXml.size() <= 1) {
			return resXml;
		}

		for (SwfMencamposDb sc : resXml) {
			String[] pathR = StringUtils.split(sc.getMtfXmltag(), "/");
			ArrayUtils.reverse(pathR);
			int cont = 0;
			for (int i = 0; i < reversed.length; i++) {
				if (pathR[i].endsWith(reversed[i])) {

				} else {
					cont++;					
					break;
				}
			}
			if (cont == 0) {
				resp.add(sc);
			}
		}
		return resp;
	}

	public Optional<SwfMencamposDb> nextNroSwfMencamposDb(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque, Integer mtfNivel) {
		if (mtfCodmt == null) {
			return Optional.empty();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt  ");

		if (mtfGrpopt != null)
			consulta.append("and t.mtfGrpopt = :mtfGrpopt ");

		// solo los que no son grupo
		// whf parametrizar
		consulta.append("and t.mtfStatus not like 'G%' ");
		consulta.append("and t.mtfBloque = :mtfBloque ");
		consulta.append("and t.mtfEstado = :mtfEstado ");

		consulta.append("and t.mtfNro = ( select min(b.mtfNro) ");
		consulta.append("from SwfMencamposDb b ");
		consulta.append("where b.mtfCodmt = t.mtfCodmt ");
		consulta.append("and b.mtfGrpopt = t.mtfGrpopt ");
		consulta.append("and b.mtfStatus not like 'G%' ");
		consulta.append("and b.mtfNro > :mtfNro ");
		consulta.append("and b.mtfBloque = t.mtfBloque ");
		consulta.append("and b.mtfEstado = t.mtfEstado ) ");
		consulta.append("order by t.mtfCodmt, t.mtfNro, t.mtfCodcampo, t.mtfGrpopt ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfNro", mtfNro);

		if (mtfGrpopt != null)
			query.setParameter("mtfGrpopt", mtfGrpopt);

		query.setParameter("mtfBloque", mtfBloque);
		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		List result = query.list();
		if (result.size() > 0) {
			return Optional.of((SwfMencamposDb) result.get(0));
		}

		return Optional.empty();

	}

	public Optional<SwfMencamposDb> nextNroSwfMencamposDb(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque) {
		if (mtfCodmt == null) {
			return Optional.empty();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt  ");

		if (mtfGrpopt != null)
			consulta.append("and t.mtfGrpopt = :mtfGrpopt ");

		// solo los que no son grupo
		// whf parametrizar
		// consulta.append("and t.mtfStatus not like 'G%' ");
		consulta.append("and t.mtfBloque = :mtfBloque ");
		consulta.append("and t.mtfEstado = :mtfEstado ");
		consulta.append("and t.mtfNro = ( select min(b.mtfNro) ");
		consulta.append("from SwfMencamposDb b ");
		consulta.append("where b.mtfCodmt = t.mtfCodmt ");
		consulta.append("and b.mtfGrpopt = t.mtfGrpopt ");
		// consulta.append("and b.mtfStatus not like 'G%' ");
		consulta.append("and b.mtfNro > :mtfNro ");
		consulta.append("and b.mtfBloque = t.mtfBloque ");
		consulta.append("and b.mtfEstado = t.mtfEstado ) ");
		consulta.append("order by t.mtfCodmt, t.mtfNro, t.mtfCodcampo, t.mtfGrpopt ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfNro", mtfNro);

		if (mtfGrpopt != null)
			query.setParameter("mtfGrpopt", mtfGrpopt);

		query.setParameter("mtfBloque", mtfBloque);
		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		List result = query.list();
		if (result.size() > 0) {
			return Optional.of((SwfMencamposDb) result.get(0));
		}

		return Optional.empty();

	}

	public Optional<SwfMencamposDb> nextLvlSwfMencamposDb(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfBloque, Integer mtfNivel) {
		if (mtfCodmt == null) {
			return Optional.empty();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt  ");
		consulta.append("and t.mtfEstado = :mtfEstado ");
		consulta.append("and t.mtfNivel = ( select min(b.mtfNivel) ");
		consulta.append("from SwfMencamposDb b ");
		consulta.append("where b.mtfCodmt = t.mtfCodmt ");
		consulta.append("and b.mtfNivel > :mtfNivel ");
		consulta.append("and b.mtfXmltag like b.mtfXmltag '' ");
		consulta.append("and b.mtfEstado = t.mtfEstado ) ");
		consulta.append("order by t.mtfCodmt, t.mtfNro, t.mtfCodcampo, t.mtfGrpopt ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfNivel", mtfNivel);

		if (mtfGrpopt != null)
			query.setParameter("mtfGrpopt", mtfGrpopt);

		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		List result = query.list();
		if (result.size() > 0) {
			return Optional.of((SwfMencamposDb) result.get(0));
		}

		return Optional.empty();

	}

	public Optional<SwfMencamposDb> nextGrpoptSwfMencamposDb(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfCodcampo, String mtfBloque) {
		if (mtfCodmt == null) {
			return Optional.empty();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt  ");

		// solo los que no son grupo
		// whf parametrizar
		consulta.append("and t.mtfStatus not like 'G%' ");
		consulta.append("and t.mtfBloque = :mtfBloque ");
		consulta.append("and t.mtfEstado = :mtfEstado ");
		consulta.append("and t.mtfCodcampo = :mtfCodcampo ");
		consulta.append("and t.mtfNro = :mtfNro ");
		consulta.append("and t.mtfGrpopt = ( select min(b.mtfGrpopt) ");
		consulta.append("from SwfMencamposDb b ");
		consulta.append("where b.mtfCodmt = t.mtfCodmt ");
		consulta.append("and b.mtfGrpopt > :mtfGrpopt ");
		consulta.append("and b.mtfStatus not like 'G%' ");
		consulta.append("and b.mtfNro = t.mtfNro ");
		consulta.append("and b.mtfCodcampo = t.mtfCodcampo ");
		consulta.append("and b.mtfBloque = t.mtfBloque ");
		consulta.append("and b.mtfEstado = t.mtfEstado ) ");
		consulta.append("order by t.mtfCodmt, t.mtfNro, t.mtfGrpopt ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfNro", mtfNro);
		query.setParameter("mtfCodcampo", mtfCodcampo);
		query.setParameter("mtfGrpopt", mtfGrpopt);
		query.setParameter("mtfBloque", mtfBloque);
		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		List result = query.list();
		if (result.size() > 0) {
			return Optional.of((SwfMencamposDb) result.get(0));
		}

		return Optional.empty();

	}

	public Optional<SwfMencamposDb> nextSwfMencamposDb(String mtfCodmt, Integer mtfNro, Integer mtfGrpopt, String mtfCodcampo, String mtfBloque) {
		if (mtfCodmt == null) {
			return Optional.empty();
		}

		Optional<SwfMencamposDb> grpSwfMencamposDb = nextGrpoptSwfMencamposDb(mtfCodmt, mtfNro, mtfGrpopt, mtfCodcampo, mtfBloque);
		if (!grpSwfMencamposDb.isPresent()) {
			Optional<SwfMencamposDb> nroSwfMencamposDb = nextNroSwfMencamposDb(mtfCodmt, mtfNro, mtfGrpopt, mtfBloque);
			return nroSwfMencamposDb;
		}
		return grpSwfMencamposDb;

	}

	public List<SwfMencamposDb> camposPorGrupos(String codMT, Integer mtfGrpopt, String nemoSubloque) {
		List<SwfMencamposDb> SwfMencamposDbList = new ArrayList<>();
		if ((codMT == null || codMT.trim().length() == 0)) {
			return SwfMencamposDbList;
		}

		String st_queryc1 = "select mtf_codmt, mtf_nro, min(mtf_grpopt) mtf_grpopt, count(distinct mtf_grpopt) grupos, count(distinct mtf_codcampo) opciones, ";
		st_queryc1 = st_queryc1.concat("min(mtf_codcampo) codcampomin, max(mtf_codcampo) codcampomax  ");
		st_queryc1 = st_queryc1.concat("from swf_mencampos ");
		st_queryc1 = st_queryc1.concat("where mtf_codmt = ? ");
		st_queryc1 = st_queryc1.concat("and mtf_bloque = ? ");
		st_queryc1 = st_queryc1.concat("and mtf_estado = ? ");
		st_queryc1 = st_queryc1.concat("and mtf_status not like 'G%' ");

		if (mtfGrpopt != null)
			st_queryc1 = st_queryc1.concat("and mtf_grpopt = ? ");

		if (nemoSubloque != null)
			st_queryc1 = st_queryc1.concat("and mtf_nemo like ? ");

		st_queryc1 = st_queryc1.concat("group by 1,2 ");
		st_queryc1 = st_queryc1.concat("order by mtf_codmt, mtf_nro ");

		final String mtfBloque = "4";

		Query query = getSessionHB().createSQLQuery(st_queryc1);
		query.setParameter(1, codMT.trim());
		query.setParameter(2, mtfBloque);

		final String mtfEstado = "V";
		query.setParameter(3, mtfEstado);

		if (mtfGrpopt != null)
			query.setParameter(4, mtfGrpopt);

		if (nemoSubloque != null)
			query.setParameter(5, nemoSubloque + "%");

		List lista = query.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives.convertListToMap(lista,
				"mtf_codmt, mtf_nro, mtf_grpopt, grupos, opciones, codcampomin, codcampomax".split(","));

		for (Map<String, Object> rquery : resultadoQuery) {
			SwfMencamposDb SwfMencamposDbNew = new SwfMencamposDb();
//			SwfMencamposDbNew.setId();

			SwfMencamposDbNew.setMtfCodmt(codMT);
			SwfMencamposDbNew.setMtfCodcampo((String) rquery.get("codcampomin"));
			SwfMencamposDbNew.setMtfNro(ValidatorCodes.stringToInteger(rquery.get("mtf_nro").toString()));
			SwfMencamposDbNew.setMtfGrpopt(ValidatorCodes.stringToInteger(rquery.get("mtf_grpopt").toString()));

			SwfMencamposDbNew.setMtfBloque((String) rquery.get("codcampomax"));
			SwfMencamposDbNew.setMtfSecpadre(rquery.get("opciones").toString());
			SwfMencamposDbNew.setMtfTipocampo(rquery.get("grupos").toString());

			SwfMencamposDbList.add(SwfMencamposDbNew);
		}

		return SwfMencamposDbList;
	}

	public List<SwfMencamposDb> nroSwfMencamposDb(String mtfCodmt, Integer mtfNro, String mtfCodcampo, Integer mtfGrpopt, String mtfBloque, Boolean exacto) {
		if (mtfCodmt == null) {
			// return Optional.empty();
		}

		StringBuffer consulta = new StringBuffer();
		consulta.append("select t ");
		consulta.append("from SwfMencamposDb t ");
		consulta.append("where t.mtfCodmt = :mtfCodmt  ");

		if (mtfGrpopt != null)
			consulta.append("and t.mtfGrpopt = :mtfGrpopt ");

		// solo los que no son grupo
		// whf parametrizar
		consulta.append("and t.mtfStatus not like 'G%' ");
		consulta.append("and t.mtfBloque = :mtfBloque ");
		consulta.append("and t.mtfEstado = :mtfEstado ");
		if (exacto)
			consulta.append("and t.mtfCodcampo = :mtfCodcampo ");
		else
			consulta.append("and t.mtfCodcampo like :mtfCodcampo ");

		consulta.append("and t.mtfNro = ( select min(b.mtfNro) ");
		consulta.append("from SwfMencamposDb b ");
		consulta.append("where b.mtfCodmt = t.mtfCodmt ");
		consulta.append("and b.mtfCodcampo = t.mtfCodcampo ");
		consulta.append("and b.mtfGrpopt = t.mtfGrpopt ");
		consulta.append("and b.mtfStatus not like 'G%' ");
		consulta.append("and b.mtfNro > :mtfNro ");
		consulta.append("and b.mtfBloque = t.mtfBloque ");
		consulta.append("and b.mtfEstado = t.mtfEstado ) ");
		consulta.append("order by t.mtfCodmt, t.mtfNro, t.mtfCodcampo, t.mtfGrpopt ");

		Query query = getSessionHB().createQuery(consulta.toString());

		query.setParameter("mtfCodmt", mtfCodmt);
		query.setParameter("mtfNro", mtfNro);

		if (mtfGrpopt != null)
			query.setParameter("mtfGrpopt", mtfGrpopt);

		query.setParameter("mtfBloque", mtfBloque);
		String mtfEstado = "V";
		query.setParameter("mtfEstado", mtfEstado);

		List result = query.list();

		return result;

	}

	public static Supplier<SwfMencamposDb> cloneSwfMencamposDb(SwfMencamposDb swfMencamposDbOld) {
		return () -> {
			if (swfMencamposDbOld == null) {
				return null;
			}

			SwfMencamposDb SwfMencamposDbNew = new SwfMencamposDb();
			SwfMencamposDbNew.setMtfCodmt(swfMencamposDbOld.getMtfCodmt());
			SwfMencamposDbNew.setMtfNro(swfMencamposDbOld.getMtfNro());
			SwfMencamposDbNew.setMtfGrpopt(swfMencamposDbOld.getMtfGrpopt());
			SwfMencamposDbNew.setMtfCodcampo(swfMencamposDbOld.getMtfCodcampo());
			SwfMencamposDbNew.setMtfNemo(swfMencamposDbOld.getMtfNemo());
			SwfMencamposDbNew.setMtfBloque(swfMencamposDbOld.getMtfBloque());
			SwfMencamposDbNew.setMtfCondicion(swfMencamposDbOld.getMtfCondicion());
			SwfMencamposDbNew.setMtfDatoadic(swfMencamposDbOld.getMtfDatoadic());
			SwfMencamposDbNew.setMtfDefault(swfMencamposDbOld.getMtfDefault());
			SwfMencamposDbNew.setMtfDescrip(swfMencamposDbOld.getMtfDescrip());
			SwfMencamposDbNew.setMtfExpresion(swfMencamposDbOld.getMtfExpresion());
			SwfMencamposDbNew.setMtfFormato(swfMencamposDbOld.getMtfFormato());
			SwfMencamposDbNew.setMtfReglaswf(swfMencamposDbOld.getMtfReglaswf());
			SwfMencamposDbNew.setMtfReglavalid(swfMencamposDbOld.getMtfReglavalid());
			SwfMencamposDbNew.setMtfSecpadre(swfMencamposDbOld.getMtfSecpadre());
			SwfMencamposDbNew.setMtfStatus(swfMencamposDbOld.getMtfStatus());
			SwfMencamposDbNew.setMtfTipocampo(swfMencamposDbOld.getMtfTipocampo());
			SwfMencamposDbNew.setMtfEstado(swfMencamposDbOld.getMtfEstado());
			return SwfMencamposDbNew;
		};
	}

	public static void main(String[] args) {
		String[] paths = "R/D/FIToFICstmrCdtTrf/CdtTrfTxInf/IntrBkSttlmAmt".split("/");
		ArrayUtils.reverse(paths);
		System.out.println(paths.toString());
		for (String p : paths) {
			System.out.println(p);
		}
	}

}
