package gob.bcb.service.servicioSioc.pojos;

import java.math.BigDecimal;
import java.util.Date;

public class ExcelOperacionesPojo
{
	private String correlativoSWIFT;//1
	private Date fechaOperacion;//2
	private String ordenanteNroCuenta;//3
	private String ordenanteNombre;//4
	private String ordenanteDireccion;//5
	private String ordenantePlaza;//6
	private String corresponsalNroCuenta;//7
	private String corresponsalNombre;//8
	private String intermediarioBancoCuenta;//9
	private String intermediarioBancoNombre;//10
	private String intermediarioBancoPlaza;//11
	private String beneficiarioBancoCuenta;//12
	private String beneficiarioBancoNombre;//13
	private String beneficiarioBancoPlaza;//14
	private String beneficiarioCuenta;//15
	private String beneficiarioNombre;//16
	private String beneficiarioDireccion;//17
	private String beneficiarioPlaza;//18
	private String detalle;//19
	private String infoAdicional;//20
	private String operacionTipo;//21
	private String operacionEstado;//22
	private String operacionCodigo;//23
	private String monedaDeLaSolicitud;//24
	private BigDecimal importeSolicitado;//25
	private String monedaDeLaTransferencia;//26
	private BigDecimal importeTransferido;//27


	/**
	 * Constructor de la clase.
	 **/
	public ExcelOperacionesPojo()
	{

	}
	/**
	 * Constructor de la clase con parametros de entrada.
	 * @param correlativoSWIFT Valor de Correlativo SWIFT.
	 * @param fechaOperacion Valor de Fecha Operación.
	 * @param ordenanteNroCuenta Valor de No. cta del ordenante.
	 * @param ordenanteNombre Valor de Nombre del ordenante.
	 * @param ordenanteDireccion Valor de Dirección del ordenante.
	 * @param ordenantePlaza Valor de Plaza del ordenante.
	 * @param corresponsalNroCuenta Valor de No. cta del corresponsal remtnt.
	 * @param corresponsalNombre Valor de Nombre corresponsal remtnt.
	 * @param intermediarioBancoCuenta Valor de BIC/cta bco intermediario.
	 * @param intermediarioBancoNombre Valor de Nombre bco intermediario.
	 * @param intermediarioBancoPlaza Valor de Plaza bco intermediario.
	 * @param beneficiarioBancoCuenta Valor de BIC/cta bco del beneficiario.
	 * @param beneficiarioBancoNombre Valor de Nombre bco del beneficiario.
	 * @param beneficiarioBancoPlaza Valor de Plaza bco del beneficiario.
	 * @param beneficiarioCuenta Valor de No. cta beneficiario.
	 * @param beneficiarioNombre Valor de Nombre del beneficiario.
	 * @param beneficiarioDireccion Valor de Dirección del beneficiario.
	 * @param beneficiarioPlaza Valor de Plaza del beneficiario.
	 * @param detalle Valor de Detalle.
	 * @param infoAdicional Valor de Info_adicional.
	 * @param operacionTipo Valor de Tipo de operación.
	 * @param operacionEstado Valor de Estado de la operación.
	 * @param operacionCodigo Valor de Código de la operación.
	 * @param monedaDeLaSolicitud Valor de Moneda de la solicitud.
	 * @param importeSolicitado Valor de Importe solicitado.
	 * @param monedaDeLaTransferencia Valor de Moneda de la transferencia.
	 * @param importeTransferido Valor de Importe transferido.
	 **/
	public ExcelOperacionesPojo(String correlativoSWIFT, Date fechaOperacion, String ordenanteNroCuenta, String ordenanteNombre, String ordenanteDireccion, String ordenantePlaza, String corresponsalNroCuenta, String corresponsalNombre, String intermediarioBancoCuenta, String intermediarioBancoNombre, String intermediarioBancoPlaza, String beneficiarioBancoCuenta, String beneficiarioBancoNombre, String beneficiarioBancoPlaza, String beneficiarioCuenta, String beneficiarioNombre, String beneficiarioDireccion, String beneficiarioPlaza, String detalle, String infoAdicional, String operacionTipo, String operacionEstado, String operacionCodigo, String monedaDeLaSolicitud, BigDecimal importeSolicitado, String monedaDeLaTransferencia, BigDecimal importeTransferido) {
		this.correlativoSWIFT = correlativoSWIFT;
		this.fechaOperacion = fechaOperacion;
		this.ordenanteNroCuenta = ordenanteNroCuenta;
		this.ordenanteNombre = ordenanteNombre;
		this.ordenanteDireccion = ordenanteDireccion;
		this.ordenantePlaza = ordenantePlaza;
		this.corresponsalNroCuenta = corresponsalNroCuenta;
		this.corresponsalNombre = corresponsalNombre;
		this.intermediarioBancoCuenta = intermediarioBancoCuenta;
		this.intermediarioBancoNombre = intermediarioBancoNombre;
		this.intermediarioBancoPlaza = intermediarioBancoPlaza;
		this.beneficiarioBancoCuenta = beneficiarioBancoCuenta;
		this.beneficiarioBancoNombre = beneficiarioBancoNombre;
		this.beneficiarioBancoPlaza = beneficiarioBancoPlaza;
		this.beneficiarioCuenta = beneficiarioCuenta;
		this.beneficiarioNombre = beneficiarioNombre;
		this.beneficiarioDireccion = beneficiarioDireccion;
		this.beneficiarioPlaza = beneficiarioPlaza;
		this.detalle = detalle;
		this.infoAdicional = infoAdicional;
		this.operacionTipo = operacionTipo;
		this.operacionEstado = operacionEstado;
		this.operacionCodigo = operacionCodigo;
		this.monedaDeLaSolicitud = monedaDeLaSolicitud;
		this.importeSolicitado = importeSolicitado;
		this.monedaDeLaTransferencia = monedaDeLaTransferencia;
		this.importeTransferido = importeTransferido;
	}

	public String getCorrelativoSWIFT() {
		return correlativoSWIFT;
	}

	public void setCorrelativoSWIFT(String correlativoSWIFT) {
		this.correlativoSWIFT = correlativoSWIFT;
	}

	public Date getFechaOperacion() {
		return fechaOperacion;
	}

	public void setFechaOperacion(Date fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}

	public String getOrdenanteNroCuenta() {
		return ordenanteNroCuenta;
	}

	public void setOrdenanteNroCuenta(String ordenanteNroCuenta) {
		this.ordenanteNroCuenta = ordenanteNroCuenta;
	}

	public String getOrdenanteNombre() {
		return ordenanteNombre;
	}

	public void setOrdenanteNombre(String ordenanteNombre) {
		this.ordenanteNombre = ordenanteNombre;
	}

	public String getOrdenanteDireccion() {
		return ordenanteDireccion;
	}

	public void setOrdenanteDireccion(String ordenanteDireccion) {
		this.ordenanteDireccion = ordenanteDireccion;
	}

	public String getOrdenantePlaza() {
		return ordenantePlaza;
	}

	public void setOrdenantePlaza(String ordenantePlaza) {
		this.ordenantePlaza = ordenantePlaza;
	}

	public String getCorresponsalNroCuenta() {
		return corresponsalNroCuenta;
	}

	public void setCorresponsalNroCuenta(String corresponsalNroCuenta) {
		this.corresponsalNroCuenta = corresponsalNroCuenta;
	}

	public String getCorresponsalNombre() {
		return corresponsalNombre;
	}

	public void setCorresponsalNombre(String corresponsalNombre) {
		this.corresponsalNombre = corresponsalNombre;
	}

	public String getIntermediarioBancoCuenta() {
		return intermediarioBancoCuenta;
	}

	public void setIntermediarioBancoCuenta(String intermediarioBancoCuenta) {
		this.intermediarioBancoCuenta = intermediarioBancoCuenta;
	}

	public String getIntermediarioBancoNombre() {
		return intermediarioBancoNombre;
	}

	public void setIntermediarioBancoNombre(String intermediarioBancoNombre) {
		this.intermediarioBancoNombre = intermediarioBancoNombre;
	}

	public String getIntermediarioBancoPlaza() {
		return intermediarioBancoPlaza;
	}

	public void setIntermediarioBancoPlaza(String intermediarioBancoPlaza) {
		this.intermediarioBancoPlaza = intermediarioBancoPlaza;
	}

	public String getBeneficiarioBancoCuenta() {
		return beneficiarioBancoCuenta;
	}

	public void setBeneficiarioBancoCuenta(String beneficiarioBancoCuenta) {
		this.beneficiarioBancoCuenta = beneficiarioBancoCuenta;
	}

	public String getBeneficiarioBancoNombre() {
		return beneficiarioBancoNombre;
	}

	public void setBeneficiarioBancoNombre(String beneficiarioBancoNombre) {
		this.beneficiarioBancoNombre = beneficiarioBancoNombre;
	}

	public String getBeneficiarioBancoPlaza() {
		return beneficiarioBancoPlaza;
	}

	public void setBeneficiarioBancoPlaza(String beneficiarioBancoPlaza) {
		this.beneficiarioBancoPlaza = beneficiarioBancoPlaza;
	}

	public String getBeneficiarioCuenta() {
		return beneficiarioCuenta;
	}

	public void setBeneficiarioCuenta(String beneficiarioCuenta) {
		this.beneficiarioCuenta = beneficiarioCuenta;
	}

	public String getBeneficiarioNombre() {
		return beneficiarioNombre;
	}

	public void setBeneficiarioNombre(String beneficiarioNombre) {
		this.beneficiarioNombre = beneficiarioNombre;
	}

	public String getBeneficiarioDireccion() {
		return beneficiarioDireccion;
	}

	public void setBeneficiarioDireccion(String beneficiarioDireccion) {
		this.beneficiarioDireccion = beneficiarioDireccion;
	}

	public String getBeneficiarioPlaza() {
		return beneficiarioPlaza;
	}

	public void setBeneficiarioPlaza(String beneficiarioPlaza) {
		this.beneficiarioPlaza = beneficiarioPlaza;
	}

	public String getDetalle() {
		return detalle;
	}

	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}

	public String getInfoAdicional() {
		return infoAdicional;
	}

	public void setInfoAdicional(String infoAdicional) {
		this.infoAdicional = infoAdicional;
	}

	public String getOperacionTipo() {
		return operacionTipo;
	}

	public void setOperacionTipo(String operacionTipo) {
		this.operacionTipo = operacionTipo;
	}

	public String getOperacionEstado() {
		return operacionEstado;
	}

	public void setOperacionEstado(String operacionEstado) {
		this.operacionEstado = operacionEstado;
	}

	public String getOperacionCodigo() {
		return operacionCodigo;
	}

	public void setOperacionCodigo(String operacionCodigo) {
		this.operacionCodigo = operacionCodigo;
	}

	public String getMonedaDeLaSolicitud() {
		return monedaDeLaSolicitud;
	}

	public void setMonedaDeLaSolicitud(String monedaDeLaSolicitud) {
		this.monedaDeLaSolicitud = monedaDeLaSolicitud;
	}

	public BigDecimal getImporteSolicitado() {
		return importeSolicitado;
	}

	public void setImporteSolicitado(BigDecimal importeSolicitado) {
		this.importeSolicitado = importeSolicitado;
	}

	public String getMonedaDeLaTransferencia() {
		return monedaDeLaTransferencia;
	}

	public void setMonedaDeLaTransferencia(String monedaDeLaTransferencia) {
		this.monedaDeLaTransferencia = monedaDeLaTransferencia;
	}

	public BigDecimal getImporteTransferido() {
		return importeTransferido;
	}

	public void setImporteTransferido(BigDecimal importeTransferido) {
		this.importeTransferido = importeTransferido;
	}

	@Override
	public String toString() {
		return "ExcelOperacionesPojo{" +
				"correlativoSWIFT='" + correlativoSWIFT + '\'' +
				", fechaOperacion=" + fechaOperacion +
				", ordenanteNroCuenta='" + ordenanteNroCuenta + '\'' +
				", ordenanteNombre='" + ordenanteNombre + '\'' +
				", ordenanteDireccion='" + ordenanteDireccion + '\'' +
				", ordenantePlaza='" + ordenantePlaza + '\'' +
				", corresponsalNroCuenta='" + corresponsalNroCuenta + '\'' +
				", corresponsalNombre='" + corresponsalNombre + '\'' +
				", intermediarioBancoCuenta='" + intermediarioBancoCuenta + '\'' +
				", intermediarioBancoNombre='" + intermediarioBancoNombre + '\'' +
				", intermediarioBancoPlaza='" + intermediarioBancoPlaza + '\'' +
				", beneficiarioBancoCuenta='" + beneficiarioBancoCuenta + '\'' +
				", beneficiarioBancoNombre='" + beneficiarioBancoNombre + '\'' +
				", beneficiarioBancoPlaza='" + beneficiarioBancoPlaza + '\'' +
				", beneficiarioCuenta='" + beneficiarioCuenta + '\'' +
				", beneficiarioNombre='" + beneficiarioNombre + '\'' +
				", beneficiarioDireccion='" + beneficiarioDireccion + '\'' +
				", beneficiarioPlaza='" + beneficiarioPlaza + '\'' +
				", detalle='" + detalle + '\'' +
				", infoAdicional='" + infoAdicional + '\'' +
				", operacionTipo='" + operacionTipo + '\'' +
				", operacionEstado='" + operacionEstado + '\'' +
				", operacionCodigo='" + operacionCodigo + '\'' +
				", monedaDeLaSolicitud='" + monedaDeLaSolicitud + '\'' +
				", importeSolicitado=" + importeSolicitado +
				", monedaDeLaTransferencia='" + monedaDeLaTransferencia + '\'' +
				", importeTransferido=" + importeTransferido +
				'}';
	}
}
