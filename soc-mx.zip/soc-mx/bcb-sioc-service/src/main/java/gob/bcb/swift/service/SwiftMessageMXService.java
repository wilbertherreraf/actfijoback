package gob.bcb.swift.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;

import com.prowidesoftware.swift.model.BIC;

import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentas;
import gob.bcb.bpm.pruebaCU.SocCuentasDao;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMsgParam;
//import gob.bcb.iso20022.model.SwfReglasmerc;
import gob.bcb.iso20022.pojo.Acc;
import gob.bcb.iso20022.pojo.BkSrv;
import gob.bcb.iso20022.pojo.Part;
import gob.bcb.iso20022.pojo.RmtInf;
import gob.bcb.iso20022.pojo.Ssi;
import gob.bcb.iso20022.swift.FieldSwf;
import gob.bcb.iso20022.utils.ValidatorCodes;
import gob.bcb.iso20022.utilsBank.UtilsSwiftMkt;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.CartasCredService;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.swift.dao.SwfDetmensajeBean;
import gob.bcb.swift.dao.SwfDetmensajeLocal;
import gob.bcb.swift.dao.SwfMencamposDbDao;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMensajeLocal;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.dao.SwfMttransferLocal;
import gob.bcb.swift.dao.SwfPersonactaBean;
import gob.bcb.swift.dao.SwfPersonactaLocal;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.pojos.SwiftDatos;

public class SwiftMessageMXService {
	private static final Logger log = Logger.getLogger(SwiftMessageService.class);

	private SocBancosDao socBancosDao = new SocBancosDao();
	private SocBenefsDao socBenefsDao = new SocBenefsDao();
	private SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
	private SwfMttransferLocal swfMttransferLocal = new SwfMttransferBean();
	private SwfPersonactaLocal swfPersonactaLocal = new SwfPersonactaBean();
	private SwfDetmensajeLocal swfDetmensajeLocal = new SwfDetmensajeBean();
	private SwfMencamposDbDao swfMencamposDbDao = new SwfMencamposDbDao();
	private SwfMencamposIsoDaoImpl swfMencamposIsoDaoImpl = new SwfMencamposIsoDaoImpl();
	private SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
	private SocCuentasDao socCuentasDao = new SocCuentasDao();
	private SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
	private SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
	private GenMonedaDao genMonedaDao = new GenMonedaDao();
	private SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
	private SessionFactory sessionFactory;

	public void generarMensajeSwift(CreateSwiftService createSwiftService, SwiftDatos swiftDatos) {
		log.info("En generarMensaje swiftDatos inicio de generar Swift " + swiftDatos.getSwfMensaje().getMenCodmt() + " "
				+ swiftDatos.getSwfMensaje().getMenCodoperacion() + " " + swiftDatos.getSwfMensaje().getMenCodusrswf());
		long buildTime = System.currentTimeMillis();
		obtenerFacts(swiftDatos, createSwiftService);
		createSwiftService.recuperarCampos("");
		createSwiftService.registerFuncsDef();
		createSwiftService.initEngine();
		createSwiftService.translate();
		createSwiftService.translatePost();
		createSwiftService.generaHeaderMsg();
		createSwiftService.createMsgSwift();
		Instruccion instruccion = createSwiftService.getInstruccion();
		String menPlano = instruccion.getMessageHolder().getMenPlano();
		log.info("Proceso generar swift concluido " + swiftDatos.getSwfMensaje().getMenCodoperacion() + " mt: " + swiftDatos.getSwfMensaje().getMenCodmt()
				+ " at (" + (System.currentTimeMillis() - buildTime) + " ms.)");
		if (StringUtils.isBlank(menPlano)) {
			throw new RuntimeException("Proceso de generacion de mensaje swift no produjo ningun resultado");
		}
	}

	public void obtenerFacts(SwiftDatos swiftDatos, CreateSwiftService createSwiftService) {
		Instruccion instr = createSwiftService.initInstruccion();
		SwfMsgParam hdr = instr.getSwfMsgParam();

		createSwiftService.addFact("instr", hdr);

		if (swiftDatos.getSocDetallessol() == null) {
			throw new RuntimeException("Detalle de la solicitud nulo, avise al administrador.");
		}
		Part frFI = factSender(swiftDatos);
		Part toFI = factReceiver(swiftDatos);
		Part dbtr = factDbtr(swiftDatos);
		Part cdtr = factCdtr(swiftDatos);
		Acc cdtrAcc = factCdtrAcc(swiftDatos, cdtr);		
		Part instrgAg = factInstrgAg(swiftDatos);
		Acc instrgAcc = factInstrgAgAcc(swiftDatos);
		Part instrdAg = factInstrdAg(swiftDatos);
		//instrdAcc, instrdAg, dbtrAg
		Ssi settlAg = instrdSettl(swiftDatos, instrgAcc, instrdAg, instrgAg);

		Part cdtrAg = factCdtrAg(swiftDatos, settlAg);
		Acc dbtrAcc = factDbtrAcc(swiftDatos);
		Acc cdtrAgAcc = factCdtrAgAcc(swiftDatos);
		Part intermAg = factIntrmy(swiftDatos);
		Part ultmtCdtr = factUltmtCdtr(swiftDatos, cdtrAcc);

		BkSrv sttlmAmt = sttlmAmt(swiftDatos);
		BkSrv amtDscnt = amtDscnt(swiftDatos);
		BkSrv amtOrd = amtOrd(swiftDatos);

		RmtInf rmtInf = rmtInfUstr(swiftDatos);
		RmtInf instrInf = instrInf(swiftDatos);

		createSwiftService.addFact("frFI", frFI);
		createSwiftService.addFact("toFI", toFI);
		createSwiftService.addFact("dbtr", dbtr);
		createSwiftService.addFact("cdtr", cdtr);
		createSwiftService.addFact("dbtrAg", instrgAg);
		createSwiftService.addFact("instrgAg", instrgAg);
		createSwiftService.addFact("instrgAcc", instrgAcc);
		createSwiftService.addFact("instrdAg", instrdAg);
		createSwiftService.addFact("settlAg", settlAg);
		createSwiftService.addFact("cdtrAg", cdtrAg);
		createSwiftService.addFact("dbtrAcc", dbtrAcc);
		createSwiftService.addFact("cdtrAcc", cdtrAcc);
		createSwiftService.addFact("cdtrAgAcc", cdtrAgAcc);
		createSwiftService.addFact("intrmyAg", intermAg);
		createSwiftService.addFact("ultmtCdtr", ultmtCdtr);
		createSwiftService.addFact("sttlmAmt", sttlmAmt);
		createSwiftService.addFact("amtDscnt", amtDscnt);
		createSwiftService.addFact("amtOrd", amtOrd);
		createSwiftService.addFact("rmtInf", rmtInf);
		createSwiftService.addFact("instrInf", instrInf);

	}

	private Part factSender(SwiftDatos swiftDatos) {
		Part sender = new Part();
		sender.setRole("frFI");

		BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByBic(swiftDatos.getSwfMensaje().getMenBicemisor());
		if (bancoPlazaSender != null) {
			sender = retPartAg(bancoPlazaSender);
		} else {
			log.warn("BIC emisor inexistente " + swiftDatos.getSwfMensaje().getMenBicemisor());
		}
		return sender;
	}

	private Part factReceiver(SwiftDatos swiftDatos) {
		Part sender = new Part();
		sender.setRole("toFI");

		BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByBic(swiftDatos.getSwfMensaje().getMenBic());
		if (bancoPlazaSender != null) {
			sender = retPartAg(bancoPlazaSender);
		} else {
			log.warn("BIC receiver inexistente " + swiftDatos.getSwfMensaje().getMenBic());
		}
		return sender;
	}

	private Part factInstrgAg(SwiftDatos swiftDatos) {
		Part sender = new Part();
		sender.setRole("instrgAg");

		BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByCod(Constants.COD_BCB_SWIFT);
		if (bancoPlazaSender != null) {
			sender = retPartAg(bancoPlazaSender);
		}
		return sender;
	}

	private Acc factInstrgAgAcc(SwiftDatos swiftDatos) {
		Acc instrdAcc = new Acc();
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		SocCuentas socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(swiftDatos.getSolicitudTO().getSolicitud(), swfMensaje.getMenCodmon(), null);
		if (socCuentas != null) {
			if (ValidatorCodes.isIban(socCuentas.getCtaNrocuenta())) {
				instrdAcc.setIban(socCuentas.getCtaNrocuenta());
			} else {
				instrdAcc.setIdacc(socCuentas.getCtaNrocuenta());
			}
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(swfMensaje.getMenCodmon());
			if (genMoneda != null)
				instrdAcc.setCurrExch(genMoneda.getMonSigla());
			instrdAcc.setAccDescr(socCuentas.getBenCodigo());
			instrdAcc.setIdaccint(socCuentas.getCtaCodigo().toString());
			instrdAcc.setDomi("SC");
		}
		return instrdAcc;
	}

	private Ssi instrdSettl(SwiftDatos swiftDatos, Acc instrdAcc, Part instrdAg, Part dbtrAg) {
//		instrgAcc, instrdAg, instrgAg
		Ssi ssi = new Ssi();
		ssi.setFinInst(instrdAg);
		ssi.setAccSttl(instrdAcc);

		SocCuentas socCuentas = socCuentasDao.getSocCuentasByCodigo(Integer.valueOf(instrdAcc.getIdaccint()));
		ssi.setMethodtype(socCuentas.getClaEsquema());
		ssi.setCurrency(instrdAcc.getCurrExch());
		if (socCuentas.getClaEsquema().equalsIgnoreCase("FW")) {
			ssi.setCountry("US");
		} else {
			String ctry = UtilsSwiftMkt.retCSMCtry(dbtrAg.getCtry(), instrdAcc.getCurrExch());
			ssi.setCountry(ctry);
		}
		ssi.setSecurity("CSH");
		return ssi;
	}

	private Part factInstrdAg(SwiftDatos swiftDatos) {
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		Part receiver = new Part();
		receiver.setRole("instrd");

		BancoPlaza bancoPlazaRec = socBancosDao.bancoPlazaByBic(swfMensaje.getMenBic());
		if (bancoPlazaRec != null) {
			receiver = retPartAg(bancoPlazaRec);
		}
		return receiver;
	}

	private Part factDbtr(SwiftDatos swiftDatos) {
		Part debtr = new Part();
		debtr.setRole("debtr");

		debtr.setCodPartInt(swiftDatos.getSolicitudTO().getSocSolicitante().getSolCodigo());
		debtr.setNm(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPersona());
		debtr.setAddress(swiftDatos.getSolicitudTO().getSocSolicitante().getSolDireccion());
		debtr.setTwnNm(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza());
		
		if (!StringUtils.isBlank(swiftDatos.getSolicitudTO().getSocSolicitante().getSolBic())) {
			BIC bic = new BIC(swiftDatos.getSolicitudTO().getSocSolicitante().getSolBic());
			debtr.setBic(bic.getBic11());
			debtr.setCtry(bic.getCountry());
		}
		
		if (!StringUtils.isBlank(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza())) {
			boolean isMatch = Pattern.matches("[A-Z]{2,2}/[^*&@]{1,}", swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza());
			if (isMatch) {
				debtr.setCtry(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza().substring(0, 2));
				debtr.setTwnNm(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza().substring(3));
			}
		}
		debtr.setStrtNm(swiftDatos.getSolicitudTO().getSocSolicitante().getSolIddirecc());
		debtr.setAcron(swiftDatos.getSolicitudTO().getSocSolicitante().getSigla());

		
		return debtr;
	}

	private Acc factDbtrAcc(SwiftDatos swiftDatos) {

		Acc debtrAcc = new Acc();

		SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(),
				Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);

		if (socSolicitudctas != null) {
			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(socSolicitudctas.getSolCodigo());
			if (socSolicitante != null) {
				if (socSolicitante.getSolCodigo().trim().equals(Constants.COD_BCB)) {

					if (ValidatorCodes.isIban(socSolicitudctas.getNroCuenta())) {
						debtrAcc.setIban(socSolicitudctas.getNroCuenta());
					} else {
						debtrAcc.setIdacc(socSolicitudctas.getNroCuenta());
					}

				} else {
					if (!StringUtils.isBlank(socSolicitante.getClaEntidad())) {
						if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
							debtrAcc.setTpAcc("ACC");
							debtrAcc.setIdacc(socSolicitudctas.getNroCuenta());
						} else if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTPUBLICO)) {
							debtrAcc.setTpAcc("LIB");
							debtrAcc.setIdacc(socSolicitudctas.getNroLibreta());
						}
					} else {
						throw new BusinessException("Error de parametrizacion, solicitante " + socSolicitudctas.getSolCodigo() + " sin tipo de entidad");
					}
				}
			} else {
				debtrAcc.setTpAcc("ACC");
				debtrAcc.setIdacc(socSolicitudctas.getNroCuenta());
			}
			debtrAcc.setAccDescr(socSolicitudctas.getDescripLibreta());
			debtrAcc.setContab(socSolicitudctas.getNroCuenta());
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socSolicitudctas.getCodMoneda());
			if (genMoneda != null)
				debtrAcc.setCurrExch(genMoneda.getMonSigla());
		}
		return debtrAcc;
	}

	private Part factCdtr(SwiftDatos swiftDatos) {
		Part cdtr = new Part();
		SocSolicitante socSolicitante = swiftDatos.getSolicitudTO().getSocSolicitante();
		SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(swiftDatos.getSocDetallessol().getBenCodigo());
		if (socBenefs != null) {
			cdtr = retPartBen(socBenefs);

			if (StringUtils.isBlank(cdtr.getBic()) && !StringUtils.isBlank(socSolicitante.getSolBic())) {
				BIC bic = new BIC(socSolicitante.getSolBic());
				cdtr.setBic(bic.getBic11());					
			}			
		}
		return cdtr;
	}

	private Acc factCdtrAcc(SwiftDatos swiftDatos, Part cdtr) {
		Acc accInstrd = new Acc();
		if (swiftDatos.getSocDetallessol() == null) {
			return accInstrd;
		}

		if (ValidatorCodes.isIban(swiftDatos.getSocDetallessol().getNroCuentabco())) {
			accInstrd.setIban(swiftDatos.getSocDetallessol().getNroCuentabco());
		} else {
			accInstrd.setIdacc(swiftDatos.getSocDetallessol().getNroCuentabco());
		}

		if (swiftDatos.getSocDetallessol().getCtaCodigo() != null && swiftDatos.getSocDetallessol().getCtaCodigo() > 0) {
			SocCuentas sc = socCuentasDao.getSocCuentasByCodigo(swiftDatos.getSocDetallessol().getCtaCodigo());
			if (sc != null) {
				accInstrd.setIdaccint(sc.getCtaCodigo().toString());
			}
		} else {
			List<SocCuentas> sc = socCuentasDao.cuentasExtByCod(null, swiftDatos.getSocDetallessol().getBenCodigo(),
					swiftDatos.getSocDetallessol().getCodBanco(), swiftDatos.getSocDetallessol().getNroCuentabco(),
					swiftDatos.getSocDetallessol().getCodMonedatdet(), swiftDatos.getSocDetallessol().getDetCodttransfer(), null);
			if (sc.size() > 0) {
				accInstrd.setIdaccint(sc.get(0).getCtaCodigo().toString());
			}
		}

		SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(swiftDatos.getSocDetallessol().getBenCodigo());
		if (socBenefs != null)
			accInstrd.setAccDescr(socBenefs.getBenNombre());

		GenMoneda genMoneda = genMonedaDao.findByCodMoneda(swiftDatos.getSocDetallessol().getCodMonedatdet());
		if (genMoneda != null)
			accInstrd.setCurrExch(genMoneda.getMonSigla());
		return accInstrd;
	}
	
	private Part factUltmtCdtr(SwiftDatos swiftDatos, Acc cdtrAcc) {
		Part UltmtCdtr = new Part();
//			List<Beneficiario> beneficiarios = socBenefsDao.beneficiariosExternosSolicitante(swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo(),
//					swiftDatos.getSocDetallessol().getBenCodigo(), swfMensaje.getMenCodmon(), null, false);
		if (cdtrAcc.getIdaccint() != null) {
			Integer idacc = ValidatorCodes.stringToInteger(cdtrAcc.getIdaccint());
			SocCuentas sc = socCuentasDao.getSocCuentasByCodigo(idacc);

			if (sc != null) {
				SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(sc.getBenCodultben());
				return retPartBen(socBenefs);
			}
		}
		return UltmtCdtr;
	}

	private Part factCdtrAg(SwiftDatos swiftDatos, Ssi settlAg) {
		Part accPart = new Part();
		BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBanco());
		if (bancoPlaza != null) {
			accPart = retPartAg(bancoPlaza);
		}
		if (ValidatorCodes.isAba(swiftDatos.getSocDetallessol().getNroCuentabcointer())) {
			accPart.setMmbId(swiftDatos.getSocDetallessol().getNroCuentabcointer());
		} else {
				if (ValidatorCodes.isAba(bancoPlaza.getPlaNrocuenta())) {
					accPart.setMmbId(bancoPlaza.getPlaNrocuenta());
				}
		}
		return accPart;
	}


	private Acc factCdtrAgAcc(SwiftDatos swiftDatos) {
		Acc accInterm = new Acc();
		if (!StringUtils.isBlank(swiftDatos.getSocDetallessol().getNroCuentabcointer())) {
			BancoPlaza bancoPlazaInt = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBancointer());
			if (bancoPlazaInt == null) {
				return accInterm;
			}
			SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(swiftDatos.getSocDetallessol().getBenCodigo());
			if (socBenefs != null) {
				accInterm.setAccDescr(socBenefs.getBenNombre());
			}
			if (ValidatorCodes.isIban(swiftDatos.getSocDetallessol().getNroCuentabcointer())) {
				accInterm.setIban(swiftDatos.getSocDetallessol().getNroCuentabcointer());
			} else {
				accInterm.setIdacc(swiftDatos.getSocDetallessol().getNroCuentabcointer());
			}
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(swiftDatos.getSocDetallessol().getCodMonedatdet());
			if (genMoneda != null)
				accInterm.setCurrExch(genMoneda.getMonSigla());
		}
		return accInterm;
	}

	private Part factIntrmy(SwiftDatos swiftDatos) {
		Part interm = new Part();
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		BancoPlaza bancoPlazaInt = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBancointer());
		if (bancoPlazaInt != null) {
			interm.setRole("interm");
			SocSolicitudes socSolicitudes = swiftDatos.getSolicitudTO().getSolicitud();
			SocDetallessol socDetallessol = swiftDatos.getSocDetallessol();
			List<SocCuentas> cuentasList = socCuentasDao.findCuentasExt(socSolicitudes.getSolCodigo(), socDetallessol.getBenCodigo(),
					socDetallessol.getCodBanco(), socDetallessol.getNroCuentabco(), socDetallessol.getCodMonedatdet(), socDetallessol.getNroCuentabcointer(),
					null, socDetallessol.getCodBancointer());

			if (cuentasList.size() >= 1) {
				if (cuentasList.size() > 1) {
					for (SocCuentas c : cuentasList) {
						if (!StringUtils.isBlank(c.getSolCodigo()) && c.getSolCodigo().equalsIgnoreCase(socSolicitudes.getSolCodigo())) {
							bancoPlazaInt = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBancointer());
							break;
						}
					}
				}

				interm = retPartAg(bancoPlazaInt);
				interm.setNm(bancoPlazaInt.getBcoNombre());
				interm.setTwnNm(bancoPlazaInt.getPlaNombre());
				interm.setCd(null);
			} else {
				if (bancoPlazaInt.getPlaBic() != null && !bancoPlazaInt.getPlaBic().equalsIgnoreCase(swfMensaje.getMenBic())) {
					interm = retPartAg(bancoPlazaInt);
				}
			}
		}
		return interm;
	}

	private BkSrv sttlmAmt(SwiftDatos swiftDatos) {
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();

		BkSrv bksrv = new BkSrv();
		bksrv.setTpcarg("sttlmAmt");
		bksrv.setAmt(swfMensaje.getMenMonto());
		bksrv.setDtExe(swfMensaje.getMenFecvalor());
		bksrv.setCurrPay(swfMensaje.getMenCodmonswift());

		return bksrv;
	}

	private BkSrv amtOrd(SwiftDatos swiftDatos) {
		BkSrv bksrv = new BkSrv();
		if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
			SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0, "MONTOORD");
			if (socOpecomi != null && socOpecomi.getMontoMo().compareTo(BigDecimal.valueOf(0)) > 0) {
				GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
				if (genMoneda != null) {
					BigDecimal montoOrd = socOpecomi.getMontoMo().setScale(2, RoundingMode.HALF_UP);
					bksrv = new BkSrv("amtOrd", "", genMoneda.getMonSigla(), montoOrd);
				}
			}

		}
		return bksrv;
	}

	private BkSrv amtDscnt(SwiftDatos swiftDatos) {
		BkSrv bksrv = new BkSrv();

		SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0, "MONTOORDCOMIS");
		if (socOpecomi != null) {
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
			if (genMoneda != null) {
				BigDecimal montoOrd = socOpecomi.getMontoMo().setScale(2, RoundingMode.HALF_UP);
				bksrv = new BkSrv("ordnComisAmt", "", genMoneda.getMonSigla(), montoOrd);
			}
		}
		return bksrv;
	}

	private RmtInf rmtInfUstr(SwiftDatos swiftDatos) {
		RmtInf rmtInf = new RmtInf();

		if (!StringUtils.isBlank(swiftDatos.getSolicitudTO().getSolicitud().getDetConcepto())) {
			rmtInf.setTpRmtInf("USTR");
			String valor = swiftDatos.getSocDetallessol().getTipoConcepto();
			rmtInf.setCd(swiftDatos.getSocDetallessol().getTipoConcepto());
			if (!StringUtils.isBlank(valor) && valor.equals("INV")) {
				valor = "/" + swiftDatos.getSocDetallessol().getTipoConcepto() + "/";
				valor = valor.concat(swiftDatos.getSolicitudTO().getSolicitud().getDetConcepto().trim());
			} else {
				valor = swiftDatos.getSolicitudTO().getSolicitud().getDetConcepto().trim();
			}
			rmtInf.setUstrd(valor);
		}
		return rmtInf;
	}

	private RmtInf instrInf(SwiftDatos swiftDatos) {
		RmtInf rmtInf = new RmtInf();

		if (!StringUtils.isBlank(swiftDatos.getSocDetallessol().getDetInfo())) {
			rmtInf.setTpRmtInf("NXTAG");
			String valor = swiftDatos.getSocDetallessol().getDetInfo();
			rmtInf.setUstrd(valor);
		}
		return rmtInf;
	}

	public static Part retPartAg(BancoPlaza bancoPlaza) {
		Part receiver = new Part();
		if (!StringUtils.isBlank(bancoPlaza.getPlaBic())) {
			BIC bic = new BIC(bancoPlaza.getPlaBic());
			receiver.setBic(bic.getBic11());
			receiver.setCtry(bic.getCountry());
		}

		receiver.setNm(bancoPlaza.getBcoNombre());
		receiver.setTwnNm(bancoPlaza.getPlaNombre());
		receiver.setCodPartInt(bancoPlaza.getSocBancos() != null ? bancoPlaza.getSocBancos().getBcoCodigo() : "");
		receiver.setDomi("BC");
		receiver.setDn(bancoPlaza.getSocBancos() != null ? bancoPlaza.getSocBancos().getBcoDn() : "");
		
		if (ValidatorCodes.isAba(bancoPlaza.getPlaNrocuenta())) {
			receiver.setMmbId(bancoPlaza.getPlaNrocuenta());
		}
		return receiver;
	}

	public static Part retPartBen(SocBenefs socBenefs) {
		Part cdtr = new Part();
		if (socBenefs == null)
			return cdtr;
		cdtr.setNm(socBenefs.getBenNombre());
		cdtr.setTwnNm(socBenefs.getBenPlaza());
		
		if (!StringUtils.isBlank(socBenefs.getBenBic())) {
			BIC bic = new BIC(socBenefs.getBenBic());
			cdtr.setBic(bic.getBic11());
			cdtr.setCtry(bic.getCountry());			
		}
		
		if (!StringUtils.isBlank(socBenefs.getBenPlaza())) {
			boolean isMatch = Pattern.matches("[A-Z]{2,2}/[^*&@]{1,}", socBenefs.getBenPlaza());
			if (isMatch) {
				cdtr.setCtry(socBenefs.getBenPlaza().substring(0, 2));
				cdtr.setTwnNm(socBenefs.getBenPlaza().substring(3));
			}
		}
		cdtr.setStrtNm(socBenefs.getBenDireccion());
		cdtr.setCtrySubDvsn(socBenefs.getBenSubregion());
		cdtr.setDept(socBenefs.getBenDept());
		cdtr.setPstCd(socBenefs.getBenCodpostal());
		cdtr.setBldgNb(socBenefs.getBenNroedif());
		cdtr.setBldgNm(socBenefs.getBenIddirecc());
		cdtr.setCodPartInt(socBenefs.getBenCodigo());

		return cdtr;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void inicializar() {
		swfMttransferLocal.setSessionFactory(getSessionFactory());
		swfPersonactaLocal.setSessionFactory(getSessionFactory());
		swfMensajeLocal.setSessionFactory(getSessionFactory());
		swfDetmensajeLocal.setSessionFactory(getSessionFactory());
		socBancosDao.setSessionFactory(getSessionFactory());
		socBenefsDao.setSessionFactory(getSessionFactory());
		swfMencamposDbDao.setSessionFactory(getSessionFactory());
		swfMencamposIsoDaoImpl.setSessionFactory(sessionFactory);
		socCuentassolDao.setSessionFactory(sessionFactory);
		socSolicitudctasDao.setSessionFactory(sessionFactory);
		socSolicitanteDao.setSessionFactory(sessionFactory);
		genMonedaDao.setSessionFactory(sessionFactory);
		socOpecomiDao.setSessionFactory(sessionFactory);
		socCuentasDao.setSessionFactory(sessionFactory);

	}

	public static void main(String[] args) {

		System.out.println("FD/52sad  asdf" + " " + "FD/52sad  asdf".substring(0, 2));
		System.out.println("FD/52sad  asdf" + " " + "FD/52sad  asdf".substring(3));
	}
}
