package gob.bcb.bpm.pruebaCU;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.service.servicioSioc.common.Constants;

public class ExpExporttrxDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(ExpExporttrxDao.class);

	public ExpExporttrx saveOrUpdate(ExpExporttrx pm) {
		pm.setExtAuditfho(new Date());
		ExpExporttrx pmN = this.getHibernateTemplate().merge(pm);
		log.info("Export creado " + pmN.getExtCodexpo());
		return pmN; //this.getHibernateTemplate().merge(pm);
	}

	public Optional<ExpExporttrx> findByCodexpo(Integer extCodexpo) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from ExpExporttrx cc ");
		query = query.append("where cc.extCodexpo = :extCodexpo ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("extCodexpo", extCodexpo);

		List<ExpExporttrx> lista = consulta.list();

		if (lista.size() > 0) {
			return Optional.of(lista.get(0));
		}
		
		return Optional.empty();
	}

	public Optional<ExpExporttrx> findBySocCodigo(String extSoccodigo) {
		if (StringUtils.isBlank(extSoccodigo)) {
			return Optional.empty();
		}
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from ExpExporttrx cc ");
		query = query.append("where cc.extSoccodigo = :extSoccodigo ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("extSoccodigo", extSoccodigo);

		List<ExpExporttrx> lista = consulta.list();

		if (lista.size() > 0) {
			return Optional.of(lista.get(0));
		}
		
		return Optional.empty();
	}

	public static ExpExporttrx newExport() {
		ExpExporttrx e = new ExpExporttrx();
		e.setExtMontomo(BigDecimal.ZERO);
		e.setExtMontomn(BigDecimal.ZERO);
		e.setExtCodmonmo(Constants.COD_MONEDA_USD.toString());
		e.setExtFecha(new Date());
		e.setExtFechorecep(new Date());
		
		return e;
	}
	

}
