package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ExpExporttrxdetPK  implements Serializable{
	private static final long serialVersionUID = 1L;
	@Column(name = "dex_codexpo")
	private Integer dexCodexpo;
	@Column(name = "dex_nrodet")
	private Integer dexNrodet;
	public ExpExporttrxdetPK() {
	}
	public Integer getDexCodexpo() {
		return dexCodexpo;
	}
	public void setDexCodexpo(Integer dexCodexpo) {
		this.dexCodexpo = dexCodexpo;
	}
	public Integer getDexNrodet() {
		return dexNrodet;
	}
	public void setDexNrodet(Integer dexNrodet) {
		this.dexNrodet = dexNrodet;
	}
	@Override
	public int hashCode() {
		return Objects.hash(dexCodexpo, dexNrodet);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExpExporttrxdetPK other = (ExpExporttrxdetPK) obj;
		return Objects.equals(dexCodexpo, other.dexCodexpo) && Objects.equals(dexNrodet, other.dexNrodet);
	}

	
}
