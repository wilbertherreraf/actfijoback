package gob.bcb.core.jms;

import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.utils.JAXBHelper;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.UtilsNet;
import gob.bcb.core.utils.UtilsXmlBind;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.IllegalStateException;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TemporaryQueue;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

public abstract class BcbMsgAbstract {
	private static Logger log = Logger.getLogger(BcbMsgAbstract.class);
	/**
	 * nombre del feature dentro del servicio de negocio o BPM
	 */
	private String nameQueueTopic;
	private Map<String, Object> parameters = new HashMap<String, Object>();
	private Map<String, Object> propiedades = new HashMap<String, Object>();
	private Object mensajeBCBJAXB;
	private Object body;
	private Message jmsMessage;
	private Session jmsSession;
	private JMSBinding binding;
	private MessageConsumer replyConsumer = null;
	private boolean typeDestinationQueue = true;
	private boolean disableReplyTo;
	private boolean printed = true;
	private Destination destination;
	private long startTime;
	private JMSConnectionHandler jMSConnectionHandler;

	private final static JAXBContext jAXBContext;
	static {
		try {
			jAXBContext = JAXBContext.newInstance("gob.bcb.core.jms.model");
			log.debug("Contexto objetos JAXB iniciado");
		} catch (JAXBException e) {
			log.error("Error al inicializar contexto JAXB " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}
//	private final static Map<Class<?>, JAXBContext> contexts = new HashMap<Class<?>, JAXBContext>();
	private static DocumentBuilderFactory documentBuilderFactory;

	public BcbMsgAbstract() {
		startTime = System.currentTimeMillis();
//		try {
//			propiedades.put("BCBAddress", UtilsNet.getAddressHost());
//			propiedades.put("BCBIdemisor", UtilsNet.getNameHost());
//		} catch (Exception e) {
//		}
//		propiedades.put("BCBIdemisor", "localhost");
		//propiedades.put("BCBAddress", UtilsNet.getAddressHost());
		propiedades.put("BCBIddestinatario", "default");
		propiedades.put("BCBIdusuario", "localhost");
		propiedades.put("BCBPasswmd5", "");
		propiedades.put("BCBIdsistema", "system");
		propiedades.put("BCBNrooperacion", UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + UtilsGeneric.generateUUID());
		propiedades.put("BCBIdoperacion", "default");
	}

	public BcbMsgAbstract(Message jmsMessage) {
		setJmsMessage(jmsMessage);
	}

	public BcbMsgAbstract(Message jmsMessage, Session session) {
		setJmsMessage(jmsMessage);
		jmsSession = session;
	}

	public abstract void setPropiedadesFromMsgBcb();

	public abstract void setMsgBcbFromPropiedades();

	public abstract void updateMsgsistemaresp(String statusCode, String statusDescription, Object tipoJAXBEleASubtituir);

	/**
	 * implementar si el body es nulo que tipo de mensaje se lleva
	 */
	protected void setBodyMsgBcb() {

		if (body == null) {
			// por defecto es XML
			try {
				setBody(toString(getMensajeBCBJAXB()));
				getRequestElements().clear();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				throw new RuntimeException(e);
			}
		}
	}


	public void sendResponseBcbMsg(String statusCode, String consent) throws JAXBException, ParserConfigurationException, TransformerException {
		updateMsgsistemaresp(statusCode, consent, null);
		if (isDisableReplyTo() || destination == null) {
			log.warn("Mensaje sin destino de respuesta");
			return;
		}

		try {
			Message response = createMessage();
			setJmsMessage(response);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
		sendResponse();
	}

	private static final int deliveryMode = DeliveryMode.NON_PERSISTENT;
	private static final int priority = 5;
	public void sendResponse() {
		MessageProducer producer = null;
		try {
			log.info(">>>>Mensaje<<<<<<<<<<<<< ");			
			producer = jmsSession.createProducer(destination);
			jmsMessage.setJMSType(body.getClass().getName());
			producer.setDeliveryMode(deliveryMode);
			producer.send(jmsMessage);
			long endTime = System.currentTimeMillis();
			log.info(">>>Mensaje de respuesta enviada [duracion: " + TimeUnit.MILLISECONDS.convert(endTime - startTime, TimeUnit.MILLISECONDS)
					+ "(ms)]:\n" + producer.toString());
		} catch (Exception e) {
			log.error("ESTO ES HORRRIBLE ERROR FATAL!!!!!: no se pudo enviar mensaje de respuesta " + e.getMessage(), e);
			throw new RuntimeException(e);
		} finally {
			if (producer != null) {
				try {
					producer.close();
					log.warn("producer de response JMS cerrado...");
				} catch (JMSException e) {
					log.error("Error al cerrar session JMS " + e.getMessage(), e);
				}
			}
		}
	}

	public StatusResponse sendMessage() {


		startTime = System.currentTimeMillis();
		try {
			send();

			if (!isDisableReplyTo()) {
				StatusResponse statusResponse = procesarResponseMsgIn();
				long endTime = System.currentTimeMillis();
				log.info("Respuesta recibida satisfactoriamente. (" + (endTime - startTime) + " ms.)");
				//getJMSConnectionHandler().closeConsumer(getJmsMessage().getJMSReplyTo());
				return statusResponse;
			}
			StatusResponse statusResponse = new StatusResponse();
			statusResponse.setStatusCode("OK");
			statusResponse.setDescrip("OK");
			return statusResponse; 
			
		} catch (NullPointerException e) {
			log.error("error al procesarResponse JMS " + e.getMessage(), e);
			StatusResponse statusResponse = new StatusResponse();
			statusResponse.setStatusCode("NullPointerException");
			statusResponse.setDescrip(e.getMessage());
			return statusResponse; 

		} catch (Exception e) {
			log.error("error al cerrar consumers JMS " + e.getMessage(), e);
			StatusResponse statusResponse = new StatusResponse();
			statusResponse.setStatusCode("Exception");
			statusResponse.setDescrip(e.getMessage());
			return statusResponse;
		} 
	}

	public void send() {
		try {
			if (jmsMessage == null) {
				Message msgOut = createMessage();
				setJmsMessage(msgOut);
			}

			try {
				if (isTypeDestinationQueue()) {
					destination = jmsSession.createQueue(nameQueueTopic);
				} else {
					destination = jmsSession.createTopic(nameQueueTopic);
				}
			} catch (JMSException e) {
				log.error("Ocurrio un error en el proceso de envio/recepcion del mensaje se intentara reconectar." + e.getMessage(), e);
				throw new JMSException(e.getMessage());				
//				try {
//					getJMSConnectionHandler().reConnect();
//					setJmsSession(getJMSConnectionHandler().getSession());
//					if (isTypeDestinationQueue()) {
//						destination = getJmsSession().createQueue(nameQueueTopic);
//					} else {
//						destination = getJmsSession().createTopic(nameQueueTopic);
//					}
//				} catch (JMSException e1) {
//					log.error("Error al reconectar " + e1.getMessage(), e1);
//					getJMSConnectionHandler().close();
//					throw new JMSException(e1.getMessage());
//				}
			}

			if (!isDisableReplyTo()) {
				TemporaryQueue confirmQueue = jmsSession.createTemporaryQueue();
				jmsMessage.setJMSReplyTo(confirmQueue);
				// getJmsMessage().setJMSExpiration(2000);
				//replyConsumer = getJMSConnectionHandler().getConsumer(confirmQueue);
				replyConsumer = jMSConnectionHandler.createConsumer(confirmQueue, true);
			}
			jMSConnectionHandler.send(destination, jmsMessage, false, 5, 120000);
			//getJMSConnectionHandler().send(destination, getJmsMessage());
			if (isPrinted())
				log.info("Mensaje request enviado: \n" + printMessage());
		} catch (Exception e) {
			log.error("error al enviar mensaje: " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public Object extractBodyAndParams(Message message) {
		Object bodyMsgIn = null;
		try {
			if (message == null) {
				log.error("Mensaje NULO");
				throw new Exception("Mensaje NULO");
			}

			propiedades = getBinding().extractHeadersFromJms(message);

			bodyMsgIn = getBinding().extractBodyFromJms(message);

			if (bodyMsgIn == null) {
				log.error("No se pudo recuperar contenido del mensaje");
				throw new Exception("No se pudo recuperar contenido del mensaje");
			}

			if (bodyMsgIn instanceof String) {
				Object mensajeJAXB = null;
				try {
					String mens =  (String) bodyMsgIn;

					mensajeJAXB = JAXBHelper.convertXMLToMsgBcb(mens, jAXBContext);
					mensajeBCBJAXB = mensajeJAXB;
					// TransformSirAladi transformSirAladi = new
					// TransformSirAladi();
					// Map<String, Object> params =
					// transformSirAladi.fromXMLToJPA(null, mensajeJAXB);
					// setRequestElements(params);
					// setPropiedadesFromMsgBcb();
				} catch (Exception e) {
					if (propiedades.containsKey("JMSType") && (propiedades.get("JMSType") != null)
							&& ((String) propiedades.get("JMSType")).equals(String.class.getName())) {
						// si tiene el parametro en el header se valida como
						// string
						log.warn("Se valida el contenido del mensaje como string " + e.getMessage(), e);
					} else {
						log.error(e.getMessage(), e);
						throw new RuntimeException(e);
					}
				}

			} else {
				Map<String, Object> params = getBinding().getParamsFromMessage(message, propiedades);
				setRequestElements(params);
				setMsgBcbFromPropiedades();
			}
			setBody(bodyMsgIn);
		} catch (Exception e) {
			log.error("Error en la recepcion del mensaje " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
		return bodyMsgIn;
	}

	public Object procesarMsgIn() {
		Object bodyMsgIn = extractBodyAndParams(jmsMessage);
		return bodyMsgIn;
	}

	protected Message createMessage() throws Exception {
		if (jmsSession == null) {
			jmsSession = jMSConnectionHandler.getSession();
		}
		setBodyMsgBcb();
		Message response = null;
		try {
			if (body instanceof byte[] || body instanceof Map) {
				setPropiedadesFromMsgBcb();
				getRequestElements().putAll(getBinding().extractParamsFilter(propiedades));
				response = getBinding().createJmsMessage(body, getRequestElements(), jmsSession);
			} else if (body instanceof String) {
				response = getBinding().createJmsMessage(body, getRequestElements(), jmsSession);
			} else {
				setPropiedadesFromMsgBcb();
				getRequestElements().putAll(getBinding().extractParamsFilter(propiedades));
				response = getBinding().createJmsMessage(body, getRequestElements(), jmsSession);
			}
			response.setJMSCorrelationID(determineCorrelationId(response));
		} catch (IllegalStateException e) {
			log.error("Error al crear mensaje reconectando: " + e.getMessage(), e);
			throw new Exception("Error al crear mensaje, " + e.getMessage(), e);
//			try {
//				getJMSConnectionHandler().reConnect();
//				setJmsSession(getJMSConnectionHandler().getSession());
//				if (isTypeDestinationQueue()) {
//					destination = getJmsSession().createQueue(nameQueueTopic);
//				} else {
//					destination = getJmsSession().createTopic(nameQueueTopic);
//				}
//
//			} catch (Exception e1) {
//				getJMSConnectionHandler().close();
//				throw new Exception("Error al crear mensaje, fallo en la reconecci�n " + e1.getMessage(), e1);
//			}
//			log.error("XXX: ULALAAAAAAA!!!! llamada recursiva : ");
//			response = createMessage();
		} catch (Exception e) {
			log.error("Error al Generico crear mensaje: " + e.getMessage(), e);
			throw new Exception(e);
		}
		return response;
	}

	public abstract StatusResponse procesarResponseMsgIn();

	public void setJmsMessage(Message jmsMessage) {
		this.jmsMessage = jmsMessage;
	}

	public Message getJmsMessage() {
		return jmsMessage;
	}

	public JMSBinding getBinding() {
		if (binding == null) {
			binding = new JMSBinding();
		}
		return binding;
	}

	public void setBinding(JMSBinding binding) {
		this.binding = binding;
	}

	public String printMessage() {
		StringBuilder result = new StringBuilder();

		// result.append(getPropiedades().toString());
		// result.append(getRequestElements().toString());
		// Enumeration names;
		// try {
		// names = getJmsMessage().getPropertyNames();
		// } catch (JMSException e) {
		// throw new RuntimeException(e);
		// }
		// while (names.hasMoreElements()) {
		// String name = names.nextElement().toString();
		// try {
		// Object value = getJmsMessage().getObjectProperty(name);
		// result.append(name + " = " + value);
		// } catch (JMSException e) {
		// result.append(name + " = tipo valor desconocido");
		// }
		// result.append("\n");
		// }
		// result.append(" ===================body=======================\n");
		if (body == null) {
			result.append(getBinding().extractBodyFromJms(jmsMessage));
		} else {
			result.append(body);
		}
		// result.append("\n===================body=======================\n");
		return result.toString();
	}

	public String toString(Object value) throws JAXBException, ParserConfigurationException, TransformerException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		// Document doc = JAXBHelper.toDocument(value, documentBuilderFactory,
		// getJaxbContext(value));
		Document doc = JAXBHelper.toDocument(value, documentBuilderFactory, getJaxbcontext());
		return UtilsXmlBind.getStringFromDom(doc);

	}

	protected String determineCorrelationId(Message message) throws JMSException {
		final String provisionalCorrelationId = (String) propiedades.get("JMSCorrelationID");

		if (provisionalCorrelationId != null) {
			return provisionalCorrelationId;
		}

		final String messageId = message.getJMSMessageID();
		final String correlationId = message.getJMSCorrelationID();
		if (correlationId == null || correlationId.trim().isEmpty()) {
			// correlation id is empty so fallback to message id
			return messageId;
		} else {
			return correlationId;
		}
	}

//	private synchronized JAXBContext getJaxbContext(Object value) throws JAXBException {
//		Class<?> type = value.getClass();
//		JAXBContext context = contexts.get(type);
//		if (context == null) {
//			context = JAXBContext.newInstance(type);
//			contexts.put(type, context);
//		}
//		return context;
//	}

	public void addDescripcionParametro(String paramName, Object objeto) {
		parameters.put(paramName, objeto);
	}

	public String getIdTipoOperacion() {
		return (String) propiedades.get("BCBIdoperacion");
	}

	public Map<String, Object> getRequestElements() {
		return this.parameters;
	}

	public void setRequestElements(Map<String, Object> parameters) {
		this.parameters = parameters;
	}

	public void setJmsSession(Session jmsSession) {
		this.jmsSession = jmsSession;
	}

	public Session getJmsSession() {
		return jmsSession;
	}

	public void setNameQueueTopic(String nameQueueTopic) {
		this.nameQueueTopic = nameQueueTopic;
	}

	public String getNameQueueTopic() {
		return nameQueueTopic;
	}

	public void setBody(Object body) {
		this.body = body;
	}

	public Object getBody() {
		return body;
	}

	public void setPropiedades(Map<String, Object> propiedades) {
		this.propiedades = propiedades;
	}

	public Map<String, Object> getPropiedades() {
		return propiedades;
	}

	public void setMensajeBCBJAXB(Object mensajeBCBJAXB) {
		this.mensajeBCBJAXB = mensajeBCBJAXB;
	}

	public Object getMensajeBCBJAXB() {
		return this.mensajeBCBJAXB;
	}

	public static JAXBContext getJaxbcontext() {
		return jAXBContext;
	}

	public void setReplyConsumer(MessageConsumer replyConsumer) {
		this.replyConsumer = replyConsumer;
	}

	public MessageConsumer getReplyConsumer() {
		return replyConsumer;
	}

	public void setDisableReplyTo(boolean disableReplyTo) {
		this.disableReplyTo = disableReplyTo;
	}

	public boolean isDisableReplyTo() {
		return disableReplyTo;
	}

	public void setTypeDestinationQueue(boolean typeDestinationQueue) {
		this.typeDestinationQueue = typeDestinationQueue;
	}

	public boolean isTypeDestinationQueue() {
		return typeDestinationQueue;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	public Destination getDestination() {
		return destination;
	}

	public void setPrinted(boolean printed) {
		this.printed = printed;
	}

	public boolean isPrinted() {
		return printed;
	}

	public void setJMSConnectionHandler(JMSConnectionHandler jMSConnectionHandler) {
		this.jMSConnectionHandler = jMSConnectionHandler;
	}

	public JMSConnectionHandler getJMSConnectionHandler0() {
		if (jMSConnectionHandler == null) {
			jMSConnectionHandler = new JMSConnectionHandler();
		}
		return jMSConnectionHandler;
	}

}

