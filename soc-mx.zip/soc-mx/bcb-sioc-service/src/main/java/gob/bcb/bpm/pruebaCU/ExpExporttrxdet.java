package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="exp_exporttrxdet")

public class ExpExporttrxdet implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private ExpExporttrxdetPK id;
	@Column(name = "dex_coddetorig")
	private String dexCoddetorig;
	@Column(name = "dex_montomo")
	private BigDecimal dexMontomo;
	@Column(name = "dex_codmonmo")
	private String dexCodmonmo;
	@Column(name = "dex_montopar")
	private BigDecimal dexMontopar;
	@Column(name = "dex_codmonpar")
	private String dexCodmonpar;
	@Column(name = "dex_montomn")
	private BigDecimal dexMontomn;	
	@Column(name = "dex_montousd")
	private BigDecimal dexMontousd;
	@Column(name = "dex_montodiff")
	private BigDecimal dexMontodiff;
	@Temporal(TemporalType.DATE)	
	@Column(name = "dex_fechavig")
	private Date dexFechavig;
	@Column(name = "dex_tramo")
	private String dexTramo;
	@Column(name = "dex_ctatramo")
	private String dexCtatramo;	
	@Column(name = "dex_tctramo")
	private BigDecimal dexTctramo;
	@Column(name = "dex_tcorig")
	private BigDecimal dexTcorig;
	@Column(name = "dex_tccont")
	private BigDecimal dexTccont;
	@Column(name = "dex_nrofact")
	private String dexNrofact;
	@Column(name = "dex_exportador")
	private String dexExportador;
	@Column(name = "dex_nit")
	private String dexNit;
	@Column(name = "dex_tramite")
	private String dexTramite;
	@Column(name = "dex_nrodoc")
	private String dexNrodoc;	
	@Temporal(TemporalType.DATE)	
	@Column(name = "dex_fecvalid")
	private Date dexFecvalid;
	@Temporal(TemporalType.DATE)
	@Column(name = "dex_fecconfirma")
	private Date dexFecconfirma;
	@Column(name = "dex_patron")
	private String dexPatron;
	@Column(name = "dex_docexport")
	private String dexDocexport;
	@Column(name = "dex_paisdest")
	private String dexPaisdest;
	@Column(name = "dex_descrip")
	private String dexDescrip;
	@Column(name = "dex_sector")
	private String dexSector;
	@Column(name = "dex_estdettrx")
	private String dexEstdettrx;
	
	@Column(name = "dex_auditusr")
	private String dexAuditusr;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dex_auditfho")
	private Date dexAuditfho;
	@Column(name = "dex_auditwst")
	private String dexAuditwst;

	public ExpExporttrxdet() {
	}
	
	public ExpExporttrxdetPK getId() {
		return id;
	}
	public void setId(ExpExporttrxdetPK id) {
		this.id = id;
	}
	
	public String getDexCoddetorig() {
		return dexCoddetorig;
	}
	public void setDexCoddetorig(String dexCoddetorig) {
		this.dexCoddetorig = dexCoddetorig;
	}
	public BigDecimal getDexMontomo() {
		return dexMontomo;
	}
	public void setDexMontomo(BigDecimal dexMontomo) {
		this.dexMontomo = dexMontomo;
	}
	public String getDexCodmonmo() {
		return dexCodmonmo;
	}
	public void setDexCodmonmo(String dexCodmonmo) {
		this.dexCodmonmo = dexCodmonmo;
	}
	public BigDecimal getDexMontopar() {
		return dexMontopar;
	}
	public void setDexMontopar(BigDecimal dexMontomn) {
		this.dexMontopar = dexMontomn;
	}
	public String getDexCodmonpar() {
		return dexCodmonpar;
	}
	public void setDexCodmonpar(String dexCodmonmn) {
		this.dexCodmonpar = dexCodmonmn;
	}
	public String getDexTramo() {
		return dexTramo;
	}
	public void setDexTramo(String dexTramo) {
		this.dexTramo = dexTramo;
	}
	public BigDecimal getDexTctramo() {
		return dexTctramo;
	}
	public void setDexTctramo(BigDecimal dexTctramo) {
		this.dexTctramo = dexTctramo;
	}
	public BigDecimal getDexTccont() {
		return dexTccont;
	}
	public void setDexTccont(BigDecimal dexTccont) {
		this.dexTccont = dexTccont;
	}
	public String getDexNrofact() {
		return dexNrofact;
	}
	public void setDexNrofact(String dexNrofact) {
		this.dexNrofact = dexNrofact;
	}
	public String getDexExportador() {
		return dexExportador;
	}
	public void setDexExportador(String dexExportador) {
		this.dexExportador = dexExportador;
	}
	public String getDexNit() {
		return dexNit;
	}
	public void setDexNit(String dexNit) {
		this.dexNit = dexNit;
	}
	public String getDexTramite() {
		return dexTramite;
	}
	public void setDexTramite(String dexTramite) {
		this.dexTramite = dexTramite;
	}
	public Date getDexFecvalid() {
		return dexFecvalid;
	}
	public void setDexFecvalid(Date dexFecvalid) {
		this.dexFecvalid = dexFecvalid;
	}
	public Date getDexFecconfirma() {
		return dexFecconfirma;
	}
	public void setDexFecconfirma(Date dexFecconfirma) {
		this.dexFecconfirma = dexFecconfirma;
	}
	public String getDexPatron() {
		return dexPatron;
	}
	public void setDexPatron(String dexPatron) {
		this.dexPatron = dexPatron;
	}
	public String getDexDocexport() {
		return dexDocexport;
	}
	public void setDexDocexport(String dexDocexport) {
		this.dexDocexport = dexDocexport;
	}
	public String getDexPaisdest() {
		return dexPaisdest;
	}
	public void setDexPaisdest(String dexPaisdest) {
		this.dexPaisdest = dexPaisdest;
	}
	public String getDexDescrip() {
		return dexDescrip;
	}
	public void setDexDescrip(String dexDescrip) {
		this.dexDescrip = dexDescrip;
	}
	public String getDexSector() {
		return dexSector;
	}
	public void setDexSector(String dexSector) {
		this.dexSector = dexSector;
	}
	public String getDexEstdettrx() {
		return dexEstdettrx;
	}
	public void setDexEstdettrx(String dexEstdettrx) {
		this.dexEstdettrx = dexEstdettrx;
	}
	public String getDexAuditusr() {
		return dexAuditusr;
	}
	public void setDexAuditusr(String dexAuditusr) {
		this.dexAuditusr = dexAuditusr;
	}
	public Date getDexAuditfho() {
		return dexAuditfho;
	}
	public void setDexAuditfho(Date dexAuditfho) {
		this.dexAuditfho = dexAuditfho;
	}
	public String getDexAuditwst() {
		return dexAuditwst;
	}
	public void setDexAuditwst(String dexAuditwst) {
		this.dexAuditwst = dexAuditwst;
	}

	public BigDecimal getDexMontousd() {
		return dexMontousd;
	}

	public void setDexMontousd(BigDecimal dexMontousd) {
		this.dexMontousd = dexMontousd;
	}

	public String getDexCtatramo() {
		return dexCtatramo;
	}

	public void setDexCtatramo(String dexCtatramo) {
		this.dexCtatramo = dexCtatramo;
	}

	public Date getDexFechavig() {
		return dexFechavig;
	}

	public void setDexFechavig(Date dexFechavig) {
		this.dexFechavig = dexFechavig;
	}

	public BigDecimal getDexMontomn() {
		return dexMontomn;
	}

	public void setDexMontomn(BigDecimal dexMontomn) {
		this.dexMontomn = dexMontomn;
	}

	public BigDecimal getDexTcorig() {
		return dexTcorig;
	}

	public void setDexTcorig(BigDecimal dexTcorig) {
		this.dexTcorig = dexTcorig;
	}

	public BigDecimal getDexMontodiff() {
		return dexMontodiff;
	}

	public void setDexMontodiff(BigDecimal dexMontodiff) {
		this.dexMontodiff = dexMontodiff;
	}

	public String getDexNrodoc() {
		return dexNrodoc;
	}

	public void setDexNrodoc(String dexNrodoc) {
		this.dexNrodoc = dexNrodoc;
	}
	
	
}
