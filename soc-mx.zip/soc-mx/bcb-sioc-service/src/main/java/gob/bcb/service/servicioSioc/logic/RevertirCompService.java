package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.joda.time.DateTime;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.bpm.pruebaCU.SocRengscompId;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

public class RevertirCompService {
	private static final Log log = LogFactory.getLog(RevertirCompService.class);
	private SocComprobanteDao comprobanteDao = new SocComprobanteDao();
	private SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
	private SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
	private SocRengscompDao socRengscompDao = new SocRengscompDao();
	private RenglonesComprobantes renglonesComprobantes = new RenglonesComprobantes();
	
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		socEsquemasDao.setSessionFactory(getSessionFactory());
		socSolicitudesDao.setSessionFactory(getSessionFactory());
		comprobanteDao.setSessionFactory(getSessionFactory());
		renglonesComprobantes.setSessionFactory(sessionFactory);
		socRengscompDao.setSessionFactory(sessionFactory);
	}

	public Solicitud generaReversa(Solicitud solicitud) {
		List<SocComprobante> socComprobanteLista = solicitud.getSocComprobanteLista();
		if (socComprobanteLista.size() == 0) {
			throw new BusinessException("Parametro SocComprobanteLista sin elementos");
		}
		SocComprobante socCompr = socComprobanteLista.get(0);
		SocComprobante socComprobante = comprobanteDao.getComprobante(socCompr.getCpbCodigo());
		if (socComprobante == null) {
			throw new BusinessException("Comprobante "+ socCompr.getCpbCodigo() +" inexistente o suspendido");
		}
		
		if (StringUtils.isBlank(socComprobante.getCveEstadocpb()) || !socComprobante.getCveEstadocpb().equals(Constants.CLAVE_ESTCOMP_CONTAB)) {
			throw new BusinessException("La operacion contable '" + socCompr.getCpbCodigo() + "' con estado '" + socComprobante.getCveEstadocpb() + "' invalido no puede modificar");
		}
		
		if (StringUtils.isBlank(socComprobante.getCpbNrocpbte())) {
			throw new BusinessException("La operacion contable '" + socCompr.getCpbCodigo() + "' sin numero de comprobante COIN, no puede modificar.");
		}
		SocEsquemas socEsquemasOrg = socEsquemasDao.esquemaByCod(socComprobante.getEsqCodigo());
		
		creaComprobante(solicitud, socComprobante,socEsquemasOrg, 0, "R", socComprobante.getCpbCodigo(),null, null);
		return solicitud;
	}
	
	private SocComprobante creaComprobante(Solicitud solicitud, SocComprobante socComprob,SocEsquemas socEsquemas, Integer detCodigo, String cveDettipocomp, String cpbCodigoref,
			String genera, Map<String, Object> paramsGlosa) {

		log.info("+++En generar REVERSA COMPROBANTE SOLO : " + solicitud.getSolicitud().toString() + " cveDettipocomp " + cveDettipocomp + " tipoComprob ==> "
				+ socEsquemas.getEsqCodigo() + " [" + solicitud.getCodEstacionAudit() + ":" + solicitud.getCodUsuarioAudit() + " - "
				+ solicitud.getCodUsuarioCont() + "]");
		// /////////////////////////////

		String glosaComprob = renglonesComprobantes.generarGlosa(solicitud, socEsquemas.getGlosaComp(), null, paramsGlosa);
		
		glosaComprob = "Comprobante revertido Nro.: "+ socComprob.getCpbNrocpbte() +" CONCEPTO: ".concat(glosaComprob);
		// ahora se hace el comprobante total
		SocComprobante socComprobante = nuevoComprobante(socComprob, solicitud.getSolicitud().getSocCodigo(), glosaComprob, socEsquemas.getEsqCodigo(), cveDettipocomp,
				detCodigo, cpbCodigoref, genera);

		socComprobante.setFechaHora(new Date());
		socComprobante.setEstacion(solicitud.getCodEstacionAudit());
		socComprobante.setUsrCodigo(solicitud.getCodUsuarioAudit());
		socComprobante.setUsrCodauto(solicitud.getCodUsuarioCont());
		socComprobante.setGenera(socComprob.getCpbNrocpbte());

		socComprobante = comprobanteDao.getHibernateTemplate().merge(socComprobante);

		socComprobante = comprobanteDao.getComprobante(socComprobante.getCpbCodigo());
		log.info("Comprobante creado:: " + socComprobante.toString());

		List<SocRengscomp> socRengscompLista = volcadoRengs(socComprob, socComprobante);
		for (SocRengscomp socRengscomp : socRengscompLista) {
			socRengscompDao.saveOrUpdate(socRengscomp);
		}

		QueryProcessor.flush();
		if (socRengscompLista.size() == 0) {
			log.info("Eliminando comprobante por no tener renglones " + socEsquemas.getEsqCodigo());
			comprobanteDao.getHibernateTemplate().delete(socComprobante);
			return null;
		}

		return socComprobante;
	}
	
	private List<SocRengscomp> volcadoRengs(SocComprobante cmpbOrig, SocComprobante cmpbRev) {
		List<SocRengscomp> renglones = socRengscompDao.getRenglones(cmpbOrig.getCpbCodigo());
		List<SocRengscomp> socRengscompLista = new ArrayList<SocRengscomp>();
		
		for(SocRengscomp reng :renglones) {
			SocRengscomp nwRen = volcadoReng(cmpbRev, reng);
			socRengscompLista.add(nwRen);
		}
		return socRengscompLista;
	}
	
	private SocRengscomp volcadoReng(SocComprobante socComprobante, SocRengscomp reng) {
		
		SocRengscomp socRengscomp = new SocRengscomp();

		SocRengscompId socRengscompId = new SocRengscompId(socComprobante.getCpbCodigo(), reng.getId().getRenCodigo());
		socRengscomp.setId(socRengscompId);

		socRengscomp.setMoneda(reng.getMoneda());
		socRengscomp.setRenAfectable(reng.getRenAfectable());
		socRengscomp.setRenMayor(reng.getRenMayor());
		socRengscomp.setSolCoddestorig(reng.getSolCoddestorig());
		socRengscomp.setCtaMovimiento(reng.getCtaMovimiento());
		socRengscomp.setTipoTransfer(reng.getTipoTransfer());
		socRengscomp.setCtaDestorig(reng.getCtaDestorig());
		socRengscomp.setRenMontomo(reng.getRenMontomo());
		socRengscomp.setRenMontomn(reng.getRenMontomn());
		socRengscomp.setRenTipocambio(reng.getRenTipocambio());
		
		socRengscomp.setClaDebehaber(reng.getClaDebehaber() == 'D' ? 'H' : 'D');			

		socRengscomp.setDetCodigo(reng.getDetCodigo());
		String glosaRenglon = reng.getRenGlosa();

		socRengscomp.setRenGlosa(glosaRenglon);
		return socRengscomp;
	}
	
	private SocComprobante nuevoComprobante(SocComprobante compbIn, String socCodigo, String glosa, Integer esqCodigo, String cveDettipocomp, Integer detCodigo, String cpbCodigoref,
			String genera) {

		// cveDettipocomp : O Operacion principal; P:provision, U: utiles, I:itf
		Date fecha = new Date();
		DateTime fechaComprob = new DateTime(fecha);

		BigDecimal tc = QueryProcessor.getTipoCambio(Constants.COD_MONEDA_USD, fecha);

		SocComprobante comprobante = null;

		List<SocComprobante> lista = comprobanteDao.comprobantesByOpeCodigo(socCodigo, detCodigo, cpbCodigoref, null, cveDettipocomp, null, esqCodigo);

		if (lista == null || lista.size() == 0) {
			Date hoy = new Date();
			String codComprobante = Long.toString(hoy.getTime());
			codComprobante = socCodigo.substring((socCodigo.length() - 6)).concat(codComprobante.substring(6));
			comprobante = new SocComprobante(codComprobante, socCodigo, fechaComprob.getYear(), fechaComprob.getMonthOfYear(), fechaComprob.getDayOfMonth(),
					tc, glosa);

			comprobante.setCveDettipocomp(cveDettipocomp);
			comprobante.setCpbFecha(fecha);
			comprobante.setEsqCodigo(compbIn.getEsqCodigo());
			comprobante.setEsqCodesqcont(compbIn.getEsqCodesqcont());
			comprobante.setCveEstadocpb(Constants.CLAVE_ESTCOMP_PEND);
			comprobante.setCpbCodigoref(cpbCodigoref);
			comprobante.setCodTransac(detCodigo);
			comprobante.setGenera(genera);

			comprobante.setFechaHora(new Date());
			comprobante.setEstacion("Esta");
			comprobante.setUsrCodigo("user");
			log.info("comprobante creado: " + comprobante.toString());
		} else {
			if (lista.size() > 1) {
				throw new BusinessException("Existe mas de una operacion contable para [solicitud= " + socCodigo + ", dettipocomprob= " + cveDettipocomp
						+ "] no puede continuar comunique al administrador");
			}
			// el comprobante existe
			comprobante = lista.get(0);

			if (StringUtils.isBlank(comprobante.getCveEstadocpb()) || comprobante.getCveEstadocpb().equals(Constants.CLAVE_ESTCOMP_CONTAB)) {
				throw new BusinessException("La operacion contable con estado [" + comprobante.getCveEstadocpb() + "] invalido no puede modificar");
			}

			comprobante.setCpbGestion(fechaComprob.getYear());
			comprobante.setCpbPeriodo(fechaComprob.getMonthOfYear());
			comprobante.setCpbDia(fechaComprob.getDayOfMonth());
			comprobante.setCpbTipocambio(tc);
			comprobante.setCpbGlosa(glosa);
			comprobante.setCpbFecha(fecha);
			comprobante.setEsqCodigo(esqCodigo);
			comprobante.setCpbCodigoref(cpbCodigoref);
			comprobante.setCodTransac(detCodigo);
			comprobante.setGenera(genera);
			comprobante.setFechaHora(new Date());
			comprobante.setEstacion("Esta");
			comprobante.setUsrCodigo("user");

			// saveOrUpdate(comprobante);
			log.info("comprobante modificado: " + comprobante.toString());
		}

		// QueryProcessor.flush();

		return comprobante;
	}
	
	private SocComprobante inicioReversa(Solicitud solicitud, SocEsquemas socEsquemasOper) {
		if (socEsquemasOper.getTipoTransfer().equals(Constants.CLAVE_TIPOTRANSFER_CONPROV)) {
			SocEsquemas socEsquemasRVS = socEsquemasDao.esquemaByCod(socEsquemasOper.getEsqCodigo());
			SocComprobante socComprobante = comprobanteDao.generaComprobante(solicitud, socEsquemasRVS, 0, Constants.CLAVE_TIPOESQ_RVS, null, null);

			socSolicitudesDao.cambiarEstadoSolicitud(solicitud.getSolicitud(), null, Constants.CLAVE_ESTWS_PROV);
			log.info("Solicitud con REVERSION DE PROV " + solicitud.getSolicitud().getSocCodigo());
			SocComprobante socComprobanteNew = comprobanteDao.getComprobante(socComprobante.getCpbCodigo());

			return socComprobanteNew;			
		}
		return null;
	}
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
}
