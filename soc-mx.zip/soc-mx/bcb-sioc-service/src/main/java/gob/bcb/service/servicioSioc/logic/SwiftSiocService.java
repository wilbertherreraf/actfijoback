package gob.bcb.service.servicioSioc.logic;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;

import com.prowidesoftware.swift.model.mx.JaxbContextCache;
import com.prowidesoftware.swift.model.mx.JaxbContextCacheImpl;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;

import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentas;
import gob.bcb.bpm.pruebaCU.SocCuentasDao;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.SocUsuariosol;
import gob.bcb.bpm.pruebaCU.SocUsuariosolDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.GuavaJaxbContextCache;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.client.utils.UtilsGeneric;
import gob.bcb.lavado.lavadoclient.ClienteLvdSioc;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.dao.SwfDetmensajeBean;
import gob.bcb.swift.dao.SwfDetmensajeLocal;
import gob.bcb.swift.dao.SwfMencamposDbDao;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.dao.SwfMttransferLocal;
import gob.bcb.swift.dao.SwfPersonactaBean;
import gob.bcb.swift.dao.SwfPersonactaLocal;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.service.SwfMencamposIsoDaoImpl;
import gob.bcb.swift.service.SwiftMessageService;

public class SwiftSiocService {
	private static final Log log = LogFactory.getLog(SwiftSiocService.class);

	private static String urlLavado = null;
	private static String pathSwift = null;
	private static String pathBase = null;

	private SocBancosDao socBancosDao = new SocBancosDao();
	private SocBenefsDao socBenefsDao = new SocBenefsDao();
	private SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
	private SwfMttransferLocal swfMttransferLocal = new SwfMttransferBean();
	private SwfPersonactaLocal swfPersonactaLocal = new SwfPersonactaBean();
	private SwfDetmensajeLocal swfDetmensajeLocal = new SwfDetmensajeBean();
	private SwfMencamposDbDao swfMencamposDbDao = new SwfMencamposDbDao();
	private SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
	private SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
	private SwfMencamposIsoDaoImpl swfMencamposIsoDaoImpl = new SwfMencamposIsoDaoImpl();
	private SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
	private SocCuentasDao socCuentasDao = new SocCuentasDao();
	private SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
	private SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
	private GenMonedaDao genMonedaDao = new GenMonedaDao();
	private SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
	private SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
	private SwiftMessageService swiftMessageService = new SwiftMessageService();
	private SocParametrosDao socParametrosDao = new SocParametrosDao();
	private SessionFactory sessionFactory;

	static {
		pathBase = (new File(Constants.PATH_BASE_SERV)).getAbsolutePath();
		log.info("pathBase configurado " + pathBase);
	}

	public void generarMensSwift(Solicitud solicitudTO) {
		String codUsuarioSwift = solicitudTO.getCodUsuarioAudit();
		
		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Swift: Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}

		if ((solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))
				&& solicitudOld.getCodMonedat().compareTo(Constants.COD_MONEDA_BS) != 0
				&& solicitudOld.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_NORMAL)) {

			if (solicitudOld.getFechaCont() == null) {
				log.error("Fecha valor mensaje swift" + solicitudOld.getSocCodigo() + " nulo");
				throw new BusinessException("Fecha valor mensaje swift" + solicitudOld.getSocCodigo() + " nulo");
			}

			Date fechaValor = solicitudOld.getFechaCont();

			if (UtilsDate.compara(solicitudOld.getFechaCont(), new Date()) < 0) {
				log.error(
						"Fecha valor mensaje swift menor [" + UtilsDate.stringFromDate(fechaValor, "dd/MM/yyyy") + "] a hoy, " + solicitudOld.getSocCodigo());
				throw new BusinessException(
						"Fecha valor mensaje swift menor [" + UtilsDate.stringFromDate(fechaValor, "dd/MM/yyyy") + "] a hoy, " + solicitudOld.getSocCodigo());
			}

			log.info("Inicio : generarMensSwift " + solicitudOld.getSocCodigo() + " " + UtilsDate.stringFromDate(fechaValor, "dd/MM/yyyy"));

			List<SocDetallessol> socDetallessolListaPrev = socDetallessolDao.getDetalles(solicitudOld.getSocCodigo());

			if (socDetallessolListaPrev.size() == 0) {
				log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] sin beneficiarios registrados");
				throw new BusinessException("Swift: Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] sin beneficiarios registrados");
			}

			// se valida que la fecha sea habil
			log.info("Proceso de registrarMensajeSwift iniciado " + UtilsDate.stringFromDate(fechaValor, "dd/MM/yyyy"));
			List<SocUsuariosol> socUsuariosolLista = socUsuariosolDao.getUsuariosSioc(Constants.COD_BCB, codUsuarioSwift, null);

			if (socUsuariosolLista.size() != 1) {
				throw new BusinessException("Swift: Error de parametrizacion usuario: " + codUsuarioSwift + " no registrado en usuarios SIOC");
			}

			if (StringUtils.isBlank(socUsuariosolLista.get(0).getUsrIniciales())) {
				throw new BusinessException("Swift: Error de parametrizacion usuario " + codUsuarioSwift + " con iniciales swift nulo");
			}

			List<SocDetallessol> socDetallessolLista = new ArrayList<SocDetallessol>();
			int cont = 0;
			// controlamos si ya fue generado los mensajes
			for (SocDetallessol socDetallessol : socDetallessolListaPrev) {
				boolean noExist = false;
				SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(solicitudTO.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo());
				if (swfMensaje == null) {
					// no fue registrado
					socDetallessolLista.add(socDetallessol);
					noExist = true;
				} else {
					if (!swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)) {
						socDetallessolLista.add(socDetallessol);
						noExist = true;
					} else {
						cont++;
					}
				}
				if (noExist) {
					SocCuentas socCuentas = socCuentasDao.getSocCuentasByCodigo(socDetallessol.getCtaCodigo());
					if (socCuentas == null) {
						List<SocCuentas> socCuentasLista = socCuentasDao.cuentasExtByCod(null, socDetallessol.getBenCodigo(), socDetallessol.getCodBanco(),
								socDetallessol.getNroCuentabco(), socDetallessol.getCodMonedatdet(), null, null);
						if (socCuentasLista.size() > 1) {
							throw new BusinessException("Swift: Existe mas de una Cta vigente registrada revise parametrizacion, Solicitud ["
									+ solicitudTO.getSolicitud().getSocCodigo() + "] en cta benef: " + socDetallessol.getBenCodigo() + ":"
									+ socDetallessol.getNroCuentabco() + " bco: " + socDetallessol.getCodBanco() + " mon: "
									+ socDetallessol.getCodMonedatdet());
						}
					}
					GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socDetallessol.getCodMonedatdet());
					crearMensajeSwift(solicitudTO, socDetallessol, socUsuariosolLista.get(0), genMoneda, swfMensaje);
				}

			}

			if (socDetallessolLista.size() == 0) {
				log.warn("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] Mensajes swift sin beneficiarios a procesar!!! swifts autorizados: "
						+ cont + " mensajes");
				return;
			}

			// si es de transferencia
			// se controla que se haya realizado la actualizacion de mensajes
			// swift
			socDetallessolLista = socDetallessolDao.getDetalles(solicitudTO.getSolicitud().getSocCodigo());
			for (SocDetallessol socDetallessol : socDetallessolLista) {

				SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(solicitudTO.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo());
				if (swfMensaje == null) {
					log.error("Mensaje Swift no fue creado o actualizado, actualice los valores para " + solicitudTO.getSolicitud().getSocCodigo()
							+ " detalle " + socDetallessol.getId().getDetCodigo());

					throw new BusinessException("Mensaje Swift no fue creado o actualizado, actualice los valores para "
							+ solicitudTO.getSolicitud().getSocCodigo() + " detalle " + socDetallessol.getId().getDetCodigo());
				}
			}

		}
	}

	private SwfMensaje crearMensajeSwift(Solicitud solicitud, SocDetallessol socDetallessol, SocUsuariosol socUsuariosol, GenMoneda genMoneda,
			SwfMensaje swfMensaje) {
		log.info("creando mensaje:  " + solicitud.getSolicitud().getSocCodigo() + " " + socDetallessol.getId().getDetCodigo());

		SwiftDatos swiftDatos = new SwiftDatos();

		swiftDatos.setAuditusr(solicitud.getSolicitud().getUsrCodigo());
		swiftDatos.setAuditwst(solicitud.getSolicitud().getEstacion());

		swiftDatos.setSolicitudTO(solicitud);
		swiftDatos.setSocDetallessol(socDetallessol);

		if (swfMensaje != null) {
			if (swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)) {
				throw new BusinessException("Swift: Operacion " + solicitud.getSolicitud().getSocCodigo() + " " + socDetallessol.getId().getDetCodigo()
						+ " con estado autorizado");
			}
		}

		socDetallessolDao.validarDatos(solicitud.getSolicitud(), socDetallessol);

		if (swfMensaje == null) {
			swfMensaje = new SwfMensaje();
			swfMensaje.setMenCodoperacion(solicitud.getSolicitud().getSocCodigo());
			swfMensaje.setMenDetcodigo(socDetallessol.getId().getDetCodigo());
		}

		Calendar c = GregorianCalendar.getInstance();

		SocCuentas socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(solicitud.getSolicitud(), socDetallessol.getCodMonedatdet(), null);

		if (socCuentas == null) {
			throw new BusinessException("Swift: Operacion " + solicitud.getSolicitud().getSocCodigo() + " det: " + socDetallessol.getId().getDetCodigo()
					+ " sin cuenta en banco(soccuentas) exterior moneda " + socDetallessol.getCodMonedatdet());
		}

		BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByCod(Constants.COD_BCB_SWIFT);
		BancoPlaza bancoPlazaReceiver = socBancosDao.bancoPlazaByCod(socCuentas.getBcoCodigo());

		swfMensaje.setMenBic(bancoPlazaReceiver.getPlaBic());
		swfMensaje.setMenCodmt(socDetallessol.getDetCodttransfer());
		swfMensaje.setMenBicemisor(bancoPlazaSender.getPlaBic());
		swfMensaje.setMenGestion(c.get(Calendar.YEAR));
		swfMensaje.setMenMonto(socDetallessol.getDetMontotrans());
		swfMensaje.setMenCodmon(solicitud.getSolicitud().getCodMonedat());
		swfMensaje.setMenCodmonswift(genMoneda.getDesSwift());
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenFecvalor(solicitud.getSolicitud().getFechaCont());
		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PEND);
		swfMensaje.setMenCodusrswf(socUsuariosol.getUsrIniciales());
		swfMensaje.setMenAuditusr(solicitud.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitud.getCodEstacionAudit());

		swiftDatos.setSwfMensaje(swfMensaje);

		SwfMensaje swfMensajeNew = swiftMessageService.generarMensaje(swiftDatos);

		return swfMensajeNew;
	}

	public Solicitud preAutorizarSwift(Solicitud solicitudTO) {
		initPathLvd();
		
		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}
		log.info("Inicio : PRE autorizarSwift [usr: " + solicitudTO.getCodUsuarioAudit() + "] para sol: " + solicitudTO.getSolicitud().getSocCodigo());

		if (!solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
			if (solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
				return solicitudTO;
			}
		}

		if (solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			if (solicitudOld.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
				log.info("Operacion[[" + solicitudOld.getSocCodigo() + "] con tipo negociacion " + solicitudOld.getSocTipnegociacion()
						+ ", no se genera swifts ");
				return solicitudTO;
			}

			if (!solicitudTO.getCodPersonaAudit().equals(Constants.COD_BCB)) {
				return solicitudTO;
			}
			solicitudTO.setSolicitud(solicitudOld);
			List<SocDetallessol> socDetallessolLista = socDetallessolDao.getDetalles(solicitudOld.getSocCodigo());
			
			validateXML(socDetallessolLista);
			
			ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc();
			clienteLvdSioc.initClienteLvd(urlLavado, pathBase);
			clienteLvdSioc.getSessionLavado(solicitudTO.getCodUsuarioAudit());

			for (SocDetallessol socDetallessol : socDetallessolLista) {
				SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(solicitudOld.getSocCodigo(), socDetallessol.getId().getDetCodigo());

				if (swfMensaje == null) {
					throw new BusinessException("Mensaje Swift para [" + solicitudOld.getSocCodigo() + "-" + socDetallessol.getId().getDetCodigo()
							+ "] inexistente, actualice la operacion");
				}
				if (swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PEND)) {
					swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
					swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());

					// ******* guardamos swifttttttttttttttt**********//
					solicitarNroLvdYScan(solicitudTO, swfMensaje, socDetallessol, pathSwift, clienteLvdSioc);

					log.info("mensaje swift PRE autorizado " + solicitudOld.getSocCodigo() + " - " + socDetallessol.getId().getDetCodigo() + " codmensaje: "
							+ swfMensaje.getMenCodmen());
				}
			}
			clienteLvdSioc.cerrarSession(solicitudTO.getCodUsuarioAudit());
		}
		return solicitudTO;
	}

	private SwfMensaje solicitarNroLvdYScan(Solicitud solicitud, SwfMensaje swfMensaje, SocDetallessol socDetallessol, String pathSwift,
			ClienteLvdSioc clienteLvdSioc) {

		SwfMensajeBean.validarDatos(swfMensaje);
		requiereCorrelativo(swfMensaje);

		String codigoOperacion = String.valueOf(swfMensaje.getMenCodoperacion() + "" + swfMensaje.getMenDetcodigo());

		SearchResponse searchResponse = clienteLvdSioc.solicitarCorrelativo(codigoOperacion, swfMensaje.getMenAuditusr());

		swfMensaje.setMenNrocorr(searchResponse.getNrocorr());
		swfMensaje.setMenNrolavado(Integer.valueOf(searchResponse.getCodoperacion()));

		log.info("Mensaje con correlativo LAVADO: " + swfMensaje.getMenCodmen() + ", nrolvd : " + swfMensaje.getMenNrolavado() + " y corr swift : "
				+ swfMensaje.getMenNrocorr());

		SwfMensaje swfMensajeNew = actualizarCampo(solicitud, swfMensaje, socDetallessol);
		Map<String, String> params = new HashMap<String, String>();
		params.put("menIdTMessageTx", swfMensaje.getMenCodmt());
		params.put("menRefer", codigoOperacion);
		String encoded="";
		try {
			encoded = UtilsGeneric.encodeQueryParams(params);
		} catch (UnsupportedEncodingException e) {
			throw new SwiftAdminException("No se pudo generar parametros " + e.getMessage());
		}
		
		String paramsAdic = Base64.encodeBase64String(encoded.getBytes());
		searchResponse = clienteLvdSioc.scanMensaje(paramsAdic, swfMensaje.getMenAuditusr(), swfMensajeNew.getMenNrolavado(),
				swfMensajeNew.getMenNrocorr(), swfMensajeNew.getMenPlano());

		if (!StringUtils.isBlank(searchResponse.getMenPlano())) {
			swfMensajeNew.setMenPlano(searchResponse.getMenPlano());
			cambioEstadoPreAutorizado(swfMensajeNew);
		} else {
			throw new SwiftAdminException("Servicio de Lavado no retorna mensaje plano IdLvd: " + swfMensajeNew.getMenNrolavado());
		}

		log.info("Correlativo SWIFT Actualizado... " + swfMensajeNew.getMenCodmen());
		return swfMensajeNew;
	}

	private SwfMensaje actualizarCampo(Solicitud solicitud, SwfMensaje swfMensaje, SocDetallessol socDetallessol) {
		log.info("actualizarCampo:: " + swfMensaje.getMenCodmen());

		if (swfMensaje.getMenNrocorr() == null || swfMensaje.getMenNrocorr().compareTo(0) <= 0) {
			throw new SwiftAdminException("Error al actualizar correlativo, mensaje sin correlativo solicitado");
		}

		SwiftDatos swiftDatos = new SwiftDatos();
		swiftDatos.setSwfMensaje(swfMensaje);
		swiftDatos.setSolicitudTO(solicitud);
		swiftDatos.setSocDetallessol(socDetallessol);

		SwfMensaje swfMensajeNew = swiftMessageService.generarMensaje(swiftDatos);
		log.info("FIN!! Mensaje actualizado:: " + swiftDatos.getSwfMensaje().getMenCodmen());
		return swfMensajeNew;
	}

	private SwfMensaje cambioEstadoPreAutorizado(SwfMensaje swfMensaje) {
		// valida y guarda en el directorio temporal
		if (!swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PEND)) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
		}

		if (swfMensaje.getMenNrocorr() == null || swfMensaje.getMenNrocorr().compareTo(0) <= 0) {
			throw new SwiftAdminException("Error al autorizar mensaje " + swfMensaje.getMenCodmen() + " sin nro swift asignado ");
		}

		if (StringUtils.isBlank(swfMensaje.getMenPlano())) {
			throw new SwiftAdminException(
					"Error al autorizar mensaje " + swfMensaje.getMenCodmen() + " texto del mensaje swift nulo, actualice o verifique la operación");
		}

		log.info("PRE Autorizando swift Codmen:" + swfMensaje.getMenCodmen() + " Codoperacion:" + swfMensaje.getMenCodoperacion() + " Codmt:"
				+ swfMensaje.getMenCodmt() + " Nrocorr:" + swfMensaje.getMenNrocorr());

		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PREAUT);
		swfMensaje.setMenFecauto(new Date());

		swfMensajeBean.getHibernateTemplate().merge(swfMensaje);
		swfMensajeBean.getHibernateTemplate().flush();

		return swfMensaje;
	}

	public Solicitud autorizarSwift(Solicitud solicitudTO) {
		initPathLvd();
		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}

		if (solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			log.info("Inicio : autorizacion Swifts " + solicitudTO.getSolicitud().getSocCodigo());
			if (solicitudOld.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
				log.info("Operacion[[" + solicitudTO.getSolicitud().getSocCodigo() + "] con tipo negociacion " + solicitudOld.getSocTipnegociacion()
						+ ", no se genera swifts ");
				return solicitudTO;
			}

			List<SocDetallessol> socDetallessolLista = socDetallessolDao.getDetalles(solicitudOld.getSocCodigo());

			ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc();
			clienteLvdSioc.initClienteLvd(urlLavado, pathBase);
			clienteLvdSioc.getSessionLavado(solicitudTO.getCodUsuarioAudit());

			for (SocDetallessol socDetallessol : socDetallessolLista) {
				log.info("Auto swft Detalle:  " + solicitudOld.getSocCodigo() + " - " + socDetallessol.getId().getDetCodigo());
				SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(solicitudOld.getSocCodigo(), socDetallessol.getId().getDetCodigo());

				if (swfMensaje == null) {
					throw new BusinessException(
							"Mensaje Swift para [" + solicitudOld.getSocCodigo() + "-" + socDetallessol.getId().getDetCodigo() + "] inexistente");
				}

				if (swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PREAUT)) {
					// ******* guardamos swifttttttttttttttt**********//
					// marcamos el detalle como Transferido
					socDetallessol.setClaEstadodet("T");
					socDetallessol.setEstacion(solicitudTO.getCodEstacionAudit());
					socDetallessol.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
					socDetallessol.setFechaHora(new Date());

					socDetallessolDao.getHibernateTemplate().merge(socDetallessol);

					swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_AUTO);
					swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
					swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());
					swfMensaje.setMenAuditfho(new Date());

					swfMensajeBean.getHibernateTemplate().merge(swfMensaje);
					clienteLvdSioc.preautorizarSwift(swfMensaje);
					salvarSwift(swfMensaje, pathSwift);
				}
			}
			clienteLvdSioc.cerrarSession(solicitudTO.getCodUsuarioAudit());
		}
		return solicitudTO;
	}

	private SwfMensaje salvarSwift(SwfMensaje swfMensaje, String pathSwift) {
		log.info("En salvarSwift " + swfMensaje.getMenCodmen());
		String nameFile = nombreArchivo(swfMensaje);

		try {
			File h = new File(pathSwift, nameFile);

			if (h.exists() && !h.isDirectory()) {
				log.info("=====%%% ATENCION!!! %%%=======");
				log.info("SWIFT [" + swfMensaje.getMenCodmen() + "] autorizado en archivo " + h.getAbsolutePath());
				log.info("SE RE - INTENTO AUTORIZAR EL MENSAJE, REVISAR MENSAJES ANTERIORES, POSIBLES ERROR EN AUTORIZACION ANTERIOR");
				log.info("=====%%% ATENCION!!! %%%=======");
				// ojooo correo aca??
			}
			String p = UtilsFile.grabaEnArchivo(swfMensaje.getMenPlano(), h.getAbsolutePath());
			log.info("SWIFT AUTORIZADO!! [" + swfMensaje.getMenCodmen() + "] generado!!! en " + p);

		} catch (Exception e) {
			log.error("Swift[" + swfMensaje.getMenCodmen() + "]: error al AUTORIZAR swift " + pathSwift + ": " + e.getMessage(), e);
			// throw new SwiftAdminException("Swift[" + swfMensaje.getMenCodmen() + "]:
			// error al AUTORIZAR swift " + pathSwift + ": " + e.getMessage(), e);
		}
		return swfMensaje;
	}

	public Solicitud rechazarSwfMensaje(Solicitud solicitudTO) {
		SwfMensaje swfMensajePar = solicitudTO.getSwfMensaje();
		if (swfMensajePar == null) {
			throw new BusinessException("Parametro swfMensaje nulo en objeto solicitud, avise al adminsitrador");
		}
		SwfMensaje swfMensaje = swfMensajeBean.findByCodigo(swfMensajePar.getMenCodmen());

		if (swfMensaje == null) {
			throw new BusinessException("Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] inexistente");
		}

		log.info("Rechazando mensaje swift " + swfMensajePar.getMenCodmen());

		if (swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)
				|| swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_RECH)) {
			throw new BusinessException("Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] en estado invalido " + swfMensaje.getMenCveestswift()
					+ " debe estar en pendiente o preautorizado para continuar");
		}

		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_RECH);
		swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());
		swfMensaje.setMenAuditfho(new Date());

		swfMensajeBean.getHibernateTemplate().merge(swfMensaje);

		return solicitudTO;
	}

	public Solicitud preAutorizarSwfMensaje(Solicitud solicitudTO) {
		initPathLvd();
		SwfMensaje swfMensajePar = solicitudTO.getSwfMensaje();

		if (swfMensajePar == null) {
			throw new BusinessException("Parametro swfMensaje nulo en objeto solicitud, avise al adminsitrador");
		}
		log.info("PRE Autorizando UN SOLO swift " + swfMensajePar.getMenCodmen());

		SwfMensaje swfMensaje = swfMensajeBean.findByCodigo(swfMensajePar.getMenCodmen());

		if (swfMensaje == null) {
			throw new BusinessException("Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] inexistente");
		}

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(swfMensaje.getMenCodoperacion());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}
		solicitudTO.setSolicitud(solicitudOld);

		if (!swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PEND)) {
			throw new BusinessException("Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] en estado invalido " + swfMensaje.getMenCveestswift()
					+ " debe estar en pendiente para continuar");
		}

		SocDetallessol socDetallessol = socDetallessolDao.getDetalle(solicitudOld.getSocCodigo(), swfMensaje.getMenDetcodigo());
		if (socDetallessol == null) {
			throw new BusinessException(
					"Detalle del beneficiario [" + swfMensaje.getMenCodoperacion() + " - " + swfMensaje.getMenDetcodigo() + "] inexistente");
		}

		swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());

		// ******* guardamos swifttttttttttttttt**********//
		ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc();
		clienteLvdSioc.initClienteLvd(urlLavado, pathBase);
		clienteLvdSioc.getSessionLavado(solicitudTO.getCodUsuarioAudit());
		solicitarNroLvdYScan(solicitudTO, swfMensaje, socDetallessol, pathSwift, clienteLvdSioc);

		clienteLvdSioc.cerrarSession(solicitudTO.getCodUsuarioAudit());

		log.info("Swift PRE autorizado " + solicitudTO.getSolicitud().getSocCodigo() + " mensaje " + swfMensaje.getMenCodmen());
		return solicitudTO;
	}

	public Solicitud autorizarSwfMensaje(Solicitud solicitudTO) {
		SwfMensaje swfMensajePar = solicitudTO.getSwfMensaje();
		if (swfMensajePar == null) {
			throw new BusinessException("Parametro swfMensaje nulo en objeto solicitud, avise al adminsitrador");
		}
		log.info("Autorizando UN SOLO swift sin LVD " + swfMensajePar.getMenCodmen());
		SwfMensaje swfMensaje = swfMensajeBean.findByCodigo(swfMensajePar.getMenCodmen());

		if (swfMensaje == null) {
			throw new BusinessException("Mensaje Swift [" + swfMensajePar.getMenCodmen() + "] inexistente");
		}

		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(swfMensaje.getMenCodoperacion());

		if (solicitudOld == null) {
			log.error("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
			throw new BusinessException("Solicitud [" + solicitudTO.getSolicitud().getSocCodigo() + "] inexistente");
		}
		solicitudTO.setSolicitud(solicitudOld);
		log.info("Autorizando mensaje swift " + swfMensaje.getMenCodmen());
		if (!swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PREAUT)) {
			throw new BusinessException("Mensaje Swift [" + swfMensaje.getMenCodmen() + "] en estado invalido " + swfMensaje.getMenCveestswift()
					+ " debe estar en preautorizado para continuar");
		}

		SocDetallessol socDetallessol = socDetallessolDao.getDetalle(solicitudOld.getSocCodigo(), swfMensaje.getMenDetcodigo());
		if (socDetallessol == null) {
			throw new BusinessException("Detalle del beneficiario [" + solicitudOld.getSocCodigo() + " - " + swfMensaje.getMenDetcodigo() + "] inexistente");
		}

		// ******* guardamos swifttttttttttttttt**********//
		// marcamos el detalle como Transferido
		socDetallessol.setClaEstadodet("T");
		socDetallessol.setEstacion(solicitudTO.getCodEstacionAudit());
		socDetallessol.setUsrCodigo(solicitudTO.getCodUsuarioAudit());
		socDetallessol.setFechaHora(new Date());

		swfMensajeBean.getHibernateTemplate().merge(socDetallessol);

		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_AUTO);
		swfMensaje.setMenAuditusr(solicitudTO.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitudTO.getCodEstacionAudit());
		swfMensaje.setMenAuditfho(new Date());

		swfMensajeBean.getHibernateTemplate().merge(swfMensaje);

		salvarSwift(swfMensaje, pathSwift);
		return solicitudTO;
	}

	public void validateXML(List<SocDetallessol> socDetallessolLista) {
		List<String> errors = new ArrayList<>();
		for (SocDetallessol socDetallessol : socDetallessolLista) {
			SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo(),
					ConstantsSwift.PAR_ESTSWIFT_PEND);
			
			if (swfMensaje != null && !StringUtils.isBlank(swfMensaje.getMenFormato())
					&& swfMensaje.getMenFormato().equalsIgnoreCase(FileFormat.MX.toString())) {
				SwiftMessageAbstract sm = FactoryParser.createParser(swfMensaje.getMenPlano());
				try {
					sm.validateSyntax().forEach(err -> {
						errors.add(socDetallessol.getId().getDetCodigo() + ": " + err);	
					});
				} catch (Exception e1) {
					log.error("Error en validar MX :" + e1.getMessage());
				}
			}
		}
		log.info("Mensaje validado errores: " + errors.size());
		if (errors.size() > 0) {
			throw new BusinessException("Errores de Validacion: " + ArrayUtils.toString(errors));
		}		
	}
	private static boolean requiereCorrelativo(SwfMensaje swfMensaje) {
		if (StringUtils.isBlank(swfMensaje.getMenCveestswift()) || swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)
				|| swfMensaje.getMenCveestswift().trim().equals(ConstantsSwift.PAR_ESTSWIFT_RECH)) {
			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
			throw new SwiftAdminException(
					"Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
		}

		if (StringUtils.isBlank(swfMensaje.getMenCodusrswf())) {
			log.error("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
			throw new SwiftAdminException("Error al actualizar nro swift mensaje " + swfMensaje.getMenCodmen() + " sin codigo de usuario");
		}

		return true;
	}

	public void initPathLvd() {
		if (StringUtils.isBlank(urlLavado)) {
			SocParametros socParametros = socParametrosDao.getByCodigo(Constants.LAVADO_RESOURCE);
			if (StringUtils.isBlank(socParametros.getParValor())) {
				throw new SwiftAdminException("Lavado: parametro " + Constants.LAVADO_RESOURCE + " invalido, revise soc_parametros");
			}
			urlLavado = socParametros.getParValor();

			log.info("inicializado parametro url LAVADO " + urlLavado);

			socParametros = socParametrosDao.getByCodigo(ConstantsSwift.PARAM_PATHSWIFT);

			pathSwift = socParametros.getParValor();
			if (StringUtils.isBlank(pathSwift)) {
				throw new SwiftAdminException("Parametro de ruta de mensajes swift nulo, avise a sistemas");
			}

			File h = new File(pathSwift);
			pathSwift = h.getAbsolutePath();
			if (!h.exists() && !h.isFile()) {
				h.mkdirs();
			}
			log.info("inicializado parametro PARAM_PATHSWIFT " + pathSwift);

		}

	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void inicializar() {
		swfMttransferLocal.setSessionFactory(getSessionFactory());
		swfPersonactaLocal.setSessionFactory(getSessionFactory());
		swfMensajeBean.setSessionFactory(getSessionFactory());
		swfDetmensajeLocal.setSessionFactory(getSessionFactory());
		socBancosDao.setSessionFactory(getSessionFactory());
		socBenefsDao.setSessionFactory(getSessionFactory());
		swfMencamposDbDao.setSessionFactory(getSessionFactory());
		socSolicitudesDao.setSessionFactory(getSessionFactory());
		socDetallessolDao.setSessionFactory(sessionFactory);
		swfMencamposIsoDaoImpl.setSessionFactory(sessionFactory);
		socCuentassolDao.setSessionFactory(sessionFactory);
		socSolicitudctasDao.setSessionFactory(sessionFactory);
		socSolicitanteDao.setSessionFactory(sessionFactory);
		genMonedaDao.setSessionFactory(sessionFactory);
		socOpecomiDao.setSessionFactory(sessionFactory);
		socCuentasDao.setSessionFactory(sessionFactory);
		socUsuariosolDao.setSessionFactory(sessionFactory);
		swiftMessageService.setSessionFactory(sessionFactory);
		socParametrosDao.setSessionFactory(sessionFactory);
		
    	JaxbContextCache jbch = JaxbContextLoader.INSTANCE.getCacheImpl();
		if (jbch == null) {
			JaxbContextLoader.INSTANCE.setCacheImpl(new JaxbContextCacheImpl());
			log.info("CACHE jb creado ...");
		} else {
			log.info("CACHE jb existente ..." + ((JaxbContextCacheImpl) JaxbContextLoader.INSTANCE.getCacheImpl()).size());			
		}
	}

	public static String nombreArchivo(SwfMensaje swfMensaje) {
		String nameFile = swfMensaje.getMenFormato() + "SOC" + swfMensaje.getMenCodoperacion() + "_" + String.format("%03d", swfMensaje.getMenDetcodigo())
				+ "_" + String.format("%06d", swfMensaje.getMenNrocorr()) + swfMensaje.getMenCodusrswf() + ".dos";
		return nameFile;
	}
}
