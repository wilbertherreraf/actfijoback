package gob.bcb.service.servicioSioc.pojos;

public class ExportsPojo {
	private String dexCodexpo;
	private String dexNrodet;
	private String dexCoddetorig;
	private String dexMontomo;
	private String dexCodmonmo;
	private String dexMontomn;
	private String dexCodmonmn;
	private String dexMontousd;
	private String dexCverango;
	private String dexTcorig;
	private String dexTccont;
	private String dexNrofact;
	private String dexExportador;
	private String dexNit;
	private String dexTramite;
	private String dexFecvalid;
	private String dexFecconfirma;
	private String dexPatron;
	private String dexDocexport;
	private String dexPaisdest;
	private String dexDescrip;
	private String dexSector;
	private String dexEstdettrx;
	
	public ExportsPojo() {
	}
	public String getDexCodexpo() {
		return dexCodexpo;
	}
	public void setDexCodexpo(String dexCodexpo) {
		this.dexCodexpo = dexCodexpo;
	}
	public String getDexNrodet() {
		return dexNrodet;
	}
	public void setDexNrodet(String dexNrodet) {
		this.dexNrodet = dexNrodet;
	}
	public String getDexCoddetorig() {
		return dexCoddetorig;
	}
	public void setDexCoddetorig(String dexCoddetorig) {
		this.dexCoddetorig = dexCoddetorig;
	}
	public String getDexMontomo() {
		return dexMontomo;
	}
	public void setDexMontomo(String dexMontomo) {
		this.dexMontomo = dexMontomo;
	}
	public String getDexCodmonmo() {
		return dexCodmonmo;
	}
	public void setDexCodmonmo(String dexCodmonmo) {
		this.dexCodmonmo = dexCodmonmo;
	}
	public String getDexMontomn() {
		return dexMontomn;
	}
	public void setDexMontomn(String dexMontomn) {
		this.dexMontomn = dexMontomn;
	}
	public String getDexCodmonmn() {
		return dexCodmonmn;
	}
	public void setDexCodmonmn(String dexCodmonmn) {
		this.dexCodmonmn = dexCodmonmn;
	}
	public String getDexCverango() {
		return dexCverango;
	}
	public void setDexCverango(String dexCverango) {
		this.dexCverango = dexCverango;
	}
	public String getDexTcorig() {
		return dexTcorig;
	}
	public void setDexTcorig(String dexTcorig) {
		this.dexTcorig = dexTcorig;
	}
	public String getDexTccont() {
		return dexTccont;
	}
	public void setDexTccont(String dexTccont) {
		this.dexTccont = dexTccont;
	}
	public String getDexNrofact() {
		return dexNrofact;
	}
	public void setDexNrofact(String dexNrofact) {
		this.dexNrofact = dexNrofact;
	}
	public String getDexExportador() {
		return dexExportador;
	}
	public void setDexExportador(String dexExportador) {
		this.dexExportador = dexExportador;
	}
	public String getDexNit() {
		return dexNit;
	}
	public void setDexNit(String dexNit) {
		this.dexNit = dexNit;
	}
	public String getDexTramite() {
		return dexTramite;
	}
	public void setDexTramite(String dexTramite) {
		this.dexTramite = dexTramite;
	}
	public String getDexFecvalid() {
		return dexFecvalid;
	}
	public void setDexFecvalid(String dexFecvalid) {
		this.dexFecvalid = dexFecvalid;
	}
	public String getDexFecconfirma() {
		return dexFecconfirma;
	}
	public void setDexFecconfirma(String dexFecconfirma) {
		this.dexFecconfirma = dexFecconfirma;
	}
	public String getDexPatron() {
		return dexPatron;
	}
	public void setDexPatron(String dexPatron) {
		this.dexPatron = dexPatron;
	}
	public String getDexDocexport() {
		return dexDocexport;
	}
	public void setDexDocexport(String dexDocexport) {
		this.dexDocexport = dexDocexport;
	}
	public String getDexPaisdest() {
		return dexPaisdest;
	}
	public void setDexPaisdest(String dexPaisdest) {
		this.dexPaisdest = dexPaisdest;
	}
	public String getDexDescrip() {
		return dexDescrip;
	}
	public void setDexDescrip(String dexDescrip) {
		this.dexDescrip = dexDescrip;
	}
	public String getDexSector() {
		return dexSector;
	}
	public void setDexSector(String dexSector) {
		this.dexSector = dexSector;
	}
	public String getDexEstdettrx() {
		return dexEstdettrx;
	}
	public void setDexEstdettrx(String dexEstdettrx) {
		this.dexEstdettrx = dexEstdettrx;
	}
	public String getDexMontousd() {
		return dexMontousd;
	}
	public void setDexMontousd(String dexMontousd) {
		this.dexMontousd = dexMontousd;
	}
	
}
