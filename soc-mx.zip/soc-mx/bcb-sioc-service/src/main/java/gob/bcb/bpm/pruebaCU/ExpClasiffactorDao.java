package gob.bcb.bpm.pruebaCU;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.service.exception.BusinessException;

public class ExpClasiffactorDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(ExpClasiffactorDao.class);

	public void saveOrUpdate(ExpClasiffactor pm) {
		pm.setFacAuditfho(new Date());

		this.getHibernateTemplate().saveOrUpdate(pm);
	}
	public void remove(ExpClasiffactor pm) {
		log.info("Eliminando por " + pm.getFacAuditusr() + " " + pm.getFacAuditwst());

		this.getHibernateTemplate().delete(pm);
	}

	public Optional<ExpClasiffactor> findByCodigo(Date facFechavig, String facCodmonpar, String facTramo) {
		if (facFechavig == null)
			return Optional.empty();
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from ExpClasiffactor cc ");
		query = query.append("where cc.id.facFechavig = :facFechavig ");
		query = query.append("and cc.id.facCodmonpar = :facCodmonpar ");
		query = query.append("and cc.id.facTramo = :facTramo ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setDate("facFechavig", facFechavig);
		consulta.setParameter("facCodmonpar", facCodmonpar);
		consulta.setParameter("facTramo", facTramo);

		List<ExpClasiffactor> lista = consulta.list();

		if (lista.size() > 0) {
			return Optional.of(lista.get(0));
		}
		return Optional.empty();
	}

	public List<ExpClasiffactor> findVigentes(Date facFechavig, String facCodmonpar, String facTramo) {
		if (facFechavig == null)
			return new ArrayList<>();

		StringBuffer query = new StringBuffer();
		query.append("select cc ");
		query.append("from ExpClasiffactor cc ");
		query.append("where cc.id.facFechavig = (select max(b.id.facFechavig) ");
		query.append("from ExpClasiffactor b ");
		query.append("where b.id.facFechavig <= :facFechavig ");
		query.append(") ");
		if (!StringUtils.isBlank(facCodmonpar))
			query.append("and cc.id.facCodmonpar = :facCodmonpar ");
		if (!StringUtils.isBlank(facTramo))
			query.append("and cc.id.facTramo = :facTramo ");
		query.append("order by cc.id.facFechavig, cc.facLimiteinf ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setDate("facFechavig", facFechavig);
		if (!StringUtils.isBlank(facCodmonpar))
			consulta.setParameter("facCodmonpar", facCodmonpar);
		if (!StringUtils.isBlank(facTramo))
			consulta.setParameter("facTramo", facTramo);

		List<ExpClasiffactor> lista = consulta.list();

		return lista;
	}

	public List<ExpClasiffactor> retAll() {

		StringBuffer query = new StringBuffer();
		query.append("select cc ");
		query.append("from ExpClasiffactor cc ");
		query.append("order by cc.id.facFechavig, cc.facLimiteinf ");

		Query consulta = getSession().createQuery(query.toString());

		List<ExpClasiffactor> lista = consulta.list();

		return lista;
	}
	
	public List<ExpClasiffactor> findTramosVig(Date facFechavig, String facCodmonpar, BigDecimal monto) {
		if (monto == null || monto.compareTo(BigDecimal.ZERO) <= 0) {
			return new ArrayList<>();
		}

		List<ExpClasiffactor> vigs = findVigentes(facFechavig, facCodmonpar, null).stream()//
//				.filter(f -> {
//					return f.getFacCodmon().equalsIgnoreCase(facCodmonpar);
//				})//				
				.filter(f -> {
					boolean isLimI = f.getFacLimiteinf().compareTo(BigDecimal.ZERO) <= 0 && f.getFacLimitesup().compareTo(BigDecimal.ZERO) > 0;
					boolean isLimS = f.getFacLimiteinf().compareTo(BigDecimal.ZERO) > 0 && f.getFacLimitesup().compareTo(BigDecimal.ZERO) <= 0;
					boolean isLim = f.getFacLimiteinf().compareTo(BigDecimal.ZERO) > 0 && f.getFacLimitesup().compareTo(BigDecimal.ZERO) > 0;
					
					return (isLimI && monto.compareTo(f.getFacLimitesup()) <= 0) //
							|| (isLim && monto.compareTo(f.getFacLimiteinf()) > 0 && monto.compareTo(f.getFacLimitesup()) <= 0) //
							|| (isLimS && monto.compareTo(f.getFacLimiteinf()) > 0);
				}).collect(Collectors.toList());

		return vigs;
	}

	public Optional<ExpClasiffactor> findTramoVig(Date facFechavig, String facCodmonpar, BigDecimal monto) {
		List<ExpClasiffactor> vigs = findTramosVig(facFechavig, facCodmonpar, monto);

		if (vigs.size() > 1) {
			throw new BusinessException("Inconsistencia en factores, existen mas de un tramo que cumple el rango del monto " + monto);
		}
		return vigs.size() == 1 ? Optional.of(vigs.get(0)) : Optional.empty();
	}

	public Optional<ExpClasiffactor> limInf(Date facFechavig, BigDecimal monto, String facCodmonpar, String facTramo) {
		if (facFechavig == null)
			return Optional.empty();
		
		StringBuffer query = new StringBuffer();
		query.append("select cc ");
		query.append("from ExpClasiffactor cc ");
		query.append("where cc.id.facFechavig = :facFechavig ");
		query.append("and cc.facLimiteinf = (select max(b.facLimiteinf) ");		
		query.append("from ExpClasiffactor b ");
		query.append("where b.id.facFechavig = :facFechavig ");
		query.append("and b.facLimiteinf < :facLimiteinf ");		
		query.append(") ");
		
		if (!StringUtils.isBlank(facCodmonpar))
			query.append("and cc.id.facCodmonpar = :facCodmonpar ");
		
		if (!StringUtils.isBlank(facTramo))
			query.append("and cc.id.facTramo = :facTramo ");
		query.append("order by cc.id.facFechavig ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setDate("facFechavig", facFechavig);
		consulta.setBigDecimal("facLimiteinf", monto);
		
		if (!StringUtils.isBlank(facCodmonpar))
			consulta.setParameter("facCodmonpar", facCodmonpar);
		if (!StringUtils.isBlank(facTramo))		
			consulta.setParameter("facTramo", facTramo);

		List<ExpClasiffactor> lista = consulta.list();

		if (lista.size() > 0) {
			return Optional.of(lista.get(0));
		}
		return Optional.empty();
	}
	
	public Optional<ExpClasiffactor> limSup(Date facFechavig, BigDecimal monto, String facCodmonpar, String facTramo) {
		if (facFechavig == null)
			return Optional.empty();
		
		StringBuffer query = new StringBuffer();
		query.append("select cc ");
		query.append("from ExpClasiffactor cc ");
		query.append("where cc.id.facFechavig = :facFechavig ");
		query.append("and cc.facLimitesup = (select min(b.facLimitesup) ");		
		query.append("from ExpClasiffactor b ");
		query.append("where b.id.facFechavig = :facFechavig ");
		query.append("and b.facLimitesup >= :facLimitesup ");		
		query.append(") ");
		
		if (!StringUtils.isBlank(facCodmonpar))
			query.append("and cc.id.facCodmonpar = :facCodmonpar ");
		
		if (!StringUtils.isBlank(facTramo))
			query.append("and cc.id.facTramo = :facTramo ");
		query.append("order by cc.id.facFechavig ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setDate("facFechavig", facFechavig);
		consulta.setBigDecimal("facLimitesup", monto);
		
		if (!StringUtils.isBlank(facCodmonpar))
			consulta.setParameter("facCodmonpar", facCodmonpar);
		if (!StringUtils.isBlank(facTramo))		
			consulta.setParameter("facTramo", facTramo);

		List<ExpClasiffactor> lista = consulta.list();

		if (lista.size() > 0) {
			return Optional.of(lista.get(0));
		}
		return Optional.empty();
	}
	
	public static ExpClasiffactor nuevo() {
		ExpClasiffactorPK id = new ExpClasiffactorPK();
		id.setFacCodmonpar("34");
		id.setFacFechavig(new Date());
		ExpClasiffactor e = new ExpClasiffactor();
		e.setId(id);
		e.setFacLimiteinf(BigDecimal.ZERO);
		e.setFacLimitesup(BigDecimal.ZERO);
		e.setFacPcomis(BigDecimal.ZERO);
		e.setFacTctramo(BigDecimal.ZERO);
		e.setFacAuditfho(new Date());
		e.setFacCodmon("34");
		
		return e;
	}
}
