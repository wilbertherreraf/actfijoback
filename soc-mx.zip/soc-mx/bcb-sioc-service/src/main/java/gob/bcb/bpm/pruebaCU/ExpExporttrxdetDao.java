package gob.bcb.bpm.pruebaCU;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.type.Type;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class ExpExporttrxdetDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(ExpExporttrxdetDao.class);

	public void saveOrUpdate(ExpExporttrxdet pm) {
		this.getHibernateTemplate().saveOrUpdate(pm);
		this.getHibernateTemplate().merge(pm);
	}

	public Optional<ExpExporttrxdet> findByCodigo(Integer dexCodexpo, Integer dexNrodet) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from ExpExporttrxdet cc ");
		query = query.append("where cc.id.dexCodexpo = :dexCodexpo ");
		query = query.append("and cc.id.dexNrodet = :dexNrodet ");

		// log.info("procesando carta det " + codcartacr + ", nroccreddet: " +
		// nroccreddet + " -> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("dexCodexpo", dexCodexpo);
		consulta.setParameter("dexNrodet", dexNrodet);

		List<ExpExporttrxdet> lista = consulta.list();

		if (lista.size() > 0) {
			return Optional.of(lista.get(0));
		}
		return Optional.empty();
	}

	public List<ExpExporttrxdet> retLote(Integer dexCodexpo) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from ExpExporttrxdet cc ");
		query = query.append("where cc.id.dexCodexpo = :dexCodexpo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("dexCodexpo", dexCodexpo);

		List<ExpExporttrxdet> lista = consulta.list();
		return lista;
	}

	public List<ExpExporttrxdet> retLotetramo(Integer dexCodexpo, String dexTramo) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from ExpExporttrxdet cc ");
		query = query.append("where cc.id.dexCodexpo = :dexCodexpo ");
		query = query.append("and cc.dexTramo = :dexTramo ");
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("dexCodexpo", dexCodexpo);
		consulta.setParameter("dexTramo", dexTramo);		

		List<ExpExporttrxdet> lista = consulta.list();
		return lista;
	}	
	
	public List<ExpExporttrxdet> retEntreFechas(Date fecIni, Date fecFin) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from ExpExporttrx e, ExpExporttrxdet cc ");
		query = query.append("where e.extCodexpo = cc.id.dexCodexpo ");
		query = query.append("and e.extFecha between :fecIni and :fecFin ");
		query = query.append("order by e.extFecha, cc.id.dexCodexpo,cc.id.dexNrodet  ");		
		Query consulta = getSession().createQuery(query.toString());

		consulta.setDate("fecIni", fecIni);
		consulta.setDate("fecFin", fecFin);		

		List<ExpExporttrxdet> lista = consulta.list();
		return lista;
	}		
	public ExpExporttrxdet totalesLote(Integer dexCodexpo) {
		List<ExpExporttrxdet> exps = retLote(dexCodexpo);
		return retTotales(exps);
	}

	public static ExpExporttrxdet retTotales(List<ExpExporttrxdet> items) {
		ExpExporttrxdet edet = newExportdet();
		BigDecimal montomo = items.stream().map(ed -> ed.getDexMontomo()).reduce(BigDecimal.ZERO, BigDecimal::add);
		BigDecimal montopar = items.stream().map(ed -> ed.getDexMontopar()).reduce(BigDecimal.ZERO, BigDecimal::add);
		BigDecimal montousd = items.stream().map(ed -> ed.getDexMontousd()).reduce(BigDecimal.ZERO, BigDecimal::add);
		BigDecimal montomn = items.stream().map(ed -> ed.getDexMontomn()).reduce(BigDecimal.ZERO, BigDecimal::add);
		
		edet.setDexMontomo(montomo);
		edet.setDexMontopar(montopar);
		edet.setDexMontousd(montousd);
		edet.setDexMontomn(montomn);
		//edet.getId().setDexNrodet(items.size());
		return edet;
	}

	public static ExpExporttrxdet newExportdet() {
		ExpExporttrxdet ed = new ExpExporttrxdet();
		ed.setId(new ExpExporttrxdetPK());
		ed.setDexMontomo(BigDecimal.ZERO);
		ed.setDexMontopar(BigDecimal.ZERO);
		ed.setDexMontousd(BigDecimal.ZERO);
		ed.setDexMontomn(BigDecimal.ZERO);
		ed.setDexTccont(BigDecimal.ZERO);
		ed.setDexTctramo(BigDecimal.ZERO);
		ed.setDexEstdettrx("R"); // registrado
		ed.setDexAuditfho(new Date());
		return ed;
	}
}
