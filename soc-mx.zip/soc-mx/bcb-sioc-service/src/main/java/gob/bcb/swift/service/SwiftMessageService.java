package gob.bcb.swift.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.prowidesoftware.swift.model.LogicalTerminalAddress;
import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.mx.JaxbContextCache;
import com.prowidesoftware.swift.model.mx.JaxbContextCacheImpl;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocCuentas;
import gob.bcb.bpm.pruebaCU.SocCuentasDao;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.iso20022.exceptions.DataValidationSwitfException;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.pojo.Block4;
import gob.bcb.iso20022.swift.FieldSwf;
import gob.bcb.iso20022.utils.UtilsDate;
import gob.bcb.lavado.client.pojos.SearchResponse;
import gob.bcb.lavado.lavadoclient.ClienteLvdSioc;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.CartasCredService;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.commons.MensSwiftUtiles;
import gob.bcb.swift.dao.SwfDetmensajeBean;
import gob.bcb.swift.dao.SwfDetmensajeLocal;
import gob.bcb.swift.dao.SwfMencamposDbDao;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMensajeLocal;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.dao.SwfMttransferLocal;
import gob.bcb.swift.dao.SwfPersonactaBean;
import gob.bcb.swift.dao.SwfPersonactaLocal;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfDetmensaje;
import gob.bcb.swift.model.SwfMencamposDb;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.pojos.SwiftMessageBcb;

//@Service("swiftMessageServiceLocal")
//@Transactional
public class SwiftMessageService implements SwiftMessageServiceLocal {
	private static final Logger log = Logger.getLogger(SwiftMessageService.class);

	private SocBancosDao socBancosDao = new SocBancosDao();
	private SocBenefsDao socBenefsDao = new SocBenefsDao();
	private SwfMensajeLocal swfMensajeLocal = new SwfMensajeBean();
	private SwfMttransferLocal swfMttransferLocal = new SwfMttransferBean();
	private SwfPersonactaLocal swfPersonactaLocal = new SwfPersonactaBean();
	private SwfDetmensajeLocal swfDetmensajeLocal = new SwfDetmensajeBean();
	private SwfMencamposDbDao swfMencamposDbDao = new SwfMencamposDbDao();

	private SwfMencamposIsoDaoImpl swfMencamposIsoDaoImpl = new SwfMencamposIsoDaoImpl();
	private SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
	private SocCuentasDao socCuentasDao = new SocCuentasDao();
	private SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
	private SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
	private GenMonedaDao genMonedaDao = new GenMonedaDao();
	private SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
	private SwiftMessageMXService swiftMessageMXService = new SwiftMessageMXService();
	private CartasCredService cartasCredService;
	private SessionFactory sessionFactory;

	public SwiftMessageService() {
	}

	public SwfMensaje generarMensaje(SwiftDatos swiftDatos) {
	
		CreateSwiftService createSwiftService = genSwiftMxMt(swiftDatos);
		Instruccion instruccion = createSwiftService.getInstruccion();
		return guardarSwiftObjectMx(swiftDatos, instruccion);
	}

	public CreateSwiftService genSwiftMxMt(SwiftDatos swiftDatos) {
		log.info("Inicio: generar Swift " + swiftDatos.getSwfMensaje().getMenCodmt() + " oper:	"
				+ swiftDatos.getSwfMensaje().getMenCodoperacion() + " " + swiftDatos.getSwfMensaje().getMenCodusrswf());

		SwfMsgParam swfMsgParam = recMsgParms(swiftDatos);

		CreateSwiftService createSwiftService = new CreateSwiftService(swfMsgParam, swfMencamposIsoDaoImpl);
		Instruccion instruccion = createSwiftService.initInstruccion();

		if (instruccion.isMt()) {
			generarMensajeSwift(createSwiftService, swiftDatos);
		} else if (instruccion.isMx()) {
			swiftMessageMXService.generarMensajeSwift(createSwiftService, swiftDatos);
		}
		log.info("fin generar swift ... hecho. " + swiftDatos.getSwfMensaje().getMenCodoperacion());
		return createSwiftService;
	}

	public void generarMensajeSwift(CreateSwiftService createSwiftService, SwiftDatos swiftDatos) {
		Instruccion instruccion = createSwiftService.initInstruccion();
		SwiftBlock4 block4List = obtenerCamposBlk4(swiftDatos);
		instruccion.setBlock4(block4List);

		createSwiftService.recuperarCampos("4");
		createSwiftService.registerFuncsDef();
		createSwiftService.translatePost();
		createSwiftService.generaHeaderMsg();
		createSwiftService.createMsgSwift();
		log.info("Proceso generar swift concluido " + swiftDatos.getSwfMensaje().getMenCodoperacion() + " mt: " + swiftDatos.getSwfMensaje().getMenCodmt());
		String menPlano = instruccion.getMessageHolder().getMenPlano();

		if (StringUtils.isBlank(menPlano)) {
			throw new RuntimeException("Proceso de generacion de mensaje swift no produjo ningun resultado");
		}
	}

	public SwiftBlock4 obtenerCamposBlk4(SwiftDatos swiftDatos) {
		SwiftBlock4 block4List = new SwiftBlock4();
		List<SwfMencamposDb> swfMencamposDbList = swfMencamposDbDao.findByMT(swiftDatos.getSwfMensaje().getMenCodmt(), "4");

		for (SwfMencamposDb swfMttransferdet : swfMencamposDbList) {
			Field field = obtenerValor(swiftDatos, swiftDatos.getSwfMensaje(), swfMttransferdet);
			if (field != null)
				block4List.append(field.asTag());
		}
		return block4List;
	}

	/**
	 * recupera valor del campo propio del bloque 4
	 * 
	 * @param swfMttransferdet
	 * @return
	 */
	private Field obtenerValor(SwiftDatos swiftDatos, SwfMensaje swfMensaje, SwfMencamposDb swfMencamposDb) {

		String campo = swfMencamposDb.getMtfCodcampo();
		String typeMsg = swfMencamposDb.getMtfCodmt();
		String valCampo = swfMencamposDb.getMtfDefault();

		// log.info("Obtener Valor " + typeMsg + " campo:" + campo + " Bloque:" +
		// swfMttransferdet.getId().getDttBloque());
		Field field = null;
		boolean requerido = true;
		if (campo.equals("20")) {
			// ref transaccion
			field = SwiftMessageBcb.setField20(swfMensaje.getMenCodswift());
		} else if (campo.equals("21")) {
			// referencia original
			field = SwiftMessageBcb.setField21(valCampo);
		} else if (campo.equals("23B")) {
			// Codigo sta operacion bancaria
			// ktte CRED
			field = SwiftMessageBcb.setField23B(valCampo);
		} else if (campo.equals("32A")) {
			// FECHA MONEDA IMPORTE
			field = SwiftMessageBcb.setField32A(swfMensaje.getMenFecvalor(), swfMensaje.getMenCodmonswift(), swfMensaje.getMenMonto());
		} else if (campo.equals("33B")) {
			// monto ordenado
			requerido = false;
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0, "MONTOORD");
				if (socOpecomi == null || socOpecomi.getMontoMo().compareTo(BigDecimal.valueOf(0)) <= 0) {
					throw new BusinessException(
							"No se puede hallar MONTOORD para Solicitud con descuento " + swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
				}

				GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
				BigDecimal montoOrd = socOpecomi.getMontoMo();

				BigDecimal monto = montoOrd.setScale(2, RoundingMode.HALF_UP);

				field = SwiftMessageBcb.setField33B(genMoneda.getMonSigla(), monto);
			}
		} else if (campo.equals("50A")) {
			field = SwiftMessageBcb.setField50A(valCampo);
		} else if (campo.equals("50F")) {
			String cta = "";
			// 50k es la cuenta del cliente originante de la solicitud
			SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(),
					Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);
			// 3987

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(socSolicitudctas.getSolCodigo());
			if (socSolicitante != null) {
				if (!StringUtils.isBlank(socSolicitante.getSolCodigo()) && socSolicitante.getSolCodigo().trim().equals(Constants.COD_BCB)) {
					// cta del bcb
					cta = socSolicitudctas.getNroCuenta();
				} else {
					if (!StringUtils.isBlank(socSolicitante.getClaEntidad())) {
						if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
							// la cta de provision pertenece a entidad es un bco
							// externo
							cta = socSolicitudctas.getNroLibreta();
						} else if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTPUBLICO)) {
							// es en el bcb
							cta = socSolicitudctas.getNroCuenta();
						}
					} else {
						throw new BusinessException("Error de parametrizacion, solicitante " + socSolicitudctas.getSolCodigo() + " sin tipo de entidad");
					}
				}
			} else {
				log.error("solicitante inexistente en socsolicitante " + socSolicitudctas.getSolCodigo());
				cta = socSolicitudctas.getNroCuenta();
			}

			if (StringUtils.isBlank(cta)) {
				throw new BusinessException("Nro Cuenta de provision de solicitante " + swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo()
						+ " nulo, revise la cuenta MOVPROVISION");
			}

			Map<String, List<String>> mapfieldf = new HashMap<>();
			List<String> lin1Name = MensSwiftUtiles.splitInLines(33, swiftDatos.getSolicitudTO().getSocSolicitante().getSolPersona(), 2, " ", "", 0);
			List<String> lin2Dir = MensSwiftUtiles.splitInLines(33, swiftDatos.getSolicitudTO().getSocSolicitante().getSolDireccion(), 2, " ", "", 0);
			List<String> lin3CtryTown = MensSwiftUtiles.splitInLines(33, swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza(), 1, " ", "", 0);

			mapfieldf.put("name", lin1Name);
			mapfieldf.put("address", lin2Dir);
			mapfieldf.put("country", lin3CtryTown);
//			
//			field = swiftMessageBcb.setField50F(cta, swiftDatos.getSolicitudTO().getSocSolicitante().getSolPersona(), 
//					swiftDatos.getSolicitudTO().getSocSolicitante().getSolDireccion(), swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza());

			field = SwiftMessageBcb.setField50F(cta, mapfieldf);

		} else if (campo.equals("50K")) {

			String cta = "";
			// 50k es la cuenta del cliente originante de la solicitud
			SocSolicitudctas socSolicitudctas = socSolicitudctasDao.getCuenta(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(),
					Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(socSolicitudctas.getSolCodigo());
			if (socSolicitante != null) {
				if (!StringUtils.isBlank(socSolicitante.getSolCodigo()) && socSolicitante.getSolCodigo().trim().equals(Constants.COD_BCB)) {
					// cta del bcb
					cta = socSolicitudctas.getNroCuenta();
				} else {
					if (!StringUtils.isBlank(socSolicitante.getClaEntidad())) {
						if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
							// la cta de provision pertenece a entidad es un bco
							// externo
							cta = socSolicitudctas.getNroLibreta();
						} else if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTPUBLICO)) {
							// es en el bcb
							cta = socSolicitudctas.getNroCuenta();
						}
					} else {
						throw new BusinessException("Error de parametrizacion, solicitante " + socSolicitudctas.getSolCodigo() + " sin tipo de entidad");
					}
				}
			} else {
				log.error("solicitante inexistente en socsolicitante " + socSolicitudctas.getSolCodigo());
				cta = socSolicitudctas.getNroCuenta();
			}

			if (StringUtils.isBlank(cta)) {
				throw new BusinessException("Nro Cuenta de provision de solicitante " + swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo()
						+ " nulo, revise la cuenta MOVPROVISION");
			}
			String nameAndLocation = StringUtils.trimToEmpty(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPersona()) + " ";
			nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(swiftDatos.getSolicitudTO().getSocSolicitante().getSolDireccion()) + " ";
			nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(swiftDatos.getSolicitudTO().getSocSolicitante().getSolPlaza());
			nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);

			field = SwiftMessageBcb.setField50K(cta, nameAndLocation);

		} else if (campo.equals("52A")) {
			field = SwiftMessageBcb.setField52A(null, swiftDatos.getSolicitudTO().getSocSolicitante().getSolBic());
		} else if (campo.equals("53B")) {
			// CORRESPONSAL DEL REMITENTE LUGAR
			// CTA BCB EN EL ESTANDAR
			// NOMBRE CTA
			SocCuentas socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(swiftDatos.getSolicitudTO().getSolicitud(), swfMensaje.getMenCodmon(), null);

			if (socCuentas != null) {
				BancoPlaza bancoPlazaSender = socBancosDao.bancoPlazaByCod(Constants.COD_BCB_SWIFT);

				field = SwiftMessageBcb.setField53B(socCuentas.getCtaNrocuenta(), bancoPlazaSender.getBcoNombre());
			}
		} else if (campo.equals("56A")) {
			// BIC INTERMEDIARIO
			// NOMBRE BCO INTERMEDIARO
			// intemediario
			// 56A
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBancointer());
			field = SwiftMessageBcb.setField56A(null, bancoPlaza.getPlaBic());

		} else if (campo.equals("57A")) {
			// BIC ENT. DEPOSITARIA DE LA CTA - FI BIC
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBanco());
			if (bancoPlaza == null) {
				throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con banco "
						+ swiftDatos.getSocDetallessol().getCodBanco() + " sin registro en bancos");
			}
			if (StringUtils.isBlank(bancoPlaza.getPlaBic())) {
				throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con Banco "
						+ swiftDatos.getSocDetallessol().getCodBanco() + " sin BIC requerido para Campo " + campo + " MT " + typeMsg);
			}
			field = SwiftMessageBcb.setField57A(null, bancoPlaza.getPlaBic());

		} else if (campo.equals("57D")) {
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getCodBanco());

			if (bancoPlaza == null) {
				throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con banco "
						+ swiftDatos.getSocDetallessol().getCodBanco() + " sin registro en bancos");
			}
			if (StringUtils.isBlank(swiftDatos.getSocDetallessol().getNroCuentabcointer())) {
				throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " con Banco "
						+ swiftDatos.getSocDetallessol().getCodBanco() + " sin Nro de cta o FW registrado, requerido para Campo " + campo + " MT " + typeMsg);
			}

			String nameAndLocation = StringUtils.trimToEmpty(bancoPlaza.getBcoNombre()) + " ";
			nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(bancoPlaza.getPlaNombre());
			nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);

			field = SwiftMessageBcb.setField57D(swiftDatos.getSocDetallessol().getNroCuentabcointer(), nameAndLocation);

		} else if (campo.equals("58A")) {
			// ENT BENEFICIARIA CON BIC
			// el beneficiario es un banco
			boolean esCartas = swiftDatos.getSolicitudTO().getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
					|| swiftDatos.getSolicitudTO().getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);

			BancoPlaza bancoPlaza = null;
			String nroCtaBco = "";
			if (esCartas) {
				Solicitud solicitud = cartasCredService.recuperarCartaYDetalleParaSolicitud(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
				bancoPlaza = socBancosDao.bancoPlazaByCod(solicitud.getCarCartascrdet().getCcdCodbcoreceptor());

				if (bancoPlaza == null) {
					throw new SwiftAdminException(
							"Entidad beneficiaria " + solicitud.getCarCartascrdet().getCcdCodbcoreceptor() + " sin registro en socbancos");
				}
				nroCtaBco = swiftDatos.getSocDetallessol().getNroCuentabco();
			} else {
				bancoPlaza = socBancosDao.bancoPlazaByCod(swiftDatos.getSocDetallessol().getNroCuentabco());

				if (bancoPlaza == null) {
					throw new SwiftAdminException("Entidad beneficiaria " + swiftDatos.getSocDetallessol().getNroCuentabco() + " sin registro en socbancos");
				}
			}

			if (StringUtils.isBlank(bancoPlaza.getPlaBic())) {
				throw new SwiftAdminException(
						"Entidad beneficiaria " + bancoPlaza.getSocBancos().getBcoCodigo() + " sin BIC, requerido para Campo " + campo + " MT " + typeMsg);
			}

			field = SwiftMessageBcb.setField58A(nroCtaBco, bancoPlaza.getPlaBic());
		} else if (campo.equals("58D")) {
			// ENT BENEFICIARIA NOMBRE DIRECCION
			SocBenefs socBenefs = socBenefsDao.getBenefsByBenCodigo(swiftDatos.getSocDetallessol().getBenCodigo());

			field = SwiftMessageBcb.setField58D(swiftDatos.getSocDetallessol().getNroCuentabco(), socBenefs.getBenNombre());

		} else if (campo.equals("59")) {
			List<Beneficiario> beneficiarios = socBenefsDao.beneficiariosExternosSolicitante(swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo(),
					swiftDatos.getSocDetallessol().getBenCodigo(), swfMensaje.getMenCodmon(), null, false);

			if (beneficiarios.size() > 0) {

				if (StringUtils.isBlank(beneficiarios.get(0).getBenDireccion()) || StringUtils.isBlank(beneficiarios.get(0).getBenPlaza())) {
					throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " - "
							+ beneficiarios.get(0).getBenNombre() + " sin registro de direccion o plaza");
				}

				String nameAndLocation = StringUtils.trimToEmpty(beneficiarios.get(0).getBenDireccion()) + ", ";
				nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(beneficiarios.get(0).getBenPlaza());

				nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);

				field = SwiftMessageBcb.setField59(swiftDatos.getSocDetallessol().getNroCuentabco(), beneficiarios.get(0).getBenNombre(), nameAndLocation);
			} else {
				throw new SwiftAdminException(swiftDatos.getSocDetallessol().getId().getDetCodigo() + ":: Campo " + campo + " MT " + typeMsg
						+ " beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " sin registro para ");
			}
		} else if (campo.equals("59F")) {
			List<Beneficiario> beneficiarios = socBenefsDao.beneficiariosExternosSolicitante(swiftDatos.getSolicitudTO().getSolicitud().getSolCodigo(),
					swiftDatos.getSocDetallessol().getBenCodigo(), swfMensaje.getMenCodmon(), null, false);

			if (beneficiarios.size() > 0) {

				if (StringUtils.isBlank(beneficiarios.get(0).getBenDireccion()) || StringUtils.isBlank(beneficiarios.get(0).getBenPlaza())) {
					throw new SwiftAdminException("Beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " - "
							+ beneficiarios.get(0).getBenNombre() + " sin registro de direccion o plaza");
				}

				String nameAndLocation = StringUtils.trimToEmpty(beneficiarios.get(0).getBenDireccion()) + ", ";
				nameAndLocation = nameAndLocation + StringUtils.trimToEmpty(beneficiarios.get(0).getBenPlaza());

				nameAndLocation = StringUtils.trimToEmpty(nameAndLocation);
				Map<String, List<String>> mapfieldf = new HashMap<>();
				List<String> lin1Name = MensSwiftUtiles.splitInLines(33, beneficiarios.get(0).getBenNombre(), 2, " ", "", 0);
				List<String> lin2Dir = MensSwiftUtiles.splitInLines(33, beneficiarios.get(0).getBenDireccion(), 2, " ", "", 0);
				List<String> lin3CtryTown = MensSwiftUtiles.splitInLines(33, beneficiarios.get(0).getBenPlaza(), 1, " ", "", 0);

				mapfieldf.put("name", lin1Name);
				mapfieldf.put("address", lin2Dir);
				mapfieldf.put("country", lin3CtryTown);

//				field = swiftMessageBcb.setField59F(swiftDatos.getSocDetallessol().getNroCuentabco(), beneficiarios.get(0).getBenNombre(), nameAndLocation);
				field = SwiftMessageBcb.setField59F(swiftDatos.getSocDetallessol().getNroCuentabco(), mapfieldf);
			} else {
				throw new SwiftAdminException(swiftDatos.getSocDetallessol().getId().getDetCodigo() + ":: Campo " + campo + " MT " + typeMsg
						+ " beneficiario " + swiftDatos.getSocDetallessol().getBenCodigo() + " sin registro para ");
			}
		} else if (campo.equals("70")) {
			requerido = false;
			if (!StringUtils.isBlank(swiftDatos.getSocDetallessol().getDetConcepto())) {
				String valor = swiftDatos.getSocDetallessol().getTipoConcepto();
				if (!StringUtils.isBlank(valor) && valor.equals("INV")) {
					valor = "/" + swiftDatos.getSocDetallessol().getTipoConcepto() + "/";
					valor = valor.concat(swiftDatos.getSocDetallessol().getDetConcepto().trim());
				} else {
					valor = swiftDatos.getSocDetallessol().getDetConcepto().trim();
				}
				field = SwiftMessageBcb.setField70(valor);
			}
		} else if (campo.equals("71A")) {
			field = SwiftMessageBcb.setField71A(valCampo);
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				if (swiftDatos.getSolicitudTO().getSolicitud().getCodMonedat().compareTo(Constants.COD_MONEDA_USD) != 0) {
					field = SwiftMessageBcb.setField71A("BEN");
				}
			}

		} else if (campo.equals("71F")) {
			requerido = false;
			// whf: solo en moneda de la union europea exigen el campo 71F
			if (swiftDatos.getSolicitudTO().getSolicitud().getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				if (swiftDatos.getSolicitudTO().getSolicitud().getCodMonedat().compareTo(Constants.COD_MONEDA_USD) != 0) {

					SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo(), 0,
							"MONTOORDCOMIS");
					if (socOpecomi == null || socOpecomi.getMontoMo().compareTo(BigDecimal.valueOf(0)) <= 0) {
						throw new BusinessException(
								"No se puede hallar MONTOORDCOMIS para Solicitud con descuento " + swiftDatos.getSolicitudTO().getSolicitud().getSocCodigo());
					}

					GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
					BigDecimal montoOrd = socOpecomi.getMontoMo();

					BigDecimal monto = montoOrd.setScale(2, RoundingMode.HALF_UP);

					field = SwiftMessageBcb.setField71F(genMoneda.getMonSigla(), monto);
				}
			}
		} else if (campo.equals("72")) {
			boolean esCartas = swiftDatos.getSolicitudTO().getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
					|| swiftDatos.getSolicitudTO().getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS);
			if (esCartas || swiftDatos.getSolicitudTO().getSolicitud().getEsqCodigo().compareTo(Constants.CODESQ_TRANSFEXT_SISTFIN) == 0
					|| swiftDatos.getSolicitudTO().getSolicitud().getEsqCodigo().compareTo(Constants.CODESQ_TRANSFEXT_OPERSBCB) == 0) {
				field = SwiftMessageBcb.setField72SinModificar(swiftDatos.getSocDetallessol().getDetInfo());
			} else {
				field = SwiftMessageBcb.setField72(swiftDatos.getSocDetallessol().getDetInfo());
			}

			requerido = false;
		} else {
			throw new SwiftAdminException("Campo " + campo + " Cod MT " + typeMsg + " no definido avise a sistemas ");
		}

		if (requerido && (field == null || field.isEmpty())) {
			throw new SwiftAdminException("Campo " + campo + " Cod MT " + typeMsg + " sin definicion de valor, avise a sistemas");
		}

//		if (field != null) {
//			log.info("Valor obtenido: " + typeMsg + ":" + campo + " => " + field.getValue());
//		}

		if (field == null || field.isEmpty()) {
			return null;
		}

		if (field.isEmpty()) {
			return null;
		}

		return field;
	}

	private SwfMensaje guardarSwiftObjectMx(SwiftDatos swiftDatos, Instruccion instruccion) {
		try {
			String mtMx = instruccion.getMessageHolder().getMenPlano();
//			log.info(mtMx);
			swiftDatos.getSwfMensaje().setMenPlano(mtMx);
			swiftDatos.getSwfMensaje().setMenFormato(instruccion.getSwfMsgParam().getMenFormato());

			SwfMensaje swfMensajeNew = swfMensajeLocal.saveorupdate(swiftDatos.getSwfMensaje());

			SwfMensaje swfMensaje = swfMensajeLocal.findByCodigo(swfMensajeNew.getMenCodmen());
			if (StringUtils.isBlank(swfMensaje.getMenPlano())) {
				throw new SwiftAdminException("No se pudo guardar Mensaje Swift, valor nulo. Repita el procedimiento");
			}
			swiftDatos.setSwfMensaje(swfMensaje);

			log.info("==>SWIFT Salvado hecho ... " + swfMensaje.getMenCodmen() + " oper: " + swfMensaje.getMenCodoperacion() + "\n"
					+ swfMensaje.getMenPlano());
			return swfMensaje;
		} catch (Exception e) {
			log.error("Error al actualizar swift " + e.getMessage(), e);
			throw new SwiftAdminException("Error al actualizar swift " + e.getMessage());
		}
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void inicializar() {
		swfMttransferLocal.setSessionFactory(getSessionFactory());
		swfPersonactaLocal.setSessionFactory(getSessionFactory());
		swfMensajeLocal.setSessionFactory(getSessionFactory());
		swfDetmensajeLocal.setSessionFactory(getSessionFactory());
		socBancosDao.setSessionFactory(getSessionFactory());
		socBenefsDao.setSessionFactory(getSessionFactory());
		swfMencamposDbDao.setSessionFactory(getSessionFactory());

		swfMencamposIsoDaoImpl.setSessionFactory(sessionFactory);
		socCuentassolDao.setSessionFactory(sessionFactory);
		socSolicitudctasDao.setSessionFactory(sessionFactory);
		socSolicitanteDao.setSessionFactory(sessionFactory);
		genMonedaDao.setSessionFactory(sessionFactory);
		socOpecomiDao.setSessionFactory(sessionFactory);
		socCuentasDao.setSessionFactory(sessionFactory);
		swiftMessageMXService.setSessionFactory(sessionFactory);
		cartasCredService = new CartasCredService(getSessionFactory(), SiocCoinService.getSessionFactory());
	}

	public SwfMsgParam recMsgParms(SwiftDatos swiftDatos) {
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		SwfMttransfer swfMttransfer = swfMttransferLocal.findByCodigo(swfMensaje.getMenCodmt());
		if (swfMttransfer == null) {
			throw new SwiftAdminException("Tipo de mensaje " + swfMensaje.getMenCodmt() + " no parametrizado en SwfMttransfer.");
		}
		if (StringUtils.isBlank(swfMttransfer.getMttFormato())
				|| (!swfMttransfer.getMttFormato().equalsIgnoreCase("MT")) && !swfMttransfer.getMttFormato().equalsIgnoreCase("MX")) {
			throw new SwiftAdminException("Formato " + swfMensaje.getMenCodmt() + " invalido en SwfMttransfer. Se esperaba MT o MX");
		}
		// log.info("MT " + swfMttransfer.getMttCodmt() + ":" +
		// swfMttransfer.getMttCodttransfer());
		SwfMsgParam swfMsgParam = new SwfMsgParam();

		swfMsgParam.setMenTypemessage(swfMttransfer.getMttCodmt());
		swfMsgParam.setMenIdTMessageTx(swfMttransfer.getMttCodttransfer());
		swfMsgParam.setMenHdrversion(swfMttransfer.getMttVerheader());
		swfMsgParam.setMenEmisor(swfMensaje.getMenBicemisor());
		swfMsgParam.setMenReceiver(swfMensaje.getMenBic());
		swfMsgParam.setMenBic(swfMensaje.getMenBic());
		swfMsgParam.setMenCodmen(swfMensaje.getMenCodmen());
		swfMsgParam.setMenCodmenOrig(swfMensaje.getMenCodmen() != null ? swfMensaje.getMenCodmen().toString() : null);
		swfMsgParam.setMenCodmenrefer(swfMensaje.getMenCodoperacion());
		String codigoOperacion = String.valueOf(swfMensaje.getMenCodoperacion() + "" + swfMensaje.getMenDetcodigo());
		swfMsgParam.setMenIdoperacion(codigoOperacion);
		swfMsgParam.setMenGestion(GregorianCalendar.getInstance().get(Calendar.YEAR));
		swfMsgParam.setMenCodmon(swfMensaje.getMenCodmonswift());
		swfMsgParam.setMenFecreg(swfMensaje.getMenFecreg());
		swfMsgParam.setMenFecauto(swfMensaje.getMenFecauto());
		swfMsgParam.setMenEstmensaje(swfMensaje.getMenCveestswift());
		swfMsgParam.setMenCodusrswf(swfMensaje.getMenCodusrswf());
		swfMsgParam.setMenPlano(swfMensaje.getMenPlano());
		swfMsgParam.setMenNrocorr(swfMensaje.getMenNrolavado());
		swfMsgParam.setMenFormato(swfMttransfer.getMttFormato());
		swfMsgParam.setMenCodapp(Constants.CODAPP_SIOC);
		swfMsgParam.setMenFecvalor(swfMensaje.getMenFecvalor());
		String idMessage = msgID(new Date(), swfMensaje.getMenNrocorr(), swfMensaje.getMenCodusrswf());
		swfMensaje.setMenCodswift(idMessage);
		swfMsgParam.setMenCodswift(swfMensaje.getMenCodswift());

		swiftDatos.setSwfMttransfer(swfMttransfer);
		return swfMsgParam;
	}

	public static String msgID(Date fecha, Integer corrIn, String codUser) {
		String userIniciales = StringUtils.trim(codUser);

		String corr = String.format("%04d", (corrIn == null ? 0 : corrIn));
		String fecStr = UtilsDate.stringFromDate(new Date(), "ddMMyy");

		String valor = corr + "/" + fecStr + "/" + userIniciales;

		return valor;
	}
}
