package gob.bcb.service.servicioSioc.logic;

import static gob.bcb.iso20022.excel.enums.FieldTypeEnum.DATE;
import static gob.bcb.iso20022.excel.enums.FieldTypeEnum.STRING;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.bpm.pruebaCU.ExpExporttrxdet;
import gob.bcb.bpm.pruebaCU.ExpExporttrxdetPK;
import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.iso20022.excel.ExcelFactory;
import gob.bcb.iso20022.excel.core.data.HeaderData;
import gob.bcb.iso20022.excel.core.data.HeaderDataBuilder;
import gob.bcb.iso20022.excel.core.listener.DataReadListener;
import gob.bcb.iso20022.excel.enums.FieldTypeEnum;
import gob.bcb.iso20022.excel.enums.FileTypeEnum;
import gob.bcb.swift.service.ArchivoSinpleServiceImpl;

public class ExportsUpload {
	private final static Logger log = LoggerFactory.getLogger(ExportsUpload.class);
	
	public static List<ExpExporttrxdet> loadFile(ArchivoSinpleServiceImpl archivoSinpleService, String nameSheet, Integer firstRow) {
		HeaderDataBuilder hdrDBuilder = headersCsvExport().nameSheet(nameSheet).firstRowData(firstRow);
		ArchivoSinple file = archivoSinpleService.getArchivoSinple();
		
		log.info("Inicio carga " + file.getName());
	
		ExcelFactory excelFactory = ExcelFactory.build().readInstance(file.getStream(), ExpExporttrxdet.class, hdrDBuilder.getHeaderContent(),
				hdrDBuilder.getNameSheet());
		excelFactory.setSheetName(nameSheet);
		//excelFactory.setFileTypeEnum(FileTypeEnum.XLSX);
		excelFactory.setFileTypeEnum(FileTypeEnum.CSV);
		excelFactory.createCsvFormat('|', '"');
		
		AtomicInteger row = new AtomicInteger();
		row.set(0);
		List<ExpExporttrxdet> impList = new ArrayList<>();
		excelFactory.read(new DataReadListener<ExpExporttrxdet>((regs -> {
			regs.forEach(u -> {
				impList.add(u);
			});
		})) {
			@Override
			public void invoke(ExpExporttrxdet data) {
				int item = row.addAndGet(1);
				ExpExporttrxdetPK id = new ExpExporttrxdetPK();
				id.setDexNrodet(item);
				data.setId(id);
				data.setDexMontomo(data.getDexMontomo() == null ? BigDecimal.ZERO : data.getDexMontomo());
				data.setDexMontousd(data.getDexMontousd() == null ? BigDecimal.ZERO : data.getDexMontousd());
				data.setDexMontomn(data.getDexMontomn() == null ? BigDecimal.ZERO : data.getDexMontomn());
				data.setDexMontopar(data.getDexMontopar() == null ? BigDecimal.ZERO : data.getDexMontopar());
				
				data.setDexCodmonmo((StringUtils.isBlank(data.getDexCodmonmo()) ? "" : data.getDexCodmonmo()).trim());
				data.setDexMontomo(data.getDexMontomo().setScale(2, BigDecimal.ROUND_HALF_UP));
				data.setDexMontousd(data.getDexMontousd().setScale(2, BigDecimal.ROUND_HALF_UP));
				data.setDexMontopar(data.getDexMontopar().setScale(2, BigDecimal.ROUND_HALF_UP));
				data.setDexMontomn(data.getDexMontomn().setScale(2, BigDecimal.ROUND_HALF_UP));
				super.invoke(data);
			}
		});
		log.info("Fin carga " + file.getName() + " con regs: " + impList.size());
		return impList;
	}


	public static HeaderDataBuilder headersCsvExport() {
		HeaderDataBuilder headerDataBuilder = HeaderDataBuilder.instance();
		List<HeaderData> headerDataList = headerDataBuilder//
				.fill("dexCoddetorig", STRING, 0) //
				.fill("dexFecvalid",DATE,1 ) //
				.fill("dexExportador", STRING, 2) //
				.fill("dexNrofact", STRING, 3) //
				.fill("dexMontousd", FieldTypeEnum.BIG_DECIMAL, 4) //
				.fill("dexTcorig", FieldTypeEnum.BIG_DECIMAL, 5) //
				.fill("dexMontomo", FieldTypeEnum.BIG_DECIMAL, 6) //
				.fill("dexTccont", FieldTypeEnum.BIG_DECIMAL, 7) //
				.fill("dexMontomn", FieldTypeEnum.BIG_DECIMAL, 8) //
				.fill("dexMontodiff", FieldTypeEnum.BIG_DECIMAL, 9) //
				.build();
		return headerDataBuilder;
	}
	
	public static HeaderDataBuilder headersXlsExport0() {
		HeaderDataBuilder headerDataBuilder = HeaderDataBuilder.instance();
		List<HeaderData> headerDataList = headerDataBuilder//
				.fill("dexTramite", FieldTypeEnum.STRING, 0) //
				.fill("dexFecvalid", FieldTypeEnum.DATE, 2) //
				.fill("dexFecconfirma", FieldTypeEnum.DATE, 3) //
				.fill("dexPatron", FieldTypeEnum.STRING, 4) //
				.fill("dexDocexport", FieldTypeEnum.STRING, 5) //
				.fill("dexExportador", FieldTypeEnum.STRING, 6) //
				.fill("dexPaisdest", FieldTypeEnum.STRING, 7) //
				.fill("dexMontomo", FieldTypeEnum.BIG_DECIMAL, 8) //
				.fill("dexCodmonmo", FieldTypeEnum.STRING, 9) //
				//.fill("dexTcorig", FieldTypeEnum.BIG_DECIMAL, 8) //
				.fill("dexDescrip", FieldTypeEnum.STRING, 12) //
				.fill("dexMontousd", FieldTypeEnum.BIG_DECIMAL, 14) //
				.fill("dexSector", FieldTypeEnum.STRING, 15) //
				//.firstRowData(2)//
				.build();
		return headerDataBuilder;
	}	
}
