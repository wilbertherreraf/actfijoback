package gob.bcb.swift.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import com.prowidesoftware.swift.model.mx.JaxbContextCacheImpl;
import com.prowidesoftware.swift.model.mx.JaxbContextLoader;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.servicioSioc.logic.SwiftSiocService;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.pojos.SwiftDatos;

public class SwiftMessageMXServiceTest extends BaseData {
	private static final Log log = LogFactory.getLog(SwiftMessageMXServiceTest.class);

	// @Test
	public void obtenerFactsTest() {
		try {
			log.info("================================");
			Date fechaDesde = UtilsDate.dateFromString("01/01/2022", "dd/MM/yyyy");
			Date fechaAl = UtilsDate.dateFromString("20/08/2023", "dd/MM/yyyy");
			String mt = "pacs.008.001";
			List<SolicitudesS> ls = socSolicitudesDao.recuperarSolicitudes(null, "VE,TE,OB", "TE", "C", "N,P", null, null, null, fechaDesde, fechaAl, null)
					.stream()//
					.limit(150)//
					.collect(Collectors.toList());

			log.info("inicio regs " + ls.size());
			List<String> lc = new ArrayList<>();
			List<String> lca = new ArrayList<>();
			ls.forEach(c -> {

				String socCodigo = c.getSocCodigo();
				log.info("******** " + socCodigo + " ********");
				SwiftDatos swiftDatos = createSwiftDatos(socCodigo, mt, null);
				if (swiftDatos != null) {
					SwfMsgParam swfMsgParam = swiftMessageService.recMsgParms(swiftDatos);
					if (!StringUtils.isBlank(swfMsgParam.getMenFormato())) {
						CreateSwiftService createSwiftService = new CreateSwiftService(swfMsgParam, swfMencamposIsoDaoImpl);
						// createSwiftService.initInstruccion();
						swiftMessageMXService.obtenerFacts(swiftDatos, createSwiftService);
					}
				}
			});

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

//	@Test
	public void translateTest() {
		try {
			log.info("================================");
			String mt = "pacs.008.103F";
			String socCodigo = "045032";
			log.info("******** " + socCodigo + " ********");
			SwiftDatos swiftDatos = createSwiftDatos(socCodigo, mt, null);
			if (swiftDatos != null) {
				SwfMsgParam swfMsgParam = swiftMessageService.recMsgParms(swiftDatos);
				if (!StringUtils.isBlank(swfMsgParam.getMenFormato())) {
					CreateSwiftService createSwiftService = new CreateSwiftService(swfMsgParam, swfMencamposIsoDaoImpl);
					swiftMessageMXService.obtenerFacts(swiftDatos, createSwiftService);
					Instruccion instruccion = createSwiftService.getInstruccion();
					createSwiftService.recuperarCampos(instruccion.isMt() ? "4" : "");
					createSwiftService.registerFuncsDef();
					createSwiftService.initEngine();
					createSwiftService.translate();
					createSwiftService.translatePost();
					createSwiftService.generaHeaderMsg();
					createSwiftService.createMsgSwift();
					String menPlano = instruccion.getMessageHolder().getMenPlano();
					log.info(menPlano);

					SwiftMessageAbstract sma = FactoryParser.createParser(menPlano).extractMetadata();

					log.info("messageType()) " + sma.messageType());
					log.info("getMenIdTMessageTx " + sma.getSwfMsgParam().getMenIdTMessageTx());
					log.info("Receiver()) " + sma.getReceiver());
					log.info("Sender()); " + sma.getSender());
					log.info("getMenCodswift " + sma.getSwfMsgParam().getMenCodswift());
					log.info("SwfMsgParam " + sma.getSwfMsgParam().getMenCodmon());
					log.info("SwfMsgParam " + sma.getSwfMsgParam().getMenFormato());
					log.info("SwfMsgParam " + sma.getSwfMsgParam().getMenInout());

					List<String> errors = sma.validateSyntax();
					log.info("errors " + errors.size());
					errors.forEach(e -> {
						log.info("error " + e);
					});

				}
			}

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	@Test
	public void translateOpersToMXTest() {
		try {
			Map<String, String> mapCtrl = new HashMap<>();
			Date fechaDesde = UtilsDate.dateFromString("01/06/2022", "dd/MM/yyyy");
			Date fechaAl = UtilsDate.dateFromString("30/08/2022", "dd/MM/yyyy");

			List<SolicitudesS> ls = socSolicitudesDao.recuperarSolicitudes(null, "VE,TE,OB", "TE", null, "N,P", null, null, null, fechaDesde, fechaAl, null)
					.stream()//
					//.limit(10)//
					.collect(Collectors.toList());
//			List<SolicitudesS> ls = Arrays.asList("025734","025828").stream().map(c -> {
//				SolicitudesS solicitudSS = new SolicitudesS();
//				solicitudSS.setSocCodigo(c);
//				return solicitudSS;
//			}).collect(Collectors.toList());
			
			log.info("=======inicio regs================== "+ ls.size());
			List<String> lc = new ArrayList<>();
			List<String> lca = new ArrayList<>();
			
			long buildTime = System.currentTimeMillis();
			
			
			for (SolicitudesS soc : ls) {
				buildTime = System.currentTimeMillis();
				SwiftDatos swiftDatos = createSwiftDatos(soc.getSocSolicitudes(), soc.getSocCodigo(), null);
				SocSolicitudes s = swiftDatos.getSolicitudTO().getSolicitud();
				String socCodigo = s.getSocCodigo();

				String ksc = s.getCveSubtipooper() + s.getClaTipo() + s.getCveTipctasolic() + s.getSolEntsolic() + s.getEsqCodigo() + s.getSocTipnegociacion()
						+ s.getTipoRetencion() + s.getTipoConcepto();

				if (mapCtrl.containsKey(ksc)) {
					continue;
				}

				log.info("******** " + s.getSocCodigo() + "[" + ksc + "] ********");
				for (SocDetallessol socDetallessol : swiftDatos.getSolicitudTO().getSocDetallessolLista()) {
					swiftDatos.setSwfMensaje(null);
					SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
					if (swfMensaje == null) {
						continue;
					}
					String mtPlano = swfMensaje.getMenPlano();
					String mt = swfMensaje.getMenCodmt();
					if (mt.startsWith("103")) {
						mt = "pacs.008." + mt;
					} else if (mt.startsWith("202")) {
						mt = "pacs.009." + mt;
					} else {
						log.error("||||||||| MT no reconocido " + swfMensaje.getMenCodmt());
						continue;
					}
					log.info("+++++++ " + s.getSocCodigo() + "-" + socDetallessol.getId().getDetCodigo() + " men: " + swfMensaje.getMenCodmen() + "[" + mt
							+ " -> " + swfMensaje.getMenCodmt() + "+++++++");
					swiftDatos.setSwfMensaje(swfMensaje);
					actMensaje(socCodigo, swiftDatos, socDetallessol, mt);

					CreateSwiftService createSwiftService = swiftMessageService.genSwiftMxMt(swiftDatos);
					Instruccion instruccion = createSwiftService.getInstruccion();
					String menPlano = instruccion.getMessageHolder().getPayLoad();
					log.info(mtPlano);
					log.info("------------ new ------------Done at (" + (System.currentTimeMillis() - buildTime) + " ms.)");
					log.info(menPlano);

					SwiftMessageAbstract sma = FactoryParser.createParser(menPlano).extractMetadata();

					List<String> errors = sma.validateSyntax();
					log.info("errors valid: " + errors.size() + " " + (errors.size() > 0 ? "Errores en MX" : ""));
					errors.forEach(e -> {
						log.info("error " + e);
					});
				}
				mapCtrl.put(ksc, s.getSocCodigo());
			}
			log.info("total diff: " + mapCtrl.size());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void translateFullTest() {
		try {
			Map<String, String> mapCtrl = new HashMap<>();
			log.info("================================");
			Date fechaDesde = UtilsDate.dateFromString("01/08/2019", "dd/MM/yyyy");
			Date fechaAl = UtilsDate.dateFromString("30/08/2020", "dd/MM/yyyy");

			List<SolicitudesS> ls = socSolicitudesDao.recuperarSolicitudes(null, "VE,TE,OB", "TE", null, "N,P", null, null, null, fechaDesde, fechaAl, null)
					.stream()//
					.limit(5)//
					.collect(Collectors.toList());

			log.info("inicio regs " + ls.size());
			List<String> lc = new ArrayList<>();
			List<String> lca = new ArrayList<>();

			ls.forEach(c -> {
				String socCodigo = c.getSocCodigo();
				String mt = "pacs.008.103B";
				SwiftDatos swiftDatos = createSwiftDatos(socCodigo, "", null);
				if (swiftDatos != null) {
					mt = swiftDatos.getSwfMensaje().getMenCodmt().startsWith("202") ? "pacs.009.001" : "pacs.008.001";

					SocSolicitudes s = swiftDatos.getSolicitudTO().getSolicitud();
					String ksc = s.getCveSubtipooper() + s.getClaTipo() + s.getCveTipctasolic() + s.getSolEntsolic() + s.getEsqCodigo()
							+ s.getSocTipnegociacion() + s.getTipoRetencion() + s.getTipoConcepto() + swiftDatos.getSwfMensaje().getMenCodmt();
//					log.info("******** " + socCodigo + "[" + ksc + "] ********");
					swiftDatos.getSwfMensaje().setMenCodmt(mt);
					SwfMsgParam swfMsgParam = swiftMessageService.recMsgParms(swiftDatos);
					if (!StringUtils.isBlank(swfMsgParam.getMenFormato()) && mt.equals("pacs.008.001")) {
						if (!mapCtrl.containsKey(ksc)) {

							log.info("******** " + socCodigo + "[" + ksc + "] ********");
							log.info("\n" + swiftDatos.getSwfMensaje().getMenPlano());
							CreateSwiftService createSwiftService = new CreateSwiftService(swfMsgParam, swfMencamposIsoDaoImpl);
							swiftMessageMXService.obtenerFacts(swiftDatos, createSwiftService);
							Instruccion instruccion = createSwiftService.getInstruccion();
							createSwiftService.recuperarCampos(instruccion.isMt() ? "4" : "");
							createSwiftService.registerFuncsDef();
							createSwiftService.initEngine();
							createSwiftService.generaHeaderMsg();
							createSwiftService.translate();
							createSwiftService.translatePost();
							createSwiftService.createMsgSwift();
							String menPlano = instruccion.getMessageHolder().getMenPlano();
							log.info(menPlano);

							SwiftMessageAbstract sm = FactoryParser.createParser(menPlano);
							List<String> errors;
							try {
								errors = sm.validateSyntax();
								log.info("errors " + errors.size());
								errors.forEach(e -> {
									log.info("error " + e);
								});
							} catch (Exception e1) {
								// e1.printStackTrace();
								log.error("EEEEEError en valid :_" + e1.getMessage());
							}
							mapCtrl.put(ksc, s.getSocCodigo());
						}
					}
				}
			});
			log.info("total " + mapCtrl.size());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void generarMensSwiftTest() {
		try {
			log.info("===========generarMensSwift=====================");
			String mt = "pacs.008.103F";
			String socCodigo = "045036";
			// String socCodigo = "037533"; // "040330"; //
			Solicitud solicitudTO = cpySolicitud(socCodigo, null);
			long buildTime = System.currentTimeMillis();
			JaxbContextLoader.INSTANCE.setCacheImpl(new JaxbContextCacheImpl());
			log.info("******** " + socCodigo + " -> " + solicitudTO.getSolicitud().getSocCodigo() + " ********");
			swiftSiocService.generarMensSwift(solicitudTO);
			log.info("Done at (" + (System.currentTimeMillis() - buildTime) + " ms.)");
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void genYActMensSwiftTest() {
		try {
			log.info("===========genYActMensSwiftTest=====================");
			String socCodigo = "045036";
			Solicitud solicitudTO = populateSolicitudTO(socCodigo);
			long buildTime = System.currentTimeMillis();

			for (SocDetallessol socDetallessol : solicitudTO.getSocDetallessolLista()) {
				SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
				if (swfMensaje != null) {
					swfMensaje.setMenCveestswift("P");
					swfMensajeBean.getHibernateTemplate().merge(swfMensaje);
				}
			}

			solicitudTO.setCodUsuarioAudit("190");
			log.info("******** " + socCodigo + " -> " + solicitudTO.getSolicitud().getSocCodigo() + " ********");
			swiftSiocService.generarMensSwift(solicitudTO);
			log.info("Done at (" + (System.currentTimeMillis() - buildTime) + " ms.)");
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void actCorrelativoSwiftTest() {
		try {
			log.info("===========actCorrelativoSwift=====================");
			String mt = "pacs.008.001";
			String socCodigo = "045036";
			Solicitud solicitudTO = populateSolicitudTO(socCodigo);
			for (SocDetallessol socDetallessol : solicitudTO.getSocDetallessolLista()) {
				SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
				if (swfMensaje != null) {
					swfMensaje.setMenCveestswift("P");
					swfMensajeBean.getHibernateTemplate().merge(swfMensaje);
				}
			}

			SwiftSiocService swiftSiocService = new SwiftSiocService();
			swiftSiocService.setSessionFactory(sessionFactorySioc);
			solicitudTO.setCodUsuarioAudit("190");
			long buildTime = System.currentTimeMillis();
			log.info("******** " + socCodigo + " -> " + solicitudTO.getSolicitud().getSocCodigo() + " ********");
			// JaxbContextLoader.INSTANCE.setCacheImpl(new JaxbContextCacheImpl());
			swiftSiocService.preAutorizarSwift(solicitudTO);
			log.info("Done at (" + (System.currentTimeMillis() - buildTime) + " ms.)");
			swiftSiocService = new SwiftSiocService();
			swiftSiocService.setSessionFactory(sessionFactorySioc);
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	// @Test
	public void preautorizarSwiftTest() {
		try {
			log.info("===========preautorizarSwift=====================");
			String mt = "pacs.008.001";
			String socCodigo = "044997";
			Solicitud solicitudTO = procesosSolicitud.recuperarSolicitudSimple(socCodigo);
			solicitudTO.setCodUsuarioAudit("190");
			log.info("******** " + socCodigo + " -> " + solicitudTO.getSolicitud().getSocCodigo() + " ********");
			swiftSiocService.autorizarSwift(solicitudTO);

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

//	@Test
	public void cicloCompTest() {
		try {
			log.info("===========cicloCompTest=====================");
			String mt = "103F";
			// mt = "pacs.008.001";
			String socCodigo = "044545";// "044545";
			Solicitud solicitudTO = cpySolicitud(socCodigo, mt);
			// Solicitud solicitudTO =
			// procesosSolicitud.recuperarSolicitudSimple(socCodigo);
			log.info("******** " + socCodigo + " -> " + solicitudTO.getSolicitud().getSocCodigo() + " ********");
			swiftSiocService.generarMensSwift(solicitudTO);
			solicitudTO.setCodUsuarioAudit("190");
			solicitudTO.setCodPersonaAudit("900");
			log.info("******** PREEEE " + socCodigo + " -> " + solicitudTO.getSolicitud().getSocCodigo() + " ********");
			swiftSiocService.preAutorizarSwift(solicitudTO);

			log.info("******** AUTOOOO " + socCodigo + " -> " + solicitudTO.getSolicitud().getSocCodigo() + " ********");
			swiftSiocService.autorizarSwift(solicitudTO);

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	public SwiftDatos createSwiftDatos(String socCodigo, String mttCodttransfer, SocDetallessol socDet) {
		Solicitud solicitud = new Solicitud();
		SocSolicitudes solicitudOld = socSolicitudesDao.getSolicitud(socCodigo);
		solicitud.setSolicitud(solicitudOld);

		List<SocDetallessol> socDetallessolLista = socDetallessolDao.getDetalles(solicitudOld.getSocCodigo());
		solicitud.setSocDetallessolLista(socDetallessolLista);

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitud.getSolicitud().getSolCodigo());
		solicitud.setSocSolicitante(socSolicitante);

		SwiftDatos swiftDatos = new SwiftDatos();
		swiftDatos.setAuditusr(solicitud.getSolicitud().getUsrCodigo());
		swiftDatos.setAuditwst(solicitud.getSolicitud().getEstacion());
		swiftDatos.setSolicitudTO(solicitud);

		SocDetallessol socDetallessol = socDet == null ? solicitud.getSocDetallessolLista().get(0) : socDet;
		swiftDatos.setSocDetallessol(socDet);
		SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socCodigo, socDetallessol.getId().getDetCodigo());
		if (swfMensaje == null)
			return null;
		if (!StringUtils.isBlank(mttCodttransfer)) {
			swfMensaje.setMenCodmt(mttCodttransfer);
		}
		swfMensaje.setMenMonto(socDetallessol.getDetMontotrans());
		swfMensaje.setMenCodmon(solicitud.getSolicitud().getCodMonedat());
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenFecvalor(solicitud.getSolicitud().getFechaCont());
		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PEND);
		swfMensaje.setMenAuditusr(solicitud.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitud.getCodEstacionAudit());

		swiftDatos.setSwfMensaje(swfMensaje);
		return swiftDatos;
	}

	public SwiftDatos createSwiftDatos(SocSolicitudes socSolicitud, String socCodigo, String mttCodttransfer) {
		Solicitud solicitud = new Solicitud();
		if (socSolicitud == null) {
			socSolicitud = socSolicitudesDao.getSolicitud(socCodigo);
		}
		solicitud.setSolicitud(socSolicitud);
		
		List<SocDetallessol> socDetallessolLista = socDetallessolDao.getDetalles(socCodigo);
		solicitud.setSocDetallessolLista(socDetallessolLista);

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(solicitud.getSolicitud().getSolCodigo());
		solicitud.setSocSolicitante(socSolicitante);

		SwiftDatos swiftDatos = new SwiftDatos();
		swiftDatos.setAuditusr(solicitud.getSolicitud().getUsrCodigo());
		swiftDatos.setAuditwst(solicitud.getSolicitud().getEstacion());
		swiftDatos.setSolicitudTO(solicitud);

		solicitud.setsIOCWEB_TIPOPERACION("preauto");
		solicitud.setCodPersonaAudit("900");

		return swiftDatos;
	}

	public void actMensaje(String socCodigo, SwiftDatos swiftDatos, SocDetallessol socDetallessol, String mt) {
		SocSolicitudes s = swiftDatos.getSolicitudTO().getSolicitud();
		swiftDatos.setSocDetallessol(socDetallessol);
		SwfMensaje swfMensaje = swiftDatos.getSwfMensaje();
		if (swiftDatos.getSwfMensaje() == null) {
			swfMensaje = swfMensajeBean.findByCodoperacion(socCodigo, socDetallessol.getId().getDetCodigo());
		}
		if (swfMensaje == null)
			return;
		if (!StringUtils.isBlank(mt)) {
			swfMensaje.setMenCodmt(mt);
		}

		swfMensaje.setMenMonto(socDetallessol.getDetMontotrans());
		swfMensaje.setMenCodmon(socDetallessol.getCodMonedatdet());
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenFecvalor(s.getFechaCont());
		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PEND);
		swfMensaje.setMenAuditusr(swiftDatos.getSolicitudTO().getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(swiftDatos.getSolicitudTO().getCodEstacionAudit());

		swiftDatos.setSwfMensaje(swfMensaje);

	}

	public Solicitud recuperarSolicitud(String socCodigo, String mttCodttransfer) {

		Solicitud solicitud = populateSolicitudTO(socCodigo);

		solicitud.getSolicitud().setFechaCont(new Date());
		solicitud.getSolicitud().setFechaHora(new Date());
		solicitud.setCodUsuarioAudit("190");
		socSolicitudesDao.getHibernateTemplate().merge(solicitud.getSolicitud());

		for (SocDetallessol socDetallessol : solicitud.getSocDetallessolLista()) {
			socDetallessol.setDetCodttransfer(mttCodttransfer);
			socDetallessolDao.getHibernateTemplate().merge(socDetallessol);
			SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
			if (swfMensaje != null) {
				swfMensaje.setMenNrocorr(null);
				swfMensaje.setMenCveestswift("1");
				swfMensajeBean.getHibernateTemplate().merge(swfMensaje);
			}
		}
		return solicitud;
	}

	public Solicitud cpySolicitud(String socCodigo, String mttCodttransfer) {

		Solicitud solicitud = populateSolicitudTO(socCodigo);
		log.info("Old solicitud copiada " + solicitud.getSocCodigo() + " det: " + solicitud.getSocDetallessolLista().size() + " cta: "
				+ solicitud.getSocSolicitudctasLista().size() + " ope: " + solicitud.getSocOpecomiLista().size());

		solicitud.getSolicitud().setSocCodigo(null);
		solicitud.getSolicitud().setFechaCont(new Date());
		solicitud.getSolicitud().setFechaHora(new Date());
		SocSolicitudes solicitudNew = socSolicitudesDao.crearActualizar(solicitud.getSolicitud());
		// List<SocDetallessol> socDetallessolListaNew =
		// socDetallessolDao.crearActualizarDetalles(solicitudNew,
		// solicitud.getSocDetallessolLista());

		for (SocDetallessol socDetallessol : solicitud.getSocDetallessolLista()) {
			if (mttCodttransfer == null && socDetallessol.getDetCodttransfer().startsWith("103"))
				socDetallessol.setDetCodttransfer("pacs.008." + socDetallessol.getDetCodttransfer());
			else
				socDetallessol.setDetCodttransfer(mttCodttransfer);

			socDetallessol.getId().setSocCodigo(solicitudNew.getSocCodigo());
			socDetallessolDao.getHibernateTemplate().merge(socDetallessol);
			SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
			if (swfMensaje != null) {
				swfMensaje.setMenNrocorr(null);
				swfMensaje.setMenCveestswift("1");
				swfMensajeBean.getHibernateTemplate().merge(swfMensaje);
			}
		}

		for (SocSolicitudctas socSolicitudctas : solicitud.getSocSolicitudctasLista()) {
			socSolicitudctas.getId().setSocCodigo(solicitudNew.getSocCodigo());
			socSolicitudctasDao.getHibernateTemplate().merge(socSolicitudctas);
		}
		for (SocOpecomi socOpecomi : solicitud.getSocOpecomiLista()) {
			socOpecomi.getId().setOpeCodigo(solicitudNew.getSocCodigo());
			socOpecomiDao.getHibernateTemplate().merge(socOpecomi);
		}
		Solicitud solicitudN = populateSolicitudTO(solicitudNew.getSocCodigo());
		solicitudN.setCodUsuarioAudit("190");
		solicitudN.setCodEstacionAudit("test");
		solicitudN.setCodPersonaAudit("900");
		log.info("Nueva solicitud copiada " + solicitudNew.getSocCodigo() + " det: " + solicitudN.getSocDetallessolLista().size() + " cta: "
				+ solicitudN.getSocSolicitudctasLista().size() + " ope: " + solicitudN.getSocOpecomiLista().size());
		return solicitudN;
	}
}
