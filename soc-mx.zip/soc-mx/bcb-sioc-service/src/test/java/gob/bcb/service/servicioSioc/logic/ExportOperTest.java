package gob.bcb.service.servicioSioc.logic;

import static gob.bcb.iso20022.excel.enums.FieldTypeEnum.DATE;
import static gob.bcb.iso20022.excel.enums.FieldTypeEnum.STRING;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.bpm.pruebaCU.ExpExporttrxdet;
import gob.bcb.bpm.pruebaCU.ExpExporttrxdetPK;
import gob.bcb.iso20022.excel.ExcelFactory;
import gob.bcb.iso20022.excel.core.data.HeaderData;
import gob.bcb.iso20022.excel.core.data.HeaderDataBuilder;
import gob.bcb.iso20022.excel.core.listener.DataReadListener;
import gob.bcb.iso20022.excel.enums.FieldTypeEnum;
import gob.bcb.iso20022.excel.enums.FileTypeEnum;
import gob.bcb.iso20022.excel.utils.CommonFileUtils;
import gob.bcb.swift.service.ArchivoSinpleServiceImpl;

public class ExportOperTest {
	private final static Logger log = LoggerFactory.getLogger(ExportOperTest.class);

//	@Test
	public void readExpotsXls() {
		try {
			log.info("inicializando format engine...");
			String nfile = "src/test/resources/xls/exportaciones.xlsx";

			HeaderDataBuilder hdrDBuilder = headersXlsMX().nameSheet("BASE").firstRowData(2);

			ExcelFactory excelFactory = ExcelFactory.build().readInstance(nfile, ExpExporttrxdet.class, hdrDBuilder.getHeaderContent(),
					hdrDBuilder.getNameSheet());
			excelFactory.setSheetName("BASE");

			new DataReadListener<ExpExporttrxdet>((users -> {
				users.forEach(u -> {
				});
			})) {
				@Override
				public void invoke(ExpExporttrxdet data) {
					// TODO Auto-generated method stub
					super.invoke(data);
				}

				@Override
				public void doAfterRead() {

					super.doAfterRead();
				}
			};

			List<ExpExporttrxdet> swfMencampos = new ArrayList<>();
			excelFactory.read(new DataReadListener<ExpExporttrxdet>((users -> {
				users.forEach(u -> {
					swfMencampos.add(u);
				});
			})) {
				@Override
				public void invoke(ExpExporttrxdet data) {
					log.info("en inboke ..." + data);
					super.invoke(data);
				}

				@Override
				public void doAfterRead() {
					log.info("en doAfterRead...");
					super.doAfterRead();
				}
			});

			log.info("datos " + swfMencampos.size());
			swfMencampos.forEach(s -> {
				log.info(s.getDexTramite() + " " + s.getDexDescrip() + " " + s.getDexFecconfirma());
			});
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}

	//@Test
	public void readExpotsCsv() {
		try {
			log.info("inicializando format engine...");
			String nfile = "src/test/resources/csv/exportaciones.csv";

			HeaderDataBuilder hdrDBuilder = headersXlsMX().nameSheet("BASE").firstRowData(1);

			ExcelFactory excelFactory = ExcelFactory.build().readInstance(nfile, ExpExporttrxdet.class, hdrDBuilder.getHeaderContent(),
					hdrDBuilder.getNameSheet());
			excelFactory.setSheetName("BASE");
			excelFactory.setFileTypeEnum(FileTypeEnum.CSV);
			excelFactory.createCsvFormat('|', '"');
			
			List<ExpExporttrxdet> swfMencampos = new ArrayList<>();
			excelFactory.read(new DataReadListener<ExpExporttrxdet>((users -> {
				users.forEach(u -> {
					swfMencampos.add(u);
				});
			})) {
				@Override
				public void invoke(ExpExporttrxdet data) {
					data.setId(new ExpExporttrxdetPK());
					data.getId().setDexNrodet(Integer.valueOf(data.getDexCoddetorig()));
					super.invoke(data);
					log.info("INV: " + data.getDexFecvalid() + " "+ data.getId().getDexNrodet() + " " + data.getDexMontousd() + " " + data.getDexTcorig());					
				}

				@Override
				public void doAfterRead() {
					log.info("en doAfterRead...");
					super.doAfterRead();
				}
			});

			log.info("datos " + swfMencampos.size());
			swfMencampos.forEach(s -> {
				log.info(s.getDexFecvalid() + " nro: "+ s.getId().getDexNrodet() + " " + s.getDexMontousd() + " " + s.getDexTcorig());
			});
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}	
	//@Test
	public void readExpotsXlsToExpdet() {
		try {
			log.info("inicializando read to map...");
			String nfile = "src/test/resources/csv/plain.txt";
			InputStream inputStream = CommonFileUtils.getFileInputStream(nfile);
			ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl(); 
			archivoSinpleService.fileUpload(inputStream, nfile);
			
			List<ExpExporttrxdet> impList = ExportsUpload.loadFile(archivoSinpleService, "BASE", 1);
			
			log.info("datos " + impList.size());
			impList.forEach(s -> {
				log.info("	" + s.getId().getDexNrodet() + " : " + s.getDexEstdettrx() + " -> "+ s.getDexTramite() + " Fecvalid: " + s.getDexFecvalid() + " " + s.getDexFecconfirma() + " " + s.getDexMontomo() + " ("+ s.getDexCodmonmo() + "), " + s.getDexMontousd() + "(USD)");				
			});
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}
	
	//@Test
	public void readExpotsXlsToMap() {
		try {
			log.info("inicializando read readExpotsXlsToExpdet...");
			String nfile = "src/test/resources/xls/exportaciones_small.xlsx";
			
			InputStream inputStream = CommonFileUtils.getFileInputStream(nfile);
			HeaderDataBuilder hdrDBuilder = headersXlsMX().nameSheet("BASE").firstRowData(2);

			ExcelFactory excelFactory = ExcelFactory.build().readInstance(inputStream, Map.class, hdrDBuilder.getHeaderContent(),
					hdrDBuilder.getNameSheet());
			excelFactory.setSheetName("BASE");
			excelFactory.setFileTypeEnum(FileTypeEnum.XLSX);

			List<Map<String, Object>> swfMencampos = new ArrayList<>();
			excelFactory.read(new DataReadListener<Map<String, Object>>((users -> {
				users.forEach(u -> {
					swfMencampos.add(u);
				});
			})) {
				@Override
				public void invoke(Map<String, Object> data) {
					super.invoke(data);
				}

				@Override
				public void doAfterRead() {
					super.doAfterRead();
				}
			});

			log.info("datos " + swfMencampos.size());
			swfMencampos.forEach(s -> {
				//log.info("size : " + s.size());
				StringBuffer sb = new StringBuffer();
				
				for(Entry<String, Object> map : s.entrySet()) {
					sb.append(map.getKey() + ": "  + (map.getValue() != null ? map.getValue().toString() : "")).append(", ");
				}
				log.info("	" +sb.toString());				
			});
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}
	public static HeaderDataBuilder headersXlsMX() {

		HeaderDataBuilder headerDataBuilder = HeaderDataBuilder.instance();
		List<HeaderData> headerDataList = headerDataBuilder//
				.fill("dexCoddetorig", STRING, 0) //
				.fill("dexFecvalid",DATE,1 ) //
				.fill("dexExportador", STRING, 2) //
				.fill("dexNrodoc", STRING, 3) //
				.fill("dexMontousd", FieldTypeEnum.BIG_DECIMAL, 4) //
				.fill("dexTcorig", FieldTypeEnum.BIG_DECIMAL, 5) //
				.fill("dexMontopar", FieldTypeEnum.BIG_DECIMAL, 6) //
				.fill("dexTccont", FieldTypeEnum.BIG_DECIMAL, 7) //
				.fill("dexMontomn", FieldTypeEnum.BIG_DECIMAL, 8) //
				.fill("dexMontodiff", FieldTypeEnum.BIG_DECIMAL, 9) //
				.build();
		return headerDataBuilder;
	}

}
