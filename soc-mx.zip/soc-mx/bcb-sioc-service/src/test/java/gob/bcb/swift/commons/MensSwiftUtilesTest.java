package gob.bcb.swift.commons;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;

import gob.bcb.swift.pojos.SwiftMessageBcb;

public class MensSwiftUtilesTest {
	private static final Logger log = Logger.getLogger(MensSwiftUtilesTest.class);

	@Test
	public void splitInLinesTest() {
		Arrays.asList("RODNEY SQNORTH 1100 NORTH MARQUET STREET WILMINGTON DELAWARER 1605 ", "cadena corata larga de pruebas ",
				"cadena mularga cadena mularga cadena mularga ad asdf asdf a s ad cadena mularga cadenaasd asdfd asdf asdf mularga cadena mularga ","","as").forEach(s -> {
					int linesField50F = 2;
					List<String> lines = MensSwiftUtiles.splitInLines(33, s, linesField50F, " ", "", 0);
					lines.forEach(l -> {
						log.info("linea " + l);
					});
				});
		;
	}
}
