package gob.bcb.service.servicioSioc;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

public class OperacionesWSTest extends BaseData {
	private static final Log log = LogFactory.getLog(OperacionesWSTest.class);

	@Test
	public void procesarTranferenciaXML() {
		log.info("========== procesarTranferenciaXML =============");		
		String filexml = "src/test/resources/mensmefp/FACT_02.XML";
		String newstr = readAndChangeCodsolic(filexml);
		Map<String, Object> mapaParametros = genMapaParamsXML(newstr);
		procesarXML(mapaParametros);
	}
	
	//@Test
	public void actualizarAFecha() {
		
		Date fecha = new Date();		
		Solicitud solicitudTO = populateSolicitudTO("032924");
		solicitudTO.getSolicitud().setFechaCont(fecha);		
		solicitudTO = procesarSinError(solicitudTO, "ACT_A_FECHA");
		if (solicitudTO != null && StringUtils.isBlank(solicitudTO.getSolicitud().getSocCodigo())) {
			throw new BusinessException("El servicio no retorna el codigo de la solicitud");
		}
	}

	//@Test
	public void preautorizarSolicitudTest() {
		log.info("========== preautorizarSolicitudTest =============");

		preautorizarTest("032924");
	}
	
	//@Test
	public void autorizarSolicitudTest() {
		log.info("========== autorizarSolicitudTest =============");
	
		autorizarTest("032924");
	}	
	public static Map<String, Object> genMapaParamsXML(String newstr) {
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "REG_SOLWS");
		mapaParametros.put("mensajeXML", newstr);
		mapaParametros.put(gob.bcb.service.servicioSioc.common.Constants.COD_IFA_REQUEST, gob.bcb.service.servicioSioc.common.Constants.COD_IFA_MEFP);
		
		return mapaParametros;
	}
	
	public void preautorizarTest(String socCodigo) {
		log.info("========== preautorizarTest =============");
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		solicitudTO = procesar(solicitudTO, "REG_SOLICITUD");
		if (StringUtils.isBlank(solicitudTO.getSolicitud().getSocCodigo())) {
			throw new BusinessException("El servicio no retorna el codigo de la solicitud");
		}
		Date fecha = new Date();
		solicitudTO.getSolicitud().setFechaCont(fecha);
		solicitudTO = procesar(solicitudTO, "PREAUT");
		log.info("Fin preautorizarSolicitudTest " + solicitudTO.getSolicitud().getSocCodigo());
	}	
	
	public void autorizarTest(String socCodigo) {
		log.info("========== autorizarTest =============");
		Solicitud solicitudTO = populateSolicitudTO(socCodigo);
		if (solicitudTO.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			procesar(solicitudTO, "AUTSWFT");
		}
		log.info("========== autorizarTest =============*********************");
		solicitudTO = populateSolicitudTO(socCodigo);
		procesar(solicitudTO, "AUTSOL");

		log.info("Fin autorizarTest " + solicitudTO.getSolicitud().getSocCodigo());
	}	
}
