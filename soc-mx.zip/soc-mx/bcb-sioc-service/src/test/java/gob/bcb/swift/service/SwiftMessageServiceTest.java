package gob.bcb.swift.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.iso20022.swift.parser.FactoryParser;
import gob.bcb.iso20022.swift.parser.SwiftMessageAbstract;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.pojos.SwiftDatos;

public class SwiftMessageServiceTest extends BaseData {
	private static final Log log = LogFactory.getLog(SwiftMessageServiceTest.class);

	//@Test
	public void translateTest() {
		try {
			log.info("================================");
			String mt = "pacs.008.103B";
			String socCodigo = "040330";//"017479";
			log.info("******** " + socCodigo + " ********");
			SwiftDatos swiftDatos = createSwiftDatos(socCodigo, mt);
			if (swiftDatos != null) {
				SwfMsgParam swfMsgParam = swiftMessageService.recMsgParms(swiftDatos);
				if (!StringUtils.isBlank(swfMsgParam.getMenFormato())) {
					CreateSwiftService createSwiftService = swiftMessageService.genSwiftMxMt(swiftDatos) ;
					Instruccion instruccion = createSwiftService.getInstruccion();
					String menPlano = instruccion.getMessageHolder().getMenPlano();
					log.info(menPlano);
				}
			}

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}

	@Test
	public void translateMixTest() {
		try {
			log.info("================================");
			String mt = "pacs.008.103B";
			String socCodigo = "017479";
			log.info("******** " + socCodigo + " ********");
			SwiftDatos swiftDatos = createSwiftDatos(socCodigo, mt);
			if (swiftDatos != null) {
				SwfMsgParam swfMsgParam = swiftMessageService.recMsgParms(swiftDatos);
				if (!StringUtils.isBlank(swfMsgParam.getMenFormato())) {
					CreateSwiftService createSwiftService = swiftMessageService.genSwiftMxMt(swiftDatos) ;
					Instruccion instruccion = createSwiftService.getInstruccion();
					String menPlano = instruccion.getMessageHolder().getMenPlano();
					log.info(menPlano);
				}
			}
			mt = "103B";
			swiftDatos = createSwiftDatos(socCodigo, mt);
			if (swiftDatos != null) {
				SwfMsgParam swfMsgParam = swiftMessageService.recMsgParms(swiftDatos);
				if (!StringUtils.isBlank(swfMsgParam.getMenFormato())) {
					CreateSwiftService createSwiftService = swiftMessageService.genSwiftMxMt(swiftDatos) ;
					Instruccion instruccion = createSwiftService.getInstruccion();
					String menPlano = instruccion.getMessageHolder().getMenPlano();
					log.info(menPlano);
				}
			}			

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
	
	//@Test
	public void translateFullTest() {
		try {
			Map<String, String> mapCtrl = new HashMap<>();
			log.info("================================");
			Date fechaDesde = UtilsDate.dateFromString("01/08/2019", "dd/MM/yyyy");
			Date fechaAl = UtilsDate.dateFromString("30/08/2023", "dd/MM/yyyy");

			List<SolicitudesS> ls = socSolicitudesDao.recuperarSolicitudes(null, "VE,TE,OB", "TE", null, "N,P", null, null, null, fechaDesde, fechaAl, null)
					.stream()//
					// .limit(35)//
					.collect(Collectors.toList());

			log.info("inicio regs " + ls.size());
			List<String> lc = new ArrayList<>();
			List<String> lca = new ArrayList<>();

			ls.forEach(c -> {
				String socCodigo = c.getSocCodigo();
				String mt = "pacs.008.103B";
				SwiftDatos swiftDatos = createSwiftDatos(socCodigo, "");
				if (swiftDatos != null) {
					mt = swiftDatos.getSwfMensaje().getMenCodmt().startsWith("202") ? "pacs.009.001" : "pacs.008.001";

					SocSolicitudes s = swiftDatos.getSolicitudTO().getSolicitud();
					String ksc = s.getCveSubtipooper() + s.getClaTipo() + s.getCveTipctasolic() + s.getSolEntsolic() + s.getEsqCodigo()
							+ s.getSocTipnegociacion() + s.getTipoRetencion() + s.getTipoConcepto() + swiftDatos.getSwfMensaje().getMenCodmt();
//					log.info("******** " + socCodigo + "[" + ksc + "] ********");
					swiftDatos.getSwfMensaje().setMenCodmt(mt);
					SwfMsgParam swfMsgParam = swiftMessageService.recMsgParms(swiftDatos);
					if (!StringUtils.isBlank(swfMsgParam.getMenFormato()) && mt.equals("pacs.008.001")) {
						if (!mapCtrl.containsKey(ksc)) {

							log.info("******** " + socCodigo + "[" + ksc + "] ********");
							log.info("\n" + swiftDatos.getSwfMensaje().getMenPlano());
							CreateSwiftService createSwiftService = new CreateSwiftService(swfMsgParam, swfMencamposIsoDaoImpl);
							swiftMessageMXService.obtenerFacts(swiftDatos, createSwiftService);
							Instruccion instruccion = createSwiftService.getInstruccion();
							createSwiftService.recuperarCampos(instruccion.isMt() ? "4" : "");
							createSwiftService.registerFuncsDef();
							createSwiftService.initEngine();
							createSwiftService.generaHeaderMsg();
							createSwiftService.translate();
							createSwiftService.translatePost();
							createSwiftService.createMsgSwift();
							String menPlano = instruccion.getMessageHolder().getMenPlano();
							log.info(menPlano);

							SwiftMessageAbstract sm = FactoryParser.createParser(menPlano);
							List<String> errors;
							try {
								errors = sm.validateSyntax();
								log.info("errors " + errors.size());
								errors.forEach(e -> {
									log.info("error " + e);
								});
							} catch (Exception e1) {
								// e1.printStackTrace();
								log.error("EEEEEError en valid :_" + e1.getMessage());
							}
							mapCtrl.put(ksc, s.getSocCodigo());
						}
					}
				}
			});
			log.info("total " + mapCtrl.size());
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}	
	public SwiftDatos createSwiftDatos(String socCodigo, String mttCodttransfer) {

		Solicitud solicitud = populateSolicitudTO(socCodigo);

		SwiftDatos swiftDatos = new SwiftDatos();

		swiftDatos.setAuditusr(solicitud.getSolicitud().getUsrCodigo());
		swiftDatos.setAuditwst(solicitud.getSolicitud().getEstacion());

		swiftDatos.setSolicitudTO(solicitud);
		swiftDatos.setSocDetallessol(solicitud.getSocDetallessolLista().get(0));

		SocDetallessol socDetallessol = solicitud.getSocDetallessolLista().get(0);
		SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
		if (swfMensaje == null)
			return null;

		swfMensaje.setMenCodmt(mttCodttransfer);
		swfMensaje.setMenMonto(socDetallessol.getDetMontotrans());
		swfMensaje.setMenCodmon(solicitud.getSolicitud().getCodMonedat());
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenFecvalor(solicitud.getSolicitud().getFechaCont());
		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PEND);
		swfMensaje.setMenAuditusr(solicitud.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitud.getCodEstacionAudit());
		swiftDatos.setSwfMensaje(swfMensaje);
		return swiftDatos;
	}
	
	public Solicitud cpySolicitud(String socCodigo, String mttCodttransfer) {

		Solicitud solicitud = populateSolicitudTO(socCodigo);
		log.info("Old solicitud copiada " + solicitud.getSocCodigo() + " det: " + solicitud.getSocDetallessolLista().size() + " cta: "
				+ solicitud.getSocSolicitudctasLista().size() + " ope: " + solicitud.getSocOpecomiLista().size());
		
		solicitud.getSolicitud().setSocCodigo(null);
		solicitud.getSolicitud().setFechaCont(new Date());
		solicitud.getSolicitud().setFechaHora(new Date());
		SocSolicitudes solicitudNew = socSolicitudesDao.crearActualizar(solicitud.getSolicitud());

		for (SocDetallessol socDetallessol : solicitud.getSocDetallessolLista()) {
			socDetallessol.setDetCodttransfer(mttCodttransfer);
			socDetallessol.getId().setSocCodigo(solicitudNew.getSocCodigo());
			socDetallessolDao.getHibernateTemplate().merge(socDetallessol);
			SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
			if (swfMensaje != null) {
				swfMensaje.setMenNrocorr(null);
				swfMensaje.setMenCveestswift("1");
				swfMensajeBean.getHibernateTemplate().merge(swfMensaje);
			}
		}

		for (SocSolicitudctas socSolicitudctas : solicitud.getSocSolicitudctasLista()) {
			socSolicitudctas.getId().setSocCodigo(solicitudNew.getSocCodigo());
			socSolicitudctasDao.getHibernateTemplate().merge(socSolicitudctas);
		}
		for (SocOpecomi socOpecomi : solicitud.getSocOpecomiLista()) {
			socOpecomi.getId().setOpeCodigo(solicitudNew.getSocCodigo());
			socOpecomiDao.getHibernateTemplate().merge(socOpecomi);
		}
		Solicitud solicitudN = populateSolicitudTO(solicitudNew.getSocCodigo());
		solicitudN.setCodUsuarioAudit("190");
		solicitudN.setCodEstacionAudit("test");
		solicitudN.setCodPersonaAudit("900");
		log.info("Nueva solicitud copiada " + solicitudNew.getSocCodigo() + " det: " + solicitudN.getSocDetallessolLista().size() + " cta: "
				+ solicitudN.getSocSolicitudctasLista().size() + " ope: " + solicitudN.getSocOpecomiLista().size());
		return solicitudN;
	}	
}
