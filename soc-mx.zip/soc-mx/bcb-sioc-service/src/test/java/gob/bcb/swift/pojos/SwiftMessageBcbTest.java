package gob.bcb.swift.pojos;

import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

import com.prowidesoftware.swift.model.field.Field;
import com.prowidesoftware.swift.model.field.Field20;
import com.prowidesoftware.swift.model.field.Field23B;
import com.prowidesoftware.swift.model.field.Field32A;
import com.prowidesoftware.swift.model.field.Field50A;
import com.prowidesoftware.swift.model.field.Field50F;
import com.prowidesoftware.swift.model.field.Field70;
import com.prowidesoftware.swift.model.field.Field71A;
import com.prowidesoftware.swift.model.field.Field72;
import com.prowidesoftware.swift.model.mt.mt1xx.MT103;

import gob.bcb.swift.commons.MensSwiftUtiles;

public class SwiftMessageBcbTest {

	@Test
	public void campo59F() {
		MT103 m = new MT103();

		m.setSender("FOOSEDR0AXXX");
		m.setReceiver("FOORECV0XXXX");
		m.addField(new Field20("REFERENCE"));
		m.addField(new Field23B("CRED"));

		Field32A f32A = new Field32A().setDate(Calendar.getInstance()).setCurrency("EUR").setAmount("1234567,89");
		m.addField(f32A);

		Field50A f50A = new Field50A().setAccount("12345678901234567890").setBIC("FOOBANKXXXXX");
		m.addField(f50A);

		SwiftMessageBcb swiftMessageBcb = new SwiftMessageBcb();
		
		Map<String, List<String>> mapfieldf = new HashMap<>();
		List<String> lin1Name = MensSwiftUtiles.splitInLines(33, "nombre de  ", 2, " ", "", 0);
		List<String> lin2Dir = MensSwiftUtiles.splitInLines(33, "diraccion ao pdel benefi acaior asdf ASDFWESASDF A ", 2, " ", "", 0);
		List<String> lin3CtryTown = MensSwiftUtiles.splitInLines(33, "AO/asdl lasdf kdie asdfEWERSDF", 1, " ", "", 0);
		
		mapfieldf.put("name", lin1Name);
		mapfieldf.put("address", lin2Dir);
		mapfieldf.put("country",lin3CtryTown);
		
		Field50F f59F = new Field50F();
		Field f = swiftMessageBcb.setField50F("23453265345", mapfieldf);
		f59F.setComponent1("12344356");
		f59F.setComponent2("1").setComponent3("1111111111");
		
//		f59F.setComponent4("2").setComponent5("2222222222");
//		f59F.setComponent6("2").setComponent7("2222222222");
		f59F.setComponent8("3").setComponent9("3333333333");
		String valor = "/BNF/SHELL BOLIVIA CORPORATION//SUC. BOLIVIA";
		valor="PAGO EXP GN MTGAS IP MT 05 MTGAS IP //MT 05 MTGAS IP MT 05 MTGAS IP MT 05 //MTGAS IP MT 05 MTGAS IP MT 05 MTGAS IP MT 05 MTGAS IP MT 05 22 IP MTC 05 22 RT ME SHELL BOLIVIA CORP AREA CAIPIPENDI MAYO 2022";
		m.addField(f59F);
		m.addField(f);
		m.addField(new Field71A("OUR"));

		Field70 field = (Field70) swiftMessageBcb.setField70(valor);
		m.addField(field);
		
		Field72 field72 = (Field72) swiftMessageBcb.setField72(valor);
		m.addField(field72);		
		System.out.println(m.message());
		
		

		boolean isM = Pattern.matches("\\s+", "asdf asdf ASD");

		System.out.println(isM);

		Arrays.asList("AS/sasdf asdf 234", "WER/EIEKD ASDF  AÑSLD", "AS/kdkldf", "ASDF/qwerlkj", "23/ASDF", "E/ñlsdie", "ASDFWER/ASDF", "sd/asdfwASD asdf-",
				"BO/", "US/ sdfkei ASDF0", "WE/WER/QWERS/").forEach(c -> {
					Pattern pattern = Pattern.compile("[A-Z]{2,2}/");
					Matcher matcher = pattern.matcher("AS/");
					boolean isMatch = Pattern.matches("[A-Z]{2,2}/[^*&@]{1,}", c);
					System.out.println(c + " cumple ? " + matcher.find() + " isMatch: " + isMatch);

				});
		;
	}
}
