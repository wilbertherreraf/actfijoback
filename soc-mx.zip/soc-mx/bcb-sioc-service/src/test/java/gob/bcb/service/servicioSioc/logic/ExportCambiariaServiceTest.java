package gob.bcb.service.servicioSioc.logic;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gob.bcb.bpm.pruebaCU.ExpClasiffactor;
import gob.bcb.bpm.pruebaCU.ExpExporttrx;
import gob.bcb.bpm.pruebaCU.ExpExporttrxDao;
import gob.bcb.bpm.pruebaCU.ExpExporttrxdet;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.iso20022.excel.utils.CommonFileUtils;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.swift.service.ArchivoSinpleServiceImpl;

public class ExportCambiariaServiceTest extends BaseData {
	private final static Logger log = LoggerFactory.getLogger(ExportCambiariaServiceTest.class);

	// @Test
	public void findTramoVigTest() {
		try {
			log.info("findTramoVig init ");
			Date fecha = UtilsDate.dateFromString("08/08/2021", "dd/MM/yyyy");
			BigDecimal monto = new BigDecimal("10000.01");
			List<ExpClasiffactor> factor = expClasiffactorDao.findTramosVig(fecha, Constants.COD_MONEDA_USD.toString(), monto);
			factor.forEach(f -> {
				log.info("favor " + f.getId().getFacTramo() + " " + f.getId().getFacFechavig() + " => " + f.getFacTctramo() + " inf: " + f.getFacLimiteinf()
						+ " - " + f.getFacLimitesup());
			});
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}

	// @Test
	public void loadUpdTest() {
		String nameSheet = "BASE";
		Integer firstRow = 1;
		String nfile = "src/test/resources/xls/exportaciones_small.xlsx";
		Date fecha = UtilsDate.dateFromString("02/08/2021", "dd/MM/yyyy");
		try {
			InputStream inputStream = CommonFileUtils.getFileInputStream(nfile);
			ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
			archivoSinpleService.fileUpload(inputStream, nfile);

			ExpExporttrx expExporttrx = ExpExporttrxDao.newExport();
			expExporttrx.setExtFecha(fecha);

			List<ExpExporttrxdet> exps = exportCambiariaService.loadAndUpdate(expExporttrx, archivoSinpleService, nameSheet, firstRow);
			exps.forEach(f -> {
				log.info(f.getId().getDexNrodet() + " : " + f.getDexTramo() + " => " + f.getDexMontomo() + "(" + f.getDexCodmonmo() + ") " + f.getDexTctramo()
						+ " usd: " + f.getDexMontousd() + " mn: " + f.getDexMontomn() + " par: " + f.getDexMontopar());
			});
			fecha = UtilsDate.dateFromString("02/08/2022", "dd/MM/yyyy");
			expExporttrx.setExtFecha(fecha);
			exps = exportCambiariaService.loadAndUpdate(expExporttrx, archivoSinpleService, nameSheet, firstRow);
			exps.forEach(f -> {
				log.info(f.getId().getDexNrodet() + " : " + f.getDexTramo() + " => " + f.getDexMontomo() + "(" + f.getDexCodmonmo() + ") " + f.getDexTctramo()
						+ " usd: " + f.getDexMontousd() + " mn: " + f.getDexMontomn() + " par: " + f.getDexMontopar());
			});
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}

	//@Test
	public void updHdrLoteTest() {
		String nameSheet = "BASE";
		Integer firstRow = 1;
		String nfile = "src/test/resources/xls/exportaciones_small.xlsx";
		Date fecha = UtilsDate.dateFromString("02/08/2021", "dd/MM/yyyy");
		try {
			InputStream inputStream = CommonFileUtils.getFileInputStream(nfile);
			ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
			archivoSinpleService.fileUpload(inputStream, nfile);

			ExpExporttrx expExporttrx = ExpExporttrxDao.newExport();
			expExporttrx.setExtFecha(fecha);

			List<ExpExporttrxdet> exps = exportCambiariaService.loadAndUpdate(expExporttrx, archivoSinpleService, nameSheet, firstRow);
			exportCambiariaService.updHdrLote(expExporttrx, exps);

			exps.forEach(f -> {
				log.info(f.getId().getDexNrodet() + " : " + f.getDexTramo() + " => " + f.getDexMontomo() + "(" + f.getDexCodmonmo() + ") " + f.getDexTctramo()
						+ " usd: " + f.getDexMontousd() + " mn: " + f.getDexMontomn() + " par: " + f.getDexMontopar() + " " + f.getDexTccont());
			});
			log.info(" MN: " + expExporttrx.getExtMontomn() + " MO: " + expExporttrx.getExtMontomo() + " PAR: " + expExporttrx.getExtMontopar() + " DIFF: "
					+ expExporttrx.getExtDiffcamb());
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}
	
	//@Test
	public void salvarLoteXlsTest() {
		String nameSheet = "BASE";
		Integer firstRow = 1;
		String nfile = "src/test/resources/xls/exportaciones.xlsx";
		Date fecha = UtilsDate.dateFromString("02/08/2022", "dd/MM/yyyy");
		try {
			InputStream inputStream = CommonFileUtils.getFileInputStream(nfile);
			ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
			archivoSinpleService.fileUpload(inputStream, nfile);

			ExpExporttrx expExporttrx = ExpExporttrxDao.newExport();
			expExporttrx.setExtFecha(fecha);
			expExporttrx.setExtAuditusr("test");
			expExporttrx.setExtAuditwst("testwst");
			
			List<ExpExporttrxdet> exps = exportCambiariaService.loadAndUpdate(expExporttrx, archivoSinpleService, nameSheet, firstRow);
			exportCambiariaService.updHdrLote(expExporttrx, exps);
			exportCambiariaService.salvarLote(expExporttrx, exps);
			
			exps.forEach(f -> {
				log.info(f.getId().getDexNrodet() + " : " + f.getDexTramo() + " => " + f.getDexMontomo() + "(" + f.getDexCodmonmo() + ") " + f.getDexTctramo()
						+ " usd: " + f.getDexMontousd() + " mn: " + f.getDexMontomn() + " par: " + f.getDexMontopar() + " " + f.getDexTccont());
			});
			log.info(" MN: " + expExporttrx.getExtMontomn() + " MO: " + expExporttrx.getExtMontomo() + " PAR: " + expExporttrx.getExtMontopar() + " DIFF: "
					+ expExporttrx.getExtDiffcamb());
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}	
	
	//@Test
	public void salvarLoteCsvTest() {
		String nameSheet = "BASE";
		Integer firstRow = 1;
		String nfile = "src/test/resources/csv/exportaciones.csv";
		Date fecha = UtilsDate.dateFromString("02/08/2022", "dd/MM/yyyy");
		try {
			InputStream inputStream = CommonFileUtils.getFileInputStream(nfile);
			ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
			archivoSinpleService.fileUpload(inputStream, nfile);

			ExpExporttrx expExporttrx = ExpExporttrxDao.newExport();
			expExporttrx.setExtFecha(fecha);
			expExporttrx.setExtAuditusr("test");
			expExporttrx.setExtAuditwst("testwst");
			
			List<ExpExporttrxdet> exps = exportCambiariaService.loadAndUpdate(expExporttrx, archivoSinpleService, nameSheet, firstRow);
			exportCambiariaService.updHdrLote(expExporttrx, exps);
			exportCambiariaService.salvarLote(expExporttrx, exps);
			
			exps.forEach(f -> {
				log.info(f.getId().getDexNrodet() + " : " + f.getDexTramo() + " => " + f.getDexMontomo() + "(" + f.getDexCodmonmo() + ") " + f.getDexTctramo()
						+ " usd: " + f.getDexMontousd() + " mn: " + f.getDexMontomn() + " par: " + f.getDexMontopar() + " " + f.getDexTccont());
			});
			log.info(" MN: " + expExporttrx.getExtMontomn() + " MO: " + expExporttrx.getExtMontomo() + " PAR: " + expExporttrx.getExtMontopar() + " DIFF: "
					+ expExporttrx.getExtDiffcamb());
		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}
	
	@Test
	public void calcComisTest() {
		try {
			Date fechaIni = UtilsDate.dateFromString("02/01/2023", "dd/MM/yyyy");
			Date fechaFin = UtilsDate.dateFromString("02/08/2023", "dd/MM/yyyy");
			
			exportCambiariaService.calcComision(fechaIni,fechaFin);

		} catch (Exception e) {
			log.error("erro " + e.getMessage(), e);
		}
	}	
}
