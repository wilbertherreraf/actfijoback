package gob.bcb.lavado.lavadoclient;

import java.io.File;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.iso20022.model.Instruccion;
import gob.bcb.iso20022.model.SwfMsgParam;
import gob.bcb.iso20022.swift.FileFormat;
import gob.bcb.service.config.BaseData;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.service.CreateSwiftService;

public class ClienteLvdSiocTest extends BaseData {
	private static final Log log = LogFactory.getLog(ClienteLvdSiocTest.class);
	String urlLavado = "http://10.3.11.82:8881/lavado/";
	
	@Test
	public void translateTest() {
		try {
			log.info("================================");
			String mt = "pacs.008.001";
			String socCodigo = "040330";
			log.info("******** " + socCodigo + " ********");
			SwiftDatos swiftDatos = createSwiftDatos(socCodigo, mt);
			if (swiftDatos != null) {
				SwfMsgParam swfMsgParam = swiftMessageService.recMsgParms(swiftDatos);
				if (!StringUtils.isBlank(swfMsgParam.getMenFormato())) {
					CreateSwiftService createSwiftService = new CreateSwiftService(swfMsgParam, swfMencamposIsoDaoImpl);
					swiftMessageMXService.obtenerFacts(swiftDatos, createSwiftService);
					Instruccion instruccion = createSwiftService.getInstruccion();
					createSwiftService.recuperarCampos(instruccion.isMt() ? "4" : "");
					createSwiftService.registerFuncsDef();
					createSwiftService.initEngine();
					createSwiftService.generaHeaderMsg();
					createSwiftService.translate();
					createSwiftService.translatePost();
					createSwiftService.createMsgSwift();
					String menPlano = instruccion.getMessageHolder().getMenPlano();
					log.info(menPlano);

					ClienteLvdSioc clienteLvdSioc = new ClienteLvdSioc();
					clienteLvdSioc.initClienteLvd(urlLavado, (new File(Constants.PATH_BASE_SERV)).getAbsolutePath());
					clienteLvdSioc.scanMensaje(menPlano);
				}
			}

		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
		}
	}
	
	public SwiftDatos createSwiftDatos(String socCodigo, String mttCodttransfer) {

		Solicitud solicitud = populateSolicitudTO(socCodigo);

		SwiftDatos swiftDatos = new SwiftDatos();

		swiftDatos.setAuditusr(solicitud.getSolicitud().getUsrCodigo());
		swiftDatos.setAuditwst(solicitud.getSolicitud().getEstacion());

		swiftDatos.setSolicitudTO(solicitud);
		swiftDatos.setSocDetallessol(solicitud.getSocDetallessolLista().get(0));

		SocDetallessol socDetallessol = solicitud.getSocDetallessolLista().get(0);
		SwfMensaje swfMensaje = swfMensajeBean.findByCodoperacion(socDetallessol.getId().getSocCodigo(), socDetallessol.getId().getDetCodigo());
		if (swfMensaje == null)
			return null;
		if (!StringUtils.isBlank(mttCodttransfer))
			swfMensaje.setMenCodmt(mttCodttransfer);
		swfMensaje.setMenMonto(socDetallessol.getDetMontotrans());
		swfMensaje.setMenCodmon(solicitud.getSolicitud().getCodMonedat());
		swfMensaje.setMenFecreg(new Date());
		swfMensaje.setMenFecvalor(solicitud.getSolicitud().getFechaCont());
		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PEND);
		swfMensaje.setMenAuditusr(solicitud.getCodUsuarioAudit());
		swfMensaje.setMenAuditwst(solicitud.getCodEstacionAudit());

		SwfMttransfer swfMttransfer = new SwfMttransfer();
		swfMttransfer.setMttCodttransfer(mttCodttransfer);
		swfMttransfer.setMttFormato(FileFormat.MT.toString());

		swiftDatos.setSwfMttransfer(swfMttransfer);
		swiftDatos.setSwfMensaje(swfMensaje);
		return swiftDatos;
	}	
}
