package gob.bcb.service.servicioSioc.logic;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.service.config.BaseDaoTest;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMensajeLocal;
import gob.bcb.swift.model.SwfMensaje;

public class SwiftSiocServiceTest extends BaseDaoTest {
	private static final Log log = LogFactory.getLog(SwiftSiocServiceTest.class);

	@Test
	public void generarMensSwiftTest() {
		try {
			
			initContext();

			ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
			procesosSolicitud.setSessionFactory(sessionFactorySioc);
			SwiftSiocService swiftSiocService = new SwiftSiocService();
			swiftSiocService.setSessionFactory(sessionFactorySioc);
			SwfMensajeBean swfMensajeLocal = new SwfMensajeBean();
			swfMensajeLocal.setSessionFactory(getSessionFactory());
			Solicitud solicitudTO = procesosSolicitud.recuperarSolicitudSimple("008821");
			
			solicitudTO.setCodEstacionAudit("1653");
			solicitudTO.setCodUsuarioAudit("1653");
			solicitudTO.setCodPersonaAudit(Constants.COD_BCB);
			solicitudTO.setCodUsuarioCont("1653");
			solicitudTO.getSolicitud().setFechaCont(new Date());
			solicitudTO.getSolicitud().setClaEstado('1');
			solicitudTO.getSolicitud().setClaEstadows("P");
			SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
			socSolicitudesDao.setSessionFactory(getSessionFactory());
			socSolicitudesDao.getHibernateTemplate().merge(solicitudTO.getSolicitud());
			SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
			socDetallessolDao.setSessionFactory(getSessionFactory());
			
			List<SocDetallessol> socDetallessolListaPrev = socDetallessolDao.getDetalles(solicitudTO.getSolicitud().getSocCodigo());
			for (SocDetallessol socDetallessol : socDetallessolListaPrev) {
				SwfMensaje swfMensaje = swfMensajeLocal.findByCodoperacion(solicitudTO.getSolicitud().getSocCodigo(), socDetallessol.getId().getDetCodigo());
				if (swfMensaje != null) {
				swfMensaje.setMenCveestswift("P");
				swfMensajeLocal.getHibernateTemplate().merge(swfMensaje);
				}
			}
			QueryProcessor.setSessionFactory(sessionFactorySioc);
			QueryProcessor.setNameSessionFactory(Constants.PROP_ALIAS_SIOC);
			SiocCoinService.setSessionFactory(sessionFactoryBeanSiocCoin);
			SiocCoinService.setNameSessionFactory(Constants.PROP_ALIAS_COIN);
			
			ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
			actualizarAFecha.setSessionFactory(getSessionFactory());			
			solicitudTO = actualizarAFecha.actualizarAFecha(solicitudTO);
			swiftSiocService.generarMensSwift(solicitudTO);
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
		}
	}
}
