package gob.bcb.portal.menu.reporte;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.web.utils.ConstantesReportes;
import gob.bcb.web.utils.DynamicColumnDataSource;
import gob.bcb.web.utils.DynamicReportBuilder;

import gob.bcb.web.utils.ConstructorReporteDinamico;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRRuntimeException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

import org.apache.log4j.Logger;


/**
 * Servlet implementation class reporte
 */
public class reporte extends HttpServlet {
	private final static Logger log = Logger.getLogger(reporte.class);
	private static final long serialVersionUID = 1L;
	public static final String REPORTE_FORMATO = "reportFormato";

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = null;
		Map<String, Object> parametros = null;
		session = request.getSession();
		String tipopar = null;
		int cont = 0;
		log.info("Abriendo reporte esperando params...");
		do {
			parametros = (Map<String, Object>) session.getAttribute("parametros");

			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				log.error(e);
			}
			tipopar = request.getParameter("tipo");
			cont++;
			//log.info("Recuperando params report: " + cont + " tipo: " + tipopar);
		} while ((parametros == null && tipopar == null) && cont <= 88);

		if (parametros == null)
			parametros = new HashMap<String, Object>();

		try {
			if (request.getParameter("cod") != null)
				parametros.put("codigo", request.getParameter("cod"));

			String tipo = request.getParameter("tipo");
			if (parametros.containsKey("tipo"))
				tipo = (String) parametros.get("tipo");

			log.info("tipo: " + tipo);
			
			String nombreReporte = null;
			boolean banderaSubReporte = true;

			if (tipo == null) {
				throw new RuntimeException("Valor de tipo de reporte NULO, pruebe nuevamente la operación o avise a sistemas");
			}
			if (tipo.equalsIgnoreCase("ERROR")) {
				throw new RuntimeException("Error al generar reporte, revise mensajes anteriores.");
			}
			if (tipo.equals("SW")) {
				nombreReporte = "swift.jasper";
			} else if (tipo.equals("TE")) {
				nombreReporte = "solicitud.jasper";
			} else if (tipo.equals("TED")) {
				nombreReporte = "solicitudD.jasper";
			} else if (tipo.equals("TC") || tipo.equals("TCID") || tipo.equals("TCRG")) {
				// se agrega a operaciones de idhy regalias
				nombreReporte = "solicitudTC.jasper";
			} else if (tipo.equals("TD")) {
				nombreReporte = "solicitudDSF.jasper";
			} else if (tipo.equals("VE")) {
				nombreReporte = "solicitudVE.jasper";
			} else if (tipo.equals("VED")) {
				nombreReporte = "solicitudVE-cc.jasper";
			} else if (tipo.equals("VEL")) {
				nombreReporte = "solicitudVETC.jasper";
			} else if (tipo.equals("VEO")) {
				nombreReporte = "solicitudVEOP.jasper";
			} else if (tipo.equals("SF")) {
				nombreReporte = "solicitudSF.jasper";
			} else if (tipo.equals("BB")) {
				nombreReporte = "bolsin.jasper";
			} else if (tipo.equals("VD")) {
				nombreReporte = "bolsinVentaDir.jasper";
			} else if (tipo.equals("BE")) {
				nombreReporte = "beneficiarioExt.jasper";
			} else if (tipo.equals("OP")) {
				String literal = request.getParameter("lit");
				nombreReporte = "ordenPago.jasper";
				parametros.put("literal", literal);
			} else if (tipo.equals("LS")) { // Listado Solicitudes
				String f1 = request.getParameter("f1");
				String f2 = request.getParameter("f2");
				String codSolicitante = (String) parametros.get("codigo");

				nombreReporte = "listadoSol.jasper";
				parametros.put("soli", codSolicitante);
				parametros.put("f1", f1);
				parametros.put("f2", f2);
			} else if (tipo.equals("ROP")) {
				log.info("Entre a  la opcion  ROP reporte .................");
				String f1 = request.getParameter("f1");
				String f2 = request.getParameter("f2");
				String ee = request.getParameter("ee");
				nombreReporte = "listaOP.jasper";
				parametros.put("f1", f1);
				parametros.put("f2", f2);
				parametros.put("ee", ee);
			} else if (tipo.equals("RBO")) {
				String f1 = request.getParameter("f1");
				String f2 = request.getParameter("f2");
				String rr = request.getParameter("rr");
				if (rr.equals("R"))
					nombreReporte = "resumenBolsin.jasper";
				if (rr.equals("D"))
					nombreReporte = "detalleBolsin.jasper";
				if (rr.equals("C"))
					nombreReporte = "consultaBolsin.jasper";

				parametros.put("f1", f1);
				parametros.put("f2", f2);
			} else if (tipo.equals("DI")) {
				String f1 = request.getParameter("f1");
				nombreReporte = "diario.jasper";
				parametros.put("fecha", UtilsDate.dateFromString(f1, "dd/MM/yyyy"));
			} else if (tipo.equals("SE")) {
				Date fecha_desde = (Date) parametros.get("FECHA_DESDE");
				Date fecha_hasta = (Date) parametros.get("FECHA_HASTA");
				nombreReporte = "semanal.jasper";
				parametros.put("fecha", fecha_desde);
				parametros.put("fecha2", fecha_hasta);
			} else if (tipo.equals("SB")) {
				String f1 = request.getParameter("fecha");
				log.info("fecha:" + f1);
				Date fd = new Date();
				log.info("fechad:" + fd);
				nombreReporte = "sesion.jasper";
				parametros.put("fecha", f1);
				parametros.put("fechad", fd);
				
			} else if (tipo.equals("bolsinDetCompra")) {
				nombreReporte = "bolsinDetCompra.jasper";
			} else if (tipo.equals("transfExtSF")) {
				nombreReporte = "transexterior_sfin.jasper";
			} else if (tipo.equals("ordendepago")) {
				nombreReporte = "ordenDePago.jasper";
			} else if (tipo.equals("extractoCtas")) {
				nombreReporte = "extracto_movctascont.jasper";
			} else if (tipo.equals("soldetalle")) {
				nombreReporte = "solicitudresu.jasper";
			} else if (tipo.equals("cartacamisa")) {
				nombreReporte = "cartacredCamisaresu.jasper";
			} else if (tipo.equals("bolSF")) {
				nombreReporte = "Sioc/rptVentaUsdBolsinSisFinan.jasper";
			} else if (tipo.equals("bolCSF")) {
				nombreReporte = "Sioc/rptVentaUsdClienteBolsinFinanciero.jasper";
			} else if (tipo.equals("bolDSF")) {
				nombreReporte = "Sioc/rptVentaUsdDiaSisFinanciero.jasper";
			} else if (tipo.equals("bolDCSF")) {
				nombreReporte = "Sioc/rptVentaUsdDiaClienteFinanciero.jasper";
			} else if (tipo.equals("vDol")) {
				nombreReporte = "Sioc/rptVentaDolaresEEUU.jasper";
				banderaSubReporte = false;
			} else if (tipo.equals("gVeDiSisFin")) {
				nombreReporte = "Sioc/rptVentaDolares.jasper";
				banderaSubReporte = false;
			} else if (tipo.equals("gVeMensualSisFin")) {
				nombreReporte = "Sioc/rptGraficoVentaMensualSistemaFinanciero.jasper";
				banderaSubReporte = false;
			} else if (tipo.equals("gTransMenAlExt")) {
				nombreReporte = "Sioc/rptGraficoMensualAlExterior.jasper";
				banderaSubReporte = false;
			} else if (tipo.equals("gTransMenAlExtCPVIS")) {
				nombreReporte = "Sioc/rptGraficoMensualAlExteriorCPVIS.jasper";
				banderaSubReporte = false;
			} else if (tipo.equals("gTransMenDelExtCPVIS")) {
				nombreReporte = "Sioc/rptGraficoMensualDelExteriorCPVIS.jasper";
				banderaSubReporte = false;
			} else if (tipo.equals("vDOpCam")) {
				nombreReporte = "Sioc/rptOperacionesCambiarias.jasper";
				banderaSubReporte = false;
			} else if (tipo.equals("rptVentaUsdExpSF")) {
				// EXPORTADORS
				nombreReporte = "Sioc/rptVentaUsdExpSF.jasper";
			} else if (tipo.equals("rptVentaUsdComisdt")) {
				nombreReporte = "Sioc/rptVentaUsdComisdt.jasper";				
			} else if (ConstantesReportes.cReporteOperacionesCambiarias.equalsIgnoreCase(tipo)) {
				nombreReporte = "Sioc/rptOpCambiariasMillones.jrxml";
				banderaSubReporte = false;
			} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresEstadounidenses)) {
				nombreReporte = "Sioc/reporteDinamico.jrxml";
			} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresBolsinSistemaFinanciero)) {
				nombreReporte = "Sioc/reporteDinamico.jrxml";
			} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresDiaSistemaFinanciero)) {
				nombreReporte = "Sioc/reporteDinamico.jrxml";
			} else if (tipo.equals(ConstantesReportes.cReporteTransferenciasExterior)) {
				nombreReporte = "Sioc/reporteDinamico.jrxml";
			} else if (tipo.equals(ConstantesReportes.cReporteTransferenciasExteriorCpVis)) {
				nombreReporte = "Sioc/reporteDinamico.jrxml";
			} else if (tipo.equals(ConstantesReportes.cReporteTransferenciasDelExteriorCpVis)) {
				nombreReporte = "Sioc/reporteDinamico.jrxml";
			} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresBolsinClientesSistemaFinanciero)) {
				nombreReporte = "Sioc/reporteDinamico.jrxml";
			} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresDiaClientesSistemaFinanciero)) {
				nombreReporte = "Sioc/reporteDinamico.jrxml";
			} else if (tipo.equals("vOperacion")) {
				nombreReporte = "Sioc/rptOperacionesExcel.jasper";
				banderaSubReporte = false;
			}
			parametros.put("REPORT_LOCALE", new Locale("es", "BO"));
			if (nombreReporte != null) {
				String URL_SUBREPORT = getServletContext().getRealPath("/jasper/");
				parametros.put("SUBREPORT_DIR", URL_SUBREPORT + "/");

				if (!banderaSubReporte) {
					String subReportDir = URL_SUBREPORT + "/Sioc/subReporteVentaDolares/";
					log.info("Sub report dir " + subReportDir);
					parametros.put("SUBREPORT_DIR", subReportDir);
				}

				ServletContext context = this.getServletConfig().getServletContext();

				String reportFileName = context.getRealPath("/jasper/" + nombreReporte);
				if (reportFileName == null) {
					reportFileName = request.getContextPath() + "/jasper/" + nombreReporte;
				}

				log.info("reportFileName " + reportFileName);
				java.io.File reportFile = (new java.io.File(reportFileName));

				if (!reportFile.exists())
					throw new JRRuntimeException(
							"Archivo " + nombreReporte + " no encontrado. El reporte no puede ser visualizado, comunique al administrador del sistema.");

				parametros.put("BaseDir", reportFile.getParentFile());
				if (!parametros.containsKey("TITULO"))
					parametros.put("TITULO", "Operacion");
				if (!parametros.containsKey("USUARIO"))
					parametros.put("USUARIO", "usuario");

				String reportFormato = "pdf";
				if (parametros.containsKey(REPORTE_FORMATO)) {
					reportFormato = (String) parametros.get(REPORTE_FORMATO);
				}
				reportFormato = reportFormato.trim().toLowerCase();
				parametros.put(REPORTE_FORMATO, reportFormato);
				String nameFileOut = (tipo.concat(UtilsDate.stringFromDate(new Date(), "yyyyMMddHHss"))).concat(".").concat(reportFormato);
				parametros.put("nameFileOut", nameFileOut);
				/* ##### GENERANDO REPORTITO ############## */
				// whf 201609 se agrega opcion de imprimir en xls
				byte[] reportePDF = null;
				if (!parametros.containsKey("esDinamico")) {
					if (!parametros.containsKey("propioDt")) {
						reportePDF = obtenerReporte(reportFileName, parametros);
					} else {
						log.info("Entro Data Source Report");
						reportePDF = obtenerReporteDataSource(reportFileName, parametros);
					}
				} else {
					String vMes = "";
					int nroSemana = 0;

					if ((String) parametros.get("mes") != null) {
						vMes = (String) parametros.get("mes");
					}
					if (parametros.containsKey("nroSemana")) {
						if ((Integer) parametros.get("nroSemana") > 0)
							nroSemana = (Integer) parametros.get("nroSemana");
					}

					if (tipo.equals(ConstantesReportes.cReporteVentaDolaresEstadounidenses)) {
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 3, 1, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresBolsinSistemaFinanciero)) {
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresDiaSistemaFinanciero)) {
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteTransferenciasExterior)) {
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteTransferenciasExteriorCpVis)) {
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteTransferenciasDelExteriorCpVis)) {
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresBolsinClientesSistemaFinanciero)) {
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresDiaClientesSistemaFinanciero)) {
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (ConstantesReportes.cReporteOperacionesCambiarias.equalsIgnoreCase(tipo)) {
						reportePDF = obtenerReporteDinamico(reportFileName, parametros);
					} else {
						log.info(">>>>>>>>>>>>>> Entro Reporte Dinamico Data Source Report >>>>>>>>>>>>>>");
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					}
				}

				log.info("Formato " + nameFileOut);
				response.setHeader("Cache-Control", "no-cache");
				response.setHeader("Pragma", "no-cache");
				response.setDateHeader("Expires", 0);
				ServletOutputStream ouputStream = response.getOutputStream();
				response.setContentType(ArchivoUtil.getMimeFromExt(ArchivoUtil.obtenerExtension(nameFileOut)));
				response.setContentLength(reportePDF.length);
				response.setHeader("content-disposition", "inline; filename=\"" + nameFileOut + "\"");
				ouputStream.write(reportePDF, 0, reportePDF.length);
				ouputStream.flush();
				ouputStream.close();
			} else {
				throw new RuntimeException("No existe parametro de reporte, intente nuevamente");
			}

		} catch (Exception e) {
			log.error("Error al generar reporte " + e.getMessage(), e);
			try {
				StringWriter stringWriter = new StringWriter();
				PrintWriter out = new PrintWriter(stringWriter);
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Error al generar reporte</title>");
				//out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"/resources/css/theme.css\" title=\"Style\">");
				out.println("</head>");
				out.println("<body bgcolor=\"white\">");
				out.println("<span>Ocurrió un error al generar el reporte :</span>");
				out.println("<pre>");
				e.printStackTrace(out);
				out.println("</pre>");
				out.println("</body>");
				out.println("</html>");
				response.setHeader("Cache-Control", "no-cache");
				response.setHeader("Pragma", "no-cache");
				response.setDateHeader("Expires", 0);
				response.setContentType("text/html");
				response.getOutputStream().print(stringWriter.toString());

				out.flush();
				out.close();
			} catch (Exception e1) {
				log.error("Error al generar pagina de error de reporte " + e1.getMessage(), e1);
			}
		} finally {
			if (session != null) {
				log.info("Removiendo valores sesion reporte processRequest");
				session.removeAttribute("RPTSwift");
				session.removeAttribute("nombreReporte");
				session.removeAttribute("archivoSinple");
				session.removeAttribute("parametros");
			}
		}
	}

	private void desplegarReporte(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = null;
		try {
//			log.info("Inicio archivo simple ....");

			ArchivoSinple archivo = null;
			int cont = 0;
			session = request.getSession();
			do {
				// si el reporte no recibe parametros en los 10 seg
				archivo = (ArchivoSinple) session.getAttribute("archivoSinple");
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					log.error(e);
				}
				cont++;
				log.info("Recuperando archivo simple pdf ciclo" + cont);
			} while (archivo == null && cont <= 20);

			if (archivo != null) {
				Integer menCodmen = (Integer) session.getAttribute("RPTSwift");
				log.info("Archivo simple recuperado: " + menCodmen + " : " + archivo.getName());

				ServletOutputStream ouputStream = response.getOutputStream();
				response.setContentType(archivo.getContentType());
				response.setContentLength(archivo.getData().length);
				response.setHeader("Content-Disposition", "inline; filename=\"" + archivo.getName() + "\"");
				ouputStream.write(archivo.getData(), 0, archivo.getData().length);
				ouputStream.flush();
				ouputStream.close();
			}

		} catch (Exception e) {
			log.error("Error al generar reporte " + e.getMessage(), e);
			try {
				StringWriter stringWriter = new StringWriter();
				PrintWriter out = new PrintWriter(stringWriter);
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Error al generar reporte</title>");
				//out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"/resources/css/theme.css\" title=\"Style\">");
				out.println("</head>");
				out.println("<body bgcolor=\"white\">");
				out.println("<span>Ocurrió un error al generar el reporte :</span>");
				out.println("<pre>");
				e.printStackTrace(out);
				out.println("</pre>");
				out.println("</body>");
				out.println("</html>");
				response.setContentType("text/html");
				response.setHeader("Cache-Control", "no-cache");
				response.setHeader("Pragma", "no-cache");
				response.setDateHeader("Expires", 0);
				response.getOutputStream().print(stringWriter.toString());
				out.flush();
				out.close();
			} catch (Exception e1) {
				log.error("Error al generar pagina de error de reporte " + e1.getMessage(), e1);
			}
		} finally {
			if (session != null) {
				log.info("Removiendo valores sesion reporte");
				session.removeAttribute("RPTSwift");
				session.removeAttribute("archivoSinple");
				session.removeAttribute("nombreReporte");
				session.removeAttribute("parametros");
			}
		}

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String nombreReporte = request.getParameter("nombreReporte");
		log.info("doGet Reporte..." + nombreReporte);		
		if (nombreReporte != null && nombreReporte.equals("reporteSwiftPdf")) {
			Map<String, Object> parametros = null;
			int cont = 0;
			do {
				// si el reporte no recibe parametros en los 10 seg
				parametros = (Map<String, Object>) session.getAttribute("parametros");
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					log.error(e);
				}
				cont++;
				log.info("espeando parametroe de reporte ... " + cont);
			} while (parametros == null && cont <= 5);

			desplegarReporte(request, response);
		} else {
			processRequest(request, response);
		}
	}


	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String nombreReporte = (String) session.getAttribute("nombreReporte");
		log.info("doPost Reporte..." + nombreReporte);		
		if (nombreReporte != null && nombreReporte.equals("reporteSwiftPdf")) {
			Map<String, Object> parametros = null;
			int cont = 0;
			do {
				// report exists in 10 segs ?
				parametros = (Map<String, Object>) session.getAttribute("parametros");
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					log.error(e);
				}
				cont++;
				log.info("espeando parametroe de reporte ... " + cont);
			} while (parametros == null && cont <= 30);

			desplegarReporte(request, response);
		} else {

			processRequest(request, response);
		}
	}

	/**
	 * Returns a short description of the servlet.
	 * 
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Short description";
	}

	private static byte[] obtenerReporte(String pathReporteJasper, Map<String, Object> parametros) throws Exception {
		Connection connection = null;
		byte[] reportePdf = null;

		// FileOutputStream fos = null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			// String fileName = "D:/Coffee.jrxml";
			long startTime = System.currentTimeMillis();

			String formatReport = (String) parametros.get(REPORTE_FORMATO);
			connection = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
			connection.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
			JasperPrint jrprintFile = JasperFillManager.fillReport(pathReporteJasper, parametros, connection);
//			log.info("jrprintFile==" + jrprintFile);

			if (formatReport.trim().equalsIgnoreCase("xlsx") || formatReport.trim().equalsIgnoreCase("xls")) {
				JRXlsxExporter exporter = new JRXlsxExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);// Set configuration as
														// you
														// like it!!
				exporter.setConfiguration(configuration);
				exporter.exportReport();
			} else {
				reportePdf = JasperRunManager.runReportToPdf(pathReporteJasper, parametros, connection);
				out.write(reportePdf);
			}

			long endTime = System.currentTimeMillis();
			long time = (endTime - startTime) / 1;

			log.info("success with " + time + " s");
//			log.info("================== " + out.size());
			return out.toByteArray();
		} catch (Exception e) {
			log.error("Error al exportar a XCEL " + e.getMessage(), e);
			throw new Exception(e);
		} finally {
			try {
				if (connection != null)
					connection.close();
			} catch (Exception e1) {
				// throw new Exception(e1);
			}
		}
		// return reportePdf;
	}

	private static byte[] obtenerReporteDataSource(String pathReporteJasper, Map<String, Object> parametros) throws Exception {

		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			long startTime = System.currentTimeMillis();

			String formatReport = (String) parametros.get(REPORTE_FORMATO);

			JasperPrint jrprintFile = JasperFillManager.fillReport(pathReporteJasper, parametros, new JREmptyDataSource());

			if (formatReport.trim().equalsIgnoreCase("xlsx") || formatReport.trim().equalsIgnoreCase("xls")) {
				JRXlsxExporter exporter = new JRXlsxExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);// Set configuration as
														// you
														// like it!!
				Map<String, String> numberFormats = new HashMap<String, String>();
				configuration.setDetectCellType(true);
				exporter.setConfiguration(configuration);
				exporter.exportReport();
			} else {
				JRPdfExporter exporter = new JRPdfExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

				exporter.exportReport();
			}

			long endTime = System.currentTimeMillis();
			long time = (endTime - startTime) / 1;

			log.info("success with " + time + " s");
			log.info("================== " + out.size());
			return out.toByteArray();
		} catch (Exception e) {
			log.error("Error al exportar a XCEL " + e.getMessage(), e);
			throw new Exception(e);
		}
		// return reportePdf;
	}

	private static byte[] obtenerReporteDinamico(String pathReporteJasper, Map<String, Object> parametros) throws Exception {
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {

			long startTime = System.currentTimeMillis();
			java.io.InputStream is = new FileInputStream(pathReporteJasper);
			List<String> columnHeaders = (List<String>) parametros.get("headers");

			List<List<String>> rows = (List<List<String>>) parametros.get("rows");

			JasperDesign jasperReportDesign = JRXmlLoader.load(is);
			DynamicReportBuilder reportBuilder = new DynamicReportBuilder(jasperReportDesign, columnHeaders.size());

			if (parametros.containsKey("tipoReporteDinamico")) {
				String tipoReporteDinamico = parametros.get("tipoReporteDinamico").toString();
				if ("opCambiarias".equalsIgnoreCase(tipoReporteDinamico)) {
					reportBuilder.addDynamicColumns();
				} else if ("transAlExterior".equalsIgnoreCase(tipoReporteDinamico)) {
					reportBuilder.addDynamicColumnsTransExt();
				}
			}

			JasperReport jasperReport = JasperCompileManager.compileReport(jasperReportDesign);

			String formatReport = (String) parametros.get(REPORTE_FORMATO);
			parametros.put("REPORT_TITLE", "Sample Dynamic Columns Report");
			DynamicColumnDataSource pdfDataSource = new DynamicColumnDataSource(columnHeaders, rows, "");

			JasperPrint jrprintFile = JasperFillManager.fillReport(jasperReport, parametros, pdfDataSource);
			log.info("jrprintFile==" + jrprintFile);

			if (formatReport.trim().equalsIgnoreCase("xlsx") || formatReport.trim().equalsIgnoreCase("xls")) {
				JRXlsxExporter exporter = new JRXlsxExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);// Set configuration as
														// you
														// like it!!
				configuration.setDetectCellType(true);

				exporter.setConfiguration(configuration);
				exporter.exportReport();
			} else {
				JRPdfExporter exporter = new JRPdfExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

				exporter.exportReport();
			}

			long endTime = System.currentTimeMillis();
			long time = (endTime - startTime) / 1;

			log.info("success with " + time + " s");
			log.info("================== " + out.size());
			return out.toByteArray();
		} catch (Exception e) {
			log.error("Error al exportar a XCEL " + e.getMessage(), e);
			throw new Exception(e);
		}
	}

	private static byte[] generaReporteDinamico(String pathReporteJasper, Map<String, Object> parametros, int pCantidadColumnas, int pNroColumnaPivote,
			int pEstiloReporte, String pMes) throws Exception {
		final ByteArrayOutputStream out = new ByteArrayOutputStream();

		try {
			String vFormatoReporte = (String) parametros.get(REPORTE_FORMATO);
			long startTime = System.currentTimeMillis();

			java.io.InputStream vRutaReporte = new FileInputStream(pathReporteJasper);

			JasperDesign jasperReportDesign = JRXmlLoader.load(vRutaReporte);
			List<String> vListaCabeceraReporte = (List<String>) parametros.get("headers");

			List<List<String>> vListaCuerpoReporte = (List<List<String>>) parametros.get("rows");

			ConstructorReporteDinamico vObjReporte = new ConstructorReporteDinamico(jasperReportDesign, vListaCabeceraReporte.size(), pCantidadColumnas,
					pNroColumnaPivote, pEstiloReporte);

			vObjReporte.addDynamicColumns();

			JasperReport jasperReport = JasperCompileManager.compileReport(jasperReportDesign);

			parametros.put("REPORT_TITLE", "Reporte dinamico.");

			DynamicColumnDataSource pdfDataSource = new DynamicColumnDataSource(vListaCabeceraReporte, vListaCuerpoReporte, pMes);
			JasperPrint jrprintFile = JasperFillManager.fillReport(jasperReport, parametros, pdfDataSource);

			log.info("jrprintFile==" + jrprintFile);

			if (vFormatoReporte.trim().equalsIgnoreCase("xlsx") || vFormatoReporte.trim().equalsIgnoreCase("xls")) {
				JRXlsxExporter vObjExcel = new JRXlsxExporter();
				vObjExcel.setExporterInput(new SimpleExporterInput(jrprintFile));
				vObjExcel.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);
				Map<String, String> numberFormats = new HashMap<String, String>();
				configuration.setDetectCellType(true);
				vObjExcel.setConfiguration(configuration);
				vObjExcel.exportReport();
			} else {
				JRPdfExporter vObjPdf = new JRPdfExporter();
				vObjPdf.setExporterInput(new SimpleExporterInput(jrprintFile));
				vObjPdf.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
				vObjPdf.exportReport();
			}
			long endTime = System.currentTimeMillis();
			long time = (endTime - startTime) / 1;

			log.info("success with " + time + " s");
			return out.toByteArray();
		} catch (Exception e) {
			log.error("Error al exportar a XCEL " + e.getMessage(), e);
			throw new Exception(e);
		}
	}

}
