package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Datosmen;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaSolicitudesBCBController {
	private SocSolicitudes solicitud = new SocSolicitudes();
	private SolicitudesS solicitudS = new SolicitudesS();
	private SocDetallessol detalle = new SocDetallessol();
	private CuentasBen cuentaBen = new CuentasBen();
	private List<SolicitudesS> solicitudes;
	private List<SocSolicitudes> listaSoli;
	private List<Datosmen> listaCampos;

	private String panel = "";
	private String verP = "";
	private String cuentaD = "";
	private String cuentaB = "";
	private String moneda = "";
	private Date fechaValor;
	private Boolean montoVer = false;
	private Boolean cuentaVer = true;
	private Boolean nroVer = false;
	private Boolean generada = true;
	private Boolean interVer = false;
	private Boolean extVer = true;
	private Boolean botonHab = false;
	private String nroOperacion;
	private String codIns;
	private String nombre = "";
	private String mensaje = "";
	private String label1 = "BIC:";
	private String bic = "";

	private String urlReporte;

	private Logger log = Logger.getLogger(ListaSolicitudesBCBController.class);

	public ListaSolicitudesBCBController() {
		this.recuperarSolicitudes();
	}

	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SolicitudesS>();
		this.listaSoli = new ArrayList<SocSolicitudes>();

		String query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
				+ " and s.cla_estado = 'R'" + " and s.sol_codigo = '900   '";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				solicitudS = new SolicitudesS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_tipo"), (String) res.get("moneda"), 'B', (Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"),
						(String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"), (BigDecimal) res.get("soc_montomn"), "");

				solicitudS.setPanel1(true);
				solicitudS.setPanel2(false);
				solicitudS.setPanel3(false);
				solicitudS.setTipo("TRANSFERENCIA AL EXTERIOR");
				if (solicitudS.getSocCorrelativo().substring(0, 3).equals("ADM"))
					solicitudS.setSolicitante("ADMINISTRACION");
				else
					solicitudS.setSolicitante("RECURSOS HUMANOS");
				solicitudes.add(solicitudS);

				solicitud = new SocSolicitudes((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_tipo"),
						(Integer) res.get("soc_cuentad"), (String) res.get("soc_nrocuentad"), (String) res.get("moneda"), 'B',
						(Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"), (Integer) res.get("soc_cuentac"),
						(String) res.get("soc_nrocuentac"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"),
						(BigDecimal) res.get("soc_montomn"), (String) res.get("soc_nropago"), (String) res.get("monedat"));
				listaSoli.add(solicitud);
			}
		} else {
			log.info("Lista Nula");
		}
	}

	public void verSolicitud(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.solicitudS = this.solicitudes.get(fila);
		this.solicitud = this.listaSoli.get(fila);
		botonHab = false;

		if (solicitud.getSocNrocuentad() != null)
			nroVer = true;
		else
			nroVer = false;

		String query = " select s.* " + " from soc_detallessol s " + " where s.soc_codigo = '" + solicitud.getSocCodigo() + "'"
				+ " and s.det_codigo = 1";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1.size() > 0) {
			for (Map<String, Object> res : resultado1) {

				detalle = new SocDetallessol(new SocDetallessolId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"), (String) res.get("moneda"),
						(Integer) res.get("det_ctabenef"), (String) res.get("det_concepto"), (String) res.get("det_info"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("monedat"), (String) res.get("det_facturas"));
			}
		} else {
			log.info("Lista Nula");
		}

		query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
				+ solicitud.getSocCuentad() + "'";

		List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
		if (resultadoD.size() == 1) {
			for (Map<String, Object> res : resultadoD) {

				cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-USD";
			}
		} else {
			log.info("Lista Nula");
		}

		query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
				+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
				+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.ben_codigo) = '" + detalle.getBenCodigo() + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {

				nombre = (String) res.get("ben_nombre");
			}
		} else {
			log.info("Lista Nula");
		}

		query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
				+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
				+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
				+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
				+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
				+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + detalle.getDetCtabenef() + "'";

		List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
		if (resultado2.size() == 1) {
			interVer = true;
			for (Map<String, Object> res : resultado2) {

				cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
						(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"),
						(String) res.get("pla_intermediario"), (String) res.get("pla_nrocuenta"), (String) res.get("bco1"), (String) res.get("pla1"));
			}
			label1 = "Cuenta:";
			bic = cuentaBen.getPlaNroCuenta();
		} else {
			query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
					+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + detalle.getDetCtabenef() + "'";

			List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
			if (resultado3.size() == 1) {
				interVer = false;
				for (Map<String, Object> res : resultado3) {

					cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
							(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"));
				}
				label1 = "BIC:";
				bic = cuentaBen.getPlaBic();
			} else {
				interVer = false;
				log.info("Lista Nula");
			}
		}
	}

	public void eventoGenerarBtn(ActionEvent action) {
		DateTime fecha = new DateTime();
		DateTime fechaV = new DateTime(fechaValor);
		log.info("fecha: " + fecha);
		log.info("valor: " + fechaV);

		if ((fechaV.getDayOfMonth() > fecha.getDayOfMonth() && fechaV.getMonthOfYear() == fecha.getMonthOfYear())
				|| (fechaV.getDayOfMonth() < fecha.getDayOfMonth() && fechaV.getMonthOfYear() > fecha.getMonthOfYear())) {
			log.info("Generando la operación: ");
			// parametros para request
			String id = new Long(new Date().getTime()).toString();

			// mapa de parametros a enviar a BPM
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "operacion");

			// enviando objeto del formulario
			mapaParametros.put("solicitud", solicitud);
			mapaParametros.put("detalle", detalle);
			mapaParametros.put("fecha", this.fechaValor);

			// Metodo estatico que se encarga de manejar las consultas al BPM
			// parametros
			// nombre BPM, ipRequest, requester, feature, mapaParametros, id
			Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros,
					id);
			if (mapaRespuesta.containsKey("resp_msgerror")) {
				mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
				return;
			}

			nroOperacion = (String) mapaRespuesta.get("nroOperacion");
			codIns = (String) mapaRespuesta.get("nroInst");

			if (!nroOperacion.equals("0000")) {
				log.info("Numero de Operación asignada desde el BPM: " + nroOperacion);

				generada = true;

				String ln = System.getProperty("line.separator");

				this.listaCampos = new ArrayList<Datosmen>();

				String query1 = " select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre " + " from soc_datosmen d, soc_campos c "
						+ " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'" + " and d.ins_codigo = '" + codIns + "'";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1);
				if (resultado1 != null) {
					for (Map<String, Object> res : resultado1) {

						String alto;
						String valor = "";
						String valor1 = (String) res.get("dam_valor");
						if (res.get("cam_codigo").equals(":32A")) {
							valor = valor1;
							valor1 = valor.substring(0, 6) + ln + valor.substring(6, 9) + ln + valor.substring(9);
						}

						if (res.get("cam_codigo").equals(":33B")) {
							valor = valor1;
							valor1 = valor.substring(0, 3) + ln + valor.substring(3);
						}

						int i = StringUtils.countMatches(valor1, ln);
						i = (i + 1) * 16;
						alto = " height : " + i + "px;";

						listaCampos.add(new Datosmen((String) res.get("cam_codigo"), (String) res.get("ins_codigo"), valor1, alto, (String) res
								.get("cam_nombre")));
					}
				} else {
					log.info("Lista Nula");
				}

				this.recuperarSolicitudes();
			}

			else {
				log.info("No se pudo generar la operación.");
				mensaje = "No se pudo generar la operación. No existe tipo de cambio para la fecha especificada.";
				generada = false;
			}
		} else {
			log.info("No se puede generar la operación con fecha anterior.");
			mensaje = "No se puede generar la operación con fecha valor anterior a la fecha actual.";
			generada = false;
		}
	}

	public void eventoAnularBtn(ActionEvent action) {
		log.info("Anulando la solicitud: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "anular");

		mapaParametros.put("solicitud", solicitud);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado asignado desde el BPM: " + estado);

		mensaje = "Se anuló la solicitud registrada.";
		botonHab = true;
		this.recuperarSolicitudes();
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitud) {
		this.solicitud = solicitud;
	}

	public SolicitudesS getSolicitudS() {
		return solicitudS;
	}

	public void setSolicitudS(SolicitudesS solicitudS) {
		this.solicitudS = solicitudS;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public CuentasBen getCuentaBen() {
		return cuentaBen;
	}

	public void setCuentaBen(CuentasBen cuentaBen) {
		this.cuentaBen = cuentaBen;
	}

	public List<SolicitudesS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SolicitudesS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public List<Datosmen> getListaCampos() {
		return listaCampos;
	}

	public void setListaCampos(List<Datosmen> listaCampos) {
		this.listaCampos = listaCampos;
	}

	public String getPanel() {
		return panel;
	}

	public void setPanel(String panel) {
		this.panel = panel;
	}

	public String getVerP() {
		return verP;
	}

	public void setVerP(String verP) {
		this.verP = verP;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public Boolean getCuentaVer() {
		return cuentaVer;
	}

	public void setCuentaVer(Boolean cuentaVer) {
		this.cuentaVer = cuentaVer;
	}

	public void setNroVer(Boolean nroVer) {
		this.nroVer = nroVer;
	}

	public Boolean getNroVer() {
		return nroVer;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Date getFechaValor() {
		return fechaValor;
	}

	public void setFechaValor(Date fechaValor) {
		this.fechaValor = fechaValor;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaB() {
		return cuentaB;
	}

	public void setCuentaB(String cuentaB) {
		this.cuentaB = cuentaB;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public void setExtVer(Boolean extVer) {
		this.extVer = extVer;
	}

	public Boolean getExtVer() {
		return extVer;
	}

	private static String getRaiz() {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String url = request.getRequestURL().toString();
		String direccionRaiz = null;
		if (url.indexOf("/faces") > 0)
			direccionRaiz = url.substring(0, url.indexOf("/faces")) + "/";
		else
			direccionRaiz = url;
		return direccionRaiz;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + codIns + "&tipo=SW";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

}
